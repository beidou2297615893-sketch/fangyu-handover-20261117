"""Combine only sealed automatic-analysis sources; preserve F104/current app."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,importlib.util,json,shutil,sys
sys.dont_write_bytecode=True
sys.stdout.reconfigure(encoding='utf-8')
W=Path(__file__).resolve().parent;P=W.parents[1]
F=P/'work/parallel-integration-20261018/final-integration'
OLD=F/'candidate-unified-v104'
PUBLIC=P/'work/complete-product-resume-20261024/live-acquisition-acceptance-20261024/project'
read=lambda p:json.loads(p.read_text('utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert len(sys.argv)==6 and sys.argv[1:3]==['--compose','--core-pins'] and sys.argv[4]=='--bridge-pins'
core_pins=Path(sys.argv[3]).resolve();bridge_pins=Path(sys.argv[5]).resolve()
assert core_pins.is_relative_to(W/'backpressure-f105/core') and bridge_pins.is_relative_to(W/'backpressure-f105/bridge')
core,bridge=read(core_pins),read(bridge_pins)
assert core['passed'] is True and bridge['passed'] is True
rows=[*core['files'],*bridge['files']]
allowed={'work/shared-backend-integration/platform_runtime.py',
    'work/ui-native-r57/workbench_backend.py','work/ui-native-r57/ui_native_host.py',
    'work/ui-approved-implementation/ui-preview/app.mjs',
    'work/ui-approved-implementation/ui-preview/backend.mjs',
    'work/ui-approved-implementation/ui-preview/pages/acquire.mjs',
    'work/ui-approved-implementation/ui-preview/pages/saved-comment-analysis.mjs'}
relatives={r['relativePath'].replace('\\','/') for r in rows}
assert len(relatives)==len(rows) and relatives<=allowed
assert {'work/shared-backend-integration/platform_runtime.py','work/ui-approved-implementation/ui-preview/pages/acquire.mjs','work/ui-approved-implementation/ui-preview/pages/saved-comment-analysis.mjs'}==relatives
assert not (F/'candidate-unified-v105').exists()
spec=importlib.util.spec_from_file_location('existing_f105_freezer',F/'freeze_unified.py')
builder=importlib.util.module_from_spec(spec);spec.loader.exec_module(builder);builder.SOURCE=PUBLIC
baseline=read(OLD/'INPUT-SNAPSHOT.json')
actual={p.relative_to(PUBLIC).as_posix():sha(p) for p in builder.input_files()}
assert actual==baseline['files'],'Unreviewed public source change'
for r in rows:
    rel=r['relativePath'].replace('\\','/')
    assert sha(Path(r['candidate']))==r['sha256'],rel
    assert sha(PUBLIC/rel)==sha(OLD/'project'/rel)==r['baselineSha256'],rel
pack=W/'package';backup=pack/'public-before-f105';backup.mkdir(exist_ok=False)
for r in rows:
    rel=r['relativePath'].replace('\\','/');target=PUBLIC/rel;before=backup/rel
    before.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(target,before)
    shutil.copy2(Path(r['candidate']),target)
composition={'atUtc':datetime.now(timezone.utc).isoformat(),'baselineInputFiles':len(actual),
    'baselineInputsMatchF104':True,'changes':rows,
    'coreValidation':str(core_pins),'coreValidationSha256':sha(core_pins),
    'bridgeValidation':str(bridge_pins),'bridgeValidationSha256':sha(bridge_pins),
    'userAuthorizedAutomaticWorkspaceAnalysis':True,'productionWrites':0,'currentWindowOperated':False}
(pack/'ROOT-COMPOSITION-V105.json').write_text(json.dumps(composition,ensure_ascii=False,indent=2)+'\n','utf-8')
sys.argv=[str(F/'freeze_unified.py'),'--candidate','candidate-unified-v105'];builder.main()
out=F/'candidate-unified-v105';stage=read(out/'STAGED.json');native=Path(stage['release'])
old_native=Path(read(OLD/'STAGED.json')['release'])
a={p.relative_to(old_native).as_posix():sha(p) for p in old_native.rglob('*') if p.is_file()}
b={p.relative_to(native).as_posix():sha(p) for p in native.rglob('*') if p.is_file()}
delta=sorted(k for k in a.keys()|b.keys() if a.get(k)!=b.get(k))
def release_path(rel):
    if 'ui-preview/' in rel:return 'web/'+rel.split('ui-preview/',1)[1]
    if rel.startswith('work/ui-native-r57/'):return rel.split('work/ui-native-r57/',1)[1]
    if rel.startswith('work/shared-backend-integration/'):return 'resources/platform-runtime/'+rel.split('work/shared-backend-integration/',1)[1]
    raise AssertionError(rel)
assert set(delta)=={'RELEASE.json'}|{release_path(rel) for rel in relatives},delta
assert b['web/pages/reply-connected.mjs']=='92bda4b28c8fe91ae3ae789c137e14a940a16ce68e1ffc2dbeb521267b1476f5'
pins={'status':'FROZEN_PENDING_VERIFICATION','releaseId':stage['release_id'],'release':str(native),
    'project':str(out/'project'),'unifiedPinsSha256':sha(out/'UNIFIED-PINS.json'),
    'stagedSha256':sha(out/'STAGED.json'),'manifestSha256':sha(native/'RELEASE.json'),
    'changedProductSourceFiles':len(rows),'changedReleaseFiles':delta,'productionWrites':0,
    'installed':False,'actualNewNativeVerified':False}
(pack/'ROOT-FINAL-PINS-V105.json').write_text(json.dumps(pins,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps(pins,ensure_ascii=False),flush=True)
