# F105 缓冲阻断独立根因

2026-10-25 01:39:57 UTC 对正式库做一次一致性只读投影。没有构造正式 Core、修改数据库、访问模型或采集，也没有操作窗口。记录只含脱敏计数和安全状态；正文、昵称、账号标识、原客户 ID 与凭据均未输出。

## 正式现状

当前任务510条：487条确认分析、9条原请求待核、14条缺正文、0条可继续分析。采集页旧分析 ledger 目前只有14个ID（9条待核、5条缺正文），并不是仍存200个ID。ledger 的原任务 binding 正确，code 仍是 PRODUCT_REQUEST_UNKNOWN；旧 ai_jobs 是 paused、同 code、pending19。独立自动分析的任务 control 已为 held、无错误 code，说明新分析本身已处理完可分析部分。

旧 collection run receipt 留着 status=paused、stop_reason=analysis_backlog、analysis_hold=true。它是历史采集停因，未随着后台分析排空而消失。

## 冻结 F104 的四层残留耦合

1. `analysis_blocks_new_batch` 只允许无错误 pending page 加 completed/pending0 job 的特别组合。原14条未知页加旧 ai_job 因此仍返回 true，`snapshot.canStart` 直接取反，完全不问当前可分析数是否为0。
2. `snapshot` 把任何存在的旧 pending page 投影为采集 paused；其 backlog 是 `added-confirmed`，当前等于23，把9条待核和14条缺正文也包括在内。它并非自动分析的 processable0。
3. `analysisBufferMessage` 仅凭历史 stopReason/文案含 analysis_backlog 或200就固定提示“达到200”，没有核本次待分析数，因此上方0与下方200同时出现。
4. 即使仅让 canStart=true，实际 `_bounded_collection` 的三处200检查/等待仍会在自动模式下停采或等待：页前比较 backlog>=200、页后独立分析非running且backlog>=200、最后等待 pending ledger ID 数<200。历史 ledger 或本人暂停分析都会使该链继续受阻。因此验收必须运行真实方法的页循环、断点和队列交接，不能只看 UI。

## F105 必须验收

- 自动模式：当前0可分析加14条旧未知/缺文，开始与继续不被分析账本挡住；14条原ID、原请求、原 binding/code 和原断点保持，通知同一独立分析消费者，不进入旧请求重提。
- 自动模式：真实未完成数大于200，页前不硬停、页后不等旧200 ledger清空；本人暂停分析不被采集隐式恢复，后台分析也不随采集暂停。
- legacy 无独立消费者路径保留原200背压与错误处理。
- 账号未就绪、平台验证码/人脸、员工/门店/任务权限、device/scope变化、真正CLI失败仍按原门槛停止；本次不扩大采集授权。
- UI依据当前事实显示历史缓冲已解除或自动排队，不凭历史stop_reason伪称当前200，也不在前端自行把后端 canStart=false 强改成true。

原始脱敏证据：`FORMAL-BACKPRESSURE-ROOT-CAUSE.json`。该只读证据不能观察控制器 RAM 中本次 processing20；原 submitted 记录仅记为待核，不冒称正在运行。
