"""Persist the installation/actual-version checkpoint without operating the UI."""
from pathlib import Path
from datetime import datetime,timezone
import json,sys
D=Path(__file__).resolve().parent;W=D.parent;P=W.parents[1]
read=lambda p:json.loads(p.read_text('utf-8-sig'))
assert sys.argv[1:] in (['installed'],['actual'],['actual','--user-confirmed-entry'])
installed=read(W/'INSTALLED-VERIFICATION-F107.json')
assert installed['protectedRecordsUnchanged'] is True
pins=read(W/'package/ROOT-FINAL-PINS-V107.json')
latest=sorted(W.glob('ACTUAL-ANALYSIS-*.json'))[-1];actual=read(latest)
matches=actual['actualRelease']==pins['releaseId']
confirmed=sys.argv[1:]==['actual','--user-confirmed-entry']
if sys.argv[1]=='actual':assert matches
state={'status':'ACTUAL_ENTRY_USER_CONFIRMED' if confirmed else 'ACTUAL_VERSION_VERIFIED_ENTRY_PENDING' if matches else 'INSTALLED_AWAITING_USER_NORMAL_REOPEN',
 'atUtc':datetime.now(timezone.utc).isoformat(),'installedRelease':pins['releaseId'],'actualRelease':actual['actualRelease'],
 'actualPid':actual['pid'],'actualMatchesInstalled':matches,'userConfirmedEntry':confirmed,
 'rootCause':'Historical analysis page/job locks new collection and old stop reason falsely says current backlog200; independent analysis itself already drained.',
 'automaticWorkspaceHasNo200CollectionCap':True,'savedCommentsAnalyzedIndependently':True,
 'scopeAndPlatformGuardsPreserved':True,'coldEmptyQueueAndLockOrderChecksPassed':True,
 'commentsPreserved':actual['allComments'],'aiResultsPreserved':actual['hasAI'],
 'original1794JudgmentsPreserved':actual['originalAnalyzedRecordsPreserved'],'accountsPreserved':3,
 'currentTaskProcessableRemaining':actual['currentTaskCounts']['pending'],
 'originalRequestHeldComments':actual['workspaceBacklogTaskCounts']['held'],'missingBody':actual['workspaceBacklogTaskCounts']['missingText'],
 'actualRealPlatformCollectionTestedThisRepair':False,'automaticCollectionOrSend':False,
 'formalDataDirectWrites':0,'nativeWindowOperated':False,'fullThreeInOneComplete':False,
 'evidence':{'installed':str(W/'INSTALLED-VERIFICATION-F107.json'),'rootGates':str(W/'package/ROOT-GATES-V107.json'),
 'packageReview':str(W/'package/FINAL-PACKAGE-REVIEW-V107.json'),'coreSeal':str(D/'core/v3/SEALED.json'),
 'latestActual':str(latest),'protectedBefore':str(W/'FORMAL-BEFORE-F107.json'),'protectedAfter':str(W/'FORMAL-AFTER-F107.json')}}
(D/'STATE.json').write_text(json.dumps(state,ensure_ascii=False,indent=2)+'\n','utf-8')
main=read(W/'STATE.json');main['collectionBackpressureRepair']=state
main['latestAuthorizedFocus']='Remove historical200 collection gate under trusted automatic workspace; preserve independent background analysis and all original data.'
(W/'STATE.json').write_text(json.dumps(main,ensure_ascii=False,indent=2)+'\n','utf-8')
central=P/'work/quota-resume-plan-20261023/STATE.json'
if central.exists():
 c=read(central);c['analysisQueueRecovery']=main;c['latestAuthorizedFocus']=main['latestAuthorizedFocus']
 central.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n','utf-8')
line='\n\n## Independent collection/analysis repair '+state['atUtc']+'\n\n'+(
 '- Release '+pins['releaseId']+' installed to original desktop entry; actual '+str(actual['actualRelease'])+'. User entry confirmed: '+str(confirmed)+'. No window operated.\n'
 '- Trusted automatic workspace no longer has old200 collection cap; old unknown page/job/stop-reason does not deny new capture. Legacy fallback limits, task/page binding errors, original account/device/platform/target/daily guards retained. Unknown AI requests not replayed.\n'
 '- Core final v3 027cc487, two UI sources; exact frozen core10+lock2+cold2+UI12 and Native gates passed. Inactive F105 rejected for lock cycle; inactive F106 superseded for cold capability decoupling, not claimed a permanent production failure. Neither installed.\n'
 '- Formal11 record classes identical before/after install:2068 comments/2018 AI cache/3 accounts and all drafts/breakpoints retained. Actual platform collection not run; user operates and sends manually. Full three-in-one scope incomplete.\n'
 '- Evidence: work/analysis-queue-recovery-20261024/backpressure-f105/STATE.json and package ROOT-GATES/FINAL-PACKAGE-REVIEW-V107.\n')
with (P/'work/commercial-integration-20261022/HANDOFF-THREE-IN-ONE-LATEST.md').open('a',encoding='utf-8') as f:f.write(line)
print(json.dumps({k:v for k,v in state.items() if k not in ('evidence','rootCause')},ensure_ascii=False))
