from pathlib import Path
import ast,hashlib,importlib.util,io,json,os,socket,subprocess,sys,unittest
from unittest.mock import patch
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
W=HERE.parents[1]
SOURCE=W/'core-audit/legacy-status-recovery'
MODULE=SOURCE/'candidate/analysis_queue_runtime.py'
BASELINE=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/candidate-unified-v102/project/work/ui-native-r57/releases/ui-r57-20261024T142602Z-eec3748c/resources/platform-runtime/analysis_queue_runtime.py')
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module);return module
def functions(path):
    tree=ast.parse(path.read_text('utf-8-sig'))
    cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='AnalysisQueueRuntime')
    return {n.name:ast.dump(n,include_attributes=False) for n in cls.body if isinstance(n,ast.FunctionDef)}

before=sha(MODULE)
sys.argv=[str(SOURCE/'tests/test_legacy_status.py'),'--module',str(MODULE),'--output',str(HERE/'author-tests')]
author=load('independent_legacy_tests',SOURCE/'tests/test_legacy_status.py')
author.base.HERE=HERE/'fixtures'
stream=io.StringIO()
with patch.object(socket.socket,'connect',author.base.deny),patch('subprocess.Popen',side_effect=author.base.deny):
    suite=unittest.TestSuite(author.LegacyStatus(name) for name in author.LegacyStatus.__dict__ if name.startswith('test_'))
    result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
(HERE/'AUTHOR-TEST-RERUN.log').write_text(stream.getvalue(),'utf-8')
assert result.wasSuccessful(),stream.getvalue()
module=author.base.candidate
matrix=[]
def error(code,status=None,context=None):
    e=ValueError('safe fixture');e.code=code
    if status is not None:e.http_status=status
    if context is not None:e.__context__=context
    return e
for status in (None,400,401,403,409,429,500,503):
    got=module._legacy_status_unavailable(error('AI_LEGACY_EXTENSIONS_DISABLED',status))
    assert got is (status==503),(status,got)
    matrix.append({'case':'exact code HTTP'+str(status),'accepted':got})
for status in (400,401,403,429,500):
    got=module._legacy_status_unavailable(error('AI_LEGACY_EXTENSIONS_DISABLED',503,error('OTHER',status)))
    assert got is False,(status,got)
    matrix.append({'case':'conflicting context HTTP'+str(status),'accepted':got})
assert not module._legacy_status_unavailable(error('AI_PROVIDER_UNAVAILABLE',503))
matrix.append({'case':'different code HTTP503','accepted':False})

# Additional full read of a malformed old diagnostic row, using only in-memory
# authority/store fixtures. No Core or WorkbenchBackend construction.
sys.path.insert(0,str(HERE.parent/'tests'))
combined=load('independent_combined_memory',HERE.parent/'tests/test_combined_controller.py')
combined.controller=module
f=combined.combined();c=f._analysis_controller()
ident=c._record_id(f.user,'store1','task1')
f.core.store.put(module.ENTITY,{'id':ident,'tenant_id':'tenant','status':'blocked','code':'AI_LEGACY_EXTENSIONS_DISABLED',
    'phase':'untrusted fixture comment content','heldStatusCode':'untrusted fixture content'})
view=f._analysis_queue_dispatch('analysis_queue_read',{'storeId':'store1','taskId':'task1'},'fixture-token')['analysisQueue']
assert view['phase']=='' and view['heldStatusCode']=='',view
assert 'untrusted fixture' not in json.dumps(view)
assert '企业AI旧接口停用' in view['message']
c.close()

# Exact current shape:186 new candidates,9 held,14 missing,301 existing AI.
# This independently exercises the patched scheduler without a production Core.
memory_module=load('independent_recovery_memory',HERE.parent/'tests/test_review_memory.py')
memory_module.controller=module
memory_module.combined=combined.combined
f=memory_module.memory(510)
for i in range(9,23):f.core.store.rows[('leads',str(i))]['text']=''
for i in range(23,324):f.core.store.rows[('leads',str(i))]['ai_intent']={'status':'graded','level':'high','fixture':'existing'}
old_attempt={'id':'original-held','tenant_id':'tenant','owner':'tester','operation':'intent_analyze','state':'unknown',
 'request_id':'11111111-2222-3333-4444-555555555555','lead_digests':[module._digest(['tenant','tester',str(i)]) for i in range(9)]}
f.core.store.rows[('ai_attempts',old_attempt['id'])]=dict(old_attempt)
protected_rows=[f.core.store.get('leads',str(i)) for i in range(324)]
old_task=f.core.store.get('tasks','task1');old_reply=f.core.store.get('replies','manual')
def old_status(user,data):
    assert data['request_id']==old_attempt['request_id']
    raise error('AI_LEGACY_EXTENSIONS_DISABLED',503)
f.platform_runtime.service.executor.ai.attempts.status=old_status
f._analysis_queue_dispatch('analysis_queue_resume',{'storeId':'store1','taskId':'task1','confirmed':True},'fixture-token')
final=memory_module.wait(f,487)
assert final['counts']=={'total':510,'pending':0,'held':9,'analyzed':487,'missingText':14},final
assert final['heldStatusCode']=='AI_LEGACY_EXTENSIONS_DISABLED'
assert f.core.store.get('ai_attempts',old_attempt['id'])==old_attempt
assert [f.core.store.get('leads',str(i)) for i in range(324)]==protected_rows
assert f.core.store.get('tasks','task1')==old_task and f.core.store.get('replies','manual')==old_reply
assert sum(len(payload['ids']) for operation,payload in f.calls if operation=='intent_analyze')==186
f._analysis_queue.close()

old,new=functions(BASELINE),functions(MODULE)
protected=('__init__','close','_scope','_guard','_inventory','_dispatch_batch_guard','_sync_confirmed_queue','execute','authorize_collection','_retire_dormant')
unchanged={name:old[name]==new[name] for name in protected}
assert all(unchanged.values()),unchanged
assert before==sha(MODULE),'candidate changed during independent review'
report={'passed':True,'module':str(MODULE),'moduleSha256':before,'baseline':str(BASELINE),'baselineSha256':sha(BASELINE),
        'authorCaseCount':result.testsRun,'authorErrors':len(result.errors),'authorFailures':len(result.failures),
        'independentHttpMatrix':matrix,'malformedPhaseAndSafeMessage':'PASS','protectedFunctionsAstIdentical':unchanged,
        'exactCurrentShapeMemory':{'total':510,'newlyAnalyzed':186,'held':9,'missingText':14,'existingAiPreserved':301,
            'originalAttemptRecordAndRequestIdDigestsPreserved':True,'manualReplyAndTaskPreserved':True,'syntheticModelCalls':len(f.calls)},
        'realCloudCalls':0,'realModelCalls':0,'productionWrites':0,'sourceWrites':0}
(HERE/'VALIDATION.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf-8')
print(json.dumps({'passed':True,'authorCases':result.testsRun,'independentHttpCases':len(matrix),'protectedFunctions':len(unchanged),'moduleSha256':before}))
