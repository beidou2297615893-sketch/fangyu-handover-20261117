"""Isolated SQLite; real batch selection/journal, fixture-only transport/model."""
from pathlib import Path
import copy, hashlib, importlib.util, io, json, os, socket, sys, threading, time, unittest
from contextlib import contextmanager
HERE=Path(__file__).resolve().parent
os.environ.setdefault('ANALYSIS_QUEUE_CONTROLLER',str(HERE/'candidate/analysis_queue_runtime.py'))
os.environ['ANALYSIS_QUEUE_EVIDENCE']=str(HERE/'evidence')
spec=importlib.util.spec_from_file_location('auto_fixture',HERE/'test_analysis_queue_base.py')
base=importlib.util.module_from_spec(spec);sys.modules[spec.name]=base;spec.loader.exec_module(base)
base.HERE=HERE
impl=base.candidate

class Required(unittest.TestCase):
    def test_workspace_login_can_start_without_task_resume(self):
        self.assertTrue(callable(getattr(impl.AnalysisQueueRuntime,'authorize_workspace',None)),
            'F103 still requires a task resume; trusted login cannot start saved-comment drain')

@unittest.skipUnless(hasattr(impl.AnalysisQueueRuntime,'authorize_workspace'),'new workspace API absent')
class WorkspaceTests(base.QueueTests):
    # Inherit fixture setup, not the original suite's tests (run separately).
    def wrefresh(self,*,fresh=False):return self.refresh(fresh=fresh)
    def factory(self,task_id):return self.wrefresh
    def auth(self):return self.manager.authorize_workspace(self.user,'fixture-store',self.wrefresh,self.factory)
    def wcall(self,action='analysis_workspace_read'):
        return self.manager.execute_workspace(action,self.user,'fixture-store',{'storeId':'fixture-store'},self.wrefresh,self.factory)
    def settle(self,pending=0,timeout=15):
        end=time.monotonic()+timeout
        while time.monotonic()<end:
            value=self.wcall()
            if value['remaining']==pending and not value['running'] and value['status'] not in ('starting','scanning'):return value
            time.sleep(.05)
        self.fail('workspace did not settle: '+str(value))
    def task_leads(self,task_id,count,start,**task_extra):
        self.core.store.put('tasks',{**self.task,'id':task_id,**task_extra})
        for i in range(start,start+count):
            self.core.store.put('leads',{'id':'lead-'+str(i),'tenant_id':self.user['tenant_id'],
                'cloud_owner':self.user['username'],'task_id':task_id,'platform':task_extra.get('platform','xiaohongshu'),
                'text':'fixture '+str(i),'content_title':'fixture post',
                'note_url':'https://www.xiaohongshu.com/explore/123456789012345678901234'})
    def test_login_drains_seven_tasks_244_without_resume_and_preserves_1794(self):
        self.leads(209)
        old=self.unknown(['lead-'+str(i) for i in range(9)])
        for i in range(195,209):self.core.store.put('leads',{**self.core.store.get('leads','lead-'+str(i)),'text':''})
        start=209
        for n,count in enumerate((10,10,10,10,10,8)):
            self.task_leads('saved-'+str(n),count+(7 if n==0 else 0),start)
            if n==0:
                for i in range(start+count,start+count+7):self.core.store.put('leads',{**self.core.store.get('leads','lead-'+str(i)),'text':''})
            start+=count+(7 if n==0 else 0)
        original=[]
        for i in range(1794):
            value={'id':'prior-'+str(i),'tenant_id':self.user['tenant_id'],'cloud_owner':self.user['username'],
                'task_id':self.task['id'],'text':'original','ai_intent':{'status':'graded','level':'high','verbatim':'keep'}}
            self.core.store.put('leads',value);original.append(value)
        self.auth();result=self.settle(timeout=90)
        self.assertEqual(result['counts'],{'total':2068,'pending':0,'processing':0,'held':9,'analyzed':2038,'missingText':21})
        self.assertEqual(sum(len(d['ids']) for op,d in self.calls if op=='intent_analyze'),244)
        self.assertEqual(self.core.store.get('ai_attempts',old['id']),old)
        self.assertEqual([self.core.store.get('leads',v['id']) for v in original],original)
        self.assertTrue(result['automaticEnabled']);self.assertEqual(result['activeTaskId'],'')
    def test_collection_pause_new_page_and_next_task_never_need_resume(self):
        self.leads(21);entered=threading.Event();release=threading.Event()
        self.model_gate=lambda:(entered.set(),release.wait(3))
        collection_stop=threading.Event();self.runtime._run_cancels={self.task['id']:{'event':collection_stop}}
        self.auth();self.assertTrue(entered.wait(3));collection_stop.set();release.set();self.settle()
        self.task_leads('new-task',3,100);self.assertTrue(self.manager.notify_saved('new-task'));self.settle()
        self.leads(2,start=200);self.assertTrue(self.manager.notify_saved(self.task['id']));self.settle()
        self.assertEqual(sum(len(d['ids']) for op,d in self.calls if op=='intent_analyze'),26)
    def test_read_does_not_authorize_or_start_or_fresh(self):
        self.leads(1);value=self.wcall();self.assertEqual(value['remaining'],1)
        self.assertEqual(self.calls,[]);self.assertEqual(self.fresh_refresh_calls,0)
        self.assertIsNone(self.manager.workspace)
    def test_same_scope_fresh_reentry_neither_restarts_nor_self_wakes(self):
        self.leads(21)
        def refresh(*,fresh=False):
            result=self.refresh(fresh=fresh)
            if fresh:self.manager.authorize_workspace(self.user,'fixture-store',refresh,self.factory)
            return result
        self.manager.authorize_workspace(self.user,'fixture-store',refresh,self.factory);self.settle()
        thread=self.manager.workspace['thread'];fresh=self.fresh_refresh_calls
        for _ in range(8):self.manager.authorize_workspace(self.user,'fixture-store',refresh,self.factory)
        time.sleep(.15)
        self.assertIs(self.manager.workspace['thread'],thread);self.assertEqual(self.fresh_refresh_calls,fresh)
        self.assertFalse(self.manager.workspace['wake'].is_set())
    def test_user_pause_persists_reopen_but_close_alone_does_not_pause(self):
        self.auth();self.settle();self.wcall('analysis_workspace_pause');self.leads(2)
        self.manager.close();self.manager.wait_for_idle(3)
        self.manager=impl.AnalysisQueueRuntime(self.runtime,workflow_factory=base.FixtureWorkflow)
        self.auth();value=self.settle(pending=2);self.assertTrue(value['autoPaused']);self.assertEqual(self.calls,[])
        self.wcall('analysis_workspace_resume');self.settle()
        self.manager.close();self.manager.wait_for_idle(3)
        self.leads(1,start=100)
        self.manager=impl.AnalysisQueueRuntime(self.runtime,workflow_factory=base.FixtureWorkflow)
        self.auth();self.settle();self.assertIsNotNone(self.core.store.get('leads','lead-100').get('ai_intent'))
    def test_new_unknown_stops_entire_workspace_and_survives_reopen(self):
        self.leads(21);self.task_leads('second-task',3,100)
        class Timeout(ValueError):code='AI_PROVIDER_TIMEOUT'
        self.changed=lambda:(_ for _ in ()).throw(Timeout('fixture'))
        self.auth();value=self.settle(pending=4)
        self.assertEqual(value['status'],'blocked');self.assertEqual(value['code'],'AI_PROVIDER_TIMEOUT')
        self.assertEqual(len([op for op,d in self.calls if op=='intent_analyze']),1)
        self.manager.close();self.manager.wait_for_idle(3)
        self.manager=impl.AnalysisQueueRuntime(self.runtime,workflow_factory=base.FixtureWorkflow)
        self.auth();self.settle(pending=4);self.assertEqual(len([op for op,d in self.calls if op=='intent_analyze']),1)
    def test_foreign_store_owner_and_platform_are_never_enqueued(self):
        self.leads(1)
        for n,extra in enumerate(({'store_id':'foreign'},{'cloud_owner':'foreign'},{'platform':'weibo'})):
            self.task_leads('foreign-'+str(n),1,100+n,**extra)
        self.auth();value=self.settle();self.assertEqual(value['counts']['total'],1)
        self.assertEqual(sum(len(d['ids']) for op,d in self.calls if op=='intent_analyze'),1)
    def test_revocation_during_call_prevents_apply_and_next_task(self):
        self.leads(21);self.task_leads('second-task',2,100)
        self.changed=lambda:self.user.update(can_analyze=False)
        self.auth();self.manager.wait_workspace_idle(5)
        self.assertIsNone(self.core.store.get('leads','lead-0').get('ai_intent'))
        self.assertEqual(len([op for op,d in self.calls if op=='intent_analyze']),1)
    def test_authorization_hook_does_no_synchronous_sql_or_network(self):
        lock=threading.Lock();lock.acquire()
        # The worker may query only on its separate director, after the hook.
        current=threading.get_ident();old=self.core.store.get
        def checked(*a,**k):
            self.assertNotEqual(threading.get_ident(),current,'hook touched SQLite synchronously')
            return old(*a,**k)
        with base.patch.object(self.core.store,'get',checked):self.auth()
        self.settle()
    def test_cold_login_starts_only_bound_explicit_local_service(self):
        self.leads(2);executor=self.executor;service=self.runtime.service
        service.executor=None;service.explicit_local=True;service.state='offline';service.closed=False
        self.runtime._device=lambda user:{'bound':True,'state':'offline'}
        started=[]
        def start():started.append(threading.get_ident());service.executor=executor;service.state='online'
        service.start=start;main=threading.get_ident()
        self.runtime.prepare=lambda *a,**k:(_ for _ in ()).throw(AssertionError('prepare forbidden'))
        self.auth();self.settle();self.assertEqual(len(started),1);self.assertNotEqual(started[0],main)
        self.assertTrue(self.runtime.started)
    def test_cold_unbound_or_other_owner_never_starts_service(self):
        self.leads(1);self.runtime.service.executor=None;self.runtime.service.explicit_local=True
        self.runtime._device=lambda user:{'bound':False,'state':'other_owner'}
        self.runtime.service.start=lambda:(_ for _ in ()).throw(AssertionError('foreign start'))
        self.auth();value=self.settle(pending=1)
        self.assertEqual(value['code'],'ANALYSIS_DEVICE_UNAVAILABLE');self.assertEqual(self.calls,[])
    def test_analysis_a_does_not_block_collection_b_authorization(self):
        self.leads(21);entered=threading.Event();release=threading.Event()
        self.model_gate=lambda:(entered.set(),release.wait(3))
        self.auth();self.assertTrue(entered.wait(3));self.task_leads('new-b',2,100)
        self.assertIs(self.manager.authorize_collection(self.user,'fixture-store','new-b',self.wrefresh),self.manager)
        self.assertTrue(self.manager.notify_saved('new-b'));release.set();self.settle()
        self.assertEqual(sum(len(d['ids']) for op,d in self.calls if op=='intent_analyze'),23)
    def test_paused_analysis_allows_collection_without_ai_feature_and_preserves_pause(self):
        self.auth();self.settle();self.wcall('analysis_workspace_pause');self.leads(2);self.task_leads('new-b',2,100)
        original=self.executor._require_product_feature
        def feature(name):
            if name=='intent_analysis':raise AssertionError('collection must not require intent feature')
            return original(name)
        with base.patch.object(self.executor,'_require_product_feature',feature):
            self.manager.authorize_collection(self.user,'fixture-store','new-b',self.wrefresh)
            self.manager.notify_saved('new-b');time.sleep(.05)
            self.assertTrue(self.wcall()['autoPaused']);self.assertEqual(self.calls,[])
        self.wcall('analysis_workspace_resume');self.settle()
        self.assertEqual(sum(len(d['ids']) for op,d in self.calls if op=='intent_analyze'),4)
    def test_idle_authority_age_renews_only_when_saved_work_exists(self):
        expired=[False]
        def refresh(*,fresh=False):
            if fresh:expired[0]=False
            # The Backend local guard permits a same-session expired snapshot;
            # actual remote revalidation remains at submission boundaries.
            return self.refresh(fresh=fresh)
        self.manager.authorize_workspace(self.user,'fixture-store',refresh,self.factory);self.settle()
        self.assertEqual(self.fresh_refresh_calls,0);expired[0]=True
        for _ in range(3):self.manager.workspace['wake'].set();time.sleep(.03)
        self.assertTrue(expired[0]);self.assertEqual(self.fresh_refresh_calls,0)
        self.leads(1);self.manager.notify_saved(self.task['id']);self.settle()
        self.assertFalse(expired[0]);self.assertGreater(self.fresh_refresh_calls,0)
    def test_real_http_401_403_stop_all_tasks_without_auto_retry(self):
        self.leads(21);self.task_leads('second-task',1,100)
        class Revoked(ValueError):http_status=403
        self.changed=lambda:(_ for _ in ()).throw(Revoked('fixture'))
        self.auth();value=self.settle(pending=2)
        self.assertEqual(value['status'],'blocked');self.assertEqual(len([op for op,d in self.calls if op=='intent_analyze']),1)
        self.manager.workspace['wake'].set();time.sleep(.05)
        self.assertEqual(len([op for op,d in self.calls if op=='intent_analyze']),1)
    def test_budget_error_stops_all_tasks_until_explicit_resume(self):
        self.leads(21);self.task_leads('second-task',1,100)
        class Budget(ValueError):code='AI_DAILY_BUDGET'
        self.changed=lambda:(_ for _ in ()).throw(Budget('fixture'))
        self.auth();value=self.settle(pending=2)
        self.assertEqual(value['code'],'AI_DAILY_BUDGET');self.assertEqual(len([op for op,d in self.calls if op=='intent_analyze']),1)
    def test_unicode_blank_text_counts_exactly_like_original_inventory(self):
        self.leads(3)
        for ident,text in enumerate(('\t\n','\u3000','\u00a0')):
            row=self.core.store.get('leads','lead-'+str(ident));self.core.store.put('leads',{**row,'text':text})
        counts=self.wcall()['counts']
        self.assertEqual(counts,{'total':3,'pending':0,'processing':0,'held':0,'analyzed':0,'missingText':3})
        self.assertEqual(self.manager._workspace_candidates(self.user,'fixture-store'),[])
    def test_manual_owned_read_mode_fails_fast_before_service_start(self):
        self.leads(1);service=self.runtime.service;service.executor=None;service.explicit_local=True
        service.manual_owned_read_start=True
        self.runtime._device=lambda user:{'bound':True,'state':'held'}
        service.start=lambda:(_ for _ in ()).throw(AssertionError('manual read mode may not start background'))
        self.auth();value=self.settle(pending=1)
        self.assertEqual(value['code'],'ANALYSIS_RUNTIME_REQUIRED');self.assertEqual(self.calls,[])
    def test_durable_count_cache_ignores_metadata_but_tracks_ai_and_unknown(self):
        self.leads(2)
        frozen=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/candidate-unified-v103/project/work/ui-native-r57/releases/ui-r57-20261024T144455Z-0597e0ca/customer_read_store.py')
        revision=base.load('workspace_actual_read_revision',frozen)
        prepared=revision.prepare_business_revision(self.core.store.path,backup_directory=Path(self.temp.name)/'revision-fixture-backup')
        self.assertTrue(prepared['ready']);reader=revision.CustomerReadStore(self.core.store.path);self.addCleanup(reader.close)
        def local_revision(db,user,store_id):
            self.assertEqual(store_id,'fixture-store')
            self.assertTrue(revision._revision_schema_valid(db))
            stat=self.core.store.path.stat()
            return reader._revision(db,{'actor':{k:user[k] for k in impl.ACTOR_FIELDS}},(stat.st_dev,stat.st_ino),reader._generation)
        def refresh(*,fresh=False):return self.wrefresh(fresh=fresh)
        refresh.local_revision=local_revision
        def read():return self.manager.execute_workspace('analysis_workspace_read',self.user,'fixture-store',{'storeId':'fixture-store'},refresh,self.factory)
        queries=[];connect=self.core.store.connect
        @contextmanager
        def traced():
            with connect() as db:db.set_trace_callback(queries.append);yield db
        def scans():return sum(sql.lstrip().startswith('SELECT l.id AS id') for sql in queries)
        with base.patch.object(self.core.store,'connect',traced):
            self.assertEqual(read()['remaining'],2);self.assertEqual(scans(),1)
            for i in range(5):
                self.core.store.put(impl.ENTITY,{'id':'control','tenant_id':self.user['tenant_id'],'phase':'scope_check','tick':i})
                self.assertEqual(read()['remaining'],2)
            self.assertEqual(scans(),1,'unchanged business must not project lead history on each poll')
            lead=self.core.store.get('leads','lead-0');self.core.store.put('leads',lead);read();self.assertEqual(scans(),1)
            self.core.store.put('leads',{**lead,'ai_intent':{'status':'graded','level':'high'}})
            self.assertEqual(read()['counts']['analyzed'],1);self.assertEqual(scans(),2)
            self.unknown(['lead-1']);result=read()
            self.assertEqual(result['counts']['held'],1);self.assertEqual(result['remaining'],0);self.assertEqual(scans(),3)
            attempt=self.core.store.get('ai_attempts','fixture-old-attempt')
            with connect() as db:before=db.execute("SELECT rowid FROM records WHERE entity='ai_attempts' AND id=?",(attempt['id'],)).fetchone()[0]
            principal,host=self.executor.ai.attempts._principal(self.user)
            self.executor.ai.attempts.validated(self.user,{'id':attempt['id'],'request_id':attempt['request_id'],
                'submission_id':attempt.get('submission_id'),'principal':principal,'host':host})
            with connect() as db:after=db.execute("SELECT rowid FROM records WHERE entity='ai_attempts' AND id=?",(attempt['id'],)).fetchone()[0]
            self.assertEqual(before,after,'actual validated uses UPDATE, not replacement')
            self.assertEqual(read()['remaining'],1);self.assertEqual(scans(),4,'validated without lead result must invalidate held count')
    def test_absent_revision_falls_back_without_false_cache_hit(self):
        self.leads(1)
        def refresh(*,fresh=False):return self.wrefresh(fresh=fresh)
        refresh.local_revision=lambda *args:None
        self.assertEqual(self.manager.execute_workspace('analysis_workspace_read',self.user,'fixture-store',{'storeId':'fixture-store'},refresh,self.factory)['remaining'],1)
        lead=self.core.store.get('leads','lead-0');self.core.store.put('leads',{**lead,'text':''})
        self.assertEqual(self.manager.execute_workspace('analysis_workspace_read',self.user,'fixture-store',{'storeId':'fixture-store'},refresh,self.factory)['counts']['missingText'],1)
    def test_current_submitted_batch_is_processing_not_old_held(self):
        self.leads(32);old=self.unknown(['lead-'+str(i) for i in range(9)])
        entered=threading.Event();release=threading.Event();self.addCleanup(release.set)
        self.model_gate=lambda:(entered.set(),release.wait(5))
        self.auth();self.assertTrue(entered.wait(3))
        queries=[];connect=self.core.store.connect
        @contextmanager
        def traced():
            with connect() as db:db.set_trace_callback(queries.append);yield db
        with base.patch.object(self.core.store,'connect',traced):value=self.wcall()
        overlay=next(sql for sql in queries if sql.startswith('SELECT l.id AS current_id'))
        with connect() as db:plan=[row['detail'] for row in db.execute('EXPLAIN QUERY PLAN '+overlay)]
        self.assertTrue(any('SEARCH l USING INDEX sqlite_autoindex_records_1' in detail for detail in plan),
            'processing must point-read <=20 IDs using existing PK, not scan tenant history: '+str(plan))
        self.assertEqual(value['remaining'],23,'normal submitted batch must not look like completed work')
        self.assertEqual(value.get('processing'),20);self.assertEqual(value['counts']['held'],9)
        self.assertEqual(value['counts']['pending'],3);self.assertEqual(value['counts']['analyzed'],0)
        self.assertEqual(sum(value['counts'][k] for k in ('pending','processing','held','analyzed','missingText')),value['counts']['total'])
        # A result already saved during the active request is no longer counted
        # as processing, even while the transport is still returning.
        run=self.manager.active;ident=run['processingBatch']['ids'][0];lead=self.core.store.get('leads',ident)
        self.core.store.put('leads',{**lead,'manual_intent':{'status':'graded','level':'high'}})
        updated=self.wcall();self.assertEqual(updated['processing'],19);self.assertEqual(updated['remaining'],22)
        self.assertEqual(updated['counts']['held'],9);self.assertEqual(updated['counts']['analyzed'],1)
        self.assertEqual(self.core.store.get('ai_attempts',old['id']),old)
        release.set();self.settle()
    def test_response_received_and_validated_before_apply_do_not_fake_progress(self):
        self.leads(32);self.unknown(['lead-'+str(i) for i in range(9)])
        received=threading.Event();validate=threading.Event();validated=threading.Event();apply=threading.Event()
        self.addCleanup(validate.set);self.addCleanup(apply.set)
        original=base.LocalAIAttempts.validated;first=[True]
        def staged(attempts,user,receipt):
            gate=first[0];first[0]=False
            if gate:received.set();validate.wait(5)
            result=original(attempts,user,receipt)
            if gate:validated.set();apply.wait(5)
            return result
        with base.patch.object(base.LocalAIAttempts,'validated',staged):
            self.auth();self.assertTrue(received.wait(3));value=self.wcall()
            self.assertEqual(value['remaining'],23);self.assertEqual(value.get('processing'),20);self.assertEqual(value['counts']['held'],9)
            validate.set();self.assertTrue(validated.wait(3));value=self.wcall()
            self.assertEqual(value['remaining'],23);self.assertEqual(value.get('processing'),0)
            self.assertEqual(value['counts']['held'],9);self.assertEqual(value['counts']['analyzed'],0)
            apply.set();self.settle()
    def test_wrong_submission_or_blocked_unknown_is_never_processing(self):
        self.leads(21);entered=threading.Event();release=threading.Event();self.addCleanup(release.set)
        self.model_gate=lambda:(entered.set(),release.wait(5))
        self.auth();self.assertTrue(entered.wait(3))
        attempt=next(row for row in self.core.store.list('ai_attempts',self.user['tenant_id']) if row['state']=='submitted')
        self.core.store.put('ai_attempts',{**attempt,'submission_id':'not-current'})
        value=self.wcall();self.assertEqual(value.get('processing'),0);self.assertEqual(value['counts']['held'],20)
        self.core.store.put('ai_attempts',{**attempt,'state':'unknown'})
        with self.manager.lock:self.manager.active['working']=False;self.manager.active['status']='blocked'
        value=self.wcall();self.assertEqual(value.get('processing'),0);self.assertFalse(value['running'])
        release.set()
    def test_idle_durable_revision_skips_candidate_scan_until_new_saved_lead(self):
        self.leads(1)
        frozen=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/candidate-unified-v103/project/work/ui-native-r57/releases/ui-r57-20261024T144455Z-0597e0ca/customer_read_store.py')
        revision=base.load('workspace_idle_actual_revision',frozen)
        self.assertTrue(revision.prepare_business_revision(self.core.store.path,backup_directory=Path(self.temp.name)/'revision-fixture-backup')['ready'])
        reader=revision.CustomerReadStore(self.core.store.path);self.addCleanup(reader.close)
        def refresh(*,fresh=False):return self.wrefresh(fresh=fresh)
        def local_revision(db,user,store_id):
            stat=self.core.store.path.stat()
            return reader._revision(db,{'actor':{k:user[k] for k in impl.ACTOR_FIELDS}},(stat.st_dev,stat.st_ino),reader._generation)
        refresh.local_revision=local_revision
        def read():return self.manager.execute_workspace('analysis_workspace_read',self.user,'fixture-store',{'storeId':'fixture-store'},refresh,self.factory)
        self.manager.authorize_workspace(self.user,'fixture-store',refresh,self.factory)
        self.assertTrue(self.manager.wait_workspace_idle(5));self.assertEqual(read()['remaining'],0)
        calls=len(self.calls);fresh=self.fresh_refresh_calls
        queries=[];connect=self.core.store.connect
        @contextmanager
        def traced():
            with connect() as db:db.set_trace_callback(queries.append);yield db
        with base.patch.object(self.core.store,'connect',traced):
            for _ in range(4):self.manager.workspace['wake'].set();time.sleep(.05);read()
            self.assertFalse(any('GROUP BY t.id' in sql or sql.lstrip().startswith('SELECT l.id AS id') for sql in queries))
            self.assertEqual(len(self.calls),calls);self.assertEqual(self.fresh_refresh_calls,fresh)
            self.leads(1,start=100);self.manager.notify_saved(self.task['id'])
            self.assertTrue(self.manager.wait_workspace_idle(5))
            end=time.monotonic()+5
            while read()['remaining'] and time.monotonic()<end:time.sleep(.03)
            self.assertEqual(read()['remaining'],0)
            self.assertTrue(any('GROUP BY t.id' in sql for sql in queries))
        self.assertEqual(sum(len(data['ids']) for op,data in self.calls if op=='intent_analyze'),2)
    def test_legacy_task_actions_still_validate_input_and_owned_task_with_auto_enabled(self):
        self.auth();self.settle()
        for data in ({'storeId':'fixture-store','taskId':'foreign-task'}, {'storeId':'fixture-store'}):
            with self.subTest(data=data):
                with self.assertRaises(impl.AnalysisQueueError):
                    self.manager.execute('analysis_queue_pause',self.user,'fixture-store',data,self.wrefresh)
        with self.assertRaises(impl.AnalysisQueueError):
            self.manager.execute('analysis_queue_resume',self.user,'fixture-store',
                {'storeId':'fixture-store','taskId':self.task['id'],'confirmed':False},self.wrefresh)

# Avoid accidentally re-running inherited task-suite cases in this focused run.
for name in list(vars(base.QueueTests)):
    if name.startswith('test_') and name not in vars(WorkspaceTests):setattr(WorkspaceTests,name,None)
if __name__=='__main__':
    source=base.candidate_path;before=hashlib.sha256(source.read_bytes()).hexdigest()
    output=io.StringIO()
    with base.patch.object(socket.socket,'connect',base.deny),base.patch('subprocess.Popen',side_effect=base.deny):
        result=unittest.TextTestRunner(stream=output,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(sys.modules[__name__]))
    after=hashlib.sha256(source.read_bytes()).hexdigest()
    report={'passed':result.wasSuccessful() and before==after,'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
        'controller':str(source),'controllerSha256':before,'controllerUnchangedDuringRun':before==after,
        'realCloudModelOrCliCalls':0,'productionDataAccess':0,'evidence':'synthetic SQLite, original batch selector and attempt journal; fixture transport/model only'}
    (HERE/'evidence/WORKSPACE-CHECKS.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8')
    (HERE/'evidence/WORKSPACE-GREEN.log').write_text(output.getvalue(),'utf-8');print(output.getvalue())
    raise SystemExit(0 if report['passed'] else 1)
