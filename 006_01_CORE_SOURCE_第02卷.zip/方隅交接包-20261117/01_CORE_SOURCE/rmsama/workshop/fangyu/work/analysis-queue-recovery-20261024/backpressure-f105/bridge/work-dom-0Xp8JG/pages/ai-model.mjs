import {workflowScope} from './workflow-summary.mjs';
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const admin=s=>s.connection==='connected'&&s.session?.user?.role==='admin'&&s.session.user.username===s.user;
function model(s){
  const scope=workflowScope(s);
  if(s.aiModelSettings?.scope!==scope)s.aiModelSettings={scope,status:'idle',config:null,draft:'',dirty:false,saving:false,message:'',pending:null};
  return s.aiModelSettings;
}
export function render(state){
  if(!admin(state))return '<section class="card am-panel"><h2>AI 模型</h2><p>当前员工账号不能修改公司模型，请使用已有的管理员账号。</p></section>';
  const d=model(state),c=d.config,disabled=d.status!=='ready'||d.saving||d.pending?'disabled':'';
  const choices=(c?.model_catalog||[]).filter(row=>row.provider===c.provider);
  const modelField=choices.some(row=>row.id===c?.model)?`<select id="am-model" name="model" ${disabled} aria-describedby="am-model-help">${choices.map(row=>`<option value="${esc(row.id)}" ${row.id===d.draft?'selected':''}>${esc(row.label+' · '+row.id)}</option>`).join('')}</select>`:`<input id="am-model" name="model" type="text" value="${esc(d.draft)}" maxlength="120" autocomplete="off" spellcheck="false" required ${disabled} aria-describedby="am-model-help">`;
  return `<section class="card am-panel" aria-busy="${d.status==='loading'||d.saving}"><header><h2>DeepSeek 模型设置</h2><p>公司统一使用，保存后后续分析按新配置执行。</p></header><dl class="am-facts"><dt>当前模型</dt><dd>${esc(c?.model||'尚未读取')}</dd><dt>模型服务</dt><dd>${esc(c?.provider==='deepseek'?'DeepSeek':c?.provider||'尚未读取')}</dd><dt>API 配置</dt><dd>${c?c.configured===true?'已保存，继续沿用现有密钥':c.configured===false?'尚未配置':'尚未确认':'尚未读取'}</dd></dl><form data-am-form><label for="am-model">使用的模型名称</label>${modelField}<p id="am-model-help">可选模型由现有服务器提供。只修改模型，不改密钥、预算或意向分级标准。</p><div class="am-actions"><button class="primary" type="submit" ${disabled}>${d.saving?'正在保存…':'保存模型'}</button><button type="button" data-am-read ${d.status==='loading'||d.saving?'disabled':''}>${d.pending?'核对保存结果':'刷新当前配置'}</button><button type="button" data-am-discard ${!d.dirty||d.saving||d.pending?'disabled':''}>放弃修改</button>${d.dirty&&c&&d.expectedRevision!==c.revision?`<button type="button" data-am-rebase ${d.saving||d.pending?'disabled':''}>保留选择，采用当前版本</button>`:''}</div></form><p class="am-feedback" role="status" aria-live="polite">${esc(d.message||(d.status==='loading'?'正在读取服务器上的当前模型…':d.dirty?'模型已修改，尚未保存。':''))}</p><p class="am-note">保存设置不会调用模型。现有分析结果保留。</p></section>`;
}
export function bind(root,ctx){
  const s=ctx.state,d=model(s),current=()=>admin(s)&&s.aiModelSettings===d&&workflowScope(s)===d.scope;
  const visible=()=>current()&&s.page==='aiModel',redraw=()=>{if(visible())ctx.update(()=>{});};
  if(!admin(s))return ()=>{};
  const pending=ctx.remotePending?.();
  if(pending?.kind==='config')d.pending={id:pending.id,revision:pending.revision};
  const confirmed=(c,p)=>p&&c?.last_save_id===p.id&&c.revision===p.revision+1;
  const adopt=c=>{
    if(!c||!Number.isSafeInteger(c.revision)||typeof c.model!=='string'||!c.model)throw Error('服务器没有返回有效模型配置，请重新读取。');
    d.config=c;
    if(!d.dirty){d.draft=c.model;d.expectedRevision=c.revision;}
  };
  const load=async(afterSave=false)=>{
    if(!current()||d.status==='loading'||d.saving)return;
    d.status='loading';d.message='';redraw();
    try{
      const r=await ctx.remoteAction('remote_ai_config_read',{storeId:s.storeId});
      if(!current())return;
      if(r.actor?.username!==s.user||r.actor?.storeId!==s.storeId)throw Error('管理员或门店已变化，请重新读取。');
      if(confirmed(r.configuration,d.pending)){d.pending=null;d.dirty=false;d.message='模型已保存，并已从服务器读回确认。';}
      adopt(r.configuration);d.status='ready';
      if(d.pending)d.message='上次保存仍未确认，继续核对即可，不会重复提交。';
      else if(d.dirty&&d.expectedRevision!==d.config.revision)d.message='服务器配置已更新，选择已保留。核对当前模型后，可点击“保留选择，采用当前版本”再保存。';
      else if(!d.message)d.message=afterSave===true?'模型已保存，并已从服务器读回确认。':'已读取当前模型。';
    }catch(e){if(current()){d.status='error';d.message=e.message;ctx.replyError?.(e);}}
    finally{redraw();}
  };
  root.querySelector('#am-model')?.addEventListener('input',e=>{if(!visible()||d.saving||d.pending)return;d.draft=e.target.value;d.dirty=true;d.message='模型已修改，尚未保存。';root.querySelector('.am-feedback').textContent=d.message;root.querySelector('[data-am-discard]').disabled=false;});
  root.querySelector('[data-am-read]')?.addEventListener('click',()=>load());
  root.querySelector('[data-am-discard]')?.addEventListener('click',()=>{if(!visible()||d.saving||d.pending)return;d.dirty=false;d.draft=d.config.model;d.expectedRevision=d.config.revision;d.message='已放弃本页修改，恢复服务器当前模型。';redraw();});
  root.querySelector('[data-am-rebase]')?.addEventListener('click',()=>{if(!visible()||d.saving||d.pending||d.status!=='ready')return;d.expectedRevision=d.config.revision;d.message='已采用当前服务器版本，所选模型尚未保存。';redraw();});
  root.querySelector('[data-am-form]')?.addEventListener('submit',async e=>{
    e.preventDefault();if(!visible()||d.saving||d.pending||d.status!=='ready'||!e.target.reportValidity())return;
    const value=d.draft.trim();
    if(!/^[A-Za-z0-9][A-Za-z0-9._:-]{0,119}$/.test(value)){d.message='请填写有效的模型名称。';redraw();return;}
    if(d.expectedRevision!==d.config.revision){d.message='服务器配置已变化，请刷新当前配置后重新编辑。';redraw();return;}
    if(ctx.remotePending?.()){d.message='还有一项远程操作正在核对，请先到对应页面查看结果。';redraw();return;}
    const id=crypto.randomUUID(),revision=d.config.revision;
    d.pending={id,revision};d.saving=true;d.message='正在保存模型…';redraw();
    try{
      const r=await ctx.remoteAction('remote_ai_config_save',{storeId:s.storeId,config:{model:value},expected_revision:revision,request_id:id});
      if(!current())return;
      if(r.request_id===id&&r.state==='succeeded'&&r.mutation_committed===true&&confirmed(r.configuration,d.pending)){
        d.pending=null;d.dirty=false;adopt(r.configuration);d.message='模型已保存。';
      }else if(r.request_id===id&&r.state==='rejected'&&r.mutation_committed===false){
        d.pending=null;d.message=r.message||'服务器未接受本次修改，原模型保持。';d.rejected=true;
      }else d.message='保存结果暂未确认，请点击“核对保存结果”。';
    }catch(e){if(current()){if(e.mutationCommitted===false)d.pending=null;d.message=e.message;ctx.replyError?.(e);}}
    finally{if(current()){d.saving=false;redraw();}}
    // Confirm the stored value through a fresh independent read, without AI use.
    if(current()&&!d.pending&&!d.rejected)await load(true);
    d.rejected=false;
  });
  if(d.status==='idle')queueMicrotask(load);
  return ()=>{};
}
