# 评论分析独立桥接候选

本目录仅保存隔离候选，未修改 F100、冻结版本、入口、当前 Native 或真实数据库。未创建正式 Core/WorkbenchBackend，未读取凭据、调用企业服务、模型或平台。

## 待 Root 合并

将 `candidate` 下七个文件按相同项目相对路径合入 Root 的下一隔离候选；以 `evidence/VALIDATION.json` 的 `baselineSha256` 校验 F100 基线、`sha256` 校验候选。新增文件 `saved-comment-analysis.mjs` 无基线。不要直接覆盖当前运行程序。

核心 Agent 另提供 `work/shared-backend-integration/analysis_queue_runtime.py` 与 `platform_runtime.py`；本候选没有修改这两个文件。`freeze_ui.py` 会把新分析模块纳入发布资源和 source pins，Host 从 `resources/platform-runtime/analysis_queue_runtime.py` 的真实 manifest 条目校验字节后加载，仅通过 `analysis_factory` 注入 Backend。普通 import 不参与接线。

## 接口

- 三个动作：`analysis_queue_read`、`analysis_queue_resume`、`analysis_queue_pause`。
- 严格参数 `{storeId, taskId}`；只有 resume 额外要求 `confirmed: true`。
- Backend 返回 `{analysisQueue: payload}`，直接使用 Controller 的实时互斥统计。`pending` 是可独立处理，`held` 是原请求待核，不采用旧 `ai_jobs.pending`。
- 原有 Host、Origin、CSRF 和本机会话检查保留；所有语义检查验证有效本机会话、当前门店及原任务 tenant/owner/store/platform/account。企业远端身份/门店授权在 Controller 首次明确 resume、每个真实 intent_analyze 提交前/返回后刷新；原有模型计划、预算和账本检查保留。
- `refresh(*,fresh=False)` 默认只读 RAM 授权快照与本地数据。快照由已有成功 `_identity` 保存，读快照有效期5分钟；冷/过期 read 准确提示，不联网。显式 resume 不受前置过期快照阻挡，由 Controller 初始 fresh 恢复授权。worker 普通语义 guard 可使用旧快照，但实际模型提交/结果返回必须 fresh 成功。远端失败后快照仅能用于停止，不能授权读取或另一次模型请求；有效本机会话和原 task/store 校验仍保留。
- 读路径懒建无副作用 Controller 对象，不授权、不起 worker。模型批次不占 Host API 锁或 Backend 锁。员工分析权限撤销后仍可暂停；pause 不依赖云可达，允许 stop-only 原范围。云端身份已明确失效后的 read/resume 失败关闭。
- 明确采集 start/resume 调用期间，Backend 只在当前线程临时设置 `runtime._analysis_collection_authorization.callback(user, task_id)`，finally 原样恢复。Runtime 在 `_start_task` 预线程同步调用；callback 只做本地 session/scope 校验及 `authorize_collection` RAM 登记，不运行 refresh、不联网、不调用模型。返回同 Controller，Runtime 持久保存为 `_analysis_queue_controller`，页保存后由核心 hook `notify_saved(task_id)` 唤醒。旧未注入 factory 的测试路径保留。
- close、成功 login、logout、成功换店关闭 Controller 停止后续小批；停止不改变采集控制、人工回复、AI 原请求账本。Controller `close()` 必须只置事件、不 join。

## 页面

沿用当前 `as-source-bar` 风格，单独显示待分析 / 原请求待核 / 缺正文 / 已分析，提供“继续分析已采评论”、明确确认、独立暂停与刷新。仅当前任务、当前门店、当前平台可见；打开页面和自动刷新只读。局部忙碌不锁回复或切换，旧弹窗不能在换店后提交。

授权快照冷/过期时提供“核对授权并继续分析”，仍需本人明确确认，不会因自动刷新自行联网或启动模型。

原采集进度与执行详情不再把历史页作业 19 当当前待分析，改用同一实时 Controller 视图；未返回前显示待读取。没有改人工回复链路、其他页面或语气设置。

## 验证与限制

`tests/run_validation.py`：9 项提取真实 Backend 路由契约、4 项实际 HTTP Handler 测试、2 项真实 Controller + 真实桥接方法的内存组合验证、真实获客页 headless render/bind 与独立分析事件、前端真实传输方法和四份 JS 语法检查，全绿。测试只用合成身份、任务、内存记录；不实例化正式业务 Core/Backend。

fresh 协议新增8项本地授权测试、4项独立内存调度/锁验证。真实继承链计数明确正常 `_identity(_MediaReadIntegrations)` 是 me1 + store_config_read1，早期“me2”推测已纠正。21条两模型批次含首次 resume 严格 fresh5；追加10次 read 不增加 fresh。暂停测试覆盖模型尚在等待时 fresh 失败、快照变成 stop-only 后仍能本地置 stop，且返回后不应用结果。

测试覆盖暂停采集时独立读、literal confirmation、跨店/跨人/跨 tenant/伪任务/撤权、注入字段、返回前 scope 改变、Host/Origin/CSRF、不会等待其他 Host 操作锁、同步授权无 cloud、threadlocal 不跨线程、异常清理、页面自动只读、真实 pending/held、显式继续/暂停、旧弹窗失效，以及分析回执不污染人工回复的全局未知状态。真实 Controller 组合验证证实旧 pending19 被忽略，209 条合成评论返回200可处理+9待核；read/授权都不写记录、不开worker，授权会执行本地原有 intent_analysis 计划检查。等待新页的已授权分析线程也保留独立暂停按钮。

真实模型/企业服务、真实 Native 图审未执行。正常采集页保存 → 自动唤醒 → 暂停后独立 drain 的代表性链路由核心 Agent 提供验证；Root 合并后需要组合复验，不能只依据本文件宣称完整恢复。
