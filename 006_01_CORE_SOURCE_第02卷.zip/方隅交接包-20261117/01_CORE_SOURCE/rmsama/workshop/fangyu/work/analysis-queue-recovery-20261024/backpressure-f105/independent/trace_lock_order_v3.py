"""Specific lock-order trace of actual legacy execute and new Runtime queue.
No real locks are held across threads; no Core/DB/cloud/native is constructed.
"""
from pathlib import Path
from datetime import datetime,timezone
from types import SimpleNamespace,MethodType
import ast,hashlib,json,re,threading
from copy import deepcopy

A=Path(__file__).resolve().parent;W=A.parents[1];P=W.parents[1]
read=lambda p:json.loads(p.read_text('utf-8-sig'))
R=Path(read(P/'work/ui-native-r57/FROZEN.json')['release'])
CONTROL=R/'resources/platform-runtime/analysis_queue_runtime.py'
RUNTIME=A.parent/'core/v3/candidate/platform_runtime.py'
trace=[];held=[]
class ObservedLock:
    def __init__(self,name):self.name=name;self.actual=threading.RLock()
    def __enter__(self):
        self.actual.acquire()
        trace.append({'acquire':self.name,'alreadyHeld':list(held)})
        held.append(self.name);return self
    def __exit__(self,*args):assert held.pop()==self.name;self.actual.release()

def methods(path,cls,names,namespace):
    tree=ast.parse(path.read_text('utf-8-sig'));original=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name==cls)
    selected=[n for n in original.body if isinstance(n,ast.FunctionDef) and n.name in names]
    node=ast.ClassDef(name='Actual',bases=[],keywords=[],body=selected,decorator_list=[])
    exec(compile(ast.fix_missing_locations(ast.Module(body=[node],type_ignores=[])),str(path),'exec'),namespace)
    return namespace['Actual'],{n.name:n.lineno for n in selected}

controller_class,controller_lines=methods(CONTROL,'AnalysisQueueRuntime',{'execute','_snapshot','_inventory','_confirmed'},
    {'KEY':re.compile(r'[A-Za-z0-9_-]{1,160}\Z'),'ACTIONS':{'analysis_queue_read','analysis_queue_pause','analysis_queue_resume'},
     'ACTOR_FIELDS':('id','tenant_id','username','role','cloud_bound'),'UNRESOLVED':{'submitted','response_received','unknown'},
     'ENTITY':'ui_task_analysis_control_v1','_safe_phase':lambda value:value,'_digest':lambda value:'unused',
     'deepcopy':deepcopy,'fail':lambda *args:(_ for _ in ()).throw(AssertionError(args))})
store=SimpleNamespace(list_task_leads=lambda *args:[],list=lambda *args:[],get=lambda *args:{},put=lambda *args:None)
core=SimpleNamespace(lock=ObservedLock('Core.lock'),store=store)
user={'id':'synthetic-user','tenant_id':'synthetic-tenant','username':'synthetic-owner','role':'operator','cloud_bound':True,'_workbench_store_id':'synthetic-store'}
task={'id':'synthetic-task','tenant_id':user['tenant_id'],'cloud_owner':user['username'],'store_id':'synthetic-store'}
executor=SimpleNamespace(_analysis_visible_leads=lambda user,task,rows=None:rows)
controller=object.__new__(controller_class);controller.core=core;controller.lock=ObservedLock('Controller.lock')
controller.workspace=None;controller.closed=False;controller.authorizations={}
controller._scope=lambda *args,**kwargs:(user,task,executor,'same-scope')
controller._record_id=lambda *args:'synthetic-id'
controller.active={'taskId':task['id'],'storeId':'synthetic-store','user':user,'scope':'same-scope',
    'thread':SimpleNamespace(is_alive=lambda:True),'stop':threading.Event(),'wake':threading.Event(),
    'status':'running','working':True,'code':'','phase':'scope_check','requestId':'synthetic'}
controller.execute('analysis_queue_resume',user,'synthetic-store',{'storeId':'synthetic-store','taskId':task['id'],'confirmed':True},lambda **kwargs:(user,{}))
legacy_trace=list(trace);trace.clear()

runtime_class,runtime_lines=methods(RUNTIME,'PlatformRuntime',{'_automatic_collection_analysis','_queue_collection_analysis'},
    {'datetime':datetime,'timezone':timezone,'_COLLECTION_ANALYSIS_ENTITY':'synthetic-page','deepcopy':deepcopy,'PlatformRuntimeError':RuntimeError})
runtime=object.__new__(runtime_class);runtime.core=core;runtime._analysis_queue_controller=controller
runtime._principal=lambda actor:actor;runtime._task=lambda actor,ident:task
runtime._independent_analysis=lambda ident:None;runtime._pending_collection_analysis=lambda actor,current:None
runtime._collection_binding=lambda current:'synthetic-binding'
runtime._queue_collection_analysis(user,task['id'],['synthetic-lead'])
queue_trace=list(trace)
def edges(events):return sorted({(name,e['acquire']) for e in events for name in e['alreadyHeld'] if name!=e['acquire']})
first=edges(legacy_trace);second=edges(queue_trace)
assert ('Controller.lock','Core.lock') in first
assert ('Core.lock','Controller.lock') not in second
helper_node=next(n for n in ast.walk(ast.parse(RUNTIME.read_text('utf-8-sig'))) if isinstance(n,ast.FunctionDef) and n.name=='_automatic_collection_analysis')
assert not any(isinstance(n,ast.Attribute) and n.attr in ('owns_collection','lock') and isinstance(n.value,ast.Name) and n.value.id=='controller' for n in ast.walk(helper_node)), 'new helper must not block on the controller mutex directly or through owns_collection'
report={'status':'PASS_NEW_RUNTIME_PATH_NO_REVERSE_EDGE','approvedForInstall':False,
    'atUtc':datetime.now(timezone.utc).isoformat(),'controllerSha256':hashlib.sha256(CONTROL.read_bytes()).hexdigest(),
    'runtimeSha256':hashlib.sha256(RUNTIME.read_bytes()).hexdigest(),
    'actualMethodLines':{'controller':controller_lines,'runtime':runtime_lines},
    'legacyDuplicateResumeTrace':legacy_trace,'newQueueTrace':queue_trace,
    'observedEdges':[list(e) for e in first+second],
    'inference':'Legacy duplicate resume still owns Controller.lock then Core.lock. The new Runtime queue/helper does not acquire Controller.lock while Core.lock is held, removing the newly introduced reverse edge. This is a review of changed paths, not a claim that every historical legacy path has been globally redesigned.',
    'limit':'Concrete sequential acquisition traces of original methods, not a production deadlock or generalized stress-test claim.',
    'formalCoreOrDbConstructed':False,'productionReads':0,'productionWrites':0,'cloudModelCliOrNativeActions':0}
(A/'LOCK-ORDER-V3-REVIEW.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps(report,ensure_ascii=False))
