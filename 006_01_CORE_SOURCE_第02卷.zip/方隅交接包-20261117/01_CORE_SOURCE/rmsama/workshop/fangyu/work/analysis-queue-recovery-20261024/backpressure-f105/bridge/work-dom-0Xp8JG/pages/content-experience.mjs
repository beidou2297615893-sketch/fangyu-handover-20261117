const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const entries=w=>w?.workflow?.experiences||[];
const ui=f=>f.experienceUI??={taskId:'',title:'',text:'',reasons:{}};
const css=`<style>.ce-panel,.ce-picker{padding:18px;margin:16px 0;border:1px solid #d8e8ec;border-radius:10px;background:#f7fbfd;font-size:17px;line-height:1.65;min-width:0;overflow-wrap:anywhere}.ce-panel p,.ce-panel label,.ce-panel small,.ce-panel input,.ce-panel textarea,.ce-panel select,.ce-picker p,.ce-picker label,.ce-picker small,.ce-panel button{font-size:17px}.ce-panel textarea,.ce-panel input[type=text],.ce-panel select{width:100%;max-width:100%;font:inherit;padding:10px;border:1px solid #bddce5;border-radius:8px;background:white;box-sizing:border-box}.ce-panel textarea{min-height:110px;resize:vertical}.ce-entry{border-top:1px solid #dce8eb;margin-top:16px;padding-top:16px}.ce-entry blockquote{margin:8px 0;white-space:pre-wrap}.ce-actions{display:flex;gap:10px;flex-wrap:wrap;margin:12px 0}.ce-picker label{display:flex;align-items:flex-start;gap:8px;margin:10px 0}.ce-entry details{margin:10px 0}.ce-panel button{white-space:normal;max-width:100%}</style>`;
const stateName=s=>({candidate:'待审阅',active:'已采用',withdrawn:'已撤回'}[s]||'待核对');
const sources=w=>(w?.workflow?.tasks||[]).filter(t=>t.methodId==='learning'&&t.state==='succeeded'&&t.appliedRefs).map(t=>({task:t,artifact:(w.workflow.artifacts||[]).find(a=>a.id===t.artifactId&&a.state==='applied')})).filter(v=>v.artifact);
const button=(label,action,id,disabled)=>`<button type="button" class="co-button" data-ce-action="${action}" ${id?`data-ce-id="${esc(id)}"`:''} ${disabled?'disabled':''}>${esc(label)}</button>`;
export function renderExperienceLibrary(w,f){
 const g=ui(f),locked=!!f.pending||!!f.localUnknown,available=sources(w);
 return `${css}<details class="ce-panel" data-ce-library ${f.experienceLibraryOpen?'open':''}><summary>复盘经验 · 审阅与撤回</summary><p>把已采用的复盘建议整理为经验，经本人核对后，可在下次任务中勾选使用。经验仍待验证。</p>${available.length?`<label>原复盘<select data-ce-field="taskId"><option value="">请选择已采用的复盘</option>${available.map(v=>`<option value="${esc(v.task.id)}" ${g.taskId===v.task.id?'selected':''}>${esc(v.task.query)}</option>`).join('')}</select></label><label>经验名称<input type="text" data-ce-field="title" maxlength="100" value="${esc(g.title)}"></label><label>待核经验<textarea data-ce-field="text" maxlength="2000" placeholder="写清观察、适用范围和仍需验证的地方。">${esc(g.text)}</textarea></label><div class="ce-actions">${button('保存经验候选','create','',locked)}</div>`:'<p>先核对并采用一份复盘结果，再来整理经验。</p>'}${entries(w).map(e=>`<section class="ce-entry" data-ce-entry="${esc(e.id)}"><strong>${esc(e.title)} · ${stateName(e.state)} · 版本 ${e.version}</strong><blockquote>${esc(e.text)}</blockquote><p>来自：${esc(e.source.taskQuery)} · 复盘建议，效果待验证</p><div class="ce-actions">${e.state!=='active'?button(e.state==='withdrawn'?'重新审阅采用':'核对并采用','adopt',e.id,locked):''}</div>${e.state==='active'?`<label>撤回说明<input type="text" data-ce-reason="${esc(e.id)}" maxlength="500" value="${esc(g.reasons[e.id]||'')}" placeholder="如证据不足、条件变化"></label><div class="ce-actions">${button('撤回这条经验','withdraw',e.id,locked)}</div>`:''}<details><summary>版本历史（${e.history.length}）</summary>${e.history.map(h=>`<p>版本 ${h.version} · ${stateName(h.state)}${h.reason?' · '+esc(h.reason):''}</p>`).join('')}</details></section>`).join('')||'<p>当前账号还没有经验候选。</p>'}</details>`;
}
export function renderExperiencePicker(w,f){
 const refs=f.experienceReferences||[],active=entries(w).filter(e=>e.state==='active'),stale=refs.some(r=>!active.some(e=>e.id===r.experienceId&&e.version===r.version&&e.digest===r.digest));
 return `${css}<details class="ce-picker" data-ce-picker ${f.experiencePickerOpen?'open':''}><summary>本次引用的经验（${refs.length}/4）</summary><p>只使用你这次勾选的版本。</p>${stale?'<p role="alert">所选经验已变化，请重新勾选。</p>':''}${active.map(e=>`<label><input type="checkbox" data-ce-ref="${esc(e.id)}" ${refs.some(r=>r.experienceId===e.id&&r.version===e.version&&r.digest===e.digest)?'checked':''} ${f.pending?'disabled':''}><span><strong>${esc(e.title)} · 版本 ${e.version}</strong><br>${esc(e.text)}<br><small>复盘经验 · 待验证</small></span></label>`).join('')||'<p>还没有已采用经验。可在“资料与引用”整理复盘经验。</p>'}${refs.length?button('清除本次经验选择','clear','',!!f.pending):''}</details>`;
}
export function bindExperiences(root,bridge){
 const {state,u,f}=bridge,g=ui(f),current=()=>entries(state.contentWorkspace);
 root.querySelector('[data-ce-library]')?.addEventListener('toggle',e=>{f.experienceLibraryOpen=e.currentTarget.open;});
 root.querySelector('[data-ce-picker]')?.addEventListener('toggle',e=>{f.experiencePickerOpen=e.currentTarget.open;});
 root.querySelectorAll('[data-ce-field]').forEach(el=>el.addEventListener(el.tagName==='SELECT'?'change':'input',()=>{g[el.dataset.ceField]=el.value;u.dirty.workflowExperience=true;}));
 root.querySelectorAll('[data-ce-reason]').forEach(el=>el.addEventListener('input',()=>{g.reasons[el.dataset.ceReason]=el.value;u.dirty.workflowExperience=true;}));
 root.querySelectorAll('[data-ce-ref]').forEach(el=>el.addEventListener('change',()=>{const item=current().find(e=>e.id===el.dataset.ceRef);if(!item)return;const refs=(f.experienceReferences||[]).filter(r=>r.experienceId!==item.id);if(el.checked)refs.push({experienceId:item.id,version:item.version,digest:item.digest});if(refs.length>4){el.checked=false;bridge.error('一次最多勾选4条经验。');return;}bridge.update(()=>{f.experienceReferences=refs;u.dirty.workflowTask=true;});}));
 root.querySelectorAll('[data-ce-action]').forEach(el=>el.addEventListener('click',async()=>{try{
  const op=el.dataset.ceAction;if(op==='clear'){bridge.update(()=>{f.experienceReferences=[];u.dirty.workflowTask=true;});return;}
  if(f.pending||f.localUnknown)throw Error('请先核对原保存结果。');
  if(op==='create'){
   const source=sources(state.contentWorkspace).find(v=>v.task.id===g.taskId);if(!source||!g.title.trim()||!g.text.trim())throw Error('请选择原复盘，填写经验名称和表述。');
   await bridge.request('content_experience_save',{operation:'create_from_learning',taskId:source.task.id,artifactId:source.artifact.id,outputDigest:source.artifact.outputDigest,title:g.title,text:g.text},()=>{g.title='';g.text='';u.dirty.workflowExperience=false;f.notice='经验候选已保存，核对后可采用。';});return;
  }
  const item=current().find(e=>e.id===el.dataset.ceId);if(!item)throw Error('请重新读取当前账号的经验。');
  const reason=(g.reasons[item.id]||'').trim();if(op==='withdraw'&&!reason)throw Error('请写明撤回原因。');
  const data={operation:op,experienceId:item.id,version:item.version,digest:item.digest,humanConfirmed:true,...(op==='withdraw'?{reason}:{})};
  bridge.confirm(op==='adopt'?'采用这版经验？':'撤回这条经验？',`<p>${esc(item.title)} · 版本 ${item.version}</p><blockquote style="white-space:pre-wrap;overflow-wrap:anywhere">${esc(item.text)}</blockquote><p>${op==='adopt'?'采用后供本账号下次任务勾选，效果仍待验证。':'之后不再用于新任务。已派发任务仍按原编号核对。'}</p><label style="font-size:17px"><input type="checkbox" data-ce-ack> 我已核对，确认${op==='adopt'?'采用':'撤回'}。</label>`,()=>{
   if(root.ownerDocument.querySelector('[data-ce-ack]')?.checked!==true)throw Error('请本人勾选确认。');
   return bridge.request('content_experience_save',data,()=>{delete g.reasons[item.id];u.dirty.workflowExperience=false;f.notice=op==='adopt'?'已采用为可选参考。':'已撤回，版本历史保留。';});
  });
 }catch(error){bridge.error(error?.message||'经验操作尚未完成。');}}));
}
