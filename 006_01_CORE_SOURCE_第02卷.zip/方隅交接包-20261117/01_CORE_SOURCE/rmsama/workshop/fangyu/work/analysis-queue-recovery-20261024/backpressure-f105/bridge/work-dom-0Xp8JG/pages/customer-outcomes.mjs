// Manual facts remain separate from comment/AI/contact evidence.
const stages=[['contacted','已联系'],['responded','客户回应'],['contact_shared','客户留资'],['appointment','已预约'],['visited','已到访'],['signed','已签约'],['payment','已回款'],['invalid','无效']];
const costs=[['software','软件'],['labor','人工'],['channel','渠道']];
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const key=v=>typeof v==='string'&&/^[a-f0-9]{64}$/.test(v);
const int=v=>Number.isSafeInteger(v)&&v>=0;
const labels=Object.fromEntries([...stages,...costs,['cost','实际投入'],['revoke','撤销登记']]);
const today=()=>new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
const owner=s=>JSON.stringify([s.session?.user?.tenant_id||'',s.user||'',s.session?.user?.role||'',s.storeId||'']);
const live=s=>JSON.stringify([s.authEpoch||0,owner(s),s.activePlatform||'xiaohongshu']);
const storageKey=(s,id)=>'fangyu-outcome-request-v1:'+owner(s)+':'+id;
const owns=(ctx,x)=>ctx.state.outcomesUI===x&&x.live===live(ctx.state)&&!x.closed&&(!x.dialogOwner||x.dialog?.__modalOwner===x.dialogOwner);
export const canOpenOutcomes=s=>s?.connection==='connected'&&Boolean(s.session&&s.user&&s.storeId);
export function parseCents(value){
  if(typeof value!=='string'||!/^\d{1,9}(?:\.\d{1,2})?$/.test(value.trim()))throw Error('请输入人民币金额，最多两位小数。');
  const [yuan,fen='']=value.trim().split('.');const n=Number(yuan)*100+Number(fen.padEnd(2,'0'));
  if(!int(n)||n>100000000000)throw Error('金额超出可登记范围。');return n;
}
const money=n=>n===null?'未知':`¥${(n/100).toLocaleString('zh-CN',{minimumFractionDigits:2,maximumFractionDigits:2})}`;
const percent=n=>n===null?'暂不计算':`${(n*100).toFixed(1)}%`;
const stable=v=>v&&typeof v==='object'&&!Array.isArray(v)?Object.fromEntries(Object.keys(v).sort().map(k=>[k,stable(v[k])])):Array.isArray(v)?v.map(stable):v;
export async function requestDigest(data){const bytes=new TextEncoder().encode(JSON.stringify(stable(data)));return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),b=>b.toString(16).padStart(2,'0')).join('');}
const style=`<style>.outcome-ui{font-size:17px;line-height:1.6;color:#193c47;max-width:100%;overflow-wrap:anywhere}.outcome-ui label{display:grid;gap:6px;margin:12px 0}.outcome-ui input,.outcome-ui select,.outcome-ui textarea{box-sizing:border-box;max-width:100%;width:100%;font:inherit;padding:10px;border:1px solid #cbdfe4;border-radius:9px;background:#fff}.outcome-ui textarea{min-height:80px}.outcome-ui .outcome-row{display:flex;gap:10px;flex-wrap:wrap;align-items:center}.outcome-ui .outcome-row>*{min-width:0;flex:1 1 160px}.outcome-ui button{font:inherit;padding:10px 14px;border:1px solid #bbd8dd;border-radius:9px;color:#234e58;background:#f1faf9;cursor:pointer;min-height:44px}.outcome-ui button:disabled{opacity:.5;cursor:default}.outcome-ui .outcome-note{background:#edf7f8;padding:12px;border-radius:9px}.outcome-ui article{padding:12px 0;border-bottom:1px solid #dce9eb}.outcome-ui table{width:100%;border-collapse:collapse}.outcome-ui td,.outcome-ui th{padding:8px;text-align:left;border-bottom:1px solid #dce9eb}.outcome-ui small{display:block;color:#526c75;font-size:15px}.outcome-ui .outcome-check{display:flex;gap:10px;align-items:flex-start}.outcome-ui .outcome-check input{width:auto;margin-top:7px;flex:none}</style>`;

function stored(ctx,id){
  try{const p=JSON.parse(localStorage.getItem(storageKey(ctx.state,id))||'null');return p&&p.owner===owner(ctx.state)&&p.customerId===id&&typeof p.requestId==='string'&&/^[A-Za-z0-9_-]{8,100}$/.test(p.requestId)&&key(p.requestDigest)?p:null;}catch{return null;}
}
function persist(ctx,x,data,digest){
  const p={owner:owner(ctx.state),customerId:x.id,platform:x.platform,requestId:data.requestId,requestDigest:digest};const text=JSON.stringify(p);
  localStorage.setItem(storageKey(ctx.state,x.id),text);if(localStorage.getItem(storageKey(ctx.state,x.id))!==text)throw Error('无法保存原操作核对编号，本次尚未登记。');x.pending=p;
}
function clear(ctx,x){localStorage.removeItem(storageKey(ctx.state,x.id));x.pending=null;}
function validate(ctx,x,v){
  if(v?.actor?.username!==ctx.state.user||v.actor.storeId!==ctx.state.storeId||v.customerId!==x.id||v.platform!==x.platform||!int(v.version)||!key(v.sourceDigest)||!Array.isArray(v.history)||v.manualEntry!==true||v.independentlyReconciled!==false)throw Error('原员工、门店或客户回执不匹配，请继续核对。');
  if(x.pending&&(v.receipt?.requestId!==x.pending.requestId||!['accepted','cancelled','not_found'].includes(v.receipt.state)||v.receipt.state!=='not_found'&&v.receipt.requestDigest!==x.pending.requestDigest))throw Error('原操作回执尚未核实，请保留核对编号。');
  return v;
}
function base(ctx,x){return {storeId:ctx.state.storeId,customerId:x.id,platform:x.platform};}
function resetDraft(x){x.draft={kind:x.id?'responded':'cost',occurredOn:today(),fact:'',source:'',evidenceRef:'',amount:'',costCategory:'software',confirmed:false};x.target=null;}
function capture(x){
  if(x.busy||x.pending||!x.dialog)return;
  for(const name of ['kind','occurredOn','fact','source','evidenceRef','amount','costCategory']){const el=x.dialog.querySelector(`[data-outcome-field="${name}"]`);if(el)x.draft[name]=el.value;}
  x.draft.confirmed=Boolean(x.dialog.querySelector('[data-outcome-confirm]')?.checked);
}
function editorHTML(x){
  const d=x.draft,disabled=x.busy||x.pending?'disabled':'',history=x.view?.history||[];
  return `${style}<section class="outcome-ui" data-outcome-editor><p class="outcome-note">人工登记 · 未独立对账${x.id?'；原评论与AI判断保留。':'；本店当前员工、全部平台投入。'}</p><p role="status">${esc(x.message)}</p>${x.pending?`<div class="outcome-note"><strong>原操作待核对</strong><p>不会重复登记。可读取原结果；尚未落盘时，取消原操作后才能重新填写。</p><div class="outcome-row"><button data-outcome-recover ${x.busy?'disabled':''}>核对原结果</button>${x.notFound?`<button data-outcome-cancel ${x.busy?'disabled':''}>取消原操作</button>`:''}</div></div>`:''}<div class="outcome-row"><label>${x.target?'正在撤销原登记':'登记结果'}<select data-outcome-field="kind" ${disabled} ${x.target?'disabled':''}>${(x.id?stages:[['cost','实际投入']]).map(([k,v])=>`<option value="${k}" ${d.kind===k?'selected':''}>${v}</option>`).join('')}</select></label><label>事实日期<input type="date" data-outcome-field="occurredOn" value="${esc(d.occurredOn)}" ${disabled}></label></div>${!x.id?`<label>投入类别<select data-outcome-field="costCategory" ${disabled}>${costs.map(([k,v])=>`<option value="${k}" ${d.costCategory===k?'selected':''}>${v}</option>`).join('')}</select></label>`:''}${!x.target&&(d.kind==='payment'||!x.id)?`<label>${x.id?'实际收到的回款':'实际投入'}（人民币元）<input inputmode="decimal" data-outcome-field="amount" value="${esc(d.amount)}" placeholder="未填写表示未知；明确无投入可填0" ${disabled}></label>`:''}<label>${x.target?'撤销原因':'事实说明'}<textarea data-outcome-field="fact" maxlength="2000" ${disabled}>${esc(d.fact)}</textarea></label><label>事实来源<input data-outcome-field="source" maxlength="300" value="${esc(d.source)}" placeholder="例如：本人电话沟通、到访登记、收款凭据" ${disabled}></label><label>来源原话或凭据说明（选填）<textarea data-outcome-field="evidenceRef" maxlength="500" ${disabled}>${esc(d.evidenceRef)}</textarea></label><label class="outcome-check"><input type="checkbox" data-outcome-confirm ${d.confirmed?'checked':''} ${disabled}><span>本人已核对事实与来源。</span></label><div class="outcome-row"><button data-outcome-save ${disabled||(!x.view?'disabled':'')}>${x.target?'确认撤销，保留历史':'保存人工登记'}</button>${x.target?`<button data-outcome-reset ${disabled}>取消撤销</button>`:''}<button data-outcome-refresh ${x.busy||x.pending?'disabled':''}>重新读取</button></div><details><summary>登记历史（${history.length}）</summary>${history.length?history.map(r=>`<article><strong>${esc(labels[r.kind]||r.kind)}${r.kind==='cost'?` · ${esc(labels[r.costCategory])}`:''}${r.revoked?' · 已撤销':''}</strong><small>${esc(r.occurredOn)} · 人工登记 · ${esc(r.owner)}</small><p>${esc(r.fact)}</p><p>来源：${esc(r.source)}</p>${r.evidenceRef?`<small>${esc(r.evidenceRef)}</small>`:''}${r.amountCents!==null?`<strong>${money(r.amountCents)}</strong>`:''}${r.operation==='record'&&!r.revoked?`<button data-outcome-revoke="${esc(r.id)}" ${disabled}>撤销此登记</button>`:''}</article>`).join(''):'<p>尚未登记。</p>'}</details></section>`;
}
function showEditor(ctx,x){
  if(!owns(ctx,x))return;
  x.dialog=ctx.modal({title:x.id?'客户跟进结果':'登记实际投入',html:editorHTML(x),canClose:()=>!x.busy});
  const dialog=x.dialog;
  x.dialogOwner=dialog.__modalOwner;
  dialog.addEventListener('close',()=>{if(ctx.state.outcomesUI===x)x.closed=true;},{once:true});
  dialog.querySelectorAll('[data-outcome-field]')?.forEach(el=>el.addEventListener('input',()=>capture(x)));
  dialog.querySelector('[data-outcome-field="kind"]')?.addEventListener('change',()=>{capture(x);showEditor(ctx,x);});
  dialog.querySelector('[data-outcome-confirm]')?.addEventListener('change',()=>capture(x));
  dialog.querySelector('[data-outcome-save]')?.addEventListener('click',()=>{capture(x);void saveEditor(ctx,x);});
  dialog.querySelector('[data-outcome-recover]')?.addEventListener('click',()=>void readEditor(ctx,x));
  dialog.querySelector('[data-outcome-refresh]')?.addEventListener('click',()=>{capture(x);void readEditor(ctx,x);});
  dialog.querySelector('[data-outcome-cancel]')?.addEventListener('click',()=>void cancelEditor(ctx,x));
  dialog.querySelector('[data-outcome-reset]')?.addEventListener('click',()=>{resetDraft(x);showEditor(ctx,x);});
  dialog.querySelectorAll('[data-outcome-revoke]')?.forEach(el=>el.addEventListener('click',()=>{capture(x);x.target=el.dataset.outcomeRevoke;x.draft.fact='';x.draft.confirmed=false;showEditor(ctx,x);}));
}
async function readEditor(ctx,x){
  if(x.busy||!owns(ctx,x))return;x.busy=true;x.message=x.pending?'正在核对原登记…':'正在读取原客户结果…';showEditor(ctx,x);
  try{const result=await ctx.actions.outcomeAction('customer_outcome_read',{...base(ctx,x),...(x.pending?{requestId:x.pending.requestId}:{})});if(!owns(ctx,x))return;x.view=validate(ctx,x,result.customerOutcomes);
      if(x.pending){x.notFound=x.view.receipt.state==='not_found';if(!x.notFound){const state=x.view.receipt.state;clear(ctx,x);if(state==='accepted')resetDraft(x);x.message=state==='accepted'?'原操作已保存；没有重复登记。':'原操作已取消，可以重新填写。';}else x.message='原操作尚未落盘；取消原操作可阻止迟到保存。';}else x.message='';
  }catch(e){if(owns(ctx,x)){x.message=e.message;ctx.actions.replyError?.(e);}}
  finally{if(owns(ctx,x)){x.busy=false;showEditor(ctx,x);}}
}
async function saveEditor(ctx,x){
  if(!owns(ctx,x)||x.busy||x.pending||!x.view)return;
  const d=x.draft;if(!d.confirmed||!d.fact.trim()||!d.source.trim()){x.message='请填写事实说明、来源并勾选本人核对。';showEditor(ctx,x);return;}
  x.busy=true;x.message='正在保存人工登记…';showEditor(ctx,x);
  try{const data={...base(ctx,x),requestId:crypto.randomUUID(),expectedVersion:x.view.version,sourceDigest:x.view.sourceDigest,operation:x.target?'revoke':'record',targetEventId:x.target||null,kind:x.target?'revoke':d.kind,occurredOn:d.occurredOn,fact:d.fact,source:d.source,evidenceRef:d.evidenceRef,amountCents:!x.target&&(d.kind==='payment'||!x.id)?parseCents(d.amount):null,costCategory:!x.id&&!x.target?d.costCategory:null,confirmed:true};
    const signature=await requestDigest(data);if(!owns(ctx,x))return;persist(ctx,x,data,signature);
    const result=await ctx.actions.outcomeAction('customer_outcome_save',data);if(!owns(ctx,x))return;x.view=validate(ctx,x,result.customerOutcomes);
    if(x.view.receipt.state==='not_found')throw Error('尚未取得保存回执，请核对原操作。');const state=x.view.receipt.state;clear(ctx,x);resetDraft(x);x.message=state==='accepted'?'人工结果已保存，原始客户资料未改。':'原操作已取消，没有新增事实。';
  }catch(e){if(owns(ctx,x)){if(e.mutationCommitted===false)clear(ctx,x);x.message=e.message;}}
  finally{if(owns(ctx,x)){x.busy=false;showEditor(ctx,x);}}
}
async function cancelEditor(ctx,x){
  if(!owns(ctx,x)||x.busy||!x.pending||!x.notFound)return;x.busy=true;x.message='正在取消原操作…';showEditor(ctx,x);
  try{const result=await ctx.actions.outcomeAction('customer_outcome_cancel',{...base(ctx,x),requestId:x.pending.requestId,requestDigest:x.pending.requestDigest});if(!owns(ctx,x))return;x.view=validate(ctx,x,result.customerOutcomes);if(x.view.receipt.state==='not_found')throw Error('取消结果仍待核对。');const state=x.view.receipt.state;clear(ctx,x);x.notFound=false;x.message=state==='accepted'?'原操作已保存，取消没有删除已登记事实。':'原操作已取消，迟到的保存不会再新增事实。';}
  catch(e){if(owns(ctx,x))x.message=e.message;}
  finally{if(owns(ctx,x)){x.busy=false;showEditor(ctx,x);}}
}
export function openOutcomeEditor(ctx,id='',platform=null){
  if(!canOpenOutcomes(ctx.state)){ctx.toast('请先登录并选择当前门店。');return;}
  if(id&&(!key(id)||!['xiaohongshu','douyin'].includes(platform))){ctx.toast('请先读取原客户详情。');return;}
  const x={id,platform,live:live(ctx.state),view:null,busy:false,closed:false,pending:stored(ctx,id),message:'',notFound:false};resetDraft(x);ctx.state.outcomesUI=x;showEditor(ctx,x);void readEditor(ctx,x);return x;
}
export function renderOutcomeReport(v){
  return `<p class="outcome-note">人工登记 · 未独立对账 · 本机当前员工与门店</p><div class="outcome-row"><div><small>本期登记客户</small><strong>${v.registeredCustomers} 位</strong></div><div><small>实际回款</small><strong>${money(v.paymentCents)}</strong></div><div><small>已登记投入</small><strong>${money(v.knownCostCents)}</strong></div><div><small>回款 / 投入比</small><strong>${v.receiptsToSpend===null?'暂不计算':Number(v.receiptsToSpend).toFixed(2)+'倍'}</strong></div></div><table><thead><tr><th>登记结果</th><th>客户数</th></tr></thead><tbody>${v.stages.map(r=>`<tr><td>${esc(r.label)}</td><td>${r.customers}</td></tr>`).join('')}</tbody></table><details><summary>投入明细与统计口径</summary><p>当前可见 ${v.visibleCustomers} 位；本期有结果登记 ${v.registeredCustomers} 位。</p>${costs.map(([k,label])=>`<p>${label}投入：${money(v.costCents[k])}</p>`).join('')}<p>${esc(v.scopeNotice)}</p>${v.stages.map(r=>`<p>${esc(r.label)}：${r.numerator} / ${r.denominator} · ${percent(r.rate)}<small>${esc(r.denominatorMeaning)}</small></p>`).join('')}<p>${esc(v.ratioNotice)}</p><p>${esc(v.evidenceNotice)}</p></details>`;
}

function showReport(ctx,x){
  if(!owns(ctx,x))return;
  x.dialog=ctx.modal({title:'客户结果与实际投入',html:`${style}<section class="outcome-ui"><div class="outcome-row"><label>开始日期<input type="date" data-outcome-from value="${esc(x.from)}"></label><label>结束日期<input type="date" data-outcome-to value="${esc(x.to)}"></label></div><div class="outcome-row"><button data-outcome-report ${x.busy?'disabled':''}>查看统计</button><button data-outcome-costs ${x.busy?'disabled':''}>登记实际投入</button></div><p role="status">${esc(x.message)}</p>${x.report?renderOutcomeReport(x.report):'<p>请选择事实日期范围。尚未登记的金额保持未知。</p>'}</section>`});
  x.dialogOwner=x.dialog.__modalOwner;
  x.dialog.addEventListener('close',()=>{if(ctx.state.outcomesUI===x)x.closed=true;},{once:true});
  x.dialog.querySelector('[data-outcome-from]')?.addEventListener('change',e=>{x.from=e.target.value;x.report=null;showReport(ctx,x);});
  x.dialog.querySelector('[data-outcome-to]')?.addEventListener('change',e=>{x.to=e.target.value;x.report=null;showReport(ctx,x);});
  x.dialog.querySelector('[data-outcome-report]')?.addEventListener('click',()=>void readReport(ctx,x));
  x.dialog.querySelector('[data-outcome-costs]')?.addEventListener('click',()=>openOutcomeEditor(ctx));
}
async function readReport(ctx,x){
  if(!owns(ctx,x)||x.busy)return;x.busy=true;x.message='正在读取已登记事实…';const range=JSON.stringify([x.from,x.to]);showReport(ctx,x);
  try{const result=await ctx.actions.outcomeAction('customer_outcome_report',{storeId:ctx.state.storeId,dateFrom:x.from,dateTo:x.to});if(!owns(ctx,x)||range!==JSON.stringify([x.from,x.to]))return;const v=result?.customerOutcomes;
    if(v?.actor?.username!==ctx.state.user||v.actor.storeId!==ctx.state.storeId||v.dateFrom!==x.from||v.dateTo!==x.to||!Array.isArray(v.stages)||!int(v.visibleCustomers)||!int(v.registeredCustomers)||v.manualEntry!==true||v.independentlyReconciled!==false||v.roi!==null)throw Error('统计范围或事实口径不匹配，请重新读取。');x.report=v;x.message='';
  }catch(e){if(owns(ctx,x)){x.message=e.message;x.report=null;}}
  finally{if(owns(ctx,x)){x.busy=false;showReport(ctx,x);}}
}
export function openOutcomeReport(ctx){
  if(!canOpenOutcomes(ctx.state)){ctx.toast('请先登录并选择当前门店。');return;}
  const x={id:null,live:live(ctx.state),from:today(),to:today(),report:null,message:'',busy:false,closed:false};ctx.state.outcomesUI=x;showReport(ctx,x);void readReport(ctx,x);return x;
}
