// A bounded recipe over original tasks/receipts. No transport or platform code.
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const STORAGE='fangyu-content-chain-pending-v1';
function saved(scope){try{const a=JSON.parse(localStorage.getItem(STORAGE)||'[]');return Array.isArray(a)?a.find(v=>v?.scope===scope&&typeof v.requestId==='string'&&typeof v.chainId==='string')||null:null;}catch{return null;}}
function persist(scope,value){try{const a=JSON.parse(localStorage.getItem(STORAGE)||'[]'),rows=(Array.isArray(a)?a:[]).filter(v=>v?.scope!==scope).slice(-19);if(value)rows.push({scope,requestId:value.requestId,chainId:value.chainId});localStorage.setItem(STORAGE,JSON.stringify(rows));return !value||saved(scope)?.requestId===value.requestId;}catch{return false;}}
const ui=f=>f.chainUI??={open:false,query:'',instructions:'',selectedId:'',notice:'',error:'',busy:false,pending:saved(f.persistScope)};
const chains=w=>Array.isArray(w?.workflow?.chains)?w.workflow.chains:[];
const selected=(r,w)=>chains(w).find(v=>v.id===r.selectedId)||chains(w).at(-1)||null;
const task=(w,id)=>w?.workflow?.tasks?.find(t=>t.id===id);
const labels={prepared:'尚未开始',running:'正在生成',unknown:'结果待核对',succeeded:'候选已生成',needs_revalidation:'来源有变化，需重新核对',known_not_executed:'未执行',completed_invalid:'结果需检查'};
const button=(name,action,disabled=false,extra='')=>`<button type="button" class="co-button" data-chain-action="${action}" ${disabled?'disabled':''} ${extra}>${esc(name)}</button>`;
export function renderChains(f,w){
 if(!Array.isArray(w?.workflow?.chains))return '';
 const r=ui(f),c=selected(r,w),t=c&&task(w,c.steps[c.currentStep].taskId),unknown=t&&['running','unknown'].includes(t.state),locked=!!f.pending||!!f.localUnknown||!!f.runUnknown;
 const running=c?.execution?.state==='running',canRun=c?.state==='active'&&!running&&!unknown&&['prepared','succeeded'].includes(t?.state)&&w.workflowCapabilities?.canRunTasks===true;
 return `<style>.mc-card{margin:18px 0;padding:18px;background:#f7fbfd;border:1px solid #d8e8ec;border-radius:9px;min-width:0;font-size:17px;line-height:1.7}.mc-card p,.mc-card label,.mc-card button,.mc-card input,.mc-card textarea,.mc-card select,.mc-card summary,.mc-card li{font-size:17px!important}.mc-card summary{font-weight:700;cursor:pointer}.mc-card input,.mc-card textarea,.mc-card select{max-width:100%}.mc-steps{list-style:none;padding:0;margin:14px 0}.mc-steps li{display:flex;gap:12px;align-items:center;justify-content:space-between;flex-wrap:wrap;padding:10px 0;border-bottom:1px solid #dce8ee}.mc-status{color:#55798e;overflow-wrap:anywhere}.mc-actions{display:flex;flex-wrap:wrap;gap:10px}.mc-actions button{max-width:100%;white-space:normal}@media(max-width:650px){.mc-card{padding:14px}.mc-steps li{align-items:flex-start;flex-direction:column}}</style><details class="mc-card" data-chain-panel ${r.open?'open':''}><summary>三步内容协作</summary><p>资料整理 → 内容撰写 → 独立审核。一次确认后顺序协作，最后由你核对采用。</p>${r.error?`<p role="alert" class="co-error">${esc(r.error)}</p>`:''}${r.notice?`<p role="status" class="mc-status">${esc(r.notice)}</p>`:''}<details><summary>准备一轮新协作</summary><label class="co-field"><span>这次要做的内容</span><input data-chain-field="query" maxlength="500" value="${esc(r.query)}" placeholder="如：介绍入住前需要核对的事项" ${r.busy||locked?'disabled':''}></label><label class="co-field"><span>补充要求（选填）</span><textarea data-chain-field="instructions" maxlength="1500" rows="3" ${r.busy||locked?'disabled':''}>${esc(r.instructions)}</textarea></label><p class="mc-status">可先在“资料与引用”中选好本次使用的资料。每一步只参考本轮输入和前一步候选。</p>${button('保存协作计划','create',r.busy||locked||!r.query.trim())}</details>${chains(w).length?`<label class="co-field"><span>已保存的协作</span><select data-chain-select ${r.busy?'disabled':''}>${chains(w).map(v=>`<option value="${esc(v.id)}"${v.id===c?.id?' selected':''}>${esc(v.title)} · ${esc(v.query)}</option>`).join('')}</select></label>`:''}${c?`<strong>${esc(c.query)}</strong><ul class="mc-steps">${c.steps.map((s,i)=>{const child=task(w,s.taskId);return `<li><span>${i+1}. ${esc(s.role)} · ${child?esc(labels[child.state]||'原任务待核对'):'等待前一步'}</span>${child?button('查看原任务','task',false,`data-chain-task="${esc(child.id)}"`):''}</li>`;}).join('')}</ul><p class="mc-status" role="status">${c.state==='cancelled'?'已停止后续步骤，已有任务和结果保留。':c.state==='completed'?'三步候选已备齐，请核对后再采用写作稿。':unknown||running?'原协作结果待核对，请先查看原任务，不会重复生成。':c.execution?.state==='paused'?'协作已暂停，请先查看原任务的原因。':'计划已保存，尚未开始本轮协作。'}</p><div class="mc-actions">${button(c.execution?'继续剩余协作':'开始三步协作','run',r.busy||locked||!!r.pending||!canRun)}${button('刷新协作进度','refresh',false)}${c.state==='active'?button('停止后续步骤','cancel',locked):''}${c.state==='completed'?button('查看写作候选并采用','task',false,`data-chain-task="${esc(c.steps[1].taskId)}"`):''}</div>`:'<p class="mc-status">先保存一轮协作计划，暂不生成内容。</p>'}${r.pending?'<p class="mc-status">原开始请求待核对，请刷新进度；不会重新发起。</p>':''}<p class="mc-status">专家审核也是建议，最终内容、素材与发布仍需你确认。</p></details>`;
}
export function bindChains(root,{f,workspace,valid,validate,adopt,update,send,base,request,confirm,openTask}){
 const r=ui(f),current=()=>valid()&&ui(f)===r;
 const put=response=>{if(!current()||!validate(response))return false;if(response.workspace.revision>=workspace().revision)adopt(response);return true;};
 const error=e=>{if(current())update(()=>{r.error=e?.message||'本次协作尚未完成，请核对原任务。';});};
 const chosen=()=>selected(r,workspace());
 async function refresh(){const pending=r.pending,response=await send('content_workspace_read',{...base(),...(pending?{requestId:pending.requestId}:{})});if(!put(response))return null;update(()=>{if(pending){const receipt=response.receipt;if(receipt?.found!==true||receipt.requestId!==pending.requestId||receipt.action!=='content_chain_run'){r.error='原开始编号尚未核对，请保留记录。';return;}if(receipt.state!=='running'){persist(f.persistScope,null);r.pending=null;}}r.notice='已读取本账号的协作进度。';});return response;}
 async function run(c){
  if(!current()||r.busy||r.pending)return;
  const requestId=crypto.randomUUID(),data={...base(),chainId:c.id,chainVersion:c.version,chainDigest:c.digest,humanConfirmed:true,expectedRevision:workspace().revision,requestId};
  if(!persist(f.persistScope,{requestId,chainId:c.id}))throw Error('无法保存本次编号，尚未开始协作。');
  update(()=>{r.busy=true;r.pending={requestId,chainId:c.id};r.error='';r.notice='正在按顺序协作；可刷新进度或停止后续步骤。';});
  try{const response=await send('content_chain_run',data);if(!put(response))return;const receipt=response.receipt;if(receipt?.found!==true||receipt.requestId!==requestId||receipt.action!=='content_chain_run'||response.result?.chain?.id!==c.id)throw Error('原协作回执尚未匹配，请刷新核对。');update(()=>{if(receipt.state!=='running'){persist(f.persistScope,null);r.pending=null;}r.notice=response.result.chain.state==='completed'?'三步候选已保存，请核对后采用。':response.result.chain.state==='cancelled'?'已停止后续步骤，原结果仍可查看。':'已保留原任务，请先核对待处理步骤。';});}
  catch(e){if(e?.mutationCommitted===false&&current())update(()=>{persist(f.persistScope,null);r.pending=null;});error(e);}
  finally{if(current())update(()=>{r.busy=false;});}
 }
 root.querySelector('[data-chain-panel]')?.addEventListener('toggle',e=>{if(current())r.open=e.target.open;});
 root.querySelectorAll('[data-chain-field]').forEach(el=>el.addEventListener('input',()=>{if(current())r[el.dataset.chainField]=el.value;root.querySelector('[data-chain-action="create"]')?.toggleAttribute('disabled',!r.query.trim()||r.busy||!!f.pending);}));
 root.querySelector('[data-chain-select]')?.addEventListener('change',e=>{if(current())update(()=>{r.selectedId=e.target.value;r.error='';r.notice='';});});
 root.querySelectorAll('[data-chain-action]').forEach(el=>el.addEventListener('click',async()=>{try{
  if(!current())throw Error('账号或门店已变化，请重新读取。');const kind=el.dataset.chainAction,c=chosen();
  if(kind==='task'){openTask(el.dataset.chainTask);return;}
  if(kind==='refresh'){await refresh();return;}
  if(kind==='create'){const response=await request('content_chain_save',{operation:'create',title:'三步内容协作',query:r.query,instructions:r.instructions,evidenceIds:[...f.evidenceIds],...(f.experienceReferences?.length?{experienceReferences:structuredClone(f.experienceReferences)}:{})},response=>{r.selectedId=response.result.chain.id;r.notice='协作计划已保存，尚未生成内容。';r.error='';});if(!response&&f.error)error(Error(f.error));return;}
  if(!c)throw Error('请先选择本账号的协作计划。');
  if(kind==='run'){confirm('开始这轮三步协作？','<p>将使用当前账号已配置的生成服务，最多顺序执行三步。中间内容仅作本轮候选，遇到结果待核对会停止；最后仍由你审核采用。</p>',()=>{void run(c).catch(error);});return;}
  if(kind==='cancel'){confirm('停止这轮后续协作？','<p>已开始的任务可能仍在等待结果。原编号和结果保留，可继续核对；不会开始后续步骤。</p>',async()=>{try{await refresh();if(!current())return;const latest=chosen();if(!latest||latest.id!==c.id)throw Error('当前协作已变化，请重新核对。');await request('content_chain_save',{operation:'cancel',chainId:latest.id,chainVersion:latest.version,chainDigest:latest.digest,humanConfirmed:true},()=>{r.notice='已停止后续步骤，原结果仍可查看。';r.error='';});}catch(e){error(e);}});}
 }catch(e){error(e);}}));
}
