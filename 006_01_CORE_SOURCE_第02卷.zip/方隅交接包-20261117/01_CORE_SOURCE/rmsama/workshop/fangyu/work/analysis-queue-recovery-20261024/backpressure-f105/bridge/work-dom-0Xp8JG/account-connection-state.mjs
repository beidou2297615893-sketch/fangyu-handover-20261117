// A success receipt must agree with the exact account snapshot.
export function accountConnectionState(platform,value={},account){
  value=value&&typeof value==='object'?value:{};
  const reported=['completed','succeeded'].includes(value.status);
  const verified=platform==='douyin'&&value.status==='ready'&&value.platformLoginConfirmed===true&&value.bindingVerified===true;
  const matching=account?.platform===platform&&value.accountId===account.id;
  const complete=Boolean(matching&&['ready','connected','online'].includes(account.status)&&(reported||verified));
  const terminal=reported||verified||['failed','cancelled','stopped'].includes(value.status);
  const needsSnapshot=Boolean((reported||verified)&&!complete);
  const phase=complete?'已连接':value.status==='checking'?'正在确认账号身份':needsSnapshot?'登录结果待核对':value.status==='cancelled'?'本次连接已取消':value.status==='stopped'?'本次连接已停止':value.status==='failed'?'连接尚未完成':account?.platformNickname||account?.platform_nickname?'已识别账号，正在连接':'等待平台登录';
  return {complete,terminal,phase,needsSnapshot};
}
