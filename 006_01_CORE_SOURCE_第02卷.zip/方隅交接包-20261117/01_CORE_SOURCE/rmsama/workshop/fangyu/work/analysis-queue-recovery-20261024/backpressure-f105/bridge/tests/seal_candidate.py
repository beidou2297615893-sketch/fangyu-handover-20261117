from pathlib import Path
from datetime import datetime,timezone
import difflib,hashlib,json,subprocess
ROOT=Path(__file__).resolve().parents[1]
BASE=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/candidate-unified-v104/project')
RELEASE=BASE/'work/ui-native-r57/releases/ui-r57-20261024T153411Z-4c9dd686'
E=ROOT/'evidence';E.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def artifact(path):return {'path':str(path),'sha256':sha(path)}
def write(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n','utf-8')
files=[];syntax=[];diff=[]
for name in ('acquire.mjs','saved-comment-analysis.mjs'):
    relative='work/ui-approved-implementation/ui-preview/pages/'+name
    candidate=ROOT/'candidate'/relative;baseline=BASE/relative;frozen=RELEASE/'web/pages'/name
    assert sha(baseline)==sha(frozen)
    files.append({'relativePath':relative,'candidate':str(candidate),'sha256':sha(candidate),
      'baselinePath':str(baseline),'baselineSha256':sha(baseline),'releaseRelativePath':'web/pages/'+name})
    run=subprocess.run(['node','--check',str(candidate)],capture_output=True,text=True)
    assert run.returncode==0,run.stderr
    syntax.append({'name':name,'command':['node','--check',str(candidate)],'exitCode':run.returncode,'sha256':sha(candidate)})
    diff.extend(difflib.unified_diff(baseline.read_text('utf-8').splitlines(True),candidate.read_text('utf-8').splitlines(True),fromfile='F104/'+name,tofile='candidate/'+name))
old=(RELEASE/'web/pages/acquire.mjs').read_text('utf-8')
new=old.replace('savedCommentAnalysisView,analysisBufferMessage}', 'savedCommentAnalysisView,analysisBufferMessage,analysisCollectionDecoupled}')
new=new.replace("if(bufferMessage){title='采集缓冲已暂停';message=bufferMessage;stage='paused';}","if(bufferMessage){title=analysisCollectionDecoupled(live)?'采集已暂停':'采集缓冲已暂停';message=bufferMessage;stage='paused';}")
assert new==(ROOT/'candidate/work/ui-approved-implementation/ui-preview/pages/acquire.mjs').read_text('utf-8'),'No acquisition capability or event gate may change'
(E/'SOURCE.diff').write_text(''.join(diff),'utf-8')
red=subprocess.run(['node',str(ROOT/'tests/test_backpressure_ui.mjs'),'--web',str(RELEASE/'web')],capture_output=True,text=True,encoding='utf-8')
(E/'BASELINE-RED.log').write_text(red.stdout+'\n'+red.stderr,'utf-8')
assert red.returncode==1
red_data=json.loads(red.stdout);assert not red_data['passed'] and red_data['cases']==12
green=json.loads((ROOT/'GREEN-FINAL.log').read_text('utf-8-sig'));prior=json.loads((ROOT/'PRIOR-UI-11.log').read_text('utf-8-sig'))
assert green['passed'] and green['cases']==12 and prior['passed'] and prior['cases']==11
assert {f['sha256'] for f in files}=={f['sha256'] for f in green['verifiedFiles']}
write(E/'SYNTAX.json',{'passed':True,'checks':syntax})
validation={'schema':'decoupled-analysis-ui-candidate-v1','passed':True,'sealed':True,'authorStopped':True,
 'atUtc':datetime.now(timezone.utc).isoformat(),'baselineRelease':str(RELEASE),'files':files,
 'rootCause':{'historicalMessage':'analysisBufferMessage treated an old collection pause text as current 200 pressure regardless of real workspace counts',
   'buttons':'acquire already trusts backend canStart/canResume; UI never overrides these capabilities',
   'runtimePrerequisite':'analysisDecoupled true, analysisBufferMode durable_background and analysisBufferLimit null explicitly identify automatic mode; legacy remains unchanged'},
 'checks':[{'name':'targeted-actual-module-and-acquisition-DOM','cases':12,'exitCode':0,'evidence':artifact(ROOT/'GREEN-FINAL.log')},
   {'name':'same-final-test-fails-on-exact-F104','cases':12,'exitCode':1,'expectedFailure':True,'evidence':artifact(E/'BASELINE-RED.log')},
   {'name':'prior-automatic-analysis-UI-regression','cases':11,'exitCode':0,'evidence':artifact(ROOT/'PRIOR-UI-11.log')},
   {'name':'module-syntax','cases':2,'exitCode':0,'evidence':artifact(E/'SYNTAX.json')},
   {'name':'all-acquisition-button-and-bind-gates-byte-preserved','passed':True}],
 'diff':artifact(E/'SOURCE.diff'),'testScript':artifact(ROOT/'tests/test_backpressure_ui.mjs'),
 'frozenVerificationArgv':['node',str(ROOT/'tests/test_backpressure_ui.mjs'),'--pins',str(ROOT.parents[1]/'package/ROOT-FINAL-PINS-V105.json')],
 'frozenVerificationAlternative':'node <testScript> --web <actual frozen release>/web',
 'boundary':{'productionWrites':0,'realCloudModelOrPlatformCalls':0,'nativeWindowActions':0},
 'limitations':['UI alone cannot release collection: the matching Runtime capability/admission repair must be composed. No live collection or actual native result is claimed.']}
write(E/'VALIDATION.json',validation)
seal={'schema':'decoupled-analysis-ui-seal-v1','passed':True,'sealed':True,'authorStopped':True,
 'validation':str(E/'VALIDATION.json'),'validationSha256':sha(E/'VALIDATION.json'),'files':files}
write(ROOT/'SEALED.json',seal)
print(json.dumps({'passed':True,'validation':artifact(E/'VALIDATION.json'),'seal':artifact(ROOT/'SEALED.json'),'files':files},ensure_ascii=False))
