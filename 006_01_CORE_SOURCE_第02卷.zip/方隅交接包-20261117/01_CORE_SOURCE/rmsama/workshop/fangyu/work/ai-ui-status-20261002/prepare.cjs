// Reuse the verified deployment workflow; stage only the reviewed UI patch.
const fs=require('node:fs'),path=require('node:path');
const project=path.resolve(__dirname,'../..');
const report=JSON.parse(fs.readFileSync(path.join(project,'work/ai-provider-status-20261002/deployment.json')));
const {digest,compare}=require(path.join(project,'work/cloud/verify_live_function_tree.cjs'));
const base='6905eb58df30882edd7ff40674ba68a3149c15d391614d621ad8e689bda54ac7';
if(report.phase!=='active'||digest(report.verified_code_copy)!==base)throw Error('baseline_differs');
const stage=path.join(__dirname,'stage');
if(fs.existsSync(stage)||fs.existsSync(path.join(__dirname,'deploy.cjs')))throw Error('already_prepared');
fs.cpSync(report.verified_code_copy,stage,{recursive:true,errorOnExist:true,force:false});
const local=path.join(project,'work/app/src/web/workspace/enterprise-ui.mjs');
const mirror=path.join(project,'work/cloud/workspace/site/enterprise-ui.mjs');
if(!fs.readFileSync(local).equals(fs.readFileSync(mirror)))throw Error('ui_mirror_differs');
fs.copyFileSync(mirror,path.join(stage,'site/enterprise-ui.mjs'));
let code=fs.readFileSync(path.join(project,'work/ai-provider-status-20261002/deploy.cjs'),'utf8');
const replacements=[
 ["work/ai-ledger-compat-20261002/deployment.json","work/ai-provider-status-20261002/deployment.json"],
 ["7fad45ac46373a9cc5b9ef221bd1e859911f123e4109518a5863dd3170521007",base],
 ["delta.changed_count!==2","delta.changed_count!==1"],
 ["['ai_enterprise.cjs','ai_provider.cjs']","['site/enterprise-ui.mjs']"],
 ["Exact provider balance/auth status compatibility patch","Exact UI balance/auth and analysis recovery status compatibility patch"]
];
for(const [before,after] of replacements){
 if(!code.includes(before))throw Error('deployment_template_differs');
 code=code.split(before).join(after);
}
fs.writeFileSync(path.join(__dirname,'deploy.cjs'),code,{flag:'wx'});
const delta=compare(report.verified_code_copy,stage);
if(delta.missing_count||delta.extra_count||delta.changed_count!==1||delta.sample_mismatch[0]!=='site/enterprise-ui.mjs')throw Error('candidate_differs');
console.log(JSON.stringify({prepared:true,changed_files:delta.sample_mismatch,candidate_sha:delta.downloaded_tree_sha256}));
