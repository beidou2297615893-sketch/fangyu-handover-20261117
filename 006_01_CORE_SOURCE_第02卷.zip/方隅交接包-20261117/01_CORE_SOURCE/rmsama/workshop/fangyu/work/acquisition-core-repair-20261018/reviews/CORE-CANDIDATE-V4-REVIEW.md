# Core candidate v4 最终闭包独立审查

结论：Critical 0 / Important 0 / Minor 0。v4 固定闭包及其相对 v3 的增量通过本次只读审查。此为技术结论，不作平台、许可、用途或商业分发批准。

## 实际闭包

- Release：`ui-r57-20261018T020223Z-45516587`。
- UNIFIED-PINS SHA：`50d1c122066e742cf2a52a7c2ddea72f4398bb42563e7ed52f752f18a0f93ec5`。
- 本审查逐项核对 2216 pins、117 frozen files、245 source55 父依赖与 2096 当前公共源输入，大小及哈希全部一致。原 CLI 297 文件同字节，未编译或执行。固定 helper8455、private_evaluation、self_operating_read、runtime_license_policy 的已审字节保持。
- 既有 UNIFIED-VALIDATION.json 的 22 项原校验器记录对应本 v4 release/pin；本审查没有重跑旧套。
- 三处装配变换逐字节重建后与候选相同：company 仅 cli_source_sha256、employee_distribution 三个 artifact pins、Runtime 仅 guarded-cli 路径。其余源输入与当前 canonical 对应。

## v3 到 v4 的精确增量

共同路径只有以下两个公共源码变化；另外 120 个旧 release/launcher 路径被 120 个新路径替换，没有其他共同路径字节变化：

1. `work/ui-native-r57/workbench_backend.py:950`：customers 入口白名单新增 audience，使现有 prospects 参数能到达服务；customer_export、detail、handoff 白名单未扩大。身份、授权门店和 actor 派生路径未变。
2. `work/ui-native-r57/customer_workbench.py:415`：提取 `_is_prospect`，与原 `_matching` 条件逻辑等价（原 non_target 单独排除已经被 eligibility 白名单覆盖）；433 行沿用它筛 prospects；527 行让 recent 同样先筛 prospects 再取前三。analyzed 仍统计所有合格已分析来源，没有用近期展示条数冒充分析量。

`_options` 184–200 行仍只接受 audience=all/prospects；_matching 在原已授权 employee/store 历史上做过滤，未扩大身份或跨店读取。默认 all 历史行为保留。已读取本轮 2 个 gateway + 3 个 scope + 12 个 media focused GREEN 的既有短日志，未重跑或将旧日志冒充新 GUI。

Core/Runtime/rental 及完整 1000 集成所记 9 源与 v3 同字节。CORE-AI-RENTAL-1000-RESULT 的 9 个 canonical 源哈希均与当前实际文件相同；其中 Runtime 在候选只做上述 selector 路径变换，其他 8 源在候选为测试字节原样。该证据真实 Core/SQLite/workflow/local rental，50 页/1000 入库/1000 分析/最大分组20，平台、provider、准入外部边界为 fixture；不据此宣称真实平台、付费 AI 或新原生 GUI 通过。v3 已审同事务 db 连接修复及账号 owner/tenant/delete 拒绝没有变化。

## 本地入口复用及待完成证据

审查时 GUI-RESULT、PREPARED、INSTALL 均尚未生成；entry 中实际两个生成脚本仍指 v3。adapt_entry_tools 源已指 v4，应按既有步骤运行它生成 v4 工具，不能直接执行当前 v3 entry 工具。此为已知顺序待办，不是需要改产品的新缺陷。

已静态核对适配算法：prepare 仍要求本 release 的新 browser/native GUI gate，零真实平台/付费 AI，并捕获新旧入口实际哈希；不借用旧原生成功记录。install 换成 v4 OUT 后与已审事务模板除 P/OUT 字面量外完全相同：仅 run_workbench.py 和 FROZEN.json，替换前逐文件 CAS、独占备份、fsync/os.replace、仅在目标仍匹配本次 old/new 时回滚。原 state、双 binding import 前校验、company、授权用途及 other-owner 边界未扩大。

在本轮 GUI gate 成立、实际生成 v4 PREPARED 并完成既有入口 --check 后，可继续已授权的本地两文件安装。本报告不预告 native/安装成功；后续实际结果须由其新证据确认。安装并非两个文件在操作系统层面的整体原子替换。

审查者只写本目录报告/短 JSON，未改产品、未访问真实 DB/vault 内容、未启动 UI/CLI/真实网络或付费请求。短核验事实见 CORE-CANDIDATE-V4-REVIEW.json。
