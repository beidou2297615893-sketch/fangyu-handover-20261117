"""Source-only search scroll snapshot and resumable observed-ID checkpoint.

Range states describe DOM evidence, never API pagination or a platform cursor.
"""

from pathlib import Path
import json
import re


_SCRIPT = (Path(__file__).resolve().parent / 'resources' / 'xhs-search-range.js').read_text(encoding='utf-8')
_ACTIONS = {'observe', 'scroll'}
_CODES = {'untrusted_page', 'feed_loading', 'feed_ambiguous', 'root_ambiguous', 'card_cap',
          'observed', 'scrolled', 'no_scroll_advance'}
_ID = re.compile(r'[0-9a-f]{24}')
_FIELDS = {'code', 'observed_ids', 'ready_ids', 'card_count', 'dom_card_count', 'visible_card_count',
           'distinct_card_tops', 'scroll_top_before', 'scroll_top_after',
           'scroll_height', 'client_height', 'feed_client_height',
           'action_performed', 'at_bottom', 'explicit_end_marker',
           'content_loading', 'count_capped'}
_GEOMETRY = ('scroll_top_after', 'scroll_height', 'client_height', 'feed_client_height')
MAX_SEEN = 100000
MAX_NO_NEW_PROGRESS = 120


def _keyword(value):
    return (type(value) is str and 0 < len(value) <= 200
            and not any(ord(char) < 32 or ord(char) == 127 for char in value))


def build_search_range_js(action: str = 'observe', *, keyword: str = '上海公寓租房') -> str:
    if (type(action) is not str or action not in _ACTIONS or not _keyword(keyword)
            or _SCRIPT.count("'__ACTION__'") != 1
            or _SCRIPT.count("'__KEYWORD__'") != 1):
        raise ValueError('search_range_action_invalid')
    return (_SCRIPT.replace("'__ACTION__'", "'" + action + "'", 1)
            .replace("'__KEYWORD__'", json.dumps(keyword, ensure_ascii=True), 1))


def _ids(value, limit):
    return (type(value) is list and len(value) <= limit
            and all(type(item) is str and _ID.fullmatch(item) for item in value)
            and len(set(value)) == len(value))


def validate_search_snapshot(value: object) -> dict:
    if not isinstance(value, dict) or set(value) != _FIELDS:
        raise ValueError('search_snapshot_invalid')
    if type(value['code']) is not str or value['code'] not in _CODES:
        raise ValueError('search_snapshot_invalid')
    if not _ids(value['observed_ids'], 200) or not _ids(value['ready_ids'], 200):
        raise ValueError('search_snapshot_invalid')
    if not set(value['ready_ids']).issubset(value['observed_ids']):
        raise ValueError('search_snapshot_invalid')
    for key in ('card_count', 'visible_card_count', 'distinct_card_tops'):
        if type(value[key]) is not int or not 0 <= value[key] <= 200:
            raise ValueError('search_snapshot_invalid')
    if type(value['dom_card_count']) is not int or not 0 <= value['dom_card_count'] <= 100000:
        raise ValueError('search_snapshot_invalid')
    for key in ('scroll_top_before', 'scroll_top_after', 'scroll_height',
                'client_height', 'feed_client_height'):
        if type(value[key]) is not int or not 0 <= value[key] <= 10000000:
            raise ValueError('search_snapshot_invalid')
    for key in ('action_performed', 'at_bottom', 'explicit_end_marker',
                'content_loading', 'count_capped'):
        if type(value[key]) is not bool:
            raise ValueError('search_snapshot_invalid')
    if (value['card_count'] > value['dom_card_count']
            or value['visible_card_count'] > value['card_count']
            or value['distinct_card_tops'] > value['card_count']
            or len(value['observed_ids']) > value['card_count']
            or value['action_performed'] != (value['code'] == 'scrolled')
            or (value['code'] == 'scrolled' and
                value['scroll_top_after'] <= value['scroll_top_before'])
            or (value['explicit_end_marker'] and
                (not value['at_bottom'] or value['content_loading']))):
        raise ValueError('search_snapshot_invalid')
    if value['code'] in {'untrusted_page', 'feed_ambiguous', 'root_ambiguous'} and (
            value['observed_ids'] or value['ready_ids'] or value['action_performed']):
        raise ValueError('search_snapshot_invalid')
    if value['code'] == 'feed_loading' and (value['observed_ids'] or value['ready_ids'] or
            value['card_count'] or value['dom_card_count'] or value['action_performed'] or
            value['explicit_end_marker'] or not value['content_loading']):
        raise ValueError('search_snapshot_invalid')
    return dict(value)


def initial_checkpoint(keyword: str = '上海公寓租房') -> dict:
    if not _keyword(keyword):
        raise ValueError('search_checkpoint_invalid')
    return {'version': 1, 'keyword': keyword, 'scan_step': 0,
            'observed_ids': [], 'ready_ids': [], 'delivered_ids': [],
            'last_geometry': None, 'stable_rounds': 0,
            'no_new_progress_steps': 0, 'range_state': 'unknown'}


def _validate_checkpoint(value):
    if (not isinstance(value, dict) or set(value) != set(initial_checkpoint())
            or type(value['version']) is not int or value['version'] != 1
            or not _keyword(value['keyword'])
            or type(value['scan_step']) is not int
            or not 0 <= value['scan_step'] <= 1000000
            or not _ids(value['observed_ids'], MAX_SEEN)
            or not _ids(value['ready_ids'], MAX_SEEN)
            or not _ids(value['delivered_ids'], MAX_SEEN)
            or not set(value['ready_ids']).issubset(value['observed_ids'])
            or not set(value['delivered_ids']).issubset(value['ready_ids'])
            or type(value['no_new_progress_steps']) is not int
            or not 0 <= value['no_new_progress_steps'] <= MAX_NO_NEW_PROGRESS
            or type(value['stable_rounds']) is not int
            or not 0 <= value['stable_rounds'] <= 2
            or type(value['range_state']) is not str
            or value['range_state'] not in {'unknown', 'more', 'plateau', 'explicit_end'}):
        raise ValueError('search_checkpoint_invalid')
    geometry = value['last_geometry']
    if geometry is not None and (
            type(geometry) is not list or len(geometry) != 4
            or any(type(n) is not int or not 0 <= n <= 10000000 for n in geometry)):
        raise ValueError('search_checkpoint_invalid')


def validate_checkpoint(value: dict) -> dict:
    _validate_checkpoint(value)
    return {**value, 'observed_ids': list(value['observed_ids']),
            'ready_ids': list(value['ready_ids']),
            'delivered_ids': list(value['delivered_ids']),
            'last_geometry': None if value['last_geometry'] is None else list(value['last_geometry'])}


def pending_ready_ids(checkpoint: dict, *, limit: int = 40) -> list[str]:
    _validate_checkpoint(checkpoint)
    if type(limit) is not int or not 1 <= limit <= 40:
        raise ValueError('search_checkpoint_invalid')
    delivered = set(checkpoint['delivered_ids'])
    return [item for item in checkpoint['ready_ids'] if item not in delivered][:limit]


def mark_delivered(checkpoint: dict, delivered_ids: list[str]) -> dict:
    """A caller records only rows it has actually handed to its pipeline."""
    _validate_checkpoint(checkpoint)
    if (type(delivered_ids) is not list or len(delivered_ids) > 40 or
            any(type(item) is not str or not _ID.fullmatch(item) for item in delivered_ids) or
            len(set(delivered_ids)) != len(delivered_ids) or
            not set(delivered_ids).issubset(set(checkpoint['ready_ids']))):
        raise ValueError('search_delivery_invalid')
    seen = set(checkpoint['delivered_ids'])
    result = {**checkpoint, 'delivered_ids': checkpoint['delivered_ids'] +
              [item for item in delivered_ids if item not in seen]}
    _validate_checkpoint(result)
    return result


def resume_checkpoint(checkpoint: dict) -> dict:
    """Keep dedupe IDs, reset page geometry/stall after a fresh owned document."""
    _validate_checkpoint(checkpoint)
    return {**checkpoint, 'observed_ids': list(checkpoint['observed_ids']),
            'ready_ids': list(checkpoint['ready_ids']),
            'delivered_ids': list(checkpoint['delivered_ids']),
            'last_geometry': None, 'stable_rounds': 0,
            'no_new_progress_steps': 0, 'range_state': 'unknown'}


def advance_checkpoint(checkpoint: dict, raw_snapshot: dict, *, keyword: str | None = None) -> tuple[dict, dict]:
    _validate_checkpoint(checkpoint)
    if checkpoint['scan_step'] >= 1000000:
        raise ValueError('search_checkpoint_full')
    if keyword is not None and keyword != checkpoint['keyword']:
        raise ValueError('search_checkpoint_keyword_mismatch')
    snapshot = validate_search_snapshot(raw_snapshot)
    if snapshot['code'] == 'feed_loading':
        # No cursor, delivered IDs or exhaustion state changes while mounting.
        return validate_checkpoint(checkpoint), {'range_state': checkpoint['range_state'],
            'new_observed_ids': [], 'new_ready_ids': [], 'terminal': False, 'next_action': 'wait'}
    if snapshot['code'] in {'untrusted_page', 'feed_ambiguous', 'root_ambiguous', 'card_cap'}:
        next_checkpoint = {**checkpoint, 'range_state': 'unknown', 'stable_rounds': 0,
                           'no_new_progress_steps': 0, 'scan_step': checkpoint['scan_step'] + 1}
        return next_checkpoint, {'range_state': 'unknown', 'new_observed_ids': [],
                                 'new_ready_ids': [], 'terminal': False, 'next_action': 'inspect'}
    seen_observed = set(checkpoint['observed_ids'])
    seen_ready = set(checkpoint['ready_ids'])
    new_observed = [item for item in snapshot['observed_ids'] if item not in seen_observed]
    new_ready = [item for item in snapshot['ready_ids'] if item not in seen_ready]
    if (len(checkpoint['observed_ids']) + len(new_observed) > MAX_SEEN or
            len(checkpoint['ready_ids']) + len(new_ready) > MAX_SEEN):
        raise ValueError('search_checkpoint_full')
    geometry = [snapshot[key] for key in _GEOMETRY]
    previous = checkpoint['last_geometry']
    progressed = previous is not None and (
        geometry[0] > previous[0] or geometry[1] > previous[1] or geometry[3] > previous[3])
    no_new_progress_steps = (0 if new_observed or new_ready else
                             min(MAX_NO_NEW_PROGRESS,
                                 checkpoint['no_new_progress_steps'] + int(progressed)))
    if snapshot['code'] == 'observed' and snapshot['explicit_end_marker']:
        state, stable = 'explicit_end', 0
    elif no_new_progress_steps >= MAX_NO_NEW_PROGRESS:
        state, stable = 'plateau', 0
    elif new_observed or new_ready or progressed:
        state, stable = 'more', 0
    elif (snapshot['code'] == 'observed' and snapshot['at_bottom']
          and not snapshot['content_loading'] and snapshot['feed_client_height'] > 0):
        stable = min(2, checkpoint['stable_rounds'] + 1)
        state = 'plateau' if stable == 2 else 'unknown'
    else:
        state, stable = 'unknown', 0
    next_checkpoint = {'version': 1, 'keyword': checkpoint['keyword'],
                       'scan_step': checkpoint['scan_step'] + 1,
                       'observed_ids': checkpoint['observed_ids'] + new_observed,
                       'ready_ids': checkpoint['ready_ids'] + new_ready,
                       'delivered_ids': list(checkpoint['delivered_ids']),
                       'last_geometry': geometry, 'stable_rounds': stable,
                       'no_new_progress_steps': no_new_progress_steps,
                       'range_state': state}
    next_action = {'more': 'collect_or_scroll', 'plateau': 'wait',
                   'explicit_end': 'stop_current_range', 'unknown': 'inspect_or_scroll'}[state]
    return next_checkpoint, {'range_state': state, 'new_observed_ids': new_observed,
                             'new_ready_ids': new_ready,
                             'terminal': state == 'explicit_end', 'next_action': next_action}

