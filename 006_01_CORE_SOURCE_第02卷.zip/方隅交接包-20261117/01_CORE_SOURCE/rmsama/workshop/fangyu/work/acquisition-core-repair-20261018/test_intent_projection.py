from pathlib import Path
import importlib.util,sys,unittest,hashlib,json,datetime
from unittest.mock import patch
W=Path(__file__).resolve().parent;P=W.parents[1]
spec=importlib.util.spec_from_file_location('employee_previous_fixture',P/'work/employee-simple-flow-20261018/test_employee_flow.py')
previous=importlib.util.module_from_spec(spec);spec.loader.exec_module(previous)
from customer_workbench import CustomerWorkbench

class CurrentIntentProjection(previous.EmployeeStartTests):
 def setUp(self):
  super().setUp()
  self.backend.customer_workbench=CustomerWorkbench(self.backend.core,self.company,P,rental_reader=self.backend._read_rental_assessment)
  self.user,self.profile=self.backend._identity(self.token)
  self.task_id='current-task-contract'
  self.backend.core.store.put('accounts',{'id':'fixture-account','tenant_id':self.user['tenant_id'],
   'cloud_owner':self.user['username'],'platform':'xiaohongshu','store_id':self.store,'status':'ready'})
  self.backend.core.store.put('tasks',{'id':self.task_id,'tenant_id':self.user['tenant_id'],
   'cloud_owner':self.user['username'],'account_id':'fixture-account','platform':'xiaohongshu',
   'store_id':self.store,'status':'ready'})
  rule=self.backend._assessment_policy(self.store)
  self.assertTrue(rule['supported']);self.assertTrue(rule['enabled'])
  self.backend.core.store.put('rental_task_context_v1',{'id':self.task_id,'tenant_id':self.user['tenant_id'],
   'owner':self.user['username'],'enabled':True,'store_id':self.store,'rule_version':rule['engineVersion'],
   'contractDigest':rule['contractDigest'],'sourceDigest':rule['sourceDigest'],'bundleRevision':rule['bundleRevision']})
 def add(self,source,text):
  self.backend.core._import([{'platform':'xiaohongshu','source_type':'comment','source_id':source,
   'comment_id':source,'author_id':source+'-author','author':'隔离测试客户','text':text,
   'task_id':self.task_id,'content_title':'古北公寓','note_url':'https://www.xiaohongshu.com/explore/'+'1'*24,
   'published_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}],self.user['tenant_id'],self.user)
  return next(v for v in self.backend.core.store.list('leads',self.user['tenant_id']) if v['source_id']==source)
 def test_no_saved_apply_still_reads_persisted_current_assessment(self):
  self.assertIsNone(self.backend._load_selection(self.user,self.login['stores'])['applied'])
  lead=self.add('renter-one','我想整租古北的一居，预算3000元每月，明天下午三点可以看房吗')
  self.assertEqual(self.backend._assess_imported(self.user,self.task_id)['assessed'],1)
  result=self.backend._read_rental_assessment(self.user,self.store,lead['id'])
  self.assertIsNotNone(result);self.assertEqual(result['intent_level'],'high')
 def test_current_task_analyzed_count_does_not_require_manual_apply(self):
  self.add('renter-two','我想整租古北的一居，预算3000元每月，明天下午三点可以看房吗')
  self.backend._assess_imported(self.user,self.task_id)
  with patch.object(self.backend.platform_runtime,'snapshot',return_value={
   'acquisition':{'taskId':self.task_id,'counts':{'added':1,'read':1,'analyzed':0},'status':'completed'}}):
   current=self.backend._platform_state(self.user,self.profile)
  self.assertEqual(current['acquisition']['counts']['analyzed'],1)
 def test_current_central_exclusions_reach_real_start_payload(self):
  config=self.cloud.configs[self.store]
  config['runtimeSearch']['excludeTerms']=['合成中介供给词']
  digest=lambda v:hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
  next(v for v in self.cloud.manifest['stores'] if v['id']==self.store)['config_digest']=digest(config)
  self.cloud.manifest['catalog_digest']=digest(self.cloud.configs)
  self.start()
  self.assertEqual(self.backend.platform_runtime.calls[0].get('excludes'),['合成中介供给词'])
 def test_non_target_supplier_is_not_a_reply_prospect(self):
  self.add('supplier','我是中介，这里有一居房源出租，欢迎私信我')
  self.add('renter','我想整租古北一居，预算3000元每月，明天下午三点可以看房吗')
  self.backend._assess_imported(self.user,self.task_id)
  try:result=self.backend.customer_workbench.list(self.user,self.store,{'audience':'prospects'})
  except ValueError as error:self.fail('Prospect scope unavailable: '+str(error))
  self.assertEqual(result['total'],1)
  self.assertEqual(result['items'][0]['eligibility'],'rental_seeker')
 def test_rule_and_source_provenance_are_not_conflated(self):
  self.add('renter-three','我想整租古北一居，预算3000元每月，明天下午三点可以看房吗')
  self.backend._assess_imported(self.user,self.task_id)
  item=self.backend.customer_workbench.list(self.user,self.store,{})['items'][0]
  rule=self.backend._assessment_policy(self.store)
  self.assertEqual(item.get('assessmentRuleSourceDigest'),rule['sourceDigest'])
  self.assertEqual(item.get('assessmentContractDigest'),rule['contractDigest'])
  self.assertNotEqual(item['assessmentSourceDigest'],item['assessmentRuleSourceDigest'])
 def test_saved_ai_grade_is_visible_when_local_rule_is_provisional(self):
  lead=self.add('contextual-question','还有房吗？')
  ai={'status':'graded','level':'high','provider':'deepseek','model':'deepseek-flash',
   'rules_version':'synthetic-cloud-policy-v7','reason':'合成AI边界已按原帖语境判断',
   'evidence':['还有房吗'],'key_info':[],'source':'cloud_ai'}
  self.backend.core.store.put('leads',{**lead,'ai_intent':ai,'analysis_status':'graded'})
  item=self.backend.customer_workbench.list(self.user,self.store,{})['items'][0]
  self.assertEqual(item['intentSource'],'ai')
  self.assertEqual(item['intentLevel'],'high')
  self.assertEqual(item.get('intentModel'),'deepseek-flash')
  self.assertEqual(item['intentRuleVersion'],'synthetic-cloud-policy-v7')
  self.assertEqual(self.backend.customer_workbench.list(self.user,self.store,{'audience':'prospects'})['total'],1)
 def test_current_saved_ai_results_are_counted_without_local_assessment(self):
  lead=self.add('ai-count','还有房吗？')
  self.backend.core.store.put('leads',{**lead,'ai_intent':{'status':'uncertain','level':None,
   'rules_version':'synthetic-cloud-policy-v7','reason':'合成AI待确认'},'analysis_status':'uncertain'})
  summary=self.backend.customer_workbench.acquisition_summary(self.user,self.store,self.task_id)
  self.assertEqual(summary['analyzed'],1)

if __name__=='__main__':
 names=[n for n in CurrentIntentProjection.__dict__ if n.startswith('test_')]
 result=unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite(CurrentIntentProjection(n) for n in names))
 raise SystemExit(not result.wasSuccessful())
