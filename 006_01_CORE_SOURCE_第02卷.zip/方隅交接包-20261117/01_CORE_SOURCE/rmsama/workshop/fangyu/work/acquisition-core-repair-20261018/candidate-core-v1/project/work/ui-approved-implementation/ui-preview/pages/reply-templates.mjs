// Copied without semantic changes from pinned web/workspace/upgrade-model.mjs:62-72.
// Source SHA256: 4CAE160CFDF1E5F8D9B84B990B8A4D1199332123871D9EFADCEBB75791585E68
// Preview/explicit overwrite/input-dirty workflow: upgrade-shell.mjs:193-201,
// SHA256: 33BC096FFFBECAC7195B8AF13FD4A87D6D142D921C8DC6AB67ADC5C38B3D157A.
export const replyTones=Object.freeze({official:'官方顾问',friendly:'亲切顾问',partner:'合作中介'});
export function replyTemplate({tone='friendly',identity=''}={}){
  const real=String(identity).trim();
  if(!real||real.length>80||/[\r\n]/.test(real))throw Error('请填写你向客户说明的真实身份，最多80字。');
  if(!Object.hasOwn(replyTones,tone))throw Error('请选择可用的回复口吻。');
  const lead={official:`你好，我是${real}。看到你的租房需求，方便确认一下意向区域、预算和入住时间吗？我可以据此帮你核对合适的选择。`,
    friendly:`你好呀，我是${real}。看到你在找房，想先了解一下你更在意的区域、预算和入住时间，我们再一起看看适合的选择。`,
    partner:`你好，我是${real}。看到你的求租需求，方便补充区域、预算和入住时间吗？我会先核对匹配情况，再与你沟通下一步。`};
  return lead[tone];
}
