/* Read a company ledger only after the local source event has been bound. */
const localId=value=>typeof value==='string'&&/^[a-f0-9]{32}$/.test(value);
const channelId=value=>typeof value==='string'&&/^hc_[a-f0-9]{64}$/.test(value);
const integer=value=>Number.isSafeInteger(value)&&value>=0;
const amount=value=>value===null||integer(value)&&value<=100000000000;
const safeText=value=>typeof value==='string'&&value.length>0&&value.length<=128&&!/[\u0000-\u001f\u007f]/.test(value);
const bool=value=>typeof value==='boolean';
const nullableBool=value=>value===null||bool(value);
const falseFlags=['cross_machine_verified','platform_requests_started','provider_requests_started','ratings_modified','contacts_modified','handoffs_modified','orders_modified','payments_started','auto_retry','local_cloud_handoff_correspondence_verified','financial_receipt_verified','cooperation_policy_verified'];
const bindingStates=['matched','link_revision_changed','source_missing','source_conflict','customer_conflict','order_missing','reverse_link_conflict','history_missing','history_conflict','record_invalid'];
const evidenceLabels={financial_cash_authority_not_integrated:'尚未接入客户实收凭证',commission_payment_authority_not_integrated:'尚未接入分成付款凭证',cooperation_policy_not_verified:'合作分成政策未由双方核验',source_missing:'来源证据缺失',source_conflict:'来源证据冲突',link_revision_changed:'关联订单版本已变化',customer_conflict:'客户对应有冲突',order_missing:'公司订单缺失',reverse_link_conflict:'订单反向关联有冲突',history_missing:'订单历史版本缺失',history_conflict:'订单历史版本有冲突',record_invalid:'订单记录格式待核对',commission_policy_history_missing:'分成计算的原政策快照缺失'};
const baseEvidence=['financial_cash_authority_not_integrated','commission_payment_authority_not_integrated','cooperation_policy_not_verified'];
const evidence=value=>Array.isArray(value)&&value.length<=13&&new Set(value).size===value.length&&value.every(code=>Object.hasOwn(evidenceLabels,code))&&baseEvidence.every(code=>value.includes(code));
const exact=(value,fields)=>value&&typeof value==='object'&&!Array.isArray(value)&&Object.keys(value).length===fields.length&&fields.every(field=>Object.hasOwn(value,field));
const orderFields=['order_no','linked_revision','current_revision','status','binding_state','link_revision_current','reported_amount_cents','reported_refund_cents','reported_net_cents','reported_by','last_edited_by','admin_review_recorded','reviewed_by','distinct_review_actor_recorded','recorded_calculated_commission_cents','calculation_status','calculation_policy_revision','calculation_policy_snapshot_available','calculation_policy_current','verified_cash_cents','verified_paid_commission_cents','financial_receipt_verified','cooperation_policy_verified','missing_evidence'];
const node=(tag,text='',className='')=>{const value=document.createElement(tag);value.textContent=String(text);if(className)value.className=className;return value;};
const money=value=>value===null?'尚无可核对金额':`${value.toLocaleString('zh-CN')} 分（币种待核对）`;

export function checkedBusinessReconciliation(value,request){
  if(!exact(value,[...falseFlags,'contract','read_only','storage_scope','local_only','cloud_read_requested','observed_at','currency','amount_unit','local_handoff','source_binding','channel','orders','verified_cash_cents','verified_paid_commission_cents','missing_evidence'])||value.contract!=='local_business_reconciliation_v1'||value.read_only!==true||value.storage_scope!=='local_bridge_company_server_ledger'||value.local_only!==false||value.cloud_read_requested!==true||falseFlags.some(field=>value[field]!==false)||value.currency!==null||value.amount_unit!=='legacy_cents'||value.verified_cash_cents!==null||value.verified_paid_commission_cents!==null||!integer(value.observed_at))throw Error('公司账本的来源或财务状态未通过核对。');
  const local=value.local_handoff,channel=value.channel,orders=value.orders,source=value.source_binding;
  if(!exact(local,['handoff_id','revision','status'])||local.handoff_id!==request.handoff_id||!localId(local.handoff_id)||!integer(local.revision)||!safeText(local.status)||!exact(source,['status','local_integrity','platform_provenance_verified'])||source.status!=='matched'||source.local_integrity!=='ok'||source.platform_provenance_verified!==false||!exact(channel,['channel_id','revision','status','current_consent_valid','eligible_for_delivery','historical_resource_receipt_recorded','receipt_evidence_independently_verified','attribution_status'])||channel.channel_id!==request.channel_id||!channelId(channel.channel_id)||!integer(channel.revision)||!safeText(channel.status)||!bool(channel.current_consent_valid)||!bool(channel.eligible_for_delivery)||!bool(channel.historical_resource_receipt_recorded)||channel.receipt_evidence_independently_verified!==false||!safeText(channel.attribution_status))throw Error('返回记录未对应当前本机来源与公司交接编号。');
  if(!exact(orders,['items','total_linked','offset','limit','has_more'])||!Array.isArray(orders.items)||!integer(orders.total_linked)||orders.offset!==request.offset||orders.limit!==request.limit||!integer(orders.offset)||!integer(orders.limit)||orders.limit<1||orders.limit>15||orders.items.length!==Math.max(0,Math.min(orders.limit,orders.total_linked-orders.offset))||orders.has_more!==(orders.offset+orders.items.length<orders.total_linked))throw Error('订单分页未通过核对，请重新读取。');
  if(!evidence(value.missing_evidence))throw Error('经营证据摘要未通过核对。');
  const seen=new Set();
  for(const item of orders.items){
    if(!exact(item,orderFields)||!safeText(item.order_no)||seen.has(item.order_no)||!bindingStates.includes(item.binding_state)||!['pending','confirmed','rejected','unknown'].includes(item.status)||!integer(item.linked_revision)||item.current_revision!==null&&!integer(item.current_revision)||!nullableBool(item.link_revision_current)||!bool(item.admin_review_recorded)||!nullableBool(item.distinct_review_actor_recorded)||!bool(item.calculation_policy_snapshot_available)||!nullableBool(item.calculation_policy_current)||item.calculation_policy_revision!==null&&!integer(item.calculation_policy_revision)||!safeText(item.calculation_status)||['reported_by','last_edited_by','reviewed_by'].some(field=>item[field]!==null&&!safeText(item[field]))||['reported_amount_cents','reported_refund_cents','reported_net_cents','recorded_calculated_commission_cents'].some(field=>!amount(item[field]))||item.verified_cash_cents!==null||item.verified_paid_commission_cents!==null||item.financial_receipt_verified!==false||item.cooperation_policy_verified!==false||!evidence(item.missing_evidence))throw Error('订单或历史计算记录未通过核对。');
    seen.add(item.order_no);
    if(!['matched','link_revision_changed'].includes(item.binding_state)&&['reported_amount_cents','reported_refund_cents','reported_net_cents','recorded_calculated_commission_cents'].some(field=>item[field]!==null))throw Error('订单对应关系有疑点，金额不能展示。');
    const reported=['reported_amount_cents','reported_refund_cents','reported_net_cents'].map(field=>item[field]);
    if(reported.some(value=>value===null)&&reported.some(value=>value!==null)||item.reported_amount_cents!==null&&(item.reported_refund_cents>item.reported_amount_cents||item.reported_net_cents!==item.reported_amount_cents-item.reported_refund_cents))throw Error('订单报录净额未通过核对。');
    if(item.recorded_calculated_commission_cents!==null&&!item.calculation_policy_snapshot_available)throw Error('历史分成缺少当时的政策版本。');
  }
  return value;
}

const bindingLabels={matched:'记录对应',link_revision_changed:'订单版本已变化',source_missing:'来源记录缺失',source_conflict:'来源记录冲突',customer_conflict:'客户对应冲突',order_missing:'订单尚未找到',reverse_link_conflict:'订单交接对应冲突',history_missing:'历史版本缺失',history_conflict:'历史版本冲突',record_invalid:'记录格式待核对'};
const statusLabels={pending:'待公司核对',confirmed:'管理员已登记确认',rejected:'管理员已登记拒绝',unknown:'状态待核对'};

const candidateEvidence=['exact_local_handoff_mapping_not_integrated',...baseEvidence];
const cursor=value=>value===null||typeof value==='string'&&/^[A-Za-z0-9_-]{1,1800}$/.test(value);
const channelStates=['draft','submitted','accepted','rejected','needs_information','duplicate_pending_review','existing_customer_pending_review','withdrawn','disputed'];
const attributionStates=['unconfirmed','duplicate_pending_review','existing_customer_pending_review','disputed','withdrawn_pending_review'];
const channelLabels={draft:'待提交',submitted:'已提交',accepted:'公司登记已接收',rejected:'公司登记未接收',needs_information:'待补资料',duplicate_pending_review:'重复线索待核对',existing_customer_pending_review:'已有客户待核对',withdrawn:'授权已撤回',disputed:'归属有争议'};

export function checkedBusinessChannelCandidates(value,request){
  const invalid=()=>{throw Error('来源候选的范围或证据状态未通过核对，请重新查找。');};
  if(!exact(value,[...falseFlags,'contract','read_only','storage_scope','local_only','cloud_read_requested','observed_at','state','local_handoff','source_window','source_results','scan','items','next_cursor','older_sources_cursor','verified_cash_cents','verified_paid_commission_cents','missing_evidence'])||value.contract!=='local_business_channel_candidates_v1'||value.read_only!==true||value.storage_scope!=='local_bridge_company_server_ledger'||value.local_only!==false||falseFlags.some(field=>value[field]!==false)||value.verified_cash_cents!==null||value.verified_paid_commission_cents!==null||!['no_local_sources','no_cloud_sources','index_unavailable','partial','complete'].includes(value.state))invalid();
  const local=value.local_handoff,window=value.source_window,source=value.source_results,scan=value.scan;
  if(!exact(local,['id','revision','status'])||!localId(local.id)||local.id!==request.handoff_id||!integer(local.revision)||local.revision<1||!safeText(local.status)||!exact(window,['event_count','acked_event_count','unacked_event_count','has_older_local_events','has_newer_local_events'])||['event_count','acked_event_count','unacked_event_count'].some(field=>!integer(window[field]))||window.event_count>5||window.acked_event_count+window.unacked_event_count!==window.event_count||!bool(window.has_older_local_events)||!bool(window.has_newer_local_events)||!exact(source,['recorded_count','not_recorded_count'])||!integer(source.recorded_count)||!integer(source.not_recorded_count)||source.recorded_count+source.not_recorded_count!==window.event_count)invalid();
  if(!exact(scan,['status','scanned_count','owned_index_count','complete'])||!integer(scan.scanned_count)||scan.scanned_count>10||scan.owned_index_count!==null&&!integer(scan.owned_index_count)||!bool(scan.complete)||scan.status!==(value.state==='no_local_sources'?'not_requested':value.state)||scan.complete!==(value.state==='complete')||!Array.isArray(value.items)||value.items.length>Math.min(5,scan.scanned_count)||!cursor(value.next_cursor)||!cursor(value.older_sources_cursor)||(value.next_cursor!==null)!==(value.state==='partial')||(value.older_sources_cursor!==null)!==window.has_older_local_events)invalid();
  if(value.state==='no_local_sources'){
    if(value.cloud_read_requested!==false||value.observed_at!==null||window.event_count!==0||window.has_older_local_events||window.has_newer_local_events||scan.scanned_count!==0||scan.owned_index_count!==null)invalid();
  }else if(value.cloud_read_requested!==true||!integer(value.observed_at)||value.observed_at<1577836800||window.event_count<1)invalid();
  if(['partial','complete'].includes(value.state)){
    if(source.recorded_count<1||scan.owned_index_count===null||scan.scanned_count>scan.owned_index_count||value.state==='partial'&&(scan.scanned_count===0||scan.scanned_count>=scan.owned_index_count))invalid();
  }else if(scan.scanned_count!==0||scan.owned_index_count!==null||value.items.length||value.state==='no_cloud_sources'&&source.recorded_count!==0||value.state==='index_unavailable'&&source.recorded_count<1)invalid();
  if(!Array.isArray(value.missing_evidence)||value.missing_evidence.length!==4||new Set(value.missing_evidence).size!==4||candidateEvidence.some(code=>!value.missing_evidence.includes(code)))invalid();
  const seen=new Set();
  for(const item of value.items){
    if(!exact(item,['channel_id','revision','status','recipient_name','created_at','updated_at','current_consent_valid','eligible_for_delivery','historical_resource_receipt_recorded','receipt_evidence_independently_verified','attribution_status','source_binding'])||!channelId(item.channel_id)||seen.has(item.channel_id)||!integer(item.revision)||item.revision<1||!channelStates.includes(item.status)||!attributionStates.includes(item.attribution_status)||!safeText(item.recipient_name)||item.recipient_name.length>100||!integer(item.created_at)||item.created_at<1577836800||!integer(item.updated_at)||item.updated_at<item.created_at||['current_consent_valid','eligible_for_delivery','historical_resource_receipt_recorded'].some(field=>!bool(item[field]))||item.eligible_for_delivery&&!item.current_consent_valid||item.receipt_evidence_independently_verified!==false||!exact(item.source_binding,['status','local_integrity','platform_provenance_verified'])||item.source_binding.status!=='matched'||item.source_binding.local_integrity!=='ok'||item.source_binding.platform_provenance_verified!==false)invalid();
    seen.add(item.channel_id);
  }
  return value;
}

export function createBusinessReconciliationUI({createDialog,read,scope}){
  let generation=0,active=null,disposed=false;
  const clear=()=>{generation++;if(active){for(const input of active.root.querySelectorAll('input'))input.value='';active.root.replaceChildren();active.root.close?.();active.root.remove();active=null;}};
  async function open({handoffId,channelId:initialChannel=''}={}){
    if(disposed)return;clear();const own=++generation,principal=scope(),view=createDialog('经营结果核对');active=view;let epoch=0;
    const current=()=>!disposed&&generation===own&&active===view&&view.current()&&scope()===principal;
    const report=(text,error=false)=>{if(current()){view.status.textContent=text;view.status.dataset.state=error?'error':'ready';}};
    view.root.append(node('p','先从本机来源查找有权读取的公司交接，再选择一条核对订单。来源匹配不会确认本机交接已送达，也不会确认客户实收或分成到账。','upgrade-muted'));
    const find=node('button','查找对应公司交接','primary');find.type='button';view.root.append(find);
    const candidates=node('section');view.root.append(candidates);
    const advanced=node('details');advanced.append(node('summary','高级核对 · 已有公司交接编号'));view.root.append(advanced);advanced.open=Boolean(initialChannel);
    const form=node('form','','upgrade-operation-form'),label=node('label','公司交接编号'),input=node('input'),control=node('button','核对公司账本','primary');
    input.type='text';input.autocomplete='off';input.maxLength=67;input.placeholder='填写公司账本中的交接编号';input.value=initialChannel;input.setAttribute('aria-label','公司交接编号');label.append(input);control.type='submit';form.append(label,control);advanced.append(form);
    const results=node('section');view.root.append(results);
    report('点击查找时才读取公司记录；有编号也可展开高级核对。');
    if(!localId(handoffId)){control.disabled=true;find.disabled=true;report('请从有权读取的本机交接明细进入经营核对。',true);return;}
    input.addEventListener('input',()=>{epoch++;results.replaceChildren();candidates.replaceChildren();control.disabled=false;find.disabled=false;report('编号已变化，请重新核对。');});
    find.onclick=()=>void discover();
    form.addEventListener('submit',event=>{event.preventDefault();const id=input.value.trim();if(!channelId(id)){report('请填写有效的公司交接编号。',true);return;}void load(id,0);});
    async function load(id,offset){
      if(!current())return;const ticket=++epoch,fresh=()=>current()&&ticket===epoch,request={handoff_id:handoffId,channel_id:id,offset,limit:10};
      results.replaceChildren();control.disabled=true;find.disabled=true;report('正在核对当前授权、完整来源与公司账本…');
      try{const value=await read('business_reconciliation_detail',request);if(!fresh())return;const result=checkedBusinessReconciliation(value,request);render(result,id);report('已核对来源对应的公司记录。报录、历史计算与实际到账分别保留。');}
      catch(error){if(fresh()){results.replaceChildren();report(error.message||'公司账本暂不可读，请检查授权和云连接。',true);}}
      finally{if(fresh()){control.disabled=false;find.disabled=false;}}
    }
    async function discover(pageCursor){
      if(!current())return;const ticket=++epoch,fresh=()=>current()&&ticket===epoch,request={handoff_id:handoffId};if(pageCursor)request.cursor=pageCursor;
      candidates.replaceChildren();results.replaceChildren();control.disabled=true;find.disabled=true;report('正在从本人本机完整来源查找公司交接…');
      try{const value=await read('business_reconciliation_candidates',request);if(!fresh())return;renderCandidates(checkedBusinessChannelCandidates(value,request));report('已读取当前范围；来源匹配、交接送达与财务到账仍分别核对。');}
      catch(error){if(fresh()){candidates.replaceChildren();results.replaceChildren();report(error.message||'公司交接候选暂不可读，请重新核对来源和权限。',true);}}
      finally{if(fresh()){control.disabled=false;find.disabled=false;}}
    }
    function renderCandidates(value){
      candidates.replaceChildren(node('h3','来源对应的公司交接'));
      const window=value.source_window,scan=value.scan;
      row(candidates,'本次来源范围',`${window.event_count} 条事件 · ${window.has_newer_local_events?'已切到较早来源':'从最近来源开始'}${window.has_older_local_events?'；还有更早来源未查找':''}`);
      row(candidates,'本机上传回执',`${window.acked_event_count} 条有记录，${window.unacked_event_count} 条暂无记录；回执不能证明公司交接送达`);
      if(value.state==='no_local_sources')candidates.append(node('p','当前本机交接没有可核对的来源事件。本次没有读取公司记录。','upgrade-muted'));
      else if(value.state==='no_cloud_sources')candidates.append(node('p','本次来源窗口在公司账本尚无记录；更早来源和其他公司交接尚未由本次结果排除。','upgrade-muted'));
      else if(value.state==='index_unavailable')candidates.append(node('p','公司有来源记录，但当前成员的候选索引暂不可用，尚未扫描交接。可请管理员核对记录，或使用高级核对。','upgrade-muted'));
      else{
        row(candidates,'公司交接扫描',`本次扫描 ${scan.scanned_count} 条 · 当前成员索引 ${scan.owned_index_count} 条；${scan.complete?'已到当前索引末页':'还有公司交接未扫描'}`);
        if(!value.items.length)candidates.append(node('p',scan.complete?'当前末页没有对应交接；此结果不排除其他页或更早本机来源。':'当前扫描页没有对应交接，请继续扫描。','upgrade-muted'));
      }
      for(const item of value.items){
        const card=node('section','','upgrade-operation-form');card.append(node('h4',item.recipient_name));row(card,'公司交接状态',channelLabels[item.status]);row(card,'公司登记时间',new Date(item.created_at*1000).toLocaleString('zh-CN'));
        row(card,'当前客户授权',item.current_consent_valid?'公司记录当前有效':'当前不可继续送达');row(card,'历史接收记录',item.historical_resource_receipt_recorded?'公司账本有记录，凭证尚未独立核验':'尚无公司账本接收记录');
        const button=node('button','选择并核对公司账本','secondary');button.type='button';button.onclick=()=>{input.value=item.channel_id;void load(item.channel_id,0);};card.append(button);
        const ids=node('details');ids.append(node('summary','查看公司交接编号'),node('p',item.channel_id,'upgrade-muted'));card.append(ids);candidates.append(card);
      }
      const paging=node('div','','upgrade-section-header');
      for(const [title,page]of [['继续扫描公司交接',value.next_cursor],['查找更早本机来源',value.older_sources_cursor]])if(page){const button=node('button',title,'secondary');button.type='button';button.onclick=()=>void discover(page);paging.append(button);}
      candidates.append(paging,node('p','候选只证明完整来源事件对应。尚无本机交接的权威对应回执，客户实收、分成实付和双方合作政策仍待核验。','upgrade-muted'));
    }
    function row(parent,title,value){const line=node('div','','upgrade-record-line');line.append(node('span',title),node('strong',value));parent.append(line);}
    function render(value,id){
      if(!current())return;results.replaceChildren(node('h3','来源与交接证据'));
      row(results,'来源事件','已匹配本机完整记录；平台真实性仍待验证');
      row(results,'本机交接送达','尚无本机与公司交接的权威对应回执');
      row(results,'公司当前客户授权',value.channel.current_consent_valid?'公司记录当前有效':'当前不可继续送达');
      row(results,'资源部历史接收',value.channel.historical_resource_receipt_recorded?'公司账本有接收记录，凭证未独立核验':'尚无公司账本接收记录');
      row(results,'客户实收 / 分成实付','尚未接入可独立核验的财务凭证');
      results.append(node('p','管理员确认表示已登记审核；不同操作人也不代表财务已独立核验。尚未取得双方核验的合作分成政策。','upgrade-muted'),node('h3','对应订单'));
      const orders=value.orders;
      if(!orders.items.length)results.append(node('p',orders.total_linked?'当前页没有可读取订单，请返回前一页。':'这条公司交接尚未登记对应订单。','upgrade-muted'));
      for(const item of orders.items){
        const card=node('section','','upgrade-operation-form');card.append(node('h4',`订单 ${item.order_no}`));
        row(card,'记录对应',bindingLabels[item.binding_state]);row(card,'公司审核',statusLabels[item.status]);
        row(card,'报录金额',money(item.reported_amount_cents));row(card,'报录退款',money(item.reported_refund_cents));row(card,'报录净额',money(item.reported_net_cents));
        row(card,'历史计算分成',money(item.recorded_calculated_commission_cents));
        row(card,'历史政策版本',item.calculation_policy_revision===null?'尚无可核对政策快照':`版本 ${item.calculation_policy_revision} · ${item.calculation_policy_current===null?'尚未核对当前政策':item.calculation_policy_current?'仍为账本当前版本':'与账本当前版本需核对'}`);
        row(card,'待补证据',item.missing_evidence.map(code=>evidenceLabels[code]).join('；'));
        card.append(node('p','上述报录净额没有客户实收证明；历史计算分成没有双方确认的应付或实际付款证明。','upgrade-muted'));results.append(card);
      }
      const paging=node('div','','upgrade-section-header');paging.append(node('p',`已登记对应订单 ${orders.total_linked} 条 · 本页 ${orders.items.length} 条；不跨页累计金额。`,'upgrade-muted'));
      for(const [title,offset,enabled]of [['上一页',Math.max(0,orders.offset-orders.limit),orders.offset>0],['下一页',orders.offset+orders.items.length,orders.has_more]]){const button=node('button',title,'secondary');button.type='button';button.disabled=!enabled;button.onclick=()=>void load(id,offset);paging.append(button);}results.append(paging);
      const evidence=node('details');evidence.append(node('summary','核对信息'));row(evidence,'本机交接编号',value.local_handoff.handoff_id);row(evidence,'公司交接编号',value.channel.channel_id);row(evidence,'当前读取时间',new Date(value.observed_at*1000).toLocaleString('zh-CN'));results.append(evidence);
    }
  }
  return {open,reset:clear,dispose(){disposed=true;clear();}};
}
