'use strict';
// Admin-only data management; no workspace housekeeping, network calls or automatic retries.
const {COMPANY,canonical,hash,manifestId,sourceId,authority}=require('./store_config.cjs');
const {build}=require('./rule_catalog_build.cjs');
const {createApproval}=require('./approved_research.cjs');
const {pack,readBundle,unpackBytes}=require('./rule_bundle_storage.cjs');
const crypto=require('node:crypto');
const OWNED_INPUT=Symbol('private-owned-rule-input'),approvalCache=new WeakMap();
const CANONICAL_SCHEMA='fangyu-validated-canonical-json/1';
const SCHEMA='fangyu-rule-bundle/1',MAX_BYTES=8388608,CHUNK_BYTES=98304,MAX_CHUNKS=86;
const OPS=new Set(['rule_bundle_status','rule_bundle_export_chunk','rule_bundle_import_begin','rule_bundle_import_chunk','rule_bundle_import_prepare','rule_bundle_import_commit','rule_bundle_import_status']);
const fields={rule_bundle_status:[],rule_bundle_export_chunk:['revision','index'],rule_bundle_import_begin:['requestId','expectedRevision','digest','bytes','chunkCount'],rule_bundle_import_chunk:['uploadId','index','dataBase64'],rule_bundle_import_prepare:['uploadId'],rule_bundle_import_commit:['uploadId','previewDigest'],rule_bundle_import_status:['uploadId','requestId']};
class RuleError extends Error{constructor(code,status=400,field){super(code);Object.assign(this,{code,status,field});}}
const fail=(code,status,field)=>{throw new RuleError(code,status,field);};
const ident=(kind,value)=>'rbundle_'+kind+'_'+hash(value);
const bundleId=revision=>ident('version',[COMPANY,revision]);
const uploadId=(username,requestId)=>ident('upload',[COMPANY,username,requestId]);
const chunkId=(id,index)=>ident('chunk',[id,index]);
const clean=row=>{const value=structuredClone(row);if(value)delete value._id;return value;};
const digest64=v=>typeof v==='string'&&/^[a-f0-9]{64}$/.test(v);
const revisionValid=v=>typeof v==='string'&&/^r_[a-f0-9]{32}$/.test(v);
const uploadValid=v=>typeof v==='string'&&/^rbundle_upload_[a-f0-9]{64}$/.test(v);
function admin(state,bearer,company,now){
 const auth=authority(state,bearer,company,now);
 if(auth.user.role!=='admin')fail('RULE_BUNDLE_ADMIN_REQUIRED',403);
 return auth;
}
function jsonData(value){
 let nodes=0;
 function visit(v,path,depth){
  if(++nodes>250000||depth>16)fail('RULE_BUNDLE_DATA_LIMIT',413,path);
  if(v===null||typeof v==='boolean')return;
  if(typeof v==='number'){if(!Number.isFinite(v))fail('RULE_BUNDLE_INVALID_NUMBER',400,path);return;}
  if(typeof v==='string'){if(Buffer.byteLength(v)>262144)fail('RULE_BUNDLE_STRING_LIMIT',413,path);return;}
  if(Array.isArray(v)){if(v.length>20000)fail('RULE_BUNDLE_ARRAY_LIMIT',413,path);v.forEach((x,i)=>visit(x,path+'/'+i,depth+1));return;}
  if(!v||typeof v!=='object'||Object.getPrototypeOf(v)!==Object.prototype)fail('RULE_BUNDLE_JSON_ONLY',400,path);
  for(const [key,item]of Object.entries(v)){
   if(key.length>120||['__proto__','constructor','prototype','$ref'].includes(key)
    ||/^(?:password|passwd|cookies?|authorization|access_?token|refresh_?token|api_?key|secret(?:_?key|_?id)?|private_?key|sessions?|accounts?|customers?|customer_rows|script|executable|eval|function)$/i.test(key))fail('RULE_BUNDLE_FORBIDDEN_FIELD',400,path+'/'+key);
   visit(item,path+'/'+key,depth+1);
  }
 }
 visit(value,'',0);
}
function omit(value,keys){const copy=structuredClone(value);for(const key of keys)delete copy[key];return copy;}
function same(a,b,field){if(hash(a)!==hash(b))fail('RULE_BUNDLE_PROTECTED_SOURCE_OR_STATUS',400,field);}
function text(v,field,max=2000){if(typeof v!=='string'||!v.trim()||v.length>max)fail('RULE_BUNDLE_TEXT_INVALID',400,field);}
function contentSummary(bundle){
 const stores=bundle.extensions.stores,common=bundle.extensions.common;
 return {originalKeywords:bundle.catalog.keywords.length,extensionStoreQueries:stores.reduce((n,s)=>n+(s.searchTerms||[]).length,0),
  totalDistinctQueries:new Set([...bundle.catalog.keywords.map(w=>w.keyword),...stores.flatMap(s=>(s.searchTerms||[]).map(t=>t.query))]).size,
  prompts:Array.isArray(common.prompts)?common.prompts.length:0,constraints:Array.isArray(common.constraints)?common.constraints.length:0,
  constructedExamples:Array.isArray(common.judgement_examples)?common.judgement_examples.length:0,contentVersion:common.version||bundle.version};
}
function freezeData(value){
 if(value&&typeof value==='object'&&!Object.isFrozen(value)){
  for(const key of Object.keys(value))freezeData(value[key]);Object.freeze(value);
 }
 return value;
}
function canonicalFieldChunks(key,value,limit){
 // JSON data has already passed jsonData. Do not collect one recursive string
 // per subtree: keep only a bounded scalar-token window and UTF-8 byte chunks.
 const chunks=[];let tokens=[],characters=0,bytes=0;
 const flush=()=>{
  if(!tokens.length)return;
  const part=Buffer.from(tokens.join(''),'utf8');bytes+=part.length;
  if(bytes>limit)fail('RULE_BUNDLE_NORMALIZED_SIZE_LIMIT',413);
  chunks.push(part);tokens=[];characters=0;
 };
 const emit=text=>{tokens.push(text);characters+=text.length;if(characters>=32768)flush();};
 const visit=node=>{
  if(Array.isArray(node)){
   emit('[');for(let i=0;i<node.length;i++){if(i)emit(',');visit(node[i]);}emit(']');
  }else if(node&&typeof node==='object'){
   emit('{');let index=0;
   for(const name of Object.keys(node).sort()){
    if(node[name]===undefined)continue;
    if(index++)emit(',');emit(JSON.stringify(name));emit(':');visit(node[name]);
   }
   emit('}');
  }else emit(JSON.stringify(node));
 };
 // Whole scalar tokens keep surrogate pairs intact at every flush boundary.
 emit(JSON.stringify(key));emit(':');visit(value);flush();return {chunks,bytes};
}
function canonicalBundleBytes(bundle){
 const fields=[];let bodyBytes=0;
 for(const key of Object.keys(bundle).filter(k=>k!=='digest'&&bundle[k]!==undefined).sort()){
  const field=canonicalFieldChunks(key,bundle[key],MAX_BYTES-bodyBytes);bodyBytes+=field.bytes;fields.push({key,...field});
 }
 const digester=crypto.createHash('sha256');digester.update('{');
 fields.forEach((field,index)=>{if(index)digester.update(',');for(const part of field.chunks)digester.update(part);});digester.update('}');
 const digest=digester.digest('hex'),digestPart=Buffer.from('"digest":'+JSON.stringify(digest));
 fields.push({key:'digest',chunks:[digestPart],bytes:digestPart.length});fields.sort((a,b)=>a.key<b.key?-1:a.key>b.key?1:0);
 const size=bodyBytes+digestPart.length+fields.length-1+2;
 if(size>MAX_BYTES)fail('RULE_BUNDLE_NORMALIZED_SIZE_LIMIT',413);
 const parts=[Buffer.from('{')];fields.forEach((field,index)=>{if(index)parts.push(Buffer.from(','));parts.push(...field.chunks);});parts.push(Buffer.from('}'));
 return {digest,bytes:Buffer.concat(parts,size)};
}
function validateBundle(input,base,ownership){
 jsonData(input);
 if(!input||input.schema_version!==SCHEMA||input.company_id!==COMPANY)fail('RULE_BUNDLE_COMPANY_OR_SCHEMA_INVALID',400,'company_id');
 if(Object.keys(input).some(k=>!['schema_version','company_id','version','catalog','extensions','digest'].includes(k)))fail('RULE_BUNDLE_UNSUPPORTED_FIELD');
 text(input.version,'version',200);
 const source=input.catalog;
 if(!source||source.schema_version!=='fangyu-store-materials-catalog/1'||!Array.isArray(source.materials)||!Array.isArray(source.keywords))fail('RULE_BUNDLE_CATALOG_INVALID');
 // Source claims and safety states cannot be laundered by editing a JSON file.
 // Existing text can be maintained; new candidate material belongs in extensions.
 same(omit(source,['digest','version','ruleVersion','materials','keywords','intentRule','rulesSummary']),omit(base,['digest','version','ruleVersion','materials','keywords','intentRule','rulesSummary']),'catalog/provenance');
 if(source.materials.length!==base.materials.length||source.keywords.length!==base.keywords.length)fail('RULE_BUNDLE_USE_EXTENSIONS_FOR_NEW_CANDIDATES',400,'catalog');
 source.materials.forEach((row,i)=>{
  same(omit(row,['name','aliases']),omit(base.materials[i],['name','aliases']),'catalog/materials/'+i);
  text(row.name,'catalog/materials/'+i+'/name',300);
  if(!Array.isArray(row.aliases)||row.aliases.length>100||row.aliases.some(v=>typeof v!=='string'||v.length>300))fail('RULE_BUNDLE_TEXT_INVALID',400,'catalog/materials/'+i+'/aliases');
 });
 source.keywords.forEach((row,i)=>{
  same(omit(row,['keyword','priority']),omit(base.keywords[i],['keyword','priority']),'catalog/keywords/'+i);
  text(row.keyword,'catalog/keywords/'+i+'/keyword',500);
  if(!Number.isInteger(row.priority)||row.priority<0||row.priority>100)fail('RULE_BUNDLE_PRIORITY_INVALID',400,'catalog/keywords/'+i+'/priority');
 });
 const mutable=['version','description','signals','budgetPrinciples','incomePrinciples'];
 same(omit(source.intentRule||{},mutable),omit(base.intentRule,mutable),'catalog/intentRule/status');
 text(source.intentRule.description,'catalog/intentRule/description',5000);
 for(const key of ['signals','budgetPrinciples','incomePrinciples'])if(!Array.isArray(source.intentRule[key])||source.intentRule[key].some(v=>typeof v!=='string'||v.length>5000)||source.intentRule[key].length>300)fail('RULE_BUNDLE_TEXT_INVALID',400,'catalog/intentRule/'+key);
 text(source.version,'catalog/version',200);text(source.ruleVersion,'catalog/ruleVersion',200);text(source.intentRule.version,'catalog/intentRule/version',200);
 if(!source.rulesSummary||typeof source.rulesSummary!=='object'||Array.isArray(source.rulesSummary))fail('RULE_BUNDLE_RULE_SUMMARY_INVALID');
 same(omit(source.rulesSummary,['version']),omit(base.rulesSummary,['version']),'catalog/rulesSummary/status');
 const ext=input.extensions;
 if(!ext||Array.isArray(ext)||typeof ext!=='object'||Object.keys(ext).some(k=>!['stores','common'].includes(k))||!Array.isArray(ext.stores)||ext.stores.length>source.materials.length||!ext.common||Array.isArray(ext.common)||typeof ext.common!=='object')fail('RULE_BUNDLE_EXTENSIONS_INVALID');
 const seen=new Set(),keys=new Set(source.materials.map(m=>m.key));
 ext.stores.forEach((row,i)=>{
  if(!row||Array.isArray(row)||typeof row!=='object'||!keys.has(row.material_key)||seen.has(row.material_key)||Object.keys(row).some(k=>!['material_key','searchTerms','excludeTerms','prompts','judgement','evidence'].includes(k)))fail('RULE_BUNDLE_MATERIAL_REFERENCE_INVALID',400,'extensions/stores/'+i);
  seen.add(row.material_key);
  for(const k of ['searchTerms','excludeTerms','prompts','judgement','evidence'])if(row[k]!==undefined&&(row[k]===null||!['object','string'].includes(typeof row[k])))fail('RULE_BUNDLE_EXTENSION_TYPE_INVALID',400,'extensions/stores/'+i+'/'+k);
  const prefix='extensions/stores/'+i,material=source.materials.find(m=>m.key===row.material_key),refs=new Set(material.sourceRefs),evidenceRefs=new Set();
  if(row.evidence!==undefined){
   if(!Array.isArray(row.evidence)||row.evidence.length>1000)fail('RULE_BUNDLE_EVIDENCE_INVALID',400,prefix+'/evidence');
   row.evidence.forEach((e,j)=>{
    const p=prefix+'/evidence/'+j;
    if(!e||typeof e!=='object'||Array.isArray(e)||typeof e.sourceRef!=='string'||!e.sourceRef||e.sourceRef.length>200||evidenceRefs.has(e.sourceRef)||refs.has(e.sourceRef)||!['verified','candidate'].includes(e.status))fail('RULE_BUNDLE_EVIDENCE_INVALID',400,p);
    text(e.title,p+'/title',1000);text(e.url,p+'/url',2000);
    let url;try{url=new URL(e.url);}catch{fail('RULE_BUNDLE_EVIDENCE_URL_INVALID',400,p+'/url');}
    if(!['https:','http:'].includes(url.protocol)||url.username||url.password)fail('RULE_BUNDLE_EVIDENCE_URL_INVALID',400,p+'/url');
    if(typeof e.checkedAt!=='string'||!/^\d{4}-\d{2}-\d{2}(?:T\d{2}:\d{2}:\d{2}(?:\.\d{1,3})?(?:Z|[+-]\d{2}:\d{2}))?$/.test(e.checkedAt)||!Number.isFinite(Date.parse(e.checkedAt)))fail('RULE_BUNDLE_EVIDENCE_DATE_INVALID',400,p+'/checkedAt');
    evidenceRefs.add(e.sourceRef);if(e.status==='verified')refs.add(e.sourceRef);
   });
  }
  if(row.excludeTerms!==undefined&&(!Array.isArray(row.excludeTerms)||row.excludeTerms.length>2000||row.excludeTerms.some(v=>typeof v!=='string'||!v.trim()||v.length>500)))fail('RULE_BUNDLE_EXCLUDE_TERMS_INVALID',400,prefix+'/excludeTerms');
  if(row.searchTerms!==undefined){
   if(!Array.isArray(row.searchTerms)||row.searchTerms.length>10000)fail('RULE_BUNDLE_SEARCH_TERMS_INVALID',400,prefix+'/searchTerms');
   row.searchTerms.forEach((term,j)=>{
    const p=prefix+'/searchTerms/'+j;
    if(!term||typeof term!=='object'||Array.isArray(term))fail('RULE_BUNDLE_SEARCH_TERM_INVALID',400,p);
    text(term.query,p+'/query',500);
    if(typeof term.enabled!=='boolean'||!['direct','context','exploratory'].includes(term.tier)||!['verified','candidate','held','blocked'].includes(term.evidence_status)||!Array.isArray(term.sourceRefs)||term.sourceRefs.length>100||term.sourceRefs.some(ref=>typeof ref!=='string'||ref.length>200))fail('RULE_BUNDLE_SEARCH_TERM_INVALID',400,p);
    if(term.enabled&&(term.evidence_status!=='verified'||!term.sourceRefs.length||term.sourceRefs.some(ref=>!refs.has(ref))))fail('RULE_BUNDLE_TERM_ENABLE_REQUIRES_VERIFIED_SOURCE',400,p);
   });
  }
 });
 let approval;try{approval=createApproval(input);}catch{fail('RULE_BUNDLE_RUNTIME_POLICY_INVALID',400,'extensions/common/runtimePolicy');}
 const warnings=[...approval.warnings],bundle=ownership===OWNED_INPUT?{...input,catalog:{...input.catalog}}:structuredClone(input),oldCatalogDigest=bundle.catalog.digest,oldDigest=bundle.digest;
 delete bundle.catalog.digest;bundle.catalog.digest=hash(bundle.catalog);
 if(oldCatalogDigest!==bundle.catalog.digest)warnings.push('CATALOG_DIGEST_RECOMPUTED_ADMIN_MODIFIED');
 const encoded=canonicalBundleBytes(bundle);bundle.digest=encoded.digest;
 if(oldDigest!==bundle.digest)warnings.push('INTERNAL_DIGEST_RECOMPUTED_ADMIN_MODIFIED');
 const bytes=encoded.bytes;if(bytes.length>MAX_BYTES)fail('RULE_BUNDLE_NORMALIZED_SIZE_LIMIT',413);
 const terms=ext.stores.flatMap(row=>row.searchTerms||[]);
 const summary={stores:source.materials.length,keywords:source.keywords.length,eligible:source.keywords.filter(w=>w.csvCandidateEligible===true).length,held:source.keywords.filter(w=>w.csvCandidateEligible!==true).length,extensionStores:ext.stores.length,extensionQueries:terms.length,runtimeQueries:terms.filter(t=>t.enabled&&t.evidence_status==='verified').length,candidateQueries:terms.filter(t=>!t.enabled).length,catalogChanged:hash(omit(source,['digest']))!==hash(omit(base,['digest'])),rulesEnabled:source.intentRule.enabled===true,pricesVerified:source.intentRule.currentPricesVerified===true};
 summary.runtimeHypotheses=ext.stores.reduce((n,s)=>n+(s.searchTerms||[]).filter(t=>approval.hypothesis(t,s.material_key)).length,0);
 summary.runtimeQueries=ext.stores.reduce((n,s)=>n+new Set((s.searchTerms||[])
  .filter(t=>approval.hypothesis(t,s.material_key)||t.enabled&&t.evidence_status==='verified').map(t=>t.query)).size,0);
 summary.assessmentPolicy=approval.assessmentPolicy;
 Object.assign(summary,contentSummary(bundle));
 const prepared={bundle,bytes,warnings,summary,previewDigest:bundle.digest};
 if(ownership===OWNED_INPUT){
  // Only private parsed inputs can alias; the entire owned graph is immutable.
  // The public exported validator still deep-clones and returns writable data.
  freezeData(bundle);
  approvalCache.set(prepared,{approval,bundle,previewDigest:prepared.previewDigest,bytesDigest:hash(bytes)});
 }
 return prepared;
}
function initialBundle(catalog){const body={schema_version:SCHEMA,company_id:COMPANY,version:catalog.version,catalog:structuredClone(catalog),extensions:{stores:[],common:{}}};return {...body,digest:hash(body)};}
function compile(prepared){
 const compiled=build(Buffer.from(canonical(prepared.bundle.catalog)),prepared.previewDigest);
 const cached=approvalCache.get(prepared);approvalCache.delete(prepared);
 if(cached&&(cached.bundle!==prepared.bundle||cached.previewDigest!==prepared.previewDigest
   ||!Object.isFrozen(prepared.bundle)||hash(prepared.bytes)!==cached.bytesDigest))fail('RULE_BUNDLE_PREVIEW_CHANGED',409);
 const approval=cached?cached.approval:createApproval(prepared.bundle);
 for(const doc of compiled.documents.filter(d=>d.doc_type==='store_config_version')){
  const ext=prepared.bundle.extensions.stores.find(row=>row.material_key===doc.config.material_key);
  const hypotheses=(ext?.searchTerms||[]).map(t=>approval.hypothesis(t,doc.config.material_key)).filter(Boolean);
  const verified=(ext?.searchTerms||[]).filter(t=>t.enabled&&t.evidence_status==='verified')
   .map(({query,tier,sourceRefs})=>({query,tier,sourceRefs:structuredClone(sourceRefs),source:'explicit_verified_search_input'}));
  const seen=new Set(),queries=[...hypotheses,...verified].filter(t=>!seen.has(t.query)&&seen.add(t.query));
  doc.config.runtimeSearch={schema:'fangyu-runtime-search/1',revision:compiled.manifest.active_revision,material_key:doc.config.material_key,
   queries,excludeTerms:[],analysisExclusionContextAvailable:!!ext?.excludeTerms?.length,
   commentFilterMode:'all',policy:'approved_source_hypotheses_not_merchant_or_intent_facts',
   sourceBundleDigest:prepared.previewDigest};
  doc.config.runtimeAssessment={...approval.assessmentPolicy,bundleRevision:compiled.manifest.active_revision};
  if(approval.assessment)doc.config.evaluator_version=approval.assessmentPolicy.engineVersion;
  compiled.manifest.stores.find(s=>s.id===doc.store_id).config_digest=hash(doc.config);
 }
 compiled.manifest.catalog_digest=hash({revision:compiled.manifest.active_revision,stores:compiled.manifest.stores});
 compiled.manifest.runtimeSummary={...contentSummary(prepared.bundle),runtimeHypotheses:prepared.summary.runtimeHypotheses,
  assessmentPolicy:approval.assessmentPolicy};
 return compiled;
}
function createRuleBundleRoutes({store,companyId,environmentId,clock=Date.now}){
 const now=()=>Math.floor(clock()/1000);
 async function active(io){
  const manifest=await io.get(manifestId(companyId));
  if(!manifest||manifest.companyId!==companyId||manifest.doc_type!=='store_config_manifest'||!revisionValid(manifest.active_revision)||manifest.disabled)fail('RULE_BUNDLE_UNAVAILABLE',503);
  const src=await io.get(sourceId(companyId,manifest.active_revision));
  if(!src||src.companyId!==companyId||src.doc_type!=='store_config_source'||src.revision!==manifest.active_revision||!src.catalog)fail('RULE_BUNDLE_SOURCE_UNAVAILABLE',503);
  const saved=manifest.rule_bundle_revision?await io.get(bundleId(manifest.active_revision)):null;
  if(manifest.rule_bundle_revision&&(!saved||saved.companyId!==companyId||saved.revision!==manifest.active_revision||saved.doc_type!=='rule_bundle_version'||saved.digest!==manifest.rule_bundle_digest))fail('RULE_BUNDLE_UNAVAILABLE',503);
  if(saved?.canonical_json!==undefined){
   const marker=saved.canonical_json;
   if(!saved.bundle_storage||saved.bundle||!marker||Object.getPrototypeOf(marker)!==Object.prototype
     ||Object.keys(marker).sort().join(',')!=='bytes,digest,schema,summaryDigest'
     ||marker.schema!==CANONICAL_SCHEMA||marker.digest!==saved.digest
     ||!Number.isInteger(marker.bytes)||marker.bytes<2||marker.bytes>MAX_BYTES
     ||!saved.summary||Object.getPrototypeOf(saved.summary)!==Object.prototype
     ||!digest64(marker.summaryDigest)||marker.summaryDigest!==manifest.rule_bundle_summary_digest
     ||hash(saved.summary)!==marker.summaryDigest)fail('RULE_BUNDLE_UNAVAILABLE',503);
   // This capsule is minted only below from validated canonical prepared.bytes,
   // never from upload fields. Both raw digest and summary digest are pinned by
   // the active manifest. Old packed/raw rows retain the parsing path below.
   const bytes=unpackBytes(saved.bundle_storage);
   if(bytes.length!==marker.bytes||hash(bytes)!==saved.digest)fail('RULE_BUNDLE_UNAVAILABLE',503);
   return {manifest,source:src.catalog,bytes,digest:saved.digest,revision:manifest.active_revision,summary:structuredClone(saved.summary)};
  }
  const bundle=saved?readBundle(saved):initialBundle(src.catalog),bytes=Buffer.from(canonical(bundle),'utf8');
  if(saved&&hash(bytes)!==saved.digest)fail('RULE_BUNDLE_UNAVAILABLE',503);
  return {manifest,source:src.catalog,bundle,bytes,digest:hash(bytes),revision:manifest.active_revision,summary:{...manifest.counts,...manifest.runtimeSummary,...contentSummary(bundle),extensionStores:bundle.extensions.stores.length,rulesEnabled:src.catalog.intentRule.enabled===true,pricesVerified:src.catalog.intentRule.currentPricesVerified===true}};
 }
 const readIO={get:id=>store.readRuleBundleDocument(id)};
 async function upload(io,id,auth){
  const row=await io.get(id);
  if(!row||row.doc_type!=='rule_bundle_upload'||row.companyId!==companyId||row.username!==auth.user.username)fail('RULE_BUNDLE_UPLOAD_NOT_FOUND',404);
  if(row.state!=='committed'&&row.expires<=now())fail('RULE_BUNDLE_UPLOAD_EXPIRED',410);
  return row;
 }
 async function assemble(io,row){
  const chunks=[];
  for(let i=0;i<row.chunkCount;i++){
   const part=await io.get(chunkId(row._id,i));
   if(!part||part.companyId!==companyId||part.uploadId!==row._id||part.index!==i)fail('RULE_BUNDLE_CHUNKS_INCOMPLETE',409);
   chunks.push(Buffer.from(part.dataBase64,'base64'));
  }
  const bytes=Buffer.concat(chunks);
  if(bytes.length!==row.bytes||hash(bytes)!==row.digest)fail('RULE_BUNDLE_TRANSPORT_DIGEST_MISMATCH',400);
  const string=bytes.toString('utf8');if(!Buffer.from(string,'utf8').equals(bytes))fail('RULE_BUNDLE_UTF8_INVALID',400);
  try{return JSON.parse(string);}catch{fail('RULE_BUNDLE_JSON_INVALID',400);}
 }
 return async function handle(payload,bearer){
  const flags={schema:SCHEMA,read_only:true,mutation_committed:false,auto_retry:false};
  try{
   if(companyId!==COMPANY||payload.environment_id!==environmentId||!OPS.has(payload.operation))fail('RULE_BUNDLE_REQUEST_INVALID',400);
   if(Object.keys(payload).some(k=>!['operation','environment_id',...fields[payload.operation]].includes(k)))fail('RULE_BUNDLE_REQUEST_INVALID',400);
   if(typeof store.readRuleBundleDocument!=='function'||typeof store.ruleBundleTransaction!=='function')fail('RULE_BUNDLE_STORAGE_UNAVAILABLE',503);
   const first=admin(await store.readStoreConfigState(),bearer,companyId,now());
   let result;
   if(['rule_bundle_status','rule_bundle_export_chunk'].includes(payload.operation)){
    const current=await active(readIO);
    result={revision:current.revision,digest:current.digest,bytes:current.bytes.length,chunkCount:Math.ceil(current.bytes.length/CHUNK_BYTES),summary:current.summary,state:'active'};
    if(payload.operation==='rule_bundle_export_chunk'){
     if(payload.revision!==current.revision)fail('RULE_BUNDLE_REVISION_CONFLICT',409);
     if(!Number.isInteger(payload.index)||payload.index<0||payload.index>=result.chunkCount)fail('RULE_BUNDLE_CHUNK_INDEX_INVALID');
     result.index=payload.index;result.dataBase64=current.bytes.subarray(payload.index*CHUNK_BYTES,(payload.index+1)*CHUNK_BYTES).toString('base64');
    }
    const last=admin(await store.readStoreConfigState(),bearer,companyId,now());
    if(last.fingerprint!==first.fingerprint)fail('RULE_BUNDLE_AUTHORITY_CHANGED',403);
    const latest=await readIO.get(manifestId(companyId));if(latest?.active_revision!==current.revision||latest?.catalog_digest!==current.manifest.catalog_digest)fail('RULE_BUNDLE_REVISION_CONFLICT',409);
   }else{
    result=await store.ruleBundleTransaction(async io=>{
     const txState=await io.state(),auth=admin(txState,bearer,companyId,now()),rawIO=io;
     io={...io,set:async(...args)=>{admin(txState,bearer,companyId,now());return rawIO.set(...args);}};
     if(auth.fingerprint!==first.fingerprint)fail('RULE_BUNDLE_AUTHORITY_CHANGED',403);
     const op=payload.operation;
     if(op==='rule_bundle_import_begin'){
      if(typeof payload.requestId!=='string'||!/^[A-Za-z0-9_-]{8,100}$/.test(payload.requestId)||!revisionValid(payload.expectedRevision)||!digest64(payload.digest)||!Number.isInteger(payload.bytes)||payload.bytes<2||payload.bytes>MAX_BYTES||!Number.isInteger(payload.chunkCount)||payload.chunkCount!==Math.ceil(payload.bytes/CHUNK_BYTES)||payload.chunkCount>MAX_CHUNKS)fail('RULE_BUNDLE_UPLOAD_METADATA_INVALID');
      const id=uploadId(auth.user.username,payload.requestId),old=await io.get(id);
      if(old){const own=await upload(io,id,auth);if(['digest','bytes','chunkCount','expectedRevision'].some(k=>own[k]!==payload[k]))fail('RULE_BUNDLE_REQUEST_ID_CONFLICT',409);return {uploadId:id,requestId:own.requestId,state:own.state};}
      const current=await io.get(manifestId(companyId));if(current?.active_revision!==payload.expectedRevision)fail('RULE_BUNDLE_REVISION_CONFLICT',409);
      const row={_id:id,doc_type:'rule_bundle_upload',companyId,username:auth.user.username,requestId:payload.requestId,expectedRevision:payload.expectedRevision,digest:payload.digest,bytes:payload.bytes,chunkCount:payload.chunkCount,receivedIndices:[],state:'uploading',created:now(),expires:now()+86400};
      await io.set(id,row);return {uploadId:id,requestId:row.requestId,state:row.state};
     }
     let id=payload.uploadId;
     if(op==='rule_bundle_import_status'){
      if((payload.uploadId!==undefined)===(payload.requestId!==undefined))fail('RULE_BUNDLE_STATUS_REFERENCE_INVALID');
      if(payload.requestId!==undefined){
       if(typeof payload.requestId!=='string'||!/^[A-Za-z0-9_-]{8,100}$/.test(payload.requestId))fail('RULE_BUNDLE_REQUEST_ID_INVALID');
       id=uploadId(auth.user.username,payload.requestId);
       if(!await io.get(id))return {requestId:payload.requestId,state:'not_found'};
      }
     }
     if(!uploadValid(id))fail('RULE_BUNDLE_UPLOAD_ID_INVALID');
     const row=await upload(io,id,auth);
     if(op==='rule_bundle_import_status')return {uploadId:row._id,requestId:row.requestId,state:row.state,
      receivedIndices:[...(row.receivedIndices||[])],chunkCount:row.chunkCount,bytes:row.bytes,digest:row.digest,
      ...(row.receipt||{}),...(row.previewDigest?{previewDigest:row.previewDigest,summary:row.summary,warnings:row.warnings}: {})};
     if(op==='rule_bundle_import_chunk'){
      if(row.state!=='uploading')fail('RULE_BUNDLE_UPLOAD_STATE_CONFLICT',409);
      const index=payload.index,encoded=payload.dataBase64;
      if(!Number.isInteger(index)||index<0||index>=row.chunkCount||typeof encoded!=='string'||encoded.length>Math.ceil(CHUNK_BYTES/3)*4||!/^([A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(encoded))fail('RULE_BUNDLE_CHUNK_INVALID');
      const part=Buffer.from(encoded,'base64'),expected=index===row.chunkCount-1?row.bytes-index*CHUNK_BYTES:CHUNK_BYTES;
      if(part.toString('base64')!==encoded||part.length!==expected)fail('RULE_BUNDLE_CHUNK_LENGTH_INVALID');
      const id=chunkId(row._id,index),old=await io.get(id);
      if(old&&old.dataBase64!==encoded)fail('RULE_BUNDLE_DUPLICATE_CHUNK_CONFLICT',409);
      if(!old)await io.set(id,{_id:id,doc_type:'rule_bundle_chunk',companyId,uploadId:row._id,index,dataBase64:encoded});
      if(!(row.receivedIndices||[]).includes(index))await io.set(row._id,{...row,
       receivedIndices:[...(row.receivedIndices||[]),index].sort((a,b)=>a-b)});
      return {uploadId:row._id,index,state:row.state};
     }
     if(op==='rule_bundle_import_prepare'){
      if(row.state==='committed')fail('RULE_BUNDLE_UPLOAD_STATE_CONFLICT',409);
      const current=await active(io);if(current.revision!==row.expectedRevision)fail('RULE_BUNDLE_REVISION_CONFLICT',409);
      const prepared=validateBundle(await assemble(io,row),current.source,OWNED_INPUT);
      const updated={...row,state:'prepared',previewDigest:prepared.previewDigest,bundle_storage:pack(prepared.bytes),summary:prepared.summary,warnings:prepared.warnings};
      delete updated.bundle;
      approvalCache.delete(prepared);await io.set(row._id,updated);
      return {uploadId:row._id,previewDigest:prepared.previewDigest,summary:prepared.summary,warnings:prepared.warnings,state:'prepared'};
     }
     if(op==='rule_bundle_import_commit'){
      if(!digest64(payload.previewDigest))fail('RULE_BUNDLE_PREVIEW_DIGEST_INVALID');
      if(row.state==='committed'){if(row.previewDigest!==payload.previewDigest)fail('RULE_BUNDLE_PREVIEW_CHANGED',409);return row.receipt;}
      if(row.state!=='prepared'||row.previewDigest!==payload.previewDigest)fail('RULE_BUNDLE_PREVIEW_CHANGED',409);
      const current=await active(io);if(current.revision!==row.expectedRevision)fail('RULE_BUNDLE_REVISION_CONFLICT',409);
      const prepared=validateBundle(readBundle(row),current.source,OWNED_INPUT);if(prepared.previewDigest!==row.previewDigest)fail('RULE_BUNDLE_PREVIEW_CHANGED',409);
      const compiled=compile(prepared),revision=compiled.manifest.active_revision;
      const bytesDigest=hash(prepared.bytes);
      // readBundle above strictly validated this staged representation. Reuse it
      // only when fresh normalization proves exactly the same canonical bytes.
      const stored=(row.bundle_storage?.sha256===bytesDigest&&row.bundle_storage.bytes===prepared.bytes.length)
       ?{...row.bundle_storage}:pack(prepared.bytes);
      const doc={_id:bundleId(revision),companyId,doc_type:'rule_bundle_version',revision,digest:bytesDigest,
       bundle_storage:stored,summary:structuredClone(prepared.summary),
       canonical_json:{schema:CANONICAL_SCHEMA,bytes:prepared.bytes.length,digest:bytesDigest,summaryDigest:hash(prepared.summary)},
       parent_revision:current.revision,source_reference:sourceId(companyId,current.revision)};
      const documents=[...compiled.documents,doc],existing=[];
      for(const item of documents)existing.push(await io.get(item._id));
      for(let i=0;i<documents.length;i++)if(existing[i]&&hash(clean(existing[i]))!==hash(clean(documents[i])))fail('RULE_BUNDLE_IMMUTABLE_CONFLICT',409);
      // Transaction reads the company document and active manifest before any writes.
      // Their transaction conflict protection supplies fresh auth + CAS at commit.
      for(let i=0;i<documents.length;i++)if(!existing[i])await io.set(documents[i]._id,documents[i]);
      await io.set(compiled.manifest._id,{...compiled.manifest,rule_bundle_revision:revision,rule_bundle_digest:doc.digest,rule_bundle_parent_revision:current.revision,rule_bundle_summary_digest:doc.canonical_json.summaryDigest});
      const receipt={requestId:row.requestId,state:'committed',revision,digest:doc.digest,summary:prepared.summary};
      await io.set(row._id,{...row,state:'committed',receipt,committed:now()});
      return receipt;
     }
     fail('RULE_BUNDLE_REQUEST_INVALID');
    });
   }
   return {status:200,data:{...flags,...result,read_only:['rule_bundle_status','rule_bundle_export_chunk','rule_bundle_import_status'].includes(payload.operation),mutation_committed:result.state==='committed'}};
  }catch(error){const known=error instanceof RuleError||[401,403].includes(error.status);return {status:known?error.status:503,data:{...flags,code:known?error.code:'RULE_BUNDLE_STORAGE_UNAVAILABLE',...(!known&&payload.operation==='rule_bundle_import_commit'?{state:'unknown',reconcile:'rule_bundle_import_status'}:{}),...(error instanceof RuleError&&error.field?{field:error.field}:{})}};}
 };
}
module.exports={OPS,SCHEMA,MAX_BYTES,CHUNK_BYTES,MAX_CHUNKS,bundleId,chunkId,validateBundle,initialBundle,compile,createRuleBundleRoutes};
