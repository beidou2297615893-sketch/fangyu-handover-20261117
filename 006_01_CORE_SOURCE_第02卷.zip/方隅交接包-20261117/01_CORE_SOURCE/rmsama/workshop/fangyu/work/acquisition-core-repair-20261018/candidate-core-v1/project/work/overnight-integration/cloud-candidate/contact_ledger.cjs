/* Company-scoped contact reports. Device reports are evidence of local action, not platform receipts. */
const crypto = require('node:crypto');

const OPERATIONS = new Set(['contact_events_sync', 'contact_responses_sync', 'contact_customers_list', 'contact_customer_detail',
  'contact_deals_list', 'contact_deal_report', 'contact_deal_review', 'contact_deal_history',
  'contact_policy_read', 'contact_policy_save','contact_ledger_summary','contact_receipts_verify']);
const COLLECTION = 'fangyu_workspace_private';
const PAGE_SIZE = 50;
const TIMELINE_SIZE = 25;
const KINDS = new Set(['reviewed', 'send_started', 'sent', 'failed', 'unknown', 'copied', 'external_reported']);
const INTENT_LEVELS = new Set(['super_high','high','medium','low','very_low']);
const INTENT_STATUSES = new Set(['graded','uncertain','unrelated','pending']);
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const PLATFORM_ID = /^[A-Za-z0-9_-]{1,160}$/;
const hash = value => crypto.createHash('sha256').update(value).digest('hex');
class LedgerError extends Error {
  constructor(code, message, status = 400) { super(message); this.code = code; this.status = status; }
}
const fail = (code, message, status) => { throw new LedgerError(code, message, status); };
const exact = (value, keys, label) => {
  if (!value || typeof value !== 'object' || Array.isArray(value) || Object.keys(value).some(key => !keys.includes(key)))
    fail('CONTACT_INVALID_INPUT', `${label}字段无效`);
};
function str(value, limit, label, required = false, preserve = false) {
  if (value === undefined || value === null) value = '';
  if (typeof value !== 'string' || value.length > limit || (required && !value.trim()))
    fail('CONTACT_INVALID_INPUT', `${label}格式无效`);
  // Tokens and credentials must never be preserved in a contact record.
  if (/\b(?:Bearer\s+[A-Za-z0-9._-]{12,}|sk-[A-Za-z0-9_-]{12,}|(?:api[_-]?key|cookie|authorization|password|secret)\s*[:=]\s*\S{8,})/i.test(value))
    fail('CONTACT_SECRET_REJECTED', '联系记录包含疑似密钥，已拒绝');
  return preserve ? value : value.trim();
}
function officialUrl(value, label, avatar = false) {
  value = str(value, 1000, label);
  if (!value) return '';
  let url;
  try { url = new URL(value); } catch { fail('CONTACT_INVALID_URL', `${label}链接无效`); }
  const host = url.hostname.toLowerCase();
  const allowed = avatar ? (host === 'xhscdn.com' || host.endsWith('.xhscdn.com'))
    : (host === 'xiaohongshu.com' || host.endsWith('.xiaohongshu.com') || host === 'xhslink.com' || host.endsWith('.xhslink.com'));
  if (url.protocol !== 'https:' || !allowed || url.username || url.password || url.port)
    fail('CONTACT_INVALID_URL', `${label}只接受小红书官方 HTTPS 链接`);
  url.hash = '';
  if (!avatar) {
    const preserved = new URLSearchParams();
    for (const key of ['xsec_token', 'xsec_source']) {
      const part = url.searchParams.get(key);
      if (part && part.length <= 500) preserved.set(key, part);
    }
    url.search = preserved.toString();
  }
  return url.toString();
}
function normalizeEvent(raw, now) {
  exact(raw, ['event_id', 'kind', 'occurred_at', 'lead', 'reply', 'sender', 'intent_snapshot'], '事件');
  if (!UUID.test(raw.event_id || '')) fail('CONTACT_INVALID_INPUT', '事件标识格式无效');
  if (!KINDS.has(raw.kind)) fail('CONTACT_INVALID_INPUT', '事件类型无效');
  if (!Number.isSafeInteger(raw.occurred_at) || raw.occurred_at < 1577836800 || raw.occurred_at > now + 86400)
    fail('CONTACT_INVALID_INPUT', '事件时间无效');
  exact(raw.lead, ['id', 'platform', 'author_id', 'author', 'text', 'note_url', 'author_avatar_url',
    'task_id', 'comment_id', 'parent_id', 'source_keyword'], '线索');
  const lead = {
    id: str(raw.lead.id, 200, '线索 ID', true), platform: str(raw.lead.platform, 40, '平台', true),
    author_id: str(raw.lead.author_id, 160, '作者 ID'), author: str(raw.lead.author, 120, '作者'),
    text: str(raw.lead.text, 3000, '原评论', false, true), note_url: officialUrl(raw.lead.note_url, '帖子'),
    author_avatar_url: officialUrl(raw.lead.author_avatar_url, '头像', true),
    task_id: str(raw.lead.task_id, 160, '任务 ID'), comment_id: str(raw.lead.comment_id, 160, '评论 ID'),
    parent_id: str(raw.lead.parent_id, 160, '父评论 ID'), source_keyword: str(raw.lead.source_keyword, 160, '来源关键词')
  };
  if (lead.platform !== 'xiaohongshu' || (!lead.author_id && !lead.comment_id))
    fail('CONTACT_INVALID_INPUT', '联系记录缺少可核对的小红书作者或评论 ID');
  exact(raw.reply || {}, raw.kind === 'sent' ? ['id', 'text', 'platform_reply_id'] : ['id', 'text'], '回复');
  exact(raw.sender || {}, raw.kind === 'sent' ? ['account_id', 'nickname', 'platform_uid'] : ['account_id', 'nickname'], '发送账号');
  const reply = {id: str(raw.reply?.id, 160, '回复 ID'), text: str(raw.reply?.text, 3000, '回复原文', false, true)};
  if (raw.kind === 'sent' && !reply.text.trim()) fail('CONTACT_INVALID_INPUT', '成功发送事件缺少回复原文');
  const sender = {account_id: str(raw.sender?.account_id, 160, '发送账号 ID'),
    nickname: str(raw.sender?.nickname, 120, '发送账号昵称')};
  if (Object.hasOwn(raw.reply || {}, 'platform_reply_id')) {
    if (!PLATFORM_ID.test(raw.reply.platform_reply_id)) fail('CONTACT_INVALID_INPUT', '平台回复 ID 格式无效');
    reply.platform_reply_id = raw.reply.platform_reply_id;
  }
  if (Object.hasOwn(raw.sender || {}, 'platform_uid')) {
    if (!PLATFORM_ID.test(raw.sender.platform_uid)) fail('CONTACT_INVALID_INPUT', '发送账号平台 UID 格式无效');
    sender.platform_uid = raw.sender.platform_uid;
  }
  let intentSnapshot;
  if (raw.intent_snapshot !== undefined) {
    const value=raw.intent_snapshot;
    exact(value,['source','status','level','reason','assessed_at','rules_version'],'联系时意向');
    if (Object.keys(value).length!==6 || !['none','manual','ai'].includes(value.source) || !INTENT_STATUSES.has(value.status) ||
        (value.source==='none')!==(value.status==='pending') ||
        (value.status==='graded' ? !INTENT_LEVELS.has(value.level) : value.level!==null))
      fail('CONTACT_INVALID_INPUT','联系时意向格式无效');
    intentSnapshot={source:value.source,status:value.status,level:value.level,
      reason:str(value.reason,500,'意向理由',false,true),
      assessed_at:str(value.assessed_at,64,'意向判断时间',false,true),
      rules_version:str(value.rules_version,80,'意向规则版本',false,true)};
  }
  return {event_id: raw.event_id.toLowerCase(), kind: raw.kind, occurred_at: raw.occurred_at, lead, reply, sender,
    ...(intentSnapshot?{intent_snapshot:intentSnapshot}:{})};
}
function normalizeResponseObservation(raw, now) {
  exact(raw, ['observation_id','sent_event_id','origin_comment_id','local_reply_id','platform_reply_id','response'], '回应观测');
  if (!UUID.test(raw.observation_id || '') || !UUID.test(raw.sent_event_id || ''))
    fail('CONTACT_INVALID_INPUT', '回应观测标识格式无效');
  const originCommentId = str(raw.origin_comment_id, 160, '原评论 ID', true);
  const localReplyId = str(raw.local_reply_id, 160, '本机回复 ID', true);
  const platformReplyId = str(raw.platform_reply_id, 160, '平台回复 ID', true);
  if (![originCommentId, platformReplyId].every(id => PLATFORM_ID.test(id)))
    fail('CONTACT_INVALID_INPUT', '回应来源 ID 格式无效');
  exact(raw.response, ['platform','author_id','note_url','comment_id','target_comment_id',
    'target_author_id','published_at','text'], '回应');
  if (Object.keys(raw.response).length !== 8) fail('CONTACT_INVALID_INPUT', '回应证据字段不完整');
  const response = {platform:str(raw.response.platform,40,'平台',true),
    author_id:str(raw.response.author_id,160,'回应作者 UID',true),
    note_url:officialUrl(raw.response.note_url,'回应原帖'),
    comment_id:str(raw.response.comment_id,160,'回应评论 ID',true),
    target_comment_id:str(raw.response.target_comment_id,160,'目标回复 ID',true),
    target_author_id:str(raw.response.target_author_id,160,'目标作者 UID',true),
    published_at:raw.response.published_at,
    text:str(raw.response.text,3000,'回应正文',true,true)};
  if (response.platform !== 'xiaohongshu' || !response.note_url ||
      ![response.author_id,response.comment_id,response.target_comment_id,response.target_author_id]
        .every(id => PLATFORM_ID.test(id)) ||
      !Number.isSafeInteger(response.published_at) || response.published_at < 1577836800 ||
      response.published_at > now + 86400)
    fail('CONTACT_INVALID_INPUT', '回应平台身份或时间无效');
  return {observation_id:raw.observation_id.toLowerCase(),sent_event_id:raw.sent_event_id.toLowerCase(),
    origin_comment_id:originCommentId,local_reply_id:localReplyId,platform_reply_id:platformReplyId,response};
}
function repoFor(transaction, companyId) {
  if (!transaction?.collection) fail('CONTACT_STORAGE_UNAVAILABLE', '联系账本事务不可用', 503);
  const ref = key => transaction.collection(COLLECTION).doc('contact_' + hash(`${companyId}\n${key}`));
  return {
    async get(key) {
      const snapshot = await ref(key).get();
      const value = Array.isArray(snapshot.data) ? snapshot.data[0] : snapshot.data;
      if (value && value.companyId !== companyId) fail('CONTACT_TENANT_MISMATCH', '企业隔离检查失败', 403);
      if (!value) return null;
      const {_id, ...document} = value;
      return document;
    },
    async set(key, value) { await ref(key).set({...value, companyId}); }
  };
}
const customerKey = lead => `${lead.platform}:${lead.author_id ? 'author:' + lead.author_id : 'comment:' + lead.comment_id}`;
const customerId = lead => 'cu_' + hash(customerKey(lead));
const responsePostIdentity = noteUrl => {
  const url = new URL(noteUrl);
  if (!['xiaohongshu.com','www.xiaohongshu.com'].includes(url.hostname)) return '';
  const note = /^\/(?:explore|search_result|discovery\/item)\/([A-Za-z0-9]{24})\/?$/.exec(url.pathname);
  return note ? note[1].toLowerCase() : '';
};
const cursorNumber = value => {
  if (value === undefined || value === '') return 0;
  if (typeof value !== 'string' || !/^(0|[1-9][0-9]*)$/.test(value) || !Number.isSafeInteger(Number(value)))
    fail('CONTACT_INVALID_CURSOR', '分页游标无效');
  return Number(value);
};
const money = (value, label) => {
  if (!Number.isSafeInteger(value) || value < 0 || value > 100000000000) fail('CONTACT_INVALID_INPUT', `${label}格式无效`);
  return value;
};
const defaultPolicy = () => ({commission_rate_bps: null, attribution_days: null});
function commission(deal, policy, sentAt, customer) {
  if (deal.status === 'pending') return {amount: null, status: 'pending_review'};
  if (deal.status === 'rejected') return {amount: null, status: 'review_rejected'};
  if (!deal.attribution_confirmed) return {amount: null, status: 'attribution_unconfirmed'};
  if (!customer || customer.provisional || !customer.author_id) return {amount: null, status: 'identity_unverified'};
  if (policy.commission_rate_bps === null || policy.attribution_days === null)
    return {amount: null, status: 'policy_unconfigured'};
  if (!sentAt) return {amount: null, status: 'no_confirmed_contact'};
  if (!deal.closed_at || sentAt > deal.closed_at || deal.closed_at - sentAt > policy.attribution_days * 86400)
    return {amount: null, status: 'outside_window'};
  return {amount: Math.floor((deal.amount_cents - deal.refund_cents) * policy.commission_rate_bps / 10000), status: 'calculated'};
}
// Canonical device payload hash, equivalent to Python sort_keys/ensure_ascii=False.
function canonical(value) {
  if (Array.isArray(value)) return '[' + value.map(canonical).join(',') + ']';
  if (value && typeof value === 'object') return '{' + Object.keys(value).sort().map(k => JSON.stringify(k)+':'+canonical(value[k])).join(',') + '}';
  return JSON.stringify(value);
}
async function summaryCounters(repo, meta) {
  if (meta.summary_version === 1) {
    for (const key of ['successful_customers','paired_sent_events','ledger_revision'])
      if (!Number.isSafeInteger(meta[key]) || meta[key]<0) fail('CONTACT_STORAGE_CONFLICT','联系账本汇总待核对',503);
    return {successful_customers:meta.successful_customers,paired_sent_events:meta.paired_sent_events,ledger_revision:meta.ledger_revision};
  }
  // One-time compatibility read of the old index; subsequent writes keep counters atomically.
  const pages=Math.ceil((meta.customer_count||0)/PAGE_SIZE);
  if (pages>8) fail('CONTACT_SUMMARY_MIGRATION_REQUIRED','旧账本汇总需受控迁移，请勿按未核对数字结算',503);
  const result={successful_customers:0,paired_sent_events:0,ledger_revision:0};
  for(let i=0;i<pages;i++) {
    const page=await repo.get(`customers:${i}`);
    if(!page||!Array.isArray(page.items))fail('CONTACT_STORAGE_CONFLICT','联系账本索引不完整',503);
    for(const row of page.items) {
      if(!row||!Number.isSafeInteger(row.sent_count)||row.sent_count<0||!Number.isSafeInteger(row.event_count)||row.event_count<1)
        fail('CONTACT_STORAGE_CONFLICT','联系账本索引待核对',503);
      result.successful_customers+=Number(row.sent_count>0&&!row.provisional&&!!row.author_id);
      result.paired_sent_events+=row.sent_count;result.ledger_revision+=row.event_count;
    }
  }
  return result;
}
function createContactLedger({store, companyId, clock = Date.now}) {
  function transact(identity, role, callback) {
    return store.transaction(async (state, transaction) => {
      if (!state || state.companyId !== companyId) fail('CONTACT_TENANT_MISMATCH', '企业隔离检查失败', 403);
      const now = Math.floor(clock() / 1000);
      let actor, device;
      if (role === 'device') {
        device = state.devices?.find(d => !d.revoked && d.digest === identity.deviceDigest);
        actor = device && state.users?.find(u => u.username === device.owner && !u.disabled);
        if (!actor || device.id !== identity.deviceId || actor.username !== identity.username)
          fail('CONTACT_AUTH_REQUIRED', '设备已撤销或员工已停用', 401);
        if (!['admin','operator'].includes(actor.role)) fail('CONTACT_FORBIDDEN', '账号无联系记录权限', 403);
      } else {
        const session = state.sessions?.find(s => s.digest === identity.sessionDigest && s.username === identity.username && s.expires > now);
        actor = session && state.users?.find(u => u.username === identity.username && !u.disabled);
        if (!actor) fail('CONTACT_AUTH_REQUIRED', '请重新登录', 401);
        if (role === 'admin' && actor.role !== 'admin') fail('CONTACT_ADMIN_REQUIRED', '需要管理员权限', 403);
      }
      const result = await callback(repoFor(transaction, companyId), actor, device, now, state);
      return {state, result};
    });
  }
  async function syncOne(event, identity) {
    return transact(identity, 'device', async (repo, actor, device, now, state) => {
      if (['send_started','sent','failed','unknown'].includes(event.kind) &&
          (!event.sender.account_id || !state.xhs_claims?.some(claim => claim.device_id === device.id && claim.account_id === event.sender.account_id)))
        fail('CONTACT_SENDER_UNCLAIMED', '发送账号未在该设备登记', 403);
      if (event.kind === 'sent' && event.sender.platform_uid &&
          !state.xhs_claims?.some(claim => claim.device_id === device.id &&
            claim.account_id === event.sender.account_id && claim.uid_hash === hash(event.sender.platform_uid)))
        fail('CONTACT_SENDER_UNCLAIMED', '发送账号平台身份与设备登记不符', 403);
      const id = customerId(event.lead);
      const eventKey = `event:${event.event_id}`;
      const existing = await repo.get(eventKey);
      const fingerprint = hash(JSON.stringify({event, employee: actor.username, device_id: device.id}));
      if (existing) {
        if (existing.fingerprint !== fingerprint) fail('CONTACT_EVENT_CONFLICT', '事件标识已用于其他内容', 409);
        return {event_id: event.event_id, customer_id: existing.customer_id, reused: true};
      }
      const terminal = ['sent','failed','unknown'].includes(event.kind);
      const attemptKey = event.reply.id ? `attempt:${device.id}:${id}:${event.reply.id}` : '';
      const attempt = (event.kind === 'send_started' || terminal) && attemptKey ? await repo.get(attemptKey) : null;
      const frozenTarget = hash(JSON.stringify({device_id: device.id, customer_id: id,
        lead_id: event.lead.id, comment_id: event.lead.comment_id, parent_id: event.lead.parent_id,
        lead_text: event.lead.text, note_url: event.lead.note_url,
        reply_id: event.reply.id, reply_text: event.reply.text, sender_account_id: event.sender.account_id}));
      const startComplete = !!(event.reply.id && event.reply.text.trim() && event.sender.account_id);
      const verification = event.kind === 'send_started' ? (startComplete ? 'start_recorded' : 'unpaired')
        : terminal ? (attempt?.status === 'open' && attempt.frozen_target === frozenTarget &&
            event.occurred_at >= attempt.started_occurred_at ? 'paired' : 'unpaired')
          : 'not_applicable';
      const customerDocKey = `customer:${id}`;
      const customer = await repo.get(customerDocKey);
      const meta = await repo.get('meta') || {customer_count: 0, deal_count: 0};
      const sequence = customer?.sequence ?? meta.customer_count;
      const indexPageNo = Math.floor(sequence / PAGE_SIZE);
      const indexKey = `customers:${indexPageNo}`;
      const indexPage = await repo.get(indexKey) || {items: []};
      const timelineCount = customer?.timeline_count || 0;
      const timelinePageNo = Math.floor(timelineCount / TIMELINE_SIZE);
      const timelineKey = `timeline:${id}:${timelinePageNo}`;
      const timelinePage = await repo.get(timelineKey) || {items: []};
      const record = {...event, customer_id: id, employee: actor.username, device_id: device.id,
        source: 'device_report', server_received_at: now, verification_status: verification};
      const confirmedSent = event.kind === 'sent' && verification === 'paired';
      const counters=await summaryCounters(repo,meta);
      Object.assign(meta,counters,{summary_version:1});
      meta.ledger_revision++;meta.paired_sent_events+=Number(confirmedSent);
      meta.successful_customers+=Number(confirmedSent&&!customer?.sent_count&&!!event.lead.author_id);
      meta.max_received_at=now;
      const summary = {
        customer_id: id, platform: event.lead.platform, author_id: event.lead.author_id,
        author: event.lead.author || customer?.author || '',
        profile_url: event.lead.author_id ? `https://www.xiaohongshu.com/user/profile/${encodeURIComponent(event.lead.author_id)}` : '',
        author_avatar_url: event.lead.author_avatar_url || customer?.author_avatar_url || '',
        last_contact_at: now, last_kind: event.kind, last_employee: actor.username,
        last_verification_status: verification,
        last_intent_snapshot: event.intent_snapshot || null,
        first_received_at: customer?.first_received_at || now, provisional: !event.lead.author_id,
        event_count: timelineCount + 1, sent_count: (customer?.sent_count || 0) + Number(confirmedSent),
        response_count: customer?.response_count || 0, last_response_at: customer?.last_response_at || null,
        last_lead: {id: event.lead.id, comment_id: event.lead.comment_id,
          text: event.lead.text.slice(0, 300), note_url: event.lead.note_url},
        last_reply: {id: event.reply.id, text: event.reply.text.slice(0, 300)},
        sequence
      };
      if (customer && customer.author_id && customer.author_id !== event.lead.author_id)
        fail('CONTACT_CUSTOMER_CONFLICT', '客户身份冲突', 409);
      const nextCustomer = {...summary, first_sent_at: customer?.first_sent_at || (confirmedSent ? now : null),
        timeline_count: timelineCount + 1, deal_count: customer?.deal_count || 0,
        first_lead: customer?.first_lead || event.lead, last_lead: event.lead, last_reply: event.reply};
      indexPage.items[sequence % PAGE_SIZE] = summary;
      timelinePage.items.push(record);
      if (timelinePage.items.length > TIMELINE_SIZE) fail('CONTACT_STORAGE_CONFLICT', '时间线分页冲突', 409);
      if (!customer) meta.customer_count++;
      // Every write is in the same CloudBase transaction. One event per transaction stays below its operation limit.
      await repo.set(eventKey, {fingerprint, customer_id: id, record});
      if (event.kind === 'send_started' && startComplete)
        await repo.set(attemptKey, {status: 'open', frozen_target: frozenTarget, start_event_id: event.event_id,
          started_at: now, started_occurred_at: event.occurred_at});
      else if (terminal && verification === 'paired')
        await repo.set(attemptKey, {...attempt, status: 'closed', terminal_event_id: event.event_id,
          terminal_kind: event.kind, finished_at: now});
      await repo.set(customerDocKey, nextCustomer);
      await repo.set(`customer_summary:${id}`, {...summary, doc_type: 'contact_customer',
        search_text: `${summary.author} ${summary.author_id} ${event.lead.text.slice(0, 500)}`});
      await repo.set(indexKey, indexPage);
      await repo.set(timelineKey, timelinePage);
      await repo.set('meta', meta);
      return {event_id: event.event_id, customer_id: id, reused: false};
    });
  }
  async function syncOneResponse(observation, identity) {
    return transact(identity, 'device', async (repo, actor, device, now) => {
      const sent = (await repo.get(`event:${observation.sent_event_id}`))?.record;
      if (!sent || sent.kind !== 'sent' || sent.verification_status !== 'paired' ||
          sent.device_id !== device.id || sent.employee !== actor.username ||
          sent.lead?.platform !== 'xiaohongshu' || !sent.lead.author_id || !sent.lead.comment_id ||
          !sent.reply?.id || !sent.reply.platform_reply_id || !sent.sender?.platform_uid ||
          sent.reply.platform_reply_id === sent.lead.comment_id ||
          sent.sender.platform_uid === sent.lead.author_id ||
          sent.lead.comment_id !== observation.origin_comment_id ||
          sent.reply.id !== observation.local_reply_id ||
          sent.reply.platform_reply_id !== observation.platform_reply_id)
        fail('CONTACT_RESPONSE_UNVERIFIED', '回应无法绑定已配对的原发送记录', 409);
      const response = observation.response;
      if (response.platform !== sent.lead.platform || response.author_id !== sent.lead.author_id ||
          !responsePostIdentity(response.note_url) ||
          responsePostIdentity(response.note_url) !== responsePostIdentity(sent.lead.note_url) ||
          response.target_comment_id !== sent.reply.platform_reply_id ||
          response.target_author_id !== sent.sender.platform_uid ||
          response.comment_id === sent.lead.comment_id ||
          response.comment_id === sent.reply.platform_reply_id ||
          response.published_at <= sent.occurred_at)
        fail('CONTACT_RESPONSE_UNVERIFIED', '回应作者、帖子、目标或时间与原发送不符', 409);
      const fingerprint = hash(canonical(observation));
      const observationKey = `response_observation:${observation.observation_id}`;
      const identityKey = `response_comment:${response.platform}:${responsePostIdentity(response.note_url)}:${response.comment_id}`;
      const existing = await repo.get(observationKey);
      if (existing) {
        if (existing.payload_hash !== fingerprint || existing.sent_event_id !== observation.sent_event_id)
          fail('CONTACT_RESPONSE_CONFLICT', '回应观测标识已用于其他内容', 409);
        return {observation_id:observation.observation_id,customer_id:existing.customer_id,
          payload_hash:fingerprint,reused:true};
      }
      if (await repo.get(identityKey)) fail('CONTACT_RESPONSE_CONFLICT', '平台回应评论已归档，内容不可改写', 409);
      const id = sent.customer_id;
      const customerKey = `customer:${id}`;
      const customer = await repo.get(customerKey);
      const summaryKey = `customer_summary:${id}`;
      const summary = await repo.get(summaryKey);
      if (!customer || !summary || customer.author_id !== response.author_id ||
          !Number.isSafeInteger(customer.response_count || 0) || (customer.response_count || 0) < 0)
        fail('CONTACT_STORAGE_CONFLICT', '客户回应归档记录待核对', 503);
      const count = customer.response_count || 0;
      const pageKey = `responses:${id}:${Math.floor(count / TIMELINE_SIZE)}`;
      const page = await repo.get(pageKey) || {items:[]};
      if (!Array.isArray(page.items) || page.items.length !== count % TIMELINE_SIZE)
        fail('CONTACT_STORAGE_CONFLICT', '客户回应分页记录待核对', 503);
      const indexKey = `customers:${Math.floor(customer.sequence / PAGE_SIZE)}`;
      const index = await repo.get(indexKey);
      if (!index || !Array.isArray(index.items) ||
          index.items[customer.sequence % PAGE_SIZE]?.customer_id !== id)
        fail('CONTACT_STORAGE_CONFLICT', '客户索引待核对', 503);
      const record = {observation_id:observation.observation_id,sent_event_id:observation.sent_event_id,
        local_reply_id:observation.local_reply_id,platform_reply_id:observation.platform_reply_id,
        origin_comment_id:observation.origin_comment_id,response,
        sent_reply_text:sent.reply.text,customer_id:id,employee:actor.username,device_id:device.id,
        source:'device_observation',server_received_at:now,payload_hash:fingerprint};
      page.items.push(record);
      const responseCount = count + 1;
      const fields = {response_count:responseCount,last_response_at:Math.max(customer.last_response_at || 0,response.published_at)};
      index.items[customer.sequence % PAGE_SIZE] = {...index.items[customer.sequence % PAGE_SIZE],...fields};
      await repo.set(observationKey,{payload_hash:fingerprint,sent_event_id:observation.sent_event_id,customer_id:id});
      await repo.set(identityKey,{payload_hash:fingerprint,observation_id:observation.observation_id,customer_id:id});
      await repo.set(pageKey,page);
      await repo.set(customerKey,{...customer,...fields});
      await repo.set(summaryKey,{...summary,...fields});
      await repo.set(indexKey,index);
      return {observation_id:observation.observation_id,customer_id:id,payload_hash:fingerprint,reused:false};
    });
  }
  async function handle(payload, identity) {
    try {
      const op = payload.operation;
      const allowed = {
        contact_events_sync: ['events'], contact_responses_sync: ['observations'],
        contact_customers_list: ['cursor','limit','query','employee','date_from','date_to'],
        contact_customer_detail: ['customer_id','cursor','deal_cursor','response_cursor'],
        contact_deals_list: ['cursor','limit','query','status'],
        contact_deal_report: ['order_no','customer_id','amount_cents','refund_cents','closed_at','evidence_reference'],
        contact_deal_review: ['order_no','expected_revision','decision','attribution_confirmed','note'],
        contact_deal_history: ['order_no','cursor','limit'],
        contact_ledger_summary: [], contact_receipts_verify: ['reply_id','events'],
        contact_policy_read: [], contact_policy_save: ['expected_revision','commission_rate_bps','attribution_days']
      }[op];
      if (!allowed) fail('CONTACT_INVALID_INPUT', '不支持的联系账本操作');
      exact(payload, ['environment_id','operation',...allowed], '请求');
      if (op === 'contact_events_sync') {
        if (!Array.isArray(payload.events) || payload.events.length < 1 || payload.events.length > 20)
          fail('CONTACT_INVALID_INPUT', '每批允许 1 至 20 条联系事件');
        const now = Math.floor(clock() / 1000);
        const events = payload.events.map(row => normalizeEvent(row, now));
        const seen = new Set();
        for (const row of events) { if (seen.has(row.event_id)) fail('CONTACT_EVENT_CONFLICT', '批内事件标识重复', 409); seen.add(row.event_id); }
        const accepted = [];
        for (const event of events) accepted.push(await syncOne(event, identity));
        return {status: 200, data: {accepted, accepted_event_ids: accepted.map(x => x.event_id), count: accepted.length}};
      }
      if (op === 'contact_responses_sync') {
        if (!Array.isArray(payload.observations) || payload.observations.length < 1 || payload.observations.length > 20)
          fail('CONTACT_INVALID_INPUT', '每批允许 1 至 20 条回应观测');
        const now = Math.floor(clock() / 1000);
        const observations = payload.observations.map(row => normalizeResponseObservation(row, now));
        if (new Set(observations.map(row => row.observation_id)).size !== observations.length ||
            new Set(observations.map(row => `${responsePostIdentity(row.response.note_url)}:${row.response.comment_id}`)).size !== observations.length)
          fail('CONTACT_RESPONSE_CONFLICT', '批内回应观测重复', 409);
        const accepted = [];
        for (const observation of observations) accepted.push(await syncOneResponse(observation, identity));
        return {status:200,data:{accepted,accepted_observation_ids:accepted.map(row => row.observation_id),count:accepted.length}};
      }
      if(op==='contact_ledger_summary') return {status:200,data:await transact(identity,'admin',async(repo,actor,device,now)=>{
        const meta=await repo.get('meta')||{customer_count:0};const counters=await summaryCounters(repo,meta);
        return {source:'cloud_ledger',scope:'all_customers',verified_at:now,total_recorded_customers:meta.customer_count||0,
          ...counters,max_received_at:meta.max_received_at||null};
      })};
      if(op==='contact_receipts_verify') {
        const replyId=str(payload.reply_id,200,'回复 ID',true),expected=payload.events;
        if(!Array.isArray(expected)||expected.length<1||expected.length>20||new Set(expected.map(x=>x?.event_id)).size!==expected.length)
          fail('CONTACT_INVALID_INPUT','核验事件格式无效');
        for(const row of expected){exact(row,['event_id','payload_hash'],'核验事件');
          if(!UUID.test(row.event_id||'')||!/^[a-f0-9]{64}$/.test(row.payload_hash||''))fail('CONTACT_INVALID_INPUT','核验事件格式无效');}
        return {status:200,data:await transact(identity,'user',async(repo,actor,device,now)=>{
          const events=[];
          for(const row of expected){
            const stored=await repo.get(`event:${row.event_id}`),record=stored?.record;
            if(!record){events.push({event_id:row.event_id,status:'pending'});continue;}
            if(record.reply.id!==replyId||(actor.role!=='admin'&&record.employee!==actor.username))
              fail('CONTACT_FORBIDDEN','不能核验其他员工或其他回复的联系记录',403);
            const raw=Object.fromEntries(['event_id','kind','occurred_at','lead','reply','sender'].map(k=>[k,record[k]]));
            if(Object.hasOwn(record,'intent_snapshot'))raw.intent_snapshot=record.intent_snapshot;
            const payloadHash=hash(canonical(raw)),same=payloadHash===row.payload_hash;
            events.push({event_id:row.event_id,status:same?'verified':'mismatch',kind:record.kind,payload_hash:payloadHash,
              verification_status:record.verification_status,server_received_at:record.server_received_at,
              employee:record.employee,device_id:record.device_id,customer_id:record.customer_id});
          }
          const verified=events.every(e=>e.status==='verified')&&events.some(e=>e.kind==='sent'&&e.verification_status==='paired')
            &&events.some(e=>e.kind==='send_started'&&e.verification_status==='start_recorded');
          return {source:'cloud_ledger',verified_at:now,reply_id:replyId,events,cloud_verified:verified,
            receipt_status:verified?'verified':events.some(e=>e.status==='mismatch')?'mismatch':'pending'};
        })};
      }
      if (op === 'contact_customers_list' || op === 'contact_deals_list') {
        const type = op === 'contact_customers_list' ? 'customers' : 'deals';
        const limit = payload.limit === undefined ? PAGE_SIZE : payload.limit;
        if (!Number.isSafeInteger(limit) || limit < 1 || limit > PAGE_SIZE) fail('CONTACT_INVALID_INPUT', '分页数量无效');
        const cursor = payload.cursor === undefined || payload.cursor === '' ? null : cursorNumber(payload.cursor);
        const query = str(payload.query, 80, '搜索词');
        const employee = type === 'customers' ? str(payload.employee, 80, '最后上报员工') : '';
        if (employee && !/^[a-zA-Z0-9_.@-]{3,80}$/.test(employee)) fail('CONTACT_INVALID_INPUT', '员工筛选格式无效');
        const dateFrom = type === 'customers' && payload.date_from !== undefined ? payload.date_from : null;
        const dateTo = type === 'customers' && payload.date_to !== undefined ? payload.date_to : null;
        for (const value of [dateFrom, dateTo]) if (value !== null && (!Number.isSafeInteger(value) || value < 1577836800))
          fail('CONTACT_INVALID_INPUT', '日期筛选格式无效');
        if (dateFrom !== null && dateTo !== null && dateFrom > dateTo) fail('CONTACT_INVALID_INPUT', '日期范围无效');
        const status = type === 'deals' ? str(payload.status, 20, '审核状态') : '';
        if (status && !['pending', 'confirmed', 'rejected'].includes(status)) fail('CONTACT_INVALID_INPUT', '审核状态无效');
        if (!store.listContactSummaries) fail('CONTACT_STORAGE_UNAVAILABLE', '联系账本检索服务不可用', 503);
        await transact(identity, 'admin', async () => true);
        const result = await store.listContactSummaries({type, cursor, limit, query, employee, dateFrom, dateTo, status});
        await transact(identity, 'admin', async () => true);
        const rows = result.rows.map(({sequence, ...row}) => {
          if (type !== 'customers') return row;
          const count = row.response_count === undefined ? 0 : row.response_count;
          if (!Number.isSafeInteger(count) || count < 0) fail('CONTACT_STORAGE_CONFLICT', '客户回应计数待核对', 503);
          return {...row,response_count:count};
        });
        const next = result.hasMore && result.rows.length ? String(result.rows.at(-1).sequence) : '';
        return {status: 200, data: type === 'customers'
          ? {customers: rows, next_cursor: next, total_customers: result.total}
          : {deals: rows, next_cursor: next, total_deals: result.total}};
      }
      if (op === 'contact_customer_detail') return {status: 200, data: await transact(identity, 'admin', async repo => {
        const id = str(payload.customer_id, 80, '客户 ID', true), cursor = cursorNumber(payload.cursor),
          dealCursor = cursorNumber(payload.deal_cursor), responseCursor = cursorNumber(payload.response_cursor);
        if (!/^cu_[a-f0-9]{64}$/.test(id)) fail('CONTACT_INVALID_INPUT', '客户 ID 无效');
        const customer = await repo.get(`customer:${id}`);
        if (!customer) fail('CONTACT_NOT_FOUND', '客户不存在', 404);
        if (cursor > customer.timeline_count) fail('CONTACT_INVALID_CURSOR', '时间线游标无效');
        const page = await repo.get(`timeline:${id}:${Math.floor(cursor / TIMELINE_SIZE)}`) || {items: []};
        const available = Math.min(TIMELINE_SIZE - cursor % TIMELINE_SIZE, customer.timeline_count - cursor);
        const timeline = page.items.slice(cursor % TIMELINE_SIZE, cursor % TIMELINE_SIZE + available);
        const next = cursor + available;
        if (dealCursor > (customer.deal_count || 0)) fail('CONTACT_INVALID_CURSOR', '成交游标无效');
        const deals = [], dealLimit = Math.min(25, (customer.deal_count || 0) - dealCursor);
        const dealPage = await repo.get(`customer_deals:${id}:${Math.floor(dealCursor / PAGE_SIZE)}`) || {items: []};
        for (let i = dealCursor; i < dealCursor + dealLimit && Math.floor(i / PAGE_SIZE) === Math.floor(dealCursor / PAGE_SIZE); i++) {
          const orderNo = dealPage.items?.[i % PAGE_SIZE];
          if (orderNo) { const deal = await repo.get(`deal:${orderNo}`); if (deal) deals.push(deal); }
        }
        const nextDealCursor = dealCursor + deals.length;
        const responseCount = customer.response_count || 0;
        if (!Number.isSafeInteger(responseCount) || responseCount < 0 || responseCursor > responseCount)
          fail('CONTACT_INVALID_CURSOR', '回应游标无效');
        const responsePage = await repo.get(`responses:${id}:${Math.floor(responseCursor / TIMELINE_SIZE)}`) || {items:[]};
        const responseAvailable = Math.min(TIMELINE_SIZE - responseCursor % TIMELINE_SIZE, responseCount - responseCursor);
        if (!Array.isArray(responsePage.items) || responsePage.items.length < responseCursor % TIMELINE_SIZE + responseAvailable)
          fail('CONTACT_STORAGE_CONFLICT', '回应分页记录待核对', 503);
        const responses = responsePage.items.slice(responseCursor % TIMELINE_SIZE,
          responseCursor % TIMELINE_SIZE + responseAvailable);
        const nextResponseCursor = responseCursor + responses.length;
        const {sequence, ...visibleCustomer} = customer;
        return {customer: {...visibleCustomer,response_count:responseCount}, timeline, next_cursor: next < customer.timeline_count ? String(next) : '',
          responses,response_next_cursor:nextResponseCursor < responseCount ? String(nextResponseCursor) : '',response_count:responseCount,
          deals: deals.map(({sequence, ...deal}) => deal),
          deal_next_cursor: nextDealCursor < (customer.deal_count || 0) ? String(nextDealCursor) : '',
          total_deals: customer.deal_count || 0};
      })};
      if (op === 'contact_policy_read' || op === 'contact_policy_save') return {status: 200, data: await transact(identity, 'admin', async repo => {
        const previous = await repo.get('policy') || {...defaultPolicy(), revision: 0};
        if (op === 'contact_policy_read') return {policy: {commission_rate_bps: previous.commission_rate_bps, attribution_days: previous.attribution_days}, revision: previous.revision};
        if (!Number.isSafeInteger(payload.expected_revision) || payload.expected_revision !== previous.revision)
          fail('CONTACT_REVISION_CONFLICT', '分成政策已更新，请刷新后再试', 409);
        const rate = payload.commission_rate_bps, days = payload.attribution_days;
        if (rate !== null && (!Number.isSafeInteger(rate) || rate < 0 || rate > 10000) ||
            days !== null && (!Number.isSafeInteger(days) || days < 1 || days > 365))
          fail('CONTACT_INVALID_INPUT', '分成政策格式无效');
        const policy = {commission_rate_bps: rate, attribution_days: days, revision: previous.revision + 1};
        await repo.set('policy_history:' + policy.revision, {...policy, saved_by: identity.username, saved_at: Math.floor(clock()/1000)});
        await repo.set('policy', policy);
        return {policy: {commission_rate_bps: rate, attribution_days: days}, revision: policy.revision};
      })};
      if (op === 'contact_deal_report') return {status: 200, data: await transact(identity, 'user', async (repo, actor, _device, now) => {
        if (!['admin','operator'].includes(actor.role)) fail('CONTACT_FORBIDDEN', '账号无成交登记权限', 403);
        const orderNo = str(payload.order_no, 120, '订单号', true), id = str(payload.customer_id, 80, '客户 ID', true);
        if (!/^[A-Za-z0-9_.-]{1,120}$/.test(orderNo) || !/^cu_[a-f0-9]{64}$/.test(id))
          fail('CONTACT_INVALID_INPUT', '订单或客户标识无效');
        const amount = money(payload.amount_cents, '成交金额'), refund = money(payload.refund_cents, '退款金额');
        if (refund > amount) fail('CONTACT_INVALID_INPUT', '退款金额不能超过成交金额');
        if (!Number.isSafeInteger(payload.closed_at) || payload.closed_at < 1577836800 || payload.closed_at > now + 86400)
          fail('CONTACT_INVALID_INPUT', '成交时间无效');
        const evidence = str(payload.evidence_reference, 500, '成交证据参考', true);
        if (/https?:\/\//i.test(evidence)) fail('CONTACT_INVALID_URL', '证据参考不能上传任意链接');
        const customer = await repo.get(`customer:${id}`);
        if (!customer) fail('CONTACT_NOT_FOUND', '客户不存在', 404);
        const existing = await repo.get(`deal:${orderNo}`);
        if (existing && existing.customer_id !== id) fail('CONTACT_ORDER_CONFLICT', '订单号已关联其他客户', 409);
        if (existing && existing.reported_by !== actor.username && actor.role !== 'admin')
          fail('CONTACT_FORBIDDEN', '只能修订本人登记的订单', 403);
        const meta = await repo.get('meta') || {customer_count: 0, deal_count: 0};
        const sequence = existing?.sequence ?? meta.deal_count;
        const globalKey = `deals:${Math.floor(sequence / PAGE_SIZE)}`;
        const globalPage = await repo.get(globalKey) || {items: []};
        const customerDealKey = `customer_deals:${id}:${Math.floor((customer.deal_count || 0) / PAGE_SIZE)}`;
        const customerDealPage = existing ? null : await repo.get(customerDealKey) || {items: []};
        const revision = (existing?.revision || 0) + 1;
        const deal = {order_no: orderNo, customer_id: id, amount_cents: amount, refund_cents: refund,
          closed_at: payload.closed_at, evidence_reference: evidence, reported_by: existing?.reported_by || actor.username,
          last_edited_by: actor.username, status: 'pending', attribution_confirmed: false, commission_cents: null,
          calculation_status: 'pending_review',
          policy_revision: null, confirmed_sent_at: null, revision, sequence, updated_at: now};
        globalPage.items[sequence % PAGE_SIZE] = deal;
        await repo.set(`deal_revision:${orderNo}:${revision}`, {...deal, change_kind: 'report'});
        await repo.set(`deal:${orderNo}`, deal);
        await repo.set(`deal_summary:${orderNo}`, {...deal, doc_type: 'contact_deal',
          search_text: `${orderNo} ${id}`});
        await repo.set(globalKey, globalPage);
        if (!existing) {
          customerDealPage.items.push(orderNo);
          await repo.set(customerDealKey, customerDealPage);
          await repo.set(`customer:${id}`, {...customer, deal_count: (customer.deal_count || 0) + 1});
          await repo.set('meta', {...meta, deal_count: meta.deal_count + 1});
        }
        const {sequence: _, ...visible} = deal;
        return {deal: visible, revision};
      })};
      if (op === 'contact_deal_review') return {status: 200, data: await transact(identity, 'admin', async (repo, actor, _device, now) => {
        const orderNo = str(payload.order_no, 120, '订单号', true);
        if (!/^[A-Za-z0-9_.-]{1,120}$/.test(orderNo) || !['confirm','reject'].includes(payload.decision) ||
            typeof payload.attribution_confirmed !== 'boolean') fail('CONTACT_INVALID_INPUT', '审核参数无效');
        const note = str(payload.note, 500, '审核备注');
        const deal = await repo.get(`deal:${orderNo}`);
        if (!deal) fail('CONTACT_NOT_FOUND', '订单不存在', 404);
        if (!Number.isSafeInteger(payload.expected_revision) || payload.expected_revision !== deal.revision)
          fail('CONTACT_REVISION_CONFLICT', '订单已更新，请刷新后再审核', 409);
        const customer = await repo.get(`customer:${deal.customer_id}`);
        const policy = await repo.get('policy') || {...defaultPolicy(), revision: 0};
        const confirmed = payload.decision === 'confirm';
        const sentAt = confirmed && payload.attribution_confirmed ? customer?.first_sent_at || null : null;
        const next = {...deal, status: confirmed ? 'confirmed' : 'rejected', attribution_confirmed: confirmed && payload.attribution_confirmed,
          confirmed_sent_at: sentAt, policy_revision: confirmed ? policy.revision : null,
          commission_cents: null, reviewed_by: actor.username, review_note: note, reviewed_at: now,
          updated_at: now, revision: deal.revision + 1};
        const calculated = commission(next, policy, sentAt, customer);
        next.commission_cents = calculated.amount;
        next.calculation_status = calculated.status;
        const globalKey = `deals:${Math.floor(deal.sequence / PAGE_SIZE)}`;
        const page = await repo.get(globalKey) || {items: []};
        page.items[deal.sequence % PAGE_SIZE] = next;
        await repo.set(`deal_revision:${orderNo}:${next.revision}`, {...next, change_kind: 'review'});
        await repo.set(`deal:${orderNo}`, next);
        await repo.set(`deal_summary:${orderNo}`, {...next, doc_type: 'contact_deal',
          search_text: `${orderNo} ${deal.customer_id}`});
        await repo.set(globalKey, page);
        const {sequence, ...visible} = next;
        return {deal: visible, revision: next.revision};
      })};
      if (op === 'contact_deal_history') return {status: 200, data: await transact(identity, 'admin', async repo => {
        const orderNo = str(payload.order_no, 120, '订单号', true), cursor = cursorNumber(payload.cursor);
        if (!/^[A-Za-z0-9_.-]{1,120}$/.test(orderNo)) fail('CONTACT_INVALID_INPUT', '订单号无效');
        const deal = await repo.get(`deal:${orderNo}`);
        if (!deal) fail('CONTACT_NOT_FOUND', '订单不存在', 404);
        if (cursor > deal.revision) fail('CONTACT_INVALID_CURSOR', '修订游标无效');
        const limit = payload.limit === undefined ? 20 : payload.limit;
        if (!Number.isSafeInteger(limit) || limit < 1 || limit > 25) fail('CONTACT_INVALID_INPUT', '修订分页数量无效');
        const revisions = [];
        for (let i = cursor + 1; i <= Math.min(deal.revision, cursor + limit); i++) {
          const revision = await repo.get(`deal_revision:${orderNo}:${i}`);
          if (revision) { const {sequence, ...visible} = revision; revisions.push(visible); }
        }
        const next = cursor + revisions.length;
        return {revisions, next_cursor: next < deal.revision ? String(next) : '', total_revisions: deal.revision};
      })};
      fail('CONTACT_INVALID_INPUT', '不支持的联系账本操作');
    } catch (error) {
      if (error instanceof LedgerError) return {status: error.status, data: {error: error.message, code: error.code}};
      throw error;
    }
  }
  return {handle};
}
module.exports = {createContactLedger, OPERATIONS, LedgerError, normalizeEvent, repoFor};
