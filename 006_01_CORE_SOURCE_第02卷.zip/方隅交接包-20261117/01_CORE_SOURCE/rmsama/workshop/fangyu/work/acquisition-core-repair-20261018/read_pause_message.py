"""Read only one owned task's short error; no credentials or lead bodies."""
from pathlib import Path
import sqlite3,json,re
W=Path(__file__).resolve().parent;P=W.parents[1]
b=json.loads((P/'work/ui-native-r57/state/production-workspace.json').read_text('utf-8-sig'))
db=sqlite3.connect((Path(b['data_dir'])/'workspace.sqlite3').as_uri()+'?mode=ro',uri=True)
db.execute('PRAGMA query_only=ON')
row=db.execute("SELECT body FROM records WHERE entity='tasks' AND id=? AND json_extract(body,'$.cloud_owner')=?",('964f7ca9339943c9ae133970befd996b',b['owner'])).fetchone()
db.close()
message=str(json.loads(row[0]).get('last_message','')) if row else 'original task not found'
message=re.sub(r'https?://\S+','[URL]',message)
message=re.sub(r'(?i)(token|cookie|password|authorization|secret)\s*[:=]\s*\S+',r'\1=[redacted]',message)
print(message[:350])
