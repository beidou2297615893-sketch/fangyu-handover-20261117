"""Build and validate one root-bound comment reply expansion on an owned note.

Selectors adapt jackwener/OpenCLI comments.js @
24136945847afbfad266c6c46a8cd335377f9112 (Apache-2.0).
"""

from __future__ import annotations

import json
from pathlib import Path
import re


_SCRIPT = (Path(__file__).resolve().parent / 'resources' /
           'xhs-natural-root-expander.js').read_text(encoding='utf-8')
_ID = re.compile(r'[0-9a-f]{24}')
_ROOT = re.compile(r'[A-Za-z0-9_-]{1,128}')
_UID = re.compile(r'[A-Za-z0-9]{1,128}')
_EPOCH = re.compile(r'(?:\d{10}|\d{13})')
_FIELDS = {'code', 'action_performed', 'match_mode', 'parent_count',
           'root_candidate_count', 'expander_count', 'inline_reply_count',
           'count_capped'}
_CODES = {'scope_invalid', 'security', 'login_wall', 'container_ambiguous',
          'root_scan_limit', 'root_not_found', 'root_ambiguous', 'root_mismatch',
          'expander_unavailable', 'expander_ambiguous', 'observed',
          'expanded_once', 'action_denied'}


def _clean(value, limit):
    if type(value) is not str or len(value) > limit:
        raise ValueError('root_expander_scope_invalid')
    value = ' '.join(value.split())
    if not value or len(value) > limit:
        raise ValueError('root_expander_scope_invalid')
    return value


def build_root_expander_js(note_id: str, root_comment_id: str,
                           action: str = 'observe', *, fallback: dict | None = None) -> str:
    """Optional fallback requires exact API author/body and comparable epoch DOM attribute."""
    if (type(note_id) is not str or not _ID.fullmatch(note_id) or
            type(root_comment_id) is not str or not _ROOT.fullmatch(root_comment_id) or
            action not in ('observe', 'expand') or type(action) is not str or
            any(_SCRIPT.count(marker) != 1 for marker in (
                '__NOTE_ID_JSON__', '__ROOT_ID_JSON__', '__ACTION_JSON__',
                '__FALLBACK_JSON__'))):
        raise ValueError('root_expander_scope_invalid')
    if fallback is not None:
        if type(fallback) is not dict or not (
                set(fallback) == {'author', 'content', 'create_time'} or
                {'author_uid', 'content'}.issubset(fallback) and
                set(fallback) <= {'author_uid', 'author', 'content', 'create_time'}):
            raise ValueError('root_expander_scope_invalid')
        if ('create_time' in fallback and
                (type(fallback['create_time']) is not str or
                 not _EPOCH.fullmatch(fallback['create_time']))):
            raise ValueError('root_expander_scope_invalid')
        if ('author_uid' in fallback and
                (type(fallback['author_uid']) is not str or
                 not _UID.fullmatch(fallback['author_uid']))):
            raise ValueError('root_expander_scope_invalid')
        fallback = {key: _clean(value, 5000 if key == 'content' else 120)
                    if key in {'author', 'content'} else value
                    for key, value in fallback.items()}
    values = {'__NOTE_ID_JSON__': note_id, '__ROOT_ID_JSON__': root_comment_id,
              '__ACTION_JSON__': action, '__FALLBACK_JSON__': fallback}
    script = _SCRIPT
    for marker, value in values.items():
        script = script.replace(marker, json.dumps(value, ensure_ascii=True), 1)
    return script


def validate_root_expander_result(value: object) -> dict:
    if type(value) is not dict or set(value) != _FIELDS:
        raise ValueError('root_expander_result_invalid')
    if (type(value['code']) is not str or value['code'] not in _CODES or
            type(value['action_performed']) is not bool or
            type(value['count_capped']) is not bool or
            type(value['match_mode']) is not str or
            value['match_mode'] not in {'none', 'dom_id', 'api_triplet', 'profile_content'}):
        raise ValueError('root_expander_result_invalid')
    for key, limit in (('parent_count', 200), ('root_candidate_count', 200),
                       ('expander_count', 20), ('inline_reply_count', 200)):
        if type(value[key]) is not int or not 0 <= value[key] <= limit:
            raise ValueError('root_expander_result_invalid')
    if (value['action_performed'] != (value['code'] == 'expanded_once') or
            (value['code'] in {'observed', 'expanded_once'} and
             (value['match_mode'] == 'none' or value['root_candidate_count'] != 1 or
              value['expander_count'] != 1)) or
            (value['match_mode'] == 'none' and value['code'] in
             {'observed', 'expanded_once', 'expander_unavailable', 'expander_ambiguous'})):
        raise ValueError('root_expander_result_invalid')
    return dict(value)
