// No platform sends, AI calls or recurring polls. Cloud ACK alone is not proof.
export function receiptRequest(local, replyId) {
 if(local?.reply_id!==replyId||local.local_integrity!=='ok'||!Array.isArray(local.events)||!local.events.length||local.events.length>20)throw Error('本机联系记录需核对');
 const events=local.events.map(e=>({event_id:e.event_id,payload_hash:e.payload_hash}));
 if(new Set(events.map(e=>e.event_id)).size!==events.length||events.some(e=>typeof e.event_id!=='string'||!/^[a-f0-9]{64}$/.test(e.payload_hash||'')))throw Error('本机联系凭据无效');
 return {reply_id:replyId,events};
}
export function receiptMatches(local,cloud,replyId){
 let request;try{request=receiptRequest(local,replyId);}catch{return false;}
 if(local.local_outcome!=='sent'||!local.local_sent_event_id||cloud?.source!=='cloud_ledger'||cloud.reply_id!==replyId||cloud.cloud_verified!==true||cloud.receipt_status!=='verified'||!Number.isSafeInteger(cloud.verified_at)||cloud.verified_at<=0||!Array.isArray(cloud.events)||cloud.events.length!==request.events.length)return false;
 const expected=new Map(request.events.map(e=>[e.event_id,e.payload_hash]));
 if(new Set(cloud.events.map(e=>e.event_id)).size!==expected.size)return false;
 if(!cloud.events.every(e=>expected.get(e.event_id)===e.payload_hash&&e.status==='verified'&&Number.isSafeInteger(e.server_received_at)&&e.server_received_at>0))return false;
 return cloud.events.some(e=>e.event_id===local.local_sent_event_id&&e.kind==='sent'&&e.verification_status==='paired')&&cloud.events.some(e=>e.kind==='send_started'&&e.verification_status==='start_recorded');
}
export async function verifyReceipt(readLocal,readCloud,replyId){
 const local=await readLocal({reply_id:replyId});
 if(local?.local_outcome==='external_reported')return {status:'external',text:'人工标记已联系 · 未经发送核验'};
 const request=receiptRequest(local,replyId),cloud=await readCloud(request);
 return receiptMatches(local,cloud,replyId)?{status:'verified',text:'已回复 · 云端已核对',verified_at:cloud.verified_at}:{status:'pending',text:'已回复 · 云端记录待核对'};
}
