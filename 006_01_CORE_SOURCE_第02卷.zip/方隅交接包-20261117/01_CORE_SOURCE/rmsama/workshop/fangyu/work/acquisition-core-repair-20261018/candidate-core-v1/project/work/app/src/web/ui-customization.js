/* Customer-facing copy and colour adapter. Never changes input values or client data. */
window.WorkbenchBrand=(()=>{
 let config={},observer=null,pending=false,warned=false;const originals=new WeakMap();
 const slots='button,summary,label,.page-head h1,.page-head p,.panel h2,.panel h3,.reference-idle strong,.reference-idle p,.reference-counts span,.nav-item-label,.nav-copy strong,.nav-copy small,.workflow-strip strong,.workflow-strip small,.keyword-assistant-head strong,.keyword-assistant-head small,.brand strong,.brand small,.footer>span,.help-list li,#quick-scope-hint';
 function copy(text){return Object.hasOwn(config.copy||{},text)?config.copy[text]:text;}
 function decorate(){
  for(const el of document.querySelectorAll(slots)){
   for(const node of el.childNodes){if(node.nodeType!==Node.TEXT_NODE)continue;const current=node.nodeValue,prior=originals.get(node),raw=prior&&prior.applied===current?prior.raw:current,key=raw.trim(),value=copy(key),applied=raw.replace(key,value);originals.set(node,{raw,applied});if(current!==applied)node.nodeValue=applied;}
  }
  for(const el of document.querySelectorAll('input[placeholder],textarea[placeholder]')){const key=el.dataset.copyOriginal||el.placeholder;el.dataset.copyOriginal=key;el.placeholder=copy(key);}
 }
 function init(value){config=value||{};if(!observer){observer=new MutationObserver(()=>{if(pending)return;pending=true;queueMicrotask(()=>{decorate();pending=false;});});observer.observe(document.getElementById('app'),{childList:true,subtree:true});observer.observe(document.getElementById('modal-body'),{childList:true,subtree:true});}}
 function apply(page){const colors=config.sections?.[page]||{};for(const k of ['accent','soft','wash','line']){document.body.style.removeProperty('--section-'+k);if(/^#[0-9a-f]{6}$/i.test(colors[k]||''))document.body.style.setProperty('--section-'+k,colors[k]);}decorate();if(!warned&&config.warnings?.length){warned=true;setTimeout(()=>toast(config.warnings.join("；")),0);}}
 return {init,apply,copy};
})();
