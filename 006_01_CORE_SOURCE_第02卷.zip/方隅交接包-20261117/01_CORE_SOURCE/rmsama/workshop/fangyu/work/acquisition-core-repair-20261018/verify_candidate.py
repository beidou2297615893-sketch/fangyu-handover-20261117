"""Verify actual unified paths with unchanged release/CLI/license validators.

No process, platform/network operation or business database construction.
"""
from pathlib import Path
from copy import deepcopy
from types import SimpleNamespace
import hashlib
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
P = HERE.parents[1]
OUT = HERE / 'candidate-core-v4'
PROJECT = OUT / 'project'
CHECKS = []


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check(name, condition):
    if not condition:
        raise AssertionError(name)
    CHECKS.append(name)


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def audit(event, args):
    if event.startswith(('subprocess.', 'os.spawn', 'os.exec')) or event in ('os.system', 'socket.connect', 'socket.getaddrinfo'):
        raise AssertionError('verification forbids process/network: ' + event)


def main():
    sys.addaudithook(audit)
    pins = json.loads((OUT / 'UNIFIED-PINS.json').read_text('utf-8'))
    for item in pins['files']:
        path = PROJECT / item['path']
        if not path.is_file() or path.stat().st_size != item['bytes'] or sha(path) != item['sha256']:
            raise AssertionError('unified pin mismatch: ' + item['path'])
    check('all_actual_file_pins', len(pins['files']) >= 2180)
    staged = json.loads((OUT / 'STAGED.json').read_text('utf-8'))
    release = Path(staged['release'])
    host = load('unified_original_host', release / 'ui_native_host.py')
    manifest, files = host.verify_release(release, staged['manifest_sha256'])
    source = host.verify_backend_dependencies(release, files, PROJECT)
    check('original_release_and_all_canonical_dependency_pins', source == PROJECT / 'work/ui-runtime-r55/src')
    dep = json.loads((release / 'resources/backend-dependencies.json').read_text('utf-8'))
    indexed = {item['path']: item for item in dep['files']}
    for name in ('core/acquisition_receipts.py', 'core/xhs_identity_recovery.py', 'assistant/browser_session_commit.py'):
        check('parent_manifest_' + name, name in indexed and indexed[name]['sha256'].lower() == sha(source / name))
        check('app_r55_protocol_pair_' + name, sha(source / name) == sha(PROJECT / 'work/app/src' / name))
    check('new_canonical_cli_wrapper', sha(source / 'platform_cli.py') == sha(PROJECT / 'work/app/src/platform_cli.py'))
    # Import the actual staged selector, then the original vendor modules through it.
    runtime = load('unified_original_platform_runtime', release / 'resources/platform-runtime/platform_runtime.py')
    app, service = runtime._modules(PROJECT)
    cli = PROJECT / 'work/login-cli-refresh-20261018/component/artifacts/platform-cli-guarded'
    check('actual_runtime_selector_resolves_candidate', Path(app.__FANGYU_GUARDED_CLI_RUNTIME_ROOT__) == cli)
    check('original_guard_body_unchanged', sha(Path(app.__file__)) == sha(P / 'work/shared-backend-integration/vendor-src/app.py'))
    company = json.loads((PROJECT / 'work/app/company.json').read_text('utf-8'))
    old_company = json.loads((P / 'work/app/company.json').read_text('utf-8-sig'))
    employee = sys.modules['assistant.employee_distribution']
    check('actual_candidate_company_valid', employee.workbench_source_config_valid(company) is True)
    check('actual_candidate_original_cli_guard', app.guarded_cli_runtime_valid(cli / 'platform-cli.exe', cli / 'guard-manifest.json', company) is True)
    check('old_company_pin_rejected', app.guarded_cli_runtime_valid(cli / 'platform-cli.exe', cli / 'guard-manifest.json', old_company) is False)
    old_guard = P / 'work/overnight-platforms-20261014/runtime-integration-candidate/guarded-cli/guard-manifest.json'
    check('old_cli_manifest_rejected', app.guarded_cli_runtime_valid(cli / 'platform-cli.exe', old_guard, company) is False)
    no_hold = deepcopy(company)
    no_hold['runtime']['public_send_hold'] = False
    check('missing_public_send_hold_rejected', app.guarded_cli_runtime_valid(cli / 'platform-cli.exe', cli / 'guard-manifest.json', no_hold) is False)
    # All source and component declarations stay technical facts, not approval.
    from core.runtime_license_policy import RuntimeLicensePolicy
    guard = json.loads((cli / 'guard-manifest.json').read_text('utf-8'))
    pending = {'schema_version': 1, 'kind': 'runtime_component_use_review',
        'company_id': company['id'], 'route': 'guarded_cli_v1', 'usage_scope': 'internal_self_use_read',
        'artifact': {'wrapper_sha256': guard['source_sha256'], 'exe_sha256': guard['exe_sha256'],
                     'runtime_tree_sha256': guard['runtime_tree_sha256'], 'guard_manifest_sha256': sha(cli / 'guard-manifest.json')},
        'materials': {key: None for key in ('license_text', 'component_notice', 'actual_dependency_inventory', 'review_evidence')},
        'review': {'decision': 'pending', 'revision': 'unified-technical-verification-pending', 'reviewed_at': None, 'reviewer_ref': None}}
    def forbidden_validator(*_args):
        raise AssertionError('pending license attempted runtime approval')
    for name, review in [('missing', None), ('pending', pending)]:
        policy = RuntimeLicensePolicy(review, server=SimpleNamespace(company=company),
            source_wrapper=source / 'platform_cli.py', material_root=OUT,
            usage_scope='internal_self_use_read', runtime_validator=forbidden_validator)
        check(name + '_license_never_grants', policy.resolve() is None)
    for name in ('assistant/private_evaluation.py', 'assistant/self_operating_read.py', 'core/runtime_license_policy.py'):
        check('unrelated_owner_policy_unchanged_' + name, sha(source / name) == sha(P / 'work/ui-runtime-r55/src' / name))
    # Fixed Douyin review: verify current disk facts only; this does not invoke identity JS.
    review_path = release / 'resources/platform-runtime/vendor-src/douyin-connection-review.json'
    review = json.loads(review_path.read_text('utf-8'))
    bridge = PROJECT / 'work/ui-runtime-r55/work/runtime/douyin-bridge'
    for item in review['materials']:
        root = source if item['root'] == 'source' else bridge
        path = root / item['path']
        if path.stat().st_size != item['bytes'] or sha(path).upper() != item['sha256']:
            raise AssertionError('fixed Douyin material mismatch: ' + item['path'])
    check('existing_fixed_douyin_materials_unchanged', True)
    result = {'status': 'PASS_ACTUAL_UNIFIED_ORIGINAL_VALIDATORS', 'checks': CHECKS,
        'unified_pin_sha256': sha(OUT / 'UNIFIED-PINS.json'), 'release': manifest['release_id'],
        'parent_py_dependencies': len(indexed), 'release_files': len(files),
        'component_use_policy': 'pending_no_grant', 'cli_executed': False, 'business_database_opened': False,
        'real_platform_calls': 0, 'promoted': False}
    (HERE / 'UNIFIED-VALIDATION.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', 'utf-8')
    print(json.dumps(result, ensure_ascii=False))


if __name__ == '__main__':
    main()

