"""Public rule documentation through real StoreMaterials.catalog; synthetic data only."""
from pathlib import Path
from types import SimpleNamespace
import hashlib
import json
import sys
import tempfile
import threading
import unittest

W = Path(__file__).resolve().parent
P = W.parents[1]
sys.dont_write_bytecode = True
sys.path.insert(0, str(P / 'work/ui-runtime-r55/src'))
sys.path.insert(0, str(P / 'work/ui-native-r57'))
from core.store import Store
from store_materials import StoreMaterials, StoreMaterialsError
from test_store_materials import fixture_catalog

SAFE_FIELDS = ('version', 'description', 'signals', 'budgetPrinciples', 'incomePrinciples',
               'currentPricesVerified', 'status', 'enabled', 'changesIntentPolicy')


class PublicRuleDocumentation(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='rules-fixture-', dir=W)
        self.directory = Path(self.temp.name)
        self.package = fixture_catalog()
        self.rule = {
            'version': 'synthetic-source-rule-v7', 'description': '真实源规则说明，不是provider提示词',
            'signals': ['真实求租语境信号', '否定与供应语境信号'],
            'budgetPrinciples': ['预算只用原话，不以未核房价比价'],
            'incomePrinciples': ['收入只保留本人自报，不由画像推算'],
            'currentPricesVerified': False, 'status': 'initial_rule_not_business_calibrated',
            'enabled': False, 'changesIntentPolicy': False,
            'privatePrompt': 'synthetic-private-prompt-must-not-project',
            'api_key': '[REDACTED:assigned_secret]',
        }
        self.package['intentRule'] = self.rule
        self.package.pop('digest', None)
        self.package['digest'] = hashlib.sha256(json.dumps(self.package, ensure_ascii=False,
            sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()
        self.path = self.directory / 'catalog.json'
        self.path.write_text(json.dumps(self.package, ensure_ascii=False), encoding='utf-8')
        self.core = SimpleNamespace(store=Store(self.directory / 'db'), lock=threading.RLock())
        self.user = {'id': 'fixture-user', 'tenant_id': 'fixture-tenant', 'username': 'fixture-operator',
                     'role': 'operator', 'cloud_bound': True, 'disabled': False}
        self.core.store.put('users', self.user)
        self.service = StoreMaterials(self.core, self.path)

    def tearDown(self):
        self.temp.cleanup()

    def catalog(self):
        return self.service.catalog(self.user, [{'id': 'fixture-store-a', 'name': '授权合成门店'}])

    def test_catalog_returns_real_public_rule_text_and_source_version(self):
        result = self.catalog()
        self.assertIn('intentRule', result, 'Catalog drops existing source rule documentation')
        self.assertEqual(result['intentRule'], {key: self.rule[key] for key in SAFE_FIELDS})
        self.assertEqual(result['intentRule']['version'], 'synthetic-source-rule-v7')

    def test_public_rule_projection_does_not_leak_extra_source_fields_or_mutate_package(self):
        before = json.dumps(self.service.package, ensure_ascii=False, sort_keys=True)
        result = self.catalog()
        self.assertIn('intentRule', result, 'Public rule projection is missing')
        encoded = json.dumps(result, ensure_ascii=False)
        self.assertFalse('synthetic-private-prompt-must-not-project' in encoded,
                         'Public catalog leaks an unapproved private source field')
        self.assertFalse('synthetic-secret-must-not-project' in encoded,
                         'Public catalog leaks an unapproved credential source field')
        result['intentRule']['signals'].append('caller mutation')
        self.assertEqual(json.dumps(self.service.package, ensure_ascii=False, sort_keys=True), before)

    def test_revoked_employee_cannot_read_even_public_rule_catalog(self):
        self.core.store.put('users', {**self.user, 'disabled': True})
        with self.assertRaises(StoreMaterialsError):
            self.catalog()


if __name__ == '__main__':
    unittest.main(verbosity=2)
