from pathlib import Path
import sqlite3,json
W=Path(__file__).resolve().parent
p=W/'gui-fixture/runs/8833b9e85370460ba0e0506033f2313b/data/workspace.sqlite3'
db=sqlite3.connect(p.as_uri()+'?mode=ro',uri=True,timeout=2)
db.execute('PRAGMA query_only=ON')
print(json.dumps(db.execute('SELECT entity,count(*) FROM records GROUP BY entity').fetchall()))
db.close()
