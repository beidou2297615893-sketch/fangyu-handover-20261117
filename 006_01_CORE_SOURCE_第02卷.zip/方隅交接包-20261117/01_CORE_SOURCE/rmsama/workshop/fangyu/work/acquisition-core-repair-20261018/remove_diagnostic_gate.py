from pathlib import Path
import shutil
W=Path(__file__).resolve().parent;P=W.parents[1]
name='work/ui-runtime-r55/src/core/engine.py';p=P/name;b=W/'before'/name
b.parent.mkdir(parents=True,exist_ok=True)
if not b.exists():shutil.copy2(p,b)
s=p.read_text('utf-8')
old="                    if allowed and task.get('platform')=='xiaohongshu':\n                        path=self.store.directory/'accounts'/task['tenant_id']/account['id']/'platform-activity.jsonl'\n                        allowed=summarize_activity(path).get('state')!='review_required'\n"
assert s.count(old)==1
s=s.replace(old,'')
p.write_text(s,'utf-8')
print('Only historical diagnostic I/O removed from continuation eligibility.')
