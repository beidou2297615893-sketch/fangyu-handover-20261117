"""Read only, tenant scoped copies of image URLs already saved on leads."""
from __future__ import annotations

import hashlib
import http.client
import io
import ipaddress
import os
import re
import socket
import ssl
import tempfile
import threading
import time
import warnings
from pathlib import Path
from types import SimpleNamespace
from urllib.parse import urlsplit

from core import CoreError
from .business import BusinessExecutor


MAX_BYTES = 3 * 1024 * 1024
MAX_PIXELS = 8_000_000
MAX_EDGE = 4096
MAX_CACHE_FILES = 2000
MAX_CACHE_BYTES = 128 * 1024 * 1024
FETCH_SECONDS = 6
NEGATIVE_SECONDS = 15 * 60
MIME_FORMATS = {'image/jpeg': ('JPEG', '.jpg'),
                'image/png': ('PNG', '.png'),
                'image/webp': ('WEBP', '.webp')}
LEAD_ID = re.compile(r'(?:[0-9a-fA-F]{32}|[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12})\Z')
_FETCH_SLOTS = threading.BoundedSemaphore(3)
_KEY_LOCKS = [threading.Lock() for _ in range(32)]


class MediaUnavailable(ValueError):
    """A missing, invalid or temporarily unavailable saved image."""


class MediaForbidden(ValueError):
    """The signed in employee cannot read this lead."""


def _allowed(core, user, lead):
    try:
        BusinessExecutor._lead_access(SimpleNamespace(core=core, tenant=user['tenant_id']), user, lead)
    except (CoreError, KeyError, TypeError) as exc:
        raise MediaForbidden('头像不可访问') from exc


def _saved_url(core, user, lead, kind):
    """Choose one unambiguous URL for exactly the same stable platform identity."""
    if lead.get('platform') != 'xiaohongshu':
        raise MediaUnavailable('头像暂不可用')
    if kind == 'cover':
        # A cover belongs to this exact saved post/comment. Never borrow a
        # different post just because its commenter is the same customer.
        direct=lead.get('content_cover_url')
        if not direct:raise MediaUnavailable('原帖图片暂不可用')
        return direct
    if kind == 'author':
        identity = lead.get('author_id')
        field = 'author_avatar_url'
    elif kind == 'post_author':
        identity = lead.get('content_author_id')
        field = 'content_author_avatar_url'
    else:
        raise MediaUnavailable('头像暂不可用')
    direct = lead.get(field)
    if direct:
        return direct
    if not isinstance(identity, str) or not identity.strip():
        raise MediaUnavailable('头像暂不可用')
    # Cross-comment reuse requires the same explicit account, not merely a
    # matching author ID from another employee's platform account.
    try:
        target_task = core._get('tasks', lead.get('task_id'), user['tenant_id'])
        account_id = target_task.get('account_id')
    except CoreError as exc:
        raise MediaUnavailable('头像暂不可用') from exc
    if not account_id:
        raise MediaUnavailable('头像暂不可用')
    candidates = set()
    for item in core.store.list('leads', user['tenant_id']):
        if item.get('platform') != lead['platform']:
            continue
        try:
            _allowed(core, user, item)
        except MediaForbidden:
            continue
        try:
            task = core._get('tasks', item.get('task_id'), user['tenant_id'])
        except CoreError:
            continue
        if task.get('account_id') != account_id:
            continue
        if item.get('author_id') == identity and item.get('author_avatar_url'):
            candidates.add(item['author_avatar_url'])
        if item.get('content_author_id') == identity and item.get('content_author_avatar_url'):
            candidates.add(item['content_author_avatar_url'])
    if len(candidates) != 1:
        raise MediaUnavailable('头像暂不可用')
    return next(iter(candidates))


def _image_url(value):
    if not isinstance(value, str) or not value or len(value) > 2048 or re.search(r'\s', value):
        raise MediaUnavailable('头像地址无效')
    try:
        parsed = urlsplit(value)
        host = (parsed.hostname or '').lower()
        port = parsed.port
    except ValueError as exc:
        raise MediaUnavailable('头像地址无效') from exc
    if (parsed.scheme != 'https' or port not in (None, 443) or parsed.username or parsed.password
            or parsed.fragment or not parsed.path or not host.endswith('.xhscdn.com')):
        raise MediaUnavailable('头像地址无效')
    return parsed, host


def _public_address(host):
    try:
        addresses = {ipaddress.ip_address(info[4][0]) for info in
                     socket.getaddrinfo(host, 443, type=socket.SOCK_STREAM)}
    except (OSError, ValueError) as exc:
        raise MediaUnavailable('头像暂不可用') from exc
    if not addresses or any(not address.is_global for address in addresses):
        raise MediaUnavailable('头像地址无效')
    return str(sorted(addresses, key=lambda address: (address.version, str(address)))[0])


def _fetch(parsed, host):
    """No cookies, proxy, redirect or second DNS lookup during connection."""
    deadline = time.monotonic() + FETCH_SECONDS
    ip = _public_address(host)
    remaining = deadline - time.monotonic()
    if remaining <= 0:
        raise MediaUnavailable('头像暂不可用')
    connection = http.client.HTTPSConnection(host, 443, timeout=remaining,
                                             context=ssl.create_default_context())
    connection._create_connection = lambda address, timeout, source_address=None: (
        socket.create_connection((ip, 443), min(timeout, max(.1, deadline-time.monotonic())), source_address))
    try:
        path = parsed.path + ('?' + parsed.query if parsed.query else '')
        connection.request('GET', path, headers={'Accept': ', '.join(MIME_FORMATS),
                                                 'Accept-Encoding': 'identity',
                                                 'User-Agent': 'FangyuSavedAvatar/1.0'})
        response = connection.getresponse()
        if response.status == 404:
            raise FileNotFoundError('saved avatar returned 404')
        # A partial response, including 206, cannot be persisted as a complete image.
        if response.status != 200:
            raise MediaUnavailable('头像暂不可用')
        mime = response.getheader('Content-Type', '').split(';', 1)[0].strip().lower()
        if mime not in MIME_FORMATS or response.getheader('Content-Encoding', 'identity').lower() != 'identity':
            raise MediaUnavailable('头像格式无效')
        declared = response.getheader('Content-Length')
        if declared is not None:
            try:
                if int(declared) < 1 or int(declared) > MAX_BYTES:
                    raise MediaUnavailable('头像过大')
            except ValueError as exc:
                raise MediaUnavailable('头像大小无效') from exc
        chunks = []
        size = 0
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise MediaUnavailable('头像暂不可用')
            if connection.sock:
                connection.sock.settimeout(remaining)
            part = response.read(min(64 * 1024, MAX_BYTES + 1 - size))
            if not part:
                break
            size += len(part)
            if size > MAX_BYTES:
                raise MediaUnavailable('头像过大')
            chunks.append(part)
        if not size or (declared is not None and size != int(declared)):
            raise MediaUnavailable('头像内容不完整')
        return b''.join(chunks), mime
    except FileNotFoundError:
        raise
    except (OSError, http.client.HTTPException) as exc:
        raise MediaUnavailable('头像暂不可用') from exc
    finally:
        connection.close()


def _verify_image(body, mime):
    """Pillow verifies the full stream, then decodes all pixels within limits."""
    if not isinstance(body, bytes) or not 0 < len(body) <= MAX_BYTES or mime not in MIME_FORMATS:
        raise MediaUnavailable('头像格式无效')
    try:
        from PIL import Image, UnidentifiedImageError
    except ImportError as exc:
        raise MediaUnavailable('图片解码库不可用') from exc
    expected, suffix = MIME_FORMATS[mime]
    try:
        with warnings.catch_warnings():
            warnings.simplefilter('error', Image.DecompressionBombWarning)
            with Image.open(io.BytesIO(body), formats=[expected]) as image:
                if (image.format != expected or getattr(image, 'n_frames', 1) != 1
                        or image.width < 1 or image.height < 1
                        or image.width > MAX_EDGE or image.height > MAX_EDGE
                        or image.width * image.height > MAX_PIXELS):
                    raise MediaUnavailable('头像格式无效')
                image.verify()
            with Image.open(io.BytesIO(body), formats=[expected]) as image:
                if image.format != expected or getattr(image, 'n_frames', 1) != 1:
                    raise MediaUnavailable('头像格式无效')
                image.load()
    except (OSError, ValueError, SyntaxError, Image.DecompressionBombWarning,
            Image.DecompressionBombError, UnidentifiedImageError) as exc:
        raise MediaUnavailable('头像格式无效') from exc
    return suffix


def _cache_root(core, tenant):
    root = Path(core.store.directory) / 'media' / 'saved-avatars'
    return root / hashlib.sha256(tenant.encode()).hexdigest()[:24]


def _atomic(path, body):
    path.parent.mkdir(parents=True, exist_ok=True)
    name = None
    try:
        with tempfile.NamedTemporaryFile(dir=path.parent, prefix='.avatar-', delete=False) as stream:
            name = stream.name
            stream.write(body)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(name, path)
    finally:
        if name and os.path.exists(name):
            os.unlink(name)


def _cache_has_room(root, size):
    if not root.exists():
        return True
    count = 0
    total = 0
    for path in root.iterdir():
        if path.is_symlink():
            return False
        if not path.is_file():
            continue
        count += 1
        total += path.stat().st_size
        if count >= MAX_CACHE_FILES or total + size > MAX_CACHE_BYTES:
            return False
    return True


def _still_allowed(core, user, lead_id, kind, url):
    try:
        current = core._get('leads', lead_id, user['tenant_id'])
    except CoreError as exc:
        raise MediaForbidden('头像不可访问') from exc
    _allowed(core, user, current)
    if _saved_url(core, user, current, kind) != url:
        raise MediaUnavailable('头像资料已变化')


def saved_avatar(core, user, lead_id, kind, fetcher=_fetch):
    """Return verified bytes and MIME after current session/lead checks in the handler."""
    if not isinstance(lead_id, str) or not LEAD_ID.fullmatch(lead_id) or kind not in ('author', 'post_author','cover'):
        raise MediaUnavailable('头像暂不可用')
    if not user or not user.get('tenant_id'):
        raise MediaForbidden('头像不可访问')
    try:
        lead = core._get('leads', lead_id, user['tenant_id'])
    except CoreError as exc:
        raise MediaForbidden('头像不可访问') from exc
    _allowed(core, user, lead)
    url = _saved_url(core, user, lead, kind)
    parsed, host = _image_url(url)
    key = hashlib.sha256((user['tenant_id'] + '\n' + url).encode()).hexdigest()
    root = _cache_root(core, user['tenant_id'])
    lock = _KEY_LOCKS[int(key[:2], 16) % len(_KEY_LOCKS)]
    with lock:
        for mime, (_, suffix) in MIME_FORMATS.items():
            path = root / (key + suffix)
            if path.is_symlink():
                raise MediaUnavailable('头像缓存无效')
            try:
                if path.stat().st_size > MAX_BYTES:
                    raise MediaUnavailable('头像缓存无效')
                body = path.read_bytes()
            except FileNotFoundError:
                continue
            except OSError as exc:
                raise MediaUnavailable('头像缓存无效') from exc
            _verify_image(body, mime)
            _still_allowed(core, user, lead_id, kind, url)
            return body, mime
        negative = root / (key + '.missing')
        try:
            if not negative.is_symlink() and time.time() - negative.stat().st_mtime < NEGATIVE_SECONDS:
                raise MediaUnavailable('头像暂不可用')
        except FileNotFoundError:
            pass
        if not _FETCH_SLOTS.acquire(timeout=1):
            raise MediaUnavailable('头像暂不可用')
        try:
            try:
                body, mime = fetcher(parsed, host)
            except FileNotFoundError as exc:
                if _cache_has_room(root, 3):
                    _atomic(negative, b'404')
                raise MediaUnavailable('头像暂不可用') from exc
            suffix = _verify_image(body, mime)
            if not _cache_has_room(root, len(body)):
                raise MediaUnavailable('头像缓存已达上限')
            _atomic(root / (key + suffix), body)
            _still_allowed(core, user, lead_id, kind, url)
            return body, mime
        finally:
            _FETCH_SLOTS.release()
