"""Actual Runtime page-AI seam; synthetic Store and strict fake external AI only.

Does not construct PlatformRuntime/AppServer, open a DB, use credentials, call a
platform/provider, or implement LocalAIWorkflow/attempt/cache internals. Its fake
analyze boundary persists synthetic results so the Runtime must re-read reality.
"""
from copy import deepcopy
import hashlib
from pathlib import Path
import sys
import threading
import types
import unittest

W = Path(__file__).resolve().parent
P = W.parents[1]
sys.path.insert(0, str(P / 'work/shared-backend-integration'))
sys.path.insert(0, str(P / 'work/ui-runtime-r55/src'))
from platform_runtime import COMPANY_ID, PlatformRuntime, PlatformRuntimeError
from assistant.ai_workflow import post_identity


class Store:
    def __init__(self):
        self.rows = {}

    def get(self, entity, ident):
        return deepcopy(self.rows.get((entity, ident)))

    def put(self, entity, row):
        self.rows[entity, row['id']] = deepcopy(row)

    def list(self, entity, tenant=None):
        return [deepcopy(row) for (kind, _), row in self.rows.items()
                if kind == entity and (tenant is None or row.get('tenant_id') == tenant)]


class BoundaryFailure(ValueError):
    code = 'AI_BILLING_UNKNOWN'


class FakeCore:
    def __init__(self, store):
        self.store, self.lock = store, threading.RLock()

    @staticmethod
    def _public(row):
        return deepcopy(row)

    def _get(self, entity, ident, tenant):
        row = self.store.get(entity, ident)
        if not row or row.get('tenant_id') != tenant:
            raise ValueError('fixture row outside tenant')
        return row

    def _task_access(self, user, task, tenant):
        if (user.get('tenant_id') != tenant or task.get('tenant_id') != tenant
                or task.get('cloud_owner') != user.get('username')):
            raise ValueError('fixture task outside actor')


class FakeAI:
    def __init__(self, case, store):
        self.case, self.store = case, store
        self.profile = {'enabled': True, 'configured': True, 'revision': 7,
                        'rules_version': 'synthetic-policy-v7',
                        'provider': 'fixture', 'model': 'not-a-real-model'}
        self.profile_reads, self.calls = [], []
        self.failure, self.after_analyze = None, None

    def cloud(self, user, operation, data):
        self.case.assertEqual(operation, 'ai_profile', 'No other cloud boundary is authorized')
        self.case.assertEqual(data, {})
        self.profile_reads.append(deepcopy(user))
        return {'config': deepcopy(self.profile)}

    def analyze(self, user, task, rows, replace_existing=False,
                expected_profile=None, explicit_retry=False):
        self.case.assertFalse(replace_existing, 'Automatic page flow cannot regrade')
        self.case.assertFalse(explicit_retry, 'Automatic page flow cannot grant a new paid retry')
        self.case.assertLessEqual(len(rows), 20)
        self.case.assertGreater(len(rows), 0)
        self.case.assertEqual(len({post_identity(row) for row in rows}), 1)
        self.calls.append([row['id'] for row in rows])
        for row in rows:
            self.case.assertEqual(row['task_id'], task['id'])
            self.case.assertEqual(row['tenant_id'], user['tenant_id'])
            self.case.assertEqual(row['cloud_owner'], user['username'])
        if self.failure:
            raise self.failure
        for index, row in enumerate(rows):
            current = self.store.get('leads', row['id'])
            status = ('graded', 'uncertain', 'unrelated')[index % 3]
            current['ai_intent'] = {'status': status,
                                    'level': 'high' if status == 'graded' else None,
                                    'provider': 'fixture', 'model': 'not-a-real-model',
                                    'rules_version': self.profile['rules_version']}
            current['analysis_status'] = status
            self.store.put('leads', current)
        if self.after_analyze:
            self.after_analyze(len(self.calls))
        return {'analyzed': len(rows), 'cache_hits': 0,
                'provider': 'fixture', 'model': 'not-a-real-model'}


class SynchronousAIContract(unittest.TestCase):
    def fixture(self):
        runtime = object.__new__(PlatformRuntime)
        runtime.closed = False
        runtime._run_lock = threading.RLock()
        runtime._run_cancels = {}
        environment = 'synthetic-review-environment'
        tenant = 'cloud-' + hashlib.sha256((environment + '\n' + COMPANY_ID).encode()).hexdigest()[:24]
        user = {'id': 'fixture-employee', 'username': 'fixture-owner', 'tenant_id': tenant,
                'role': 'admin', 'cloud_bound': True, '_workbench_store_id': 'fixture-store'}
        task = {'id': 'fixture-task', 'tenant_id': tenant, 'cloud_owner': user['username'],
                'store_id': user['_workbench_store_id'], 'platform': 'xiaohongshu',
                'account_id': 'fixture-account', 'scope': 'search_comments', 'status': 'ready',
                'city': '上海', 'area': '古北', 'keywords': ['古北租房'],
                'comment_keyword_mode': 'all', 'continuous_enabled': False}
        store = Store()
        store.put('users', user)
        store.put('tasks', task)
        runtime.core = FakeCore(store)
        runtime.server = types.SimpleNamespace(company={'id': COMPANY_ID,
                'managedWorkspace': {'environment_id': environment}})
        ai = FakeAI(self, store)
        visibility_calls = []

        def visible(actor, current_task, rows=None):
            self.assertIsNotNone(rows, 'Page analysis must not scan the whole old task backlog')
            runtime.core._task_access(actor, current_task, actor['tenant_id'])
            visibility_calls.append([row['id'] for row in rows])
            return iter([deepcopy(row) for row in rows
                         if row.get('tenant_id') == actor['tenant_id']
                         and row.get('task_id') == current_task['id']
                         and row.get('cloud_owner') in (None, actor['username'])])

        executor = types.SimpleNamespace(ai=ai, _analysis_visible_leads=visible,
                core=runtime.core, owner=user['username'], tenant=tenant, user_id=user['id'])

        def owned_executor(actor, **kwargs):
            current = runtime._principal(actor)
            self.assertEqual(current['id'], executor.user_id)
            self.assertEqual(current['username'], executor.owner)
            self.assertEqual(current['tenant_id'], executor.tenant)
            return executor

        runtime._executor = owned_executor
        runtime.service = types.SimpleNamespace(executor=executor, closed=False, state='online')
        return runtime, executor, user, task, store, ai, visibility_calls

    @staticmethod
    def lead(task, ident, post='post-one', **changes):
        return {'id': ident, 'tenant_id': task['tenant_id'], 'task_id': task['id'],
                'cloud_owner': task['cloud_owner'], 'platform': task['platform'],
                'text': '本人求租一居室，预算六千', 'content_title': '古北租房讨论',
                'content_author': 'fixture-author',
                'note_url': 'https://www.xiaohongshu.com/explore/' + post, **changes}

    def invoke(self, fixture, ids):
        runtime, executor, user, task, *_ = fixture
        # Missing method is an intentional RED, rather than a fake replacement.
        return runtime._analyze_collection_page(executor, user, task['id'], ids)

    def test_all_page_groups_are_drained_in_same_post_batches_at_most_twenty(self):
        f = self.fixture()
        *_, task, store, ai, visibility = f
        ids = []
        for post, count in (('one', 31), ('two', 22)):
            for index in range(count):
                ident = f'{post}-{index}'
                store.put('leads', self.lead(task, ident, post))
                ids.append(ident)
        self.invoke(f, ids)
        actual = [ident for batch in ai.calls for ident in batch]
        self.assertCountEqual(actual, ids)
        self.assertEqual(len(actual), len(set(actual)))
        self.assertEqual(len(ai.calls), 4)
        self.assertTrue(visibility)
        self.assertTrue(all(store.get('leads', ident).get('ai_intent') for ident in ids))

    def test_only_this_page_owned_unfinished_rows_are_sent(self):
        f = self.fixture()
        *_, task, store, ai, _ = f
        entries = [('valid', {}), ('demo', {'demo': True}),
                   ('manual', {'manual_intent': {'status': 'graded', 'level': 'high'}}),
                   ('complete', {'ai_intent': {'status': 'unrelated', 'level': None}}),
                   ('missing', {'text': ''}), ('foreign-owner', {'cloud_owner': 'other'}),
                   ('foreign-task', {'task_id': 'other-task'}),
                   ('foreign-tenant', {'tenant_id': 'other-tenant'})]
        for ident, changes in entries:
            store.put('leads', self.lead(task, ident, **changes))
        store.put('leads', self.lead(task, 'old-unfinished-backlog'))
        self.invoke(f, [ident for ident, _ in entries] + ['valid', 'absent'])
        self.assertEqual(ai.calls, [['valid']])
        self.assertIsNone(store.get('leads', 'old-unfinished-backlog').get('ai_intent'))
        self.assertEqual(store.get('leads', 'manual')['manual_intent']['level'], 'high')
        self.assertEqual(store.get('leads', 'complete')['ai_intent']['status'], 'unrelated')

    def test_disabled_profile_is_pending_without_model_submission(self):
        self.profile_block(enabled=False, configured=True, code='AI_DISABLED')

    def test_unconfigured_profile_is_pending_without_model_submission(self):
        self.profile_block(enabled=True, configured=False, code='AI_NOT_CONFIGURED')

    def profile_block(self, *, enabled, configured, code):
        f = self.fixture()
        *_, task, store, ai, _ = f
        store.put('leads', self.lead(task, 'waiting'))
        ai.profile.update(enabled=enabled, configured=configured)
        self.invoke(f, ['waiting'])
        self.assertEqual(ai.calls, [])
        job = store.get('ai_jobs', task['id'])
        self.assertIsNotNone(job)
        self.assertEqual(job['tenant_id'], task['tenant_id'])
        self.assertEqual(job['code'], code)
        self.assertEqual(job['status'], 'pending')
        self.assertGreaterEqual(job.get('pending', 0), 1)
        self.assertIsNone(store.get('leads', 'waiting').get('ai_intent'))

    def test_unknown_paid_outcome_is_not_retried_or_forged_complete(self):
        f = self.fixture()
        *_, task, store, ai, _ = f
        for index in range(21):
            store.put('leads', self.lead(task, f'waiting-{index}'))
        ai.failure = BoundaryFailure('synthetic uncertain result; no real call')
        try:
            self.invoke(f, [f'waiting-{index}' for index in range(21)])
        except (BoundaryFailure, PlatformRuntimeError):
            pass
        self.assertEqual(len(ai.calls), 1)
        self.assertTrue(all(not store.get('leads', f'waiting-{i}').get('ai_intent') for i in range(21)))
        job = store.get('ai_jobs', task['id'])
        self.assertIsNotNone(job)
        self.assertEqual(job['code'], 'AI_BILLING_UNKNOWN')
        self.assertIn(job['status'], ('pending', 'paused'))

    def test_store_switch_between_groups_stops_later_model_submissions(self):
        self.scope_switch('store')

    def test_actor_disabled_between_groups_stops_later_model_submissions(self):
        self.scope_switch('actor')

    def test_unresolved_billing_still_blocks_when_page_rows_already_look_complete(self):
        f=self.fixture()
        *_,task,store,ai,_=f
        store.put('leads',self.lead(task,'completed',ai_intent={'status':'graded','level':'high'}))
        store.put('ai_jobs',{'id':task['id'],'tenant_id':task['tenant_id'],'status':'paused','code':'AI_BILLING_UNKNOWN'})
        with self.assertRaises(PlatformRuntimeError):self.invoke(f,['completed'])
        self.assertEqual(ai.calls,[])
        self.assertEqual(store.get('ai_jobs',task['id'])['code'],'AI_BILLING_UNKNOWN')

    def scope_switch(self, kind):
        f = self.fixture()
        *_, task, store, ai, _ = f
        ids = [f'row-{index}' for index in range(21)]
        for ident in ids:
            store.put('leads', self.lead(task, ident))

        def switch(call_count):
            if call_count != 1:
                return
            if kind == 'store':
                current = store.get('tasks', task['id'])
                current['store_id'] = 'different-store'
                store.put('tasks', current)
            else:
                current = store.get('users', f[2]['id'])
                current['disabled'] = True
                store.put('users', current)

        ai.after_analyze = switch
        try:
            self.invoke(f, ids)
        except (ValueError, PlatformRuntimeError):
            pass
        self.assertEqual(len(ai.calls), 1)
        self.assertEqual(sum(bool(store.get('leads', ident).get('ai_intent')) for ident in ids), 20)


if __name__ == '__main__':
    unittest.main(verbosity=2)
