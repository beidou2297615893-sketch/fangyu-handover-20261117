"""Bounded, credential-free lifecycle events. Diagnostic failures never abort work."""
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import re
import stat
import sys
import threading

MAX_BYTES = 1024 * 1024
_LOCK = threading.RLock()
STAGES = frozenset(('launcher_start', 'manifest_verified', 'host_import_started',
    'host_imported', 'host_main_start', 'launcher_exit', 'launcher_failed', 'host_start',
    'host_verified', 'workspace_bound', 'runtime_start', 'runtime_ready', 'runtime_failed',
    'shutdown_start', 'shutdown_complete', 'native_opening', 'native_ready', 'native_closed',
    'native_failed', 'native_process_failed', 'native_diagnostic_unavailable',
    'unhandled_exception', 'thread_exception', 'unraisable_exception', 'startup_timeout'))
ERROR_TYPES = frozenset(('UIHostError', 'WorkspaceBindingError', 'RuntimeRequestError',
    'RuntimeError', 'ValueError', 'TypeError', 'OSError', 'ImportError', 'ModuleNotFoundError',
    'FileNotFoundError', 'PermissionError', 'TimeoutError', 'MemoryError', 'AssertionError',
    'KeyboardInterrupt', 'SystemExit'))
ERROR_CODES = frozenset(('WORKSPACE_BINDING_MISSING', 'WORKSPACE_BINDING_UNAVAILABLE',
    'WORKSPACE_BINDING_INVALID', 'WORKSPACE_BINDING_PATH_INVALID', 'WORKSPACE_BINDING_CHANGED',
    'WORKSPACE_BINDING_DATA_UNAVAILABLE', 'WORKSPACE_BINDING_DEVICE_MISMATCH',
    'WORKSPACE_IN_USE', 'AUTH_REQUIRED', 'STARTUP_FAILED', 'NATIVE_PROCESS_FAILED'))
PROCESS_KINDS = frozenset(('BrowserProcessExited', 'RenderProcessExited',
    'RenderProcessUnresponsive', 'FrameRenderProcessExited', 'UtilityProcessExited',
    'SandboxHelperProcessExited', 'GpuProcessExited', 'PpapiPluginProcessExited',
    'PpapiBrokerProcessExited', 'UnknownProcessExited'))


def _plain(path, *, directory=False):
    for item in (path, *path.parents):
        info = item.lstat()
        if item.is_symlink() or getattr(info, 'st_file_attributes', 0) & 0x400:
            raise OSError('diagnostic_path_unavailable')
    info = path.stat()
    if directory:
        if not stat.S_ISDIR(info.st_mode):
            raise OSError('diagnostic_path_unavailable')
    elif not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
        raise OSError('diagnostic_path_unavailable')


class LifecycleLog:
    def __init__(self, state_root, release_id, *, max_bytes=MAX_BYTES):
        self.directory = Path(state_root) / 'lifecycle'
        self.release_id = release_id if isinstance(release_id, str) and re.fullmatch(
            r'(?:ui-r57-\d{8}T\d{6}Z-[0-9a-f]{8}|owned-test|fixture-[A-Za-z0-9_-]{1,30})', release_id) else 'unknown'
        self.max_bytes = max(256, min(MAX_BYTES, int(max_bytes)))

    def record(self, stage, *, error=None, traceback=None, instance_id='', kind=None, exit_code=None):
        """Accept fixed fields only; exception text, locals and objects are never serialized."""
        try:
            row = {'schema': 'fangyu-lifecycle-v1',
                'utc': datetime.now(timezone.utc).isoformat(timespec='milliseconds'),
                'pid': os.getpid(), 'parent_pid': os.getppid(), 'release': self.release_id,
                'stage': stage if stage in STAGES else 'unknown'}
            if isinstance(instance_id, str) and re.fullmatch(r'[0-9a-f]{32}', instance_id):
                row['instance_id'] = instance_id
            if error is not None:
                name = type(error).__name__
                row['error_type'] = name if name in ERROR_TYPES else 'OtherError'
                code = getattr(error, 'code', '')
                if isinstance(code, str) and code in ERROR_CODES:
                    row['error_code'] = code
                tb = traceback if traceback is not None else getattr(error, '__traceback__', None)
                if tb is not None:
                    while tb.tb_next is not None:
                        tb = tb.tb_next
                    name = Path(tb.tb_frame.f_code.co_filename).name
                    if re.fullmatch(r'[A-Za-z0-9_.-]{1,100}\.py', name):
                        row['source_file'] = name
                        row['source_line'] = max(0, min(10000000, int(tb.tb_lineno)))
            if isinstance(kind, str) and kind in PROCESS_KINDS:
                row['process_kind'] = kind
            if type(exit_code) is int and -(2**31) <= exit_code < 2**32:
                row['exit_code'] = exit_code
            raw = (json.dumps(row, ensure_ascii=True, separators=(',', ':')) + '\n').encode('utf-8')
            if len(raw) > self.max_bytes:
                return False
            with _LOCK:
                # Check existing ancestors before creating the instance's log directory.
                for parent in (self.directory, *self.directory.parents):
                    if parent.exists():
                        _plain(parent, directory=True)
                self.directory.mkdir(parents=True, exist_ok=True)
                _plain(self.directory, directory=True)
                guard_path = self.directory / '.write.lock'
                if guard_path.exists() or guard_path.is_symlink():
                    _plain(guard_path)
                with guard_path.open('a+b') as guard:
                    guard.seek(0)
                    if not guard.read(1):
                        guard.write(b'0')
                        guard.flush()
                    guard.seek(0)
                    locked = False
                    try:
                        if os.name == 'nt':
                            import msvcrt
                            msvcrt.locking(guard.fileno(), msvcrt.LK_NBLCK, 1)
                            locked = True
                        target = self.directory / 'lifecycle.jsonl'
                        paths = [target, target.with_name('lifecycle.jsonl.1'), target.with_name('lifecycle.jsonl.2')]
                        for path in paths:
                            if path.exists() or path.is_symlink():
                                _plain(path)
                        if target.exists() and target.stat().st_size + len(raw) > self.max_bytes:
                            if paths[2].exists():
                                paths[2].unlink()
                            if paths[1].exists():
                                os.replace(paths[1], paths[2])
                            os.replace(target, paths[1])
                        with target.open('ab') as stream:
                            stream.write(raw)
                    finally:
                        if locked:
                            guard.seek(0)
                            msvcrt.locking(guard.fileno(), msvcrt.LK_UNLCK, 1)
            return True
        except Exception:
            return False


class _Hooks:
    def __init__(self, previous, current):
        self.previous, self.current = previous, current

    def restore(self):
        for name, before, installed in zip(('excepthook', 'unraisablehook'),
                self.previous[:2], self.current[:2]):
            if getattr(sys, name) is installed:
                setattr(sys, name, before)
        if threading.excepthook is self.current[2]:
            threading.excepthook = self.previous[2]


def install_hooks(log):
    """No original exception text is emitted by these process-local hooks."""
    previous = (sys.excepthook, sys.unraisablehook, threading.excepthook)

    def emit(stage, error, tb):
        try:
            log.record(stage, error=error, traceback=tb)
        except Exception:
            pass

    def uncaught(exc_type, error, tb):
        emit('unhandled_exception', error, tb)

    def unraisable(args):
        emit('unraisable_exception', args.exc_value, args.exc_traceback)

    def thread_failed(args):
        emit('thread_exception', args.exc_value, args.exc_traceback)

    sys.excepthook, sys.unraisablehook, threading.excepthook = uncaught, unraisable, thread_failed
    return _Hooks(previous, (uncaught, unraisable, thread_failed))
