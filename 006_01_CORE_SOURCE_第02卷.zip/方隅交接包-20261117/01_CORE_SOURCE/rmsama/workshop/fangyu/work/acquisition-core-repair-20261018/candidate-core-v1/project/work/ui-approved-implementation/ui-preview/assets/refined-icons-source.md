# 精修图标来源

来源为已验许可的本地 Lucide 6bc1373b3f30 快照，官方 https://github.com/lucide-icons/lucide ，保留同目录 lucide-LICENSE.txt。

- icon-arrow-right.svg：原 icons/arrow-right.svg，登录按钮对应原图箭头。
- icon-message-square-more.svg：原 icons/message-square-more.svg，侧栏回复图标。
- icon-play-filled.svg：原 icons/play.svg，只将 fill="none" 改成 fill="currentColor"；原路径几何未改，匹配原图实心播放标志。

未添加手绘图形、外部图标库或运行依赖。
