/* Local business forms. No platform send, automatic receipt or role grant. */
const {replyTones,voluntaryContactDraft}=await import(new URL('?asset=upgrade-model.mjs',import.meta.url));
const {handoffExportFile}=await import(new URL('?asset=handoff-export-file.mjs',import.meta.url));
const {createIntentRuleUI}=await import(new URL('?asset=intent-rule-ui.mjs',import.meta.url));
const {createPlatformReadUI,checkedArchive,checkedReplyTarget,checkedSourceAnalysis}=await import(new URL('?asset=platform-read-ui.mjs',import.meta.url));
const {createIntentQualityUI,checkedQualityReceipt}=await import(new URL('?asset=intent-quality-ui.mjs',import.meta.url));
const {createCompanyPolicyUI,checkedCompanyPolicyReceipt}=await import(new URL('?asset=company-policy-ui.mjs',import.meta.url));
const {createBusinessReconciliationUI}=await import(new URL('?asset=business-reconciliation-ui.mjs',import.meta.url));
const {createSelfWorklistUI}=await import(new URL('?asset=self-worklist-ui.mjs',import.meta.url));
const {createSelfDailyEvidenceUI}=await import(new URL('?asset=self-daily-evidence-ui.mjs',import.meta.url));
const {createCompanyHandoffReceiverUI}=await import(new URL('?asset=company-handoff-receiver-ui.mjs',import.meta.url));
const {createCompanyContactDeliveryUI,companyContactScope}=await import(new URL('?asset=company-contact-delivery-ui.mjs',import.meta.url));
const element=(tag,text='',className='')=>{const node=document.createElement(tag);node.textContent=String(text);if(className)node.className=className;return node;};
const PLATFORM_ENTRY_SCOPE_TEXT='本轮仅开放小红书、抖音和视频号的新采集；其他平台保留历史查询，快手为演示预留，未接真实账号。';
export function primaryPlatformEntryAllowed(platform,companyId){return companyId!=='fangyu-apartment-client'||['xiaohongshu','douyin','wechat_channels'].includes(platform);}
export function operationScope(context={}){const user=context.user||{};return JSON.stringify([user.id,user.username,user.tenant_id,user.role,context.deviceId,context.deviceGeneration]);}
export function operationFailureIsUncertain(error){return error?.timeout===true||!Number.isInteger(error?.status)||error.status>=500;}
export function operationLockSlot(context,action,target='new'){return 'fangyu:product-operation:'+operationScope({...context,user:{...context.user,role:undefined},deviceGeneration:undefined})+':'+action+':'+target;}
export function keywordImportRows(text,limit=500){return String(text).split(/\r?\n/).map(value=>value.trim()).filter(Boolean).slice(0,limit).map(keyword=>({keyword,group:'人工导入',priority:50,enabled:true}));}
const preparationExact=(value,keys)=>value&&typeof value==='object'&&!Array.isArray(value)&&Object.keys(value).length===keys.length&&keys.every(key=>Object.hasOwn(value,key));
const preparationHex=value=>typeof value==='string'&&/^[a-f0-9]{64}$/.test(value);
export function checkedCompanyPreparation(result,{handoffId,key=null,expectedRevision=null,readOnly=true}={}){
  const fail=()=>{throw Error('本机准备记录未通过核对；保留原编号，暂勿重复保存。');};
  const fields=['contract','local_only','storage_scope','cross_machine_verified','operation_action','idempotency_key','operation_id','state','origin','current','read_only','mutation_committed','replayed','refresh_required','no_dispatch','no_dispatch_scope','previous_company_dispatch_status','cloud_requests_started','platform_requests_started','provider_requests_started','contacts_modified','handoffs_modified','ratings_modified','auto_retry'];
  if(!preparationExact(result,fields)||result.contract!=='company_handoff_preparation_v1'||result.local_only!==true||result.storage_scope!=='this_device'||result.operation_action!=='company_handoff_prepare'||result.read_only!==readOnly||result.mutation_committed!==!readOnly||typeof result.replayed!=='boolean'||result.refresh_required!==true||result.no_dispatch!==true||result.no_dispatch_scope!=='this_preparation_only'||result.previous_company_dispatch_status!=='unknown')fail();
  for(const name of ['cross_machine_verified','cloud_requests_started','platform_requests_started','provider_requests_started','contacts_modified','handoffs_modified','ratings_modified','auto_retry'])if(result[name]!==false)fail();
  const current=result.current;
  if(!preparationExact(current,['handoff_id','revision','status','qualification','consent_state','source_state','preparation_usable','blocked_reason'])||current.handoff_id!==handoffId||!/^[a-f0-9]{32}$/.test(handoffId||'')||!Number.isSafeInteger(current.revision)||current.revision<1||!['draft','ready_to_deliver','accepted','rejected','needs_information','duplicate_pending_review','existing_customer_pending_review','withdrawn','disputed'].includes(current.status)||!['unreviewed','qualified','needs_information','duplicate','existing_customer','not_qualified'].includes(current.qualification)||!['granted','withdrawn','unavailable'].includes(current.consent_state)||!['matched','changed','unavailable'].includes(current.source_state)||typeof current.preparation_usable!=='boolean'||![null,'not_prepared','handoff_not_ready','not_qualified','consent_unavailable','source_changed','source_unavailable','source_ack_missing','origin_state_unknown'].includes(current.blocked_reason))fail();
  if(result.state==='not_prepared'){
    if(!readOnly||result.idempotency_key!==null||result.operation_id!==null||result.origin!==null||current.preparation_usable!==false||current.blocked_reason!=='not_prepared'||result.replayed!==false)fail();
    return result;
  }
  const origin=result.origin;
  if(result.state!=='prepared'||typeof result.idempotency_key!=='string'||!/[A-Za-z0-9]/.test(result.idempotency_key)||!/^[A-Za-z0-9._:-]{8,128}$/.test(result.idempotency_key)||!preparationHex(result.operation_id)||!preparationExact(origin,['origin_id','local_handoff_revision','cloud_operation_action','cloud_idempotency_key','expected_cloud_channel_id','cloud_payload_hash','source_event_kind','source_ack_recorded','source_cloud_binding_verified','created_at'])||!preparationHex(origin.origin_id)||!Number.isSafeInteger(origin.local_handoff_revision)||origin.local_handoff_revision<1||current.revision<origin.local_handoff_revision||origin.cloud_operation_action!=='acquisition_channel_register'||!preparationHex(origin.cloud_idempotency_key)||!/^hc_[a-f0-9]{64}$/.test(origin.expected_cloud_channel_id)||!preparationHex(origin.cloud_payload_hash)||!['reviewed','send_started','sent','failed','unknown','copied','external_reported'].includes(origin.source_event_kind)||origin.source_ack_recorded!==true||origin.source_cloud_binding_verified!==false||!Number.isSafeInteger(origin.created_at)||origin.created_at<1)fail();
  if(key!==null&&result.idempotency_key!==key||expectedRevision!==null&&origin.local_handoff_revision!==expectedRevision)fail();
  if(current.preparation_usable&&(current.revision!==origin.local_handoff_revision||current.blocked_reason!==null||current.status!=='ready_to_deliver'||current.qualification!=='qualified'||current.consent_state!=='granted'||current.source_state!=='matched')||!current.preparation_usable&&current.blocked_reason===null)fail();
  return result;
}
export function checkedCompanyOriginalStatus(result,{handoffId,origin=null}={}){
  const fail=()=>{throw Error('原公司操作回执未通过核对；原准备编号继续保留。');};
  const fields=['contract','read_only','mutation_committed','local_only','storage_scope','cross_machine_verified','cloud_read_requested','observed_at','state','origin','current_local','original_operation','current_company','origin_binding_verified','source_cloud_binding_verified','platform_delivery_verified','financial_receipt_verified','cooperation_policy_verified','verified_cash_cents','verified_paid_commission_cents','settlement_active','auto_retry','no_dispatch','no_dispatch_scope','provider_requests_started','platform_requests_started','contacts_modified','handoffs_modified','ratings_modified'];
  if(!preparationExact(result,fields)||result.contract!=='company_handoff_original_status_v1'||result.read_only!==true||result.mutation_committed!==false||result.storage_scope!=='local_bridge_company_server_ledger'||!['no_origin','unknown','recorded'].includes(result.state)||result.no_dispatch!==true||result.no_dispatch_scope!=='this_status_query_only'||result.verified_cash_cents!==null||result.verified_paid_commission_cents!==null)fail();
  for(const key of ['cross_machine_verified','source_cloud_binding_verified','platform_delivery_verified','financial_receipt_verified','cooperation_policy_verified','settlement_active','auto_retry','provider_requests_started','platform_requests_started','contacts_modified','handoffs_modified','ratings_modified'])if(result[key]!==false)fail();
  const local=result.current_local;
  if(!preparationExact(local,['handoff_id','revision','status','qualification','consent_state','source_state','preparation_usable','blocked_reason'])||!/^[a-f0-9]{32}$/.test(handoffId||'')||local.handoff_id!==handoffId||!Number.isSafeInteger(local.revision)||local.revision<1||!['draft','ready_to_deliver','accepted','rejected','needs_information','duplicate_pending_review','existing_customer_pending_review','withdrawn','disputed'].includes(local.status)||!['unreviewed','qualified','needs_information','duplicate','existing_customer','not_qualified'].includes(local.qualification)||!['granted','withdrawn','unavailable'].includes(local.consent_state)||!['matched','changed','unavailable'].includes(local.source_state)||typeof local.preparation_usable!=='boolean'||![null,'not_prepared','handoff_not_ready','not_qualified','consent_unavailable','source_changed','source_unavailable','source_ack_missing','origin_state_unknown'].includes(local.blocked_reason))fail();
  if(result.state==='no_origin'){
    if(origin!==null||result.origin!==null||result.local_only!==true||result.cloud_read_requested!==false||result.observed_at!==null||result.origin_binding_verified!==false||result.original_operation!==null||result.current_company!==null||local.preparation_usable!==false||local.blocked_reason!=='not_prepared')fail();
    return result;
  }
  if(!origin||!preparationHex(origin.origin_id)||!Number.isSafeInteger(origin.local_handoff_revision)||!preparationExact(result.origin,['origin_id','local_handoff_revision'])||result.origin.origin_id!==origin.origin_id||result.origin.local_handoff_revision!==origin.local_handoff_revision||local.revision<origin.local_handoff_revision||result.local_only!==false||result.cloud_read_requested!==true||!Number.isSafeInteger(result.observed_at)||result.observed_at<0)fail();
  if(local.preparation_usable&&(local.revision!==origin.local_handoff_revision||local.status!=='ready_to_deliver'||local.qualification!=='qualified'||local.consent_state!=='granted'||local.source_state!=='matched'||local.blocked_reason!==null)||!local.preparation_usable&&local.blocked_reason===null)fail();
  if(result.state==='unknown'){
    if(result.origin_binding_verified!==false||result.original_operation!==null||result.current_company!==null)fail();
    return result;
  }
  const original=result.original_operation,current=result.current_company;
  if(result.origin_binding_verified!==true||!/^hc_[a-f0-9]{64}$/.test(origin.expected_cloud_channel_id||'')||!preparationExact(original,['channel_id','revision','historical_status','occurred_at','historical_event_self_hash_verified','full_historical_chain_verified','operation_action','execution_confirmed'])||original.channel_id!==origin.expected_cloud_channel_id||original.revision!==1||original.historical_status!=='draft'||!Number.isSafeInteger(original.occurred_at)||original.occurred_at<0||original.occurred_at>result.observed_at||original.historical_event_self_hash_verified!==true||original.full_historical_chain_verified!==false||original.operation_action!=='acquisition_channel_register'||original.execution_confirmed!==true)fail();
  if(!preparationExact(current,['channel_id','revision','status','current_consent_valid','historical_resource_receipt_recorded','receipt_evidence_independently_verified'])||current.channel_id!==origin.expected_cloud_channel_id||!Number.isSafeInteger(current.revision)||current.revision<1||!['draft','submitted','accepted','rejected','needs_information','duplicate_pending_review','existing_customer_pending_review','withdrawn','disputed'].includes(current.status)||typeof current.current_consent_valid!=='boolean'||typeof current.historical_resource_receipt_recorded!=='boolean'||current.receipt_evidence_independently_verified!==false||current.status==='withdrawn'&&current.current_consent_valid!==false)fail();
  return result;
}

export function checkedCompanySourceBinding(result,{handoffId,origin=null}={}){
  const fail=()=>{throw Error('原来源公司回执未通过核对；原准备继续保留。');};
  const fields=['contract','read_only','mutation_committed','local_only','storage_scope','cross_machine_verified','cloud_read_requested','observed_at','state','origin','current_local','source_event','company_event_payload_matched','source_cloud_binding_verified','local_chain_authority_verified','platform_provenance_verified','platform_delivery_verified','financial_receipt_verified','cooperation_policy_verified','verified_cash_cents','verified_paid_commission_cents','settlement_active','auto_retry','no_dispatch','no_dispatch_scope','provider_requests_started','platform_requests_started','contacts_modified','handoffs_modified','ratings_modified'];
  if(!preparationExact(result,fields)||result.contract!=='company_handoff_source_binding_v1'||result.read_only!==true||result.mutation_committed!==false||result.storage_scope!=='local_bridge_company_server_ledger'||!['no_origin','not_recorded','matched'].includes(result.state)||result.no_dispatch!==true||result.no_dispatch_scope!=='this_source_query_only'||result.verified_cash_cents!==null||result.verified_paid_commission_cents!==null)fail();
  for(const key of ['cross_machine_verified','source_cloud_binding_verified','local_chain_authority_verified','platform_provenance_verified','platform_delivery_verified','financial_receipt_verified','cooperation_policy_verified','settlement_active','auto_retry','provider_requests_started','platform_requests_started','contacts_modified','handoffs_modified','ratings_modified'])if(result[key]!==false)fail();
  const local=result.current_local;
  if(!preparationExact(local,['handoff_id','revision','status','qualification','consent_state','source_state','preparation_usable','blocked_reason'])||!/^[a-f0-9]{32}$/.test(handoffId||'')||local.handoff_id!==handoffId||!Number.isSafeInteger(local.revision)||local.revision<1||!['draft','ready_to_deliver','accepted','rejected','needs_information','duplicate_pending_review','existing_customer_pending_review','withdrawn','disputed'].includes(local.status)||!['unreviewed','qualified','needs_information','duplicate','existing_customer','not_qualified'].includes(local.qualification)||!['granted','withdrawn','unavailable'].includes(local.consent_state)||!['matched','changed','unavailable'].includes(local.source_state)||typeof local.preparation_usable!=='boolean'||![null,'not_prepared','handoff_not_ready','not_qualified','consent_unavailable','source_changed','source_unavailable','source_ack_missing','origin_state_unknown'].includes(local.blocked_reason))fail();
  if(result.state==='no_origin'){
    if(origin!==null||result.origin!==null||result.local_only!==true||result.cloud_read_requested!==false||result.observed_at!==null||result.company_event_payload_matched!==false||result.source_event!==null||local.preparation_usable!==false||local.blocked_reason!=='not_prepared')fail();
    return result;
  }
  if(!origin||!preparationHex(origin.origin_id)||!Number.isSafeInteger(origin.local_handoff_revision)||!preparationExact(result.origin,['origin_id','local_handoff_revision'])||result.origin.origin_id!==origin.origin_id||result.origin.local_handoff_revision!==origin.local_handoff_revision||local.revision<origin.local_handoff_revision||result.local_only!==false||result.cloud_read_requested!==true||!Number.isSafeInteger(result.observed_at)||result.observed_at<1577836800)fail();
  if(local.preparation_usable&&(local.revision!==origin.local_handoff_revision||local.status!=='ready_to_deliver'||local.qualification!=='qualified'||local.consent_state!=='granted'||local.source_state!=='matched'||local.blocked_reason!==null)||!local.preparation_usable&&local.blocked_reason===null)fail();
  if(result.state==='not_recorded'){
    if(result.company_event_payload_matched!==false||result.source_event!==null)fail();
    return result;
  }
  if(result.company_event_payload_matched!==true||!preparationExact(result.source_event,['kind','server_received_at'])||!['reviewed','send_started','sent','failed','unknown','copied','external_reported'].includes(result.source_event.kind)||result.source_event.kind!==origin.source_event_kind||!Number.isSafeInteger(result.source_event.server_received_at)||result.source_event.server_received_at<1577836800||result.source_event.server_received_at>result.observed_at)fail();
  return result;
}

export function checkedCompanyRegistration(result,{handoffId,origin=null,readOnly=true}={}){
  const fail=()=>{throw Error('公司草稿登记记录未通过核对；保留原编号，暂勿再次提交。');};
  const exact=preparationExact,hex=preparationHex,integer=value=>Number.isSafeInteger(value)&&value>=0;
  const fields=['contract','read_only','mutation_committed','storage_scope','local_only','cross_machine_verified','state','observed_at','origin','attempt','current_local','original_operation','current_company','origin_binding_verified','company_event_payload_matched','registration_source_verified','eligible_for_company_submit','can_register','previous_company_dispatch_status','cloud_register_requested','cloud_read_requested','platform_delivery_verified','source_cloud_binding_verified','financial_receipt_verified','cooperation_policy_verified','verified_cash_cents','verified_paid_commission_cents','settlement_active','auto_retry','no_dispatch','no_dispatch_scope','platform_requests_started','provider_requests_started','contacts_modified','handoffs_modified','ratings_modified'];
  if(!exact(result,fields)||result.contract!=='company_handoff_registration_v1'||result.read_only!==readOnly||typeof result.mutation_committed!=='boolean'||readOnly&&result.mutation_committed!==false||result.storage_scope!=='local_bridge_company_server_ledger'||!['not_attempted','unknown','recorded'].includes(result.state)||result.no_dispatch_scope!==(readOnly?'this_registration_get_only':'this_registration_call_only')||result.verified_cash_cents!==null||result.verified_paid_commission_cents!==null)fail();
  for(const key of ['cross_machine_verified','eligible_for_company_submit','platform_delivery_verified','source_cloud_binding_verified','financial_receipt_verified','cooperation_policy_verified','settlement_active','auto_retry','platform_requests_started','provider_requests_started','contacts_modified','handoffs_modified','ratings_modified'])if(result[key]!==false)fail();
  for(const key of ['local_only','origin_binding_verified','company_event_payload_matched','registration_source_verified','can_register','cloud_register_requested','cloud_read_requested','no_dispatch'])if(typeof result[key]!=='boolean')fail();
  if(result.no_dispatch!==!result.cloud_register_requested||readOnly&&result.cloud_register_requested||result.observed_at!==null&&!integer(result.observed_at))fail();
  const local=result.current_local;
  if(!exact(local,['handoff_id','revision','status','qualification','consent_state','source_state','preparation_usable','blocked_reason'])||local.handoff_id!==handoffId||!/^[a-f0-9]{32}$/.test(handoffId||'')||!integer(local.revision)||local.revision<1||!['draft','ready_to_deliver','accepted','rejected','needs_information','duplicate_pending_review','existing_customer_pending_review','withdrawn','disputed'].includes(local.status)||!['unreviewed','qualified','needs_information','duplicate','existing_customer','not_qualified'].includes(local.qualification)||!['granted','withdrawn','unavailable'].includes(local.consent_state)||!['matched','changed','unavailable'].includes(local.source_state)||typeof local.preparation_usable!=='boolean'||![null,'not_prepared','handoff_not_ready','not_qualified','consent_unavailable','source_changed','source_unavailable','source_ack_missing','origin_state_unknown'].includes(local.blocked_reason))fail();
  if(local.preparation_usable&&(local.status!=='ready_to_deliver'||local.qualification!=='qualified'||local.consent_state!=='granted'||local.source_state!=='matched'||local.blocked_reason!==null)||!local.preparation_usable&&local.blocked_reason===null)fail();
  if(result.origin===null){if(origin!==null||result.state!=='not_attempted'||local.preparation_usable||result.can_register)fail();}
  else if(!origin||!exact(result.origin,['origin_id','local_handoff_revision'])||!hex(result.origin.origin_id)||result.origin.origin_id!==origin.origin_id||!integer(result.origin.local_handoff_revision)||result.origin.local_handoff_revision!==origin.local_handoff_revision||local.revision<origin.local_handoff_revision||local.preparation_usable&&local.revision!==origin.local_handoff_revision)fail();
  if(result.state==='not_attempted'){
    if(!readOnly||result.local_only!==true||result.attempt!==null||result.original_operation!==null||result.current_company!==null||result.observed_at!==null||result.cloud_read_requested||result.cloud_register_requested||result.origin_binding_verified||result.company_event_payload_matched||result.registration_source_verified||result.previous_company_dispatch_status!=='unknown'||result.can_register!==!!(result.origin&&local.preparation_usable))fail();
    return result;
  }
  const attempt=result.attempt;
  if(!result.origin||result.local_only!==false||result.can_register||!exact(attempt,['attempt_id','state','created_at','updated_at','registration_source_verified'])||!hex(attempt.attempt_id)||!['unknown','recorded'].includes(attempt.state)||!integer(attempt.created_at)||attempt.created_at<1||!integer(attempt.updated_at)||attempt.updated_at<attempt.created_at||typeof attempt.registration_source_verified!=='boolean'||result.registration_source_verified&&(!attempt.registration_source_verified||!result.company_event_payload_matched||result.state!=='recorded'))fail();
  if(result.state==='unknown'){
    if(result.origin_binding_verified||result.registration_source_verified||result.original_operation!==null||result.current_company!==null||result.previous_company_dispatch_status!=='unknown')fail();
    return result;
  }
  const original=result.original_operation,current=result.current_company;
  if(result.origin_binding_verified!==true||result.cloud_read_requested!==true||result.observed_at===null||result.previous_company_dispatch_status!=='recorded'||!/^hc_[a-f0-9]{64}$/.test(origin.expected_cloud_channel_id||'')||!exact(original,['channel_id','revision','historical_status','occurred_at','historical_event_self_hash_verified','full_historical_chain_verified','operation_action','execution_confirmed'])||original.channel_id!==origin.expected_cloud_channel_id||original.revision!==1||original.historical_status!=='draft'||!integer(original.occurred_at)||original.occurred_at>result.observed_at||original.historical_event_self_hash_verified!==true||original.full_historical_chain_verified!==false||original.operation_action!=='acquisition_channel_register'||original.execution_confirmed!==true)fail();
  if(!exact(current,['channel_id','revision','status','current_consent_valid','historical_resource_receipt_recorded','receipt_evidence_independently_verified'])||current.channel_id!==origin.expected_cloud_channel_id||!integer(current.revision)||current.revision<1||!['draft','submitted','accepted','rejected','needs_information','duplicate_pending_review','existing_customer_pending_review','withdrawn','disputed'].includes(current.status)||typeof current.current_consent_valid!=='boolean'||typeof current.historical_resource_receipt_recorded!=='boolean'||current.receipt_evidence_independently_verified!==false||current.status==='withdrawn'&&current.current_consent_valid!==false)fail();
  return result;
}

export function checkedCompanySubmission(result,{handoffId,origin=null,readOnly=true,expectedCloudRevision=null}={}){
  const fail=()=>{throw Error('原公司提交回执未通过核对；保留原编号，只读核对，暂勿重复提交。');};
  const exact=preparationExact,integer=value=>Number.isSafeInteger(value)&&value>=0;
  const fields=['contract','read_only','mutation_committed','local_only','storage_scope','cross_machine_verified','state','origin','attempt','current_local','current_company','register_operation','original_operation','origin_binding_verified','registration_source_verified','company_event_payload_matched','current_channel_source_matched','eligible_for_company_submit','submission_execution_confirmed','cloud_read_requested','cloud_submit_requested','no_dispatch','no_dispatch_scope','source_cloud_binding_verified','platform_delivery_verified','financial_receipt_verified','cooperation_policy_verified','verified_cash_cents','verified_paid_commission_cents','settlement_active','auto_retry','provider_requests_started','platform_requests_started','contacts_modified','local_handoffs_modified','ratings_modified'];
  if(!exact(result,fields)||result.contract!=='company_handoff_submission_v1'||result.read_only!==readOnly||typeof result.mutation_committed!=='boolean'||readOnly&&result.mutation_committed!==false||result.storage_scope!=='local_bridge_company_server_ledger'||!['no_origin','not_attempted','unknown','recorded'].includes(result.state)||result.no_dispatch_scope!==(readOnly?'this_submission_get_only':'this_submission_call_only')||result.verified_cash_cents!==null||result.verified_paid_commission_cents!==null)fail();
  for(const key of ['cross_machine_verified','source_cloud_binding_verified','platform_delivery_verified','financial_receipt_verified','cooperation_policy_verified','settlement_active','auto_retry','provider_requests_started','platform_requests_started','contacts_modified','local_handoffs_modified','ratings_modified'])if(result[key]!==false)fail();
  for(const key of ['local_only','origin_binding_verified','registration_source_verified','company_event_payload_matched','current_channel_source_matched','eligible_for_company_submit','cloud_read_requested','cloud_submit_requested','no_dispatch'])if(typeof result[key]!=='boolean')fail();
  if(result.local_only!==!result.cloud_read_requested||result.no_dispatch!==!result.cloud_submit_requested||readOnly&&result.cloud_submit_requested||result.mutation_committed!==result.cloud_submit_requested||![null,true].includes(result.submission_execution_confirmed))fail();
  const local=result.current_local;
  if(!exact(local,['handoff_id','revision','status','qualification','consent_state','source_state','preparation_usable','blocked_reason'])||!/^[a-f0-9]{32}$/.test(handoffId||'')||local.handoff_id!==handoffId||!integer(local.revision)||local.revision<1||!['draft','ready_to_deliver','accepted','rejected','needs_information','duplicate_pending_review','existing_customer_pending_review','withdrawn','disputed'].includes(local.status)||!['unreviewed','qualified','needs_information','duplicate','existing_customer','not_qualified'].includes(local.qualification)||!['granted','withdrawn','unavailable'].includes(local.consent_state)||!['matched','changed','unavailable'].includes(local.source_state)||typeof local.preparation_usable!=='boolean'||![null,'not_prepared','handoff_not_ready','not_qualified','consent_unavailable','source_changed','source_unavailable','source_ack_missing','origin_state_unknown'].includes(local.blocked_reason))fail();
  if(local.preparation_usable&&(local.status!=='ready_to_deliver'||local.qualification!=='qualified'||local.consent_state!=='granted'||local.source_state!=='matched'||local.blocked_reason!==null)||!local.preparation_usable&&local.blocked_reason===null)fail();
  if(result.state==='no_origin'){
    if(!readOnly||origin!==null||result.origin!==null||result.attempt!==null||result.local_only!==true||result.cloud_read_requested||result.register_operation!==null||result.original_operation!==null||result.current_company!==null||result.origin_binding_verified||result.registration_source_verified||result.company_event_payload_matched||result.current_channel_source_matched||result.eligible_for_company_submit||result.submission_execution_confirmed!==null||local.preparation_usable||local.blocked_reason!=='not_prepared')fail();
    return result;
  }
  if(!origin||!exact(result.origin,['origin_id','local_handoff_revision'])||!preparationHex(result.origin.origin_id)||result.origin.origin_id!==origin.origin_id||!integer(result.origin.local_handoff_revision)||result.origin.local_handoff_revision<1||result.origin.local_handoff_revision!==origin.local_handoff_revision||local.revision<origin.local_handoff_revision||local.preparation_usable&&local.revision!==origin.local_handoff_revision||!/^hc_[a-f0-9]{64}$/.test(origin.expected_cloud_channel_id||''))fail();
  const operation=(value,action,revision,status)=>exact(value,['channel_id','revision','historical_status','occurred_at','historical_event_self_hash_verified','full_historical_chain_verified','operation_action','execution_confirmed'])&&value.channel_id===origin.expected_cloud_channel_id&&value.revision===revision&&value.historical_status===status&&integer(value.occurred_at)&&value.historical_event_self_hash_verified===true&&value.full_historical_chain_verified===false&&value.operation_action===action&&value.execution_confirmed===true;
  const company=result.current_company;
  if(company!==null&&(!exact(company,['channel_id','revision','status','current_consent_valid','historical_resource_receipt_recorded','receipt_evidence_independently_verified'])||company.channel_id!==origin.expected_cloud_channel_id||!integer(company.revision)||company.revision<1||!['draft','submitted','accepted','rejected','needs_information','duplicate_pending_review','existing_customer_pending_review','withdrawn','disputed'].includes(company.status)||typeof company.current_consent_valid!=='boolean'||typeof company.historical_resource_receipt_recorded!=='boolean'||company.receipt_evidence_independently_verified!==false||company.status==='withdrawn'&&company.current_consent_valid!==false))fail();
  if(result.origin_binding_verified!==!!result.register_operation||result.register_operation!==null&&(!operation(result.register_operation,'acquisition_channel_register',1,'draft')||company===null)||result.current_channel_source_matched&&(!result.origin_binding_verified||!result.company_event_payload_matched||!company)||result.registration_source_verified&&!result.current_channel_source_matched)fail();
  if(result.state==='not_attempted'){
    if(!readOnly||result.attempt!==null||result.original_operation!==null||result.submission_execution_confirmed!==null||result.cloud_submit_requested)fail();
    if(result.eligible_for_company_submit&&(!local.preparation_usable||!result.current_channel_source_matched||company?.status!=='draft'||company.current_consent_valid!==true))fail();
    return result;
  }
  const attempt=result.attempt;
  if(result.local_only||!result.cloud_read_requested||result.eligible_for_company_submit||!exact(attempt,['attempt_id','state','expected_company_revision','created_at','updated_at'])||!preparationHex(attempt.attempt_id)||!['unknown','recorded'].includes(attempt.state)||!integer(attempt.expected_company_revision)||attempt.expected_company_revision<1||!integer(attempt.created_at)||attempt.created_at<1577836800||!integer(attempt.updated_at)||attempt.updated_at<attempt.created_at)fail();
  if(result.state==='unknown'){
    if(result.original_operation!==null||result.submission_execution_confirmed!==null||result.cloud_submit_requested)fail();
    return result;
  }
  if(!result.origin_binding_verified||!operation(result.original_operation,'acquisition_handoff_submit',attempt.expected_company_revision+1,'submitted')||result.submission_execution_confirmed!==true||!company||company.revision<result.original_operation.revision||result.cloud_submit_requested&&(attempt.state!=='recorded'||expectedCloudRevision!==null&&attempt.expected_company_revision!==expectedCloudRevision))fail();
  return result;
}

export function checkedCompanyChannelCheck(result,{handoffId,origin=null}={}){
  const fail=()=>{throw Error('公司当前来源记录未通过核对；原登记编号继续保留。');};
  const exact=preparationExact,integer=value=>Number.isSafeInteger(value)&&value>=0;
  const fields=['contract','read_only','mutation_committed','local_only','storage_scope','cross_machine_verified','cloud_read_requested','observed_at','state','origin','current_local','original_operation','current_company','origin_binding_verified','source_cloud_binding_verified','platform_delivery_verified','financial_receipt_verified','cooperation_policy_verified','verified_cash_cents','verified_paid_commission_cents','settlement_active','auto_retry','no_dispatch','no_dispatch_scope','provider_requests_started','platform_requests_started','contacts_modified','handoffs_modified','ratings_modified','company_event_payload_matched','current_channel_source_matched','registration_source_verified','eligible_for_company_submit','detail_read_requested'];
  if(!exact(result,fields)||result.contract!=='company_handoff_channel_check_v1'||result.read_only!==true||result.mutation_committed!==false||result.storage_scope!=='local_bridge_company_server_ledger'||!['no_origin','not_attempted','registration_unknown','matched','hold'].includes(result.state)||result.no_dispatch!==true||result.no_dispatch_scope!=='this_channel_check_get_only'||result.verified_cash_cents!==null||result.verified_paid_commission_cents!==null)fail();
  for(const key of ['cross_machine_verified','source_cloud_binding_verified','platform_delivery_verified','financial_receipt_verified','cooperation_policy_verified','settlement_active','auto_retry','provider_requests_started','platform_requests_started','contacts_modified','handoffs_modified','ratings_modified','eligible_for_company_submit'])if(result[key]!==false)fail();
  for(const key of ['local_only','cloud_read_requested','origin_binding_verified','company_event_payload_matched','current_channel_source_matched','registration_source_verified','detail_read_requested'])if(typeof result[key]!=='boolean')fail();
  const local=result.current_local;
  if(!exact(local,['handoff_id','revision','status','qualification','consent_state','source_state','preparation_usable','blocked_reason'])||!/^[a-f0-9]{32}$/.test(handoffId||'')||local.handoff_id!==handoffId||!integer(local.revision)||local.revision<1||!['draft','ready_to_deliver','accepted','rejected','needs_information','duplicate_pending_review','existing_customer_pending_review','withdrawn','disputed'].includes(local.status)||!['unreviewed','qualified','needs_information','duplicate','existing_customer','not_qualified'].includes(local.qualification)||!['granted','withdrawn','unavailable'].includes(local.consent_state)||!['matched','changed','unavailable'].includes(local.source_state)||typeof local.preparation_usable!=='boolean'||![null,'not_prepared','handoff_not_ready','not_qualified','consent_unavailable','source_changed','source_unavailable','source_ack_missing','origin_state_unknown'].includes(local.blocked_reason))fail();
  if(local.preparation_usable&&(local.status!=='ready_to_deliver'||local.qualification!=='qualified'||local.consent_state!=='granted'||local.source_state!=='matched'||local.blocked_reason!==null)||!local.preparation_usable&&local.blocked_reason===null)fail();
  if(result.state==='no_origin'){
    if(origin!==null||result.origin!==null||result.local_only!==true||result.cloud_read_requested||result.observed_at!==null||result.origin_binding_verified||result.original_operation!==null||result.current_company!==null||result.company_event_payload_matched||result.current_channel_source_matched||result.registration_source_verified||result.detail_read_requested||local.preparation_usable||local.blocked_reason!=='not_prepared')fail();
    return result;
  }
  if(!origin||!preparationHex(origin.origin_id)||!integer(origin.local_handoff_revision)||origin.local_handoff_revision<1||!exact(result.origin,['origin_id','local_handoff_revision'])||result.origin.origin_id!==origin.origin_id||result.origin.local_handoff_revision!==origin.local_handoff_revision||local.revision<origin.local_handoff_revision||local.preparation_usable&&local.revision!==origin.local_handoff_revision)fail();
  if(result.state==='not_attempted'){
    if(result.local_only!==true||result.cloud_read_requested||result.observed_at!==null||result.origin_binding_verified||result.original_operation!==null||result.current_company!==null||result.company_event_payload_matched||result.current_channel_source_matched||result.registration_source_verified||result.detail_read_requested)fail();
    return result;
  }
  if(result.local_only!==false||result.cloud_read_requested!==true||!integer(result.observed_at)||result.observed_at<1577836800)fail();
  if(result.state==='registration_unknown'){
    if(result.origin_binding_verified||result.original_operation!==null||result.current_company!==null||result.company_event_payload_matched||result.current_channel_source_matched||result.registration_source_verified||result.detail_read_requested)fail();
    return result;
  }
  const original=result.original_operation,current=result.current_company;
  if(result.origin_binding_verified!==true||result.current_channel_source_matched!==true||result.detail_read_requested!==true||!/^hc_[a-f0-9]{64}$/.test(origin.expected_cloud_channel_id||'')||!exact(original,['channel_id','revision','historical_status','occurred_at','historical_event_self_hash_verified','full_historical_chain_verified','operation_action','execution_confirmed'])||original.channel_id!==origin.expected_cloud_channel_id||original.revision!==1||original.historical_status!=='draft'||!integer(original.occurred_at)||original.occurred_at>result.observed_at||original.historical_event_self_hash_verified!==true||original.full_historical_chain_verified!==false||original.operation_action!=='acquisition_channel_register'||original.execution_confirmed!==true)fail();
  if(!exact(current,['channel_id','revision','status','current_consent_valid','historical_resource_receipt_recorded','receipt_evidence_independently_verified'])||current.channel_id!==origin.expected_cloud_channel_id||!integer(current.revision)||current.revision<1||!['draft','submitted','accepted','rejected','needs_information','duplicate_pending_review','existing_customer_pending_review','withdrawn','disputed'].includes(current.status)||typeof current.current_consent_valid!=='boolean'||typeof current.historical_resource_receipt_recorded!=='boolean'||current.receipt_evidence_independently_verified!==false||current.status==='withdrawn'&&current.current_consent_valid!==false||result.registration_source_verified&&!result.company_event_payload_matched)fail();
  const usable=result.company_event_payload_matched&&local.preparation_usable&&current.current_consent_valid;
  if(result.state==='matched'&&!usable||result.state==='hold'&&usable)fail();
  return result;
}

export function companyPreparationSlot(context,handoffId){return 'fangyu:company-preparation:'+operationScope({...context,user:{...context?.user,role:undefined},deviceGeneration:undefined})+':'+handoffId;}

export function verifiedArchiveReceipt(result,key){
  try{return Boolean(key&&result?.idempotency_key===key&&checkedArchive(result,key));}catch{return false;}
}

export function aiAttemptStatusText(result, original){
  if(!result||result.request_id!==original.request_id||result.operation_kind!==original.operation_kind||result.read_only!==true||result.retry_allowed!==false||result.billing_verified!==false||![true,false,null].includes(result.execution_confirmed)||![true,false,null].includes(result.reservation_retained)||typeof result.result_available!=='boolean'||typeof result.requires_revalidation!=='boolean')throw Error('原分析回执未通过核对；原编号继续保留。');
  if(result.current_submission_no_dispatch===true){if(result.proof_scope!=='current_submission'||result.state!=='legacy_untracked'||result.execution_confirmed!==null||result.reservation_retained!==null||result.result_available!==false||result.requires_revalidation!==true||result.execution_kind!=='unknown')throw Error('本次提交证明的范围无效。');return '这一次提交未调用模型；更早历史仍未知。修正配置后，可明确发起新的操作。';}
  const labels={unknown:'原分析尚未确认；继续保留原编号，暂勿重复分析。',legacy_untracked:'旧记录缺少完整追踪证据，是否执行仍未知；暂勿重复分析。',known_unbilled:'已确认原请求未执行；核对配置后，可明确发起新的操作。',completed_no_result:'原请求已经结束，可用结果尚未恢复；请核对原记录。',succeeded:result.execution_kind==='cache_hit'?'原请求返回已有缓存结果；当前资料仍需校验。':'原请求已结束；当前资料仍需校验。'};
  if(!Object.hasOwn(labels,result.state)||!['unknown','cache_hit','provider_result','known_unbilled'].includes(result.execution_kind)||
    result.state==='known_unbilled'&&(result.execution_confirmed!==false||result.reservation_retained!==false||result.result_available!==false||result.execution_kind!=='known_unbilled')||
    ['unknown','legacy_untracked'].includes(result.state)&&(result.execution_confirmed!==null||result.result_available!==false||result.execution_kind!=='unknown')||
    ['succeeded','completed_no_result'].includes(result.state)&&(result.execution_confirmed!==true||result.reservation_retained!==false||!['cache_hit','provider_result'].includes(result.execution_kind))||
    result.state==='completed_no_result'&&result.result_available!==false)throw Error('原分析状态无效；原编号继续保留。');
  return labels[result.state]+' 费用尚未核验。'+(result.reservation_retained===true?' 原预算预留仍保留。':'');
}

const PREFLIGHT_BLOCK=['task_paused','task_exhausted','task_running','task_not_ready','task_outside_schedule','account_not_ready','account_removed','duplicate_platform_uid','activity_review_required','account_busy','strategy_management_required','strategy_disabled','lease_expired','entitlement_denied','platform_policy_hold','license_pending'];
const PREFLIGHT_UNKNOWN=['not_strategy_task','snapshot_unavailable','snapshot_changed','account_identity_unavailable','activity_unavailable','occupancy_unavailable','batch_configuration_unavailable','license_unavailable','quota_unavailable','local_limits_unavailable','local_daily_count_unavailable','schedule_unavailable','platform_unsupported'];
const PREFLIGHT_CHECKS={snapshot:['snapshot_unavailable','snapshot_changed','not_strategy_task','strategy_disabled','lease_expired','strategy_management_required'],account_identity:['account_not_ready','account_removed','account_identity_unavailable','duplicate_platform_uid'],activity:['activity_review_required','activity_unavailable'],occupancy:['task_running','account_busy','occupancy_unavailable'],batch_configuration:['platform_policy_hold','license_pending','license_unavailable','batch_configuration_unavailable','platform_unsupported'],entitlement:['entitlement_denied'],local_collection_limits:['task_paused','task_exhausted','task_not_ready','task_outside_schedule','local_limits_unavailable','local_daily_count_unavailable','schedule_unavailable','quota_unavailable']};
const PREFLIGHT_STEPS=['check_account','review_activity','wait_for_idle','check_snapshot','check_authorization','check_configuration','explicit_single_batch_confirmation'];
const PREFLIGHT_REASON_TEXT={task_paused:'任务已暂停',task_exhausted:'本批任务已完成或达到范围上限',task_running:'任务正在执行',task_not_ready:'任务当前状态需核对',task_outside_schedule:'当前不在任务允许的采集时段',account_not_ready:'平台账号当前未就绪',account_removed:'原账号已停用或撤销',duplicate_platform_uid:'存在相同平台身份的账号记录',activity_review_required:'平台活动有异常或未核对请求',account_busy:'账号被另一种运行模式占用',strategy_management_required:'当前账号没有运行此私有快照的管理权限',strategy_disabled:'当前策略未启用',lease_expired:'原快照租约已过期',entitlement_denied:'当前服务权益不允许采集',platform_policy_hold:'公司当前暂停此平台采集',license_pending:'此运行路线的商业许可尚未确认',not_strategy_task:'首版仅检查私有策略的明确单批任务，请先整理对应快照',snapshot_unavailable:'原私有快照记录暂不可核对',snapshot_changed:'原快照与租约内容不一致',account_identity_unavailable:'本人平台身份尚未完整核实',activity_unavailable:'平台活动记录不可完整核对',occupancy_unavailable:'账号占用状态尚未确认',batch_configuration_unavailable:'单批运行组件或配置尚未完整核对',license_unavailable:'本机未取得完整商业许可配置',quota_unavailable:'关键词槽位记录暂不可核对',local_limits_unavailable:'本机采集范围与上限暂不可核对',local_daily_count_unavailable:'当天已保存数量暂不可核对',schedule_unavailable:'任务采集时段配置暂不可核对',platform_unsupported:'此平台尚未具备本预检所需的单批运行证据'};
export function checkedAcquisitionRunPreflight(value,request){
  const fail=()=>{throw Error('采集检查范围或条件未通过核对，请重新读取原任务。');};
  const exact=(v,keys)=>v&&typeof v==='object'&&!Array.isArray(v)&&Object.keys(v).length===keys.length&&keys.every(k=>Object.hasOwn(v,k));
  const integer=v=>Number.isSafeInteger(v)&&v>=0;
  const opaque=v=>typeof v==='string'&&/^[A-Za-z0-9_-]{1,160}$/.test(v);
  const list=(v,allowed)=>Array.isArray(v)&&v.length<=allowed.length&&new Set(v).size===v.length&&v.every(k=>allowed.includes(k));
  const falseFlags=['cross_machine_verified','mutation_committed','auto_retry','platform_requests_started','provider_requests_started','cloud_requests_started','task_started','account_mode_acquired','live_checked','real_platform_verified','rate_safety_verified'];
  const top=['contract','read_only','local_only','storage_scope',...falseFlags,'request_upper_bound','estimated_duration_seconds','task_id','platform','task_digest','observed_at','state','blocking_reasons','unknown_reasons','next_steps','checks','snapshot','quota'];
  if(!exact(request,['task_id'])||!opaque(request.task_id)||!exact(value,top)||value.contract!=='acquisition_run_preflight_v1'||value.read_only!==true||value.local_only!==true||value.storage_scope!=='this_device'||falseFlags.some(k=>value[k]!==false)||value.request_upper_bound!==null||value.estimated_duration_seconds!==null||value.task_id!==request.task_id||value.platform!==null&&!opaque(value.platform)||typeof value.task_digest!=='string'||!/^[a-f0-9]{64}$/i.test(value.task_digest)||!integer(value.observed_at)||value.observed_at<1577836800||value.observed_at>253402300799||!['blocked','eligible_for_explicit_run','unknown'].includes(value.state)||!list(value.blocking_reasons,PREFLIGHT_BLOCK)||!list(value.unknown_reasons,PREFLIGHT_UNKNOWN)||!list(value.next_steps,PREFLIGHT_STEPS)||!exact(value.checks,Object.keys(PREFLIGHT_CHECKS)))fail();
  const all=[];
  for(const [key,allowed]of Object.entries(PREFLIGHT_CHECKS)){
    const row=value.checks[key];if(!exact(row,['status','reason_codes'])||!['checked','blocked','unknown'].includes(row.status)||!list(row.reason_codes,allowed))fail();
    const blocked=row.reason_codes.some(code=>PREFLIGHT_BLOCK.includes(code));
    if(row.status!==(blocked?'blocked':row.reason_codes.length?'unknown':'checked'))fail();all.push(...row.reason_codes);
  }
  const same=(a,b)=>a.length===new Set(b).size&&a.every(v=>b.includes(v));
  if(!same(value.blocking_reasons,all.filter(k=>PREFLIGHT_BLOCK.includes(k)))||!same(value.unknown_reasons,all.filter(k=>PREFLIGHT_UNKNOWN.includes(k)))||value.state!==(value.blocking_reasons.length?'blocked':value.unknown_reasons.length?'unknown':'eligible_for_explicit_run'))fail();
  const snapshot=value.snapshot,quota=value.quota;
  if(!exact(snapshot,['kind','planned_keyword_count','max_batches'])||snapshot.kind!=='private_strategy_single_batch'||snapshot.max_batches!==1||snapshot.planned_keyword_count!==null&&(!integer(snapshot.planned_keyword_count)||snapshot.planned_keyword_count<1||snapshot.planned_keyword_count>100)||!exact(quota,['unit','total','spent','reserved','remaining','platform_http_limit'])||quota.unit!=='keyword_query_slots'||quota.platform_http_limit!==null)fail();
  const numbers=['total','spent','reserved','remaining'].map(k=>quota[k]);
  if(!numbers.every(v=>v===null)&&(!numbers.every(integer)||quota.spent+quota.reserved>quota.total||quota.remaining!==quota.total-quota.spent-quota.reserved||snapshot.planned_keyword_count!==null&&quota.reserved!==snapshot.planned_keyword_count))fail();
  if(value.state==='eligible_for_explicit_run'&&(snapshot.planned_keyword_count===null||numbers.some(v=>v===null)||!value.next_steps.includes('explicit_single_batch_confirmation')))fail();
  if(value.state!=='eligible_for_explicit_run'&&value.next_steps.includes('explicit_single_batch_confirmation'))fail();
  return value;
}

export function checkedPrivateSingleBatchTask(value,taskId){
  const fail=()=>{throw Error('原私有快照未通过核对，请重新选择已保存任务。');};
  const opaque=v=>typeof v==='string'&&/^[A-Za-z0-9_-]{1,160}$/.test(v);
  const integer=v=>Number.isSafeInteger(v)&&v>=0;
  const text=(v,max)=>typeof v==='string'&&v.length<=max&&!/[\p{Cc}\p{Cf}]/u.test(v);
  const subset=(v,required,optional=[])=>v&&typeof v==='object'&&!Array.isArray(v)&&required.every(k=>Object.hasOwn(v,k))&&Object.keys(v).every(k=>required.includes(k)||optional.includes(k));
  if(!opaque(taskId)||!preparationExact(value,['task','platform_requests_started'])||value.platform_requests_started!==false)fail();
  const task=value.task,required=['id','name','platform','account_id','scope','status','keywords','keywords_private','continuous_enabled','last_message','strategy'];
  const optional=['exhausted','accumulated','daily_limit','target_count','created_at','updated_at','last_run','sequence_status','sequence_batches','last_batch'];
  if(!subset(task,required,optional)||task.id!==taskId||!opaque(task.account_id)||!text(task.name,100)||!['xiaohongshu','douyin','zhihu','wechat_channels'].includes(task.platform)||task.scope!=='search_comments'||!['ready','paused','running','completed','failed','stopped','idle'].includes(task.status)||!Array.isArray(task.keywords)||task.keywords.length!==0||task.keywords_private!==true||task.continuous_enabled!==false||!['后台策略采集已暂停，请核对账号或采集许可','后台策略本批已完成','后台策略快照已保存，按单批断点执行'].includes(task.last_message))fail();
  if(Object.hasOwn(task,'exhausted')&&typeof task.exhausted!=='boolean')fail();
  for(const key of ['accumulated','daily_limit','target_count','sequence_batches'])if(Object.hasOwn(task,key)&&!integer(task[key]))fail();
  for(const key of ['created_at','updated_at','last_run'])if(Object.hasOwn(task,key)&&task[key]!==null&&!text(task[key],80))fail();
  if(Object.hasOwn(task,'sequence_status')&&!text(task.sequence_status,80))fail();
  if(Object.hasOwn(task,'last_batch')){const batch=task.last_batch;if(!subset(batch,[],['read','filtered','duplicates','imported','deferred','completed_at']))fail();for(const key of Object.keys(batch))if(key==='completed_at'?!text(batch[key],80):!integer(batch[key]))fail();}
  const strategy=task.strategy;
  if(!preparationExact(strategy,['id','revision','keyword_count','city','area','storage_scope','cross_machine_verified'])||typeof strategy.id!=='string'||!/^[a-f0-9]{64}$/.test(strategy.id)||!integer(strategy.revision)||!integer(strategy.keyword_count)||strategy.keyword_count<1||strategy.keyword_count>100||!text(strategy.city,40)||!text(strategy.area,80)||strategy.storage_scope!=='this_device'||strategy.cross_machine_verified!==false)fail();
  // The run callback receives identifiers and counts only, never words, paths or stored errors.
  return {id:task.id,name:task.name,platform:task.platform,account_id:task.account_id,scope:task.scope,status:task.status,exhausted:task.exhausted===true,...Object.fromEntries(['accumulated','daily_limit','target_count'].filter(key=>Object.hasOwn(task,key)).map(key=>[key,task[key]])),keywords:[],keywords_private:true,continuous_enabled:false,strategy:{id:strategy.id,revision:strategy.revision,keyword_count:strategy.keyword_count,storage_scope:'this_device',cross_machine_verified:false}};
}
export function privateBatchSelection(task){
  const opaque=v=>typeof v==='string'&&/^[A-Za-z0-9_-]{1,160}$/.test(v),strategy=task?.strategy;
  if(!task||!opaque(task.id)||!opaque(task.account_id)||!['xiaohongshu','douyin','zhihu','wechat_channels'].includes(task.platform)||task.scope!=='search_comments'||task.keywords_private!==true||task.continuous_enabled!==false||!Array.isArray(task.keywords)||task.keywords.length||!strategy||typeof strategy.id!=='string'||!/^[a-f0-9]{64}$/.test(strategy.id)||!Number.isSafeInteger(strategy.revision)||strategy.revision<0||!Number.isSafeInteger(strategy.keyword_count)||strategy.keyword_count<1||strategy.keyword_count>100||strategy.storage_scope!=='this_device'||strategy.cross_machine_verified!==false)throw Error('原私有快照范围未通过核对。');
  return Object.freeze({task_id:task.id,account_id:task.account_id,platform:task.platform,scope:task.scope,strategy_id:task.strategy.id,strategy_revision:task.strategy.revision,keyword_count:task.strategy.keyword_count});
}

export function manualReplyLocatorScope(context={}){
  return JSON.stringify([context.user,context.deviceId,context.deviceGeneration,context.companyId,
    context.environmentId,context.cloudEpoch,context.cloudCompanyId,context.cloudEnvironmentId,
    context.endpoint,context.localWorkspace]);
}

// This exact controller is embedded in the operations candidate. Persistent
// storage contains only the original opaque key, never the form or locator.
export function createManualReplyLocatorController({scope,call,storage,slot,replyId,
  onChange=()=>{},keyFactory=()=>crypto.randomUUID()}){
  const initial=scope();let disposed=false,busy=false,record=null,error='',state='new';
  const raw=storage.getItem(slot);let original=raw?JSON.parse(raw):null;
  if(original&&(Object.keys(original).sort().join(',')!=='action,idempotency_key,reply_id'
    ||original.action!=='manual_reply_locator_save'||original.reply_id!==replyId
    ||typeof original.idempotency_key!=='string'||!/^[A-Za-z0-9_-]{8,128}$/.test(original.idempotency_key)))
    throw Error('原定位编号暂不可核对，请保留原记录。');
  if(original)state='pending';
  const view=()=>({state,busy,record,error,key:disposed?'':original?.idempotency_key||'',
    canSave:!disposed&&!busy&&(!original||state==='rejected'),canRead:!disposed&&!busy&&!!original});
  function invalidate(){disposed=true;busy=false;record=null;error='';state='scope_changed';onChange(view());}
  function sync(){if(disposed)return false;let fresh=false;try{fresh=scope()===initial;}catch{}
    if(!fresh){invalidate();return false;}return true;}
  function checked(value){
    if(!value||value.reply_id!==replyId||value.idempotency_key!==original.idempotency_key
      ||value.auto_retry!==false||value.response_check_started!==false)throw Error('原定位回显待核对，请保留编号。');
    if(value.state==='unknown'&&value.evidence===null&&value.mutation_committed===false)return value;
    if(value.status!=='external_reported'||value.verification_status!=='unverified'
      ||value.message!=='定位待核验'||value.storage_scope!=='this_device'
      ||value.platform_verified!==false||value.platform_reply_id_modified!==false
      ||!/^[a-f0-9]{64}$/.test(value.evidence_id||'')||!/^[a-f0-9]{64}$/.test(value.evidence_digest||'')
      ||!value.locator||typeof value.locator.reported_comment_id!=='string'
      ||typeof value.locator.reported_note_url!=='string')throw Error('定位证据回显待核对，请保留编号。');
    return value;
  }
  async function request(action,body){
    if(!sync()||busy)return null;busy=true;error='';onChange(view());
    try{const value=await call(action,body);if(!sync())return null;
      const result=checked(value);record=result.state==='unknown'?null:result;
      state=record?'saved':'unknown';return result;
    }catch(cause){if(sync()){record=null;
      if(action==='manual_reply_locator_save'&&cause?.mutation_committed===false){state='rejected';error=cause.message||'后台已明确拒绝本次保存；请修正后再次确认，仍沿用原编号。';}
      else{state='unknown';error='保存结果待核对，请按原编号读取；暂勿重复保存。';}
    }return null;
    }finally{if(sync()){busy=false;onChange(view());}}
  }
  return {view,sync,clear:invalidate,
    async save({reported_note_url,reported_comment_id,confirmed}){
      if(!sync()||busy||original&&state!=='rejected')return null;
      if(confirmed!==true)throw Error('请先明确确认这是本人手工发送的定位信息。');
      if(typeof reported_comment_id!=='string'||!/^[A-Za-z0-9][A-Za-z0-9_-]{0,159}$/.test(reported_comment_id)
        ||typeof reported_note_url!=='string'||!/^https:\/\/(?:www\.)?xiaohongshu\.com\/(?:explore|search_result|discovery\/item)\/[A-Za-z0-9]+$/.test(reported_note_url))
        throw Error('请填写公开原帖 URL 和发出的评论 ID；不要填登录凭据或带参数的链接。');
      const key=original?.idempotency_key||keyFactory();if(typeof key!=='string'||!/^[A-Za-z0-9_-]{8,128}$/.test(key))throw Error('原编号创建失败，本次未保存。');
      if(!original){const next={action:'manual_reply_locator_save',reply_id:replyId,idempotency_key:key};storage.setItem(slot,JSON.stringify(next));original=next;}
      state='pending';
      return request('manual_reply_locator_save',{reply_id:replyId,idempotency_key:key,
        reported_note_url,reported_comment_id,confirmed:true});
    },
    async read(){if(!sync()||!original)return null;return request('manual_reply_locator_get',
      {reply_id:replyId,idempotency_key:original.idempotency_key});}
  };
}

export function createUpgradeOperations({execute,getContext,shell,openWorkItem=null,runPrivateBatch=null,onError=()=>{},storage=window.sessionStorage}){
  let dialog=null,dialogClosed=null,dialogGeneration=0,busy=false,disposed=false,activeOperation=0,privateRunBusy=false;
  const scope=()=>operationScope(getContext()||{});
  const platformReadScope=()=>{const context=getContext()||{};return JSON.stringify([scope(),context.cloudEpoch,context.companyId,context.environmentId,context.cloudCompanyId,context.cloudEnvironmentId,context.endpoint,(context.accounts||[]).map(account=>[account.id,account.platform,account.status,account.conn_id,account.platform_uid,account.tenant_id,account.cloud_owner,account.disabled,account.revoked])]);};
  const privateScope=()=>{const context=getContext()||{};return JSON.stringify([scope(),context.user?.company_id,context.companyId,context.environmentId]);};
  const read=async(action,data={})=>{const before=scope(),answer=await execute(action,data);if(before!==scope()||disposed)throw Error('当前账号或电脑已变化，请重新读取。');if(answer?.status!=='succeeded'||!answer.result||typeof answer.result!=='object')throw Error(answer?.error||'记录未返回有效结果。');return answer.result;};
  const pending=(action,target)=>{try{return JSON.parse(storage.getItem(operationLockSlot(getContext()||{},action,target))||'null');}catch{throw Error('无法读取原操作编号，请先检查本机存储。');}};
  function clearOriginal(slot,original){
    let current;try{current=JSON.parse(storage.getItem(slot)||'null');}catch{throw Error('原操作存储无法核对，继续保留编号。');}
    if(current&&(current.action!==original.action||current.idempotency_key!==original.idempotency_key||current.payload_digest!==original.payload_digest))throw Error('保存期间原操作编号已变化，继续保留当前编号。');
    if(current)storage.removeItem(slot);
  }
  async function write(action,data,target='new'){
    const currentScope=['platform_archive_reply_target_bind','source_intent_analyze_selected'].includes(action)?platformReadScope:scope,before=currentScope(),operation=activeOperation,slot=operationLockSlot(getContext()||{},action,target);
    const assertWriteScope=()=>{if(!disposed&&before===currentScope()&&operation===activeOperation)return;const error=Error('当前账号、电脑或操作窗口已变化，本次尚未提交，请重新核对。');error.mutation_committed=false;throw error;};
    let old;try{old=JSON.parse(storage.getItem(slot)||'null');}catch{throw Error('无法保留操作编号，本次未提交。');}
    if(old)throw Error(`上次 ${action} 的结果待核对，暂勿重复提交。操作编号：${old.idempotency_key}`);
    const idempotency_key=crypto.randomUUID(),body={...data,idempotency_key},sourceSelectedCount=action==='source_intent_analyze_selected'&&Array.isArray(body.lead_ids)?body.lead_ids.length:null;
    const digest=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(JSON.stringify(body)));
    const payload_digest=Array.from(new Uint8Array(digest),value=>value.toString(16).padStart(2,'0')).join('');
    assertWriteScope();
    // Only opaque operation metadata persists. Phone, WeChat, consent and form text stay in memory.
    try{storage.setItem(slot,JSON.stringify({action,idempotency_key,payload_digest,state:'submitted'}));}catch{throw Error('无法保留操作编号，本次未提交。');}
    let confirmed=false;
    try{assertWriteScope();const answer=await execute(action,body);if(answer?.status!=='succeeded'||!answer.result||typeof answer.result!=='object'){const error=Error(answer?.error?.message||answer?.error||'保存结果未确认。');error.mutation_committed=answer?.mutation_committed??answer?.error?.mutation_committed;throw error;}if(action==='platform_read_archive'&&!verifiedArchiveReceipt(answer.result,idempotency_key))throw Error('归档回执未通过核对，请保留原编号，暂勿重复保存。');if(action==='platform_archive_reply_target_bind'){const receipt=checkedReplyTarget(answer.result,{lead:target,key:idempotency_key,readOnly:false});if(receipt.state!=='bound'||before!==currentScope()||disposed)throw Error('原回复目标或账号范围仍待核对，继续保留原编号。');}if(action==='source_intent_analyze_selected'){const receipt=checkedSourceAnalysis(answer.result,{key:idempotency_key,readOnly:false});if(before!==currentScope()||disposed||receipt.state!=='succeeded'||receipt.analysis_complete!==true||receipt.selected_count!==sourceSelectedCount)throw Error('原分析结果或当前来源范围仍待核对，继续保留原编号。');}if(['intent_quality_batch_create','intent_quality_label'].includes(action))checkedQualityReceipt(answer.result,idempotency_key,action);if(action==='intent_policy_publish'){checkedCompanyPolicyReceipt(answer.result,idempotency_key,{expected:data});if(answer.result.state!=='succeeded'||answer.result.current_cloud_verified!==true)throw Error('原发布结果仍待核对，请保留原编号。');}clearOriginal(slot,{action,idempotency_key,payload_digest});confirmed=true;if(before!==currentScope()||disposed)throw Error('操作已返回，账号或电脑已变化；请在原账号核对记录。');return answer.result;}
    catch(error){if(confirmed)throw error;if(error.mutation_committed===false){clearOriginal(slot,{action,idempotency_key,payload_digest});throw error;}error.productOperationKey=idempotency_key;error.message=`${error.message||'保存结果未确认'} · 暂勿重复提交，先核对记录。操作编号：${idempotency_key}`;throw error;}
  }
  async function recover(action,target='new'){
    const original=pending(action,target);if(!original)throw Error('当前没有需要核对的原操作。');
    if(action==='source_intent_analyze_selected'){
      if(original.action!==action||typeof original.idempotency_key!=='string'||!/^[A-Za-z0-9._:-]{8,128}$/.test(original.idempotency_key))throw Error('原分析编号无法核对，继续保留原记录。');
      const before=platformReadScope(),slot=operationLockSlot(getContext()||{},action,target),result=checkedSourceAnalysis(await read('source_intent_analysis_status',{idempotency_key:original.idempotency_key}),{key:original.idempotency_key,readOnly:true});
      if(before!==platformReadScope()||disposed)throw Error('当前账号、电脑或来源已变化，继续保留原分析编号。');
      const resolved=result.state==='succeeded'&&result.mutation_committed===true&&result.analysis_complete===true||result.state==='not_committed'&&result.mutation_committed===false;
      if(resolved)clearOriginal(slot,original);
      return {...result,result,resolved};
    }
    if(action==='platform_archive_reply_target_bind'){
      if(original.action!==action||typeof original.idempotency_key!=='string'||!/^[A-Za-z0-9_-]{8,128}$/.test(original.idempotency_key))throw Error('原回复目标编号无法核对，继续保留原记录。');
      const before=platformReadScope(),slot=operationLockSlot(getContext()||{},action,target),result=checkedReplyTarget(await read('platform_archive_reply_target_get',{lead_id:target}),{lead:target,readOnly:true});
      if(before!==platformReadScope()||disposed)throw Error('当前账号、电脑或来源已变化，继续保留原回复目标编号。');
      const resolved=result.state==='bound'&&result.operation_action===action&&result.idempotency_key===original.idempotency_key;
      if(resolved)clearOriginal(slot,original);
      return {...result,result,resolved};
    }
    const before=scope(),slot=operationLockSlot(getContext()||{},action,target);
    const result=action==='intent_policy_publish'?await read('intent_policy_publish_status',{idempotency_key:original.idempotency_key}):['intent_quality_batch_create','intent_quality_label'].includes(action)?await read('intent_quality_operation_status',{operation_action:action,idempotency_key:original.idempotency_key}):action==='platform_read_archive'?await read('platform_read_archive_status',{idempotency_key:original.idempotency_key}):action==='strategy_task_create'?await read('strategy_task_status',{idempotency_key:original.idempotency_key}):await read('acquisition_operation_status',{operation_action:action,idempotency_key:original.idempotency_key});
    if(before!==scope()||result.operation_action!==action||result.idempotency_key!==original.idempotency_key)throw Error('操作核对返回的身份或编号不一致，继续保留原编号。');
    if(action==='platform_read_archive'&&!verifiedArchiveReceipt(result,original.idempotency_key))throw Error('原归档回执未通过核对，继续保留原编号。');
    if(['intent_quality_batch_create','intent_quality_label'].includes(action))checkedQualityReceipt(result,original.idempotency_key,action);
    if(action==='intent_policy_publish')checkedCompanyPolicyReceipt(result,original.idempotency_key,{readOnly:true});
    const resolved=action==='intent_policy_publish'?result.state==='succeeded'&&result.mutation_committed===true&&result.current_cloud_verified===true:result.mutation_committed===true&&['succeeded','known_saved'].includes(result.state)||result.mutation_committed===false&&['rejected','not_committed','cancelled'].includes(result.state);
    if(resolved)clearOriginal(slot,original);
    return {...result,result:result.result||(result.task?{task:result.task}:['platform_read_archive','intent_quality_batch_create','intent_quality_label','intent_policy_publish'].includes(action)?result:undefined),resolved};
  }
  const close=()=>{if(busy)return;dialogGeneration++;if(dialog){const root=dialog,notify=dialogClosed;dialog=null;dialogClosed=null;notify?.();for(const node of root.querySelectorAll('input,textarea')){node.value='';node.checked=false;}root.close();root.remove();}};
  function createDialog(title,{onClose=null}={}){companyContactUI.clearSensitive();close();const own=++dialogGeneration,root=element('dialog','','upgrade-operation-dialog');root.setAttribute('aria-label',title);const heading=element('div','','upgrade-section-header'),button=element('button','关闭','text-button');button.type='button';button.onclick=close;heading.append(element('h2',title),button);root.append(heading);root.addEventListener('cancel',event=>{event.preventDefault();close();});const status=element('p','正在读取…','upgrade-status');status.role='status';status.setAttribute('aria-live','polite');root.append(status);document.body.append(root);dialog=root;dialogClosed=onClose;root.showModal();return {root,status,own,current:()=>!disposed&&dialog===root&&own===dialogGeneration};}
  const input=(form,label,{name,type='text',value='',required=false,maxLength,max,min,placeholder,pattern}={})=>{const wrapper=element('label',label),field=element('input');field.name=name;field.type=type;field.value=String(value??'');field.required=required;if(maxLength)field.maxLength=maxLength;if(max!==undefined)field.max=String(max);if(min!==undefined)field.min=String(min);if(placeholder)field.placeholder=placeholder;if(pattern)field.pattern=pattern;if(type==='tel')field.autocomplete='off';wrapper.append(field);form.append(wrapper);return field;};
  const select=(form,label,name,choices,value='')=>{const wrapper=element('label',label),field=element('select');field.name=name;for(const [key,text] of choices)field.append(new Option(text,key));field.value=value;wrapper.append(field);form.append(wrapper);return field;};
  const checkbox=(form,label)=>{const wrapper=element('label','','upgrade-check'),field=element('input');field.type='checkbox';wrapper.append(field,element('span',label));form.append(wrapper);return field;};
  const button=(form,label,fn,{primary=false}={})=>{const control=element('button',label,primary?'':'secondary');control.type='button';control.onclick=()=>void fn(control);form.append(control);return control;};
  async function perform(view,button,fn,{message='正在保存本机记录…'}={}){if(busy||!view.current())return;const operation=++activeOperation;busy=true;const controls=[...view.root.querySelectorAll('button,input,select,textarea')],disabled=controls.map(control=>control.disabled);controls.forEach(control=>control.disabled=true);view.status.textContent=message;try{await fn();}catch(error){if(view.current()){view.status.textContent=error.message||'操作未完成，请核对。';view.status.dataset.state='error';}else onError(error);}finally{if(operation===activeOperation){busy=false;if(view.current())controls.forEach((control,index)=>control.disabled=disabled[index]);}}}
  async function refreshRecords(){const principal=scope();await Promise.allSettled([shell.refresh('handoff'),shell.refresh('overview')]);if(!disposed&&principal===scope())document.dispatchEvent(new CustomEvent('upgrade:handoff-records-changed',{detail:{operationScope:principal}}));}
  function mountRecovery(view,targets,onRecovered=()=>{}){
    const host=element('div','','upgrade-operation-recovery');view.root.insertBefore(host,view.status.nextSibling);
    const redraw=()=>{host.replaceChildren();for(const [action,target] of targets){const original=pending(action,target);if(!original)continue;const row=element('div');row.append(element('p',`这次操作结果尚未确认。原编号：${original.idempotency_key}`,'upgrade-muted'));button(row,'按原编号核对结果',control=>perform(view,control,async()=>{const answer=await recover(action,target);if(!view.current())return;if(answer.resolved){if(answer.mutation_committed===true)await onRecovered(action,answer.result||{},answer);await Promise.allSettled([refreshRecords(),shell.refresh('management')]);if(!view.current())return;view.status.textContent=answer.mutation_committed===true?'原操作已记录，请核对返回记录后继续。':'后台已确认原操作未提交，可修正资料后重新提交。';redraw();}else view.status.textContent=answer.message||'原操作仍待确认，继续保留编号；暂勿重复提交。';}));host.append(row);}};
    redraw();return redraw;
  }

  function openManualReplyConfirmation({replyId,leadId}={}, {accept=()=>true}={}){
    if(disposed||busy||getContext()?.localWorkspace!==true||![replyId,leadId].every(value=>typeof value==='string'&&/^[A-Za-z0-9][A-Za-z0-9_-]{0,159}$/.test(value)))return Promise.resolve(false);
    try{if(accept()!==true)return Promise.resolve(false);}catch{return Promise.resolve(false);}
    const initial=manualReplyLocatorScope(getContext());
    return new Promise(resolve=>{
      let settled=false,timer=0;
      const settle=value=>{if(settled)return;settled=true;clearInterval(timer);resolve(value);};
      const view=createDialog('登记人工发送',{onClose:()=>settle(false)});
      const current=()=>{try{return view.current()&&accept()===true&&initial===manualReplyLocatorScope(getContext());}catch{return false;}};
      const form=element('section','','upgrade-operation-form');view.root.append(form);
      form.append(element('p','请确认：你已在原帖人工发出这条已审核回复。这里只登记人工联系，不核验平台发送或客户回应。','upgrade-muted'));
      const confirmed=checkbox(form,'我确认已在原帖人工发出这条已审核回复');
      const submit=button(form,'确认登记人工发送',()=>{if(!confirmed.checked||!current())return;settle(true);close();},{primary:true});
      button(form,'取消',()=>close());
      const sync=()=>{if(!current()){confirmed.checked=false;submit.disabled=true;settle(false);if(view.current())close();return;}submit.disabled=!confirmed.checked;};
      confirmed.addEventListener('change',sync);view.status.textContent='请明确勾选后登记；这里只记录人工联系，平台未核验。';
      timer=setInterval(sync,250);sync();
    });
  }

  let manualLocatorController=null;
  const clearManualLocator=()=>{manualLocatorController?.clear();manualLocatorController=null;};
  async function openManualReplyLocator({replyId,leadId}={}, {accept=()=>true}={}){
    if(disposed||getContext()?.localWorkspace!==true||typeof replyId!=='string'||!/^[A-Za-z0-9][A-Za-z0-9_-]{0,159}$/.test(replyId))throw Error('请在原电脑选择已有人工联系记录。');
    if(accept()!==true)return;clearManualLocator();let timer=0,controller=null;
    const view=createDialog('人工发送定位',{onClose:()=>{clearInterval(timer);controller?.clear();if(manualLocatorController===controller)manualLocatorController=null;}});
    const initial=manualReplyLocatorScope(getContext()),current=()=>{try{return view.current()&&accept()===true&&initial===manualReplyLocatorScope(getContext());}catch{return false;}};
    const form=element('section','','upgrade-operation-form'),saved=element('section','','upgrade-record-list');
    view.root.append(element('p','填写本人手工发出的评论位置，保存后显示“定位待核验”；不会核验平台发送、客户回应或解锁发送。','upgrade-muted'),form,saved);
    const url=input(form,'公开原帖 URL',{name:'reported_note_url',required:true,maxLength:2048,placeholder:'https://www.xiaohongshu.com/explore/原帖编号'});
    const comment=input(form,'人工发出的评论 ID',{name:'reported_comment_id',required:true,maxLength:160});
    const confirmed=checkbox(form,'我确认这是本人手工发送的定位信息，仍需核验');
    const keyLine=element('p','','upgrade-muted');view.root.append(keyLine);
    const save=button(form,'保存定位待核验',async()=>{if(!current()||!url.reportValidity()||!comment.reportValidity())return;try{await controller.save({reported_note_url:url.value.trim(),reported_comment_id:comment.value.trim(),confirmed:confirmed.checked});}catch(error){if(current())view.status.textContent=error.message;}});
    const readOriginal=button(view.root,'按原编号读取定位',async()=>{if(current())await controller.read();});
    let displayedState='';const render=value=>{
      if(!current()||value.state==='scope_changed'){url.value='';comment.value='';confirmed.checked=false;saved.replaceChildren();keyLine.textContent='';save.disabled=true;readOriginal.disabled=true;form.hidden=true;view.status.textContent='当前账号、公司或电脑已变化，请重新打开原记录。';clearInterval(timer);return;}
      if(value.state==='rejected'&&displayedState!=='rejected')confirmed.checked=false;displayedState=value.state;
      save.disabled=!value.canSave||!confirmed.checked;readOriginal.disabled=!value.canRead;
      keyLine.textContent=value.key?'原编号：'+value.key:'';form.hidden=!!value.key&&value.state!=='rejected';
      view.status.textContent=value.busy?'正在核对本机原记录…':value.error||({new:'请填写本人手工发送的位置。',pending:'已有原定位操作，请按原编号读取；暂勿重复保存。',unknown:'原编号保存结果仍待核对；不会自动重试。',saved:'定位待核验'})[value.state]||'定位待核验';
      saved.replaceChildren();if(value.record){saved.append(element('p','定位待核验'),element('p','人工发出评论 ID：'+value.record.locator.reported_comment_id),element('p','公开原帖：'+value.record.locator.reported_note_url),element('p','人工登记，不表示平台发送已核验、客户已回应或成交。','upgrade-muted'));}
    };
    controller=createManualReplyLocatorController({scope:()=>JSON.stringify([manualReplyLocatorScope(getContext()),current(),leadId]),call:read,storage,slot:operationLockSlot(getContext(),'manual_reply_locator_save',replyId),replyId,onChange:render});
    manualLocatorController=controller;confirmed.addEventListener('change',()=>{if(controller.sync())render(controller.view());});render(controller.view());timer=setInterval(()=>controller.sync(),250);
  }

  const primaryEntryAllowed=platform=>primaryPlatformEntryAllowed(platform,getContext()?.companyId);
  async function openRunPreflight({taskId}={}, {accept=()=>true}={}){
    if(disposed)return;try{if(accept()!==true)return;}catch{return;}
    if(typeof taskId!=='string'||!/^[A-Za-z0-9_-]{1,160}$/.test(taskId))throw Error('请选择已保存的采集任务。');
    const initial=scope(),view=createDialog('采集前检查'),request={task_id:taskId};let epoch=0;
    const current=()=>{try{return view.current()&&scope()===initial&&accept()===true;}catch{return false;}};
    const host=element('section','','upgrade-record-list');
    view.root.append(element('p','检查当前任务的本机条件，检查后仍须按原入口确认单批运行。','upgrade-muted'));
    const control=button(view.root,'重新检查',()=>load());view.root.append(host);
    async function load(){
      if(!current())return;const ticket=++epoch,valid=()=>current()&&ticket===epoch;host.replaceChildren();control.disabled=true;view.status.textContent='正在核对原任务、账号与本机运行条件…';
      try{
        const answer=await read('acquisition_run_preflight',request);if(!valid())return;
        const value=checkedAcquisitionRunPreflight(answer,request);
        const outsideEntryScope=!primaryEntryAllowed(value.platform);
        view.status.textContent=outsideEntryScope?PLATFORM_ENTRY_SCOPE_TEXT:({blocked:'当前存在阻断，请先核对下列条件。',unknown:'部分运行条件尚未核实，请先补齐检查。',eligible_for_explicit_run:'当前本机条件可进入单批运行确认。'})[value.state];view.status.dataset.state=outsideEntryScope?'platform_scope_held':value.state;
        const title=({xiaohongshu:'小红书',douyin:'抖音',zhihu:'知乎',wechat_channels:'视频号',bilibili:'哔哩哔哩',kuaishou:'快手'})[value.platform]||'平台待支持';
        host.append(element('h3',title+' · 原任务'),element('p','本检查没有验证实时登录、平台允许速度或实际吞吐；运行时会再次检查。','upgrade-muted'));
        const names={snapshot:'原私有单批快照',account_identity:'本人平台账号身份',activity:'平台活动风险记录',occupancy:'账号与任务占用',batch_configuration:'单批组件、配置与许可',entitlement:'当前服务权益',local_collection_limits:'本机范围与数量限制'};
        for(const [key,name]of Object.entries(names)){
          const item=value.checks[key],row=element('section','','upgrade-operation-form'),line=element('div','','upgrade-record-line');line.append(element('span',name),element('strong',({checked:'已核对',blocked:'需先处理',unknown:'未核实'})[item.status]));row.append(line);
          for(const code of item.reason_codes)row.append(element('p',PREFLIGHT_REASON_TEXT[code],'upgrade-muted'));host.append(row);
        }
        const counts=[['本快照关键词',value.snapshot.planned_keyword_count],['计划最多采集批次',value.snapshot.max_batches],['关键词查询槽位总量',value.quota.total],['已完成词槽',value.quota.spent],['已保留词槽',value.quota.reserved],['剩余词槽',value.quota.remaining],['平台请求上限',null],['预计运行时长',null]];
        const summary=element('section','','upgrade-operation-form');summary.append(element('h3','本批计划与范围'));
        for(const [name,count]of counts){const row=element('div','','upgrade-record-line');row.append(element('span',name),element('strong',count===null?'未核实':String(count)));summary.append(row);}
        summary.append(element('p','词槽、平台请求和采集批次是不同单位；词库数量不能直接换算成速度或精准客户人数。','upgrade-muted'));host.append(summary);
        const instructions={check_account:'到平台账号页核对本人账号与重复身份。',review_activity:'核对平台活动异常和未确认请求，保留原会话。',wait_for_idle:'先核对原任务或账号占用；本检查不会释放占用。',check_snapshot:'到管理中心核对当前私有策略及原快照。',check_authorization:'核对本人运行权限与当前服务权益。',check_configuration:'核对组件、公司配置和商业许可。',explicit_single_batch_confirmation:'从原任务运行入口明确确认单批，执行时重新核对条件。'};
        if(value.next_steps.length){const next=element('section','','upgrade-operation-form');next.append(element('h3','下一步'));for(const code of value.next_steps)if(!outsideEntryScope||code!=='explicit_single_batch_confirmation')next.append(element('p',instructions[code],'upgrade-muted'));host.append(next);}
      }catch{if(valid()){host.replaceChildren();view.status.textContent='原任务采集条件暂不可核对，请重新检查；未启动或修改任务。';view.status.dataset.state='error';}}
      finally{if(valid())control.disabled=false;}
    }
    await load();
  }

  async function openPrivateSingleBatch({taskId}={}, {accept=()=>true}={}){
    if(disposed)return;try{if(accept()!==true)return;}catch{return;}
    if(busy||privateRunBusy){onError(Error('当前还有操作正在处理，请等待原操作返回。'));return;}
    if(typeof taskId!=='string'||!/^[A-Za-z0-9_-]{1,160}$/.test(taskId))throw Error('请选择已保存的原私有任务。');
    const initial=privateScope(),view=createDialog('原私有快照单批运行'),request={task_id:taskId};
    const current=()=>{try{return view.current()&&privateScope()===initial&&accept()===true;}catch{return false;}};
    const host=element('section','','upgrade-record-list');view.root.append(element('p','本入口只确认已保存任务的一批采集。私有词库保持隐藏，运行时继续检查账号、许可与原任务；不会持续运行或自动进入下一批。','upgrade-muted'),element('p','每次只按原断点执行一批；完成一批不代表全部冻结关键词已经采集。下一批仍需重新核对并确认。','upgrade-muted'),host);
    const acknowledged=checkbox(view.root,'我已核对原任务、账号和本机单批条件');
    let baseline=null,loading=false,confirming=false,submitted=false;
    const confirm=button(view.root,'确认运行原任务单批',()=>confirmRun(),{primary:true});confirm.disabled=true;
    const reload=button(view.root,'重新核对原任务',()=>load());
    const gate=()=>{const context=getContext()||{},held=Object.hasOwn(context,'privateCollectionHeld')?context.privateCollectionHeld:context.collectionHeld;
      if(typeof runPrivateBatch!=='function')return '当前窗口尚未接入单批运行，请从原任务入口继续。';
      if(context.localWorkspace!==true||typeof context.companyId!=='string'||!context.companyId||typeof context.environmentId!=='string'||!context.environmentId||!context.user||!context.deviceId)return '当前本机、公司或员工范围尚未核实，请重新选择。';
      if(context.taskOperationPending!==false)return '原任务操作仍待核对，请保留原编号，暂勿启动另一批。';
      if(held!==false)return '当前平台采集尚未开放，请先核对账号与许可。';
      if(busy||privateRunBusy)return '当前还有操作正在处理，请等待原操作返回。';
      return '';
    };
    const safeFailure=error=>{const blocked=gate();if(blocked)return blocked;const known=[PLATFORM_ENTRY_SCOPE_TEXT,'当前预检存在阻断，请先处理原任务条件。','当前预检仍有未核实条件，暂不可运行原任务。','原任务或快照范围已变化，请重新核对后再明确确认。'];return known.includes(error?.message)?error.message:'原任务或运行条件未通过核对，请先查看采集前检查；本入口尚未提交运行。';};
    const updateControls=()=>{if(!current())return;acknowledged.disabled=loading||confirming||submitted||!baseline;confirm.disabled=loading||confirming||submitted||!baseline||!acknowledged.checked||!!gate();reload.disabled=loading||confirming||submitted;};
    acknowledged.onchange=updateControls;
    const checkPair=(preflight,task)=>{
      if(!primaryEntryAllowed(task.platform))throw Error(PLATFORM_ENTRY_SCOPE_TEXT);
      if(preflight.state!=='eligible_for_explicit_run'||task.status!=='ready'||task.exhausted||preflight.platform!==task.platform||preflight.snapshot.planned_keyword_count!==task.strategy.keyword_count||!/^[a-f0-9]{64}$/.test(preflight.task_digest))throw Error('原任务条件未满足明确单批运行，请核对预检与原快照。');
      return {taskDigest:preflight.task_digest,selection:privateBatchSelection(task)};
    };
    async function pair(){
      if(!current())return null;let blocked=gate();if(blocked)throw Error(blocked);
      const preflightResult=await read('acquisition_run_preflight',request);if(!current())return null;blocked=gate();if(blocked)throw Error(blocked);
      const preflight=checkedAcquisitionRunPreflight(preflightResult,request);
      // A blocked or unknown check cannot authorize a second read or a run.
      if(preflight.state!=='eligible_for_explicit_run')throw Error(preflight.state==='blocked'?'当前预检存在阻断，请先处理原任务条件。':'当前预检仍有未核实条件，暂不可运行原任务。');
      const taskResult=await read('strategy_task_get',request);if(!current())return null;blocked=gate();if(blocked)throw Error(blocked);
      return checkPair(preflight,checkedPrivateSingleBatchTask(taskResult,taskId));
    }
    async function load(){
      if(!current()||loading||confirming||submitted)return;loading=true;baseline=null;acknowledged.checked=false;host.replaceChildren();view.status.textContent='正在核对原任务、私有快照与本机单批条件…';updateControls();
      try{const value=await pair();if(!current()||!value)return;baseline=value;const platform=({xiaohongshu:'小红书',douyin:'抖音',zhihu:'知乎',wechat_channels:'视频号'})[value.selection.platform];
        for(const [label,text]of [['原任务编号',taskId],['原平台账号编号',value.selection.account_id],['平台',platform],['原策略版本',String(value.selection.strategy_revision)],['本批冻结词数',String(value.selection.keyword_count)],['最多采集批次','1']]){const row=element('div','','upgrade-record-line');row.append(element('span',label),element('strong',text));host.append(row);}
        host.append(element('p','关键词槽位不等于平台请求数或客户人数；当前检查没有证明实时登录、平台允许速度或实际吞吐。','upgrade-muted'));view.status.textContent='原任务与预检已核对。勾选确认后，将再次读取同一任务和条件。';view.status.dataset.state='eligible_for_explicit_run';
      }catch(error){if(current()){baseline=null;view.status.textContent=safeFailure(error);view.status.dataset.state='error';}}
      finally{loading=false;updateControls();}
    }
    async function confirmRun(){
      if(!current()||loading||confirming||submitted||!baseline||!acknowledged.checked)return;const blocked=gate();if(blocked){view.status.textContent=blocked;updateControls();return;}
      confirming=true;updateControls();view.status.textContent='正在再次核对原任务与单批条件…';let dispatched=false;
      try{const expected=baseline,fresh=await pair();if(!current()||!fresh)return;
        if(fresh.taskDigest!==expected.taskDigest||JSON.stringify(fresh.selection)!==JSON.stringify(expected.selection)){baseline=null;acknowledged.checked=false;throw Error('原任务或快照范围已变化，请重新核对后再明确确认。');}
        const beforeSubmit=gate();if(beforeSubmit)throw Error(beforeSubmit);if(!current())return;
        // The app bridge keeps the original command/key recovery and rechecks the server run boundary.
        privateRunBusy=true;dispatched=true;const answer=await runPrivateBatch({taskId,taskDigest:fresh.taskDigest,selection:fresh.selection},{accept:current});if(!current())return;
        if(answer===false){baseline=null;acknowledged.checked=false;view.status.textContent='本次范围未确认，请核对原任务记录后继续。';view.status.dataset.state='error';return;}
        if(!preparationExact(answer,['submitted','task_id','max_batches'])||answer.submitted!==true||answer.task_id!==taskId||answer.max_batches!==1)throw Error('原任务指令结果仍待核对。');
        submitted=true;view.status.textContent='单批指令已交给原任务流程，请查看采集进度和原指令状态；这不表示整批采集或全部关键词已完成。';view.status.dataset.state='submitted';
      }catch(error){if(current()){baseline=null;acknowledged.checked=false;view.status.textContent=dispatched?'本次运行状态尚未确认，请查看采集进度；如已有原指令，请核对该指令，暂勿重复提交。':safeFailure(error);view.status.dataset.state='error';if(dispatched)submitted=true;}}
      finally{if(dispatched)privateRunBusy=false;confirming=false;updateControls();}
    }
    await load();
  }

  async function openAIAttempts(){
    const view=createDialog('核对原分析记录'),initial=scope();
    view.root.append(element('p','查看本机当前账号保留的原操作编号。核对只读状态，不发起模型分析，也不解除未知预算预留。','upgrade-muted'));
    const host=element('div','','upgrade-record-list');view.root.append(host);
    try{
      const result=await read('ai_attempt_list',{limit:50});if(!view.current()||scope()!==initial)return;
      const operations={intent_analyze:'评论意向分析',keyword_suggest:'关键词联想'},states={prepared:'已准备',submitted:'已提交，结果待核对',unknown:'结果未知',response_received:'收到返回，资料待校验',validated:'结果已通过本机校验',not_dispatched:'本次提交未调用模型'};
      if(result.read_only!==true||result.executes_model!==false||result.billing_verified!==false||result.source!=='local_attempt_metadata'||!Number.isInteger(result.total)||result.total<0||!Array.isArray(result.items)||result.items.length>50||result.total<result.items.length||new Set(result.items.map(row=>row?.request_id)).size!==result.items.length)throw Error('原分析清单未通过核对。');
      for(const row of result.items){if(!row||typeof row.request_id!=='string'||!/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i.test(row.request_id)||!Object.hasOwn(operations,row.operation_kind)||!Object.hasOwn(states,row.state)||typeof row.scope_matches!=='boolean')throw Error('原分析记录格式无效。');}
      view.status.textContent=result.total?`已读取${result.items.length}条本机记录，共${result.total}条。清单状态不代表云端执行或实际费用。`:'本机当前账号尚无分析操作记录；这不能证明历史请求未执行。';
      for(const row of result.items){
        const card=element('article','','upgrade-record-line');card.append(element('strong',operations[row.operation_kind]),element('p',states[row.state]),element('p',`原编号：${row.request_id}`,'upgrade-muted'));
        const answer=element('p',row.scope_matches?'尚未核对云端原记录。':'员工或电脑绑定已变化，请回到原范围核对。','upgrade-muted');answer.role='status';card.append(answer);
        const control=button(card,'只核对原编号',async control=>{if(!view.current()||scope()!==initial)return;control.disabled=true;try{const status=await read('ai_attempt_status',{request_id:row.request_id});if(view.current()&&scope()===initial)answer.textContent=aiAttemptStatusText(status,row);}catch(error){if(view.current()&&scope()===initial)answer.textContent=error.message||'核对暂未完成；原编号继续保留。';}finally{if(view.current()&&scope()===initial)control.disabled=!row.scope_matches;}});control.disabled=!row.scope_matches;host.append(card);
      }
    }catch(error){if(view.current()&&scope()===initial){host.replaceChildren();view.status.textContent=error.message||'原分析记录暂未读取，未重复分析。';view.status.dataset.state='error';}}
  }

  async function openExport(){
    const view=createDialog('导出交接核对清单');
    const form=element('form','','upgrade-operation-form');form.addEventListener('submit',event=>event.preventDefault());view.root.append(form);
    const format=select(form,'文件格式','format',[['xlsx','Excel 工作簿'],['csv','CSV 表格']],'xlsx');
    const mode=select(form,'记录范围','mode',[['delivery','当前授权有效的待送达记录'],['audit','本人有权查看的历史核对记录']],'delivery');
    const limit=input(form,'本批最多条数（1–1000）',{type:'number',value:1000,min:1,max:1000,required:true});
    view.status.textContent='核对清单不读取受保护联系方式；导出不登记送达、接收或成交。';
    button(form,'生成并下载清单',async control=>{
      if(busy||!view.current()||!form.reportValidity())return;
      const operation=++activeOperation;busy=true;const originalScope=scope(),requested={format:format.value,mode:mode.value,limit:Number(limit.value)},controls=[...view.root.querySelectorAll('button,input,select,textarea')],disabled=controls.map(field=>field.disabled);controls.forEach(field=>field.disabled=true);
      try{view.status.textContent='正在核对当前授权与来源…';const result=await read('handoff_export',requested);if(!view.current())return;
        const file=await handoffExportFile(result,requested);if(!view.current()||originalScope!==scope())throw Error('当前账号或电脑已变化，尚未下载，请重新核对。');
        const link=element('a'),url=URL.createObjectURL(file.blob);link.href=url;link.download=file.filename;link.hidden=true;view.root.append(link);
        try{link.click();}finally{link.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);}
        view.status.textContent=`已生成${file.rows}条本机核对记录。${file.hasMore?'范围内仍有记录，请按明确编号分批核对。':''}请在保存对话框核对文件；未登记送达或接收。`;
      }catch(error){if(view.current()){view.status.textContent=error.message||'导出未完成，请重新核对。';view.status.dataset.state='error';}else onError(error);}
      finally{if(operation===activeOperation){busy=false;if(view.current())controls.forEach((field,index)=>field.disabled=disabled[index]);}}
    },{primary:true});
  }

  async function openCreate({leadId=''}={}){
    const view=createDialog('整理资源部交接'),initial=scope();
    try{const list=await read('handoff_list',{offset:0,limit:1});if(!view.current()||scope()!==initial)return;
      if(list.permissions?.can_create!==true){view.status.textContent='当前账号没有整理交接的权限。';return;}
      const recipients=Array.isArray(list.recipients)?list.recipients:[];if(!recipients.length){view.status.textContent='尚未配置资源部接收方，请由获授权管理人员先配置。';return;}
      const form=element('form','','upgrade-operation-form');form.addEventListener('submit',event=>event.preventDefault());view.root.append(form);
      const source=select(form,'来源客户与原始评论','lead_id',[['','选择已保存评论']]);source.required=true;let offset=0,total=0;
      async function loadSources(){const result=await read('leads_list',{worklist:'all',sort:'intent',offset,limit:25});if(!view.current())return;const items=Array.isArray(result.items)?result.items:[];total=result.total||0;for(const lead of items)source.append(new Option(`${lead.author||'客户'} · ${String(lead.text||'正文待补').slice(0,70)}`,lead.id));next.disabled=offset+25>=total;view.status.textContent=`已读取${source.options.length-1}条授权评论，选择固定来源后整理交接。`;}
      const next=button(form,'再读取25条来源',async control=>{control.disabled=true;try{offset+=25;await loadSources();}catch(error){offset=Math.max(0,offset-25);view.status.textContent=error.message;control.disabled=false;}});
      const recipient=select(form,'明确的资源部接收方','recipient_id',[['','请选择接收方'],...recipients.map(item=>[item.id,`${item.name||item.id}${item.receiver_configured?'':' · 接收主体尚未配置'}`])]);recipient.required=true;
      const purpose=input(form,'交接用途',{name:'purpose',maxLength:100,required:true,placeholder:'填写客户已知晓的实际用途'});
      const evidenceOptions=element('details');evidenceOptions.append(element('summary','已有客户同意证据（选填）'));form.append(evidenceOptions);
      const reference=input(evidenceOptions,'已有证据引用',{name:'consent',maxLength:200,pattern:'consent:[a-f0-9]{32}',placeholder:'有已有证据时填写其记录引用'});let operatorReference='',operatorConsentScope='';
      const notice=input(form,'已向客户说明的告知版本',{name:'notice',maxLength:80,required:true,placeholder:'填写实际使用的告知版本'});
      const phone=input(form,'手机号（可选）',{name:'phone',type:'tel',maxLength:25,placeholder:'仅填写客户已授权交给此接收方的号码'});
      const wechat=input(form,'微信号（可选）',{name:'wechat',maxLength:30,placeholder:'不填联系方式时保留原平台身份引用'});
      const consent=checkbox(form,'我已向客户说明接收方和用途，并取得客户明确同意');consent.required=true;
      form.append(element('p','勾选后由本机登记客户同意记录。这是操作人登记，尚未独立核验客户证据；本步骤只保存交接草稿。','upgrade-muted'));
      const draftPanel=element('details');draftPanel.append(element('summary','客户回应后 · 告知与自愿留资草稿'));form.append(draftPanel);
      const identity=input(draftPanel,'向客户说明的真实身份',{name:'disclosure_identity',maxLength:80,placeholder:'例如：租赁顾问或合作中介，按真实身份填写'});
      const tone=select(draftPanel,'告知口吻','disclosure_tone',Object.entries(replyTones),'friendly');
      draftPanel.append(element('p','口吻不代表官方授权或入住经历。先填写接收方、用途和实际采用的告知版本，再预览。','upgrade-muted'));
      const draftText=element('textarea');draftText.readOnly=true;draftText.rows=7;draftText.hidden=true;draftText.setAttribute('aria-label','给客户审阅的告知草稿');draftPanel.append(draftText);
      const draftFeedback=element('p','预览和复制只整理文案；客户实际同意后仍需人工确认。','upgrade-muted');draftFeedback.role='status';draftFeedback.setAttribute('aria-live','polite');draftPanel.append(draftFeedback);
      let disclosure=null,copyAttempt=null;
      const disclosureScope=()=>JSON.stringify([scope(),source.value,recipient.value,purpose.value,notice.value,reference.value,consent.checked,phone.value,wechat.value,identity.value,tone.value]);
      const invalidateDisclosure=()=>{disclosure=null;copyAttempt=null;draftText.value='';draftText.hidden=true;copyDisclosure.disabled=true;draftFeedback.textContent='当前资料已变化，请重新预览告知草稿。';};
      const disclosureCurrent=(draft=disclosure)=>view.current()&&scope()===initial&&disclosure===draft&&draft?.scope===disclosureScope();
      const copyCurrent=attempt=>copyAttempt===attempt&&disclosureCurrent(attempt.draft);
      button(draftPanel,'预览告知草稿',()=>{try{if(!view.current()||scope()!==initial)throw Error('当前账号或电脑已变化，请重新打开交接。');if(!source.value||![...source.options].some(option=>option.value===source.value))throw Error('请先选择当前有权读取的来源客户。');const receiver=recipients.find(item=>item.id===recipient.value);if(!receiver)throw Error('请先选择实际接收方。');const value=voluntaryContactDraft({tone:tone.value,identity:identity.value,recipient:receiver.name||receiver.id,purpose:purpose.value,noticeVersion:notice.value});copyAttempt=null;disclosure={...value,scope:disclosureScope()};draftText.value=value.text;draftText.hidden=false;copyDisclosure.disabled=false;draftFeedback.textContent=`告知版本：${value.notice_version} · 尚未发送或取得客户同意。`;}catch(error){invalidateDisclosure();draftFeedback.textContent=error.message;} });
      const copyDisclosure=button(draftPanel,'复制告知草稿',async()=>{if(!disclosureCurrent()){invalidateDisclosure();return;}if(copyAttempt)return;const original=disclosure,attempt={draft:original};copyAttempt=attempt;copyDisclosure.disabled=true;try{if(typeof navigator?.clipboard?.writeText!=='function')throw Error('clipboard unavailable');await navigator.clipboard.writeText(original.text);if(!copyCurrent(attempt))return;draftFeedback.textContent=`已复制告知版本 ${original.notice_version}；请人工沟通并核对客户同意，未发送或保存交接。`;}catch{if(copyCurrent(attempt))draftFeedback.textContent='自动复制未完成，请选中草稿手动复制。';}finally{if(copyAttempt===attempt){copyAttempt=null;if(disclosureCurrent(original))copyDisclosure.disabled=false;else if(disclosure===original)invalidateDisclosure();}}});copyDisclosure.disabled=true;
      for(const field of [source,recipient,purpose,notice,reference,consent,phone,wechat,identity,tone]){field.addEventListener('input',invalidateDisclosure);field.addEventListener('change',invalidateDisclosure);}
      let protectedReference='',protectedScope='';const protectedStatus=element('p','','upgrade-muted');form.append(protectedStatus);
      const consentRangeChanged=()=>{if(reference.value===operatorReference)reference.value='';operatorReference=operatorConsentScope=protectedReference=protectedScope='';consent.checked=false;protectedStatus.textContent='来源、用途或接收方已变化，请重新确认客户同意。';};
      source.addEventListener('change',consentRangeChanged);recipient.addEventListener('change',consentRangeChanged);purpose.addEventListener('input',consentRangeChanged);notice.addEventListener('input',consentRangeChanged);
      mountRecovery(view,[]);
      const recovery=()=>mountRecovery(view,[['contact_create',source.value],['handoff_create',source.value]],async(action,result)=>{
        if(action==='contact_create'&&result.contact_reference){const selectedSource=source.value,contact=await read('contact_read',{contact_reference:result.contact_reference,reveal:false});if(!view.current()||source.value!==selectedSource)return;if(contact.lead_id!==selectedSource)throw Error('受保护联系记录与当前来源不一致，请核对原来源。');if(![...recipient.options].some(option=>option.value===contact.recipient_id))throw Error('原接收方不在当前授权范围，请核对交接配置。');invalidateDisclosure();recipient.value=contact.recipient_id;purpose.value=contact.purpose||'';reference.value=contact.consent?.evidence_reference||'';notice.value=contact.consent?.notice_version||'';consent.checked=false;phone.value=wechat.value='';operatorConsentScope=JSON.stringify([source.value,recipient.value,purpose.value.trim(),notice.value.trim()]);operatorReference=reference.value;const restored={lead_id:source.value,recipient_id:recipient.value,purpose:purpose.value.trim(),consent:{status:'granted',evidence_reference:reference.value.trim(),notice_version:notice.value.trim()}};protectedReference=result.contact_reference;protectedScope=JSON.stringify([restored,'','']);protectedStatus.textContent='已有受保护联系方式（'+(Object.values(contact.masked||{}).join(' · ')||'掩码暂未提供')+'），请重新确认用途和接收方；无需填写原号码。';}
        if(action==='handoff_create'&&(result.item?.id||result.id)){busy=false;close();await openDetail(result.item||{id:result.id});}
      });
      source.addEventListener('change',()=>{for(const node of view.root.querySelectorAll('.upgrade-operation-recovery'))node.remove();if(source.value)recovery();});
      button(form,'保存交接草稿',async control=>{if(!form.reportValidity())return;const consentScope=JSON.stringify([source.value,recipient.value,purpose.value.trim(),notice.value.trim()]);if(!operatorReference||operatorConsentScope!==consentScope){operatorReference='consent:'+crypto.randomUUID().replaceAll('-','');operatorConsentScope=consentScope;protectedReference=protectedScope='';}const payload={lead_id:source.value,recipient_id:recipient.value,purpose:purpose.value.trim(),consent:{status:'granted',evidence_reference:reference.value.trim()||operatorReference,notice_version:notice.value.trim()}};
        await perform(view,control,async()=>{
          const contactScope=JSON.stringify([payload,phone.value.trim(),wechat.value.trim()]);
          if(protectedReference&&protectedScope===contactScope)payload.contact_reference=protectedReference;
          else if(phone.value.trim()||wechat.value.trim()){
            protectedScope=contactScope;const record=await write('contact_create',{...payload,phone:phone.value.trim(),[REDACTED:wechat_id].value.trim()},payload.lead_id);protectedReference=record.contact_reference;if(!protectedReference)throw Error('受保护联系方式引用未返回，未创建交接。');
            payload.contact_reference=protectedReference;
          }
          const saved=await write('handoff_create',payload,payload.lead_id);phone.value=wechat.value='';view.status.textContent='本机交接草稿已保存；尚未登记送达或接收。';await refreshRecords();if(view.current()){busy=false;close();await openDetail(saved.item||{id:saved.id});}
        });if(view.current()){for(const node of view.root.querySelectorAll('.upgrade-operation-recovery'))node.remove();recovery();}
      },{primary:true});await loadSources();if(leadId){while(view.current()&&offset+25<total&&![...source.options].some(option=>option.value===leadId)){offset+=25;await loadSources();}if([...source.options].some(option=>option.value===leadId)){source.value=leadId;source.dispatchEvent(new Event('change'));}else view.status.textContent='指定来源不在当前授权范围，请选择可读取的原始评论。';}
    }catch(error){if(view.current()){view.status.textContent=error.message;view.status.dataset.state='error';}}
  }
  async function openDetail(record,{accept=()=>true}={}){
    if(typeof accept!=='function'||!accept())return false;
    const view=createDialog('核对交接记录'),originalCurrent=view.current;view.current=()=>originalCurrent()&&accept();
    try{const answer=await read('handoff_detail',{id:record.id});if(!view.current())return;let item=answer.item;if(!item)throw Error('交接明细未返回，请重新读取。');
      view.status.textContent='本机记录；跨电脑送达、公司成交和结算仍需独立回执。';
      const details=element('div');view.root.append(details);
      const rows=[['来源平台',({xiaohongshu:'小红书',douyin:'抖音',zhihu:'知乎',wechat_channels:'视频号'})[item.source?.platform]||'平台待核对'],['接收方',item.recipient_name],['交接用途',item.purpose],['当前状态',item.status_text||({draft:'待整理草稿',ready_to_deliver:'待送达',accepted:'接收记录',rejected:'已拒绝',needs_information:'待补充资料',withdrawn:'已撤回',disputed:'归属争议'})[item.status]||'状态待核对'],['资料核验',({qualified:'已完成人工核验',unreviewed:'尚未人工核验',not_qualified:'未符合交接要求'})[item.qualification]||'核验状态待核对'],['当前联系方式授权',item.current_authorization?.status_text||'当前授权待核对'],['历史接收记录',item.historical_resource_receipt_verified===true?'曾由本机授权接收人确认':'尚未取得已核验历史接收记录'],['接收记录时间',item.receipt?.recorded_at?new Date(item.receipt.recorded_at*1000).toLocaleString('zh-CN'):'尚未取得本机接收记录']];
      for(const [label,value] of rows){const row=element('div','','upgrade-record-line');row.append(element('span',label),element('strong',value||'未提供'));details.append(row);}
      if(item.current_authorization?.state!=='granted')details.append(element('p','当前授权已撤回或尚未核对；历史接收记录不代表现在可再次交付。','upgrade-authorization-warning'));
      const sourceEvidence=element('details');sourceEvidence.append(element('summary','来源证据与操作编号'));for(const [label,value]of [['客户来源身份',item.source?.author_id],['渠道编号',item.id],['版本',item.revision],['联系方式引用',item.contact_reference],['同意证据引用',item.consent?.evidence_reference],['客户告知版本',item.consent?.notice_version]]){const row=element('div','','upgrade-record-line');row.append(element('span',label),element('strong',value??'未提供'));sourceEvidence.append(row);}details.append(sourceEvidence);
      details.append(element('p',item.consent?.independently_verified===true?'客户同意证据已有独立核验记录。':'客户同意由操作人登记，尚未独立核验客户证据。','upgrade-muted'));
      if(item.contact_reference?.startsWith('contact:')){try{const contact=await read('contact_read',{contact_reference:item.contact_reference,reveal:false});if(view.current()){const row=element('div','','upgrade-record-line');row.append(element('span','联系方式掩码'),element('strong',Object.values(contact.masked||{}).join(' · ')||'未返回可见掩码'));details.append(row);}}catch{if(view.current())details.append(element('p','当前账号无法读取联系方式掩码；未请求明文。','upgrade-muted'));}}if(!view.current())return false;
      const actor=getContext()?.user?.username,permissions=item.permissions||{};
      button(view.root,'核对来源对应的公司账本',()=>businessUI.open({handoffId:item.id}));
      button(view.root,'准备公司平台线索',()=>{if(view.current())return openCompanyPreparation(item,{accept});});
      const redrawRecovery=mountRecovery(view,[['handoff_update',item.id],['handoff_submit',item.id],['handoff_receipt',item.id]],async(action,result)=>{item=result.item||item;busy=false;close();await openDetail(item);});
      async function update(action,data,control){await perform(view,control,async()=>{const result=await write(action,{id:item.id,expected_revision:item.revision,...data},item.id);item=result.item||item;await refreshRecords();if(view.current()){busy=false;close();await openDetail(item);}});if(view.current())redrawRecovery();}
      if(permissions.can_edit===true){
        const form=element('div','','upgrade-operation-form');view.root.append(form);const qualified=checkbox(form,'我已核对原始来源、客户同意、资料有效性及重复情况，确认可交接');
        button(form,'记录人工核验',async control=>{if(!qualified.checked){view.status.textContent='请先完成并勾选真实人工核验。';return;}await update('handoff_update',{operation:'edit',qualification:'qualified'},control);});
      }
      if(permissions.can_submit===true)button(view.root,'登记为待送达',control=>update('handoff_submit',{},control),{primary:true});
      if(permissions.can_withdraw===true||permissions.can_dispute===true){
        const form=element('div','','upgrade-operation-form');view.root.append(form);
        const reason=select(form,'撤回 / 争议原因','reason',[['','选择真实原因'],['customer_withdrew','客户撤回同意'],['incorrect_information','资料不正确'],['duplicate','重复线索'],['existing_customer','既有客户'],['ownership_conflict','归属冲突']]);
        const evidence=input(form,'争议证据引用（登记争议时必填）',{maxLength:200,placeholder:'evidence:实际证据32位编号'});
        if(permissions.can_withdraw===true)button(form,'登记撤回',async control=>{if(!reason.value){view.status.textContent='请选择真实撤回原因。';return;}await update('handoff_update',{operation:'withdraw',reason_code:reason.value},control);});
        if(permissions.can_dispute===true)button(form,'记录归属争议',async control=>{if(!reason.value||!/^(?:evidence|document):[a-f0-9]{32}$/.test(evidence.value.trim())){view.status.textContent='请选择争议原因并填写实际证据引用。';return;}await update('handoff_update',{operation:'dispute',reason_code:reason.value,evidence_reference:evidence.value.trim()},control);});
      }
      if(permissions.can_review===true&&actor!==item.submitted_by){
        const form=element('form','','upgrade-operation-form');form.addEventListener('submit',event=>event.preventDefault());view.root.append(form);
        form.append(element('h3','独立核对归属疑点'));
        const result=select(form,'实际核对结论','review_reason',[['','选择已核实的结论'],['reviewed_unique','核对为独立有效来源'],['needs_information','证据不足，需补充资料'],['not_qualified','资料不符合交接要求']]);result.required=true;
        const evidence=input(form,'独立核对证据引用',{required:true,pattern:'(?:evidence|document):[a-f0-9]{32}',maxLength:200,placeholder:'evidence:实际证据32位编号'});
        const confirmed=checkbox(form,'我作为获授权的另一位审核人已实际核对证据，提交人未代为审核');confirmed.required=true;
        form.append(element('p','本次只登记独立核对结果；不会确认资源部送达、成交、结算或最终客户归属。','upgrade-muted'));
        button(form,'登记独立核对结果',async control=>{if(!form.reportValidity())return;await update('handoff_update',{operation:'review',reason_code:result.value,evidence_reference:evidence.value.trim()},control);});
      }
      if(permissions.can_receipt===true&&actor!==item.submitted_by){
        const form=element('form','','upgrade-operation-form');form.addEventListener('submit',event=>event.preventDefault());view.root.append(form);
        form.append(element('h3','独立接收主体登记'));const decision=select(form,'实际接收决定','decision',[['','选择决定'],['accept','接收'],['reject','拒收'],['needs_information','待补充资料'],['duplicate','重复客户待核对'],['existing_customer','既有客户待核对']]);decision.required=true;
        const reason=select(form,'决定原因','reason',[['','接收时无需原因'],['not_qualified','线索不符合要求'],['outside_service_area','不在服务范围'],['needs_information','需要补充资料'],['duplicate','重复客户'],['existing_customer','既有客户']]);
        const evidence=input(form,'独立接收 / 拒收证据引用',{required:true,pattern:'(?:evidence|document):[a-f0-9]{32}',maxLength:200,placeholder:'evidence:实际证据32位编号'});
        const confirmed=checkbox(form,'我作为已授权接收主体已实际核对，提交人未代为确认');confirmed.required=true;
        button(form,'登记本机接收决定',async control=>{if(!form.reportValidity())return;const data={decision:decision.value,evidence_reference:evidence.value.trim()};if(decision.value!=='accept')data.reason_code=reason.value;await update('handoff_receipt',data,control);},{primary:true});
      }
      const events=Array.isArray(answer.events)?answer.events:[];if(events.length){const history=element('details'),summary=element('summary','操作记录');history.append(summary);for(const event of events)history.append(element('p',`${event.sequence}. ${event.action} · ${event.actor} · ${event.status}`,'upgrade-muted'));view.root.append(history);}
    }catch(error){if(view.current()){view.status.textContent=error.message;view.status.dataset.state='error';}}
  }
  async function openCompanyPreparation(record,{accept=()=>true}={}){
    if(typeof accept!=='function'||!accept()||!/^[a-f0-9]{32}$/.test(record?.id||''))return false;
    const view=createDialog('准备公司平台线索'),initial=privateScope(),originalCurrent=view.current,handoffId=record.id,recordRevision=record.revision;
    view.current=()=>originalCurrent()&&accept()&&privateScope()===initial&&record.id===handoffId&&record.revision===recordRevision;
    view.root.append(element('p','保存本次交接的来源和原请求编号，供后续核对公司记录。准备完成后仍需单独送达。','upgrade-muted'));
    const pane=element('section','','upgrade-operation-form');view.root.append(pane);
    const slot=companyPreparationSlot(getContext()||{},record.id);
    const loadPending=()=>{
      let value;try{value=JSON.parse(storage.getItem(slot)||'null');}catch{throw Error('本机原准备编号暂不可读，请先核对存储；暂勿保存。');}
      if(value&&!preparationExact(value,['handoff_id','expected_revision','idempotency_key'])||value&&(value.handoff_id!==record.id||!Number.isSafeInteger(value.expected_revision)||value.expected_revision<1||typeof value.idempotency_key!=='string'||!/^[A-Za-z0-9._:-]{8,128}$/.test(value.idempotency_key)))throw Error('本机原准备编号无法核对，继续保留记录；暂勿保存。');
      return value;
    };
    const clearPending=original=>{
      const fresh=loadPending();if(!fresh)return;
      if(fresh.handoff_id!==original.handoff_id||fresh.expected_revision!==original.expected_revision||fresh.idempotency_key!==original.idempotency_key)throw Error('本机原准备编号已变化，请核对当前记录。');
      storage.removeItem(slot);
    };
    let answer=null,unconfirmed=false,companyStatus=null,sourceBinding=null,registration=null,registrationUnconfirmed=false,channelCheck=null,submission=null,submissionUnconfirmed=false,companyReadGeneration=0;
    function render(){
      if(!view.current())return;
      pane.replaceChildren();const original=loadPending();
      if(!answer){view.status.textContent='本机准备记录尚未读取；暂勿保存。';}
      else if(answer.state==='prepared'){
        pane.append(element('h3','已保存本次准备'));
        const usable=answer.current.preparation_usable;
        pane.append(element('p',usable?'当前来源与授权可用于本次准备。':'当前来源或授权需要重新核对，原准备记录继续保留。',usable?'upgrade-muted':'upgrade-authorization-warning'));
        const companyRegistrationKnown=registrationUnconfirmed||registration&&registration.state!=='not_attempted'||channelCheck?.origin_binding_verified||submission?.origin_binding_verified;
        pane.append(element('p',companyRegistrationKnown?'保存准备这一步没有向公司发送。公司登记结果以本页草稿核对记录为准；本机来源归档不等于公司确认。':'本次准备没有向公司发送（仅指保存准备这一步）。更早的公司操作状态仍待核对；本机来源归档不等于公司确认。','upgrade-muted'));
        const details=element('details');details.append(element('summary','原请求与来源摘要'));
        for(const [label,value] of [['本机原准备编号',answer.idempotency_key],['准备时交接版本',answer.origin.local_handoff_revision],['公司原请求编号',answer.origin.cloud_idempotency_key],['预期公司渠道编号',answer.origin.expected_cloud_channel_id],['来源核对',answer.current.source_state==='matched'?'与准备时一致':'需重新核对'],['本机来源归档','已登记；公司来源绑定尚未验证']]){const row=element('div','','upgrade-record-line');row.append(element('span',label),element('strong',value));details.append(row);}
        pane.append(details);view.status.textContent=usable?'准备已保存，尚未送达。':'准备已保存，当前交付保持暂停。';
      }else{
        pane.append(element('h3','尚未保存本次准备'));
        pane.append(element('p','请先完成当前交接的人工核验、客户授权与原来源归档，再保存准备记录。','upgrade-muted'));
        view.status.textContent='这里只保存本次准备；公司送达和接收仍需后续独立回执。';
      }
      if(original||unconfirmed){pane.append(element('p',original?`这次保存结果尚未确认。原编号：${original.idempotency_key}`:'保存结果尚未确认，请回到原范围读取准备记录。','upgrade-authorization-warning'));view.status.textContent='原准备结果待核对；暂勿重复保存。';}
      button(pane,'读取原准备记录',control=>perform(view,control,async()=>{await load();}));
      if(answer?.state==='prepared'){
        button(pane,'联系方式交付与授权撤回',()=>{
          if(!view.current())return;
          const contactScope=companyContactScope(getContext()||{}),channelId=answer.origin.expected_cloud_channel_id;
          return companyContactUI.open({channelId,mode:'source',contactReference:record.contact_reference||null,leadId:record.lead_id||null,recipientId:record.recipient_id||null,purpose:record.purpose||null},{accept:()=>accept()&&contactScope===companyContactScope(getContext()||{})&&record.id===handoffId&&record.revision===recordRevision});
        });
        button(pane,'核对原公司操作',control=>perform(view,control,async()=>{
          if(!view.current())return;
          const expected=answer.origin;
          companyStatus=null;sourceBinding=null;channelCheck=null;submission=null;companyReadGeneration++;
          render();view.status.textContent='正在核对原公司操作…';
          const result=await read('company_handoff_original_status',{handoff_id:record.id});
          if(!view.current())return;
          companyStatus=checkedCompanyOriginalStatus(result,{handoffId:record.id,origin:expected});
          answer={...answer,current:{...companyStatus.current_local}};
          render();
        },{message:'正在核对原公司操作…'}));
        button(pane,'核对原来源公司记录',control=>perform(view,control,async()=>{
          if(!view.current())return;
          const expected=answer.origin;
          sourceBinding=null;companyStatus=null;channelCheck=null;submission=null;companyReadGeneration++;
          render();view.status.textContent='正在核对原来源公司记录…';
          const result=await read('company_handoff_source_binding_get',{handoff_id:record.id});
          if(!view.current())return;
          sourceBinding=checkedCompanySourceBinding(result,{handoffId:record.id,origin:expected});
          answer={...answer,current:{...sourceBinding.current_local}};
          render();
        },{message:'正在核对原来源公司记录…'}));
        button(pane,'核对公司当前来源',control=>perform(view,control,async()=>{
          if(!view.current())return;
          const expected={...answer.origin},generation=++companyReadGeneration;
          channelCheck=null;companyStatus=null;sourceBinding=null;submission=null;render();view.status.textContent='正在核对公司当前草稿来源…';
          const result=await read('company_handoff_channel_check_get',{handoff_id:record.id});
          if(!view.current()||generation!==companyReadGeneration||answer?.origin?.origin_id!==expected.origin_id||answer.origin.local_handoff_revision!==expected.local_handoff_revision)return;
          channelCheck=checkedCompanyChannelCheck(result,{handoffId:record.id,origin:expected});
          answer={...answer,current:{...channelCheck.current_local}};registration=null;render();
        },{message:'正在核对公司当前草稿来源…'}));

      }
      if(companyStatus){
        const section=element('section','','upgrade-operation-form');pane.append(section);
        section.append(element('h3',companyStatus.state==='recorded'?'已核对到原公司登记':'原公司登记仍未知'));
        section.append(element('p',companyStatus.state==='recorded'?'原登记与保存的准备编号一致。':'当前未取得可确认的原登记记录，请保留原编号，暂勿重发。','upgrade-muted'));
        const current=companyStatus.current_local;
        section.append(element('p',current.preparation_usable?'本机当前准备条件保持；公司交付仍需独立核对。':'本机当前交付保持暂停，历史登记继续保留。','upgrade-muted'));
        if(companyStatus.current_company){
          const labels={draft:'草稿',submitted:'已提交',accepted:'已接收',rejected:'已拒收',needs_information:'待补充',duplicate_pending_review:'重复客户待核对',existing_customer_pending_review:'既有客户待核对',withdrawn:'已撤回',disputed:'争议待核对'};
          for(const [label,value] of [['公司当前交接状态',labels[companyStatus.current_company.status]],['公司当前授权',companyStatus.current_company.current_consent_valid?'有效':'当前无有效授权'],['历史接收登记',companyStatus.current_company.historical_resource_receipt_recorded?'已记录，证据待独立核对':'尚未记录']]){const row=element('div','','upgrade-record-line');row.append(element('span',label),element('strong',value));section.append(row);}
        }
        section.append(element('p','此次只读取原记录；平台送达、独立接收证据、合作分成和实际回款仍未核验。','upgrade-muted'));
        view.status.textContent=companyStatus.state==='recorded'?'原公司登记已对应；请继续核对当前交付条件。':'原公司登记仍未知；原准备编号继续保留。';
      }

      if(sourceBinding){
        const section=element('section','','upgrade-operation-form');pane.append(section);
        section.append(element('h3',sourceBinding.state==='matched'?'公司已留存对应原事件':'原来源公司记录仍待核对'));
        section.append(element('p',sourceBinding.state==='matched'?'公司账本留存的原设备上报事件，与保存准备的摘要一致。':'此次未读到对应原事件，请保留原准备；不能据此判断以前没有上传或发送。','upgrade-muted'));
        section.append(element('p',sourceBinding.current_local.preparation_usable?'本机当前准备条件保持；公司交付仍需独立核对。':'本机当前交付保持暂停，原来源记录继续保留。','upgrade-muted'));
        if(sourceBinding.source_event){
          const labels={reviewed:'人工复核上报',send_started:'开始发送上报',sent:'已发送上报',failed:'失败上报',unknown:'结果未知上报',copied:'复制上报',external_reported:'人工外部记录'};
          const row=element('div','','upgrade-record-line');row.append(element('span','原事件类型'),element('strong',labels[sourceBinding.source_event.kind]));section.append(row);
        }
        section.append(element('p','此次只读取公司留存记录；平台事实、客户同意、独立接收与实际回款仍需各自证据。','upgrade-muted'));
        view.status.textContent=sourceBinding.state==='matched'?'原事件已对应；当前交付条件仍单独核对。':'原来源公司记录仍待核对；原准备继续保留。';
      }

      if(channelCheck){
        const section=element('section','','upgrade-operation-form');pane.append(section);
        const matched=channelCheck.current_channel_source_matched;
        const matchedLabel=channelCheck.current_company?.status==='draft'?'公司当前草稿来源已对应':'公司当前交接来源已对应';
        section.append(element('h3',matched?matchedLabel:channelCheck.state==='registration_unknown'?'原公司登记仍未知':channelCheck.state==='not_attempted'?'本机尚未记录登记尝试':'尚无本机原准备'));
        section.append(element('p',matched?'此次公司渠道详情与原客户、原来源及原准备一致；这是公司设备上报记录的核对。':channelCheck.state==='registration_unknown'?'原编号登记仍未知，请保留原记录，暂勿再次提交。':'本机缺少对应准备或尝试记录；不能据此断言公司以前没有记录或执行。','upgrade-muted'));
        if(channelCheck.original_operation){
          section.append(element('p',channelCheck.registration_source_verified?'原登记回显已保存；与本次当前来源核对分别留存。':'原登记回显未保存，历史来源回显仍待核对。','upgrade-muted'));
          section.append(element('p',channelCheck.company_event_payload_matched?'公司留存的原事件摘要已对应。':'原来源公司事件仍待核对。','upgrade-muted'));
        }
        if(channelCheck.current_company){
          const labels={draft:'草稿',submitted:'已提交',accepted:'已接收',rejected:'已拒收',needs_information:'待补充',duplicate_pending_review:'重复客户待核对',existing_customer_pending_review:'既有客户待核对',withdrawn:'已撤回',disputed:'争议待核对'};
          for(const [label,value]of [['公司当前状态',labels[channelCheck.current_company.status]],['公司当前授权',channelCheck.current_company.current_consent_valid?'有效':'当前无有效授权']]){const row=element('div','','upgrade-record-line');row.append(element('span',label),element('strong',value));section.append(row);}
        }
        section.append(element('p',channelCheck.state==='matched'?'本机当前准备条件保持；本次仍未向资源部提交。':channelCheck.state==='hold'?'本机当前交付保持暂停，来源对应和历史登记继续保留。':'公司交付仍需继续核对原编号及当前授权。',channelCheck.state==='hold'?'upgrade-authorization-warning':'upgrade-muted'));
        section.append(element('p','此次只读核对；资源部独立接收、成交与回款仍未核验，不能据此确认平台送达或分成。','upgrade-muted'));
        view.status.textContent=channelCheck.state==='matched'?matchedLabel+'；本次未执行资源部交付。':channelCheck.state==='hold'?'公司当前来源已核对，当前交付保持暂停。':'原公司来源仍待核对；原编号继续保留。';
      }

      if(answer?.state==='prepared'&&!original&&!unconfirmed){
        const section=element('section','','upgrade-operation-form');pane.append(section);
        section.append(element('h3','公司平台线索草稿'));
        section.append(element('p','登记原平台线索到当前公司；资源部接收、联系方式交付和成交仍需后续独立确认。','upgrade-muted'));
        button(section,registrationUnconfirmed||registration&&registration.state!=='not_attempted'?'核对原公司草稿':'登记或核对公司草稿',control=>perform(view,control,async()=>{await loadRegistration();},{message:'正在读取原公司草稿登记状态…'}));
        if(registrationUnconfirmed){section.append(element('p','这次登记结果待核对，请保留原编号；此处仅提供原号核对，不再次提交。','upgrade-authorization-warning'));view.status.textContent='公司草稿登记结果待核对。';}
        if(registration?.state==='not_attempted'&&!registrationUnconfirmed){
          if(!registration.can_register){section.append(element('p','当前准备条件未满足，请先核对原来源、客户同意和交接状态。','upgrade-authorization-warning'));}
          else{
            for(const [label,value]of [['原客户来源',record.source?.author_id||'请核对原交接客户'],['接收方',record.recipient_name||record.recipient_id||'未提供'],['交接用途',record.purpose||'未提供']]){const row=element('div','','upgrade-record-line');row.append(element('span',label),element('strong',value));section.append(row);}
            const expected={...answer.origin};
            const confirmed=checkbox(section,'我确认将这位原客户登记为当前公司平台线索草稿，并已核对接收方、用途及客户授权');
            const register=button(section,'确认登记公司草稿',control=>perform(view,control,async()=>{
              if(!view.current()||!confirmed.checked||registrationUnconfirmed||registration?.state!=='not_attempted'||!registration.can_register||answer.origin.origin_id!==expected.origin_id||answer.origin.local_handoff_revision!==expected.local_handoff_revision)return;
              confirmed.checked=false;registrationUnconfirmed=true;
              try{
                const response=await execute('company_handoff_register',{handoff_id:record.id,expected_origin_id:expected.origin_id,expected_handoff_revision:expected.local_handoff_revision});
                if(!view.current())return;
                if(response?.status!=='succeeded'||!response.result)throw Error(response?.error?.message||response?.error||'公司草稿登记结果尚未确认，请按原编号核对。');
                registration=checkedCompanyRegistration(response.result,{handoffId:record.id,origin:expected,readOnly:false});
                answer={...answer,current:{...registration.current_local}};registrationUnconfirmed=false;companyStatus=null;sourceBinding=null;channelCheck=null;submission=null;companyReadGeneration++;render();
              }catch(error){if(view.current()){registration=null;render();}throw error;}
            },{message:'正在按原编号登记公司草稿…'}),{primary:true});
            register.disabled=true;confirmed.addEventListener('change',()=>{register.disabled=!view.current()||!confirmed.checked||registrationUnconfirmed||registration?.state!=='not_attempted';});
          }
        }
        if(registration&&registration.state!=='not_attempted'){
          const recorded=registration.state==='recorded';
          section.append(element('p',recorded?(registration.registration_source_verified?'公司原编号草稿登记已核对，登记来源摘要一致。':'原编号已有公司草稿记录，登记来源证据仍待核对。'):'原编号登记结果仍未知，请继续保留原记录。',recorded&&registration.registration_source_verified?'upgrade-muted':'upgrade-authorization-warning'));
          if(registration.current_company){const labels={draft:'草稿',submitted:'已提交',accepted:'已接收',rejected:'已拒收',needs_information:'待补充',duplicate_pending_review:'重复待核对',existing_customer_pending_review:'既有客户待核对',withdrawn:'已撤回',disputed:'争议待核对'};const row=element('div','','upgrade-record-line');row.append(element('span','公司当前状态'),element('strong',labels[registration.current_company.status]));section.append(row);}
          section.append(element('p',registration.current_local.preparation_usable?'本机准备条件保持；资源部交付尚未执行。':'本机当前交付保持暂停，历史原编号继续保留。','upgrade-muted'));
          section.append(element('p','此次不确认资源部独立接收、平台送达、成交、分成或回款。','upgrade-muted'));
          view.status.textContent=recorded?'原编号公司草稿已核对；尚未执行资源部交付。':'原编号公司登记仍待核对，暂勿再次提交。';
        }
      }
      if(answer?.state==='not_prepared'&&!original&&!unconfirmed){
        const ready=answer.current.status==='ready_to_deliver'&&answer.current.qualification==='qualified'&&answer.current.consent_state==='granted'&&answer.current.source_state==='matched';
        const control=button(pane,'保存本次准备',control=>perform(view,control,async()=>{
          if(!view.current()||loadPending()||unconfirmed)return;
          const original={handoff_id:record.id,expected_revision:answer.current.revision,idempotency_key:crypto.randomUUID()};
          storage.setItem(slot,JSON.stringify(original));
          if(!view.current()){clearPending(original);return;}
          let confirmed=false;
          try{
            const response=await execute('company_handoff_prepare',original);
            if(!view.current())return;
            if(response?.status!=='succeeded'||!response.result){const error=Error(response?.error?.message||response?.error||'本次准备结果尚未确认。');error.mutation_committed=response?.mutation_committed??response?.error?.mutation_committed;throw error;}
            const prepared=checkedCompanyPreparation(response.result,{handoffId:record.id,key:original.idempotency_key,expectedRevision:original.expected_revision,readOnly:false});
            clearPending(original);confirmed=true;answer=prepared;unconfirmed=false;render();
          }catch(error){
            if(!view.current())return;
            if(!confirmed&&error.mutation_committed===false)clearPending(original);
            else unconfirmed=true;
            render();throw error;
          }
        }),{primary:true});control.disabled=!ready;
        if(!ready)pane.append(element('p','当前交接状态、核验或授权尚未满足准备条件，请先核对原交接。','upgrade-muted'));
      }
      if(channelCheck?.current_channel_source_matched){
        const current=channelCheck.state==='hold'?'公司当前来源已对应，当前交付保持暂停':'公司当前来源已对应';
        view.status.textContent=current+(channelCheck.registration_source_verified?'；本次未执行资源部交付。':'；原登记回显仍待核对。');
      }
      if(answer?.state==='prepared'&&!original&&!unconfirmed){
        const section=element('section','','upgrade-operation-form');pane.append(section);
        section.append(element('h3','公司资源部提交'));
        section.append(element('p','先按原准备核对提交记录；符合当前授权后，再由你明确确认提交。','upgrade-muted'));
        section.append(element('p','本次仅提交平台身份引用，不交付手机号或微信；不会自动发送评论或私信。','upgrade-muted'));
        button(section,submission?.attempt||submissionUnconfirmed?'核对原公司提交':'核对或提交资源部',control=>perform(view,control,async()=>{await loadSubmission();},{message:'正在读取原公司提交与当前条件…'}));
        if(submissionUnconfirmed){section.append(element('p','这次提交结果仍待核对，只读取原编号，不再次提交或更换编号。','upgrade-authorization-warning'));view.status.textContent='原公司提交仍待核对；请保留原编号。';}
        if(submission){
          if(submission.state==='not_attempted'){
            section.append(element('p','本机尚未记录此原准备的提交尝试；这不证明公司过去没有记录或执行。','upgrade-muted'));
            if(!submission.eligible_for_company_submit||submissionUnconfirmed)section.append(element('p','当前提交保持暂停，请核对原公司记录、客户授权与来源。','upgrade-authorization-warning'));
            else{
              section.append(element('p',submission.registration_source_verified?'原登记及当前来源已分别核对。':'公司当前来源已对应；原登记回显未保存，历史来源回显仍待核对。','upgrade-muted'));
              for(const [label,value]of [['原客户','原交接客户'],['接收方',record.recipient_name||'原准备的接收方'],['交接用途',record.purpose||'原准备的用途']]){const row=element('div','','upgrade-record-line');row.append(element('span',label),element('strong',value));section.append(row);}
              const expected={...answer.origin},localRevision=answer.current.revision,companyRevision=submission.current_company.revision,eligible=submission,ticket=companyReadGeneration;
              const confirmed=checkbox(section,'我已核对原客户、接收方、用途和当前授权，确认将平台线索提交公司资源部');
              const current=()=>view.current()&&ticket===companyReadGeneration&&submission===eligible&&!submissionUnconfirmed&&submission.eligible_for_company_submit&&answer?.origin?.origin_id===expected.origin_id&&answer.origin.local_handoff_revision===expected.local_handoff_revision&&answer.current.revision===localRevision;
              const submit=button(section,'确认提交资源部',control=>perform(view,control,async()=>{
                if(!current()||!confirmed.checked)return;
                const generation=++companyReadGeneration;
                confirmed.checked=false;submissionUnconfirmed=true;submission=null;channelCheck=null;companyStatus=null;sourceBinding=null;registration=null;render();
                const fresh=()=>view.current()&&generation===companyReadGeneration&&answer?.origin?.origin_id===expected.origin_id&&answer.origin.local_handoff_revision===expected.local_handoff_revision&&answer.current.revision===localRevision;
                try{
                  const response=await execute('company_handoff_submit',{handoff_id:handoffId,expected_origin_id:expected.origin_id,expected_handoff_revision:expected.local_handoff_revision,expected_cloud_revision:companyRevision});
                  if(!fresh())return;
                  if(response?.status!=='succeeded'||!response.result){const error=Error(response?.error?.message||response?.error||'公司原提交尚未确认，请只读核对原编号。');error.mutation_committed=response?.mutation_committed??response?.error?.mutation_committed;throw error;}
                  const checked=checkedCompanySubmission(response.result,{handoffId,origin:expected,readOnly:false,expectedCloudRevision:companyRevision});
                  submission=checked;answer={...answer,current:{...checked.current_local}};submissionUnconfirmed=false;render();
                }catch(error){if(fresh()){if(error.mutation_committed===false)submissionUnconfirmed=false;submission=null;render();}throw error;}
              },{message:'正在按固定原编号提交公司资源部…'}),{primary:true});
              submit.disabled=true;confirmed.addEventListener('change',()=>{submit.disabled=!current()||!confirmed.checked;});
              view.status.textContent='当前条件已核对；勾选确认后才提交公司资源部。';
            }
          }else if(submission.state==='unknown'){
            section.append(element('p','原公司提交结果未知；缺少回执不能证明未执行，只能按原号继续核对。','upgrade-authorization-warning'));
            view.status.textContent='原公司提交仍未知；未自动重发。';
          }else if(submission.state==='recorded'){
            section.append(element('h3','原公司提交已核对'));
            section.append(element('p','原编号历史记录为已提交；本次核对不会再次提交，不代表资源部已独立接收或成交。','upgrade-muted'));
            if(!submission.registration_source_verified)section.append(element('p','原登记回显未保存，历史来源回显仍待核对；不抹去已核对的原提交事实。','upgrade-authorization-warning'));
            const labels={draft:'草稿',submitted:'已提交，待接收',accepted:'接收已登记，证据待核对',rejected:'已拒收',needs_information:'待补充',duplicate_pending_review:'重复客户待核对',existing_customer_pending_review:'既有客户待核对',withdrawn:'已撤回',disputed:'争议待核对'},company=submission.current_company;
            for(const [label,value]of [['原操作历史','已提交'],['公司当前状态',labels[company.status]],['客户当前公司授权',company.current_consent_valid?'有效':'当前无有效授权'],['资源部历史接收记录',company.historical_resource_receipt_recorded?'已记录；接收证据待独立核对':'尚未记录'],['本机当前授权',submission.current_local.consent_state==='granted'?'操作人已登记，尚未独立核验':'当前无有效登记授权']]){const row=element('div','','upgrade-record-line');row.append(element('span',label),element('strong',value));section.append(row);}
            view.status.textContent='原公司提交已核对'+(company.status==='withdrawn'?'；当前已撤回。':'；独立接收仍需核对。');
          }
          section.append(element('p','平台送达、资源部独立接收证据、成交、分成支付与实际回款各自核对；此处不会把本机客户标为已联系或已交付。','upgrade-muted'));
        }
      }
    }
    async function loadSubmission(){
      if(!view.current()||answer?.state!=='prepared')return;
      const expected={...answer.origin},localRevision=answer.current.revision,generation=++companyReadGeneration;
      submission=null;channelCheck=null;companyStatus=null;sourceBinding=null;registration=null;render();view.status.textContent='正在读取原公司提交与当前条件…';
      const result=await read('company_handoff_submission_get',{handoff_id:handoffId});
      if(!view.current()||generation!==companyReadGeneration||answer?.origin?.origin_id!==expected.origin_id||answer.origin.local_handoff_revision!==expected.local_handoff_revision||answer.current.revision!==localRevision)return;
      submission=checkedCompanySubmission(result,{handoffId,origin:expected,readOnly:true});
      if(submission.attempt)submissionUnconfirmed=false;
      answer={...answer,current:{...submission.current_local}};render();
    }
    async function loadRegistration(){
      if(!view.current()||answer?.state!=='prepared')return;
      const expected={...answer.origin};registration=null;channelCheck=null;submission=null;companyReadGeneration++;render();
      const result=await read('company_handoff_registration_get',{handoff_id:record.id});
      if(!view.current()||answer.origin.origin_id!==expected.origin_id||answer.origin.local_handoff_revision!==expected.local_handoff_revision)return;
      registration=checkedCompanyRegistration(result,{handoffId:record.id,origin:expected,readOnly:true});
      answer={...answer,current:{...registration.current_local}};registrationUnconfirmed=false;companyStatus=null;sourceBinding=null;render();
    }
    async function load(){
      if(!view.current())return;
      channelCheck=null;submission=null;companyReadGeneration++;render();
      const result=await read('company_handoff_preparation_get',{handoff_id:record.id});
      if(!view.current())return;
      const checked=checkedCompanyPreparation(result,{handoffId:record.id,readOnly:true}),original=loadPending();
      if(checked.state==='prepared'&&original&&checked.idempotency_key===original.idempotency_key&&checked.origin.local_handoff_revision===original.expected_revision)clearPending(original);
      answer=checked;companyStatus=null;sourceBinding=null;registration=null;if(checked.state==='prepared'&&!loadPending())unconfirmed=false;render();
    }
    try{await load();}catch(error){if(view.current()){pane.replaceChildren();view.status.textContent=error.message||'本机准备记录暂不可读。';view.status.dataset.state='error';button(pane,'读取原准备记录',control=>perform(view,control,async()=>{await load();}));}}
    return true;
  }

  async function openStrategy(){
    const view=createDialog('编辑房源与获客策略');
    try{let strategy=await read('strategy_get');if(!view.current())return;if(strategy.can_manage!==true){view.status.textContent='当前账号只能查看策略范围，不能编辑词库。';return;}
      const redrawRecovery=mountRecovery(view,[['strategy_save',strategy.id||'strategy'],['strategy_import',strategy.id||'strategy']],async()=>{busy=false;close();await openStrategy();});
      const form=element('form','','upgrade-operation-form');form.addEventListener('submit',event=>event.preventDefault());view.root.append(form);
      const name=input(form,'策略名称',{required:true,value:strategy.name,maxLength:80});const city=input(form,'城市',{value:strategy.city,maxLength:40});const area=input(form,'区域 / 附近',{value:strategy.area,maxLength:80});
      const batch=input(form,'活跃批次（1–100）',{type:'number',value:strategy.active_batch_size,min:1,max:100,required:true});const quota=input(form,'总查询额度（词查询槽位）',{type:'number',value:strategy.total_query_quota,min:1,max:1000000,required:true});
      const enabled=checkbox(form,'启用此策略');enabled.checked=strategy.enabled===true;view.status.textContent='编辑仅保存后台策略，不自动开始平台采集。';
      button(form,'保存策略',async control=>{if(!form.reportValidity())return;await perform(view,control,async()=>{strategy=await write('strategy_save',{expected_revision:strategy.revision,name:name.value.trim(),city:city.value.trim(),area:area.value.trim(),active_batch_size:Number(batch.value),total_query_quota:Number(quota.value),enabled:enabled.checked},strategy.id||'strategy');view.status.textContent='策略已保存；未发起平台采集。';await shell.refresh('management');});if(view.current())redrawRecovery();},{primary:true});
      const importBox=element('details'),summary=element('summary','追加关键词 / 预览活跃批次');importBox.append(summary);form.append(importBox);const textarea=element('textarea');textarea.rows=6;textarea.placeholder='每行一个已审核关键词；每次最多追加500行。';textarea.setAttribute('aria-label','待追加关键词');importBox.append(textarea);const preview=element('div','','upgrade-keyword-preview');importBox.append(preview);
      button(importBox,'追加这一批关键词',async control=>{const rows=keywordImportRows(textarea.value);if(!rows.length){view.status.textContent='请先填写需要追加的关键词。';return;}await perform(view,control,async()=>{strategy=await write('strategy_import',{expected_revision:strategy.revision,mode:'append',keywords:rows},strategy.id||'strategy');const rest=textarea.value.split(/\r?\n/).map(value=>value.trim()).filter(Boolean).slice(rows.length);textarea.value=rest.join('\n');view.status.textContent=`本批新增${strategy.added??'待核对'}个，重复${strategy.duplicates??'待核对'}个；剩余${rest.length}行。未启动平台请求。`;await shell.refresh('management');});if(view.current())redrawRecovery();});
      button(importBox,'只预览下一批',async control=>{control.disabled=true;try{const result=await read('strategy_preview_batch',{limit:Math.min(100,Number(batch.value)||20)});if(!view.current())return;preview.replaceChildren();for(const row of result.keywords||[])preview.append(element('span',row.keyword,'upgrade-chip'));view.status.textContent='这是离线调度预览，不消耗平台请求配额，也不开始采集。';}catch(error){if(view.current())view.status.textContent=error.message;}finally{control.disabled=false;}});
      const snapshot=element('details'),snapshotTitle=element('summary','建立单批采集快照');snapshot.append(snapshotTitle);view.root.append(snapshot);
      snapshot.append(element('p','快照将冻结后台本批策略与检索词，员工界面不展示私有词库。创建只保存任务，不自动采集。','upgrade-muted'));
      const accounts=(getContext()?.accounts||[]).filter(account=>['xiaohongshu','douyin','zhihu','wechat_channels'].includes(account.platform)&&primaryEntryAllowed(account.platform));
      const account=select(snapshot,'实际平台账号','account_id',[['','选择本机平台账号'],...accounts.map(item=>[item.id,`${({xiaohongshu:'小红书',douyin:'抖音',zhihu:'知乎',wechat_channels:'视频号'})[item.platform]} · ${item.display_name||item.nickname||item.name||item.label||item.id} · ${item.requires_review?'待核实':item.status==='ready'?'已连接':'状态待核对'}`])]);
      const snapshotName=input(snapshot,'快照名称',{maxLength:100,value:'后台策略采集'}),snapshotSize=input(snapshot,'冻结词数（1–100）',{type:'number',value:strategy.active_batch_size||20,min:1,max:100,required:true});
      const taskId=input(snapshot,'已保存的任务编号（查看时填写）',{maxLength:160,placeholder:'创建成功后自动填入'}),taskResult=element('div','','upgrade-keyword-preview');snapshot.append(taskResult);
      function renderTask(task){if(!view.current()||!task)return;taskId.value=task.id||'';taskResult.replaceChildren();for(const [label,value] of [['任务名称',task.name],['任务编号',task.id],['平台',({xiaohongshu:'小红书',douyin:'抖音',zhihu:'知乎',wechat_channels:'视频号'})[task.platform]||'平台待核对'],['版本',task.strategy?.revision],['本批冻结词数',task.strategy?.keyword_count],['任务状态',task.status==='paused'?'已暂停':task.exhausted?'本批已完成':'已保存快照'],['本批已保存',task.last_batch?.imported]]){const row=element('div','','upgrade-record-line');row.append(element('span',label),element('strong',value??'未提供'));taskResult.append(row);}taskResult.append(element('p','本机策略快照；未确认跨电脑执行或传递。开始采集需到采集任务核对许可、账号与单批运行。','upgrade-muted'));if(!primaryEntryAllowed(task.platform))taskResult.append(element('p',PLATFORM_ENTRY_SCOPE_TEXT,'upgrade-muted'));if(primaryEntryAllowed(task.platform)&&typeof task.id==='string'&&/^[A-Za-z0-9_-]{1,160}$/.test(task.id)){const originalTaskId=task.id,originalScope=privateScope();button(taskResult,'确认原快照单批运行',()=>{if(view.current()&&originalScope===privateScope())return openPrivateSingleBatch({taskId:originalTaskId},{accept:()=>originalScope===privateScope()});});}}
      const redrawTaskRecovery=mountRecovery(view,[['strategy_task_create','strategy-snapshot']],async(action,result)=>renderTask(result.task));
      button(snapshot,'只创建本批快照',async control=>{const selected=accounts.find(item=>item.id===account.value);if(!selected){view.status.textContent='请选择本机实际平台账号。';return;}if(!primaryEntryAllowed(selected.platform)){view.status.textContent=PLATFORM_ENTRY_SCOPE_TEXT;return;}if(selected.requires_review||selected.status!=='ready'){view.status.textContent='所选账号需先核实，未创建快照。';return;}if(!snapshotSize.reportValidity()||!snapshotName.reportValidity())return;await perform(view,control,async()=>{const result=await write('strategy_task_create',{expected_revision:strategy.revision,platform:selected.platform,account_id:selected.id,name:snapshotName.value.trim(),batch_size:Number(snapshotSize.value)},'strategy-snapshot');renderTask(result.task);view.status.textContent='本批快照已保存，未开始平台采集。';await shell.refresh('management');});if(view.current())redrawTaskRecovery();},{primary:true});
      button(snapshot,'查看这个任务',async control=>{if(!taskId.value.trim()){view.status.textContent='请先填写已保存的任务编号。';return;}control.disabled=true;try{const result=await read('strategy_task_get',{task_id:taskId.value.trim()});if(view.current()){renderTask(result.task);view.status.textContent='已读取本机快照；未发起平台请求。';}}catch(error){if(view.current())view.status.textContent=error.message;}finally{control.disabled=false;}});
    }catch(error){if(view.current()){view.status.textContent=error.message;view.status.dataset.state='error';}}
  }
  const rulesUI=createIntentRuleUI({createDialog,read,write,scope,perform,pending,recover,onSaved:()=>shell.refresh('management')});
  const platformReadsUI=createPlatformReadUI({createDialog,read,scope:platformReadScope,getContext,write,perform,pending,recover,openItem:openWorkItem,closeDialog:close,onAnalyzed:()=>{if(!disposed)document.dispatchEvent(new CustomEvent('upgrade:source-intent-changed',{detail:{operationScope:scope()}}));}});
  const qualityUI=createIntentQualityUI({createDialog,read,write,scope,perform,pending,recover});
  const companyPolicyUI=createCompanyPolicyUI({createDialog,read,write,scope,perform,pending,recover});
  const businessUI=createBusinessReconciliationUI({createDialog,read,scope});
  const selfWorklistUI=createSelfWorklistUI({createDialog,read,scope,openItem:openWorkItem,onError});
  shell.hooks.setAction('self-worklist-open',()=>void selfWorklistUI.open());
  const selfDailyEvidenceUI=createSelfDailyEvidenceUI({createDialog,read,scope});
  const companyContactUI=createCompanyContactDeliveryUI({createDialog,execute,getContext});
  const companyReceiverUI=createCompanyHandoffReceiverUI({createDialog,execute,getContext,openContacts:(options,controls)=>companyContactUI.open(options,controls),clearSensitiveContacts:()=>companyContactUI.clearSensitive()});
  shell.hooks.setAction('self-daily-evidence-open',()=>void selfDailyEvidenceUI.open());
  shell.hooks.setAction('company-policy-open',()=>void companyPolicyUI.open());
  shell.hooks.setAction('intent-quality-open',()=>void qualityUI.open());
  shell.hooks.setAction('ai-attempt-open',()=>void openAIAttempts());
  shell.hooks.setAction('platform-read-open',()=>void platformReadsUI.open());
  shell.hooks.setAction('intent-rule-edit',()=>void rulesUI.open());
  shell.hooks.setAction('intent-rule-preview',leadId=>void rulesUI.open({leadId}));
  shell.hooks.setAction('handoff-create',()=>void openCreate());shell.hooks.setAction('handoff-open',record=>void openDetail(record));shell.hooks.setAction('strategy-edit',()=>void openStrategy());shell.hooks.setAction('handoff-export',()=>void openExport());
  return {openManualReplyConfirmation,openManualReplyLocator,openCreate,openDetail,openCompanyPreparation,openCompanyInbox:()=>companyReceiverUI.open(),clearSensitiveContacts:()=>{companyContactUI.clearSensitive();clearManualLocator();},openRunPreflight,openPrivateSingleBatch,openStrategy,openExport,openAIAttempts,openBusinessReconciliation:options=>businessUI.open(options),openSelfWorklist:()=>selfWorklistUI.open(),openSelfDailyEvidence:()=>selfDailyEvidenceUI.open(),openIntentQuality:()=>qualityUI.open(),openCompanyPolicy:()=>companyPolicyUI.open(),openIntentRules:options=>rulesUI.open(options),openPlatformReads:()=>platformReadsUI.open(),reset(){clearManualLocator();activeOperation++;busy=false;companyContactUI.reset();rulesUI.reset();platformReadsUI.reset();qualityUI.reset();companyPolicyUI.reset();businessUI.reset();selfWorklistUI.reset();selfDailyEvidenceUI.reset();companyReceiverUI.reset();close();},dispose(){clearManualLocator();activeOperation++;disposed=true;busy=false;companyContactUI.dispose();rulesUI.dispose();platformReadsUI.dispose();qualityUI.dispose();companyPolicyUI.dispose();businessUI.dispose();selfWorklistUI.dispose();selfDailyEvidenceUI.dispose();companyReceiverUI.dispose();close();},write,recover};
}
