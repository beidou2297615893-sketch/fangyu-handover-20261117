/* Employee-local recommendations. Every business action keeps its own gate. */
const lanes=['check_record','response','handoff','draft','contact'];
const laneLabels={all:'全部待办',check_record:'先核对记录',response:'查看客户回应',handoff:'继续整理交接',draft:'继续已有草稿',contact:'核对后联系'};
const reasons={journal_unreadable:'联系历史暂不可完整核对',contact_result_unknown:'已有联系结果尚未确认',contact_record_unverified:'联系记录尚未核验',source_identity_unverified:'来源账号身份需要核对',source_text_missing:'来源正文需要补齐',source_version_changed:'来源内容已变化',history_scope_unavailable:'部分历史当前无权读取',handoff_audit_conflict:'交接审计记录需要核对',authorization_not_current:'当前客户授权需要核对',handoff_needs_review:'交接资料尚需人工核验',draft_snapshot_changed:'原草稿来源或账号已变化',draft_owner_unverified:'原草稿归属需要核对',permission_unavailable:'当前操作权限需要核对',response_observed:'已保存可核对的客户回应',handoff_pending:'已有当前有权待整理的交接',draft_existing:'已有草稿，请先继续原记录',high_intent_uncontacted:'高意向客户尚无已记录联系'};
const falseFlags=['cross_machine_verified','platform_requests_started','provider_requests_started','ratings_modified','contacts_modified','handoffs_modified','auto_retry'];
const integer=value=>Number.isSafeInteger(value)&&value>=0;
const safe=value=>typeof value==='string'&&value.length>0&&value.length<=160&&!/[\p{Cc}\p{Cf}\p{Cs}]/u.test(value);
const leadReference=value=>typeof value==='string'&&/^[A-Za-z0-9_-]{1,160}$/.test(value);
const hex=(value,length)=>typeof value==='string'&&new RegExp(`^[a-f0-9]{${length}}$`).test(value);
const exact=(value,fields)=>value&&typeof value==='object'&&!Array.isArray(value)&&Object.keys(value).length===fields.length&&fields.every(field=>Object.hasOwn(value,field));
const node=(tag,text='',className='')=>{const element=document.createElement(tag);element.textContent=String(text);if(className)element.className=className;return element;};

export function checkedSelfWorklist(value,request){
  const invalid=()=>{throw Error('本人处理清单的范围或记录状态尚未通过核对，请重新读取。');};
  if(!exact(value,[...falseFlags,'contract','read_only','local_only','storage_scope','lane','offset','limit','total','counts','items'])||value.contract!=='self_worklist_v1'||value.read_only!==true||value.local_only!==true||value.storage_scope!=='this_device'||falseFlags.some(field=>value[field]!==false)||value.lane!==request.lane||value.offset!==request.offset||value.limit!==request.limit||!['all',...lanes].includes(value.lane)||!integer(value.offset)||!integer(value.limit)||value.limit<1||value.limit>20||!integer(value.total)||!exact(value.counts,['all',...lanes])||['all',...lanes].some(lane=>!integer(value.counts[lane]))||value.counts.all!==lanes.reduce((sum,lane)=>sum+value.counts[lane],0)||value.total!==value.counts[value.lane]||!Array.isArray(value.items)||value.items.length!==Math.max(0,Math.min(value.limit,value.total-value.offset)))invalid();
  const seen=new Set();
  for(const item of value.items){
    if(!exact(item,['author_key','lead_id','display_name','lane','reason_code','detail_view','handoff_id'])||!hex(item.author_key,64)||seen.has(item.author_key)||!leadReference(item.lead_id)||!safe(item.display_name)||!lanes.includes(item.lane)||value.lane!=='all'&&item.lane!==value.lane||!Object.hasOwn(reasons,item.reason_code)||!['contact','handoff'].includes(item.detail_view)||(item.detail_view==='handoff')!==(item.handoff_id!==null)||item.handoff_id!==null&&!hex(item.handoff_id,32)||item.lane==='handoff'&&item.detail_view!=='handoff'||['response','draft','contact'].includes(item.lane)&&item.detail_view!=='contact')invalid();
    seen.add(item.author_key);
  }
  return value;
}

export function createSelfWorklistUI({createDialog,read,scope,openItem,onError=()=>{}}){
  let generation=0,active=null,disposed=false;
  function clear(){generation++;if(active){active.root.replaceChildren();active.root.close?.();active.root.remove();active=null;}}
  async function open(){
    if(disposed)return;clear();const own=++generation,principal=scope(),view=createDialog('本人继续处理');active=view;let epoch=0,lane='all',offset=0;
    const current=()=>!disposed&&generation===own&&scope()===principal&&active===view&&view.current();
    const report=(text,error=false)=>{if(current()){view.status.textContent=text;view.status.dataset.state=error?'error':'ready';}};
    view.root.append(node('p','按客户去重，先核对未知或变化记录。清单只建议人工下一步，不会自动联系、生成新草稿或标记处理完成。','upgrade-muted'));
    const form=node('form','','upgrade-operation-form'),label=node('label','处理范围'),choice=node('select'),refresh=node('button','重新读取','secondary');
    choice.setAttribute('aria-label','本人处理范围');for(const value of ['all',...lanes]){const option=node('option',laneLabels[value]);option.value=value;choice.append(option);}choice.value=lane;label.append(choice);refresh.type='submit';form.append(label,refresh);view.root.append(form);
    const summary=node('p','','upgrade-muted'),results=node('section');view.root.append(summary,results);
    choice.addEventListener('change',()=>{lane=choice.value;offset=0;void load();});form.addEventListener('submit',event=>{event.preventDefault();void load();});
    async function load(){
      if(!current())return;const ticket=++epoch,valid=()=>current()&&ticket===epoch,request={lane,offset,limit:10};results.replaceChildren();summary.textContent='';refresh.disabled=true;report('正在核对本人有权来源、原草稿和交接记录…');
      try{const value=await read('self_worklist_get',request);if(!valid())return;render(checkedSelfWorklist(value,request));report('已读取本人当前处理清单。人数按客户计算，未作为联系、成交或到账证明。');}
      catch(error){if(valid()){results.replaceChildren();summary.textContent='';report(error.message||'本人清单暂不可读，请重新核对。',true);}}
      finally{if(valid())refresh.disabled=false;}
    }
    function render(value){
      results.replaceChildren();summary.textContent=`本机有权待办 ${value.counts.all} 位客户 · ${laneLabels[value.lane]} ${value.total} 位；先筛选再分页，不按本页推算全量。`;
      for(const option of choice.children)option.textContent=`${laneLabels[option.value]} · ${value.counts[option.value]} 位`;
      if(!value.items.length)results.append(node('p',value.total?'当前页没有待办，请返回前页或重新读取。':'当前有权范围没有这类待办；不表示没有客户回应或业务机会。','upgrade-muted'));
      for(const item of value.items){
        const card=node('section','','upgrade-operation-form');card.append(node('h3',item.display_name),node('p',laneLabels[item.lane]),node('p',reasons[item.reason_code],'upgrade-muted'));
        const button=node('button',item.detail_view==='handoff'?'打开原交接核对':'打开这条原记录','secondary');button.type='button';button.onclick=()=>void select(item,button);card.append(button);results.append(card);
      }
      const paging=node('div','','upgrade-section-header');paging.append(node('p',`本页 ${value.items.length} 位 · 第 ${Math.floor(value.offset/value.limit)+1} 页`,'upgrade-muted'));
      for(const [title,next,enabled]of [['上一页',Math.max(0,value.offset-value.limit),value.offset>0],['下一页',value.offset+value.items.length,value.offset+value.items.length<value.total]]){const button=node('button',title,'secondary');button.type='button';button.disabled=!enabled;button.onclick=()=>{offset=next;void load();};paging.append(button);}results.append(paging);
    }
    async function select(item,button){
      if(!current()||button.disabled)return;const ticket=++epoch,valid=()=>current()&&ticket===epoch,request={lane,offset,limit:10};button.disabled=true;refresh.disabled=true;report('正在重新核对这位客户的当前来源…');
      try{
        const value=await read('self_worklist_get',request);if(!valid())return;const checked=checkedSelfWorklist(value,request),fresh=checked.items.find(row=>row.author_key===item.author_key&&row.lead_id===item.lead_id&&row.detail_view===item.detail_view&&row.handoff_id===item.handoff_id);
        if(!fresh)throw Error('这条建议的来源或状态已变化，请重新读取清单。');
        if(typeof openItem!=='function')throw Error('原记录入口暂未连接，请回到客户工作台核对。');
        const accepted=()=>!disposed&&generation===own&&scope()===principal&&ticket===epoch;
        view.root.replaceChildren();view.root.close?.();view.root.remove();active=null;
        const shown=await openItem({...fresh},{accept:accepted});if(accepted()&&shown===false)onError(Error('原记录未能打开，请重新读取本人处理清单。'));
      }catch(error){if(valid())report(error.message||'原记录尚未打开，请重新核对。',true);else if(!disposed&&generation===own&&scope()===principal&&ticket===epoch)onError(error);}
      finally{if(valid()){button.disabled=false;refresh.disabled=false;}}
    }
    await load();
  }
  return {open,reset:clear,dispose(){disposed=true;clear();}};
}
