from pathlib import Path
import shutil,json,hashlib
W=Path(__file__).resolve().parent;P=W.parents[1]
name='work/ui-native-r57/store_materials.py'
before=W/'before'/name;before.parent.mkdir(parents=True,exist_ok=True)
if not before.exists():
    original=P/'work/employee-simple-flow-20261018/candidate-v3/project'/name
    current=(P/name).read_text('utf-8')
    baseline=original.read_text('utf-8')
    assert current.replace("            'intentRule':deepcopy(self.package.get('intentRule',{})),\n",'')==baseline
    shutil.copy2(original,before)
name='work/ui-native-r57/rental_assessment.py';target=P/name;before=W/'before'/name
if not before.exists():shutil.copy2(target,before)
s=target.read_text('utf-8')
needle='ENTITY = "rental_assessments_v1"'
if 'def rule_overview()' not in s:
    s=s.replace(needle,'''def rule_overview():
    """Public explanation pinned to this evaluator version; no model prompt."""
    return {'engineVersion':RULE_VERSION,'source':'local_evidence_evaluator',
        'standards':[
            {'code':'R1','label':'非目标','description':'供应方、转出方、研究或非本人租住用途，不进入待回复客户。'},
            {'code':'R2','label':'已解决或已放弃','description':'需求已解决或明确否定，保留原记录，不作为普通低意向待联系。'},
            {'code':'R4','label':'高意向','description':'明确租住需求、具体条件，以及当前真实推进请求；提出约看不代表预约已确认。'},
            {'code':'R5','label':'中意向','description':'明确租住需求和具体条件，尚无当前真实推进动作。'},
            {'code':'R6','label':'低意向','description':'需求待条件触发，或明确远期了解。'},
            {'code':'R0/R3/R7/R_TIME','label':'待确认','description':'来源或原文不足、需求冲突、缺具体需求，或推进时间过期、无原始时间锚点。'}],
        'budget':'提取客户预算原文；未获得已核同口径门店报价时，价格适配待核。',
        'income':'只记录客户自报收入，不按职业、头像或租金推断收入和支付能力。'}


'''+needle)
    target.write_text(s,'utf-8')
backend=P/'work/ui-native-r57/workbench_backend.py';s=backend.read_text('utf-8')
needle="                # Use the existing public read: private criteria stay behind"
if "materials['localAssessmentOverview']" not in s:
    s=s.replace(needle,"                from rental_assessment import rule_overview\n                materials['localAssessmentOverview']=rule_overview()\n"+needle)
backend.write_text(s,'utf-8')
ui=P/'work/ui-approved-implementation/ui-preview/pages/management-rules.mjs';s=ui.read_text('utf-8')
s=s.replace("  // Public bootstrap exposes draft signals and price status, but no unified exclusion field.\n  // These overview controls disclose source state; they do not edit collection filters.\n",'')
s=s.replace('未提供统一排除项${icon',"${list(v.search?.excludeTerms).length?'已启用 '+list(v.search?.excludeTerms).length+' 个排除词':'当前服务器未配置排除词'}${icon")
s=s.replace('<h3>覆盖方向</h3>','<h3>实际搜索词</h3>')
s=s.replace("${u.phase==='saving'?'保存中…':'保存方案'}","${u.phase==='saving'?'保存中…':'保存本门店方案'}")
s=s.replace('<span class="mr-status"', '<small>保存搜索模式、意向偏好及本门店选词；开始获客会自动读取服务器最新有效词库。</small><span class="mr-status"')
s=s.replace("if(kind==='exclude')return {title:'排除内容',html:'<p>当前门店资料未提供统一排除项。</p><p>此页不会新增或修改采集过滤规则。</p>'};", "if(kind==='exclude')return {title:'当前排除词',html:`<p>随当前搜索方案传入采集过滤。</p><div class=\"mr-detail-words\">${list(v.search?.excludeTerms).map(word=>`<span>${escape(word)}</span>`).join('')||'服务器当前未配置排除词；仍按客户角色与意向结果筛选回复候选。'}</div>`};")
start=s.index("  if(kind==='words')return")
end=s.index("  if(kind==='budget')",start)
s=s[:start]+'''  if(kind==='words')return {title:'实际关键词与来源',html:`<p>当前：${escape(v.search?.name||'暂未选择')} · ${v.selected.length}个搜索词</p>${v.searches.map(search=>`<section><h3>${escape(search.name||search.id)}</h3><div class="mr-detail-words">${list(search.keywords).map(word=>`<span>${escape(word)}</span>`).join('')||'暂无有效关键词'}</div>${list(search.sourceBindings).map(binding=>`<p>${escape(binding.keyword||'')} · ${escape(list(binding.sourceRefs).join('、'))}</p>`).join('')}</section>`).join('')}<p>词库版本：${escape(state.materials?.central?.revision||state.materials?.version||'未提供')}；来源：${escape(v.search?.materialName||v.material?.name||'当前门店资料')}。</p>${v.automatic?'<p>完整词库按方案保留，每次任务最多100个词，其余词按原方案分批使用。</p>':''}`};
'''+s[end:]
start=s.index("  return {title:'判断依据'")
end=s.index('\n}',start)
s=s[:start]+'''  const overview=state.materials?.intentPolicyOverview||{},local=state.materials?.localAssessmentOverview||{},labels={super_high:'超高',high:'高',medium:'中',low:'低',very_low:'极低'};
  return {title:'意向标准与执行来源',html:`<p>每批保存后调用企业已配置AI进行结构化意向分析，再继续采集。AI使用服务器当前发布的规则与提示词；此接口未返回完整远端提示词，不把本地规则当作远端提示词。</p><h3>本地已保存的五级分级标准</h3>${overview.canManage&&overview.criteria?Object.entries(overview.criteria).map(([level,text])=>`<p><strong>${escape(labels[level]||level)}：</strong>${escape(text)}</p>`).join(''):'<p>详细企业分级标准仅策略管理员可见。</p>'}<p>本地规则版本：${escape(overview.revision??'未提供')}；摘要：${escape(overview.digest||'未提供')}。</p><h3>本机客户证据筛选</h3>${list(local.standards).map(row=>`<p><strong>${escape(row.label)}（${escape(row.code)}）：</strong>${escape(row.description)}</p>`).join('')}<p>引擎：${escape(local.engineVersion||status.policy.engineVersion||'未提供')}。${escape(local.budget||'')}${escape(local.income||'')}</p><p>原始资料版本：${escape(rule.version||'未提供')}；信号：${escape(list(rule.signals).join('；'))}。</p>`};'''+s[end:]
s=s.replace("u.phase==='saved'?'方案已保存'", "u.phase==='saved'?'本门店方案已保存'")
ui.write_text(s,'utf-8')
print('Updated rule explanations and existing permission-bound policy projection.')
