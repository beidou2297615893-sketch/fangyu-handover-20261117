'use strict';

const {COMPANY,SCHEMA,hash,manifestId,versionId,sourceId}=require('./store_config.cjs');
const EVALUATOR='2026-10-16-intent-budget-income-draft-v2';
const PROJECTION='source-group-v3-private-judgement-text';
function build(bytes,bundleDigest){
 const source=JSON.parse(bytes.toString('utf8')),body={...source};delete body.digest;
 if(source.schema_version!=='fangyu-store-materials-catalog/1'||source.digest!==hash(body))throw Error('source_catalog_invalid');
 const sourceHash=hash(bytes),revision='r_'+hash([source.digest,sourceHash,EVALUATOR,PROJECTION,bundleDigest]).slice(0,32);
 const source_versions={version:source.version,materialsVersion:source.materialsVersion,ruleVersion:source.ruleVersion,
  source_catalog_digest:source.digest,source_raw_sha256:sourceHash,evaluator_version:EVALUATOR,projection_version:PROJECTION};
 const documents=[],stores=[];
 for(const material of source.materials){
  const storeId='fy_s_'+hash(COMPANY+'\nsource-group-v1\n'+material.key).slice(0,24);
  const ids=new Set([...material.keywordIds,...material.heldKeywordIds]);
  const references=new Set(material.sourceRefs),notes=new Set(material.noteIds),facts=new Set(material.factRefs);
  const keywords=source.keywords.filter(row=>ids.has(row.id)).map(row=>{
   const item=structuredClone(row);
   item.bindings=item.bindings.filter(binding=>binding.materialKey===material.key).map(binding=>({...binding,
    sourceRefs:binding.sourceRefs.filter(ref=>references.has(ref)),noteIds:binding.noteIds.filter(id=>notes.has(id)),
    factRefs:binding.factRefs.filter(ref=>facts.has(ref))}));
   item.clusters=[...new Set(item.bindings.map(binding=>binding.cluster).filter(Boolean))];
   item.group=material.key+'/'+(item.clusters.join('/')||'current-store');
   return item;
  });
  const pack={schema_version:source.schema_version,version:source.version,materialsVersion:source.materialsVersion,ruleVersion:source.ruleVersion,
   materials:[structuredClone(material)],keywords,
   intentRule:{version:source.intentRule.version,enabled:source.intentRule.enabled===true,status:source.intentRule.status,
    currentPricesVerified:source.intentRule.currentPricesVerified===true,changesIntentPolicy:false,
    description:'判断方案由管理员维护；完整规则文本仅管理员可见'},rulesSummary:structuredClone(source.rulesSummary),
   sourceArtifacts:structuredClone(source.sourceArtifacts),sourceNotes:source.sourceNotes.filter(row=>row.sourceRefs.some(ref=>references.has(ref)))
    .map(row=>({...structuredClone(row),sourceRefs:row.sourceRefs.filter(ref=>references.has(ref))})),
   sources:source.sources.filter(row=>material.sourceRefs.includes(row.sourceRef)),boundaries:structuredClone(source.boundaries),
   source_catalog_digest:source.digest};
  pack.counts={materials:1,keywords:pack.keywords.length,eligible:pack.keywords.filter(row=>row.csvCandidateEligible).length,held:pack.keywords.filter(row=>!row.csvCandidateEligible).length};
  pack.digest=hash(pack);
  const config={schema:SCHEMA,store_id:storeId,material_key:material.key,evaluator_version:EVALUATOR,
   mapping_basis:'company_and_source_group_hash',source_versions,package:pack,
   local_selection_only:true,priceVerified:material.priceVerified===true,verifiedMonthlyPrice:material.verifiedMonthlyPrice,
   ruleEnabled:source.intentRule.enabled===true,ruleStatus:source.intentRule.status};
  const configDigest=hash(config);
  documents.push({_id:versionId(COMPANY,revision,storeId),companyId:COMPANY,doc_type:'store_config_version',revision,store_id:storeId,config});
  stores.push({id:storeId,name:material.name,materialKey:material.key,city:material.city,district:material.district,
   status:material.status,captureStatus:material.captureStatus,missingOriginalMediaCount:material.missingOriginalMediaCount,
   priceVerified:config.priceVerified,verifiedMonthlyPrice:config.verifiedMonthlyPrice,ruleEnabled:config.ruleEnabled,config_digest:configDigest});
 }
 const counts={stores:stores.length,keywords:source.keywords.length,eligible:source.keywords.filter(row=>row.csvCandidateEligible).length,
  held:source.keywords.filter(row=>!row.csvCandidateEligible).length};
 const manifest={_id:manifestId(COMPANY),companyId:COMPANY,doc_type:'store_config_manifest',schema:SCHEMA,
  active_revision:revision,catalog_digest:hash({revision,stores}),source_versions,counts,stores};
 documents.push({_id:sourceId(COMPANY,revision),companyId:COMPANY,doc_type:'store_config_source',revision,source_versions,catalog:source});
 return {manifest,documents,source,sourceHash};
}
module.exports={build,EVALUATOR};
