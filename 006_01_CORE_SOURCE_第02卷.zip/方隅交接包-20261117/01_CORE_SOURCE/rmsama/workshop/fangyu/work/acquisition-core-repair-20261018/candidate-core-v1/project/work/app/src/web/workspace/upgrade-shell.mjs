const {upgradePages,upgradeNavigation,overviewMetrics,inventoryMetrics,safetyPresentation,handoffPresentation,replyTones,replyTemplate,actualRoleLabel,capabilityItems,traceUpgradeRoute}=await import(new URL('?asset=upgrade-model.mjs',import.meta.url));

const textNode=(tag,text='',className='')=>{const node=document.createElement(tag);node.textContent=String(text);if(className)node.className=className;return node;};
const readable=value=>typeof value==='string'||typeof value==='number'?String(value):'';
const time=value=>{if(!value)return '时间未提供';const date=new Date(typeof value==='number'?value*1000:value);return Number.isNaN(date.getTime())?'时间待核对':date.toLocaleString('zh-CN',{month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hour12:false});};

export function cloudUsageRows(usage){
  const known=value=>Number.isSafeInteger(value)&&value>=0?String(value):'待核对';
  const messages={verified:'已读取云端分析槽位账本。',not_configured:'云端尚未配置套餐额度。',not_tracked:'尚未追踪分析槽总量，剩余额度未知。',period_required:'服务周期待配置，当前可用额度未知。',period_inactive:'当前不在服务周期内；历史用量不代表当前余额。',expired:'服务权益已到期；历史用量仍可核对。',identity_changed:'账号或电脑已变化，请重新读取。',invalid_receipt:'云端回执需核对，额度保持未知。',unavailable:'云端套餐用量暂不可读。'};
  if(!usage||typeof usage!=='object')return [['云端分析用量','暂不可读；未推算为无限或零。']];
  const rows=[['云端本周期分析用量',messages[usage.state]||messages.unavailable]];
  if(usage.cloud_receipt_verified===true&&usage.analysis?.tracked===true){const source=usage.analysis;for(const [label,key]of [['本周期分析槽位总量','total'],['已确认分析槽位','confirmed'],['已预留分析槽位','reserved'],['其中结果未确认','unknown'],['当前剩余分析槽位','remaining']])rows.push([label,known(source[key])]);const percent=source.usage_percent;rows.push(['分析槽位使用比例',typeof percent==='number'&&Number.isFinite(percent)&&percent>=0?`${percent}%`:'待核对']);}
  if(usage.cloud_receipt_verified===true){rows.push(['已启用账号席位',`${known(usage.seats?.enabled)} / ${known(usage.seats?.total)}`],['已绑定门店组',`${known(usage.stores?.enabled)} / ${known(usage.stores?.total)}`]);}
  return rows;
}

export function createUpgradeShell({execute,getContext,navigate,onError=()=>{}}){
  const $=id=>document.getElementById(id),listeners=[],generations=new Map(),actions=new Map();
  let disposed=false,currentPage='customers',overview=null,handoffs=null,management=null,customerSummary=null,preview='',previewOwner='',loadRevision=0;
  const context=()=>getContext()||{},owner=()=>JSON.stringify([context().user?.id,context().user?.username,context().user?.tenant_id,context().user?.role,context().deviceId,context().deviceGeneration]);
  const readOwner=()=>JSON.stringify([owner(),context().user?.company_id,context().cloudEpoch,context().companyId,context().environmentId,context().cloudCompanyId,context().cloudEnvironmentId,context().endpoint]);
  let handoffOffset=0,handoffTotal=null,handoffFilter='all',handoffLoading=false,handoffReadOwner='';
  const on=(element,event,handler)=>{if(!element)return;element.addEventListener(event,handler);listeners.push(()=>element.removeEventListener(event,handler));};
  const run=async(button,fn)=>{if(button?.disabled)return;if(button){button.disabled=true;button.setAttribute('aria-busy','true');}try{await fn();}catch(error){onError(error);}finally{if(button){button.disabled=false;button.removeAttribute('aria-busy');}}};
  const read=async(action,data={})=>{const result=await execute(action,data);if(result?.status!=='succeeded'||!result.result||typeof result.result!=='object')throw Error(result?.error||'读取结果尚未确认，请重试。');return result.result;};
  document.body.dataset.upgradeUi='true';

  function renderSafety(){
    const safety=safetyPresentation(context()),host=$('upgrade-safety');if(!host)return;
    host.dataset.state=safety.state;host.dataset.tone=safety.tone;
    $('upgrade-safety-title').textContent=safety.title;$('upgrade-safety-copy').textContent=safety.detail;
    const accountState=$('upgrade-account-state');if(accountState){accountState.textContent=({review:'账号待核实',blocked:'采集已暂停',held:'许可待核实',unconfirmed:'状态待核对',login:'需要登录',running:'任务运行中',idle:'账号已连接'})[safety.state]||'状态待核对';accountState.dataset.tone=safety.tone;}
    const who=$('upgrade-role');if(who)who.textContent=actualRoleLabel(context().user);
  }
  function renderMetrics(){
    for(const host of document.querySelectorAll('[data-upgrade-metrics]')){
      const counts={...overview?.counts};
      host.replaceChildren();for(const item of (host.dataset.upgradeMetrics==='inventory'?inventoryMetrics:overviewMetrics)({...overview,counts})){
        const card=textNode('div','','upgrade-metric');card.dataset.metric=item.key;
        const icon=textNode('span','','upgrade-metric-icon');icon.setAttribute('aria-hidden','true');const image=document.createElement('img');image.alt='';image.src='?asset='+({comments:'tabler-message.svg',customers:'tabler-user-scan.svg',high_intent_customers:'tabler-user-scan.svg',pending_contact:'tabler-upgrade-phone.svg',awaiting_response:'tabler-upgrade-message.svg',responded:'tabler-upgrade-check.svg',pending_handoff:'tabler-upgrade-users.svg',accepted:'tabler-upgrade-file.svg'})[item.key];icon.append(image);
        const copy=textNode('div');copy.append(textNode('span',item.label),textNode('strong',item.value===null?'—':item.value));card.append(icon,copy);host.append(card);
      }
    }
  }
  function showError(host,error){host.textContent=error.message||'记录暂未读取，请重试。';host.dataset.state='error';}
  function renderOverview(result){
    overview=result;renderMetrics();document.dispatchEvent(new CustomEvent('upgrade:permissions'));$('upgrade-summary-note').textContent=result.local_only===true?'待交接含未送达草稿；接收仅为本机授权记录，跨电脑资源部回执尚未核验。':'人数按客户身份统计，评论与人数分别计算。';const host=$('upgrade-overview-recent'),status=$('upgrade-overview-status');if(!host)return;
    host.replaceChildren();status.textContent='已读取本机工作记录；统计以记录范围为准。';status.dataset.state='ready';
    const recent=Array.isArray(result.recent)?result.recent:[];
    if(!recent.length)host.append(empty('暂无最近工作记录','开始处理已有客户，或查看采集任务。'));
    else for(const item of recent.slice(0,12)){const row=textNode('div','','upgrade-activity');row.append(textNode('span','','upgrade-activity-dot'),textNode('div',readable(item.label||item.title||item.action)||'工作记录'),textNode('time',time(item.at||item.created_at)));host.append(row);}
    const evidence=$('upgrade-overview-evidence');evidence.replaceChildren();
    const limitations=Array.isArray(result.limitations)?result.limitations:[];
    for(const item of limitations)evidence.append(textNode('p',typeof item==='string'?item:readable(item.message||item.label)));
    if(!limitations.length)evidence.append(textNode('p','意向、联系、回应和交接分别记录；未取得成交回执时不展示营收。'));
  }
  function empty(title,copy){const box=textNode('div','','upgrade-empty');box.append(textNode('strong',title),textNode('p',copy));return box;}
  function checkedHandoffPage(result,offset,limit){
    if(!Number.isSafeInteger(result.total)||result.total<0||!Array.isArray(result.items)||result.items.length>limit||(result.items.length&&offset+result.items.length>result.total))throw Error('交接记录范围尚未确认，请重新读取。');
    return result.items;
  }
  function syncHandoffPaging(){
    const previous=$('upgrade-handoff-prev'),next=$('upgrade-handoff-next'),filter=$('upgrade-handoff-filter'),page=$('upgrade-handoff-page');
    if(previous)previous.disabled=handoffLoading||handoffTotal===null||handoffOffset===0;
    if(next)next.disabled=handoffLoading||handoffTotal===null||handoffOffset+50>=handoffTotal;
    if(filter){filter.disabled=handoffLoading;filter.value=handoffFilter;}
    if(page)page.textContent=handoffTotal===null?'页数待核对':`第 ${Math.floor(handoffOffset/50)+1} 页 · 共 ${Math.max(1,Math.ceil(handoffTotal/50))} 页`;
  }
  function renderHandoffs(result,query={offset:0,status:'all'}){
    const items=checkedHandoffPage(result,query.offset,50);
    handoffOffset=query.offset;handoffFilter=query.status;handoffTotal=result.total;handoffReadOwner=readOwner();
    handoffs=result;const host=$('upgrade-handoff-list'),status=$('upgrade-handoff-status');if(!host)return;host.replaceChildren();sync();
    status.textContent=`当前范围共 ${result.total} 条 · 本页 ${items.length} 条${items.length?`（第 ${query.offset+1}–${query.offset+items.length} 条）`:''}${result.local_only===true?' · 本机记录，跨电脑送达与接收尚未核验':''}`;status.dataset.state='ready';syncHandoffPaging();
    if(!items.length){host.append(empty(result.total===0?'当前范围暂无可见交接记录':'当前页暂无可见记录',result.total===0?'取得客户同意并核对联系方式后，再整理资源部交接。':'记录范围已变化，请返回上一页核对。'));return;}
    const table=textNode('table','','upgrade-table'),head=textNode('thead'),hr=textNode('tr');for(const label of ['客户 / 渠道','接收部门','交接状态','更新时间','记录'])hr.append(textNode('th',label));head.append(hr);table.append(head);const body=textNode('tbody');
    for(const item of items){const row=textNode('tr'),identity=textNode('td'),state=handoffPresentation({...item,local_only:result.local_only===true});identity.append(textNode('strong',readable(item.customer_display_name)||(item.source?.author_id?'已保存客户':'客户身份待核对')),textNode('small',({xiaohongshu:'小红书',douyin:'抖音',zhihu:'知乎',wechat_channels:'视频号'})[item.source?.platform]||'平台待核对'));identity.title=`来源身份：${readable(item.source?.author_id)||'未提供'}；交接编号：${readable(item.id)||'未提供'}`;row.append(identity,textNode('td',readable(item.recipient_name)||'尚未指定'));
      const cell=textNode('td'),badge=textNode('span',state.label,'upgrade-chip');badge.dataset.tone=state.tone;cell.append(badge);row.append(cell,textNode('td',time(item.updated_at||item.created_at)));
      const last=textNode('td'),button=textNode('button','查看记录','secondary');button.type='button';button.onclick=()=>openHandoff(item);last.append(button);row.append(last);body.append(row);
    }table.append(body);host.append(table);
  }
  function openHandoff(item){
    if(actions.has('handoff-open')){void Promise.resolve(actions.get('handoff-open')(item)).catch(onError);return;}
    const detail=$('upgrade-handoff-detail'),body=$('upgrade-handoff-detail-body');body.replaceChildren();
    const lines=[['渠道编号',item.id],['来源平台',item.source?.platform],['交接状态',handoffPresentation({...item,local_only:handoffs?.local_only===true}).label],['客户来源身份',item.source?.author_id],['接收方',item.recipient_name],['联系信息引用',item.contact_reference],['提交时间',time(item.submitted_at)],['接收记录时间',item.receipt?.recorded_at?time(item.receipt.recorded_at):'尚未取得接收回执']];
    for(const [label,value] of lines){const row=textNode('div','','upgrade-record-line');row.append(textNode('span',label),textNode('strong',readable(value)||'未提供'));body.append(row);}detail.showModal();
    document.dispatchEvent(new CustomEvent('upgrade:handoff-open',{detail:{id:item.id||'',record:item}}));
    actions.get('handoff-open')?.(item);
  }
  function renderManagement(result){
    management=result;const strategy=$('upgrade-strategy-summary'),catalog=$('upgrade-capability-list');strategy.replaceChildren();catalog.replaceChildren();
    if(result.strategyError)strategy.append(empty('策略记录未读取',result.strategyError));
    else if(result.strategy){const source=result.strategy;for(const [label,value] of [['策略名称',source.name||source.title],['版本',source.revision??source.version],['适用区域',[source.city,source.area].filter(Boolean).join(' · ')||source.region],['关键词总量',source.keyword_count],['已启用关键词',source.enabled_keyword_count],['活跃批次规模',source.active_batch_size],['查询额度',source.total_query_quota]]){const row=textNode('div','','upgrade-record-line');row.append(textNode('span',label),textNode('strong',readable(value)||'未提供'));strategy.append(row);}strategy.append(textNode('p','策略、词库和模型配置由获授权账号管理；员工权限以后台配置为准。','upgrade-muted'));}
    else strategy.append(empty('策略尚未配置','提供公寓资料后，可依据区域、预算与入住时间建立采集策略。'));
    if(result.capabilityError)catalog.append(empty('授权功能未读取',result.capabilityError));
    else {const items=capabilityItems(result.capabilities);if(!items.length)catalog.append(empty('暂无已公布的功能目录','不显示模拟售价、充值成功或未授权能力。'));for(const item of items){const card=textNode('div','','upgrade-capability');card.append(textNode('strong',readable(item.name||item.label||item.key)||'功能项'),textNode('p',readable(item.description)||'详情以后台授权记录为准'));const status=textNode('span',item.enabled===true||item.allowed===true?'配置已授权':item.enabled===false||item.allowed===false?'配置未授权':'授权状态待核对','upgrade-chip');status.dataset.tone=item.enabled===true||item.allowed===true?'positive':'neutral';card.append(status);const conditions=[item.installed===false?'未安装':'',item.operational===false?'当前不能运营':'',item.real_verified===false?'真实账号未验证':'',item.license_reviewed===false?'许可待审':'',({paused:'受控暂停',controlled_pause:'受控暂停',contract_only:'仅合约校验',pending_verification:'待验证'})[item.status]||''].filter(Boolean);if(conditions.length)card.append(textNode('p',conditions.join(' · '),'upgrade-muted'));catalog.append(card);}}
    const entitlements=$('upgrade-entitlement-list');entitlements.replaceChildren();
    if(result.entitlementError)entitlements.append(empty('服务权益未读取',result.entitlementError));
    else if(result.entitlements){const current=result.entitlements.current||{};const state=current.configured===true?(current.expired?'已到期':'已配置'):'尚未配置';entitlements.append(textNode('strong',readable(current.name)||'当前服务权益'),textNode('p',`${state} · 支付未开放`,'upgrade-muted'));for(const item of Array.isArray(result.entitlements.candidates)?result.entitlements.candidates:[]){const row=textNode('div','','upgrade-record-line');row.append(textNode('span',readable(item.name)||'候选服务'),textNode('strong',item.price==null?'价格未发布':'价格以正式发布为准'));entitlements.append(row);}entitlements.append(textNode('p','候选版本用于规划；不会发起充值或付款。','upgrade-muted'));for(const [label,value]of cloudUsageRows(result.entitlements.cloud_usage)){const row=textNode('div','','upgrade-record-line');row.append(textNode('span',label),textNode('strong',value));entitlements.append(row);}entitlements.append(textNode('p','未知结果包含在已预留槽位内；云端槽位不等于平台效果、客户成交或付款。未配置与不可读不推算为无限。','upgrade-muted'));}
    sync();
  }
  async function refresh(page=currentPage,requested={}){
    if(disposed||!context().user)return;const type=['leads','customers','overview'].includes(page)?'overview':page;if(!['overview','handoff','management'].includes(type))return;
    const generation=++loadRevision;generations.set(type,generation);const principal=readOwner(),valid=()=>!disposed&&principal===readOwner()&&generations.get(type)===generation;
    const query={offset:requested.offset??handoffOffset,status:requested.status??handoffFilter};
    if(type==='handoff'){
      if(handoffReadOwner&&handoffReadOwner!==principal){handoffs=null;handoffOffset=0;handoffTotal=null;handoffFilter='all';query.offset=0;query.status='all';$('upgrade-handoff-list').replaceChildren();}
      handoffLoading=true;syncHandoffPaging();
    }
    const status=$(type==='overview'?'upgrade-overview-status':type==='handoff'?'upgrade-handoff-status':'upgrade-management-status');if(status){status.textContent='正在读取工作记录…';status.dataset.state='loading';}
    try{
      if(type==='overview'){const result=await read('acquisition_overview');if(valid())renderOverview(result);}
      if(type==='handoff'){const result=await read('handoff_list',{offset:query.offset,limit:50,status:query.status});if(valid())renderHandoffs(result,query);}
      if(type==='management'){
        const values=await Promise.allSettled([read('strategy_get'),read('capability_catalog'),read('entitlement_summary')]);if(!valid())return;
        renderManagement({strategy:values[0].status==='fulfilled'?values[0].value:null,strategyError:values[0].status==='rejected'?values[0].reason.message:'',capabilities:values[1].status==='fulfilled'?values[1].value:null,capabilityError:values[1].status==='rejected'?values[1].reason.message:'',entitlements:values[2].status==='fulfilled'?values[2].value:null,entitlementError:values[2].status==='rejected'?values[2].reason.message:''});status.textContent=values.every(item=>item.status==='fulfilled')?'已读取当前账号可查看的管理记录。':'部分记录未读取；保留已读取内容。';status.dataset.state=values.every(item=>item.status==='fulfilled')?'ready':'partial';
      }
    }catch(error){if(valid()){if(status)showError(status,error);if(type==='overview'){$('upgrade-summary-note').textContent='工作统计尚未确认，当前客户资料仍可查看。';}else if(type==='handoff'){status.textContent='交接记录读取失败：'+status.textContent;if(handoffs)status.textContent+=' 当前保留上次已读取页，尚未更新。';else $('upgrade-handoff-list').replaceChildren(empty('交接记录未读取','检查当前账号权限与连接，然后重新读取。'));}}}
    finally{if(type==='handoff'&&valid()){handoffLoading=false;syncHandoffPaging();}}
  }
  function sync(page=currentPage){
    currentPage=page;renderSafety();const navPage=upgradeNavigation(page);
    for(const button of document.querySelectorAll('.nav-main button[data-page]')){const active=button.dataset.page===navPage;button.classList.toggle('active',active);if(active)button.setAttribute('aria-current','page');else button.removeAttribute('aria-current');}
    $('upgrade-breadcrumb').textContent=upgradePages[page]||'工作台';
    $('page-heading').textContent=upgradePages[page]||'工作台';$('upgrade-page-subtitle').textContent=({overview:'从来源、客户到交接，核对每一步进展。',tasks:'查看采集进度，先核实账号再开始。',handoff:'客户同意后整理资料，以真实接收记录核对交接。',devices:'核对每一个平台账号和当前操作身份。',management:'策略、词库与功能授权，按真实账号权限管理。'})[page]||'每条线索都有来源，每次交接都有回执。';
    const workbench=['leads','customers'].includes(page);$('upgrade-workbench-header').hidden=!workbench;
    for(const button of document.querySelectorAll('[data-upgrade-view]')){const selected=button.dataset.upgradeView===page;button.classList.toggle('active',selected);button.setAttribute('aria-selected',String(selected));}
    $('upgrade-summary').hidden=!workbench;renderMetrics();
    const canEdit=actions.has('strategy-edit')&&management?.strategy?.can_manage===true;$('upgrade-strategy-edit').hidden=!canEdit;$('upgrade-handoff-create').hidden=!(actions.has('handoff-create')&&handoffs?.permissions?.can_create===true);
    const ruleEditor=$('upgrade-intent-rule-edit');if(ruleEditor)ruleEditor.hidden=!(actions.has('intent-rule-edit')&&management);
    const aiReviewer=$('upgrade-ai-attempt-open');if(aiReviewer)aiReviewer.hidden=!actions.has('ai-attempt-open');
    const qualityReviewer=$('upgrade-intent-quality-open');if(qualityReviewer)qualityReviewer.hidden=!actions.has('intent-quality-open');
    const companyPublisher=$('upgrade-company-policy-open');if(companyPublisher)companyPublisher.hidden=!(actions.has('company-policy-open')&&management);
    const platformReader=$('upgrade-platform-read-open');if(platformReader)platformReader.hidden=!actions.has('platform-read-open');
    const exporter=$('upgrade-handoff-export');if(exporter)exporter.hidden=!(actions.has('handoff-export')&&handoffs);
  }
  for(const button of document.querySelectorAll('[data-upgrade-view]'))on(button,'click',()=>navigate(button.dataset.upgradeView));
  for(const button of document.querySelectorAll('[data-upgrade-go]'))on(button,'click',()=>navigate(button.dataset.upgradeGo));
  for(const button of document.querySelectorAll('[data-upgrade-refresh]'))on(button,'click',()=>run(button,()=>refresh(button.dataset.upgradeRefresh)));
  on($('upgrade-handoff-prev'),'click',()=>{if(handoffLoading||handoffTotal===null||!handoffOffset)return;void refresh('handoff',{offset:Math.min(Math.max(0,handoffOffset-50),Math.max(0,Math.ceil(handoffTotal/50)-1)*50)});});
  on($('upgrade-handoff-next'),'click',()=>{if(handoffLoading||handoffTotal===null||handoffOffset+50>=handoffTotal)return;void refresh('handoff',{offset:handoffOffset+50});});
  on($('upgrade-handoff-filter'),'change',()=>{if(handoffLoading)return;void refresh('handoff',{offset:0,status:$('upgrade-handoff-filter').value});});
  on($('upgrade-handoff-close'),'click',()=>$('upgrade-handoff-detail').close());
  on($('upgrade-self-worklist-open'),'click',()=>actions.get('self-worklist-open')?.());
  on($('upgrade-self-daily-evidence-open'),'click',()=>actions.get('self-daily-evidence-open')?.());
  on($('upgrade-handoff-create'),'click',()=>actions.get('handoff-create')?.());
  if($('upgrade-handoff-export'))on($('upgrade-handoff-export'),'click',()=>actions.get('handoff-export')?.());
  on($('upgrade-strategy-edit'),'click',()=>actions.get('strategy-edit')?.());
  on($('upgrade-intent-rule-edit'),'click',()=>actions.get('intent-rule-edit')?.());
  on($('upgrade-ai-attempt-open'),'click',()=>actions.get('ai-attempt-open')?.());
  on($('upgrade-intent-quality-open'),'click',()=>actions.get('intent-quality-open')?.());
  on($('upgrade-company-policy-open'),'click',()=>actions.get('company-policy-open')?.());
  on($('upgrade-platform-read-open'),'click',()=>actions.get('platform-read-open')?.());
  const detail=$('reply-detail');detail.removeAttribute('aria-selected');detail.classList.remove('active');let detailReadGeneration=0;
  async function refreshInlineHandoff(offset=0){
    if(detail.hidden||!detail.dataset.leadId)return;const generation=++detailReadGeneration,principal=owner(),leadId=detail.dataset.leadId,authorId=detail.dataset.authorId,platform=detail.dataset.platform,mode=detail.dataset.detailView;
    const readPrincipal=readOwner(),host=$('upgrade-inline-handoff'),step=detail.querySelector('[data-step="handoff"]');
    const current=()=>!disposed&&owner()===principal&&readOwner()===readPrincipal&&generation===detailReadGeneration&&detail.dataset.detailView===mode&&detail.dataset.leadId===leadId&&detail.dataset.authorId===authorId&&detail.dataset.platform===platform&&!detail.hidden;
    const setStep=(label,tone='neutral',title=label)=>{if(!step)return;step.dataset.tone=tone;step.title=title;if(step.lastChild?.nodeType===3)step.lastChild.textContent=label;else step.append(document.createTextNode(label));};
    try{
      const result=await read('handoff_list',{customer_lead_id:leadId,offset,limit:100});if(!current())return;
      if(result.customer_scope_lead_id!==leadId)throw Error('当前客户的交接范围尚未确认，请重新读取。');
      const items=checkedHandoffPage(result,offset,100);
      if(items.some(item=>item.lead_id!==leadId&&!(authorId&&item.source?.author_id===authorId&&item.source?.platform===platform)))throw Error('交接记录与当前客户不一致，请重新核对。');
      const latest=[...items].sort((a,b)=>(b.updated_at||0)-(a.updated_at||0))[0];
      // Older pages contain history, not a new current-status observation.
      if(offset===0){
        if(latest){const state=handoffPresentation(latest),label=latest.current_authorization?.state==='withdrawn'?'授权已撤回':latest.current_authorization?.state==='unavailable'?'授权待核对':latest.status==='draft'?'待整理交接':latest.status==='ready_to_deliver'?'待资源部送达':latest.status==='accepted'&&state.tone==='positive'?'本机已接收':state.label;setStep(label,state.tone,state.label);}
        else setStep(result.total===0?'本机未登记交接':'交接待核对');
      }
      if(mode!=='handoff')return;host.replaceChildren();
      host.append(textNode('p',`当前客户共 ${result.total} 条可见本机记录 · 本页 ${items.length} 条；跨电脑送达仍需独立回执。`,'upgrade-muted'));
      if(!items.length)host.append(empty(result.total===0?'当前客户暂无可见本机交接记录':'当前页暂无可见记录',result.total===0?'本机已登记记录已按当前客户核对；跨电脑记录仍待独立核验。':'记录范围已变化，请返回上一页核对。'));
      for(const item of items){const row=textNode('div','','upgrade-record-line'),state=handoffPresentation(item),view=textNode('button',state.label,'secondary');view.type='button';view.dataset.tone=state.tone;view.onclick=()=>{if(current())openHandoff(item);};row.append(textNode('span',readable(item.recipient_name)||'接收方待核对'),view);host.append(row);}
      const paging=textNode('div','','upgrade-pagination-controls'),previous=textNode('button','‹','secondary'),next=textNode('button','›','secondary'),page=textNode('span',`第 ${Math.floor(offset/100)+1} 页 · 共 ${Math.max(1,Math.ceil(result.total/100))} 页`);
      previous.id='upgrade-inline-handoff-prev';next.id='upgrade-inline-handoff-next';page.id='upgrade-inline-handoff-page';previous.type=next.type='button';previous.setAttribute('aria-label','当前客户交接记录上一页');next.setAttribute('aria-label','当前客户交接记录下一页');previous.disabled=offset===0;next.disabled=offset+100>=result.total;
      previous.onclick=()=>{if(current()&&!previous.disabled)void run(previous,()=>refreshInlineHandoff(Math.min(Math.max(0,offset-100),Math.max(0,Math.ceil(result.total/100)-1)*100)));};
      next.onclick=()=>{if(current()&&!next.disabled)void run(next,()=>refreshInlineHandoff(offset+100));};paging.append(previous,page,next);host.append(paging);
      if(result.permissions?.can_create===true){const create=textNode('button',result.total?'另建一份交接草稿':'整理这位客户的交接','secondary');create.type='button';create.onclick=()=>{if(current())document.dispatchEvent(new CustomEvent('upgrade:handoff-create',{detail:{leadId}}));};host.append(create);}
    }catch(error){if(current()){setStep('交接待核对');if(mode==='handoff')host.replaceChildren(empty('交接记录尚未确认',error.message||'请重新读取当前客户记录。'));}throw error;}
  }
  async function selectDetailView(mode){
    traceUpgradeRoute('shell.selectDetailView',mode,detailReadGeneration,true);
    detail.dataset.detailView=mode;const generation=++detailReadGeneration,principal=owner(),leadId=detail.dataset.leadId;
    for(const item of document.querySelectorAll('button[data-detail-view]')){const active=item.dataset.detailView===mode;item.classList.toggle('active',active);item.setAttribute('aria-selected',String(active));}
    $('upgrade-inline-handoff').hidden=mode!=='handoff';if(mode==='source')$('reply-review-details').open=true;
    if(mode==='handoff'){const host=$('upgrade-inline-handoff');host.replaceChildren(textNode('p','正在读取当前客户的交接记录…','upgrade-muted'));try{await refreshInlineHandoff();}catch(error){if(principal===owner()&&detail.dataset.leadId===leadId&&detail.dataset.detailView===mode&&detailReadGeneration===generation+1)host.replaceChildren(textNode('p','交接记录读取失败，请重新点击交接记录核对。','upgrade-muted'));throw error;}}
  }
  for(const button of document.querySelectorAll('button[data-detail-view]'))on(button,'click',()=>run(button,()=>selectDetailView(button.dataset.detailView)));
  on(document,'upgrade:handoff-records-changed',event=>{if(event.detail?.operationScope===owner())void refreshInlineHandoff().catch(onError);});
  on(document,'upgrade:lead-detail',event=>{if(event.detail?.leadId===detail.dataset.leadId){if(event.detail.context_changed!==false)$('upgrade-inline-handoff').replaceChildren();void refreshInlineHandoff().catch(onError);}});
  const more=document.createElement('details');more.className='upgrade-person-more';const summary=textNode('summary',''),dots=document.createElement('img');dots.src='?asset=tabler-upgrade-dots.svg';dots.alt='';summary.append(dots);summary.setAttribute('aria-label','更多客户操作');summary.title='更多客户操作';more.append(summary);const menu=textNode('div','','upgrade-person-more-menu');for(const [label,operation]of [['查看来源证据','source'],['人工核对意向','intent'],['核对本条意向规则','rules'],['整理这位客户交接','handoff']]){const button=textNode('button',label,'text-button');button.type='button';button.dataset.detailOperation=operation;on(button,'click',()=>{if(detail.hidden||!detail.dataset.leadId)return;more.open=false;if(operation==='rules'){actions.get('intent-rule-preview')?.(detail.dataset.leadId);return;}if(operation==='handoff'){if(!handoffs?.permissions?.can_create&&!overview?.permissions?.can_create)return;void selectDetailView('handoff').catch(onError);return;}const evidence=$('reply-review-details');evidence.open=true;if(operation==='intent'){const control=evidence.querySelector('.manual-correction');control.open=true;control.querySelector('select')?.focus();}else document.querySelector('button[data-detail-view="source"]')?.click();evidence.scrollIntoView?.({block:'nearest'});});menu.append(button);}more.append(menu);$('reply-intent')?.parentElement?.append(more);const updateMore=()=>{for(const button of menu.children)if(button.dataset.detailOperation==='handoff')button.hidden=!(handoffs?.permissions?.can_create===true||overview?.permissions?.can_create===true);};on(document,'upgrade:permissions',updateMore);updateMore();

  const toneHost=$('upgrade-tone-options');for(const [tone,label] of Object.entries(replyTones)){const button=textNode('button',label,'upgrade-tone-choice');button.type='button';button.dataset.tone=tone;if(tone==='official')button.title='仅指正式服务口吻，不代表平台或公寓官方授权；身份按真实填写内容说明。';button.setAttribute('aria-pressed',String(tone==='friendly'));on(button,'click',()=>{
    if(replyLocked())return;const target=$('reply-text'),feedback=$('upgrade-template-feedback');
    try{const next=replyTemplate({tone,identity:$('upgrade-real-identity').value});if(target.value.trim()&&target.value!==next&&!window.confirm('替换当前回复框内容？原内容尚未自动保存。'))return;for(const item of toneHost.children)item.setAttribute('aria-pressed',String(item===button));target.value=next;target.dispatchEvent(new Event('input',{bubbles:true}));preview='';$('upgrade-template-preview').hidden=true;$('upgrade-template-apply').disabled=true;feedback.textContent='模板已放入回复框，尚未保存、审核或发送。';}catch(error){feedback.textContent=error.message;}
  });toneHost.append(button);}
  on($('upgrade-template-preview-button'),'click',()=>{const feedback=$('upgrade-template-feedback');try{preview=replyTemplate({tone:toneHost.querySelector('[aria-pressed="true"]')?.dataset.tone,identity:$('upgrade-real-identity').value});previewOwner=owner();$('upgrade-template-text').value=preview;$('upgrade-template-preview').hidden=false;$('upgrade-template-apply').disabled=replyLocked();feedback.textContent='这是可审阅模板，应用后仍需核对并保存草稿。';}catch(error){preview='';$('upgrade-template-apply').disabled=true;feedback.textContent=error.message;}});
  on($('upgrade-real-identity'),'input',()=>{preview='';$('upgrade-template-apply').disabled=true;});
  const replyLocked=()=>$('reply-text')?.disabled||$('reply-text')?.readOnly||['sent','unknown','sending','copied'].includes($('reply-feedback')?.dataset.replyState);
  on($('upgrade-template-apply'),'click',()=>{const target=$('reply-text');if(!preview||previewOwner!==owner()||replyLocked())return;if(target.value.trim()&&target.value!==preview&&!window.confirm('替换当前回复框内容？原内容尚未自动保存。'))return;target.value=preview;target.dispatchEvent(new Event('input',{bubbles:true}));$('upgrade-template-feedback').textContent='已放入回复框，尚未保存、审核或发送。';target.focus();});
  const syncReplyControls=()=>{$('upgrade-template-apply').disabled=!preview||replyLocked();for(const button of toneHost.children)button.disabled=replyLocked();};const observer=new MutationObserver(syncReplyControls);observer.observe($('reply-text'),{attributes:true,attributeFilter:['disabled','readonly']});observer.observe($('reply-feedback'),{attributes:true,attributeFilter:['data-reply-state']});syncReplyControls();
  renderMetrics();renderSafety();
  return {
    sync,load:refresh,refresh,showHandoff(leadId){traceUpgradeRoute('shell.showHandoff','handoff',detailReadGeneration,!detail.hidden&&detail.dataset.leadId===leadId);if(detail.hidden||detail.dataset.leadId!==leadId)throw Error('当前客户已变化，请重新打开交接记录。');return selectDetailView('handoff');},canCreateHandoff:()=>handoffs?.permissions?.can_create===true||overview?.permissions?.can_create===true,
    hooks:{setOverview:renderOverview,setHandoffs:renderHandoffs,setManagement:renderManagement,setSafety:renderSafety,setCustomerSummary(result){customerSummary=result;renderMetrics();},
      setAction(name,callback){if(typeof callback==='function')actions.set(name,callback);else actions.delete(name);sync();}},
    reset(){generations.clear();detailReadGeneration++;handoffOffset=0;handoffTotal=null;handoffFilter='all';handoffLoading=false;handoffReadOwner='';overview=handoffs=management=customerSummary=null;preview='';previewOwner='';$('upgrade-real-identity').value='';$('upgrade-template-text').value='';$('upgrade-template-preview').hidden=true;$('upgrade-template-apply').disabled=true;$('upgrade-template-feedback').textContent='';$('upgrade-summary-note').textContent='人数按客户身份统计，评论与人数分别计算。';for(const id of ['upgrade-overview-recent','upgrade-overview-evidence','upgrade-handoff-list','upgrade-handoff-detail-body','upgrade-inline-handoff','upgrade-strategy-summary','upgrade-capability-list','upgrade-entitlement-list'])$(id).replaceChildren();$('upgrade-handoff-detail').close();more.open=false;for(const id of ['upgrade-overview-status','upgrade-handoff-status','upgrade-management-status']){const status=$(id);status.textContent='工作记录尚未读取。';delete status.dataset.state;}syncHandoffPaging();sync();updateMore();},
    dispose(){disposed=true;generations.clear();observer.disconnect();listeners.splice(0).forEach(fn=>fn());},
  };
}
