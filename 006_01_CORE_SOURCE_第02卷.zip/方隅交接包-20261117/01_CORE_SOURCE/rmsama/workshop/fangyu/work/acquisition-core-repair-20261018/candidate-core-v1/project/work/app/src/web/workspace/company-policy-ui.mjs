/* Explicit administrator publication; reads expose only version metadata. */
const fields=['contract','scope','policy_revision','policy_digest','effective_facts_digest','enabled','facts_as_of','facts_valid_until','usable_fact_count','incomplete_fact_count','expired_fact_count','future_fact_count','source','independently_verified','inventory_verified','publication_id','publication_key','source_local_revision','source_local_digest'];
const hash=value=>typeof value==='string'&&/^[a-f0-9]{64}$/.test(value);
const key=value=>typeof value==='string'&&/^[A-Za-z0-9_.:-]{8,128}$/.test(value);
const opaque=value=>typeof value==='string'&&/^[A-Za-z0-9_.:-]{1,128}$/.test(value);
const integer=value=>Number.isSafeInteger(value)&&value>=0;
const utc=value=>typeof value==='string'&&/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/.test(value)&&Number.isFinite(Date.parse(value));
const node=(tag,text='',className='')=>{const element=document.createElement(tag);element.textContent=String(text);if(className)element.className=className;return element;};
export function checkedCompanyPolicySummary(value){
  if(!value||Object.keys(value).length!==fields.length||fields.some(field=>!Object.hasOwn(value,field))||value.contract!=='company_intent_policy_v1'||value.scope!=='company'||!integer(value.policy_revision)||value.policy_revision<1||!hash(value.policy_digest)||!hash(value.effective_facts_digest)||typeof value.enabled!=='boolean'||value.source!=='operator_recorded'||value.independently_verified!==false||value.inventory_verified!==false||!utc(value.facts_as_of)||value.facts_valid_until!==null&&(!utc(value.facts_valid_until)||value.facts_valid_until<=value.facts_as_of)||value.publication_id!==null&&!opaque(value.publication_id)||value.publication_key!==null&&!key(value.publication_key)||value.source_local_revision!==null&&!integer(value.source_local_revision)||value.source_local_digest!==null&&!hash(value.source_local_digest))throw Error('公司规则摘要未通过核对。');
  const counts=['usable_fact_count','incomplete_fact_count','expired_fact_count','future_fact_count'];if(counts.some(field=>!integer(value[field])||value[field]>200)||counts.reduce((total,field)=>total+value[field],0)>200)throw Error('公司资料数量未通过核对。');return value;
}
export function checkedCompanyPolicyReceipt(value,original,{expected,readOnly=false}={}){
  if(!value||!key(original)||value.idempotency_key!==original||value.operation_action!=='intent_policy_publish'||typeof value.local_source_matches!=='boolean'||typeof value.current_cloud_verified!=='boolean'||value.requires_revalidation!==(!value.local_source_matches||!value.current_cloud_verified)||!['succeeded','unknown'].includes(value.cloud_current_state)||value.current_cloud_verified!==(value.cloud_current_state==='succeeded')||readOnly&&value.read_only!==true)throw Error('原公司规则发布回执未通过核对，继续保留原编号。');
  if(value.state==='unknown'){if(value.mutation_committed!==null||value.read_only!==true||value.current_cloud_verified!==false||value.requires_revalidation!==true)throw Error('公司规则未知状态证明无效。');return value;}
  if(value.state!=='succeeded'||value.mutation_committed!==true||!opaque(value.publication_id))throw Error('公司规则发布结果未确认。');const summary=checkedCompanyPolicySummary(value.summary);
  if(summary.publication_key!==original||summary.publication_id!==value.publication_id||summary.source_local_revision===null||summary.source_local_digest===null||expected&&(summary.source_local_revision!==expected.expected_local_revision||summary.source_local_digest!==expected.expected_local_digest||summary.policy_revision!==expected.expected_policy_revision+1))throw Error('公司规则发布未对应原本机来源或版本。');return value;
}

export function createCompanyPolicyUI({createDialog,read,write,scope,perform,pending,recover}){
  let generation=0,active=null,disposed=false;
  const clear=()=>{generation++;if(active){active.root.replaceChildren();active.root.close?.();active.root.remove();active=null;}};
  async function open(){
    if(disposed)return;clear();const own=++generation,principal=scope(),view=createDialog('公司意向规则发布');active=view;
    const current=()=>!disposed&&generation===own&&active===view&&view.current()&&scope()===principal;
    const report=(text,error=false)=>{if(current()){view.status.textContent=text;view.status.dataset.state=error?'error':'ready';}};
    const host=node('section'),recovery=node('section'),target='company-intent-policy';let source=null,published=null,canPublish=false,readGeneration=0;
    view.root.append(node('p','将已经保存的本机规则与公寓资料明确发布到当前公司。仅获云端授权的管理员可发布；不会调用模型、重算历史评级或修改套餐。','upgrade-muted'),host,recovery);
    const button=(parent,title,fn)=>{const control=node('button',title,'secondary');control.type='button';control.onclick=()=>void fn(control);parent.append(control);return control;};
    function render(){
      if(!current())return;host.replaceChildren(node('h3','当前来源与公司版本'));
      if(source)host.append(node('p',`本机已保存规则版本 ${source.revision} · ${source.can_manage?'可管理本机资料':'只读摘要'}`));
      if(published)host.append(node('p',`公司当前版本 ${published.policy_revision} · 有效期内资料 ${published.usable_fact_count} 份 · 待补 ${published.incomplete_fact_count} 份 · 过期 ${published.expired_fact_count} 份`),node('p',`来源本机版本 ${published.source_local_revision??'未记录'} · ${source&&source.revision===published.source_local_revision&&source.digest===published.source_local_digest?'与当前本机来源一致':'与当前本机来源需核对'}`,'upgrade-muted'));
      else host.append(node('p','尚未核对到已发布的公司版本。','upgrade-muted'));
      host.append(node('p','资料是操作人登记，未独立核验，也不是实时可出租库存。原发布回执能核对不表示仍为公司当前适用版本；分析时另核对当前版本和有效资料。','upgrade-muted'));
      const control=button(host,'发布已保存规则到公司',async control=>{if(!current()||!source||!canPublish)return;await perform(view,control,async()=>{const expected={expected_local_revision:source.revision,expected_local_digest:source.digest,expected_policy_revision:published?.policy_revision??0};const value=await write('intent_policy_publish',expected,target);if(!current())return;checkedCompanyPolicyReceipt(value,value.idempotency_key,{expected});const fresh=await load();if(current()&&fresh)report(value.local_source_matches?'原发布已确认，已重新读取公司当前版本；历史客户评级保留。':'原来源版本发布成功；本机来源已变化，请核对后决定下一次发布。');});if(current())renderRecovery();});
      control.disabled=!canPublish||!source||!!pending('intent_policy_publish',target);
      if(!canPublish)host.append(node('p','当前云端身份或服务权益未确认发布权限；可先管理本机资料并核对历史。','upgrade-muted'));
    }
    function renderRecovery(){
      if(!current())return;recovery.replaceChildren();const original=pending('intent_policy_publish',target);if(!original)return;
      recovery.append(node('p',`原发布结果待核对。编号：${original.idempotency_key}`,'upgrade-muted'));button(recovery,'只核对原发布编号',control=>perform(view,control,async()=>{const answer=await recover('intent_policy_publish',target);if(!current())return;const value=checkedCompanyPolicyReceipt(answer.result||answer,original.idempotency_key,{readOnly:true});if(value.state==='succeeded'&&value.current_cloud_verified){const fresh=await load();if(fresh)report('原发布收据已核对，已重新读取公司当前版本；未再次发布。');}else report(value.state==='succeeded'?'历史发布曾确认成功，当前原收据仍未恢复核验；保留原编号，暂勿再次发布。':'原发布是否成功仍未知；保留原编号，暂勿再次发布。',true);renderRecovery();render();}));
    }
    async function load(){const epoch=++readGeneration,fresh=()=>current()&&epoch===readGeneration;
      const local=await read('intent_rules_get',{});if(!fresh())return false;const summary=local.summary;if(!summary||!integer(summary.revision)||!hash(summary.digest)||typeof summary.can_manage!=='boolean')throw Error('本机规则来源版本无法核对。');source=summary;published=null;canPublish=false;render();
      try{const value=await read('intent_policy_read',{});if(!fresh())return false;if(typeof value.can_publish!=='boolean'||!Object.hasOwn(value,'summary'))throw Error('公司规则发布权限回执无效。');published=value.summary===null?null:checkedCompanyPolicySummary(value.summary);canPublish=value.can_publish&&source.can_manage;render();renderRecovery();report('已核对本机来源与云端当前摘要；不会自动发布或启动模型。');return true;}
      catch(error){if(fresh()){render();renderRecovery();report(error.message||'公司云连接尚未核对，发布保持暂停。',true);}return false;}
    }
    button(view.root,'重新读取当前版本',async control=>{control.disabled=true;try{await load();}catch(error){report(error.message,true);}finally{if(current())control.disabled=false;}});
    renderRecovery();try{await load();}catch(error){report(error.message,true);}
  }
  return {open,reset:clear,dispose(){disposed=true;clear();}};
}
