'use strict';
const {adminWorkbenchFor,sourceFields}=require('./admin_workbench_policy.cjs');
// A query of existing policy facts. No heartbeat, command claim or state repair.
const crypto=require('node:crypto');
const VALID_ID=/^[A-Za-z0-9_-]{16,80}$/;
const FAILURE={purpose:'device_permission_snapshot',schema:'device-permission-snapshot-v1',read_only:true,mutation_committed:false,command_claimed:false,auto_retry:false};
function devicePermissionSnapshot({state,payload,bearer,now,companyId,releaseApproved=false,releaseVersion='',pairingApproved=false,pairingVersion='',employeeReleaseEnabled=false,employeeReleaseVersion='',platformQaDeviceId='',qaContinuousUntil=0,continuousReadonlyDeviceId=''}){
 const fail=(status,code)=>({status,data:{...FAILURE,code}});
 if(!payload||Object.keys(payload).some(k=>!['environment_id','operation'].includes(k))||payload.operation!=='device_permission_snapshot')return fail(400,'DEVICE_SNAPSHOT_REQUEST_INVALID');
 if(!state||!Array.isArray(state.devices)||!Array.isArray(state.users))return fail(503,'DEVICE_SNAPSHOT_STORAGE_UNAVAILABLE');
 if(typeof bearer!=='string'||!/^[A-Za-z0-9_-]{40,100}$/.test(bearer))return fail(401,'DEVICE_SNAPSHOT_AUTH_REQUIRED');
 const digest=crypto.createHash('sha256').update(bearer).digest('hex');
 const matches=state.devices.filter(d=>d&&!d.revoked&&d.digest===digest);
 if(matches.length!==1)return fail(401,'DEVICE_SNAPSHOT_AUTH_REQUIRED');
 const d=matches[0],owners=state.users.filter(u=>u&&u.username===d.owner&&!u.disabled);
 if(owners.length!==1)return fail(401,'DEVICE_SNAPSHOT_AUTH_REQUIRED');
 const owner=owners[0];
 if(!VALID_ID.test(d.id)||typeof d.owner!=='string'||typeof d.name!=='string'||typeof d.version!=='string'||!Number.isSafeInteger(d.last_seen)||d.last_seen<0||!Number.isSafeInteger(now)||now<0)return fail(503,'DEVICE_SNAPSHOT_STATE_INVALID');
 const safetyHold=companyId==='fangyu-apartment-client'&&releaseApproved!==true;
 const qaPairing=safetyHold&&pairingApproved===true&&/^[0-9]+\.[0-9]+\.[0-9]+-qa\.[1-9][0-9]{0,5}$/.test(pairingVersion);
 const qaDeviceId=qaPairing&&pairingVersion==='1.1.7-qa.1'&&VALID_ID.test(platformQaDeviceId)?platformQaDeviceId:'';
 const qa=!!(qaDeviceId&&d.id===qaDeviceId&&d.version==='1.1.7-qa.1');
 const qaContinuous=qa&&Number.isSafeInteger(qaContinuousUntil)&&qaContinuousUntil>now&&qaContinuousUntil-now<=1800;
 const continuousReadonly=qa&&continuousReadonlyDeviceId===qaDeviceId;
 const continuous=continuousReadonly||qaContinuous;
 const base={allowed:false,device_id:d.id,version:employeeReleaseVersion||'',continuous_read:false,lease_seconds:0};
 const employeePolicy=safetyHold&&employeeReleaseEnabled===true&&employeeReleaseVersion==='1.1.8-pilot.1';
 const reason=!employeePolicy?'POLICY_DISABLED':owner.role!=='operator'&&!adminWorkbenchFor(companyId,d,owner)?'ROLE_INELIGIBLE':d.version!==employeeReleaseVersion?'VERSION_MISMATCH':!d.last_seen||now-d.last_seen>90?'DEVICE_OFFLINE':'ALLOWED';
 const employee=reason==='ALLOWED'?{...base,...(adminWorkbenchFor(companyId,d,owner)?sourceFields():{}),allowed:true,continuous_read:true,lease_seconds:45,reason}:{...base,reason};
 const device={id:d.id,name:d.name,owner:d.owner,version:d.version,last_seen:d.last_seen,revoked:false,platform_qa:qa,continuous_qa:continuous,employee_release:employee};
 return {status:200,data:{...FAILURE,snapshot_at:now,device,
  safety_hold:safetyHold&&!qa&&!employee.allowed,owner_permissions:{can_reply:owner.can_reply!==false},employee_release:employee,
  platform_qa_device_id:qa?qaDeviceId:'',platform_qa_version:qa?'1.1.7-qa.1':'',continuous_qa:continuous,
  continuous_qa_mode:continuousReadonly?'device_readonly':qaContinuous?'qa_trial':'',continuous_qa_max_batches:continuousReadonly?0:2,
  continuous_qa_until:!continuousReadonly&&qaContinuous?qaContinuousUntil:0,
  continuous_qa_remaining_seconds:continuousReadonly?45:qaContinuous?qaContinuousUntil-now:0,
  release_approved:releaseApproved===true,release_version:releaseVersion||''}};
}
module.exports={devicePermissionSnapshot};
