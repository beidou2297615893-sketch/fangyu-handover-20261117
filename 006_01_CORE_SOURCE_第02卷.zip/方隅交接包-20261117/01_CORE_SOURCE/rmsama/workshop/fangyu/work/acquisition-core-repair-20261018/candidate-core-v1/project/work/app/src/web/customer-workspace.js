/* Fangyu customer edition: task-oriented navigation and explicit connection states. */
(() => {
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  const labels = {
    tasks: ['开始获客', '设置关键词，找到租房需求', '01'],
    leads: ['客户清单', '看意向、评分与回复', '02'],
    accounts: ['平台连接', '扫码连接小红书等账号', '03'],
    team: ['团队成员', '管理同事账号与权限', '04'],
    settings: ['设置', '云端共享、AI 与企业资料', '05']
  };
  Object.entries(labels).forEach(([key, value]) => names[key] = value[0]);
  state.page = 'tasks';
  const originalRender = render, originalAction = action, originalTasks = pages.tasks;
  const originalLeads = pages.leads, originalSettings = pages.settings, originalLogin = login;
  let integrations = null, keywordRequest = 0;
  const safetyHold = () => state.company?.id === 'fangyu-apartment-client' && state.company?.runtime?.xiaohongshu_automation === 'hold';
  // Customer edition owns page transitions; keep existing drawer/help primitives.
  WorkbenchUI.afterRender = () => {};
  const section = (title, body, cls = '') => `<section class="panel ${cls}"><h2>${title}</h2>${body}</section>`;
  const safeMotion = (node, frames, options = {}) => {
    if (!node || reduced.matches || document.body.classList.contains('ui-refresh')) return;
    if (window.Motion?.animate) return Motion.animate(node, frames, {duration: .32, ease: [.16, 1, .3, 1], ...options});
  };
  function animatePage() {
    if (document.body.classList.contains('ui-refresh')) return;
    document.querySelectorAll('#page > .panel, #page > .workflow-strip, #page > .reference-layout, #page > .leads-layout, #page > .customer-grid').forEach((el, i) => {
      safeMotion(el, {opacity: [0, 1], y: [14, 0]}, {delay: Math.min(i, 4) * .045});
    });
    document.querySelectorAll('.platform-picker, #page tbody tr').forEach((el, i) => {
      if (i < 10) safeMotion(el, {opacity: [0, 1], y: [8, 0]}, {duration: .25, delay: .06 + i * .035});
    });
  }
  render = function () {
    labels.tasks[0] = safetyHold() ? '历史任务' : '开始获客';
    labels.tasks[1] = safetyHold() ? '查看已保存任务，不运行采集' : '设置关键词，找到租房需求';
    labels.accounts[0] = safetyHold() ? '账号状态' : '平台连接';
    labels.accounts[1] = safetyHold() ? '仅查看历史状态，暂不扫码' : '扫码连接小红书等账号';
    names.tasks = labels.tasks[0]; names.accounts = labels.accounts[0];
    const previous = document.querySelector('.nav .active')?.getBoundingClientRect();
    if (state.page === 'dashboard') state.page = 'tasks';
    originalRender();
    document.body.classList.add('customer-edition');
    const nav = document.querySelector('.nav');
    nav.innerHTML = `<div class="nav-group-label">获客工作区</div>${Object.entries(labels).map(([key, [title, description, num]], i) => `${i === 3 ? '<div class="nav-group-label secondary">管理与配置</div>' : ''}<button data-nav="${key}" class="${state.page === key ? 'active' : ''}" aria-current="${state.page === key ? 'page' : 'false'}">${icon(key === 'team' ? 'accounts' : key)}<span class="nav-copy"><strong>${title}</strong><small>${description}</small></span><span class="nav-index">${num}</span></button>`).join('')}`;
    document.querySelector('.brand small').textContent = '租赁获客 · 团队工作区';
    const cloudConnected = integrations?.cloud?.connected ?? state.user?.cloud_bound;
    document.querySelector('.workspace-status span').textContent = cloudConnected ? '已登录云端 · 清单手动同步' : '本机工作区 · 云端待连接';
    document.querySelector('.service-state').innerHTML = '<i class="local-dot"></i>' + (cloudConnected ? '云端账号已登录' : '本机数据已就绪');
    document.querySelector('.footer').innerHTML = safetyHold() ? '<span>方隅公寓 · 获客工作区</span><span>当前版本验收中 · 只处理历史线索</span>' : '<span>方隅公寓 · 获客工作区</span><span>连接平台 → 找到客户 → 查看意向与回复</span>';
    bind(); animatePage();
    const active = nav.querySelector('.active');
    if (active) {
      const marker = document.createElement('span'); marker.className = 'customer-nav-marker'; marker.setAttribute('aria-hidden', 'true'); active.prepend(marker);
      if (previous) safeMotion(marker, {y: [previous.top - active.getBoundingClientRect().top, 0]}, {duration: .32});
    }
  };
  pages.dashboard = () => pages.tasks();
  function workflow() {
    const ready = rows('accounts').some(a => a.status === 'ready');
    const total = counts().total;
    return `<div class="workflow-strip" aria-label="获客操作流程"><button data-action="goto-accounts" class="${ready ? 'complete' : 'current'}"><span class="step-orb">${ready ? '✓' : '1'}</span><span><strong>连接平台</strong><small>${ready ? '账号已就绪' : '用手机扫码，软件自动检查'}</small></span></button><i></i><button data-action="focus-search" class="${ready ? 'current' : ''}"><span class="step-orb">2</span><span><strong>找到客户</strong><small>填写地区与租房关键词</small></span></button><i></i><button data-action="goto-leads"><span class="step-orb">3</span><span><strong>处理客户清单</strong><small>${total ? `已有 ${total} 位客户，查看意向与回复` : '筛选高意向，逐条确认回复'}</small></span></button></div>`;
  }
  pages.tasks = function () {
    if (safetyHold()) {
      const tasks = rows('tasks');
      $('#page').innerHTML = heading('当前版本验收中，电脑端暂停小红书扫码、采集和公开发送。历史线索仍可查看、评分并准备内部草稿。', button('查看历史线索','goto-leads','','primary')) +
        section('已保存的任务', tasks.length ? `<div class="task-history">${tasks.map(t => `<div class="step"><div><strong>${esc((t.keywords||[]).join('、')||t.name||'未命名任务')}</strong><p class="muted">${esc(platformName(t.platform))} · 历史新增 ${Number(t.accumulated)||0} 条 · 当前版本不运行采集</p></div></div>`).join('')}</div>` : '<p class="muted">尚无历史任务。版本验收期间不能新建或启动采集。</p>');
      return;
    }
    originalTasks();
    document.querySelector('#page > .page-head p').textContent = '从租房相关内容的评论中，找到正在找房的人。';
    document.querySelector('.page-head').insertAdjacentHTML('afterend', workflow());
    const recent = rows('tasks').filter(t => t.last_batch && t.last_run).sort((a,b) => b.last_run.localeCompare(a.last_run)).slice(0,3);
    if (recent.length) {
      const reasons = {identity:'排除的作者或博主',intent:'不符合意向等级',excluded_word:'命中排除词',keyword:'未命中关键词',missing_metadata:'地区或时间缺失 / 无效',region:'地区不符合',date:'时间不符合'};
      const reports = recent.map(t => {
        const b=t.last_batch;
        return `<details class="collection-report"><summary>${esc((t.keywords||[]).join('、')||t.name)} · 最近一批新增 ${Number(b.imported)||0} 位</summary><p>${esc(b.completed_at||t.last_run)} · ${esc(platformName(t.platform))}</p><div class="collection-counts"><span>读取 <strong>${Number(b.read)||0}</strong></span><span>筛除 <strong>${Number(b.filtered)||0}</strong></span><span>重复 <strong>${Number(b.duplicates)||0}</strong></span><span>新增 <strong>${Number(b.imported)||0}</strong></span></div><ul>${Object.entries(b.filter_reasons||{}).map(([key,value])=>`<li>${esc(reasons[key]||key)}：${Number(value)||0} 条</li>`).join('')}</ul>${b.deferred?`<p>还有 ${Number(b.deferred)} 条因本次额度暂未入库，采集进度已保留。</p>`:''}<small>每条被筛除的数据只计入首个未通过条件；缺失信息不会被猜测。${!b.imported?' 可先检查筛选条件，不必反复点击开始。':''}</small></details>`;
      }).join('');
      document.querySelector('.reference-layout')?.insertAdjacentHTML('afterend',section('最近采集结果',reports,'collection-reports'));
    }
    const strip = document.querySelector('.reference-account-strip');
    if (strip) {
      const b = strip.querySelector('[data-action]');
      if (b) b.textContent = rows('accounts').length ? '切换 / 连接平台' : '第一步：扫码连接平台';
    }
    document.querySelector('.reference-editor h2').textContent = '你想找什么样的租客？';
    const preset = document.querySelector('#f-quick-preset'); if (preset) preset.value = 'apartment';
    const input = document.querySelector('#quick-keywords');
    if (input) {
      input.placeholder = '例如：杭州滨江租房、地铁一居室';
      input.closest('.reference-form-row').insertAdjacentHTML('afterend', `<div class="keyword-assistant"><div class="keyword-assistant-head"><div><strong>关键词助手</strong><small>先写一个需求，再选择适合的搜索词</small></div><button type="button" id="suggest-keywords">联想关键词</button></div><div id="keyword-suggestions" aria-live="polite"><span class="muted">可使用公寓词库；配置 AI API 后可切换为 AI 联想。</span></div></div>`);
      document.querySelector('#suggest-keywords').onclick = suggestKeywords;
    }
    const error = document.querySelector('#quick-error');
    if (error) error.insertAdjacentHTML('afterend', '<button type="button" class="text-button" data-action="goto-accounts">账号没有连上？去平台连接</button>');
    const actions = document.querySelector('.reference-form-actions');
    if (actions) document.querySelector('.keyword-assistant')?.before(actions);
  };
  async function suggestKeywords() {
    const input = document.querySelector('#quick-keywords'), target = document.querySelector('#keyword-suggestions');
    if (!input.value.trim()) { target.textContent = '先写一个需求，例如“杭州滨江租房”。'; input.focus(); return; }
    const request = ++keywordRequest, b = document.querySelector('#suggest-keywords');
    WorkbenchUI.busy(b, true); target.innerHTML = '<span class="ui-spinner">正在整理可用的搜索词…</span>';
    try {
      const r = await api('keyword_suggest', {seed: input.value.trim()});
      if (request !== keywordRequest || !target.isConnected) return;
      target.innerHTML = `<small class="suggest-source">${esc(r.source)} · 点击添加，可随时删除</small><div class="keyword-chips">${r.keywords.map(k => `<button type="button" aria-pressed="false" data-keyword="${esc(k)}">＋ ${esc(k)}</button>`).join('')}</div>`;
      target.querySelectorAll('[data-keyword]').forEach(chip => chip.onclick = () => {
        const words = new Set(input.value.split(/[,，\n]/).map(x => x.trim()).filter(Boolean));
        const selected = chip.getAttribute('aria-pressed') === 'true';
        selected ? words.delete(chip.dataset.keyword) : words.add(chip.dataset.keyword);
        input.value = [...words].join('，'); input.dispatchEvent(new Event('input'));
        chip.setAttribute('aria-pressed', String(!selected)); chip.textContent = (selected ? '＋ ' : '✓ ') + chip.dataset.keyword;
        safeMotion(chip, {scale: [.94, 1]}, {duration: .2});
      });
      safeMotion(target, {opacity: [0, 1], y: [6, 0]});
    } catch (e) { if (target.isConnected) target.innerHTML = `<p class="error" role="alert">${esc(e.message)}</p>`; }
    finally { WorkbenchUI.busy(b, false); }
  }
  pages.accounts = function () {
    if (safetyHold()) {
      const accounts = rows('accounts');
      $('#page').innerHTML = heading('这里仅显示电脑端已保存的账号记录。版本验收期间无需再次扫码，当前登录身份也未重新验证。') +
        section('历史账号记录', accounts.length ? accounts.map(a => `<div class="step"><div><strong>${esc(a.name||'未命名账号')}</strong><p class="muted">${esc(platformName(a.platform))} · ${a.status==='ready'?'上次验证通过，当前会话未核实':'当前会话未核实'}</p></div></div>`).join('') : '<p class="muted">没有已保存的平台账号。</p>');
      return;
    }
    const allowed = state.platforms.filter(p => ['xiaohongshu', 'douyin', 'kuaishou', 'weibo'].includes(p.id));
    $('#page').innerHTML = heading('这里连接的是社交平台账号；同事登录软件的账号在「团队成员」。') +
      section('选择平台，直接开始连接', `<p class="section-description">无需先建配置。点选平台 → 本人扫码 / 登录 → 自动检查连接。</p><div class="platform-pickers">${allowed.map(p => {
        const existing = rows('accounts').find(a => a.platform === p.id && a.status !== 'ready');
        const detail = p.id === 'xiaohongshu' ? '手机小红书扫码' : p.id === 'weibo' ? '手机微博扫码' : '打开独立窗口，由你登录';
        return `<button class="platform-picker" data-action="${existing ? 'account-setup' : 'add-platform-account'}" data-id="${esc(existing?.id || p.id)}">${platformLogo(p.id)}<strong>${esc(platformName(p.id))}</strong><small>${detail}</small><span>${existing ? '继续连接' : '连接账号'} <b>→</b></span></button>`;
      }).join('')}</div>`, 'platform-start') +
      section('已添加的平台账号', `<p class="section-description">已连接的账号可用于获客。每个账号在这台电脑独立保存登录状态。</p><div class="customer-account-grid">${accountList()}</div>`) +
      `<details class="reference-advanced"><summary>查看平台支持范围与实验接口</summary><div class="capability-grid">${platformCards()}</div>${state.platforms.some(p => p.id === 'wechat_channels') ? '<p>视频号仍为实验接口，暂不作为员工默认入口。</p>' : ''}</details>`;
  };
  pages.team = function () {
    const admin = state.user.role === 'admin';
    $('#page').innerHTML = heading('每位员工使用自己的账号。老板和管理员统一分配账号与权限。') +
      `<div class="customer-grid">${section('员工账号与权限', admin ? '<p>创建员工账号后，将用户名与初始密码交给对应员工。可以随时重置密码或停用离职员工账号。</p>' + button('管理 / 分配员工账号', 'cloud-team', '', 'primary') : '<p>你的账号由管理员分配。忘记密码或需要调整权限，请联系管理员。</p>')}${section('不同电脑，同一企业工作区', '<p>员工直接使用各自的用户名和密码登录，无需填写服务器地址。共享客户清单由企业服务统一保存，社交平台仍需本人登录。</p>', 'team-cloud')}</div>`;
  };
  pages.leads = function () {
    originalLeads();
    document.querySelector('.page-head p').textContent = safetyHold() ? '只查看历史客户、修正意向并准备内部回复草稿；公开发送暂停。' : '这里是已经找到的客户。先看意向依据，再评分、编辑回复或加入共享清单。';
    document.querySelector('.page-head .actions').insertAdjacentHTML('afterbegin', button('云端共享清单', 'shared-list'));
  };
  pages.settings = function () {
    const admin = state.user.role === 'admin';
    $('#page').innerHTML = heading('配置一次，日常工作回到「开始获客」和「客户清单」。') + `<div class="customer-grid integrations-grid">${section('企业共享服务', '<span class="integration-state" id="cloud-state">未配置</span><p>让不同电脑的同事使用统一账号，共享客户清单。</p>' + button('企业服务状态', 'cloud-config', '', 'primary'))}${section('AI 关键词助手', '<span class="integration-state" id="ai-state">公寓词库可用</span><p>输入租房需求，生成可选择的搜索词。支持接入你自己的兼容 API。</p>' + (admin ? button('配置 AI API', 'ai-config') : '<p>API 由管理员配置。</p>'))}</div><div class="customer-grid">${section('企业资料', `<p><strong>${esc(state.tenant?.name || state.company.name)}</strong></p><p>${(state.company.profileSchema || []).map(f => `${esc(f.label)}：${esc(state.tenant?.[f.key] || '待完善')}`).join('<br>')}</p>` + (admin ? button('编辑企业资料', 'edit-company') : ''))}${section('本机备份', '<p>备份客户、任务与资料。云端共享清单独立保存；平台登录状态和 API 密钥不随备份迁移。</p><div class="actions">' + (admin ? button('创建备份', 'backup') + button('打开备份文件夹', 'backup-folder') + button('恢复备份', 'restore') : '') + '</div>')}</div><details class="reference-advanced"><summary>帮助与维护</summary><div class="actions">${button('使用说明', 'help')}${admin ? button('操作记录', 'audit') + button('检查平台依赖', 'diagnostics') : ''}</div></details>`;
    refreshIntegrations();
  };
  async function refreshIntegrations() {
    try {
      integrations = await api('integration_status');
      const c = $('#cloud-state'), a = $('#ai-state');
      if (c) c.textContent = integrations.cloud.connected ? '企业账号已登录' : integrations.cloud.configured ? '已配置，等待登录验证' : '企业服务等待部署';
      if (a) a.textContent = integrations.ai.configured ? (integrations.ai.enabled ? 'API 已启用 · 按点击请求' : 'API 已配置 · 暂未启用') : '公寓词库 · 未接入 AI';
    } catch (e) { if ($('#cloud-state')) $('#cloud-state').textContent = e.message; }
  }
  async function cloudDialog() {
    toast('企业服务由管理员统一配置；请使用分配的员工账号登录。');
  }
  async function aiDialog() {
    await refreshIntegrations(); const a = integrations?.ai || {};
    form('AI 关键词 API', '只在你点击“联想关键词”时发送输入的需求，不上传客户清单。启用后可能消耗供应商额度。',
      field('endpoint', 'API 基础地址', a.endpoint || '', 'url', '例如服务商提供的 https://…/v1') + field('model', '模型名称', a.model || '') + field('api_key', 'API Key', '', 'password', a.configured ? '已保存密钥；留空保留。' : '在本机加密保存，不写入源码。', true) + select('enabled', '关键词联想方式', [['false', '公寓词库（不调用 API）'], ['true', 'AI API（点击时调用）']], String(!!a.enabled)),
      async values => { await api('integration_save', {kind: 'ai', ...values, enabled: values.enabled === 'true'}); });
  }
  async function cloudTeam() {
    await refreshIntegrations();
    if (!integrations?.cloud?.connected) return cloudDialog();
    $('#modal-body').innerHTML = '<h2>员工账号管理</h2><p class="ui-spinner">正在读取成员…</p>'; if (!$('#modal').open) $('#modal').showModal();
    try {
      const r = await api('cloud_members');
      $('#modal-body').innerHTML = `<h2>员工账号管理</h2><p class="intro">每位员工使用自己的账号登录。管理员可创建账号、分配权限、重置密码或停用账号。</p><div class="table-wrap"><table><thead><tr><th>成员</th><th>权限</th><th>状态</th><th></th></tr></thead><tbody>${r.users.map(u => `<tr><td>${esc(u.username)}</td><td>${u.role === 'admin' ? '管理员' : '运营成员'}</td><td>${u.disabled ? '已停用' : '正常'}</td><td><button data-cloud-member="${esc(u.username)}">编辑</button></td></tr>`).join('')}</tbody></table></div><div class="form-actions"><button id="cloud-team-close">关闭</button><button id="cloud-team-add" class="primary">分配员工账号</button></div>`;
      $('#cloud-team-close').onclick = () => $('#modal').close();
      const edit = u => {
        form(u ? '编辑员工账号' : '分配员工账号', '由云端管理员分配权限。密码变更或停用后，旧会话失效。', field('username', '员工用户名', u?.username || '', 'text', '3–80 位字母、数字或 _.@-') + select('role', '权限', [['operator', '运营成员'], ['admin', '管理员']], u?.role || 'operator') + select('disabled', '状态', [['false', '启用'], ['true', '停用']], String(!!u?.disabled)) + field('password', u ? '新密码（留空不修改）' : '初始密码', '', 'password', '至少 12 位', true), async values => api('cloud_member_save', {...values, disabled: values.disabled === 'true'}));
        if (u) $('#f-username').readOnly = true;
      };
      $('#cloud-team-add').onclick = () => edit(null);
      document.querySelectorAll('[data-cloud-member]').forEach(b => b.onclick = () => edit(r.users.find(u => u.username === b.dataset.cloudMember)));
    } catch (e) { $('#modal-body').innerHTML = `<h2>无法读取云端成员</h2><p class="error">${esc(e.message)}</p><button id="cloud-team-close">关闭</button>`; $('#cloud-team-close').onclick = () => $('#modal').close(); }
  }
  function filterCustomers(items, query, grade, platform) {
    const needle = query.trim().toLocaleLowerCase();
    return items.filter(x => (!grade || x.grade === grade) && (!platform || x.platform === platform) &&
      (!needle || [x.author, x.text, x.title, x.source_id].some(v => String(v || '').toLocaleLowerCase().includes(needle))));
  }
  function customerFilters(items) {
    return `<div class="share-filters"><input id="share-query" aria-label="搜索客户" placeholder="搜索昵称、需求或来源 ID"><select id="share-grade" aria-label="筛选意向"><option value="">全部意向</option><option value="A">A 高意向</option><option value="B">B 中意向</option><option value="C">C 待判断</option></select><select id="share-platform" aria-label="筛选平台"><option value="">全部平台</option>${[...new Set(items.map(x => x.platform).filter(Boolean))].map(p => `<option value="${esc(p)}">${esc(platformName(p))}</option>`).join('')}</select></div>`;
  }
  function customerPager() {
    return '<div class="share-pager"><button type="button" id="share-prev">上一页</button><span id="share-page" aria-live="polite"></span><button type="button" id="share-next">下一页</button></div>';
  }
  async function sharedList() {
    await refreshIntegrations();
    if (!integrations?.cloud?.connected) { await cloudDialog(); return; }
    $('#modal-body').innerHTML = '<h2>云端共享清单</h2><p class="ui-spinner">正在读取云端清单…</p>'; if (!$('#modal').open) $('#modal').showModal();
    try {
      const r = await api('cloud_list');
      if (!$('#modal').open) return;
      const loaded = [...(r.items || [])]; let nextCursor = r.next_cursor || '';
      $('#modal-body').innerHTML = `<h2>云端共享清单</h2><p class="intro">同一企业的员工使用各自账号，即可读取这里的清单。平台登录凭证不会上传。</p>${customerFilters(loaded)}<p id="share-total"></p><div class="table-wrap"><table><thead><tr><th>客户</th><th>平台</th><th>意向</th><th>需求</th></tr></thead><tbody id="share-rows"></tbody></table></div>${customerPager()}<button type="button" id="share-more" ${nextCursor ? '' : 'hidden'}>继续加载共享客户</button><p id="share-error" class="error" role="alert"></p><div class="form-actions"><button id="share-close">关闭</button><button id="share-publish" class="primary">选择本机客户加入共享清单</button></div>`;
      let page = 0; const size = 25;
      const draw = () => {
        const filtered = filterCustomers(loaded, $('#share-query').value, $('#share-grade').value, $('#share-platform').value);
        const pages = Math.max(1, Math.ceil(filtered.length / size)); page = Math.min(page, pages - 1);
        $('#share-total').textContent = nextCursor ? `已载入 ${loaded.length} 位客户，当前已载入范围符合 ${filtered.length} 位；筛选仅覆盖已载入客户` : `共 ${loaded.length} 位客户，当前符合 ${filtered.length} 位`;
        $('#share-rows').innerHTML = filtered.slice(page * size, (page + 1) * size).map(x => `<tr><td>${esc(x.author || '未提供昵称')}</td><td>${esc(platformName(x.platform))}</td><td>${esc(x.grade || '待判断')}</td><td class="wrap">${esc(x.text || '')}</td></tr>`).join('') || '<tr><td colspan="4">没有符合条件的客户，试试调整筛选。</td></tr>';
        $('#share-page').textContent = `${page + 1} / ${pages} 页`;
        $('#share-prev').disabled = page === 0; $('#share-next').disabled = page + 1 === pages;
      };
      ['share-query', 'share-grade', 'share-platform'].forEach(id => $('#' + id).oninput = () => { page = 0; draw(); });
      $('#share-prev').onclick = () => { page--; draw(); }; $('#share-next').onclick = () => { page++; draw(); };
      $('#share-more').onclick = async () => {
        if (!nextCursor) return;
        const button = $('#share-more'); button.disabled = true; $('#share-error').textContent = '';
        try {
          const more = await api('cloud_list', {cursor: nextCursor, revision: r.revision});
          if (!button.isConnected) return;
          loaded.push(...(more.items || [])); nextCursor = more.next_cursor || ''; button.hidden = !nextCursor; draw();
        } catch (error) { if (button.isConnected) $('#share-error').textContent = error.message + '；请关闭清单后重新打开。'; }
        finally { if (button.isConnected) button.disabled = false; }
      };
      $('#share-close').onclick = () => $('#modal').close(); $('#share-publish').onclick = () => selectShared(r); draw();
    } catch (e) { $('#modal-body').innerHTML = `<h2>共享清单暂时无法读取</h2><p class="error">${esc(e.message)}</p><button id="share-close">关闭</button>`; $('#share-close').onclick = () => $('#modal').close(); }
  }
  function selectShared(remote) {
    const local = rows('leads').filter(x => !x.demo), selected = new Set();
    const maxBatch = Number(remote.max_batch) || 100;
    let page = 0; const size = 25;
    $('#modal-body').innerHTML = `<h2>选择要共享的客户</h2><p class="intro">从全部本机客户中筛选，跨页勾选后一次上传。每次最多 ${maxBatch} 条；已有共享客户会更新资料。</p>${customerFilters(local)}<p id="share-total"></p><div class="share-pager"><button type="button" id="share-select-page">选择本页</button><button type="button" id="share-clear">清空选择</button><strong id="share-selected" aria-live="polite"></strong></div><div id="share-choices" class="share-selection"></div>${customerPager()}<p class="error" id="share-error" role="alert"></p><div class="form-actions"><button type="button" id="share-back">返回</button><button class="primary" type="button" id="share-submit">确认上传所选客户</button></div>`;
    const filtered = () => filterCustomers(local, $('#share-query').value, $('#share-grade').value, $('#share-platform').value);
    const visible = () => filtered().slice(page * size, (page + 1) * size);
    const updateCount = () => { $('#share-selected').textContent = `已选择 ${selected.size} / ${maxBatch} 位`; $('#share-submit').disabled = selected.size === 0; };
    const draw = () => {
      const list = filtered(), pages = Math.max(1, Math.ceil(list.length / size)); page = Math.min(page, pages - 1);
      $('#share-total').textContent = `本机共 ${local.length} 位，当前符合 ${list.length} 位；切换筛选会保留已选客户`;
      $('#share-choices').innerHTML = visible().map(x => `<label><input type="checkbox" name="lead" value="${esc(x.id)}" ${selected.has(x.id) ? 'checked' : ''}><span><strong>${esc(x.author || '未提供昵称')}</strong><small>${esc(platformName(x.platform))} · ${esc(x.grade || '待判断')} · ${esc((x.text || x.title || '').slice(0, 160))}</small></span></label>`).join('') || '<p>没有符合条件的客户。</p>';
      $('#share-choices').querySelectorAll('input').forEach(box => box.onchange = () => {
        if (box.checked && selected.size >= maxBatch) { box.checked = false; $('#share-error').textContent = `每次最多选择 ${maxBatch} 位，请先取消部分选择或分批上传。`; return; }
        box.checked ? selected.add(box.value) : selected.delete(box.value); $('#share-error').textContent = ''; updateCount();
      });
      $('#share-page').textContent = `${page + 1} / ${pages} 页`; $('#share-prev').disabled = page === 0; $('#share-next').disabled = page + 1 === pages; updateCount();
    };
    ['share-query', 'share-grade', 'share-platform'].forEach(id => $('#' + id).oninput = () => { page = 0; draw(); });
    $('#share-prev').onclick = () => { page--; draw(); }; $('#share-next').onclick = () => { page++; draw(); };
    $('#share-select-page').onclick = () => { const list = visible(); for (const x of list) { if (selected.size < maxBatch) selected.add(x.id); } $('#share-error').textContent = list.some(x => !selected.has(x.id)) ? `已达到 ${maxBatch} 位上限，部分客户未选中。` : ''; draw(); };
    $('#share-clear').onclick = () => { selected.clear(); $('#share-error').textContent = ''; draw(); };
    $('#share-back').onclick = sharedList;
    $('#share-submit').onclick = async e => {
      if (!selected.size) return;
      const submit = e.currentTarget;
      const buttons = [...$('#modal-body').querySelectorAll('button, input, select')]; buttons.forEach(b => b.disabled = true);
      WorkbenchUI.busy(submit, true);
      let published = false;
      try {
        await api('cloud_publish', {ids: [...selected], revision: remote.revision});
        published = true;
        await sharedList();
        if ($('#share-choices')) throw Error('企业服务连接状态暂时无法确认');
        const notice = document.createElement('p'); notice.className = 'share-success'; notice.textContent = `已上传 ${selected.size} 位客户。`;
        $('#modal-body').prepend(notice); toast(notice.textContent);
      } catch (err) {
        if (published) {
          $('#modal-body').innerHTML = `<h2>上传已完成</h2><p class="share-success">已上传 ${selected.size} 位客户。</p><p class="error">清单刷新失败：${esc(err.message)}。请重新打开共享清单核对。</p><button type="button" id="share-close">关闭</button>`;
          $('#share-close').onclick = () => $('#modal').close();
        } else $('#share-error').textContent = err.message + '；选择已保留。';
      }
      finally { WorkbenchUI.busy(submit, false); buttons.forEach(b => { if (b.isConnected) b.disabled = false; }); if ($('#share-choices')) draw(); if ($('#share-error')?.textContent) $('#share-error').scrollIntoView({block:'center'}); }
    };
    draw();
  }
  action = async function (a, id) {
    if (safetyHold() && ['add-platform-account','account-setup','account-check','collect-account','start-search','run-task','queue-replies'].includes(a)) { toast('当前版本验收中，扫码、采集和公开发送已暂停。'); return; }
    if (a === 'focus-search' || a === 'new-task') { state.page = 'tasks'; render(); $('#quick-keywords')?.focus(); return; }
    if (a === 'goto-team') { state.page = 'team'; render(); return; }
    if (a === 'cloud-config') return cloudDialog();
    if (a === 'cloud-team') return cloudTeam();
    if (a === 'ai-config') return aiDialog();
    if (a === 'shared-list') return sharedList();
    return originalAction(a, id);
  };
  login = function (first) {
    originalLogin(false);
    document.body.classList.add('customer-edition');
    $('.login-local').textContent = '方隅公寓 · 员工工作区';
    $('.login-inner > p').textContent = '使用老板或管理员分配的用户名和密码登录。';
    $('.login-inner .notice').textContent = '账号由企业统一管理 · 无需自行注册';
  };
  const oldLeadDetail = leadDetail;
  leadDetail = function (id) {
    oldLeadDetail(id);
    if (safetyHold()) {
      const detail = $('#lead-inspector')?.hidden === false ? $('#lead-inspector') : $('#modal-body');
      detail?.querySelectorAll('#send-direct,#copy-reply,#mark-sent').forEach(button => button.remove());
      const title = [...(detail?.querySelectorAll('h3')||[])].find(node => node.textContent === '联系客户');
      if (title && !detail.querySelector('.safety-hold-note')) {
        title.textContent = '准备内部回复草稿';
        const note = document.createElement('p'); note.className = 'notice safety-hold-note';
        note.textContent = '当前版本验收中：可保存和审核内部草稿，暂不扫码、复制对外发送或登记已发送。';
        title.insertAdjacentElement('afterend', note);
      }
    }
    const panel = $('#lead-inspector');
    if (panel && !panel.hidden && !$('#detail-share')) {
      const b = document.createElement('button'); b.id = 'detail-share'; b.textContent = '查看云端共享清单'; b.onclick = sharedList; panel.append(b);
    }
  };
  // Animate dialog state transitions once; never replay the whole page on polling.
  const modal = $('#modal');
  new MutationObserver(records => { if (records.some(r => r.attributeName === 'open') && modal.open) safeMotion(modal, {opacity: [0, 1], y: [12, 0], scale: [.985, 1]}, {duration: .24}); }).observe(modal, {attributes: true, attributeFilter: ['open']});
  window.CustomerWorkspace = {labels, refreshIntegrations};
})();

/* Approved interaction flow; visual assets are decorative and never imply service status. */
(() => {
  const asset = id => '/assets/fy-' + id + '.png';
  const art = (id, cls='') => `<img class="fy-art ${cls}" src="${asset(id)}" alt="" aria-hidden="true" decoding="async">`;
  function add(node, id, cls='') { if(node && !node.querySelector(':scope > .fy-art')) node.insertAdjacentHTML('afterbegin', art(id,cls)); }
  function decorate() {
    const nav = {tasks:'icon-07-search',leads:'icon-17-customers',accounts:'icon-34-connect',team:'icon-40-team',settings:'icon-47-settings'};
    Object.entries(nav).forEach(([key,id]) => { const b=document.querySelector(`[data-nav="${key}"]`); if(b){ b.querySelector(':scope > .ui-icon, :scope > .nav-icon')?.remove(); add(b,id,'fy-nav-icon'); }});
    const brand=document.querySelector('.sidebar .brand, .brand');
    if(brand && !brand.closest('.login-inner')) { brand.querySelector(':scope > svg, :scope > .ui-icon, :scope > .brand-mark')?.remove(); add(brand,'icon-02-building','fy-brand-icon'); }
    const header=document.querySelector('#page > .page-head');
    const heroes={tasks:'scene-02-keys',leads:'scene-03-customers',accounts:'scene-05-connect',team:'scene-08-team',settings:'scene-10-backup'};
    if(header) {header.classList.add('fy-page-head');add(header,heroes[state.page]||'scene-01-apartment','fy-page-art');}
    if(state.page==='tasks') {
      add(document.querySelector('.reference-idle'),'scene-09-room','fy-room-art');
      document.querySelector('.reference-idle > .ui-icon, .reference-idle > .nav-icon')?.remove();
      add(document.querySelector('.keyword-assistant-head'),'scene-07-ai-suggestions','fy-keyword-art');
    }
    if(state.page==='leads') document.querySelectorAll('#page .empty').forEach(el=>{
      el.querySelector('.empty-art')?.remove();add(el,rows('leads').length?'state-06-no-results':'state-01-empty-customers','fy-empty-art');
    });
    if(state.page==='team') add(document.querySelector('.team-cloud'),'scene-06-cloud-sync','fy-card-art');
    if(state.page==='settings') {
      document.querySelectorAll('.customer-grid .panel').forEach((el,i)=>add(el,['scene-06-cloud-sync','scene-07-ai-suggestions','scene-01-apartment','scene-10-backup'][i],'fy-card-art'));
    }
  }
  const previousRender=render;
  render=function(){previousRender();decorate();};
  const previousLogin=login;
  login=function(first){previousLogin(first);const scene=document.querySelector('.login-story');if(scene){scene.querySelector('.login-building')?.remove();scene.insertAdjacentHTML('afterbegin',art('scene-11-login-entrance','fy-login-art'));}};
  // Observe only modal content. Idempotent decorations cannot retrigger business operations.
  const modal=document.querySelector('#modal-body');
  function decorateModal(){
    const frame=document.querySelector('#customer-qr-frame');
    if(frame){
      const qr=document.querySelector('#customer-qr-image');
      let statusArt=frame.querySelector('.fy-qr-art');
      if(!statusArt){frame.insertAdjacentHTML('afterbegin',art('state-04-loading','fy-qr-art'));statusArt=frame.querySelector('.fy-qr-art');}
      const failed=document.querySelector('#customer-qr-status')?.classList.contains('failed');
      const done=document.querySelector('#customer-qr-done');
      const success=done && !done.hidden;
      const src=asset(failed?'state-03-error':success?'state-02-success':'state-04-loading');
      if(statusArt.getAttribute('src')!==src)statusArt.setAttribute('src',src);
      const hideArt=!!qr && !qr.hidden && !failed && !success; if(statusArt.hidden!==hideArt)statusArt.hidden=hideArt;
      frame.classList.toggle('fy-status-frame',!statusArt.hidden);
    } else if(document.querySelector('#f-environment_id')) add(modal,'scene-06-cloud-sync','fy-dialog-art');
    else if(document.querySelector('#f-api_key')) add(modal,'scene-07-ai-suggestions','fy-dialog-art');
  }
  new MutationObserver(decorateModal).observe(modal,{subtree:true,childList:true,attributes:true,attributeFilter:['hidden','class']});
})();



