"""Persistent owned Douyin browser, reusing the reviewed r55 bridge/relay.

The show mailbox belongs to one randomly marked account window. It carries no
platform credentials and supports only a user-requested show/restore operation.
Login, captcha and any platform verification remain human browser actions.
"""
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import secrets
import sys
import threading
from urllib.parse import urlparse

_ORIGINAL_WINDOW_SHA='a41868f18fdbc6783b8c731042e0582a7c1e9d344b9d593eef0b3bd0b0e3f5ea'


def request_show(owned):
    """Called only after the original current-actor/device guards succeed."""
    if not owned.get('show_path'):
        return False  # A pre-upgrade process has no mailbox.
    marker=owned.get('marker')
    if type(marker) is not str or re.fullmatch(r'[a-f0-9]{40}',marker) is None:
        raise ValueError('owned_window_unconfirmed')
    path=Path(owned['show_path'])
    payload={'marker':marker,'action':'show','nonce':secrets.token_hex(16)}
    temporary=path.with_name(path.name+'.'+payload['nonce']+'.tmp')
    temporary.write_text(json.dumps(payload,separators=(',',':')),'utf-8')
    temporary.replace(path)
    return True


class ShowRequests:
    def __init__(self,window,path,marker):
        self.window=window;self.path=Path(path);self.marker=marker
        self.last_nonce=None;self.closed=threading.Event()

    def check_once(self):
        try:
            if not self.path.is_file() or self.path.stat().st_size>1024:return False
            value=json.loads(self.path.read_text('utf-8'))
            if (type(value) is not dict or set(value)!={'marker','action','nonce'}
                    or value['marker']!=self.marker or value['action']!='show'
                    or type(value['nonce']) is not str
                    or re.fullmatch(r'[a-f0-9]{32}',value['nonce']) is None
                    or value['nonce']==self.last_nonce):return False
            self.last_nonce=value['nonce']
            self.window.restore();self.window.show()
            return True
        except (OSError,ValueError,TypeError):return False

    def run(self):
        while not self.closed.wait(.25):
            try:self.check_once()
            except Exception:pass  # An unavailable show call never closes login.


def _original(source_root):
    path=Path(source_root)/'managed_platform_window.py'
    if hashlib.sha256(path.read_bytes()).hexdigest()!=_ORIGINAL_WINDOW_SHA:
        raise ValueError('component_review_pending')
    spec=importlib.util.spec_from_file_location('_fangyu_reviewed_douyin_window',path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module


def main(spec_path=None):
    import webview
    spec=json.loads(Path(spec_path or sys.argv[1]).read_text('utf-8'))
    if (spec.get('platform')!='douyin' or type(spec.get('marker')) is not str
            or re.fullmatch(r'[a-f0-9]{40}',spec['marker']) is None):
        raise ValueError('owned_window_unconfirmed')
    original=_original(spec['source_root'])
    config=json.loads(Path(spec['config']).read_text('utf-8'))
    raw=Path(spec['script']).read_text('utf-8').replace(config['bridge']['token'],'')
    relay=original.Relay(config,'douyin',spec.get('state_path'))
    window=webview.create_window('登录抖音 · '+spec['name'],'https://www.douyin.com/',
        js_api=relay,width=1180,height=820,focus=True)
    relay._window=window
    mailbox=ShowRequests(window,spec['show_path'],spec['marker'])
    def loaded():
        current=urlparse(window.get_current_url() or '')
        if current.scheme=='https' and current.hostname=='www.douyin.com':
            window.evaluate_js(original.injection(raw,spec['marker']))
    window.events.loaded+=loaded
    window.events.closed+=mailbox.closed.set
    try:
        # No login timer and no auth-success shutdown: this exact account's
        # profile and browser remain available for manual page verification.
        webview.start(mailbox.run,gui='edgechromium',private_mode=False,
            storage_path=spec['profile'])
    finally:mailbox.closed.set()


if __name__=='__main__':main()
