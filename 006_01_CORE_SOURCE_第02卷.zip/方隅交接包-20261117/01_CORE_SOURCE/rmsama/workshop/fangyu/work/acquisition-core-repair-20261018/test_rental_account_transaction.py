"""1000 real rental assessments with real Core task/account authorization.

Synthetic owned SQLite only. No permission/Store method is stubbed. Baseline
--project-root selects the frozen failed GUI candidate, so RED stays reproducible
even while the sole author repairs canonical code. No server or native window.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import socket
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

W = Path(__file__).resolve().parent
P = W.parents[1]
parser = argparse.ArgumentParser()
parser.add_argument('--project-root', default=str(P))
parser.add_argument('--result', default='RENTAL-ACCOUNT-1000-RESULT.json')
args = parser.parse_args()
SOURCE = Path(args.project_root).resolve()
if not SOURCE.is_relative_to(P):
    raise SystemExit('Only named project/candidate source inside this project is allowed')
sys.path.insert(0, str(SOURCE / 'work/ui-runtime-r55/src'))
sys.path.insert(0, str(SOURCE / 'work/ui-native-r57'))
from core import Core
from rental_assessment import RentalAssessmentService, RentalAssessmentPermissionError, ENTITY


class RentalAccountTransaction(unittest.TestCase):
    evidence = {}

    def test_1000_assessments_keep_real_account_guard_in_one_transaction(self):
        started = time.monotonic()
        company = {'id': 'fangyu-apartment-client', 'edition': 'customer',
                   'personalMode': False, 'authMode': 'managed',
                   'managedWorkspace': {'environment_id': 'synthetic-rental-account-fixture'}}
        tenant = 'cloud-' + hashlib.sha256((company['managedWorkspace']['environment_id'] +
                                          '\n' + company['id']).encode()).hexdigest()[:24]
        user = {'id': 'synthetic-rental-user', 'tenant_id': tenant, 'username': 'synthetic-owner',
                'role': 'operator', 'cloud_bound': True, 'disabled': False}

        def forbidden(*unused, **kwargs):
            raise AssertionError('Network/process IO is forbidden in this synthetic assessment test')

        with tempfile.TemporaryDirectory(prefix='rental-account-owned-', dir=W) as directory:
            self.assertEqual(Path(directory).parent, W)
            with patch.object(socket.socket, 'connect', forbidden), \
                    patch.object(socket, 'create_connection', forbidden), \
                    patch.object(subprocess, 'Popen', forbidden):
                core = Core(directory)
                try:
                    core.store.put('tenants', {'id': tenant, 'tenant_id': tenant,
                                              'name': 'Synthetic transaction fixture'})
                    core.store.put('users', user)
                    account = core.handle('save', {'entity': 'accounts', 'record': {
                        'name': 'Synthetic owned account', 'platform': 'xiaohongshu',
                        'cloud_owner': user['username'], 'status': 'ready'}}, user)
                    task = core.handle('save', {'entity': 'tasks', 'record': {
                        'name': 'Synthetic real-account rental transaction', 'platform': 'xiaohongshu',
                        'scope': 'search_comments', 'account_id': account['id'],
                        'keywords': ['古北租房'], 'comment_keyword_mode': 'all',
                        'continuous_enabled': False, 'daily_limit': 1000, 'target_count': 1000,
                        'city': '上海', 'area': '古北'}}, user)
                    task.update(store_id='synthetic-store', status='completed')
                    core.store.put('tasks', task)
                    stamp = datetime.now(timezone.utc).isoformat()
                    rows = [{'platform': 'xiaohongshu', 'source_type': 'comment',
                        'source_id': f'synthetic-source-{index:04d}', 'task_id': task['id'],
                        'comment_id': f'synthetic-comment-{index:04d}',
                        'author_id': f'synthetic-author-{index:04d}', 'author': f'合成租客{index:04d}',
                        'text': '我自己想租古北一居室，预算人民币4000元/月，明天下午3点能看房吗？'
                                f'这是合成事务回归来源{index:04d}。',
                        'note_url': 'https://www.xiaohongshu.com/explore/abcdef0123456789abcdef01',
                        'content_title': '合成求租讨论', 'published_at': stamp}
                        for index in range(1000)]
                    self.assertEqual(core._import(rows, tenant, user)['imported'], 1000)
                    self.assertNotIn('_task_access', core.__dict__)
                    self.assertNotIn('_account_access', core.__dict__)
                    service = RentalAssessmentService(core, company, store_id='synthetic-store')

                    # Prove the real original guard rejects a foreign account before writes.
                    foreign = {**account, 'cloud_owner': 'different-synthetic-owner'}
                    core.store.put('accounts', foreign)
                    with self.assertRaises(RentalAssessmentPermissionError):
                        service.assess_task(user, task['id'])
                    self.assertEqual(core.store.list(ENTITY, tenant), [])
                    core.store.put('accounts', account)
                    self.evidence['foreign_account_rejected_before_writes'] = True

                    # 1000 rows exceed the default SQLite pager cache with normal assessments.
                    # Keep every real task/account read and all default cache/locking behavior.
                    result = service.assess_task(user, task['id'])
                    self.assertEqual(result['assessed'], 1000)
                    self.assertEqual(result['written'], 1000)
                    stored = core.store.list(ENTITY, tenant)
                    self.assertEqual(len(stored), 1000)
                    self.assertEqual(len({row['lead_id'] for row in stored}), 1000)
                    self.assertTrue(all(row['owner'] == user['username'] and
                                        row['task_id'] == task['id'] and
                                        row['store_id'] == 'synthetic-store' for row in stored))
                    self.assertEqual(core.store.get('accounts', account['id'])['cloud_owner'], user['username'])
                    original_scope = service._scope
                    original_sidecars = json.dumps(sorted(stored, key=lambda row: row['id']),
                                                   sort_keys=True, ensure_ascii=False)
                    transaction_rejections = {}
                    for change in ('owner', 'tenant', 'delete'):
                        injected = []

                        def mutate_in_same_transaction(db, current_actor, lead):
                            # Injection only: the original scope and actual Core guards execute.
                            # An external writer cannot enter this BEGIN IMMEDIATE transaction.
                            if not injected:
                                injected.append(True)
                                if change == 'delete':
                                    db.execute('DELETE FROM records WHERE entity=? AND id=?',
                                               ('accounts', account['id']))
                                else:
                                    changed = dict(account)
                                    changed['cloud_owner' if change == 'owner' else 'tenant_id'] = 'foreign-synthetic-scope'
                                    db.execute('UPDATE records SET body=?,tenant_id=? WHERE entity=? AND id=?',
                                        (json.dumps(changed, ensure_ascii=False), changed['tenant_id'],
                                         'accounts', account['id']))
                            return original_scope(db, current_actor, lead)

                        with patch.object(service, '_scope', side_effect=mutate_in_same_transaction):
                            with self.assertRaises(RentalAssessmentPermissionError):
                                service.assess_task(user, task['id'])
                        self.assertEqual(injected, [True])
                        self.assertEqual(core.store.get('accounts', account['id']), account)
                        self.assertEqual(json.dumps(sorted(core.store.list(ENTITY, tenant),
                                                          key=lambda row: row['id']),
                                                    sort_keys=True, ensure_ascii=False), original_sidecars)
                        transaction_rejections[change] = True
                    self.evidence.update(status='PASS', assessed=result['assessed'], written=result['written'],
                                         stored=len(stored), seconds=round(time.monotonic()-started, 3),
                                         same_transaction_account_mutations_rejected=transaction_rejections,
                                         mutation_injection='scope entry calls original scope; no Core auth/Store stub')
                finally:
                    core.adapters.close()


if __name__ == '__main__':
    destination = (W / args.result).resolve()
    if destination.parent != W or destination.suffix != '.json':
        raise SystemExit('Result must stay directly in the owned batch')
    evidence = RentalAccountTransaction.evidence
    evidence.update(status='NOT_COMPLETED', source_root=str(SOURCE), count=1000,
        source_sha256={name: hashlib.sha256((SOURCE / name).read_bytes()).hexdigest() for name in (
            'work/ui-native-r57/rental_assessment.py', 'work/ui-runtime-r55/src/core/engine.py',
            'work/ui-runtime-r55/src/core/store.py')},
        core_task_guard_stubbed=False, core_account_guard_stubbed=False,
        real_network_calls=0, real_cli_executions=0, paid_ai_requested=False)
    outcome = unittest.TextTestRunner(verbosity=2).run(
        unittest.defaultTestLoader.loadTestsFromTestCase(RentalAccountTransaction))
    if not outcome.wasSuccessful():
        evidence.update(status='FAIL', errors=outcome.errors, failures=outcome.failures)
    destination.write_text(json.dumps(evidence, ensure_ascii=False, indent=2, default=str)+'\n', 'utf-8')
    print(json.dumps({key: value for key, value in evidence.items()
                      if key not in ('errors', 'failures', 'source_sha256')}, ensure_ascii=False))
    raise SystemExit(0 if outcome.wasSuccessful() else 1)
