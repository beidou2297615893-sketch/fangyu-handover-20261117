'use strict';
const $=id=>document.getElementById(id);
const states={
 unbound:['连接这台电脑',''],
 pending:['连接未完成','粘贴原码重试；过期则在网页生成新码。'],
 binding:['正在连接',''],
 offline:['暂时离线','助手会自动重连，先检查网络。'],
 online:['电脑已连接','可接收采集任务。'],
 held:['电脑已连接，平台任务暂停','采集和公开发送暂停；此前结果不明的回复需人工核实，不能视为发送失败。'],
 revoked:['连接已停用','请联系管理员。'],
 stopped:['助手连接已断开','请先检查本地助手状态；刚才的扫码结果尚未核实。'],
 error:['助手状态异常','本地助手返回错误，请记录页面提示后联系管理员核查。扫码结果尚未核实。']
};
const artByState={unbound:'fy-scene-05-connect.png',pending:'fy-state-04-loading.png',binding:'fy-state-04-loading.png',online:'fy-state-02-success.png',held:'fy-state-05-offline.png',offline:'fy-state-05-offline.png',revoked:'fy-state-03-error.png',stopped:'fy-state-05-offline.png',error:'fy-state-03-error.png'};
let submitting=false,reading=false,lastState='',didEnter=false,currentStatus='unbound',accountSafetyAvailable=null,lastSetupStep='',pairingError='',accountReading=false,loginJob='',accountChoices=[],safetyRevision=null,safetyRevisionAccount='';
function showError(message,persistent=false){
 if(persistent)pairingError=message;
 const box=$('error'),changed=box.hidden||box.textContent!==message;box.textContent=message;box.hidden=false;
 if(changed&&window.gsap&&!matchMedia('(prefers-reduced-motion: reduce)').matches)window.gsap.fromTo(box,{autoAlpha:0,y:5},{autoAlpha:1,y:0,duration:.22,ease:'power2.out',clearProps:'all',overwrite:'auto'});
}
function clearError(){pairingError='';$('error').textContent='';$('error').hidden=true;}
function animateEntrance(){
 if(didEnter)return;didEnter=true;
 if(!window.gsap||matchMedia('(prefers-reduced-motion: reduce)').matches)return;
 window.gsap.fromTo(['.intro-copy','.intro-art-frame','.connection',...(currentStatus==='online'?['.local-login']:[])],{autoAlpha:0,y:13},{autoAlpha:1,y:0,duration:.45,stagger:.09,ease:'power2.out',clearProps:'all',overwrite:'auto'});
}
function animateState(value){if(lastState===value||!window.gsap||matchMedia('(prefers-reduced-motion: reduce)').matches){lastState=value;return;}lastState=value;window.gsap.fromTo('.status-line, #description',{autoAlpha:0,y:7},{autoAlpha:1,y:0,duration:.22,stagger:.05,ease:'power2.out',clearProps:'all',overwrite:'auto'});}
async function api(action,data={}){const r=await fetch('/api',{method:'POST',headers:{'Content-Type':'application/json','X-Local-App':'1'},body:JSON.stringify({action,data}),cache:'no-store'});const value=await r.json();if(!r.ok)throw Error(value.error||'助手暂时无法连接');return value;}
function syncAccountSelection(){
 const selected=accountChoices.find(account=>account.id===$('assistant-account').value);
 const ready=selected?.status==='ready';
 $('assistant-login').textContent=ready?'重新登录此账号':selected?'重新打开此账号登录':'登录新的小红书账号';
 $('assistant-login').classList.toggle('secondary',ready);
 $('assistant-account-actions').hidden=!selected;
 $('account-state').textContent=ready?'已保存登录状态。':selected?'请扫码登录。':'扫码后会自动显示昵称。';
}
async function refreshAccounts(){
 if(accountReading||!(accountSafetyAvailable===null?['online','held'].includes(currentStatus):accountSafetyAvailable))return; accountReading=true;
 try{
  const value=await api('assistant_workspace_state');
  const select=$('assistant-account');
  const accounts=(value.accounts||[]).filter(x=>x.platform==='xiaohongshu');
  accountChoices=accounts;
  const previous=select.value;
  select.innerHTML='<option value="">首次登录：创建新账号</option>'+accounts.map(x=>'<option value="'+x.id+'">'+String(x.name||'小红书账号').replace(/[&<>"']/g,'')+' · '+({ready:'已保存登录',logging_in:'登录中',login_required:'待登录',identity_mismatch:'扫码账号不一致，已暂停',identity_unverified:'账号身份未核实，已暂停',duplicate_identity:'本机账号记录重复，已暂停',duplicate_identity_remote:'企业身份登记冲突，已暂停',identity_cloud_unavailable:'企业身份校验不可用，已暂停'}[x.status]||'待确认')+'</option>').join('');
  select.value=accounts.some(x=>x.id===previous)?previous:(accounts.find(x=>x.status==='ready')?.id||'');
  syncAccountSelection();
  const safety=$('safety-account'),oldSafety=safety.value;
  safety.innerHTML='<option value="">选择小红书账号</option>'+accounts.map(x=>'<option value="'+x.id+'">'+String(x.name||'小红书账号').replace(/[&<>"']/g,'')+'</option>').join('');
  safety.value=accounts.some(x=>x.id===oldSafety)?oldSafety:(accounts[0]?.id||'');
  if(safety.value)await refreshSafety();
  else{$('safety-state').textContent='暂无账号记录。';$('safety-record').textContent='';}
 }catch(e){$('account-state').textContent=e.message;}finally{accountReading=false;}
}
async function refreshSafety(){
 const id=$('safety-account').value;
 if(!id){safetyRevision=null;safetyRevisionAccount='';$('safety-state').textContent='选择账号查看记录。';$('safety-record').textContent='';return;}
 try{
  const value=await api('assistant_account_safety',{account_id:id});
  if($('safety-account').value!==id)return;
  safetyRevision=Number.isSafeInteger(value.activity_revision_bytes)?value.activity_revision_bytes:null;
  safetyRevisionAccount=id;
  const observed=Number(value.observed_gap_before_signal_seconds);
  const hasObserved=value.observed_gap_before_signal_seconds!==null&&Number.isFinite(observed);
  const gap=value.suggested_trial_gap_seconds
   ?'已记录异常前的最大采集/回复请求间隔约 '+observed+' 秒；下次人工试运行参考至少间隔 '+value.suggested_trial_gap_seconds+' 秒。此数值不是平台安全频率，软件目前不会自动按此数值限速。'
   :hasObserved?'已记录异常前的采集/回复请求间隔约 '+observed+' 秒，但超出可参考范围，无法给出下次试运行秒数；请人工核实。'
   :(value.risk_signals||value.process_anomalies?'现有采集/回复记录不足，无法推算试运行间隔；扫码轮询不用于推算。':'');
  $('safety-state').textContent=value.state==='review_required'?'账号需核实，相关采集已暂停。':'暂无待核实提醒。';
  $('safety-record').textContent=`${value.message} 近 30 天：${value.requests} 次请求，${value.risk_signals} 次提醒，${value.process_anomalies} 次退出异常。${gap}`;
  if($('safety-summary'))$('safety-summary').textContent=value.state==='review_required'?'需要处理':'查看记录';
  if(value.state==='review_required')$('account-safety').open=true;
  $('safety-review').hidden=value.state!=='review_required'||!['online','held'].includes(currentStatus);
 }catch(e){safetyRevision=null;safetyRevisionAccount='';$('safety-state').textContent=e.message;$('safety-record').textContent='';}
}
async function recordSafety(kind){
 const id=$('safety-account').value;if(!id)return;
 if(kind==='review_completed'&&(safetyRevisionAccount!==id||safetyRevision===null)){
  await refreshSafety();$('safety-state').textContent+=' 请核对最新记录后再点击人工复核。';return;
 }
 if(kind==='review_completed'&&!confirm('请确认已人工核实账号状态与上次操作结果。这里只记录复核，不会解除公司暂停或自动恢复登录、采集、发送；仍有封号风险。是否记录？'))return;
 for(const key of ['safety-phone','safety-logout','safety-review'])$(key).disabled=true;
 try{await api('assistant_account_signal',{account_id:id,kind,...(kind==='review_completed'?{revision:safetyRevision}:{})});await refreshSafety();}
 catch(e){safetyRevision=null;safetyRevisionAccount='';$('safety-state').textContent=e.message;}
 finally{for(const key of ['safety-phone','safety-logout','safety-review'])$(key).disabled=false;}
}
async function pollLogin(job){
 const image=$('assistant-qr-image'),placeholder=$('assistant-qr-placeholder'),message=$('assistant-qr-state');
 // The CLI may wait up to 300 seconds; do not report a client timeout first.
 for(let i=0;i<230;i++){
  await new Promise(r=>setTimeout(r,1500));
  if(loginJob!==job||$('assistant-qr').hidden)return;
  try{
   const value=await api('assistant_job_status',{job_id:job});
   if(value.status==='running'&&value.phase==='verifying_identity'){
    image.hidden=true;placeholder.hidden=true;
    message.textContent='扫码流程已结束，本机正在核验账号身份。';
   }else if(value.status==='running'&&value.qr_ready){
    placeholder.hidden=true;
    if(image.hidden){image.src='/assistant-qr/'+job+'?t='+Date.now();image.hidden=false;}
    message.textContent='请用小红书 App 扫码，完成后等待状态更新。';
   }
   if(value.status!=='running'){
    image.hidden=true;placeholder.hidden=true;
    const code=value.error_code?`（诊断码：${value.error_code}）`:'';
    message.textContent=value.status==='completed'?'小红书登录已完成；账号操作仍须遵守当前安全暂停状态。':(value.error||'登录未完成')+code+'。请先核对手机与账号状态，不要连续重试。';
    await refreshAccounts();return;
   }
  }catch(e){image.hidden=true;placeholder.hidden=true;message.textContent=e instanceof TypeError?'本地助手连接已断开，扫码结果尚未核实；请先检查助手状态。':e.message;return;}
 }
 image.hidden=true;placeholder.hidden=true;
 message.textContent='扫码结果仍未核实；请检查助手状态与手机提示，暂勿重复扫码。';
}

function updateSetupStep(status){
 const step=status==='online'?3:status==='unbound'?($('pair-code').value.trim()?2:1):['pending','binding'].includes(status)?2:0;
 for(let n=1;n<=3;n++){
  const item=$(`setup-step-${n}`);
  item.classList.toggle('current-step',n===step);item.classList.toggle('is-complete',step>0&&n<step);
  if(n===step)item.setAttribute('aria-current','step');else item.removeAttribute('aria-current');
 }
 if(step&&lastSetupStep&&step!==lastSetupStep&&!$('setup-steps').hidden&&window.gsap&&!matchMedia('(prefers-reduced-motion: reduce)').matches){
  window.gsap.fromTo($(`setup-step-${step}`),{scale:.97,y:3},{scale:1,y:0,duration:.22,ease:'power2.out',clearProps:'transform',overwrite:'auto'});
 }
 lastSetupStep=step;
}
function render(value){
 currentStatus=value.state;
 const localWorkspace=value.local_workspace===true;
 const localAccountVisible=!localWorkspace||Boolean(value.device);
 $('assistant-edition').textContent=localWorkspace?'账号设置':'本地助手';
 $('assistant-heading').textContent=localWorkspace?'账号设置':'账号与连接';
 accountSafetyAvailable=localAccountVisible&&(typeof value.account_safety_available==='boolean'
  ?value.account_safety_available:['online','held'].includes(value.state));
 const held=Boolean(value.safety_hold);
 const pairingAllowed=!held||value.pairingAllowed===true;
 for(const link of document.querySelectorAll('.workspace-link')){
  const target=value.workspace_url||'';
  link.hidden=!target;
  if(target){
   link.href=target;
   link.textContent=value.local_workspace?'返回工作台':'进入工作台 ↗';
   link.target=value.local_workspace?'_self':'_blank';
  }
 }
 document.body.dataset.assistantState=value.state;
 document.body.dataset.assistantHold=String(held);
 const state=states[value.state]||states.error;
 const art=$('assistant-art'),asset=artByState[value.state]||artByState.error;
 if(art.dataset.asset!==asset){art.src=`/assets/${asset}`;art.dataset.asset=asset;
  if(lastState&&window.gsap&&!matchMedia('(prefers-reduced-motion: reduce)').matches)window.gsap.fromTo(art,{autoAlpha:0,scale:.96,y:7},{autoAlpha:1,scale:1,y:0,duration:.32,ease:'power2.out',clearProps:'opacity,visibility,transform',overwrite:'auto'});
 }
 $('connection-title').textContent=!pairingAllowed&&['unbound','pending','binding'].includes(value.state)?'新电脑连接已暂停':state[0];
 const description=localWorkspace&&!value.device?'请返回工作台登录并连接这台电脑。':value.state==='held'?state[1]:held&&value.hold_reason==='remote_unconfirmed'?'正在连接公司服务，无需重新绑定；结果不明的回复需人工核实。':held?'采集和公开发送暂未开放；结果不明的回复需人工核实。':state[1];
 $('description').textContent=description;$('description').hidden=!description;
 $('assistant-footer').textContent=held||value.state==='held'?'当前平台采集已暂停。':'采集期间请保持助手运行。';
 $('light').classList.toggle('online',value.state==='online');
 $('light').classList.toggle('busy',['pending','binding','offline','held'].includes(value.state));
 $('connection-panel').classList.toggle('is-online',value.state==='online');
 $('pair-form').hidden=localWorkspace||!pairingAllowed||!['unbound','pending','binding'].includes(value.state);
 $('bind').disabled=localWorkspace||!pairingAllowed||submitting||value.binding;
 $('bind').textContent=submitting||value.binding?'正在连接…':value.state==='pending'?'继续连接':'连接电脑';
 $('identity').hidden=true;
 $('identity').textContent='';
 $('platform-login').hidden=!localAccountVisible||value.state!=='online'||held;
 $('account-safety').hidden=!accountSafetyAvailable;
 if(accountSafetyAvailable)refreshAccounts();
 $('refresh').hidden=!['pending','offline','error','revoked','stopped'].includes(value.state);
 const steps=$('setup-steps'),previousState=lastState;
 const animateHandoff=!localWorkspace&&!held&&value.state==='online'&&previousState&&previousState!=='online'&&!steps.hidden&&window.gsap&&!matchMedia('(prefers-reduced-motion: reduce)').matches;
 if(window.gsap){window.gsap.killTweensOf(steps);if(!animateHandoff)window.gsap.set(steps,{clearProps:'opacity,visibility,transform'});}
 steps.hidden=localWorkspace||!pairingAllowed||!['unbound','pending','binding'].includes(value.state)&&!animateHandoff;
 updateSetupStep(value.state);
 animateState(value.state);animateEntrance();
 if(value.state==='online'&&!held&&previousState&&previousState!=='online'&&window.gsap&&!matchMedia('(prefers-reduced-motion: reduce)').matches){
  const timeline=window.gsap.timeline({defaults:{ease:'power2.out'}});
  if(animateHandoff)timeline.to(steps,{autoAlpha:0,y:-8,duration:.2,onComplete:()=>{if(currentStatus==='online'){steps.hidden=true;window.gsap.set(steps,{clearProps:'opacity,visibility,transform'});}}},0);
  timeline.fromTo('#connection-panel',{scale:.992},{scale:1,duration:.28,clearProps:'transform',overwrite:'auto'},0)
   .fromTo('#platform-login',{autoAlpha:0,y:11},{autoAlpha:1,y:0,duration:.36,clearProps:'all',overwrite:'auto'},.06)
   .fromTo('.local-login-art',{autoAlpha:0,scale:.88},{autoAlpha:1,scale:1,duration:.3,clearProps:'all',overwrite:'auto'},.16);
 }
}
async function refresh(){
 if(reading||submitting)return;reading=true;
 try{const value=await api('assistant_status');render(value);if(!['unbound','pending','binding'].includes(value.state))clearError();else if(pairingError)showError(pairingError);else clearError();}
 catch(e){const disconnected=e instanceof TypeError;render({state:disconnected?'stopped':'error'});showError(disconnected?'本地助手页面无法连接本机服务，扫码结果尚未核实。':e.message);}
 finally{reading=false;}
}
$('pair-form').addEventListener('submit',async e=>{
 e.preventDefault();
 if(submitting)return;
 const action=currentStatus==='pending'?'assistant_replace_pair':'assistant_bind';
 const code=$('pair-code').value.trim();
 submitting=true;
 clearError();
 render({state:'binding',binding:true});
 try{
  render(await api(action,{code}));
  $('pair-code').value='';
 }catch(error){showError(error.message,true);}
 finally{submitting=false;await refresh();}
});
$('pair-code').addEventListener('input',()=>{clearError();updateSetupStep(currentStatus);});
$('refresh').addEventListener('click',refresh);refresh();setInterval(refresh,3000);



$('assistant-login')?.addEventListener('click',async()=>{const id=$('assistant-account').value;$('assistant-login').disabled=true;$('assistant-qr').hidden=false;$('assistant-qr-placeholder').hidden=false;$('assistant-qr-image').hidden=true;$('assistant-qr-state').textContent='正在准备二维码…';try{const value=await api(id?'assistant_account_login':'assistant_new_account_login',id?{account_id:id}:{});loginJob=value.login_job;pollLogin(loginJob);}catch(e){$('assistant-qr-state').textContent=e.message;}finally{$('assistant-login').disabled=false;}});
$('assistant-qr-close')?.addEventListener('click',()=>{loginJob='';$('assistant-qr').hidden=true;$('assistant-qr-image').hidden=true;refreshAccounts();});

$('assistant-account')?.addEventListener('change',syncAccountSelection);

$('assistant-delete')?.addEventListener('click',async()=>{const id=$('assistant-account').value;if(!id)return;if(!confirm('确定删除这个本机平台账号吗？本机登录凭据和缓存会清除；客户、评分、草稿与安全记录保留。正在运行的任务需先停止。'))return;$('assistant-delete').disabled=true;try{await api('assistant_account_delete',{account_id:id});await refreshAccounts();$('account-state').textContent='账号已删除；本机登录凭据已清除。';}catch(e){$('account-state').textContent=e.message;}finally{$('assistant-delete').disabled=false;}});
$('safety-account')?.addEventListener('change',refreshSafety);
$('safety-phone')?.addEventListener('click',()=>recordSafety('phone_verification'));
$('safety-logout')?.addEventListener('click',()=>recordSafety('unexpected_logout'));
$('safety-review')?.addEventListener('click',()=>recordSafety('review_completed'));
