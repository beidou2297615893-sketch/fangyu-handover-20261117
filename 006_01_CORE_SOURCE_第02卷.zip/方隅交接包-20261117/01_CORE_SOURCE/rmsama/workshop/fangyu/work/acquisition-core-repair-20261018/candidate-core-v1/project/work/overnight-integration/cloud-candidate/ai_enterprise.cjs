/* Atomic enterprise ledger/cache, using the same real CloudBase transaction as workspace auth. */
const crypto = require('node:crypto');
const {AiError, defaults, safeConfig, saveConfig, normalizeInput, prompt, validateOutput, validateIntentBatchSafe, tariff, usageOf,
  actualMicro, reservationMicro, dayOf, hash, RULES_VERSION, MODELS, OPENAI_MODELS,
  reasoningEffort, apiKeyFor, effectiveRulesVersion} = require('./ai_contract.cjs');
const {createProvider, ProviderError} = require('./ai_provider.cjs');
const OPERATIONS = new Set(['ai_config_read', 'ai_config_save', 'ai_profile', 'keyword_suggest', 'intent_analyze']);
const COLLECTIONS = {budget: 'fangyu_ai_budget', ledger: 'fangyu_ai_ledger', cache: 'fangyu_ai_cache'};
const microsToCny = n => n / 1000000;
function usageTotals(previous, usage, unknown, now, costMicro = 0) {
  const totals = previous || {tracking_started_at: now, known_requests: 0, unknown_requests: 0,
    prompt_tokens: 0, completion_tokens: 0, total_tokens: 0, confirmed_cost_micro: 0};
  if (unknown) return {...totals, unknown_requests: totals.unknown_requests + 1};
  if (!usage) return totals;
  return {...totals, known_requests: totals.known_requests + 1,
    prompt_tokens: totals.prompt_tokens + usage.prompt_tokens,
    completion_tokens: totals.completion_tokens + usage.completion_tokens,
    total_tokens: totals.total_tokens + usage.prompt_tokens + usage.completion_tokens,
    confirmed_cost_micro: totals.confirmed_cost_micro + costMicro};
}
function usageSummary(totals) {
  const {confirmed_cost_micro, ...visible} = totals;
  return {...visible, confirmed_cost_cny: microsToCny(confirmed_cost_micro),
    has_unknown_billing: totals.unknown_requests > 0};
}
function employeeConfig(config) {
  const {daily_budget_cny, usd_cny_rate, price_version, price_source, last_save_id, intent_policy, ...visible} = safeConfig(config);
  return visible;
}
function analysisForRole(data, isAdmin) {
  if (isAdmin) return data;
  const {billing, budget, validation_issue, ...visible} = data;
  return visible;
}
function budgetMetadata(value, config, now) {
  const limit = Math.round(config.daily_budget_cny * 1000000);
  const spent = value?.spent_micro || 0, reserved = value?.reserved_micro || 0;
  return {day: dayOf(now), limit_cny: microsToCny(limit), spent_cny: microsToCny(spent),
    reserved_cny: microsToCny(reserved), remaining_cny: microsToCny(Math.max(0, limit - spent - reserved))};
}
function repoFor(transaction, companyId) {
  if (!transaction?.collection) throw new AiError('AI_TRANSACTION_UNAVAILABLE', '企业 AI 事务存储尚未配置', 503);
  const ref = (type, key) => transaction.collection(COLLECTIONS[type]).doc(hash(`${companyId}\n${key}`));
  return {
    get: async (type, key) => {
      const snapshot = await ref(type, key).get();
      const value = Array.isArray(snapshot.data) ? snapshot.data[0] : snapshot.data;
      if (value && value.companyId !== companyId) throw new AiError('AI_TENANT_MISMATCH', '企业 AI 隔离检查失败', 403);
      if (!value) return null;
      const {_id, ...document} = value;
      return document;
    },
    set: (type, key, value) => {
      const {_id, ...document} = value;
      return ref(type, key).set({...document, companyId});
    }
  };
}
function createEnterpriseAi({store, companyId, clock = Date.now, provider = createProvider(), retryDelay = ms => new Promise(r => setTimeout(r, ms)),
  requestTimeoutMs = 45000, deadlineClock = () => performance.now()}) {
  if (!Number.isFinite(requestTimeoutMs) || requestTimeoutMs < 1 || requestTimeoutMs > 45000) throw new TypeError('AI request timeout must be between 1 and 45000 ms');
  function transact(identity, callback, requireAuth = true) {
    return store.transaction(async (state, transaction) => {
      if (!state || state.companyId !== companyId) throw new AiError('AI_TENANT_MISMATCH', '企业 AI 隔离检查失败', 403);
      let user;
      if (requireAuth) {
        const now = Math.floor(clock() / 1000);
        const session = state.sessions?.find(s => s.digest === identity.sessionDigest && s.username === identity.username && s.expires > now);
        user = session && state.users?.find(u => u.username === identity.username && !u.disabled);
        if (!user) throw new AiError('AI_AUTH_REQUIRED', '请重新登录', 401);
        if (identity.adminOnly && user.role !== 'admin') throw new AiError('AI_ADMIN_REQUIRED', '需要管理员权限', 403);
      }
      const next = structuredClone(state);
      const result = await callback(next, repoFor(transaction, companyId), user);
      return {state: next, result};
    });
  }
  async function configAction(payload, identity) {
    identity = {...identity, adminOnly: payload.operation !== 'ai_profile' || payload.connectivity_check === true};
    return transact(identity, async (state, repo, user) => {
      let config = {...defaults(), ...state.enterpriseAi};
      // Read every document before writing: CloudBase may replay the transaction callback.
      const budget = await repo.get('budget', dayOf(clock()));
      if (payload.operation === 'ai_config_save') {
        if (payload.request_id !== undefined &&
            (typeof payload.request_id !== 'string' ||
              !/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(payload.request_id)))
          throw new AiError('AI_INVALID_INPUT', '配置保存请求标识格式不正确');
        if (payload.expected_revision !== undefined &&
            (!Number.isSafeInteger(payload.expected_revision) || payload.expected_revision < 0))
          throw new AiError('AI_INVALID_INPUT', 'AI 配置版本格式不正确');
        if (payload.expected_revision !== undefined && payload.expected_revision !== config.revision)
          throw new AiError('AI_CONFIG_CHANGED', '企业 AI 配置已更新，请刷新后再试', 409);
        config = saveConfig(config, payload);
        state.enterpriseAi = config;
        state.audit.push({user: identity.username, operation: 'ai_config_save', time: Math.floor(clock() / 1000)});
        state.audit = state.audit.slice(-300);
      }
      if (user.role !== 'admin') return {config: employeeConfig(config)};
      return {config: safeConfig(config), budget: budgetMetadata(budget, config, clock()),
        usage: {today: usageSummary(budget?.usage_totals || usageTotals(null, null, false, clock())),
          cumulative: usageSummary(state.aiUsageTotals || usageTotals(null, null, false, clock())),
          coverage: 'since_tracking_start'}};
    });
  }
  async function reserve(operation, input, identity, expectedRevision, expectedRulesVersion) {
    const requestId = crypto.randomUUID();
    return transact(identity, async (state, repo, user) => {
      const config = {...defaults(), ...state.enterpriseAi};
       if (expectedRevision !== undefined) {
         if (!Number.isSafeInteger(expectedRevision) || expectedRevision < 0)
           throw new AiError('AI_INVALID_INPUT', 'AI 配置版本格式不正确');
         if (expectedRevision !== config.revision)
           throw new AiError('AI_CONFIG_CHANGED', '企业 AI 配置已更新，请刷新后再试', 409);
       }
       // Optional for older clients. When supplied, compare the effective
       // server contract and enterprise policy before cache or budget work.
       if (expectedRulesVersion !== undefined) {
         if (typeof expectedRulesVersion !== 'string' || !expectedRulesVersion || expectedRulesVersion.length > 256)
           throw new AiError('AI_INVALID_INPUT', 'AI 规则版本格式不正确');
         if (expectedRulesVersion !== effectiveRulesVersion(config))
           throw new AiError('AI_CONFIG_CHANGED', '企业 AI 规则已更新，请刷新后再试', 409);
       }
       if (!['openai', 'deepseek'].includes(config.provider))
         throw new AiError('AI_INVALID_INPUT', '企业 AI 服务商配置无效，请管理员重新保存', 503);
       const selectedProvider = config.provider;
       const catalog = selectedProvider === 'openai' ? OPENAI_MODELS : MODELS;
       // Never replace an invalid saved selection with a default, especially a dearer model.
       if (!Object.hasOwn(catalog, config.model))
         throw new AiError('AI_UNPRICED_MODEL', '企业 AI 模型配置无效，请管理员重新保存', 503);
       const selectedModel = config.model;
       if (selectedProvider === 'openai' && config.reasoning_effort != null &&
           !catalog[selectedModel].efforts.includes(config.reasoning_effort))
         throw new AiError('AI_INVALID_INPUT', '企业 AI 推理档位配置无效，请管理员重新保存', 503);
       const selectedEffort = selectedProvider === 'openai' ? reasoningEffort(config, selectedModel) : null;
       const selectedKey = apiKeyFor(config, selectedProvider);
       if (!config.enabled || !selectedKey) throw new AiError('AI_NOT_CONFIGURED', '请联系管理员启用企业 AI', 503);
       const now = clock(), day = dayOf(now), price = tariff(selectedModel, now, config);
       const contextHash = hash(JSON.stringify({companyId, operation, provider: selectedProvider, model: selectedModel,
         reasoning_effort: selectedEffort, usd_cny_rate: config.usd_cny_rate, rules_version: effectiveRulesVersion(config),
        schema_version: RULES_VERSION, revision: config.revision, input}));
      const cache = await repo.get('cache', contextHash);
      const budget = await repo.get('budget', day) || {day, spent_micro: 0, reserved_micro: 0, request_count: 0};
      if (cache?.status === 'ready' && cache.expires_at > now) {
         return {cached: true, isAdmin: user.role === 'admin', output: cache.output, provider: selectedProvider, model: cache.actual_model || selectedModel,
           configured_model: selectedModel, reasoning_effort: selectedEffort, rules_version: effectiveRulesVersion(config),
          budget: budgetMetadata(budget, config, now)};
      }
      if (cache?.status === 'in_flight' && cache.expires_at > now) {
        throw new AiError('AI_IN_PROGRESS', '同一内容正在分析，请稍后读取', 409);
      }
      const messages = prompt(operation, input, config);
      const maxTokens = operation === 'keyword_suggest' ? Math.min(16384, Math.max(2048, input.count * 128)) : Math.min(16384, 1024 + input.comments.length * 256);
       const reservation = reservationMicro(messages, maxTokens, selectedModel, config);
      const limit = Math.round(config.daily_budget_cny * 1000000);
      if (budget.spent_micro + budget.reserved_micro + reservation.micro > limit) {
        throw new AiError('AI_DAILY_BUDGET', '企业今日 AI 预算不足，请明日再试或由管理员调整预算', 429);
      }
      const ledger = {request_id: requestId, operation, day, username: identity.username, context_hash: contextHash,
         provider: selectedProvider, model: selectedModel, configured_model: selectedModel, reasoning_effort: selectedEffort,
         rules_version: effectiveRulesVersion(config), schema_version: RULES_VERSION,
         price_version: price.price_version, price_window: price.window, usd_cny_rate: price.usd_cny_rate || null,
         price_per_million: {hit: price.hit, miss: price.miss, write: price.write || price.miss, output: price.output}, reserved_micro: reservation.micro,
        prompt_bound: reservation.prompt_bound, max_tokens: maxTokens, status: 'reserved', created_at: now, attempts: []};
      await repo.set('budget', day, {...budget, reserved_micro: budget.reserved_micro + reservation.micro, request_count: budget.request_count + 1});
      await repo.set('ledger', requestId, ledger);
       await repo.set('cache', contextHash, {status: 'in_flight', request_id: requestId, provider: selectedProvider,
         model: selectedModel, rules_version: effectiveRulesVersion(config), expires_at: now + 120000});
       return {requestId, day, contextHash, apiKey: selectedKey, provider: selectedProvider, model: selectedModel,
         isAdmin: user.role === 'admin',
         reasoningEffort: selectedEffort, config, messages, maxTokens, price, reservation};
    });
  }
  async function markAttempt(plan, identity, attempt) {
    return transact(identity, async (_state, repo) => {
      const ledger = await repo.get('ledger', plan.requestId);
      if (!ledger || ledger.status !== 'reserved') throw new AiError('AI_LEDGER_CONFLICT', 'AI 请求状态异常，请稍后再试', 503);
      await repo.set('ledger', plan.requestId, {...ledger, attempts: [...ledger.attempts, {attempt, started_at: clock()}]});
    });
  }
  async function settle(plan, identity, {usage = null, output = null, errorCode = '', knownUnbilled = false, httpStatus = 0, validationIssue = null}) {
    // Settlement survives logout/revocation so a completed bill can never lose its accounting.
    return transact(identity, async (state, repo) => {
      const ledger = await repo.get('ledger', plan.requestId);
      const budget = await repo.get('budget', plan.day);
      const cache = await repo.get('cache', plan.contextHash);
      if (!ledger || !budget) throw new AiError('AI_LEDGER_CONFLICT', 'AI 用量记录暂时无法核对', 503);
      if (ledger.status !== 'reserved') return ledger;
      const actual = usage ? actualMicro(usage, plan.price) : null;
      // Usage outside our token bound indicates a changed provider contract; keep the full
      // reservation and record the overrun rather than silently understating consumption.
      const withinBound = usage && usage.prompt_tokens <= plan.reservation.prompt_bound && usage.completion_tokens <= plan.maxTokens;
      const unknown = !knownUnbilled && (!usage || !withinBound);
      const status = unknown ? 'billing_unknown' : knownUnbilled ? 'unbilled' : output ? 'settled' : 'invalid_output';
      const updated = {...ledger, status, completed_at: clock(), usage, actual_cost_micro: actual,
        error_code: errorCode || (unknown ? 'AI_BILLING_UNKNOWN' : ''), http_status: httpStatus,
        validation_issue: validationIssue,
        reservation_retained: !!unknown};
      if (!unknown) await repo.set('budget', plan.day, {...budget,
        reserved_micro: Math.max(0, budget.reserved_micro - ledger.reserved_micro), spent_micro: budget.spent_micro + (actual || 0),
        usage_totals: usageTotals(budget.usage_totals, usage, false, clock(), actual || 0)});
      // A verified overrun is still a known liability in addition to the retained reserve.
      if (usage && !withinBound) await repo.set('budget', plan.day, {...budget,
        spent_micro: budget.spent_micro + Math.max(0, actual - ledger.reserved_micro),
        usage_totals: usageTotals(budget.usage_totals, null, true, clock())});
      if (unknown && (!usage || withinBound)) await repo.set('budget', plan.day, {...budget,
        usage_totals: usageTotals(budget.usage_totals, null, true, clock())});
      state.aiUsageTotals = usageTotals(state.aiUsageTotals, unknown ? null : usage, unknown, clock(), unknown ? 0 : actual || 0);
      await repo.set('ledger', plan.requestId, updated);
      if (cache?.request_id === plan.requestId) await repo.set('cache', plan.contextHash, output && !unknown
         ? {status: 'ready', request_id: plan.requestId, output, provider: plan.provider, model: plan.model,
             actual_model: usage?.response_model || plan.model,
            rules_version: effectiveRulesVersion(plan.config), schema_version: RULES_VERSION, expires_at: clock() + 24 * 3600000}
        : {status: 'failed', request_id: plan.requestId, error_code: updated.error_code, expires_at: clock()});
      return updated;
    }, false);
  }
  async function handle(payload, identity) {
    // The same monotonic deadline includes reservation, attempt bookkeeping and
    // a possible 429 backoff; a retry never receives a fresh 45-second timer.
    const deadline = deadlineClock() + requestTimeoutMs;
    const remaining = () => Math.max(0, Math.floor(deadline - deadlineClock()));
    let plan;
    try {
      if (payload.operation.startsWith('ai_config_') || payload.operation === 'ai_profile') {
        if (payload.operation === 'ai_profile' && payload.connectivity_check !== undefined &&
            typeof payload.connectivity_check !== 'boolean')
          throw new AiError('AI_INVALID_INPUT', '连通性检查参数无效');
        const profile = await configAction(payload, identity);
        if (payload.operation !== 'ai_profile' || payload.connectivity_check !== true)
          return {status: 200, data: profile};
        // Authorization is checked by the CloudBase transaction above. Never
        // make a network call in a transaction callback, which may be replayed.
        let observed;
        try { observed = await provider.checkConnectivity?.(); } catch {}
        const reachability = ['reachable','unreachable','timeout'].includes(observed?.reachability)
          ? observed.reachability : 'unreachable';
        const status = Number.isInteger(observed?.http_status) && observed.http_status >= 100 && observed.http_status <= 599
          ? observed.http_status : 0;
        const allowedCauses = new Set(['ENOTFOUND','EAI_AGAIN','ETIMEDOUT','ECONNREFUSED','ECONNRESET',
          'ENETUNREACH','EHOSTUNREACH','UND_ERR_CONNECT_TIMEOUT','CERT_HAS_EXPIRED',
          'UNABLE_TO_VERIFY_LEAF_SIGNATURE','TIMEOUT','BODY_LIMIT','NETWORK_OTHER']);
        const suppliedCode = observed?.error?.cause?.code;
        const causeCode = allowedCauses.has(suppliedCode) ? suppliedCode : 'NETWORK_OTHER';
        const connectivity = {reachability, http_status:status,
          error:reachability === 'reachable' && observed?.error == null ? null : {cause:{code:causeCode}}};
        // A session revoked during the probe must not receive the admin result.
        await transact({...identity, adminOnly:true}, async () => null);
        return {status:200, data:{...profile, connectivity}};
      }
      const input = normalizeInput(payload.operation, payload);
       plan = await reserve(payload.operation, input, identity, payload.expected_revision, payload.expected_rules_version);
      if (plan.cached) return {status: 200, data: analysisForRole({...plan.output, count: plan.output.keywords?.length || plan.output.results?.length,
         source: 'cloud_ai', provider: plan.provider, model: plan.model, configured_model: plan.configured_model,
         reasoning_effort: plan.reasoning_effort, rules_version: plan.rules_version, cache_hit: true,
        billing: {status: 'cache_hit', actual_cost_cny: 0}, budget: plan.budget}, plan.isAdmin)};
      let response, providerError;
      for (let attempt = 1; attempt <= 2; attempt++) {
        if (!remaining()) { providerError = new ProviderError('AI_PROVIDER_TIMEOUT', {knownUnbilled: true}); break; }
        await markAttempt(plan, identity, attempt);
        const timeoutMs = remaining();
        if (!timeoutMs) { providerError = new ProviderError('AI_PROVIDER_TIMEOUT', {knownUnbilled: true}); break; }
        try {
           response = await provider({provider: plan.provider, apiKey: plan.apiKey, model: plan.model,
             reasoningEffort: plan.reasoningEffort, messages: plan.messages,
            maxTokens: plan.maxTokens, tenantId: hash(companyId), timeoutMs});
          providerError = null; break;
        } catch (error) {
          providerError = error instanceof ProviderError ? error : new ProviderError('AI_PROVIDER_UNAVAILABLE');
          if (!(providerError.knownUnbilled && providerError.retryable && attempt < 2)) break;
          if (remaining() <= 250) { providerError = new ProviderError('AI_PROVIDER_TIMEOUT', {knownUnbilled: true}); break; }
          await retryDelay(250);
        }
      }
      if (providerError) {
        const ledger = await settle(plan, identity, {errorCode: providerError.code, knownUnbilled: providerError.knownUnbilled, httpStatus: providerError.httpStatus});
        const isAdmin = await transact(identity, async (_state, _repo, user) => user.role === 'admin');
         const providerLabel = plan.provider === 'openai' ? 'OpenAI' : 'DeepSeek';
         const message = providerError.code === 'AI_PROVIDER_BALANCE' ? `企业 ${providerLabel} API 余额不足，请管理员检查后点继续分析`
           : providerError.code === 'AI_PROVIDER_AUTH' ? `企业 ${providerLabel} API 密钥无效，请管理员检查后点继续分析`
          : '企业 AI 暂时不可用，评论保持待分析，请稍后再试';
         return {status: 502, data: analysisForRole({code: providerError.code, error: message, ai_status: 'pending',
           provider: plan.provider, configured_model: plan.model, reasoning_effort: plan.reasoningEffort,
          billing: {status: ledger.status, reservation_retained: ledger.reservation_retained, request_id: plan.requestId}}, isAdmin)};
      }
       const usage = usageOf(response, plan.model);
      let output, validationError;
      try {
        if (!usage) throw new AiError('AI_BILLING_UNKNOWN', 'AI 用量返回不完整，暂未完成分析', 502);
        const choice = response?.choices?.[0];
        if (choice?.finish_reason !== 'stop' || typeof choice?.message?.content !== 'string') {
          const error = new AiError('AI_INVALID_OUTPUT', 'AI 返回不完整，暂未完成分析', 502);
          error.validation_issue = choice?.finish_reason !== 'stop' ? 'response_incomplete' : 'response_content_type';
          throw error;
        }
        let parsed;
        try { parsed = JSON.parse(choice.message.content); } catch {
          const error = new AiError('AI_INVALID_OUTPUT', 'AI 返回格式不正确，暂未完成分析', 502);
          error.validation_issue = 'response_json_parse'; throw error;
        }
         const secrets = [plan.apiKey, apiKeyFor(plan.config, 'deepseek'), apiKeyFor(plan.config, 'openai')];
         output = payload.operation === 'intent_analyze'
           ? validateIntentBatchSafe(parsed, input, secrets)
           : validateOutput(payload.operation, parsed, input, secrets);
      } catch (error) { validationError = error instanceof AiError ? error : new AiError('AI_INVALID_OUTPUT', 'AI 返回内容未通过校验', 502); }
      const ledger = await settle(plan, identity, {usage, output, errorCode: validationError?.code || '', validationIssue: validationError?.validation_issue || null});
      const isAdmin = await transact(identity, async (_state, _repo, user) => user.role === 'admin');
      if (validationError || ledger.reservation_retained) return {status: 502, data: analysisForRole({code: validationError?.code || 'AI_BILLING_UNKNOWN',
        error: validationError?.message || 'AI 用量无法核对，暂未完成分析', ai_status: 'pending',
         validation_issue: validationError?.validation_issue || null,
         provider: plan.provider, model: usage?.response_model || null, configured_model: plan.model,
         reasoning_effort: plan.reasoningEffort,
        billing: {status: ledger.status, reservation_retained: ledger.reservation_retained, request_id: plan.requestId}}, isAdmin)};
      // Recheck the session before returning private analysis after a long network call.
      return {status: 200, data: analysisForRole({...output, count: output.keywords?.length || output.results?.length, source: 'cloud_ai',
         provider: plan.provider, model: usage.response_model || plan.model, configured_model: plan.model,
         reasoning_effort: plan.reasoningEffort, rules_version: effectiveRulesVersion(plan.config), cache_hit: false,
        billing: {status: ledger.status, request_id: plan.requestId, actual_cost_cny: microsToCny(ledger.actual_cost_micro),
          usage: ledger.usage, price_version: ledger.price_version, price_window: ledger.price_window}}, isAdmin)};
    } catch (error) {
      // Errors before/after a network call are safe metadata only. No raw exception text.
      const e = error instanceof AiError ? error : plan && !plan.cached
        ? new AiError('AI_LEDGER_CONFLICT', '企业 AI 账本状态待核对，请管理员检查', 503)
        : new AiError('AI_SERVICE_UNAVAILABLE', '企业 AI 服务暂时不可用，请稍后再试', 503);
       return {status: e.status, data: {code: e.code, error: e.message, ai_status: 'pending',
         ...(plan && !plan.cached ? {provider: plan.provider, configured_model: plan.model,
           reasoning_effort: plan.reasoningEffort} : {})}};
    }
  }
  return {handle};
}
module.exports = {createEnterpriseAi, OPERATIONS, COLLECTIONS, budgetMetadata, repoFor};
