# 示例头像资产来源

生成日期：2026-10-16（北京时间）。方式：内置 imagegen，4 个独立生成调用（3 位示例成年人、1 只金毛）；未使用真实平台用户头像或第三方版权照片。未暴露可核验的模型版本。工具实际输出均为 1254×1254 方图，保留原始分辨率。

用途：方隅浅青 UI 演示，分别对应小雨、陈先生、芝士奶盖、糯米团子。三张人物图均为虚构成年人物的真实摄影风格头像。已实际查看保存原图：单人方图、浅灰背景、脸部与肩颈自然，陈先生眼镜正常，两位女性发型及面部可区分；金毛耳朵、眼睛、口鼻和胸前毛发自然；未见明显结构错误。可由界面 CSS 做圆裁切，文件本身保留方图。没有用照片拼图、Python改图、抠图或重新压缩；通过 Copy-Item 原样复制，源文件保留。

参考 UI 原图：`C:/积木软件工坊/项目/方隅公寓客户版/outputs/新UI第三轮（完整修订）/03-意向回复.png`，已查看；仅参考头像用途与整体简洁风格，不声称生成了原图中同一真实人物。

## portrait-woman-1.png

生成原图：`C:/Users/rmsama/.codex/generated_images/01a1406d-d5a5-7670-91ce-ec9e7e4379df/exec-9fdfc11c-cd76-4b36-aae2-1501b4557eaf.png`

提示词：

Create exactly ONE standalone square realistic photographic profile avatar for a fictional demo person named Xiaoyu, an adult Chinese woman about 28 years old. Head and upper shoulders portrait, looking directly at camera, natural warm subtle smile, long dark brown lightly wavy hair, simple ivory blouse. Soft diffuse daylight studio photography, pale neutral light gray background, realistic skin texture, clean natural face, ordinary modern person, tasteful and approachable. Center the entire head, leave generous space above hair and around both shoulders so a circle crop will include all face and hair; clear anatomically correct neck and shoulders. Camera straight on at eye level, face centered, tight head-and-shoulders framing. One person only, no collage, no grids, no split panels, no text, no watermark, no UI, no symbols, no circular frame. Single independent 512x512 square PNG style image intended for a small circular avatar in a pale teal apartment customer dashboard.

## portrait-man-1.png

生成原图：`C:/Users/rmsama/.codex/generated_images/01a1406d-d5a5-7670-91ce-ec9e7e4379df/exec-f983c63a-5a5c-4125-8aff-beeee7ee4036.png`

提示词：

Create exactly ONE standalone square realistic photographic profile avatar for a fictional demo person named Mr Chen, an adult Chinese man about 35 years old, wearing thin dark rectangular eyeglasses. Head and upper shoulders portrait, looking directly at camera, friendly composed subtle smile, short neat black hair, clean shaven, dark navy casual blazer over pale blue shirt without tie. Soft diffuse daylight studio photography, pale neutral light gray background, realistic skin texture, ordinary modern person, tasteful and approachable. Center the entire head, leave generous space above hair and around both shoulders so a circle crop will include all face and hair; clear anatomically correct neck and shoulders, symmetrical properly aligned eyeglasses. Camera straight on at eye level, face centered, tight head-and-shoulders framing. One person only, no collage, no grids, no split panels, no text, no watermark, no UI, no symbols, no circular frame. Single independent 512x512 square PNG style image intended for a small circular avatar in a pale teal apartment customer dashboard.

## portrait-woman-2.png

生成原图：`C:/Users/rmsama/.codex/generated_images/01a1406d-d5a5-7670-91ce-ec9e7e4379df/exec-7e66b026-ed6c-4c3a-b809-27db4f9262ab.png`

提示词：

Create exactly ONE standalone square realistic photographic profile avatar for a fictional demo person nicknamed Zhishi Naigai, an adult Chinese woman about 25 years old. She must have a clearly different facial identity from a typical long-haired oval-face portrait: short dark brown chin-length bob haircut with natural side part, softly rounded face, smiling eyes, natural friendly subtle smile, simple pale peach casual top. Head and upper shoulders portrait, looking directly at camera. Soft diffuse daylight studio photography, pale neutral light gray background, realistic skin texture, ordinary modern person, tasteful and approachable. Center the entire head, leave generous space above hair and around both shoulders so a circle crop will include all face and hair; clear anatomically correct neck and shoulders. Camera straight on at eye level, face centered, tight head-and-shoulders framing. One person only, no collage, no grids, no split panels, no text, no watermark, no UI, no symbols, no circular frame. Single independent 512x512 square PNG style image intended for a small circular avatar in a pale teal apartment customer dashboard.

## portrait-dog.png

生成原图：`C:/Users/rmsama/.codex/generated_images/01a1406d-d5a5-7670-91ce-ec9e7e4379df/exec-b724ccd0-64be-46ec-8fec-5bdc9cedf1b9.png`

提示词：

Create exactly ONE standalone square realistic photographic profile avatar of a friendly adult golden retriever dog, fictional demo pet nicknamed Nuomi Tuanzi. Front-facing symmetrical head and a little upper chest, golden cream fur, natural dark eyes, relaxed happy expression with slightly open mouth, correctly formed dog nose and muzzle, no collar text. Pale neutral light gray softly blurred background, soft diffuse daylight photography, realistic detailed fur. Center full head with generous room around ears and above head so a circular UI avatar crop will keep the face and ears. One dog only, no humans, no other animals, no collage, no grid, no split panels, no text, no watermarks, no border, no UI, no circular frame. Single independent 512x512 square PNG style image for a small circular avatar in a pale teal apartment customer dashboard.



