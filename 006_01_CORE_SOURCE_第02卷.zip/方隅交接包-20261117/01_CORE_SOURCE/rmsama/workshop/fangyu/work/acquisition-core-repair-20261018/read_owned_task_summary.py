"""Read only owned task counters/reason codes; never read leads or credentials."""
from pathlib import Path
import json,sqlite3,re,hashlib,datetime
W=Path(__file__).resolve().parent;P=W.parents[1]
binding=json.loads((P/'work/ui-native-r57/state/production-workspace.json').read_text('utf-8-sig'))
database=Path(binding['data_dir'])/'workspace.sqlite3'
db=sqlite3.connect(database.as_uri()+'?mode=ro',uri=True)
db.execute('PRAGMA query_only=ON')
rows=db.execute("SELECT body FROM records WHERE entity='tasks' AND (json_extract(body,'$.cloud_owner')=? OR json_extract(body,'$.owner')=?) ORDER BY coalesce(json_extract(body,'$.last_run'),json_extract(body,'$.updated_at'),json_extract(body,'$.created_at')) DESC LIMIT 5",(binding['owner'],binding['owner'])).fetchall()
out=[]
for (body,) in rows:
 t=json.loads(body);summary=(t.get('last_result') or {}).get('summary') or {};pipe=t.get('pipeline') or {};msg=str(t.get('last_message') or '')
 safe={k:t.get(k) for k in ('id','platform','status','sequence_status','pause_reason','daily_limit','target_count','accumulated','exhausted','last_run','created_at')}
 safe['owner_matches_original_binding']=t.get('cloud_owner',t.get('owner'))==binding['owner']
 safe['keyword_count']=len(t.get('keywords') or [])
 safe['exclude_term_count']=len(t.get('excludes') or [])
 safe['comment_keyword_mode']=t.get('comment_keyword_mode')
 safe['summary']={k:summary.get(k) for k in ('stop_reason','can_continue','exhausted','read','filtered','imported','duplicates','batches') if k in summary}
 safe['last_batch']={k:(t.get('last_batch') or {}).get(k) for k in ('read','filtered','imported','duplicates','filter_reasons') if k in (t.get('last_batch') or {})}
 safe['pipeline']={k:pipe.get(k) for k in ('keyword_index','note_index','search_page','search_exhausted') if k in pipe}
 safe['pipeline_fields']=list(pipe)
 safe['cursor_present']=any(bool(pipe.get(k)) for k in ('comment_cursor','cursor','search_cursor'))
 safe['pipeline_digest']=hashlib.sha256(json.dumps(pipe,sort_keys=True).encode()).hexdigest()
 safe['last_message_signals']=[code for code,pattern in {
  'HTTP461':r'461','HTTP429':r'429','VERIFICATION':r'验证码|验证|captcha|verification',
  'LEASE':r'租约|lease','TIMEOUT':r'超时|timeout|timed.out','LOGIN':r'登录|login',
  'DAY_LIMIT':r'今日|每日|日上限|daily','TARGET':r'目标|target','MANUAL_PAUSE':r'手动|人工|任务已暂停',
  'ENTERPRISE_CONNECT':r'企业连接|云端|cloud|授权|许可','EMPTY':r'为空|无结果|empty',
  'CURSOR':r'游标|cursor','REVIEW':r'复核|review','PAGE':r'翻页|页码|page'
 }.items() if re.search(pattern,msg,re.I)]
 safe['message_sha256']=hashlib.sha256(msg.encode()).hexdigest()
 out.append(safe)
db.close()
result={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'original-binding owner latest 5 task metadata only','read_only':True,'leads_read':False,'vault_read':False,'tasks':out}
(W/'OWNED-TASK-SUMMARY.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2))
