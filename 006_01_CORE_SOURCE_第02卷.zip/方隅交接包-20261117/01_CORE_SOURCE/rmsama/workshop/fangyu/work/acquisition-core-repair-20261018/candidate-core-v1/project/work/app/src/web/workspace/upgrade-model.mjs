/* Product presentation only. Platform permissions and evidence remain server owned. */
/* Temporary, opt-in local routing diagnostics. Contains no record or identity data. */
export function traceUpgradeRoute(stage,view='',nonce=0,current=true){
  if(typeof location==='undefined'||typeof document==='undefined'||new URLSearchParams(location.search).get('route_debug')!=='1')return;
  const host=document.getElementById('workspace');if(!host)return;
  let history=[];try{history=JSON.parse(host.dataset.routeTrace||'[]');}catch{}
  history.push({stage,view:['contact','handoff','source'].includes(view)?view:'',nonce:Number.isSafeInteger(nonce)?nonce:0,current:current===true});
  host.dataset.routeTrace=JSON.stringify(history.slice(-96));
}
export const upgradePages = Object.freeze({
  overview:'工作总览',tasks:'采集任务',leads:'客户工作台',customers:'客户工作台',
  handoff:'资源部交接',devices:'平台账号',management:'管理中心',
  review:'审核回复',team:'团队账号',maintenance:'设备状态',
});
export function upgradeNavigation(page){return page==='customers'?'leads':page;}
export function confirmedCount(value){return Number.isSafeInteger(value)&&value>=0?value:null;}
export function overviewMetrics(result={}){
  const counts=result.counts||{};
  const definitions=[
    ['pending_contact','待联系',['pending_contact','uncontacted']],
    ['awaiting_response','待回应',['awaiting_response','waiting_response']],
    ['responded','已回应',['responded','customer_replied']],
    ['pending_handoff','待交接',['pending_handoff']],
    ['accepted','已接收',['accepted_current_authorized','accepted','handoff_accepted']],
  ];
  const draft=confirmedCount(counts.draft),ready=confirmedCount(counts.ready_to_deliver);
  return definitions.map(([key,label,aliases])=>({key,label,value:aliases.map(name=>confirmedCount(counts[name])).find(value=>value!==null)??(key==='pending_handoff'&&draft!==null&&ready!==null?draft+ready:null)}));
}
export function inventoryMetrics(result={}){const source=result.counts||{},workflow=overviewMetrics(result);return [{key:'comments',label:'已保存评论',value:confirmedCount(source.comments)},{key:'customers',label:'已归档客户',value:confirmedCount(source.customers)},{key:'high_intent_customers',label:'高意向客户',value:confirmedCount(source.high_intent_customers)},workflow[3],workflow[4]];}
export function safetyPresentation({accounts=[],tasks=[],collectionHeld=false,accountSnapshotKnown=false}={}){
  const review=accounts.find(account=>account.requires_review===true||['check_required','identity_mismatch','identity_unverified','duplicate_identity_remote'].includes(account.status));
  if(review)return {state:'review',tone:'warning',title:'账号待核实 · 采集已停止',detail:'先核对手机与本次操作结果，再检查平台账号。',accountId:review.id||''};
  const uncertain=tasks.find(task=>task.continuous?.status==='blocked'||task.continuous?.wait_reason==='account_review');
  if(uncertain)return {state:'blocked',tone:'warning',title:'采集已停止 · 断点已保留',detail:uncertain.continuous?.message||uncertain.last_message||'查看平台账号和任务记录后再继续。'};
  if(collectionHeld)return {state:'held',tone:'warning',title:'采集许可尚未确认',detail:'当前资料可查看，开始采集前请核对账号与设备。'};
  if(!accountSnapshotKnown||!accounts.length)return {state:'unconfirmed',tone:'neutral',title:'平台账号状态待核对',detail:'查看已连接账号，确认当前采集和回复身份。'};
  const login=accounts.find(account=>['login_required','logging_in','not_authenticated'].includes(account.status));
  if(login)return {state:'login',tone:'warning',title:'部分平台账号需要登录',detail:'已保存资料保留；请在平台账号中检查对应账号。',accountId:login.id||''};
  const running=tasks.some(task=>['queued','running','waiting'].includes(task.continuous?.status));
  return {state:running?'running':'idle',tone:'neutral',title:running?'采集任务正在运行':'当前没有正在运行的采集任务',detail:running?'查看任务进度与当前账号。':'可先处理已有客户，再按需要开始采集。'};
}
export function contactPresentation(person={}){
  if(person.uncertain_contact||person.contact_state==='unknown')return {key:'unknown',label:'发送待核对',tone:'warning'};
  if(person.incoming_reply_status==='observed')return {key:'responded',label:'客户已回应',tone:'positive'};
  if(person.contact_state==='sent')return {key:'sent',label:'系统记录已发送',tone:'info'};
  if(person.contact_state==='external_reported')return {key:'manual',label:'人工记录已联系',tone:'neutral'};
  if(person.contact_state==='copied')return {key:'copied',label:'已复制 · 未确认发送',tone:'neutral'};
  if(person.contact_state==='legacy_sent_unverified')return {key:'legacy',label:'历史联系待核对',tone:'warning'};
  return {key:'uncontacted',label:'未记录联系',tone:'neutral'};
}
export function handoffPresentation(item={}){
  const authorization=item.current_authorization?.state,historical=item.historical_resource_receipt_verified===true;
  if(authorization==='withdrawn')return {status:item.status||'unknown',label:(historical?'历史接收 · ':'')+'当前授权已撤回',tone:'warning'};
  if(authorization==='unavailable'||item.current_consent_valid===false)return {status:item.status||'unknown',label:(historical?'历史接收 · ':'')+'当前授权待核对',tone:'warning'};
  const received=item.resource_receipt_verified===true?(item.local_only?'本机授权接收人已确认':'接收已核验'):'接收记录待核验';
  const labels={draft:'待整理',ready:'待提交',ready_to_deliver:'待送达',submitted:'待接收',pending:'待接收',accepted:received,received,
    rejected:'已拒绝',needs_information:'待补充资料',duplicate_pending_review:'重复线索待核对',existing_customer_pending_review:'既有客户待核对',withdrawn:'已撤回',disputed:'归属争议',conflict:'归属待核对',following:'跟进中',closed:'已结束',settled:'已结算',cancelled:'已撤回'};
  const status=typeof item.status==='string'?item.status:'unknown';
  if(['accepted','received'].includes(status)&&item.current_consent_valid!==true)return {status,label:historical?'历史接收 · 当前授权待核对':'接收记录待核验',tone:'warning'};
  return {status,label:labels[status]||'状态待核对',tone:['accepted','received'].includes(status)?(item.resource_receipt_verified===true?'positive':'warning'):status==='settled'?'positive':['rejected','conflict','unknown'].includes(status)?'warning':'neutral'};
}
export const replyTones=Object.freeze({official:'官方顾问',friendly:'亲切顾问',partner:'合作中介'});
export function replyTemplate({tone='friendly',identity=''}={}){
  const real=String(identity).trim();
  if(!real||real.length>80||/[\r\n]/.test(real))throw Error('请填写你向客户说明的真实身份，最多80字。');
  if(!Object.hasOwn(replyTones,tone))throw Error('请选择可用的回复口吻。');
  const lead={official:`你好，我是${real}。看到你的租房需求，方便确认一下意向区域、预算和入住时间吗？我可以据此帮你核对合适的选择。`,
    friendly:`你好呀，我是${real}。看到你在找房，想先了解一下你更在意的区域、预算和入住时间，我们再一起看看适合的选择。`,
    partner:`你好，我是${real}。看到你的求租需求，方便补充区域、预算和入住时间吗？我会先核对匹配情况，再与你沟通下一步。`};
  return lead[tone];
}
export function voluntaryContactDraft({tone='friendly',identity='',recipient='',purpose='',noticeVersion=''}={}){
  const text=(value,label,max)=>{if(typeof value!=='string'||!value.trim()||value.length>max||/[\x00-\x1f\x7f]/.test(value))throw Error(`请填写${label}，最多${max}字。`);return value.trim();};
  if(!Object.hasOwn(replyTones,tone))throw Error('请选择可用的回复口吻。');
  const real=text(identity,'向客户说明的真实身份',80),receiver=text(recipient,'实际接收方',100),use=text(purpose,'客户知晓的具体用途',100),version=text(noticeVersion,'实际采用的告知版本',80);
  const opening={official:`谢谢你的回复，我是${real}。`,friendly:`谢谢回复呀，我是${real}。`,partner:`谢谢回复，我是${real}。`};
  return {notice_version:version,text:`${opening[tone]}为便于按你的租房需求核对房源，如果你同意，我会把你通过私信自愿提供的手机号或微信号转交给「${receiver}」，仅用于「${use}」。请不要在公开评论留下联系方式；也可以继续在平台沟通。你是否同意上述转交？`};
}
export function actualRoleLabel(user){return user?.role==='admin'?'管理员':user?.role==='operator'?'员工账号':'账号身份待核对';}
export function capabilityItems(result){return Array.isArray(result?.items)?result.items:[];}
export function explicitNeedCards(text=''){
  const original=String(text),direct=original.match(/(?:搬到|搬去|意向区域[：:]?|区域[：:]?)([\p{Script=Han}]{2,10})(?=[，。,\s]|$)/u),question=original.match(/(?:^|[，。,；;]\s*)(?:请问|想问(?:一下|下)?|问(?:一下|下)?)?([\p{Script=Han}]{2,10})(?=有(?:一|两|二|三|1|2|3)室(?:户)?|有房(?:源)?|附近(?:有|能)|一室户(?:有|可以))/u);
  const safe=match=>{if(!match)return null;const point=match.index+match[0].indexOf(match[1]);const start=Math.max(original.lastIndexOf('，',point),original.lastIndexOf(',',point),original.lastIndexOf('。',point),original.lastIndexOf('；',point))+1;const tail=original.slice(point).search(/[，。,；;]/u),end=tail<0?original.length:point+tail;const clause=original.slice(start,end);return /不|没|非|别|朋友|同事|别人|他|她|听说|看到|房东|原来|以前|除了/u.test(clause)?null:match;};
  // This card quotes an explicit customer request; it never changes AI region status.
  const districts='(?:黄浦|徐汇|长宁|静安|普陀|虹口|杨浦|闵行|宝山|嘉定|金山|松江|青浦|奉贤|崇明)(?:区)?|浦东(?:新区|区)?';
  const place=String.raw`(?:上海(?:市)?(?:(?:${districts}))?|(?:${districts})|(?:地铁)?(?:[1-9]\d?号线|[\p{Script=Han}]{2,12}站)(?:附近|周边)?)`;
  const demand=original.match(new RegExp(String.raw`(?:^|[，。,；;]\s*)(?:我(?:们)?|本人)?(?:想了解|想(?:在|去|到|租)?|(?:打算|计划|准备|考虑|需要)(?:在|去|到)?|求租|找房(?:在)?)(${place})(?=的?有?(?:(?:一|两|二|三|1|2|3)室(?:户)?|一居室|两居室|租(?:房|公寓|房子|住房|一|两|二|三|1|2|3)|找房|公寓|房源|房子|住房))`,'u'));
  const safeArea=match=>{
    if(!safe(match))return null;
    const point=match.index+match[0].indexOf(match[1]),start=Math.max(original.lastIndexOf('，',point),original.lastIndexOf(',',point),original.lastIndexOf('。',point),original.lastIndexOf('；',point))+1;
    const tail=original.slice(point).search(/[，。,；;]/u),end=tail<0?original.length:point+tail,clause=original.slice(start,end),before=original.slice(Math.max(0,start-80),start);
    if(/推荐|帖子|笔记|博主|中介|曾经|之前|原先|过去|当时|老家|住过|[“”"「」『』]/u.test(clause)
      ||/(?:朋友|同事|别人|他|她|房东|中介|博主|帖子)[^，。,；;\n]{0,8}(?:说|提到|写道|推荐)[，,]\s*$/u.test(before)
      ||/^(?:附近|周边|这里|那里|这边|那边|地铁(?:站)?(?:附近|周边)?|公交站(?:附近|周边)?|车站(?:附近|周边)?|区域|地区|城市|本地|当地|随便|随便哪里|都可以|不详|待定|未定|未确定|尚未确定)$/u.test(match[1]))return null;
    return match;
  };
  const area=safeArea(direct)||safeArea(demand)||safeArea(question),budget=safe(original.match(/预算\s*[约为是:：]?\s*([0-9]{3,6}(?:\s*[-–—~至]\s*[0-9]{3,6})?\s*(?:元|左右|以内|上下)?)/u));
  return [{key:'area',label:'原文地点',value:area?.[1]||'原文未明确',evidence:area?.[0].trim()||'',known:!!area},{key:'budget',label:'预算',value:budget?.[1].trim()||'原文未明确',evidence:budget?.[0]||'',known:!!budget}];
}
