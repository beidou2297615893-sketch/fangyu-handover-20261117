"""Explicit, tenant-scoped cloud sharing and user-configured keyword assistance.

No remote request runs at startup. Credentials use Windows DPAPI and are excluded
from UI responses. Cloud list sharing is an explicit user action, never a background upload.
"""
import base64
import ctypes
import json
import os
import re
import threading
import time
import hashlib
import secrets
from pathlib import Path
from urllib.parse import urlsplit
from urllib.request import Request, build_opener, HTTPRedirectHandler
from urllib.error import HTTPError, URLError


class IntegrationError(ValueError):
    pass


# Only authenticated AI operations may project this fixed server contract. Never
# accept arbitrary PRODUCT_ strings or provider error text as trusted review state.
PRODUCT_AI_ERROR_CODES = frozenset((
    'PRODUCT_AUTH_REQUIRED','PRODUCT_TENANT_INVALID','PRODUCT_TENANT_MISMATCH',
    'PRODUCT_STORAGE_UNAVAILABLE','PRODUCT_POLICY_INVALID','PRODUCT_SERVER_CONFIG_INVALID',
    'PRODUCT_EXPIRED','PRODUCT_FEATURE_DENIED','PRODUCT_PERIOD_REQUIRED','PRODUCT_PERIOD_INACTIVE',
    'PRODUCT_PERIOD_CONFLICT','PRODUCT_REQUEST_INVALID','PRODUCT_REQUEST_SCOPE','PRODUCT_REQUEST_CANCELLED',
    'PRODUCT_REQUEST_CONFLICT','PRODUCT_REQUEST_UNKNOWN','PRODUCT_REQUEST_RELEASED','PRODUCT_REQUEST_RESOLVED',
    'PRODUCT_ANALYSIS_LIMIT','PRODUCT_SETTLEMENT_SCOPE','PRODUCT_SETTLEMENT_CONFLICT'))


class EmployeeLoginRequired(IntegrationError):
    def __init__(self):
        super().__init__('管理员请打开自己的方隅管理后台；此工作台仅供员工使用')


def protect(data, decrypt=False):
    if os.name != 'nt':
        raise IntegrationError('本机密钥存储需要 Windows DPAPI')
    from ctypes import wintypes
    class Blob(ctypes.Structure):
        _fields_ = [('size', wintypes.DWORD), ('data', ctypes.POINTER(ctypes.c_byte))]
    raw = ctypes.create_string_buffer(data)
    source = Blob(len(data), ctypes.cast(raw, ctypes.POINTER(ctypes.c_byte)))
    result = Blob()
    api = ctypes.windll.crypt32.CryptUnprotectData if decrypt else ctypes.windll.crypt32.CryptProtectData
    api.argtypes = [ctypes.POINTER(Blob), ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(Blob)]
    api.restype = wintypes.BOOL
    if not api(ctypes.byref(source), None, None, None, None, 1, ctypes.byref(result)):
        raise IntegrationError('无法访问本机加密配置，请使用保存配置的 Windows 账号')
    try:
        return ctypes.string_at(result.data, result.size)
    finally:
        ctypes.windll.kernel32.LocalFree.argtypes = [ctypes.c_void_p]
        ctypes.windll.kernel32.LocalFree(ctypes.cast(result.data, ctypes.c_void_p))


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        raise IntegrationError('服务地址发生跳转，请填写最终 HTTPS 地址后重试')


def endpoint(value):
    value = str(value or '').strip().rstrip('/')
    if not value:
        return ''
    u = urlsplit(value)
    if u.scheme != 'https' or not u.hostname or u.username or u.password or u.query or u.fragment:
        raise IntegrationError('服务地址必须是无账号、无查询参数的 HTTPS 地址')
    if len(value) > 500:
        raise IntegrationError('服务地址过长')
    return value


def request_json(url, payload, token=''):
    headers = {'Content-Type': 'application/json', 'Accept': 'application/json'}
    if token:
        headers['Authorization'] = 'Bearer ' + token
    request = Request(url, data=json.dumps(payload, ensure_ascii=False).encode(), headers=headers, method='POST')
    try:
        timeout=70 if payload.get('operation') in ('keyword_suggest','intent_analyze') else 25
        with build_opener(NoRedirect()).open(request, timeout=timeout) as response:
            raw = response.read(2 * 1024 * 1024 + 1)
        if len(raw) > 2 * 1024 * 1024:
            raise IntegrationError('服务返回内容超过限制')
        result = json.loads(raw)
        if not isinstance(result, dict):
            raise IntegrationError('服务响应格式不正确')
        return result
    except HTTPError as e:
        if str(payload.get('operation','')).startswith('contact_'):
            try: body=json.loads(e.read(32768))
            except Exception: body={}
            contact_codes={'CONTACT_INVALID_INPUT','CONTACT_SECRET_REJECTED','CONTACT_INVALID_URL',
                'CONTACT_STORAGE_UNAVAILABLE','CONTACT_TENANT_MISMATCH','CONTACT_INVALID_CURSOR',
                'CONTACT_AUTH_REQUIRED','CONTACT_ADMIN_REQUIRED','CONTACT_EVENT_CONFLICT',
                'CONTACT_CUSTOMER_CONFLICT','CONTACT_STORAGE_CONFLICT','CONTACT_NOT_FOUND',
                'CONTACT_REVISION_CONFLICT','CONTACT_ORDER_CONFLICT','CONTACT_FORBIDDEN',
                'CONTACT_SENDER_UNCLAIMED'}
            code=body.get('code') if isinstance(body,dict) else None
            if isinstance(code,str) and code in contact_codes:
                error=IntegrationError('联系或成交记录未完成，请核对状态后重试')
                error.code=code
                raise error from None
        messages = {401: '云端账号或密钥无效，请重新登录或检查 API Key', 403: '当前账号没有权限', 409: '共享清单已被其他电脑更新，请重新读取后再提交', 423: '企业共享清单迁移中，本次未上传，请稍后重试', 429: '请求过于频繁，请稍后再试', 507: '企业共享清单已达当前部署容量；本次未上传，本机客户仍保留，请联系管理员扩容'}
        # Only a fixed safe error code is propagated; provider bodies/secrets are never logged.
        if payload.get('operation') in ('keyword_suggest','intent_analyze','ai_profile','ai_config_read','ai_config_save','ai_attempt_status',
                                      'intent_policy_read','intent_policy_publish','intent_policy_publish_status'):
            try:body=json.loads(e.read(32768))
            except Exception:body={}
            safe_codes={'AI_DAILY_BUDGET':'今日 AI 预算已用完，评论已保留待分析',
                        'AI_NOT_CONFIGURED':'请管理员配置企业 AI',
                        'AI_CONFIG_CHANGED':'企业 AI 配置已变化，请核对新模型后继续',
                        'AI_DISABLED':'企业 AI 已暂停，评论已保留待分析',
                        'AI_INVALID_OUTPUT':'AI 返回结果未通过校验，评论仍待分析',
                        'AI_BILLING_UNKNOWN':'上次 AI 费用待核实，暂未重新请求',
                        'AI_PROVIDER_BALANCE':'企业 AI 余额不足，充值后点继续分析',
                        'AI_PROVIDER_AUTH':'企业 AI 密钥无效，请管理员检查后点继续分析'}
            code=body.get('code')
            if isinstance(code,str) and (re.fullmatch(r'AI_[A-Z_]{1,60}',code) or code in PRODUCT_AI_ERROR_CODES):
                product_text=('原分析结果尚未核对，已保留原请求；未自动重试'
                              if code=='PRODUCT_REQUEST_UNKNOWN' else
                              '原分析操作已完成，需核对保留结果；未建立新请求'
                              if code=='PRODUCT_REQUEST_RESOLVED' else
                              '当前分析额度不足，评论已保存；请管理员核对服务周期和额度'
                              if code=='PRODUCT_ANALYSIS_LIMIT' else
                              '当前服务权益或原请求需核对，评论已保存；未自动重试')
                error=IntegrationError(product_text if code in PRODUCT_AI_ERROR_CODES else
                                       safe_codes.get(code,'AI 暂不可用，评论已保留待分析'))
                error.code=code
                proof=body.get('rejection_receipt')
                if (code in ('AI_NOT_CONFIGURED','AI_DAILY_BUDGET','PRODUCT_ANALYSIS_LIMIT')
                        and isinstance(proof,dict) and proof.get('contract')=='ai_no_dispatch_v1'
                        and proof.get('no_dispatch') is True and proof.get('proof_scope')=='current_submission'
                        and all(isinstance(proof.get(k),str) and 0<len(proof[k])<=128 for k in
                                ('environment_id','company_id','actor','operation_kind','request_id','submission_id'))
                        and all(isinstance(proof.get(k),str) and re.fullmatch(r'[a-f0-9]{64}',proof[k])
                                for k in ('input_digest','context_digest'))
                        and type(proof.get('config_revision')) is int and proof['config_revision']>=0
                        and isinstance(proof.get('rules_version'),str) and 0<len(proof['rules_version'])<=80):
                    error._candidate_no_dispatch={k:proof[k] for k in
                        ('contract','no_dispatch','proof_scope','environment_id','company_id','actor',
                         'operation_kind','request_id','submission_id','input_digest','context_digest',
                         'config_revision','rules_version')}
                raise error from None
        error=IntegrationError(messages.get(e.code, f'服务请求失败（HTTP {e.code}），请检查地址与服务部署'))
        error.http_status=e.code
        raise error from None
    except (URLError, TimeoutError, OSError):
        raise IntegrationError('无法连接服务，请检查网络与 HTTPS 服务地址；没有自动重试提交') from None
    except (ValueError, UnicodeError):
        raise IntegrationError('服务没有返回有效 JSON，请检查是否填入了正确接口地址') from None


def clean_keywords(values):
    if not isinstance(values, list):
        raise IntegrationError('AI 返回格式不正确，需要 keywords 数组')
    result = []
    for item in values:
        if isinstance(item, str):
            word = re.sub(r'[\x00-\x1f<>]', '', item).strip()[:40]
            if word and word not in result:
                result.append(word)
    if not result:
        raise IntegrationError('没有生成可用关键词，请换一种描述')
    return result[:16]


def apartment_keywords(seed):
    seeds = [s.strip() for s in re.split(r'[,，\n]', seed) if s.strip()][:3]
    out = []
    for item in seeds:
        stem = re.sub(r'(租房|求租|公寓|租客|找房)', '', item).strip()
        out.extend([item, stem + '求租', stem + '租房', stem + '一居室', stem + '整租', stem + '地铁租房', stem + '拎包入住'])
    return clean_keywords(out)


def remembered_expiry(result, device_id):
    """Accept only a cloud-confirmed remember grant for this exact device."""
    if not result.get('refresh_token'):
        return None
    now = time.time()
    secret = result.get('refresh_token')
    idle, absolute = result.get('refresh_idle_expires'), result.get('refresh_absolute_expires')
    if (result.get('device_id') != device_id
            or not isinstance(secret, str) or not re.fullmatch(r'rd_[A-Za-z0-9_-]{40,100}', secret)
            or type(idle) not in (int, float) or type(absolute) not in (int, float)
            or not now < idle <= now + 30 * 86400 + 5
            or not idle <= absolute <= now + 90 * 86400 + 5):
        raise IntegrationError('云端记住设备授权无效，本机登录未保存')
    return min(float(absolute), now + 90 * 86400)


class Integrations:
    def __init__(self, core):
        self.core = core
        self.root = core.store.directory / 'private-config'
        self.lock = threading.RLock()
        self.last_request = {}
        self.identity_cache = {}
        self.refresh_last_failure = {}

    def enter(self, data, expected_user=None, expected_guard=None, employee_only=False):
        """A cloud user can enter on a fresh computer without a local bootstrap."""
        from core.engine import password_hash
        managed = self.core.deployment_config.get('authMode') == 'managed'
        connection = self.core.deployment_config.get('managedWorkspace', {}) if managed else data
        if managed and not (connection.get('environment_id') and connection.get('endpoint')):
            raise IntegrationError('企业服务尚未配置完成，请联系管理员；无需员工填写服务器信息')
        env = str(connection.get('environment_id', '')).strip()
        url = endpoint(connection.get('endpoint'))
        if not re.fullmatch(r'[a-zA-Z0-9_-]{3,100}', env) or not url:
            raise IntegrationError('请填写腾讯云环境 ID 与 HTTPS 工作区服务地址')
        name, password = str(data.get('username', '')).strip(), str(data.get('password', ''))
        if not name or not password or len(password) > 256:
            raise IntegrationError('请填写云端账号和密码')
        company = self.core.deployment_config.get('id')
        tenant = 'cloud-' + hashlib.sha256((env + '\n' + company).encode()).hexdigest()[:24]
        uid = hashlib.sha256((tenant + '\n' + name).encode()).hexdigest()
        with self.lock:
            prior_session = self._read(tenant).get('sessions', {}).get(uid, {})
        device_id = prior_session.get('device_id')
        if not isinstance(device_id, str) or not re.fullmatch(r'[A-Za-z0-9_-]{16,100}', device_id):
            device_id = secrets.token_urlsafe(24)
        result = request_json(url, {'operation': 'login', 'environment_id': env, 'username': name,
                                    'password': password, 'remember_device': True, 'device_id': device_id})
        if result.get('contract') != 'fangyu-workspace-v1' or result.get('environment_id') != env or result.get('company_id') != company:
            raise IntegrationError('云端环境或公司身份不匹配')
        profile = result.get('user', {})
        if (not result.get('token') or profile.get('role') not in ('admin', 'operator')
                or profile.get('disabled') or profile.get('username') != name):
            raise IntegrationError('云端账号响应无效')
        if employee_only and profile['role'] != 'operator':
            try:
                request_json(url, {'operation': 'logout', 'environment_id': env}, result['token'])
            except Exception:
                pass
            raise EmployeeLoginRequired()
        remember_absolute = remembered_expiry(result, device_id)
        uid = hashlib.sha256((tenant + '\n' + profile['username']).encode()).hexdigest()
        if expected_user is not None and (expected_user.get('id') != uid
                or expected_user.get('tenant_id') != tenant
                or expected_user.get('username') != name
                or expected_user.get('role') != 'operator'
                or expected_user.get('cloud_bound') is not True
                or expected_user.get('disabled')
                or profile.get('username') != name or profile.get('role') != 'operator'):
            raise IntegrationError('云端员工身份与本机绑定不匹配')
        token = secrets.token_urlsafe(32)
        expires = min(float(result.get('expires', 0)), time.time() + 8 * 3600)
        if expires <= time.time():
            raise IntegrationError('云端会话已过期')
        with self.lock, self.core.lock:
            if expected_user is not None:
                if expected_guard is None or not expected_guard():
                    raise IntegrationError('本机绑定员工状态已变化')
                current = self.core.store.get('users', uid)
                if (not current or current.get('id') != uid
                        or current.get('tenant_id') != tenant
                        or current.get('username') != name
                        or current.get('role') != 'operator'
                        or current.get('cloud_bound') is not True
                        or current.get('disabled')):
                    raise IntegrationError('本机绑定员工状态已变化')
            if not self.core.store.get('tenants', tenant):
                self.core.store.put('tenants', self.core._record({'id': tenant, 'name': self.core.deployment_config.get('name', '方隅公寓'), 'industry': 'apartment', 'company_id': company}, tenant))
            previous = self.core.store.get('users', uid) or {}
            user = self.core._record({**previous, 'id': uid, 'username': profile['username'], 'role': profile['role'], 'disabled': False, 'cloud_bound': True, 'password_hash': password_hash(secrets.token_urlsafe(48))}, tenant)
            user['can_reply']=profile.get('can_reply') is not False
            self.core.store.put('users', user)
            config = self._read(tenant)
            config['cloud'] = {'environment_id': env, 'endpoint': url}
            saved_session = {'token': result['token'], 'expires': expires,
                             'username': profile['username']}
            if remember_absolute is not None:
                saved_session.update(device_id=device_id, refresh_token=result['refresh_token'],
                                     refresh_idle_expires=result.get('refresh_idle_expires', 0),
                                     refresh_absolute_expires=result.get('refresh_absolute_expires', 0))
            config.setdefault('sessions', {})[uid] = saved_session
            self._write(tenant, config)
            with self.core.store.connect() as db:
                db.execute('DELETE FROM sessions WHERE user_id=?', (uid,))
                db.execute('INSERT INTO sessions VALUES(?,?,?)', (hashlib.sha256(token.encode()).hexdigest(), uid,
                                                              remember_absolute or expires))
            self.identity_cache.pop(uid, None)
        return {'token': token, 'user': self.core._public(user),
                'cookie_max_age': max(1, int(remember_absolute - time.time())) if remember_absolute else None}

    def verify_identity(self, user, expected_user=None):
        if not user or not user.get('cloud_bound'):
            return user
        with self.lock:
            cached = self.identity_cache.get(user['id'])
            if expected_user is None and cached and cached[0] > time.monotonic():
                return cached[1]
            config = self._read(user['tenant_id'])
            try:
                profile = self._cloud(config, user, 'me')['user']
                if profile.get('disabled') or profile.get('username') != user['username'] or profile.get('role') not in ('admin', 'operator'):
                    raise IntegrationError('云端账号状态已变化')
                current = self.core.store.get('users', user['id'])
                if expected_user is not None and (not current
                        or current.get('id') != expected_user.get('id')
                        or current.get('tenant_id') != expected_user.get('tenant_id')
                        or current.get('username') != expected_user.get('username')
                        or current.get('role') != 'operator'
                        or current.get('cloud_bound') is not True
                        or current.get('disabled')
                        or profile.get('role') != 'operator'):
                    raise IntegrationError('云端员工身份与本机绑定不匹配')
                current['role'] = profile['role']
                current['can_reply']=profile.get('can_reply') is not False
                self.core.store.put('users', current)
                validated = self.core._public(current)
                self.identity_cache[user['id']] = (time.monotonic() + 30, validated)
                return validated
            except (IntegrationError, KeyError):
                self.identity_cache.pop(user['id'], None)
                return None

    def _path(self, tenant):
        import hashlib
        return self.root / (hashlib.sha256(tenant.encode()).hexdigest() + '.dpapi')

    def _read(self, tenant):
        path = self._path(tenant)
        if not path.exists():
            return {}
        try:
            return json.loads(protect(path.read_bytes(), decrypt=True))
        except (OSError, ValueError):
            raise IntegrationError('本机加密配置无法读取，请检查当前 Windows 账号') from None

    def _write(self, tenant, config):
        self.root.mkdir(parents=True, exist_ok=True)
        path = self._path(tenant)
        tmp = path.with_suffix('.tmp')
        tmp.write_bytes(protect(json.dumps(config, ensure_ascii=False).encode()))
        tmp.replace(path)

    def _refresh_session(self, config, user):
        """Refresh the existing cloud employee without retaining their password.

        A staged next secret is saved with DPAPI before the network request. If
        the response is lost, refresh_status probes only that staged secret;
        business commands are never replayed to discover the outcome.
        """
        with self.lock:
            latest = self._read(user['tenant_id'])
            if latest.get('cloud') != config.get('cloud'):
                raise IntegrationError('企业服务配置已变化，请重新登录')
            session = latest.get('sessions', {}).get(user['id'], {})
            if session.get('token') and float(session.get('expires', 0)) > time.time() + 60:
                return session
            if time.monotonic() - self.refresh_last_failure.get(user['id'], -1e9) < 60:
                raise IntegrationError('企业会话续期暂未确认，请稍后刷新；不会重复提交采集命令')
            device_id, refresh = session.get('device_id'), session.get('refresh_token')
            if (not isinstance(device_id, str) or not re.fullmatch(r'[A-Za-z0-9_-]{16,100}', device_id)
                    or not isinstance(refresh, str) or not refresh.startswith('rd_')
                    or float(session.get('refresh_idle_expires', 0)) <= time.time()
                    or float(session.get('refresh_absolute_expires', 0)) <= time.time()):
                return session
            cloud = latest['cloud']
            base = {'environment_id': cloud['environment_id'], 'device_id': device_id}

            def accept(result, new_refresh):
                profile = result.get('user') if isinstance(result, dict) else None
                if (not isinstance(result, dict)
                        or result.get('contract') != 'fangyu-workspace-v1'
                        or result.get('environment_id') != cloud['environment_id']
                        or result.get('company_id') != self.core.deployment_config.get('id')
                        or not isinstance(profile, dict) or profile.get('username') != user['username']
                        or profile.get('role') not in ('admin', 'operator') or profile.get('disabled')
                        or result.get('device_id') != device_id
                        or not isinstance(result.get('token'), str) or not result['token']
                        or float(result.get('expires', 0)) <= time.time()):
                    raise IntegrationError('企业会话续期响应无效，原会话已保留')
                updated = {**session, 'token': result['token'],
                           'expires': min(float(result['expires']), time.time() + 8 * 3600),
                           'refresh_token': new_refresh,
                           'refresh_idle_expires': result.get('refresh_idle_expires', 0),
                           'refresh_absolute_expires': result.get('refresh_absolute_expires', 0)}
                updated.pop('pending_refresh', None)
                latest['sessions'][user['id']] = updated
                self._write(user['tenant_id'], latest)
                self.identity_cache.pop(user['id'], None)
                self.refresh_last_failure.pop(user['id'], None)
                return updated

            pending = session.get('pending_refresh')
            if pending:
                try:
                    result = request_json(cloud['endpoint'], {'operation': 'refresh_status', **base}, pending)
                except IntegrationError as exc:
                    if getattr(exc, 'http_status', None) != 401:
                        self.refresh_last_failure[user['id']] = time.monotonic()
                        raise
                else:
                    return accept(result, pending)
            else:
                pending = 'rd_' + secrets.token_urlsafe(32)
                session = {**session, 'pending_refresh': pending}
                latest['sessions'][user['id']] = session
                self._write(user['tenant_id'], latest)
            try:
                result = request_json(cloud['endpoint'],
                                      {'operation': 'refresh', **base, 'next_refresh_token': pending}, refresh)
            except IntegrationError:
                self.refresh_last_failure[user['id']] = time.monotonic()
                raise
            return accept(result, pending)

    def _cloud(self, integration_config, user, operation, *, _owner_scope=None, **data):
        expected_company = self.core.deployment_config.get('id')
        if _owner_scope is not None:
            from assistant.self_operating_source_intent import _OwnerAICloudScope
            from assistant.owner_keyword_workflow import _OwnerKeywordAICloudScope
            if type(_owner_scope) not in (_OwnerAICloudScope,_OwnerKeywordAICloudScope) or _owner_scope.integrations is not self:
                raise IntegrationError('自营 AI 需要可信原服务绑定')
            expected_company = _owner_scope.check(user,integration_config,operation)
        cloud = integration_config.get('cloud', {})
        if not cloud.get('endpoint') or not cloud.get('environment_id'):
            raise IntegrationError('请先在设置中保存腾讯云环境 ID 与已部署的 HTTPS 服务地址')
        session = (_owner_scope.session() if _owner_scope is not None else
                   self._refresh_session(integration_config, user) if operation != 'login'
                   else integration_config.get('sessions', {}).get(user['id'], {}))
        if operation != 'login' and not session.get('token'):
            raise IntegrationError('请先登录云端成员账号')
        try:
            result = request_json(cloud['endpoint'], {'operation': operation, 'environment_id': cloud['environment_id'], **data}, session.get('token', ''))
        except IntegrationError as error:
            proof=getattr(error,'_candidate_no_dispatch',None)
            if (proof and error.code in ('AI_NOT_CONFIGURED','AI_DAILY_BUDGET','PRODUCT_ANALYSIS_LIMIT')
                    and operation in ('intent_analyze','keyword_suggest')
                    and proof['environment_id']==cloud['environment_id']
                    and proof['company_id']==(expected_company if _owner_scope is not None else self.core.deployment_config.get('id'))
                    and proof['actor']==user['username'] and proof['operation_kind']==operation
                    and proof['request_id']==data.get('request_id')
                    and proof['submission_id']==data.get('submission_id')
                    and type(data.get('expected_revision')) is int
                    and proof['config_revision']==data['expected_revision']
                    and proof['rules_version']==data.get('expected_rules_version')):
                error.no_dispatch_receipt=proof
            if hasattr(error,'_candidate_no_dispatch'):
                del error._candidate_no_dispatch
            raise
        if _owner_scope is not None:_owner_scope.check(user,integration_config,operation)
        if result.get('contract') != 'fangyu-workspace-v1' or result.get('environment_id') != cloud['environment_id'] or result.get('company_id') != (expected_company if _owner_scope is not None else self.core.deployment_config.get('id')):
            raise IntegrationError('服务身份或环境 ID 不匹配，请核实部署地址')
        if result.get('error'):
            raise IntegrationError('云端操作未完成，请检查账号权限和服务配置')
        return result

    def handle(self, action, data, user):
        if not user:
            raise IntegrationError('请先登录工作台')
        current = self.core.store.get('users', user['id'])
        if not current or current.get('disabled'):
            raise IntegrationError('账号已停用')
        user = self.core._public(current)
        tenant = user['tenant_id']
        with self.lock:
            config = self._read(tenant)
        cloud, ai = config.get('cloud', {}), config.get('ai', {})
        if action == 'integration_status':
            s = config.get('sessions', {}).get(user['id'], {})
            return {'cloud': {**cloud, 'configured': bool(cloud.get('endpoint') and cloud.get('environment_id')), 'connected': bool(s.get('token') and s.get('expires', 0) > time.time()), 'username': s.get('username', '')}, 'ai': {k: ai.get(k, '') for k in ('endpoint', 'model', 'enabled')} | {'configured': bool(ai.get('api_key') and ai.get('endpoint') and ai.get('model'))}}
        if action == 'integration_save':
            if user['role'] != 'admin':
                raise IntegrationError('需要管理员权限')
            kind = data.get('kind')
            with self.lock:
                config = self._read(tenant)
                if kind == 'cloud':
                    if self.core.deployment_config.get('authMode') == 'managed':
                        raise IntegrationError('企业服务器由部署配置统一管理')
                    env = str(data.get('environment_id', '')).strip()
                    if not re.fullmatch(r'[a-zA-Z0-9_-]{3,100}', env):
                        raise IntegrationError('请填写有效的 CloudBase 环境 ID')
                    new = {'environment_id': env, 'endpoint': endpoint(data.get('endpoint'))}
                    if new != config.get('cloud'):
                        config['sessions'] = {}
                    config['cloud'] = new
                elif kind == 'ai':
                    key = str(data.get('api_key') or config.get('ai', {}).get('api_key', '')).strip()
                    model = str(data.get('model', '')).strip()[:150]
                    url = endpoint(data.get('endpoint'))
                    enabled = data.get('enabled') is True
                    if enabled and not (url and key and model):
                        raise IntegrationError('启用 AI 前请填写 API 地址、模型名称和密钥')
                    if len(key) > 8192 or '\n' in key or '\r' in key:
                        raise IntegrationError('API Key 格式不正确')
                    config['ai'] = {'endpoint': url, 'model': model, 'api_key': key, 'enabled': enabled}
                else:
                    raise IntegrationError('不支持的配置类型')
                self._write(tenant, config)
            return {'ok': True}
        if action == 'keyword_suggest':
            seed = str(data.get('seed', '')).strip()
            if not seed or len(seed) > 500:
                raise IntegrationError('请输入 1 至 500 字的需求')
            if not ai.get('enabled'):
                return {'source': '公寓词库联想（未调用 AI）', 'keywords': apartment_keywords(seed)}
            with self.lock:
                now = time.monotonic()
                if now - self.last_request.get(user['id'], -100) < 3:
                    raise IntegrationError('请稍候再生成关键词')
                self.last_request[user['id']] = now
            response = request_json(ai['endpoint'] + '/chat/completions', {'model': ai['model'], 'messages': [{'role': 'system', 'content': '你是租赁获客搜索助手。根据用户需求推荐8至12个简短搜索词，覆盖区域、房型、通勤、租期与求租意图。只返回JSON对象，格式为{"keywords":["词1"]}。不编造真实房源、价格或保证获客量。'}, {'role': 'user', 'content': seed}], 'max_tokens': 500, 'temperature': 0.5}, ai['api_key'])
            try:
                raw = response['choices'][0]['message']['content'].strip()
                raw = re.sub(r'^```(?:json)?\s*|\s*```$', '', raw)
                words = json.loads(raw)['keywords']
            except (KeyError, IndexError, TypeError, ValueError):
                raise IntegrationError('AI 返回内容格式不正确；请检查模型是否支持对话 JSON 输出') from None
            return {'source': 'AI 联想 · ' + ai['model'], 'keywords': clean_keywords(words)}
        if action == 'cloud_login':
            name, password = str(data.get('username', '')).strip(), str(data.get('password', ''))
            if not name or not password or len(password) > 256:
                raise IntegrationError('请填写云端用户名与密码')
            result = self._cloud(config, user, 'login', username=name, password=password)
            if not result.get('token') or not isinstance(result.get('user'), dict):
                raise IntegrationError('云端登录响应不完整')
            with self.lock:
                latest = self._read(tenant)
                if latest.get('cloud') != cloud:
                    raise IntegrationError('云端配置已经变化，请重新登录')
                latest.setdefault('sessions', {})[user['id']] = {'token': result['token'], 'expires': result.get('expires', 0), 'username': result['user']['username']}
                self._write(tenant, latest)
            return {'ok': True, 'user': result['user']}
        if action == 'cloud_logout':
            try:
                self._cloud(config, user, 'logout')
            finally:
                with self.lock:
                    latest = self._read(tenant)
                    latest.setdefault('sessions', {}).pop(user['id'], None)
                    self.identity_cache.pop(user['id'], None)
                    self._write(tenant, latest)
            return {'ok': True}
        if action == 'cloud_list':
            cursor = data.get('cursor', '')
            revision = data.get('revision')
            if cursor and (not isinstance(cursor, str) or len(cursor) > 16 or not re.fullmatch(r'[1-9][0-9]*', cursor) or int(cursor) > 9007199254740991):
                raise IntegrationError('共享清单分页位置无效，请从第一页重新读取')
            if cursor and type(revision) is not int:
                raise IntegrationError('共享清单版本无效，请从第一页重新读取')
            return self._cloud(config, user, 'list', **({'cursor': cursor, 'revision': revision} if cursor else {}))
        if action == 'cloud_members':
            return self._cloud(config, user, 'members')
        if action == 'cloud_member_save':
            if user['role'] != 'admin':
                raise IntegrationError('需要管理员权限')
            return self._cloud(config, user, 'member_save', username=str(data.get('username', '')), password=str(data.get('password', '')), role=data.get('role'), disabled=data.get('disabled') is True)
        if action == 'cloud_publish':
            ids = data.get('ids', [])
            if not isinstance(ids, list) or not 1 <= len(ids) <= 100:
                raise IntegrationError('每次请选择 1 至 100 位客户')
            records = []
            for identifier in dict.fromkeys(ids):
                row = self.core.store.get('leads', identifier)
                if not row or row['tenant_id'] != tenant or row.get('demo'):
                    raise IntegrationError('选中的客户已不可用，请刷新后重试')
                records.append({k: str(row.get(k, ''))[:limit] for k, limit in {'platform': 40, 'source_id': 300, 'author': 120, 'text': 2000, 'url': 1000, 'grade': 10, 'reason': 300}.items()})
            return self._cloud(config, user, 'publish', items=records, revision=data.get('revision'))
        raise IntegrationError('不支持的集成操作')
