'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {createService}=require('./service.cjs');
const {hash,canonical,COMPANY,manifestId,sourceId,versionId}=require('./store_config.cjs');
const {CHUNK_BYTES,initialBundle}=require('./rule_bundle.cjs');
const {build}=require('../../central-store-config/catalog_build.cjs');
const base=build(),NOW=2000000000,ADMIN='synthetic-admin',OPERATOR='synthetic-operator';
function fixture(){
 const state={companyId:COMPANY,revision:5,users:[{username:'admin',role:'admin'},{username:'staff',role:'operator',store_id:base.manifest.stores[0].id}],sessions:[{username:'admin',digest:hash(ADMIN),expires:NOW+3600},{username:'staff',digest:hash(OPERATOR),expires:NOW+3600}],devices:[],audit:[],attempts:{},items:[],rememberedDevices:[]};
 const docs=new Map([base.manifest,...base.documents].map(v=>[v._id,structuredClone(v)]));
 let txHook=()=>{},readHook=()=>{},unknown=false,txCount=0;
 const store={readStoreConfigState:async()=>{readHook(state);return structuredClone(state);},readStoreConfigDocument:async id=>structuredClone(docs.get(id)||null),readRuleBundleDocument:async id=>structuredClone(docs.get(id)||null),
  transaction:async callback=>{const out=await callback(structuredClone(state),{});return out.result;},
  ruleBundleTransaction:async callback=>{
   txCount++;txHook(state);const staged=new Map();
   const result=await callback({state:async()=>structuredClone(state),get:async id=>structuredClone(docs.get(id)||null),set:async(id,v)=>staged.set(id,structuredClone(v))});
   for(const [id,value]of staged)docs.set(id,value);
   if(unknown){unknown=false;throw Error('synthetic_lost_commit_response');}return result;
  }};
 const service=createService({store,companyId:COMPANY,environmentId:'synthetic-env',clock:()=>NOW*1000});
 return {state,docs,setTxHook:fn=>txHook=fn,setReadHook:fn=>readHook=fn,unknown:()=>unknown=true,get txCount(){return txCount;},
  call:(operation,data={},token=ADMIN)=>service({environment_id:'synthetic-env',operation,...data},token)};
}
async function exportBundle(f){const status=await f.call('rule_bundle_status');assert.equal(status.status,200);const parts=[];for(let index=0;index<status.data.chunkCount;index++){const p=await f.call('rule_bundle_export_chunk',{revision:status.data.revision,index});assert.equal(p.status,200);parts.push(Buffer.from(p.data.dataBase64,'base64'));}const bytes=Buffer.concat(parts);assert.equal(hash(bytes),status.data.digest);return {status:status.data,bundle:JSON.parse(bytes)};}
async function begin(f,bundle,requestId='synthetic-request-001'){
 const bytes=Buffer.from(canonical(bundle)),chunkCount=Math.ceil(bytes.length/CHUNK_BYTES),res=await f.call('rule_bundle_import_begin',{requestId,expectedRevision:base.manifest.active_revision,digest:hash(bytes),bytes:bytes.length,chunkCount});assert.equal(res.status,200,JSON.stringify(res));
 return {uploadId:res.data.uploadId,bytes,chunkCount,requestId};
}
async function chunks(f,upload,reverse=true){for(const index of Array.from({length:upload.chunkCount},(_,i)=>i)[reverse?'reverse':'slice']()){const res=await f.call('rule_bundle_import_chunk',{uploadId:upload.uploadId,index,dataBase64:upload.bytes.subarray(index*CHUNK_BYTES,(index+1)*CHUNK_BYTES).toString('base64')});assert.equal(res.status,200,JSON.stringify(res));}}
function extension(bundle){const material=bundle.catalog.materials[0];bundle.extensions.stores=[{material_key:material.key,searchTerms:[{query:'near verified station rental',tier:'context',evidence_status:'verified',enabled:true,sourceRefs:[material.sourceRefs[0]]},{query:'candidate text retained',tier:'exploratory',evidence_status:'candidate',enabled:false,sourceRefs:[]}],excludeTerms:['broker-only'],prompts:{intent:'private admin prompt'},judgement:{income:'self reported only'},evidence:[]}];}
test('representative service route: export >400KB, unordered chunks, prepare does not activate, atomic commit and runtime projection',async()=>{
 const f=fixture(),stateBefore=hash(f.state),out=await exportBundle(f);assert.ok(out.status.chunkCount>1);extension(out.bundle);out.bundle.extensions.common.transportPadding='representative-data-'.repeat(10000);out.bundle.catalog.keywords[0].keyword+=' updated';
 const upload=await begin(f,out.bundle);await chunks(f,upload);const before=hash(f.docs.get(manifestId(COMPANY))),prepared=await f.call('rule_bundle_import_prepare',{uploadId:upload.uploadId});assert.equal(prepared.status,200,JSON.stringify(prepared));assert.equal(prepared.data.state,'prepared');assert.ok(prepared.data.warnings.includes('INTERNAL_DIGEST_RECOMPUTED_ADMIN_MODIFIED'));assert.equal(hash(f.docs.get(manifestId(COMPANY))),before);
 const committed=await f.call('rule_bundle_import_commit',{uploadId:upload.uploadId,previewDigest:prepared.data.previewDigest});assert.equal(committed.status,200,JSON.stringify(committed));assert.equal(committed.data.state,'committed');assert.notEqual(committed.data.revision,base.manifest.active_revision);
 const manifest=f.docs.get(manifestId(COMPANY)),version=f.docs.get(versionId(COMPANY,manifest.active_revision,manifest.stores[0].id));assert.equal(version.config.runtimeSearch.queries.length,1);assert.equal(version.config.runtimeSearch.queries[0].tier,'context');assert.equal(version.config.runtimeSearch.prompts,undefined);assert.equal(version.config.ruleEnabled,false);assert.equal(version.config.priceVerified,false);
 assert.ok(f.docs.has(sourceId(COMPANY,base.manifest.active_revision)));assert.equal(hash(f.state),stateBefore);
 const staff=await f.call('store_config_read',{store_id:manifest.stores[0].id},OPERATOR);assert.equal(staff.status,200);assert.equal(staff.data.config.runtimeSearch.queries.length,1);assert.equal(JSON.stringify(staff).includes('private admin prompt'),false);
 const current=await exportBundle(f);assert.equal(current.bundle.extensions.stores[0].prompts.intent,'private admin prompt');assert.equal(current.status.digest,committed.data.digest);
});
test('management always requires true admin: absent/expired/revoked, operator, device, company and fresh transaction auth',async()=>{
 for(const token of ['',OPERATOR,'synthetic-device']){const f=fixture();const r=await f.call('rule_bundle_status',{},token);assert.equal(r.status,token===OPERATOR?403:401);assert.equal(r.data.dataBase64,undefined);}
 for(const mutate of [s=>s.sessions.splice(0,1),s=>s.sessions[0].expires=NOW,s=>s.users[0].disabled=true,s=>s.companyId='other-company']){const f=fixture();mutate(f.state);assert.equal((await f.call('rule_bundle_status')).status,401);}
 const f=fixture();f.setTxHook(s=>{s.users[0].role='operator';});const bundle=initialBundle(base.source),bytes=Buffer.from(canonical(bundle));assert.equal((await f.call('rule_bundle_import_begin',{requestId:'synthetic-expired',expectedRevision:base.manifest.active_revision,digest:hash(bytes),bytes:bytes.length,chunkCount:Math.ceil(bytes.length/CHUNK_BYTES)})).status,403);assert.equal(f.docs.size,16);
 const r=fixture();let reads=0;r.setReadHook(s=>{if(++reads===2)s.sessions=[];});assert.equal((await r.call('rule_bundle_status')).status,401);
});
test('upload limits, malformed/duplicate chunks, transport digest and missing chunks fail closed',async()=>{
 const f=fixture(),upload=await begin(f,initialBundle(base.source));
 assert.equal((await f.call('rule_bundle_import_prepare',{uploadId:upload.uploadId})).status,409);
 assert.equal((await f.call('rule_bundle_import_chunk',{uploadId:upload.uploadId,index:upload.chunkCount,dataBase64:'AAAA'})).status,400);
 assert.equal((await f.call('rule_bundle_import_chunk',{uploadId:upload.uploadId,index:0,dataBase64:'A'.repeat(CHUNK_BYTES*2)})).status,400);
 const first=upload.bytes.subarray(0,CHUNK_BYTES).toString('base64');assert.equal((await f.call('rule_bundle_import_chunk',{uploadId:upload.uploadId,index:0,dataBase64:first})).status,200);assert.equal((await f.call('rule_bundle_import_chunk',{uploadId:upload.uploadId,index:0,dataBase64:first})).status,200);assert.equal((await f.call('rule_bundle_import_chunk',{uploadId:upload.uploadId,index:0,dataBase64:Buffer.alloc(CHUNK_BYTES).toString('base64')})).status,409);
 const changed=Buffer.from(upload.bytes);changed[changed.length-2]^=1;upload.bytes=changed;
 for(let i=1;i<upload.chunkCount;i++)assert.equal((await f.call('rule_bundle_import_chunk',{uploadId:upload.uploadId,index:i,dataBase64:changed.subarray(i*CHUNK_BYTES,(i+1)*CHUNK_BYTES).toString('base64')})).status,200);
 assert.equal((await f.call('rule_bundle_import_prepare',{uploadId:upload.uploadId})).data.code,'RULE_BUNDLE_TRANSPORT_DIGEST_MISMATCH');
 assert.equal((await f.call('rule_bundle_import_begin',{requestId:'synthetic-limit',expectedRevision:base.manifest.active_revision,digest:'a'.repeat(64),bytes:8388609,chunkCount:86})).status,400);
});
test('protected evidence/held/draft/price and unsupported or secret data rejected with explicit fields',async()=>{
 const {validateBundle}=require('./rule_bundle.cjs');
 for(const [field,mutate]of [['held',b=>b.catalog.keywords.find(w=>!w.csvCandidateEligible).csvCandidateEligible=true],['draft',b=>b.catalog.intentRule.enabled=true],['price',b=>b.catalog.materials[0].priceVerified=true],['source',b=>b.catalog.sourceArtifacts[0].sha256='a'.repeat(64)],['secret',b=>b.extensions.common.apiKey='synthetic'],['reference',b=>b.extensions.stores=[{material_key:'missing'}]]]){const b=initialBundle(base.source);mutate(b);assert.throws(()=>validateBundle(b,base.source),undefined,field);}
 const b=initialBundle(base.source);extension(b);b.extensions.stores[0].searchTerms[0].sourceRefs=['unknown-ref'];assert.throws(()=>validateBundle(b,base.source),e=>e.code==='RULE_BUNDLE_TERM_ENABLE_REQUIRES_VERIFIED_SOURCE'&&e.field.includes('searchTerms'));
 b.extensions.stores[0].evidence=[{sourceRef:'unknown-ref',url:'https://example.com/public',title:'Synthetic public source',checkedAt:'2026-10-17',status:'verified'}];assert.equal(validateBundle(b,base.source).summary.runtimeQueries,1);
 b.extensions.stores[0].evidence[0].url='https://user:secret@example.com/';assert.throws(()=>validateBundle(b,base.source),e=>e.code==='RULE_BUNDLE_EVIDENCE_URL_INVALID');
});
test('CAS conflict does not activate; unknown commit reconciles receipt by uploadId/requestId with no auto retry',async()=>{
 const f=fixture(),upload=await begin(f,initialBundle(base.source));await chunks(f,upload);const p=await f.call('rule_bundle_import_prepare',{uploadId:upload.uploadId});assert.equal(p.status,200);
 const manifest=f.docs.get(manifestId(COMPANY)),original=manifest.active_revision,other='r_'+'a'.repeat(32);f.docs.set(sourceId(COMPANY,other),{_id:sourceId(COMPANY,other),companyId:COMPANY,doc_type:'store_config_source',revision:other,catalog:base.source});manifest.active_revision=other;assert.equal((await f.call('rule_bundle_import_commit',{uploadId:upload.uploadId,previewDigest:p.data.previewDigest})).status,409);manifest.active_revision=original;
 f.unknown();const count=f.txCount;const lost=await f.call('rule_bundle_import_commit',{uploadId:upload.uploadId,previewDigest:p.data.previewDigest});assert.equal(lost.status,503);assert.equal(lost.data.state,'unknown');assert.equal(f.txCount,count+1);
 for(const reference of [{uploadId:upload.uploadId},{requestId:upload.requestId}]){const receipt=await f.call('rule_bundle_import_status',reference);assert.equal(receipt.status,200);assert.equal(receipt.data.state,'committed');}
 assert.equal((await f.call('rule_bundle_import_status',{requestId:'never-begun-request'})).data.state,'not_found');assert.equal((await f.call('rule_bundle_import_status',{uploadId:upload.uploadId},OPERATOR)).status,403);
});
test('all baseline bytes except two adapters retained; old health/me/store read keep working',async()=>{
 const baseline=path.resolve(__dirname,'../cloud-live-source');
 for(const name of fs.readdirSync(baseline)){if(fs.statSync(path.join(baseline,name)).isFile()&&!['service.cjs','index.js'].includes(name))assert.equal(hash(fs.readFileSync(path.join(__dirname,name))),hash(fs.readFileSync(path.join(baseline,name))),name);}
 const f=fixture();assert.equal((await f.call('health')).status,200);assert.equal((await f.call('me')).status,200);assert.equal((await f.call('store_config_read')).data.stores.length,14);
});

test('complete approved research bundle can import without truncation and stays private',async()=>{
 const f=fixture(),bundle=JSON.parse(fs.readFileSync(path.resolve(__dirname,'../package-audit/compiled-rule-bundle.json'),'utf8'));
 bundle.extensions.common.runtimePolicy={schema:'fangyu-approved-runtime-policy/1',searchHypotheses:true,assessment:true};
 const upload=await begin(f,bundle,'complete-source-bundle-001');await chunks(f,upload);
 const p=await f.call('rule_bundle_import_prepare',{uploadId:upload.uploadId});assert.equal(p.status,200,JSON.stringify(p));
 assert.equal(p.data.summary.runtimeQueries,1506);
 const commit=await f.call('rule_bundle_import_commit',{uploadId:upload.uploadId,previewDigest:p.data.previewDigest});assert.equal(commit.status,200,JSON.stringify(commit));
 const exported=await exportBundle(f);assert.equal(exported.bundle.extensions.common.researchArtifacts.length,54);
 assert.equal(exported.bundle.extensions.common.judgement_examples.length,108);
 assert.equal(exported.bundle.extensions.common.constraints.length,41);
 const manifest=f.docs.get(manifestId(COMPANY));let hypothesisCount=0;
 for(const s of manifest.stores){
  const config=f.docs.get(versionId(COMPANY,manifest.active_revision,s.id)).config;
  hypothesisCount+=config.runtimeSearch.queries.filter(q=>q.source==='approved_search_hypothesis').length;
  assert.equal(config.runtimeAssessment.enabled,true);assert.equal(config.runtimeAssessment.calibrated,false);
  assert.equal(config.package.intentRule.enabled,false);assert.equal(config.priceVerified,false);
  assert.equal(JSON.stringify(config).includes('researchArtifacts'),false);
 }
 assert.equal(hypothesisCount,1506);
 const staff=await f.call('store_config_read',{store_id:manifest.stores[0].id},OPERATOR);assert.equal(staff.status,200);
 assert.equal(JSON.stringify(staff).includes('judgement_examples'),false);
 assert.equal((await f.call('rule_bundle_status',{},OPERATOR)).status,403);
});

test('uploaded eligibility is not authority; same-version changed judgement contract is inactive',()=>{
 const {validateBundle,compile}=require('./rule_bundle.cjs');
 const bundle=JSON.parse(fs.readFileSync(path.resolve(__dirname,'../package-audit/compiled-rule-bundle.json'),'utf8'));
 bundle.extensions.common.runtimePolicy={schema:'fangyu-approved-runtime-policy/1',searchHypotheses:true,assessment:true};
 const eligible=bundle.extensions.stores.flatMap(s=>s.searchTerms).find(t=>t.eligibleHypothesis);
 eligible.query='forged unrelated query';eligible.enabled=false;
 const held=bundle.extensions.stores.flatMap(s=>s.searchTerms).find(t=>!t.eligibleHypothesis);
 held.eligibleHypothesis=true;held.holdReasons=[];
 bundle.extensions.common.constraints[0]={id:'fake-constraint-same-version',text:'fake instruction'};
 const prepared=validateBundle(bundle,base.source);
 assert.equal(prepared.summary.runtimeHypotheses,1505);assert.equal(prepared.summary.assessmentPolicy.enabled,false);
 assert.ok(prepared.warnings.includes('ASSESSMENT_CONTRACT_REQUIRES_ENGINE_UPDATE'));
 const compiled=compile(prepared);
 assert.equal(JSON.stringify(compiled.documents.filter(d=>d.doc_type==='store_config_version')).includes('forged unrelated query'),false);
 const parent=bundle.extensions.common.researchArtifacts.find(a=>a.id==='ART-5c9defa77ce939605737');
 parent.sha256='a'.repeat(64);
 // Uploading a matching forged source pin does not alter the independent code pin.
 bundle.extensions.common.sourcePins.find(a=>a.id===parent.id).sha256=parent.sha256;
 assert.equal(validateBundle(bundle,base.source).summary.runtimeHypotheses,0);
});

test('employee projection omits admin rule text while admin export retains it',async()=>{
 const f=fixture(),b=initialBundle(base.source);b.catalog.intentRule.description='ADMIN_PRIVATE_REVIEW_SENTINEL';
 const u=await begin(f,b,'admin-private-text-check');await chunks(f,u);
 const p=await f.call('rule_bundle_import_prepare',{uploadId:u.uploadId});assert.equal(p.status,200);
 const c=await f.call('rule_bundle_import_commit',{uploadId:u.uploadId,previewDigest:p.data.previewDigest});assert.equal(c.status,200);
 const m=f.docs.get(manifestId(COMPANY)),staff=await f.call('store_config_read',{store_id:m.stores[0].id},OPERATOR);
 assert.equal(staff.status,200);assert.equal(JSON.stringify(staff).includes('ADMIN_PRIVATE_REVIEW_SENTINEL'),false);
 assert.equal((await exportBundle(f)).bundle.catalog.intentRule.description,'ADMIN_PRIVATE_REVIEW_SENTINEL');
});

test('accepted chunk is observable by original request id without another upload mutation',async()=>{
 const f=fixture(),u=await begin(f,initialBundle(base.source),'chunk-status-reconciliation');
 const send=await f.call('rule_bundle_import_chunk',{uploadId:u.uploadId,index:0,dataBase64:u.bytes.subarray(0,CHUNK_BYTES).toString('base64')});assert.equal(send.status,200);
 const before=f.txCount,r=await f.call('rule_bundle_import_status',{requestId:u.requestId});
 assert.equal(r.status,200);assert.deepEqual(r.data.receivedIndices,[0]);assert.equal(r.data.chunkCount,u.chunkCount);
 assert.equal(r.data.state,'uploading');assert.equal(f.txCount,before+1);
});

test('complete stored bundle is compact and a damaged stored payload cannot export or activate',async()=>{
 const f=fixture(),b=JSON.parse(fs.readFileSync(path.resolve(__dirname,'../package-audit/compiled-rule-bundle.json'),'utf8'));
 const u=await begin(f,b,'compact-stored-research-001');await chunks(f,u);
 const p=await f.call('rule_bundle_import_prepare',{uploadId:u.uploadId});assert.equal(p.status,200);
 const staged=f.docs.get(u.uploadId);
 assert.equal(staged.bundle,undefined);assert.equal(staged.bundle_storage.encoding,'gzip+base64');
 assert.ok(Buffer.byteLength(JSON.stringify(staged))<2300000);
 // A corrupted prepared copy cannot become active, even with the valid preview.
 const original=structuredClone(staged);staged.bundle_storage.sha256='f'.repeat(64);
 const blocked=await f.call('rule_bundle_import_commit',{uploadId:u.uploadId,previewDigest:p.data.previewDigest});
 assert.equal(blocked.status,503);assert.equal(f.docs.get(manifestId(COMPANY)).active_revision,base.manifest.active_revision);
 f.docs.set(u.uploadId,original);
 const c=await f.call('rule_bundle_import_commit',{uploadId:u.uploadId,previewDigest:p.data.previewDigest});assert.equal(c.status,200);
 const m=f.docs.get(manifestId(COMPANY)),row=f.docs.get(require('./rule_bundle.cjs').bundleId(m.active_revision));
 assert.equal(row.bundle,undefined);assert.ok(Buffer.byteLength(JSON.stringify(row))<2300000);
 assert.equal((await exportBundle(f)).bundle.extensions.common.researchArtifacts.length,54);
 row.bundle_storage.dataBase64=row.bundle_storage.dataBase64.slice(4);
 assert.equal((await f.call('rule_bundle_status')).status,503);
});

test('existing uncompressed versions remain readable and decompression is strictly bounded',()=>{
 const {pack,unpack,readBundle,MAX_BYTES}=require('./rule_bundle_storage.cjs');
 const b=initialBundle(base.source);assert.deepEqual(readBundle({bundle:b}),b);
 const bytes=Buffer.from(canonical(b)),p=pack(bytes);assert.deepEqual(unpack(p),b);
 assert.throws(()=>readBundle({bundle:b,bundle_storage:p}));
 for(const mutation of [x=>x.bytes=MAX_BYTES+1,x=>x.sha256='0'.repeat(64),x=>x.dataBase64+=' ',x=>x.extra=true]){
  const bad=structuredClone(p);mutation(bad);assert.throws(()=>unpack(bad));
 }
 const zipBomb={...p,bytes:MAX_BYTES,dataBase64:require('node:zlib').gzipSync(Buffer.alloc(MAX_BYTES+1)).toString('base64')};
 assert.throws(()=>unpack(zipBomb));
});

test('validated packed canonical export skips reparsing while metadata corruption fails closed and public validation retains isolation',async()=>{
 const storage=require('./rule_bundle_storage.cjs');
 assert.equal(typeof storage.unpackBytes,'function');
 const f=fixture(),b=initialBundle(base.source),publicPrepared=require('./rule_bundle.cjs').validateBundle(b,base.source);
 publicPrepared.bundle.extensions.common.publicMutation='must not alias caller';assert.equal(b.extensions.common.publicMutation,undefined);
 const u=await begin(f,b,'canonical-export-memory-001');await chunks(f,u);const p=await f.call('rule_bundle_import_prepare',{uploadId:u.uploadId});assert.equal(p.status,200);
 const c=await f.call('rule_bundle_import_commit',{uploadId:u.uploadId,previewDigest:p.data.previewDigest});assert.equal(c.status,200);
 const m=f.docs.get(manifestId(COMPANY)),row=f.docs.get(require('./rule_bundle.cjs').bundleId(m.active_revision));
 assert.equal(row.canonical_json.schema,'fangyu-validated-canonical-json/1');assert.equal(row.canonical_json.digest,row.digest);
 assert.equal(m.rule_bundle_summary_digest,hash(row.summary));
 const parse=JSON.parse;let s,chunk;
 JSON.parse=()=>{throw Error('packed export must not JSON.parse');};
 try{s=await f.call('rule_bundle_status');chunk=await f.call('rule_bundle_export_chunk',{revision:m.active_revision,index:0});}finally{JSON.parse=parse;}
 assert.equal(s.status,200);assert.equal(chunk.status,200);assert.equal(s.data.digest,row.digest);
 const original=structuredClone(row);row.summary.originalKeywords=0;assert.equal((await f.call('rule_bundle_status')).status,503);f.docs.set(row._id,structuredClone(original));
 const corrupt=f.docs.get(row._id);corrupt.canonical_json.schema='untrusted';assert.equal((await f.call('rule_bundle_status')).status,503);f.docs.set(row._id,structuredClone(original));
 const invalid=f.docs.get(row._id);invalid.bundle_storage=storage.pack(Buffer.from('not JSON'));assert.equal((await f.call('rule_bundle_status')).status,503);f.docs.set(row._id,structuredClone(original));
 // Old packed rows with no validation capsule retain their strict JSON parse path.
 const old=f.docs.get(row._id);delete old.canonical_json;delete old.summary;delete m.rule_bundle_summary_digest;
 assert.equal((await f.call('rule_bundle_status')).status,200);
});

test('bounded canonical byte writer matches original digests and escaping without public aliases or uploaded capsules',()=>{
 const {validateBundle}=require('./rule_bundle.cjs'),b=initialBundle(base.source);
 b.extensions.common.byteRegression={'2':'two','10':'ten','1':'one',samples:[-0,1e-10,1e22,null,false,'汉字\u0000😀',String.fromCharCode(0xd800),'x'.repeat(32766)+'😀'+'y'.repeat(32766)]};
 const result=validateBundle(b,base.source);assert.equal(result.bytes.toString('utf8'),canonical(result.bundle));
 const body=structuredClone(result.bundle);delete body.digest;assert.equal(result.previewDigest,hash(body));
 result.bundle.extensions.common.byteRegression.samples[0]=42;assert.equal(Object.is(b.extensions.common.byteRegression.samples[0],-0),true);
 const forged=initialBundle(base.source);forged.canonical_json={schema:'fangyu-validated-canonical-json/1',digest:'a'.repeat(64)};
 assert.throws(()=>validateBundle(forged,base.source),error=>error.code==='RULE_BUNDLE_UNSUPPORTED_FIELD');
});


test('single-entry decoded byte reuse preserves strict envelopes, detects mutable byte corruption and never serves damaged storage',()=>{
 const {pack,unpackBytes}=require('./rule_bundle_storage.cjs'),raw=Buffer.from('{"plain":"validated bytes"}'),p=pack(raw);
 const first=unpackBytes(p);assert.deepEqual(first,raw);first[0]=0;
 assert.deepEqual(unpackBytes(p),raw);
 assert.throws(()=>unpackBytes({...p,extra:true}));assert.throws(()=>unpackBytes({...p,dataBase64:p.dataBase64+' '}));
 const other=pack(Buffer.from('{"other":1}'));assert.deepEqual(unpackBytes(other),Buffer.from('{"other":1}'));assert.deepEqual(unpackBytes(p),raw);
 assert.throws(()=>unpackBytes({...p,dataBase64:p.dataBase64.slice(4)}));
});
