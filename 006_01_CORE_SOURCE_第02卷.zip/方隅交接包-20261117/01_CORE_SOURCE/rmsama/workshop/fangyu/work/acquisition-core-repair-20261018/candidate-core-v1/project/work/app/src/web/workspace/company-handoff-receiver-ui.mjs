/* Company receiver actions use the backend's original attempt; never a new generic key. */
const exact=(value,keys)=>value&&typeof value==='object'&&!Array.isArray(value)&&Object.keys(value).length===keys.length&&keys.every(key=>Object.hasOwn(value,key));
const hex=value=>typeof value==='string'&&/^[a-f0-9]{64}$/.test(value);
const channel=value=>typeof value==='string'&&/^hc_[a-f0-9]{64}$/.test(value);
const identifier=value=>typeof value==='string'&&/^[A-Za-z0-9_-]{1,160}$/.test(value);
const integer=value=>Number.isSafeInteger(value)&&value>=0;
const stamp=value=>integer(value)&&value>=1577836800&&value<=253402300799;
const bool=value=>typeof value==='boolean';
const safeLabel=value=>{
  if(typeof value!=='string'||!value.trim()||value.length>160||value!==value.normalize('NFKC')||/[\p{Cc}\p{Cf}\p{Cs}]/u.test(value))return false;
  const compact=value.replace(/[\p{P}\p{Z}]/gu,'');
  return !/\d{7,}/.test(compact)&&!/(?:contact|platform|consent|evidence|notice|document)\s*:|(?:微信|wechat|weixin|wxid|手机号|电话)\s*[:：_号]?\s*[A-Za-z0-9]{3,}|(?<![A-Za-z0-9_])wx\s*[:：_号]\s*[A-Za-z0-9_-]{3,}|(?<![A-Za-z0-9_])Bearer\s+|sk-[\w-]{12}|(?:cookie|password|secret|api[_-]?key)\s*[:=]/i.test(value);
};
const actions=['company_handoff_received_list','company_handoff_received_detail','company_handoff_receipt','company_handoff_receipt_get'];
const decisions=['accept','reject','needs_information','duplicate','existing_customer'];
const decisionStates={accept:'accepted',reject:'rejected',needs_information:'needs_information',duplicate:'duplicate_pending_review',existing_customer:'existing_customer_pending_review'};
const labels={draft:'待提交',submitted:'公司已登记提交',accepted:'公司登记已接收',rejected:'公司登记未接收',needs_information:'待补资料',duplicate_pending_review:'重复线索待核对',existing_customer_pending_review:'已有客户待核对',withdrawn:'当前授权已撤回',disputed:'归属有争议'};
const falseFlags=['cross_machine_verified','auto_retry','platform_delivery_verified','receipt_evidence_independently_verified','financial_receipt_verified','cooperation_policy_verified','settlement_active','contacts_modified','local_handoffs_modified','platform_requests_started','provider_requests_started'];
const topFields=['contract','operation_action','read_only','mutation_committed','storage_scope','local_only','actor_scope_hash','observed_at','state','item','items','authorized_recipients','selected_recipient_id','selection_required','total','offset','has_more','attempt','original_operation','original_execution_confirmed','eligible_for_receipt','cloud_receipt_requested','contact_delivery','verified_cash_cents','verified_paid_commission_cents',...falseFlags];
const itemFields=['channel_id','customer_scope_hash','source_actor_scope_hash','platform','recipient_id','recipient_name','purpose','revision','status','current_consent_valid','can_receipt','historical_resource_receipt_recorded','receipt_evidence_independently_verified','contact_delivery','created_at','updated_at'];

const ownerTag=item=>item?.origin_kind==='owner_package_v1';
const ownerStatuses=['draft','submitted','accepted','rejected','needs_information','duplicate_pending_review','existing_customer_pending_review','withdrawn','needs_review'];
const ownerItemFields=['origin_kind','channel_id','case_id','claim_id','instance_id','package_id','row_id','selection_digest','artifact_sha256','sender_subject_id','recipient_id','recipient_name','purpose','status','revision','consent','receipt','permissions','source_authorization','created_at','updated_at'];
const ownerSubject=value=>typeof value==='string'&&/^su_[a-f0-9]{32}$/.test(value);
const ownerStateLabel=item=>ownerTag(item)&&item.status==='needs_review'?'原资料包记录待核对':labels[item.status];
const receiverCanReceipt=item=>ownerTag(item)?item.permissions.can_receipt:item.can_receipt;
function checkedOwnerReceiverItem(item,fail){
 if(!exact(item,ownerItemFields)||!ownerTag(item)||!channel(item.channel_id)||!/^oc_[a-f0-9]{64}$/.test(item.case_id)||!/^cl_[a-f0-9]{64}$/.test(item.claim_id)||!/^[a-f0-9]{32}$/.test(item.instance_id)||![item.package_id,item.row_id,item.selection_digest,item.artifact_sha256].every(hex)||!ownerSubject(item.sender_subject_id)||!identifier(item.recipient_id)||!safeLabel(item.recipient_name)||!safeLabel(item.purpose)||!ownerStatuses.includes(item.status)||!integer(item.revision)||item.revision<1||!stamp(item.created_at)||!stamp(item.updated_at)||item.updated_at<item.created_at)fail();
 const consent=item.consent,authorization=item.source_authorization,permissions=item.permissions;
 if(!exact(consent,['version','status','binding_digest','last_synced_at','valid_until'])||!integer(consent.version)||!['unconfirmed','granted','withdrawn'].includes(consent.status)||!hex(consent.binding_digest)||consent.last_synced_at!==null&&!stamp(consent.last_synced_at)||consent.valid_until!==null&&!stamp(consent.valid_until))fail();
 if(consent.status==='unconfirmed'&&(consent.version!==0||consent.last_synced_at!==null||consent.valid_until!==null)||consent.status==='granted'&&(consent.version<1||!stamp(consent.last_synced_at)||!stamp(consent.valid_until)||consent.valid_until<consent.last_synced_at||consent.valid_until>consent.last_synced_at+300)||consent.status==='withdrawn'&&consent.version<1)fail();
 if(!exact(authorization,['state','company_scope','checked_at','consent_version','valid_until'])||!['current_company_scope','last_synced_expired','withdrawn','admission_expired','admission_revoked','needs_review'].includes(authorization.state)||authorization.company_scope!=='last_synced_authenticated_sender_declaration'||!stamp(authorization.checked_at)||authorization.consent_version!==consent.version||authorization.valid_until!==consent.valid_until)fail();
 if(!exact(permissions,['can_submit','can_withdraw','can_receipt','can_review'])||Object.values(permissions).some(value=>!bool(value))||permissions.can_submit!==false||permissions.can_receipt&&(item.status!=='submitted'||consent.status!=='granted'||authorization.state!=='current_company_scope')||item.status==='withdrawn'&&consent.status!=='withdrawn')fail();
 const receipt=item.receipt;
 if(receipt!==null&&(!exact(receipt,['channel_id','revision','decision','reason_code','evidence_reference','recorded_at','receiver_subject_id','receiver_mapping_version','authenticated_receiver_decision','receipt_evidence_independently_verified'])||receipt.channel_id!==item.channel_id||!integer(receipt.revision)||receipt.revision<1||receipt.revision>item.revision||!decisions.includes(receipt.decision)||![null,'not_qualified','outside_service_area','needs_information','duplicate','existing_customer'].includes(receipt.reason_code)||!/^(?:evidence|document):[a-f0-9]{32}$/.test(receipt.evidence_reference)||!stamp(receipt.recorded_at)||!ownerSubject(receipt.receiver_subject_id)||receipt.receiver_subject_id===item.sender_subject_id||!integer(receipt.receiver_mapping_version)||receipt.receiver_mapping_version<1||receipt.authenticated_receiver_decision!==true||receipt.receipt_evidence_independently_verified!==false))fail();
 return item;
}

export function checkedCompanyReceiver(value,action,request={},expected={}){
  const fail=()=>{throw Error('公司收件记录的范围或证据状态未通过核对；请核对原操作，暂勿再次提交。');};
  if(!exact(value,topFields)||!actions.includes(action)||value.operation_action!==action||value.contract!=='company_handoff_receiver_v1'||value.storage_scope!=='local_bridge_company_server_ledger'||value.local_only!==false||falseFlags.some(key=>value[key]!==false)||!['platform_reference_only','owner_package_metadata_only'].includes(value.contact_delivery)||value.verified_cash_cents!==null||value.verified_paid_commission_cents!==null||!hex(value.actor_scope_hash)||expected.actorHash&&value.actor_scope_hash!==expected.actorHash||!stamp(value.observed_at)||!bool(value.read_only)||!bool(value.mutation_committed)||!bool(value.cloud_receipt_requested)||!bool(value.eligible_for_receipt)||!bool(value.selection_required)||!bool(value.has_more)||!Array.isArray(value.items)||!Array.isArray(value.authorized_recipients)||value.authorized_recipients.length>100)fail();
  if(value.read_only?value.mutation_committed!==false||value.cloud_receipt_requested!==false:action!=='company_handoff_receipt'||value.mutation_committed!==true||value.cloud_receipt_requested!==true||value.state!=='recorded')fail();
  const validItem=item=>{
    if(ownerTag(item)){if(value.contact_delivery!=='owner_package_metadata_only')fail();checkedOwnerReceiverItem(item,fail);if(expected.recipientId&&item.recipient_id!==expected.recipientId)fail();return;}
    if(!exact(item,itemFields)||!channel(item.channel_id)||!hex(item.customer_scope_hash)||!hex(item.source_actor_scope_hash)||!['xiaohongshu','douyin','zhihu','wechat_channels','weixin','bilibili','bili','kuaishou'].includes(item.platform)||!identifier(item.recipient_id)||!safeLabel(item.recipient_name)||!safeLabel(item.purpose)||!integer(item.revision)||item.revision<1||!Object.hasOwn(labels,item.status)||!bool(item.current_consent_valid)||!bool(item.can_receipt)||!bool(item.historical_resource_receipt_recorded)||item.receipt_evidence_independently_verified!==false||item.contact_delivery!=='platform_reference_only'||!stamp(item.created_at)||!stamp(item.updated_at)||item.updated_at<item.created_at||item.status==='withdrawn'&&item.current_consent_valid||item.can_receipt&&(!item.current_consent_valid||item.status!=='submitted'))fail();
    if(expected.recipientId&&item.recipient_id!==expected.recipientId)fail();
  };
  const seenRecipients=new Set();
  for(const recipient of value.authorized_recipients){if(!exact(recipient,['id','name'])||!identifier(recipient.id)||!safeLabel(recipient.name)||seenRecipients.has(recipient.id))fail();seenRecipients.add(recipient.id);}
  if(action==='company_handoff_received_list'){
    if(value.read_only!==true||value.state!=='list'||value.item!==null||value.attempt!==null||value.original_operation!==null||value.original_execution_confirmed!==null||value.eligible_for_receipt!==false||!integer(value.offset)||value.offset!==(request.offset??0)||value.items.length>(request.limit??10)||value.items.length>15)fail();
    if(!request.recipient_id){if(value.selection_required!==true||value.selected_recipient_id!==null||value.total!==null||value.items.length||value.has_more||value.offset!==0)fail();}
    else if(value.selection_required!==false||value.selected_recipient_id!==request.recipient_id||!seenRecipients.has(request.recipient_id)||!integer(value.total)||value.items.length>Math.max(0,value.total-value.offset)||value.has_more!==(value.offset+value.items.length<value.total))fail();
    const seen=new Set();for(const item of value.items){validItem(item);if(item.recipient_id!==request.recipient_id||seen.has(item.channel_id))fail();seen.add(item.channel_id);}
    if(value.contact_delivery==='owner_package_metadata_only'&&!value.items.some(ownerTag))fail();
    return value;
  }
  if(!channel(request.channel_id)||value.items.length||value.authorized_recipients.length||value.selected_recipient_id!==null||value.selection_required!==false||value.total!==null||value.offset!==null||value.has_more!==false)fail();
  validItem(value.item);if(value.item.channel_id!==request.channel_id||value.contact_delivery!==(ownerTag(value.item)?'owner_package_metadata_only':'platform_reference_only'))fail();
  const attempt=value.attempt,original=value.original_operation;
  if(attempt!==null){
    if(!exact(attempt,['state','expected_revision','decision','created_at','updated_at','operation_action','idempotency_key'])||!['unknown','recorded'].includes(attempt.state)||!integer(attempt.expected_revision)||attempt.expected_revision<1||!decisions.includes(attempt.decision)||!stamp(attempt.created_at)||!stamp(attempt.updated_at)||attempt.updated_at<attempt.created_at||attempt.operation_action!=='acquisition_handoff_receipt'||!hex(attempt.idempotency_key)||value.item.revision<attempt.expected_revision)fail();
    if(action==='company_handoff_receipt'&&(attempt.expected_revision!==request.expected_revision||attempt.decision!==request.decision))fail();
    if(expected.attempt&&(attempt.idempotency_key!==expected.attempt.idempotency_key||attempt.expected_revision!==expected.attempt.expected_revision||attempt.decision!==expected.attempt.decision))fail();
  }else if(expected.attempt)fail();
  if(value.state==='not_attempted'){
    if(attempt!==null||original!==null||value.original_execution_confirmed!==null||value.eligible_for_receipt!==receiverCanReceipt(value.item)||value.read_only!==true||action==='company_handoff_receipt')fail();
  }else if(value.state==='unknown'){
    if(!attempt||attempt.state!=='unknown'||original!==null||value.original_execution_confirmed!==null||value.eligible_for_receipt!==false||value.read_only!==true)fail();
  }else if(value.state==='recorded'&&ownerTag(value.item)){
    if(!attempt||!exact(original,['channel_id','revision','original_event_hash'])||original.channel_id!==request.channel_id||original.revision!==attempt.expected_revision+1||original.revision>value.item.revision||!hex(original.original_event_hash)||value.original_execution_confirmed!==true||value.eligible_for_receipt!==false||!value.read_only&&attempt.state!=='recorded')fail();
  }else if(value.state==='recorded'){
    if(!attempt||!exact(original,['channel_id','revision','historical_status','occurred_at','historical_event_self_hash_verified','full_historical_chain_verified'])||original.channel_id!==request.channel_id||original.revision!==attempt.expected_revision+1||original.revision>value.item.revision||original.historical_status!==decisionStates[attempt.decision]||!stamp(original.occurred_at)||original.historical_event_self_hash_verified!==true||original.full_historical_chain_verified!==false||value.original_execution_confirmed!==true||value.eligible_for_receipt!==false||!value.read_only&&attempt.state!=='recorded'||attempt.decision==='accept'&&value.item.historical_resource_receipt_recorded!==true)fail();
  }else fail();
  return value;
}

export function companyReceiverScope(context={}){
  const user=context.user||{};
  return JSON.stringify([user.id,user.username,user.tenant_id,user.role,user.company_id,context.companyId,context.environmentId,context.deviceId,context.deviceGeneration,context.localWorkspace]);
}
const node=(tag,text='',className='')=>{const result=document.createElement(tag);result.textContent=String(text);if(className)result.className=className;return result;};

/* A normal company employee explicitly reports an existing customer/order association. */
function companyOrderLinkCapability(value){return exact(value,['contract','available','owner_package_only','company_staff_only','read_only_prepare','financial_receipt_verified','cooperation_policy_verified','auto_retry'])&&value.contract==='owner_company_order_link_v1'&&value.available===true&&value.owner_package_only===true&&value.company_staff_only===true&&value.read_only_prepare===true&&value.financial_receipt_verified===false&&value.cooperation_policy_verified===false&&value.auto_retry===false;}
function createCompanyOrderLinkUI({root,execute,getContext,current,setBusy,onFinished}){
 const scope=()=>JSON.stringify([companyReceiverScope(getContext()||{}),getContext()?.cloudEpoch,getContext()?.cloudCompanyId,getContext()?.cloudEnvironmentId,getContext()?.endpoint]);
 const storageScope=()=>{const c=getContext()||{},u=c.user||{};return JSON.stringify([u.id,u.username,u.tenant_id,u.company_id,c.companyId,c.environmentId,c.deviceId,c.localWorkspace]);};
 const opening=scope(),slot='fangyu:company-owner-order-link:v1:'+storageScope();
 let available=false,marker=null,storageBlocked=false,pending=false,serial=0,prepared=null,formState=null,statusChecked=false,message='';
 const recovery=node('section','','upgrade-operation-form'),status=node('p'),check=node('button','核对订单关联原操作','secondary'),finish=node('button','完成本次关联','secondary');recovery.hidden=true;check.type=finish.type='button';status.setAttribute('role','status');status.setAttribute('aria-live','polite');recovery.append(status,check,finish);root.append(recovery);
 const fresh=()=>current()&&scope()===opening;
 const staff=()=>getContext()?.localWorkspace===true&&['admin','operator'].includes(getContext()?.user?.role);
 const markerFields=['schema','scope','channel_id','order_no','idempotency_key','package_id','row_id','state'];
 const safeOrder=x=>typeof x==='string'&&x.length>0&&x.length<=128&&x.trim()===x&&!/[\u0000-\u001f\u007f]/.test(x);
 const validMarker=m=>exact(m,markerFields)&&m.schema===1&&m.scope===storageScope()&&channel(m.channel_id)&&safeOrder(m.order_no)&&hex(m.idempotency_key)&&hex(m.package_id)&&hex(m.row_id)&&['unknown','recorded','rejected'].includes(m.state);
 function restore(){try{const raw=localStorage.getItem(slot);if(raw===null)return;if(raw.length>2500)throw Error();const value=JSON.parse(raw);if(!validMarker(value))throw Error();marker=value;statusChecked=false;message='已有订单关联原操作，请先核对原号，不重新关联。';}catch{storageBlocked=true;message='订单关联原号存储待核对，停止新关联；原记录保留。';}}
 function persist(value){if(!validMarker(value))throw Error('订单关联原号范围未核实');marker=value;try{const raw=JSON.stringify(value);localStorage.setItem(slot,raw);if(localStorage.getItem(slot)!==raw)throw Error();}catch{storageBlocked=true;throw Error('未能先保留并核对原号，本次没有发起新关联。');}}
 function paint(){recovery.hidden=!marker&&!storageBlocked;status.textContent=message||'请先核对订单关联原操作。';check.disabled=!fresh()||!available||pending||storageBlocked||!marker;finish.disabled=!fresh()||pending||storageBlocked||!marker||!statusChecked||!['recorded','rejected'].includes(marker.state);if(formState){const {controls,prepare,confirm,commit,feedback}=formState;for(const field of controls)field.disabled=!!marker||storageBlocked;prepare.disabled=!fresh()||!available||pending||!!marker||storageBlocked;confirm.disabled=!fresh()||pending||!!marker||storageBlocked||!prepared;commit.disabled=confirm.disabled||!confirm.checked;feedback.textContent=pending?'正在核对本次明确操作…':marker?'先核对并完成原订单关联操作。':formState.message|| (prepared?'当前版本已核对；请明确确认这是公司报录关联，客户身份和款项未独立核验。':'先核对现有公司记录，尚未关联订单。');}}
 async function initialize(){restore();try{const value=await execute('workspace_state',{});if(!fresh())return;available=value?.status==='succeeded'&&companyOrderLinkCapability(value.result?.owner_company_order_link);}catch{available=false;}paint();}
 function checkedPreparation(v,request,item){const fail=()=>{throw Error('公司记录的版本或原号未通过核对。');};if(!exact(v,['contract','action','channel_id','claim_id','package_id','row_id','order_no','company_customer_binding_hash','binding_evidence_reference','evidence_reference','expected_revision','expected_business_revision','order_revision','idempotency_key','read_only','mutation_committed','auto_retry','association_independently_verified'])||v.contract!=='owner_company_order_link_preparation_v1'||v.action!=='company_handoff_order_link_prepare'||v.channel_id!==item.channel_id||v.claim_id!==item.claim_id||v.package_id!==item.package_id||v.row_id!==item.row_id||v.order_no!==request.order_no||v.binding_evidence_reference!==request.binding_evidence_reference||v.evidence_reference!==request.evidence_reference||!hex(v.company_customer_binding_hash)||!integer(v.expected_revision)||v.expected_revision<item.revision||!integer(v.expected_business_revision)||!integer(v.order_revision)||v.order_revision<1||!hex(v.idempotency_key)||v.read_only!==true||v.mutation_committed!==false||v.auto_retry!==false||v.association_independently_verified!==false)fail();return v;}
 function checkedOutcome(v,action,m){const fail=()=>{throw Error('订单关联原结果未通过核对；保留原号。');};if(!exact(v,['contract','action','channel_id','order_no','idempotency_key','state','item','original_operation','read_only','mutation_committed','auto_retry','company_reported_only','financial_receipt_verified','cooperation_policy_verified','verified_cash_cents','verified_paid_commission_cents'])||v.contract!=='owner_company_order_link_v1'||v.action!==action||v.channel_id!==m.channel_id||v.order_no!==m.order_no||v.idempotency_key!==m.idempotency_key||!['not_attempted','unknown','recorded','rejected'].includes(v.state)||v.auto_retry!==false||v.company_reported_only!==true||v.financial_receipt_verified!==false||v.cooperation_policy_verified!==false||v.verified_cash_cents!==null||v.verified_paid_commission_cents!==null)fail();if(action==='company_handoff_order_link_get'){if(v.read_only!==true||v.mutation_committed!==false)fail();}else if(v.read_only!==false||v.state!=='recorded'||v.mutation_committed!==true)fail();if(['recorded','rejected'].includes(v.state)){checkedOwnerReceiverItem(v.item,fail);const o=v.original_operation;if(v.item.channel_id!==m.channel_id||v.item.package_id!==m.package_id||v.item.row_id!==m.row_id||!exact(o,['payload_hash','channel_id','revision','original_event_hash'])||!hex(o.payload_hash)||o.channel_id!==m.channel_id||!integer(o.revision)||o.revision<1||o.revision>v.item.revision||(v.state==='recorded'?!hex(o.original_event_hash):o.original_event_hash!==null))fail();}else if(v.item!==null||v.original_operation!==null)fail();return v;}
 function render(formHost,value,item,valid){prepared=null;formState=null;serial++;if(!ownerTag(item))return;
  const section=node('details');section.append(node('summary','关联公司已有客户与订单'));formHost.append(section);
  if(!available||!staff()){section.append(node('p','当前版本或公司账号暂不能关联订单。'));return;}
  if(value.state==='unknown'||item.status!=='accepted'||item.receipt?.decision!=='accept'||item.receipt.authenticated_receiver_decision!==true||item.source_authorization.state!=='current_company_scope'||item.consent.status!=='granted'){section.append(node('p','先核对公司的独立接收记录与当前客户授权。'));return;}
  const form=node('form','','upgrade-operation-form'),controls=[],fields={};form.addEventListener('submit',event=>event.preventDefault());section.append(form,node('p','只关联公司已有客户与已有订单；这是公司报录，不代表客户身份或实收、分成付款已独立核验。','upgrade-muted'));
  for(const [name,title,max]of [['customer_id','公司已有客户编号（不是平台UID或昵称）',160],['order_no','公司已有订单编号',128],['binding_evidence_reference','客户对应的实际证据引用',41],['evidence_reference','订单关联的实际证据引用',41]]){const label=node('label',title),field=node('input');field.id='company-order-link-'+name;field.type='text';field.autocomplete='off';field.maxLength=max;field.setAttribute('aria-label',title);if(name.endsWith('reference'))field.placeholder='evidence: 或 document: 后接32位编号';label.append(field);form.append(label);fields[name]=field;controls.push(field);}
  const prepare=node('button','核对现有记录与版本','secondary'),confirm=node('input'),label=node('label','','upgrade-check'),commit=node('button','确认公司报录关联','secondary'),feedback=node('p');prepare.type=commit.type='button';prepare.id='company-order-link-prepare';commit.id='company-order-link-commit';confirm.type='checkbox';confirm.id='company-order-link-confirm';confirm.checked=false;label.append(confirm,node('span','我已核对公司现有客户、订单和实际证据，明确登记本次对应关系。'));feedback.setAttribute('role','status');form.append(prepare,label,commit,feedback);formState={controls,prepare,confirm,commit,feedback};
  const params=()=>({channel_id:item.channel_id,order_no:fields.order_no.value.trim(),customer_id:fields.customer_id.value.trim(),binding_evidence_reference:fields.binding_evidence_reference.value.trim(),evidence_reference:fields.evidence_reference.value.trim()});
  const signature=()=>JSON.stringify(params());const source=JSON.stringify(item);const here=()=>fresh()&&valid()&&source===JSON.stringify(item)&&formState?.prepare===prepare;
  for(const field of controls)field.addEventListener('input',()=>{if(marker)return;serial++;prepared=null;formState.message=null;confirm.checked=false;paint();});confirm.addEventListener('change',()=>paint());
  prepare.onclick=async()=>{if(!here()||pending||marker||storageBlocked||!available)return;const request=params();if(!identifier(request.customer_id)||!safeOrder(request.order_no)||[request.binding_evidence_reference,request.evidence_reference].some(x=>!/^(?:evidence|document):[a-f0-9]{32}$/.test(x))){feedback.textContent='请填写公司现有客户/订单编号及两项实际证据引用。';return;}const own=++serial,snapshot=signature();pending=true;prepared=null;formState.message=null;confirm.checked=false;paint();try{const answer=await execute('company_handoff_order_link_prepare',request);if(!here()||own!==serial||snapshot!==signature())return;if(answer?.status!=='succeeded')throw Error();prepared={value:checkedPreparation(answer.result,request,item),request,snapshot,source,serial:own};}catch{if(here()&&own===serial)formState.message='现有记录或版本暂未核实，未登记关联。';}finally{pending=false;paint();}};
  commit.onclick=async()=>{const p=prepared;if(!here()||pending||marker||storageBlocked||!available||!p||p.serial!==serial||p.snapshot!==signature()||p.source!==JSON.stringify(item)||!confirm.checked)return;const v=p.value,m={schema:1,scope:storageScope(),channel_id:item.channel_id,order_no:v.order_no,idempotency_key:v.idempotency_key,package_id:item.package_id,row_id:item.row_id,state:'unknown'};try{persist(m);}catch(error){message=error.message;paint();return;}pending=true;statusChecked=false;setBusy(true);for(const field of root.querySelectorAll('button,input,select'))field.disabled=true;message='正在登记公司报录关联；结果未知时只核对原号。';paint();const original=marker;try{const answer=await execute('company_handoff_order_link',{...p.request,expected_revision:v.expected_revision,expected_business_revision:v.expected_business_revision,order_revision:v.order_revision,idempotency_key:v.idempotency_key});if(!fresh()||marker!==original)return;if(answer?.status!=='succeeded')throw Error();checkedOutcome(answer.result,'company_handoff_order_link',m);message='公司报录关联已返回；请核对原操作后完成本次关联。';}catch{if(fresh()&&marker===original)message='本次关联结果尚未确认，原号已保留；只核对原号，不重新提交。';}finally{pending=false;setBusy(false);paint();}};
  paint();
 }
 check.onclick=async()=>{if(!fresh()||!available||!marker||storageBlocked||pending)return;const original=marker;pending=true;statusChecked=false;setBusy(true);message='正在核对订单关联原操作…';paint();try{const answer=await execute('company_handoff_order_link_get',{channel_id:original.channel_id,order_no:original.order_no,idempotency_key:original.idempotency_key});if(!fresh()||marker!==original)return;if(answer?.status!=='succeeded')throw Error();const value=checkedOutcome(answer.result,'company_handoff_order_link_get',original);if(['recorded','rejected'].includes(value.state)){persist({...original,state:value.state});statusChecked=true;message=value.state==='recorded'?'公司已登记该关联；财务款项未核实。可完成本次关联。':'原关联已明确拒绝；保留历史记录，可完成后重新核对正确资料。';}else message='原关联仍未确认；缺少记录不代表没有执行，不换行或编号。';}catch{if(fresh())message='原关联暂无法核对，继续保留原号；不会重新提交。';}finally{pending=false;setBusy(false);paint();}};
 finish.onclick=()=>{if(!fresh()||pending||storageBlocked||!marker||!statusChecked||!['recorded','rejected'].includes(marker.state))return;try{const raw=JSON.stringify(marker);if(localStorage.getItem(slot)!==raw)throw Error();localStorage.removeItem(slot);if(localStorage.getItem(slot)!==null)throw Error();}catch{storageBlocked=true;message='原号标记未能安全结束，继续保留；没有重新关联。';paint();return;}marker=null;prepared=null;serial++;statusChecked=false;message='本次关联已结束，后台原记录保留。';paint();onFinished();};
 return {initialize,render,blocked:()=>!!marker||storageBlocked};
}

export function createCompanyHandoffReceiverUI({createDialog,execute,getContext,openContacts=null,clearSensitiveContacts=()=>{}}){
  let generation=0,active=null,disposed=false;
  // Opaque scope/channel metadata only. A lost response never enables another ACK in this UI instance.
  const blocked=new Set(),scope=()=>companyReceiverScope(getContext()||{});
  const clear=(remove=true)=>{generation++;blocked.clear();const previous=active;active=null;if(previous){previous.release();for(const field of previous.root.querySelectorAll('input,textarea')){field.value='';field.checked=false;}previous.root.replaceChildren();if(remove){previous.root.close?.();previous.root.remove();}}};
  async function open(){
    if(disposed)return;clearSensitiveContacts();clear();const owner=scope(),own=++generation;
    const view=createDialog('公司收件箱',{onClose:()=>{if(active?.root===view.root)clear(false);}});let epoch=0,actorHash=null,recipientId='',detail=null,writing=false;const originalByChannel=new Map();
    active={root:view.root,release(){epoch++;detail=null;actorHash=null;recipientId='';writing=false;originalByChannel.clear();}};
    const current=()=>{if(active?.root===view.root&&scope()!==owner){clear();return false;}return !disposed&&generation===own&&active?.root===view.root&&view.current();};
    const report=(text,error=false)=>{if(current()){view.status.textContent=text;view.status.dataset.state=error?'error':'ready';}};
    const host=node('section','','upgrade-record-list');view.root.append(node('p','先选择本人获权的接收部门。这里只核对交接记录；授权资料包文件仍按约定人工转交，不从本页恢复联系方式。','upgrade-muted'),host);
    const linkUI=createCompanyOrderLinkUI({root:view.root,execute,getContext,current,setBusy:value=>{writing=value;},onFinished:()=>void list(recipientId)});
    const clearHost=()=>{for(const field of host.querySelectorAll('input,textarea')){field.value='';field.checked=false;}host.replaceChildren();};
    const button=(parent,text,fn)=>{const control=node('button',text,'secondary');control.type='button';control.onclick=()=>void fn(control);parent.append(control);return control;};
    const call=async(action,request,expected={},fresh=current)=>{
      if(!fresh())return null;
      const answer=await execute(action,request);
      if(!fresh())return null;
      if(answer?.status!=='succeeded'||!answer.result||typeof answer.result!=='object'){const error=Error('公司记录暂不可读，请核对权限和原操作。');error.mutation_committed=answer?.mutation_committed??answer?.error?.mutation_committed;throw error;}
      const value=checkedCompanyReceiver(answer.result,action,request,{...expected,actorHash});
      if(!fresh())return null;if(actorHash===null)actorHash=value.actor_scope_hash;return value;
    };
    async function list(id='',offset=0){
      if(!current()||writing)return;if(linkUI.blocked()){report('请先核对并结束订单关联原操作，暂不切换资料行。',true);return;}const ticket=++epoch,fresh=()=>current()&&ticket===epoch;detail=null;recipientId=id;clearHost();report('正在读取当前账号获权的公司接收范围…');
      try{
        const request=id?{recipient_id:id,offset,limit:10}:{};
        const value=await call('company_handoff_received_list',request,{},fresh);if(!value)return;
        const form=node('form','','upgrade-operation-form'),label=node('label','接收部门'),choice=node('select');choice.setAttribute('aria-label','接收部门');
        choice.append(new Option('请选择本人获权的部门',''));for(const row of value.authorized_recipients)choice.append(new Option(row.name,row.id));choice.value=id;label.append(choice);form.append(label);host.append(form);
        const choose=button(form,'读取所选部门',()=>{if(!current()||writing)return;if(!value.authorized_recipients.some(row=>row.id===choice.value)){report('请明确选择本人获权的接收部门。',true);return;}void list(choice.value);});
        form.addEventListener('submit',event=>{event.preventDefault();choose.onclick();});
        choice.addEventListener('change',()=>{if(!current())return;clearSensitiveContacts();epoch++;detail=null;for(const child of [...host.children])if(child!==form)child.remove();report('部门已变化，请点击读取所选部门。');});
        if(value.selection_required){report(value.authorized_recipients.length?'请选择接收部门，选择前未读取收件列表。':'当前账号没有获权的接收部门。');return;}
        report(`公司交接记录共 ${value.total} 条，包含当前状态与历史记录。`);
        if(!value.items.length)host.append(node('p','该范围当前没有公司交接记录。','upgrade-muted'));
        for(const item of value.items){const row=node('section','','upgrade-operation-form');row.append(node('h3',item.purpose),node('p',`${item.recipient_name} · ${ownerStateLabel(item)}`),node('p',`公司交接编号：${item.channel_id}`,'upgrade-muted'));button(row,'查看公司详情',()=>load(item.channel_id));host.append(row);}
        if(offset>0)button(host,'上一页',()=>list(id,Math.max(0,offset-10)));
        if(value.has_more)button(host,'下一页',()=>list(id,offset+value.items.length));
      }catch{if(fresh()){clearHost();report('公司收件范围暂不可读，请检查权限后重新读取。',true);button(host,'重新读取本人范围',()=>list());}}
    }
    async function load(id,originalOnly=false){
      if(!current()||writing||!channel(id))return;if(linkUI.blocked()){report('请先核对订单关联原操作，不换行或编号。',true);return;}const ticket=++epoch,fresh=()=>current()&&ticket===epoch,previous=detail?.item.channel_id===id?detail:null;
      clearSensitiveContacts();detail=null;clearHost();report(originalOnly?'正在按本人原操作核对公司回执…':'正在核对公司当前授权、版本和接收权限…');
      const action=originalOnly?'company_handoff_receipt_get':'company_handoff_received_detail';
      try{const value=await call(action,{channel_id:id},{recipientId,attempt:previous?.attempt||originalByChannel.get(id)},fresh);if(!value)return;detail=value;render(value);}
      catch{if(fresh()){report('当前记录尚未核实，请按原操作重新核对，暂勿再次提交。',true);button(host,'核对本人原操作',()=>load(id,true));button(host,'返回部门列表',()=>list(recipientId));}}
    }
    function render(value){
      if(!current())return;const item=value.item,id=item.channel_id,lock=id;clearHost();if(value.attempt)originalByChannel.set(id,value.attempt);
      const summary=node('section','','upgrade-operation-form');summary.append(node('h3',item.purpose));
      const facts=ownerTag(item)?[['接收部门',item.recipient_name],['当前公司状态',ownerStateLabel(item)],['来源同意声明',item.source_authorization.state==='current_company_scope'?'公司最后同步的认证来源声明有效':'公司最后同步的来源声明需核对'],['声明有效至',item.consent.valid_until?new Date(item.consent.valid_until*1000).toLocaleString('zh-CN'):'尚未同步有效声明'],['历史接收决定',item.receipt?({accept:'另一已认证主体记录接受',reject:'记录拒收',needs_information:'记录待补资料',duplicate:'重复线索待核对',existing_customer:'已有客户待核对'})[item.receipt.decision]:'尚无已核接收决定'],['证据独立核验','尚未独立核验'],['客户实收 / 分成到账','未核实 / 未核实'],['资料交付','文件仍走已约定方式；本页没有联系方式或文件下载']]:[['接收部门',item.recipient_name],['公司交接编号',id],['当前公司状态',labels[item.status]],['当前客户同意',item.current_consent_valid?'公司记录有效':'当前无有效同意'],['历史资源接收',item.historical_resource_receipt_recorded?'公司曾登记接收':'当前投影未见接受登记'],['证据独立核验','尚未独立核验'],['客户实收 / 分成到账','未核实 / 未核实'],['联系方式交付','平台交接历史仍是引用；联系方式需单独核对授权']];
      for(const [title,text]of facts){const row=node('p');row.append(node('strong',title+'：'),node('span',text));summary.append(row);}
      if(ownerTag(item)){const metadata=node('details');metadata.append(node('summary','原资料包与渠道核对'),node('p',`公司渠道 ${id}；原包 ${item.package_id}；原行 ${item.row_id}；当前声明版本 ${item.consent.version}。摘要仅作原记录关联，不证明远程原包或客户身份。`));summary.append(metadata);}
      host.append(summary);linkUI.render(host,value,item,()=>current()&&detail===value&&(!blocked.has(lock)||!!value.original_operation));button(host,'返回部门列表',()=>list(recipientId));
      if(!ownerTag(item)&&typeof openContacts==='function')button(host,'核对本人联系方式查看',()=>{
        if(!current()||detail?.item!==item)return;
        const original=JSON.stringify(getContext()||{}),selected=recipientId;
        // Opening the shared dialog closes this parent. Do not retain its current() fence.
        return openContacts({channelId:id,mode:'receiver',recipientId:item.recipient_id,purpose:item.purpose},{accept:()=>JSON.stringify(getContext()||{})===original&&selected===item.recipient_id});
      });
      if(value.attempt||blocked.has(lock)){
        blocked.add(lock);
        if(value.original_operation){const original=value.original_operation;host.append(node('p',`本人原操作已核对：${ownerTag(item)?({accept:'公司登记已接收',reject:'公司登记未接收',needs_information:'待补资料',duplicate:'重复线索待核对',existing_customer:'已有客户待核对'})[value.attempt.decision]:labels[original.historical_status]} · 原记录版本 ${original.revision}。该历史记录与当前授权分开保留。`,'upgrade-muted'));report('已核对本人原操作；不会再次提交接收决定。');}
        else report('本人原操作结果仍待核对。缺少回执不能判断尚未执行；暂勿再次提交。',true);
        if(value.attempt)host.append(node('p',`本人原操作编号：${value.attempt.idempotency_key}`,'upgrade-muted'));
        button(host,'核对本人原操作',()=>load(id,true));return;
      }
      if(!value.eligible_for_receipt){report('当前账号或当前授权不允许登记接收。');return;}
      const form=node('form','','upgrade-operation-form');form.addEventListener('submit',event=>event.preventDefault());host.append(form);
      const decisionLabel=node('label','处理决定'),decision=node('select');decision.setAttribute('aria-label','处理决定');for(const [key,text]of [['accept','接受处理'],['reject','拒绝接收'],['needs_information','需要补充资料'],['duplicate','疑似重复线索'],['existing_customer','疑似已有客户']])decision.append(new Option(text,key));decision.value='accept';decisionLabel.append(decision);form.append(decisionLabel);
      const reasonLabel=node('label','拒收原因'),reason=node('select');reason.setAttribute('aria-label','拒收原因');for(const [key,text]of [['not_qualified','线索不符合条件'],['outside_service_area','超出服务区域']])reason.append(new Option(text,key));reason.value='not_qualified';reasonLabel.append(reason);reasonLabel.hidden=true;form.append(reasonLabel);
      const evidenceLabel=node('label','实际证据引用'),evidence=node('input');evidence.type='text';evidence.autocomplete='off';evidence.maxLength=41;evidence.placeholder='evidence: 或 document: 后接32位编号';evidence.setAttribute('aria-label','实际证据引用');evidenceLabel.append(evidence);form.append(evidenceLabel);
      const confirmationLabel=node('label','','upgrade-check'),confirmation=node('input');confirmation.type='checkbox';confirmation.checked=false;confirmation.setAttribute('aria-label','确认本次接收决定');confirmationLabel.append(confirmation,node('span','我已核对当前客户同意、接收部门、处理决定与实际证据。'));form.append(confirmationLabel);
      const validEvidence=()=>/^(?:evidence|document):[a-f0-9]{32}$/.test(evidence.value.trim());
      const submit=button(form,'确认登记本次决定',()=>ack());
      const update=()=>{confirmation.checked=false;reasonLabel.hidden=decision.value!=='reject';submit.disabled=true;};
      decision.addEventListener('change',update);reason.addEventListener('change',update);evidence.addEventListener('input',update);confirmation.addEventListener('change',()=>{submit.disabled=!current()||writing||!confirmation.checked||!validEvidence();});submit.disabled=true;
      report('当前可由本人登记处理决定；填写证据并手动确认后才会提交。');
      async function ack(){
        if(!current()||writing||linkUI.blocked()||detail!==value||blocked.has(lock)||!value.eligible_for_receipt||!confirmation.checked||!validEvidence()||!decisions.includes(decision.value))return;
        const request={channel_id:id,expected_revision:item.revision,decision:decision.value,evidence_reference:evidence.value.trim()};
        if(request.decision==='reject'){if(!['not_qualified','outside_service_area'].includes(reason.value))return;request.reason_code=reason.value;}else if(request.decision!=='accept')request.reason_code=request.decision;
        const ticket=++epoch,fresh=()=>current()&&ticket===epoch;writing=true;blocked.add(lock);for(const control of host.querySelectorAll('button,input,select'))control.disabled=true;report('正在登记本次决定；结果未知时只核对原操作。');
        try{const answer=await call('company_handoff_receipt',request,{recipientId},fresh);if(!answer)return;detail=answer;render(answer);}
        catch(error){if(fresh()){detail=null;clearHost();if(error.mutation_committed===false){blocked.delete(lock);report('后台明确拒绝本次提交。请重新读取当前详情并核对条件。',true);button(host,'重新读取当前详情',()=>load(id));}else{report('本次结果尚未确认。请按本人原操作核对，暂勿再次提交。',true);button(host,'核对本人原操作',()=>load(id,true));}button(host,'返回部门列表',()=>list(recipientId));}}
        finally{if(fresh())writing=false;}
      }
    }
    await linkUI.initialize();if(current())await list();
  }
  return {open,reset(){clear();},dispose(){disposed=true;clear();blocked.clear();}};
}


/* Normal company admins configure a separate partner scope; no partner credential enters this UI. */
export function createOriginPartnerAdminUI({host,execute,getContext}){
 const writes=['owner_origin_subject_bind','owner_origin_partner_save','owner_origin_admission_set'],flags=['auto_retry','remote_original_package_verified','platform_delivery_verified','attribution_confirmed','settlement_active','financial_receipt_verified','cooperation_policy_verified'];
 const username=x=>typeof x==='string'&&/^[A-Za-z0-9_.@-]{3,80}$/.test(x),subject=x=>typeof x==='string'&&/^su_[a-f0-9]{32}$/.test(x),admission=x=>typeof x==='string'&&/^oa_[a-f0-9]{32}$/.test(x),instance=x=>typeof x==='string'&&/^[a-f0-9]{32}$/.test(x);
 const canonical=x=>Array.isArray(x)?'['+x.map(canonical).join(',')+']':x&&typeof x==='object'?'{'+Object.keys(x).sort().map(k=>JSON.stringify(k)+':'+canonical(x[k])).join(',')+'}':JSON.stringify(x);
 const digest=async x=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(canonical(x))))).map(x=>x.toString(16).padStart(2,'0')).join('');
 const known=new Map();let serial=0,busy=null;
 const context=()=>{const c=getContext();return c&&c.localWorkspace===false&&c.user?.role==='admin'&&username(c.user.username)&&typeof c.companyId==='string'&&typeof c.environmentId==='string'?c:null;};
 const namespace=c=>JSON.stringify([c.companyId,c.environmentId,c.user.username]);
 const fresh=(c,t)=>{const now=context();return now&&now.user===c.user&&now.epoch===c.epoch&&namespace(now)===namespace(c)&&serial===t;};
 const node=(tag,text)=>{const x=document.createElement(tag);if(text!==undefined)x.textContent=text;return x;};
 const output=node('p','先创建合作账号，再按原版本配置主体与准入。该账号不能登录员工工作台。');output.setAttribute('role','status');
 const details=node('pre');details.setAttribute('aria-label','公司配置安全结果');
 const fail=()=>{throw Error('公司配置回执范围不匹配，请保留原操作编号核对。');};
 function record(value,action,c,k){
  const keys=action===writes[0]?['subject_id','username','mapping_version','operation_id','state']:action===writes[1]?['username','subject_id','account_version','access_class','disabled','operation_id','state']:['admission','operation_id','state'];
  if(!exact(value,keys)||!hex(value.operation_id)||value.state!=='recorded')fail();
  if(action===writes[0]&&(!subject(value.subject_id)||!username(value.username)||!integer(value.mapping_version)||value.mapping_version<1))fail();
  if(action===writes[1]&&(!username(value.username)||!subject(value.subject_id)||!integer(value.account_version)||value.account_version<1||value.access_class!=='owner_origin_only'||!bool(value.disabled)))fail();
  if(action===writes[2]){const a=value.admission;if(!exact(a,['admission_id','version','company_id','environment_id','subject_id','subject_mapping_version','username','instance_id','recipient_id','local_recipient_label_digest','local_purpose_digest','expires_at','revoked'])||!admission(a.admission_id)||!integer(a.version)||a.version<1||a.company_id!==c.companyId||a.environment_id!==c.environmentId||!subject(a.subject_id)||!integer(a.subject_mapping_version)||a.subject_mapping_version<1||!username(a.username)||!instance(a.instance_id)||!identifier(a.recipient_id)||!hex(a.local_recipient_label_digest)||!hex(a.local_purpose_digest)||!integer(a.expires_at)||a.expires_at<=0||!bool(a.revoked))fail();}
  if(k?.request){const r=k.request;if(action!==writes[2]&&value.username!==r.username||action===writes[0]&&(value.mapping_version!==r.expected_mapping_version+1||r.subject_id!==null&&value.subject_id!==r.subject_id)||action===writes[1]&&(value.subject_id!==r.subject_id||value.account_version!==r.expected_account_version+1||value.disabled!==r.disabled))fail();
   if(action===writes[2]){const a=value.admission;if(a.username!==r.username||a.instance_id!==r.instance_id||a.recipient_id!==r.recipient_id||a.local_recipient_label_digest!==r.local_recipient_label_digest||a.local_purpose_digest!==r.local_purpose_digest||a.version!==r.expected_version+1||a.expires_at!==r.expires_at||a.revoked!==r.revoked||r.admission_id!==null&&a.admission_id!==r.admission_id)fail();}}
  return value;
 }
 async function checked(value,action,c,k){
  const dataKeys=action==='owner_origin_admin_status'?['operation','record']:action===writes[0]?['subject_id','username','mapping_version','operation_id','state']:action===writes[1]?['username','subject_id','account_version','access_class','disabled','operation_id','state']:['admission','operation_id','state'];
  if(!exact(value,['contract','company_id','environment_id',...dataKeys,'read_only','mutation_committed',...flags])||value.contract!=='fangyu-workspace-v1'||value.company_id!==c.companyId||value.environment_id!==c.environmentId||flags.some(f=>value[f]!==false))fail();
  if(action!=='owner_origin_admin_status'){if(value.read_only!==false||value.mutation_committed!==true)fail();return record(Object.fromEntries(dataKeys.map(key=>[key,value[key]])),action,c,k);}
  const o=value.operation;if(value.read_only!==true||value.mutation_committed!==false||!exact(o,['operation_id','operation_action','idempotency_key','state','mutation_committed','result_digest','reason_code','auto_retry'])||!hex(o.operation_id)||o.operation_action!==k.action||o.idempotency_key!==k.key||o.auto_retry!==false||!['unknown','recorded','rejected'].includes(o.state))fail();
  if(o.state==='unknown'){if(o.mutation_committed!==null||o.result_digest!==null||value.record!==null||o.reason_code!=='OPERATION_UNKNOWN')fail();return null;}
  if(o.state==='rejected'){if(o.mutation_committed!==false||value.record!==null||o.result_digest!==null||typeof o.reason_code!=='string'||!/^[A-Z_]{1,80}$/.test(o.reason_code))fail();return {state:'rejected',reason_code:o.reason_code};}
  const result=record(value.record,k.action,c,k);if(o.mutation_committed!==true||o.reason_code!==null||!hex(o.result_digest)||result.operation_id!==o.operation_id||await digest(result)!==o.result_digest)fail();return result;
 }
 const getPending=()=>{const c=context();return c?known.get(namespace(c)):null;};
 function controls(){const blocked=!context()||!!busy||!!getPending();for(const form of forms.values())for(const button of form.querySelectorAll('button'))button.disabled=blocked;check.disabled=!context()||!!busy;finish.disabled=!context()||!!busy||!getPending()?.terminal;}
 const forms=new Map(),fields=new Map();
 function input(form,name,label,type='text',optional=false){const l=node('label',label),x=node('input');x.type=type;x.name=name;x.required=!optional;if(type==='number'){x.min='0';x.step='1';}if(type==='password'){x.autocomplete='new-password';x.maxLength=256;}x.setAttribute('aria-label',label);l.append(x);form.append(l);fields.set(form.dataset.action+':'+name,x);return x;}
 const specs=[{action:writes[0],title:'绑定公司主体',fields:[['username','公司账号'],['subject_id','已有公司主体编号（首次留空）','text',true],['expected_mapping_version','原主体版本','number']]},{action:writes[1],title:'更新合作账号',fields:[['username','合作账号'],['subject_id','公司主体编号'],['expected_account_version','原账号版本','number'],['password','新密码（不更改则留空）','password',true],['disabled','停用合作账号','checkbox',true]]},{action:writes[2],title:'配置原资料包准入',fields:[['admission_id','原准入编号（首次留空）','text',true],['username','合作账号'],['instance_id','本机实例编号'],['recipient_id','公司接收部门编号'],['local_recipient_label_digest','原包接收部门摘要'],['local_purpose_digest','原包用途摘要'],['expected_version','原准入版本','number'],['expires_at','到期时间（秒）','number'],['revoked','撤销准入','checkbox',true]]}];
 function request(form){const action=form.dataset.action,values={};for(const spec of specs.find(s=>s.action===action).fields){const [name,,type]=spec,x=fields.get(action+':'+name);values[name]=type==='checkbox'?x.checked:type==='number'?x.value.trim()===''?NaN:Number(x.value):x.value.trim();if(type==='password')values[name]=x.value||null;}
  if(!username(values.username))throw Error('请填写公司原账号。');for(const name of ['expected_mapping_version','expected_account_version','expected_version'])if(Object.hasOwn(values,name)&&!integer(values[name]))throw Error('请填写已核对的原版本，首次为 0。');
  if(action===writes[0]){values.subject_id=values.subject_id||null;if(values.subject_id!==null&&!subject(values.subject_id))throw Error('公司主体编号格式不正确。');}
  if(action===writes[1]&&(!subject(values.subject_id)||values.password!==null&&(values.password.length<12||values.password.length>256)))throw Error('请核对公司主体及新密码。');
  if(action===writes[2]){values.admission_id=values.admission_id||null;if(values.admission_id!==null&&!admission(values.admission_id)||!instance(values.instance_id)||!identifier(values.recipient_id)||!hex(values.local_recipient_label_digest)||!hex(values.local_purpose_digest)||!integer(values.expires_at)||values.expires_at<=0)throw Error('请按原资料包核对准入信息。');}
  return values;
 }
 async function write(event,form){event.preventDefault();const c=context();if(!c||busy||getPending())return;let values;try{values=request(form);}catch(e){output.textContent=e.message;return;}
  const action=form.dataset.action,key=Array.from(crypto.getRandomValues(new Uint8Array(32))).map(x=>x.toString(16).padStart(2,'0')).join(''),safe=Object.fromEntries(Object.entries(values).filter(([name])=>name!=='password')),pending={action,key,request:safe,terminal:false};known.set(namespace(c),pending);const t=++serial;busy=t;originalAction.value=action;originalKey.value=key;details.textContent=JSON.stringify({operation_action:action,idempotency_key:key},null,2);output.textContent='正在登记公司配置；请保留原操作编号。';controls();
  const secret=fields.get(action+':password');if(secret)secret.value='';
  try{const answer=await execute(action,{...values,idempotency_key:key});values.password=null;if(!fresh(c,t))return;const value=await checked(answer,action,c,pending);if(!fresh(c,t))return;pending.terminal=true;details.textContent=JSON.stringify(value,null,2);output.textContent='公司配置已登记。请保存原版本与编号，再确认结束。';}
  catch{values.password=null;if(fresh(c,t))output.textContent='配置结果未确认。请核对原操作，暂勿重新登记或更换编号。';}
  finally{values.password=null;if(busy===t)busy=null;controls();}
 }
 for(const spec of specs){const form=node('form');form.dataset.action=spec.action;form.className='upgrade-operation-form';form.append(node('h3',spec.title));for(const args of spec.fields)input(form,...args);const b=node('button','登记'+spec.title);b.type='submit';form.append(b);form.addEventListener('submit',event=>void write(event,form));forms.set(spec.action,form);host.append(form);}
 const original=node('section');original.append(node('h3','核对本人原配置'));const originalAction=node('select');originalAction.setAttribute('aria-label','原配置操作');for(const action of writes)originalAction.append(new Option(specs.find(x=>x.action===action).title,action));originalAction.value=writes[0];const originalKey=node('input');originalKey.setAttribute('aria-label','原配置操作编号');original.append(originalAction,originalKey);
 const check=node('button','核对原配置'),finish=node('button','确认本次配置已结束');check.type=finish.type='button';original.append(check,finish);host.append(original,output,details);
 check.addEventListener('click',async()=>{const c=context();if(!c||busy)return;const held=getPending(),action=originalAction.value,key=originalKey.value.trim();if(!writes.includes(action)||!hex(key)||held&&(held.action!==action||held.key!==key)){output.textContent='请保留并核对当前本人原操作编号。';return;}
  const pending=held||{action,key,terminal:false};known.set(namespace(c),pending);const t=++serial;busy=t;controls();try{const answer=await execute('owner_origin_admin_status',{operation_action:action,idempotency_key:key});if(!fresh(c,t))return;const value=await checked(answer,'owner_origin_admin_status',c,pending);if(!fresh(c,t))return;pending.terminal=!!value;details.textContent=value?JSON.stringify(value,null,2):JSON.stringify({operation_action:action,idempotency_key:key},null,2);output.textContent=value?.state==='rejected'?'原配置已明确拒绝，本次未写入业务配置；请核对原版本后确认结束。':value?'原配置结果已核对，请保存后确认结束。':'原配置仍未确认；缺少记录不等于尚未执行。';}catch{if(fresh(c,t))output.textContent='原配置尚不可核对，请保留原编号。';}finally{if(busy===t)busy=null;controls();}});
 finish.addEventListener('click',()=>{const c=context(),p=getPending();if(!c||busy||!p?.terminal)return;known.delete(namespace(c));output.textContent='已保留公司原记录，可明确登记下一项配置。';controls();});
 return {sync(){const p=getPending();if(p){originalAction.value=p.action;originalKey.value=p.key;output.textContent=p.terminal?'原配置已核对，请保存结果后确认结束。':'仍有本人原配置未确认，请先核对原编号。';}controls();},reset(){serial++;busy=null;for(const x of fields.values()){if(x.type==='checkbox')x.checked=false;else x.value='';}originalKey.value='';details.textContent='';output.textContent='请在公司管理员原范围核对配置。';controls();}};
}
