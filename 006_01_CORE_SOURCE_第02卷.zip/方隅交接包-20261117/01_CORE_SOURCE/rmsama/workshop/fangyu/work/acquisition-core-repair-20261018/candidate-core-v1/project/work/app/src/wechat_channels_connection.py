"""Explicit wx_channel local connection; never silently installs certificates/proxy."""
import hashlib, json, os, subprocess, threading, urllib.error, urllib.request
from pathlib import Path
from urllib.parse import urlsplit

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,req,fp,code,msg,headers,newurl):return None

def endpoint_for_port(port):
    if isinstance(port,bool):raise ValueError('端口应为1024到65535之间的整数')
    try:value=int(str(port))
    except (TypeError,ValueError):raise ValueError('端口应为1024到65535之间的整数') from None
    if not 1024<=value<=65535:raise ValueError('端口应为1024到65535之间的整数')
    return 'http://127.0.0.1:'+str(value)

def local_get(endpoint,path,timeout=3):
    parsed=urlsplit(str(endpoint))
    try:port=parsed.port
    except ValueError:raise ValueError('本机连接地址无效') from None
    if parsed.scheme!='http' or parsed.hostname not in ('127.0.0.1','localhost','::1') or parsed.username or parsed.password or parsed.path not in ('','/') or parsed.query or parsed.fragment or not port or not 1024<=port<=65535:
        raise ValueError('只允许指定端口的本机HTTP连接，不允许外网、凭据或附加路径')
    if not path.startswith('/api/') or '://' in path:raise ValueError('本机接口路径无效')
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirect())
    request=urllib.request.Request(str(endpoint).rstrip('/')+path,headers={'Accept':'application/json'})
    try:
        with opener.open(request,timeout=timeout) as response:
            raw=response.read(1048577)
            if len(raw)>1048576:raise ValueError('本机工具返回内容过大')
    except urllib.error.HTTPError as exc:
        if 300<=exc.code<400:raise ValueError('本机工具返回重定向，已停止；请核对端口') from None
        raise ValueError('本机工具接口返回HTTP '+str(exc.code)+'，请核对工具版本和端口') from None
    except (urllib.error.URLError,TimeoutError,OSError):raise ValueError('未能连接本机工具，请先启动工具并确认端口，随后检查连接') from None
    try:value=json.loads(raw)
    except (ValueError,UnicodeError):raise ValueError('端口返回的不是有效JSON，可能不是视频号工具') from None
    if not isinstance(value,dict):raise ValueError('本机工具返回格式不兼容')
    return value

def status_clients(payload):
    if payload.get('code')!=0 or isinstance(payload.get('code'),bool):raise ValueError('视频号工具状态接口未返回成功，请核对工具版本')
    data=payload.get('data')
    if not isinstance(data,dict) or type(data.get('clients')) is not int or not isinstance(data.get('client_list'),list):raise ValueError('视频号状态协议不兼容，请使用支持client_list的工具版本')
    raw=data['client_list']
    if data['clients']!=len(raw):raise ValueError('客户端数量与列表不一致，请稍后重试')
    result=[]
    for item in raw:
        if not isinstance(item,dict) or not isinstance(item.get('remote_addr'),str) or not item['remote_addr'].strip():raise ValueError('客户端缺少临时连接标识，请重新打开视频号页面')
        result.append({'id':item['remote_addr'][:256],'page_path':str(item.get('page_path',''))[:256],**{k:item.get(k) is True for k in ('api_ready','fresh','api_functional','api_functional_fresh','supports_search','supports_comment')}})
    return result

class WechatChannelsConnection:
    def __init__(self,server,runtime):
        self.server=server;self.runtime=Path(runtime);self.lock=threading.RLock();self.process=None
    def context(self,user,ident):
        context=self.server.core.handle('account_browser_context',{'id':ident},user)
        if context['account']['platform']!='wechat_channels':raise ValueError('请选择视频号连接账号')
        return context
    def config_path(self,context):
        return self.server.core.store.directory/'accounts'/context['tenant']/context['account']['id']/'wechat_channels.json'
    def tool(self):
        return self.runtime/'wx_channel.exe'
    def launch_allowed(self):
        marker=self.runtime/'workbench-loopback-build.json'
        if not marker.is_file() or not self.tool().is_file():return False
        try:
            record=json.loads(marker.read_text('utf-8'))
            return record.get('loopback_only') is True and record.get('exe_sha256')==hashlib.sha256(self.tool().read_bytes()).hexdigest()
        except (OSError,ValueError):return False
    def base(self,context):
        a=context['account'];endpoint=a.get('endpoint') or endpoint_for_port(2026)
        port=urlsplit(endpoint).port
        return {'endpoint':endpoint,'port':port,'authenticated':False,'verified':False,'identity_verified':False,'clients':[],'bound_client_id':a.get('bound_client_id',''),'tool_available':self.tool().is_file(),'launch_allowed':self.launch_allowed(),'launch_note':'原版工具的API可能监听全部网卡，并可能安装证书/调整系统代理；工作台不会自动启动。','tool_path':str(self.tool()),'single_session':True,'account_isolation':False,'binding_kind':'temporary_connection_address','status':'disconnected','message':'尚未连接视频号本机工具。','next_action':'先查看连接说明，再显式启动工具'}
    def persist(self,context,state,bound=None,*,_preview_call=None):
        if _preview_call is not None:
            self._check_preview(_preview_call,context);_preview_call.before_io()
        core=self.server.core
        with core.lock:
            if _preview_call is not None:_preview_call.check()
            current=core.store.get('accounts',context['account']['id'])
            if not current:return
            current.update(status='connected_unverified' if state['status']=='connected_unverified' else 'unverified',connection_message=state['message'])
            if bound is not None:current['bound_client_id']=bound
            core.store.put('accounts',current)
            if _preview_call is not None:_preview_call.accept_saved(current)
            if bound is not None:
                path=self.config_path(context);path.parent.mkdir(parents=True,exist_ok=True)
                path.write_text(json.dumps({'endpoint':current.get('endpoint') or endpoint_for_port(2026),'bound_client_id':bound},ensure_ascii=False),'utf-8')
    def configure(self,user,data,*,_preview_call=None):
        with self.lock:
            context=self.context(user,data.get('id'));endpoint=endpoint_for_port(data.get('port',2026));core=self.server.core
            if _preview_call is not None:self._check_preview(_preview_call,context)
            with core.lock:
                if any(t.get('account_id')==data['id'] and (t['id'] in core.running or t['id'] in core.sequences) for t in core.store.list('tasks',context['tenant'])):raise ValueError('请先停止此账号的采集任务，再修改端口')
                if _preview_call is not None:_preview_call.check()
                account=core.store.get('accounts',data['id'])
                account.update(endpoint=endpoint,bound_client_id='',status='unverified');core.store.put('accounts',account)
                if _preview_call is not None:_preview_call.accept_saved(account)
                context['account']=account;path=self.config_path(context);path.parent.mkdir(parents=True,exist_ok=True)
                path.write_text(json.dumps({'endpoint':endpoint,'bound_client_id':''}),'utf-8')
            return self.status(user,data,_preview_call=_preview_call)
    def open_folder(self,user,data):
        context=self.context(user,data.get('id'))
        if not self.runtime.is_dir():raise ValueError('视频号工具尚未装配，请使用包含视频号组件的新版安装包')
        os.startfile(str(self.runtime))
        return {'opened':True,'path':str(self.runtime),'message':'已打开备用工具文件夹。原版API可能监听全部网卡，运行还可能安装证书、调整系统代理；请先阅读说明。本轮工作台仅连接你已自行运行的本机服务。'}
    def launch(self,user,data):
        context=self.context(user,data.get('id'))
        if data.get('acknowledge_system_changes') is not True:raise ValueError('启动视频号工具可能安装本机证书并调整系统代理；请先阅读说明并明确确认')
        with self.lock:
            if not self.launch_allowed():raise ValueError('已下载的原版工具可能向局域网开放接口，工作台暂不代为启动。请等待仅本机监听版本；当前可以检查你已自行运行的服务。')
            if not self.tool().is_file():raise ValueError('未找到视频号工具，请安装包含此组件的版本')
            if self.process and self.process.poll() is None:
                state=self.base(context);state.update(status='starting',message='本次启动的工具仍在运行。请在Windows微信打开视频号页面，然后检查连接。',next_action='检查连接');return state
            api_port=self.base(context)['port']
            if api_port<=1024:raise ValueError('启动工具的API端口须为1025到65535；代理端口会使用API端口减1')
            directory=self.server.core.store.directory/'wechat-channels-tool';directory.mkdir(parents=True,exist_ok=True)
            config=directory/'config.yaml'
            config.write_text('cloud_enabled: false\nradar_enabled: false\nauto_open_channels: false\n','utf-8')
            with (directory/'tool.log').open('ab') as log:
                self.process=subprocess.Popen([str(self.tool()),'--config',str(config),'--port',str(api_port-1)],cwd=self.runtime,stdin=subprocess.DEVNULL,stdout=log,stderr=log,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
            state=self.base(context);state.update(status='starting',message='已请求启动视频号工具。它可能需要证书或系统代理授权；随后在Windows微信打开视频号页面并检查连接。',next_action='在微信中打开视频号，再检查连接')
            self.persist(context,state);return state
    def _check_preview(self,call,context):
        from assistant.owner_channels_read import _OwnerChannelsCall
        if type(call) is _OwnerChannelsCall:
            if call.manager is not self or context['account']['id']!=call.account_id:
                raise ValueError('owner_preview_scope_invalid')
            call.check();return
        from assistant.wechat_preview_service import _WechatPreviewCall
        if (type(call) is not _WechatPreviewCall or call.manager is not self
                or context['account']['id']!=call.account_id):raise ValueError('preview_scope_invalid')
        call.check()

    def status(self,user,data,*,_preview_call=None):
        with self.lock:
            context=self.context(user,data.get('id'));state=self.base(context)
            if _preview_call is not None:self._check_preview(_preview_call,context)
            try:
                getter=local_get if _preview_call is None else _preview_call.local_get
                clients=status_clients(getter(state['endpoint'],'/api/channels/status',timeout=3))
                state['clients']=clients;state['server_online']=True
                if len(clients)>1:
                    state.update(status='failed',message='检测到多个微信视频号页面。此工具不能指定账号，请只保留一个视频号窗口后再检查。',next_action='关闭多余视频号页面，再检查连接')
                elif not clients:
                    state.update(status='server_online',message='本机工具已启动，但尚未连接微信视频号页面；这不代表已登录。',next_action='在Windows微信中打开视频号页面')
                else:
                    client=clients[0];bound=state['bound_client_id']
                    if bound and bound!=client['id']:
                        state.update(status='failed',message='微信页面连接已改变，已暂停使用旧绑定。核对当前微信后，保存连接设置以重新确认。',next_action='核对微信账号后保存设置')
                    elif not client['fresh'] or not client['api_ready']:
                        state.update(status='server_online',message='微信视频号页面已出现，但连接尚未就绪。请保持页面打开并稍后检查。',next_action='保持视频号页面打开，再检查连接')
                    else:
                        state.update(status='connected_unverified',bound_client_id=client['id'],message='已连接唯一视频号页面；软件尚不能核实微信身份，请确认电脑微信是你要使用的账号。',next_action='确认微信身份后，可尝试采集')
                        self.persist(context,state,bound=client['id'],_preview_call=_preview_call)
                        return state
            except ValueError as exc:
                state.update(status='disconnected',message=str(exc),next_action='确认工具正在运行、API端口正确，再检查连接')
            self.persist(context,state,_preview_call=_preview_call);return state
