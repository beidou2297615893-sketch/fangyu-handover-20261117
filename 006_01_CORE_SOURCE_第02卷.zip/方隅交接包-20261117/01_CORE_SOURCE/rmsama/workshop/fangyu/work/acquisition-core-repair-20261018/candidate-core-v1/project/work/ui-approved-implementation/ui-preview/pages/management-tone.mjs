export const toneChoices=Object.freeze({friendly:'自然友好',concise:'简洁直接',patient:'耐心解答'});
const focusChoices=Object.freeze({budget:'预算',moveIn:'入住时间',housing:'房源匹配'});
const descriptions={friendly:'亲切清楚',concise:'直奔重点',patient:'细致耐心'};
const escape=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const icon=(file,cls='')=>`<img class="mt-icon ${cls}" src="/assets/${file}" alt="" aria-hidden="true">`;
const defaults=()=>({identity:'',tone:'friendly',salutation:'你好',focus:Object.keys(focusChoices)});
function line(value,max,label){
  if(typeof value!=='string'||value.length>max||/[\u0000-\u001f\u007f\u2028\u2029]/.test(value))throw Error(`${label}最多${max}字，且只能填写一行。`);
  return value.trim();
}
function values(preferences={}){
  const identity=line(preferences.identity??'',80,'真实身份'),salutation=line(preferences.salutation??'你好',20,'开场称呼');
  const tone=preferences.tone??'friendly',focus=preferences.focus??Object.keys(focusChoices);
  if(!Object.hasOwn(toneChoices,tone))throw Error('请选择自然友好、简洁直接或耐心解答。');
  if(!Array.isArray(focus)||focus.some(key=>!Object.hasOwn(focusChoices,key)))throw Error('表达重点只能选择预算、入住时间或房源匹配。');
  return {identity,tone,salutation,focus:Object.keys(focusChoices).filter(key=>focus.includes(key))};
}
// Reuses the real-identity validation and rental-question wording of reply-templates.mjs.
// This is a local deterministic template. Calling it never saves, applies or sends text.
export function tonePreview(preferences={}){
  const p=values(preferences);if(!p.identity)throw Error('请先填写向客户说明的真实身份。');
  const greeting=p.salutation?`${p.salutation}${/[，,。.!！?？、;；:：]$/.test(p.salutation)?'':'，'}`:'';
  const question=['budget','moveIn'].filter(key=>p.focus.includes(key)).map(key=>focusChoices[key]).join('和');
  const housing=p.focus.includes('housing'),intro=`${greeting}我是${p.identity}。`;
  if(p.tone==='concise')return `${intro}${question?`方便确认${question}吗？`:'方便确认你的租房需求吗？'}${housing?'我会据此核对匹配房源。':''}`;
  if(p.tone==='patient')return `${intro}看到你的租房需求，${question?`可以先说说你的${question}，`:'可以先说说你想找什么样的房子，'}${housing?'我会逐项核对合适的房源，再与你沟通。':'我们再一起确认具体安排。'}`;
  return `${intro}看到你在找房，${question?`想先了解一下你的${question}，`:''}${housing?'我帮你核对合适的房源。':question?'我们再一起确认下一步。':'方便聊聊你的租房需求吗？'}`;
}
const username=s=>String(s.user||s.session?.user?.username||'');
const storeId=s=>String(s.storeId||(s.connection==='preview'?s.store:'')||'');
const scope=s=>JSON.stringify([s.connection,username(s),s.session?.user?.username||'',storeId(s)]);
const authenticated=s=>s.connection==='connected'&&Boolean(username(s)&&s.session?.user?.username===username(s)&&storeId(s));
const editable=s=>authenticated(s)&&s.session?.user?.role==='admin';
const matches=(s,p)=>authenticated(s)&&p?.actor?.username===username(s)&&p?.actor?.storeId===storeId(s)&&Number.isInteger(p.revision)&&p.revision>=0;
function adopt(d,p){Object.assign(d,values(p),{expectedRevision:p.revision,loadedRevision:p.revision,loadStatus:'ready',error:'',dirty:false});}
function model(state){
  const key=scope(state);let d=state.toneDraft;
  if(!d||d.scope!==key)d=state.toneDraft={scope:key,...defaults(),expectedRevision:0,loadedRevision:null,dirty:false,saving:false,loadStatus:'idle',error:'',feedback:'',focusedField:''};
  if(d.loadStatus==='idle'&&state.tonePreferencesError){d.loadStatus='error';d.error=state.tonePreferencesError.message||String(state.tonePreferencesError);}
  if(matches(state,state.tonePreferences)&&!d.dirty&&!d.saving&&d.loadStatus!=='loading'&&(d.loadedRevision===null||state.tonePreferences.revision>d.loadedRevision)){
    try{adopt(d,state.tonePreferences);}catch(error){d.loadStatus='error';d.error=error.message;}
  }
  return d;
}
function previewText(d){try{return {text:tonePreview(d),empty:false};}catch(error){return {text:error.message,empty:true};}}
function feedback(state,d){
  if(d.error)return d.error;
  if(d.saving)return '正在保存方案…';
  if(d.feedback)return d.feedback;
  if(d.loadStatus==='loading'||state.tonePreferencesLoading)return '正在读取本店口吻方案…';
  if(!authenticated(state))return state.connection==='preview'?'界面预览 · 方案尚未连接':'请先登录并选择已授权门店。';
  if(state.session?.user?.role!=='admin')return '当前方案只读，请联系管理员修改。';
  return d.dirty?'有未保存的修改。':'';
}
export function render(state){
  const d=model(state),p=previewText(d),canEdit=editable(state)&&d.loadStatus==='ready'&&!d.saving&&!state.busy;
  const disabled=canEdit?'':'disabled',stores=Array.isArray(state.stores)?state.stores:[];
  const current=stores.find(row=>row.id===state.storeId),name=current?.name||state.store||'待选择门店';
  const outdated=matches(state,state.tonePreferences)&&state.tonePreferences.revision>d.expectedRevision;
  return `<div class="management-tone-page" data-page-management-tone>
    <section class="mt-card mt-store-card" aria-labelledby="mt-store-heading">
      <div class="mt-store-heading"><h2 id="mt-store-heading">当前门店</h2><span class="mt-badge">按门店保存</span></div>
      <div class="mt-store-controls"><div class="mt-store-select">${icon('tabler-upgrade-pin.svg')}<select id="mt-store" data-mt-store aria-label="当前门店" ${state.busy||d.saving||!stores.length?'disabled':''}>${stores.length?stores.map(row=>`<option value="${escape(row.id)}" ${row.id===state.storeId?'selected':''}>${escape(row.name)}</option>`).join(''):`<option value="">${escape(name)}</option>`}</select></div><button type="button" class="mt-switch" data-mt-switch ${state.busy||d.saving||!stores.length?'disabled':''}>${icon('fy-icon-63-refresh.png')}切换门店</button></div>
    </section>
    <form class="mt-form" data-mt-form>
      <div class="mt-columns">
        <section class="mt-card mt-identity-card" aria-labelledby="mt-identity-heading"><h2 id="mt-identity-heading">身份与表达</h2>
          <div class="mt-identity-row"><label for="mt-identity">对外身份</label><input id="mt-identity" data-mt-identity maxlength="80" autocomplete="off" value="${escape(d.identity)}" placeholder="请如实填写身份" ${disabled}></div>
          <fieldset class="mt-fieldset"><legend>服务口吻</legend><div class="mt-tones">${Object.entries(toneChoices).map(([key,label])=>`<label class="mt-tone ${d.tone===key?'is-selected':''}"><input type="radio" name="mt-tone" data-mt-tone value="${key}" ${d.tone===key?'checked':''} ${disabled}><span class="mt-tone-mark">${icon('tabler-upgrade-check.svg')}</span>${icon(key==='friendly'?'approved-icon-message-circle.svg':key==='concise'?'tabler-message-dots.svg':'approved-icon-user-round.svg','mt-tone-symbol')}<strong>${label}</strong><small>${descriptions[key]}</small></label>`).join('')}</div></fieldset>
          <div class="mt-field"><label for="mt-salutation">开场称呼</label><input id="mt-salutation" data-mt-salutation maxlength="20" autocomplete="off" value="${escape(d.salutation)}" ${disabled}></div>
          <fieldset class="mt-fieldset mt-focus-field"><legend>表达重点</legend><div class="mt-focuses">${Object.entries(focusChoices).map(([key,label])=>`<label><input type="checkbox" data-mt-focus value="${key}" ${d.focus.includes(key)?'checked':''} ${disabled}><span>${label}</span></label>`).join('')}</div></fieldset>
        </section>
        <section class="mt-card mt-preview-card" aria-labelledby="mt-preview-heading"><div class="mt-preview-heading"><h2 id="mt-preview-heading">回复预览</h2><span class="mt-badge">示例评论</span></div>
          <div class="mt-comment"><img class="mt-avatar" src="/assets/portrait-woman-1.png" alt="示例头像"><div><div class="mt-comment-meta"><strong>租房咨询</strong><span class="mt-platform">小红书</span></div><p>下个月想搬家，附近有一居室吗？</p></div></div>
          <h3 class="mt-preview-label">当前身份与口吻</h3><div class="mt-reply ${p.empty?'is-empty':''}" data-mt-preview aria-live="polite">${escape(p.text)}</div>
          <p class="mt-preview-note">${icon('fy-icon-45-eye.png')}仅预览，不会发送消息</p>
        </section>
      </div>
      <footer class="mt-card mt-save-bar"><div class="mt-save-meta"><strong data-mt-summary>${escape(name)} · ${toneChoices[d.tone]}</strong><span data-mt-feedback ${d.error?'role="alert"':'role="status"'}>${escape(feedback(state,d))}</span>${d.loadStatus==='error'||d.error||outdated?`<button type="button" class="mt-reload" data-mt-reload ${d.saving||state.busy?'disabled':''}>${outdated?'重新读取已保存方案':'重新读取'}</button>`:''}</div><div class="mt-save-actions"><button type="button" class="mt-reset" data-mt-reset ${disabled}>重置为默认</button><button type="submit" class="mt-save" data-mt-save ${disabled}>${d.saving?'保存中…':'保存方案'}</button></div></footer>
    </form>
  </div>`;
}
export function bind(root,ctx){
  const d=model(ctx.state),key=d.scope;
  const current=()=>ctx.state.toneDraft===d&&scope(ctx.state)===key;
  const own=()=>current()&&ctx.state.page==='tone';
  const redraw=()=>{if(own())ctx.update(()=>{});};
  const field=name=>root.querySelector(`[data-mt-${name}]`);
  const change=fn=>{
    if(!own()||!editable(ctx.state)||d.saving||d.loadStatus!=='ready'||ctx.state.busy)return;
    fn();d.dirty=true;d.error='';d.feedback='';
    const p=previewText(d),preview=field('preview');if(preview){preview.textContent=p.text;preview.classList?.toggle('is-empty',p.empty);}
    const status=field('feedback');if(status){status.textContent=feedback(ctx.state,d);status.setAttribute?.('role','status');}
    const summary=field('summary');if(summary)summary.textContent=`${ctx.state.store||'当前门店'} · ${toneChoices[d.tone]}`;
    for(const radio of root.querySelectorAll('[data-mt-tone]'))radio.closest?.('.mt-tone')?.classList.toggle('is-selected',radio.value===d.tone);
  };
  async function read(){
    if(!own()||!authenticated(ctx.state)||d.loadStatus==='loading'||ctx.state.tonePreferencesLoading||d.saving)return;
    d.loadStatus='loading';d.error='';d.feedback='';redraw();
    try{
      if(typeof ctx.actions.readTonePreferences!=='function')throw Error('口吻方案暂不可读取，请稍后重试。');
      const result=await ctx.actions.readTonePreferences();if(!current())return;
      const saved=matches(ctx.state,result)?result:ctx.state.tonePreferences;
      if(!matches(ctx.state,saved))throw Error('读取口吻方案失败，请重试。');
      if(!d.dirty)adopt(d,saved);else d.loadStatus='ready';
    }catch(error){if(current()){d.loadStatus='error';d.error=error.message||'读取口吻方案失败，请重试。';}}
    finally{redraw();}
  }
  const discardThen=operation=>{
    if(!d.dirty){operation();return;}
    if(typeof ctx.modal!=='function'){d.error='请先保存当前修改，再切换或重新读取。';redraw();return;}
    ctx.modal({title:'当前有未保存修改',html:'<p>继续后将放弃当前未保存的修改。</p>',confirmLabel:'放弃修改并继续',onConfirm:()=>{if(!own())return false;d.dirty=false;operation();}});
  };
  field('identity')?.addEventListener('input',e=>change(()=>{d.identity=e.target.value;}));
  field('salutation')?.addEventListener('input',e=>change(()=>{d.salutation=e.target.value;}));
  for(const radio of root.querySelectorAll('[data-mt-tone]'))radio.addEventListener('change',()=>{if(radio.checked)change(()=>{d.tone=radio.value;});});
  for(const check of root.querySelectorAll('[data-mt-focus]'))check.addEventListener('change',()=>change(()=>{d.focus=Object.keys(focusChoices).filter(id=>Array.from(root.querySelectorAll('[data-mt-focus]')).some(node=>node.value===id&&node.checked));}));
  field('reset')?.addEventListener('click',()=>{change(()=>Object.assign(d,defaults()));redraw();});
  field('reload')?.addEventListener('click',()=>discardThen(()=>{d.loadStatus='idle';read();}));
  field('switch')?.addEventListener('click',()=>{
    if(!own()||ctx.state.busy||d.saving)return;const id=field('store')?.value;
    if(!id||id===ctx.state.storeId||!ctx.state.stores?.some(row=>row.id===id))return;
    discardThen(async()=>{try{await ctx.actions.selectStore(id);if(ctx.state.page==='tone'&&storeId(ctx.state)===id)await ctx.actions.readTonePreferences();}catch(error){if(own()){d.error=error.message||'切换门店失败，请重试。';redraw();}}});
  });
  field('form')?.addEventListener('submit',async event=>{
    event.preventDefault();if(!own()||!editable(ctx.state)||d.saving||d.loadStatus!=='ready'||ctx.state.busy)return;
    let payload;try{payload={...values(d),expectedRevision:d.expectedRevision};if(!payload.identity)throw Error('请先填写向客户说明的真实身份。');}catch(error){d.error=error.message;redraw();return;}
    d.saving=true;d.error='';d.feedback='';redraw();
    try{
      if(typeof ctx.actions.saveTonePreferences!=='function')throw Error('口吻方案暂不可保存，请稍后重试。');
      const saved=await ctx.actions.saveTonePreferences(payload);if(!current())return;
      if(!matches(ctx.state,saved)||saved.revision<=payload.expectedRevision)throw Error(ctx.state.tonePreferencesError||'保存失败，修改已保留，请重试。');
      adopt(d,saved);d.feedback='方案已保存。';
    }catch(error){if(current())d.error=error.message||'保存失败，修改已保留，请重试。';}
    finally{if(current()){d.saving=false;redraw();}}
  });
  if(d.focusedField){const input=field(d.focusedField);input?.focus?.({preventScroll:true});try{input?.setSelectionRange?.(d.selectionStart,d.selectionEnd);}catch{}}
  if(d.loadStatus==='idle'&&authenticated(ctx.state)&&!ctx.state.tonePreferencesLoading&&!ctx.state.tonePreferencesError)queueMicrotask(()=>{if(own()&&d.loadStatus==='idle'&&!ctx.state.tonePreferencesLoading&&!ctx.state.tonePreferencesError)void read();});
  return ()=>{
    if(ctx.state.toneDraft!==d||scope(ctx.state)!==key)return;
    const active=root.ownerDocument?.activeElement;
    d.focusedField=ctx.state.page==='tone'&&active===field('identity')?'identity':ctx.state.page==='tone'&&active===field('salutation')?'salutation':'';
    if(d.focusedField){const input=field(d.focusedField);if(editable(ctx.state)&&!d.saving&&input.value!==d[d.focusedField]){d[d.focusedField]=input.value;d.dirty=true;}d.selectionStart=input.selectionStart;d.selectionEnd=input.selectionEnd;}
  };
}
