/* Short-lived, single-use reply trial inside the existing workspace state. */
const crypto = require('node:crypto');
const ID = /^[A-Za-z0-9_-]{16,80}$/;
const DIGEST = /^[a-f0-9]{64}$/;
const ACTIVE = new Set(['queued', 'running', 'uncertain']);

function authorize(state, payload, user, now, qaForDevice) {
  if (user?.role !== 'admin') return {status:403,error:'仅管理员可授权回复试验'};
  if (Object.keys(payload).some(key => !['environment_id','operation','device_id','account_id','targets','expires_at'].includes(key)))
    return {status:400,error:'回复试验授权参数无效'};
  const {device_id, account_id, targets, expires_at} = payload;
  if (!ID.test(device_id || '') || !ID.test(account_id || '') ||
      !Array.isArray(targets) || targets.length < 1 || targets.length > 2 ||
      !Number.isSafeInteger(expires_at) || expires_at <= now || expires_at > now + 900 ||
      targets.some(row => !row || typeof row !== 'object' || Array.isArray(row) ||
        Object.keys(row).some(key => !['reply_id','snapshot_digest'].includes(key)) ||
        !ID.test(row.reply_id || '') || !DIGEST.test(row.snapshot_digest || '')) ||
      new Set(targets.map(row => row.reply_id)).size !== targets.length)
    return {status:400,error:'回复试验授权参数无效'};
  const device = state.devices?.find(row => row.id === device_id && !row.revoked);
  const owner = device && state.users?.find(row => row.username === device.owner && !row.disabled && row.can_reply !== false);
  if (!device || !owner || !qaForDevice(device)) return {status:403,error:'指定设备或员工未通过内部验收身份检查'};
  if (!state.xhs_claims?.some(row => row.device_id === device.id && row.account_id === account_id))
    return {status:403,error:'发送账号尚未登记在指定设备'};
  if (state.commands?.some(row => row.device_id === device.id && ACTIVE.has(row.status)))
    return {status:409,error:'设备仍有未结束指令，请先核对'};
  const previous = state.reply_trial_grant;
  if (previous && !previous.revoked_at && previous.device_id === device_id && previous.account_id === account_id &&
      previous.expires_at === expires_at && previous.created_by === user.username &&
      JSON.stringify(previous.targets.map(({reply_id,snapshot_digest}) => ({reply_id,snapshot_digest}))) === JSON.stringify(targets))
    return {status:200,reply_trial:visible(previous)};
  // This deployment permits one grant only; expiry or consumption cannot silently open another two sends.
  if (previous) return {status:409,error:'本轮回复试验授权已使用，不能再次开放'};
  const grant = {grant_id: crypto.randomBytes(18).toString('base64url'), device_id: device.id, owner: device.owner,
    account_id, expires_at, created_at: now, created_by: user.username,
    targets: targets.map(row => ({reply_id: row.reply_id, snapshot_digest: row.snapshot_digest,
      status: 'available'}))};
  state.reply_trial_grant = grant;
  state.audit ??= [];
  state.audit.push({user:user.username,operation:'reply_trial_authorize',time:now,device_id:device.id,
    grant_id:grant.grant_id,target_count:grant.targets.length});
  state.audit = state.audit.slice(-300);
  return {status:200,reply_trial:visible(grant)};
}
function activeGrant(state, device, now) {
  const grant = state.reply_trial_grant;
  if (!grant || grant.revoked_at || !device || device.revoked || grant.device_id !== device.id || grant.owner !== device.owner ||
      grant.expires_at <= now || !state.users?.some(user => user.username === grant.owner && !user.disabled && user.can_reply !== false) ||
      !state.xhs_claims?.some(row => row.device_id === device.id && row.account_id === grant.account_id)) return null;
  return grant;
}
function revoke(state, payload, user, now) {
  if (user?.role !== 'admin') return {status:403,error:'仅管理员可收回回复试验授权'};
  if (Object.keys(payload).some(key => !['environment_id','operation','grant_id'].includes(key)) || !ID.test(payload.grant_id || ''))
    return {status:400,error:'回复试验授权标识无效'};
  const grant = state.reply_trial_grant;
  if (!grant || grant.grant_id !== payload.grant_id) return {status:404,error:'回复试验授权不存在'};
  if (!grant.revoked_at) {
    grant.revoked_at = now;
    grant.revoked_by = user.username;
    for (const command of state.commands || []) {
      if (command.reply_trial_grant_id !== grant.grant_id) continue;
      if (command.status === 'queued') {
        command.status = 'cancelled'; command.finished_at = now;
        command.error = '管理员已收回回复试验授权，未发送';
      } else if (command.status === 'running') {
        command.status = 'uncertain'; command.finished_at = now;
        command.error = '管理员已收回回复试验授权，发送结果待人工核实';
      }
    }
    state.audit ??= [];
    state.audit.push({user:user.username,operation:'reply_trial_revoke',time:now,grant_id:grant.grant_id});
    state.audit = state.audit.slice(-300);
  }
  return {status:200,revoked:true,grant_id:grant.grant_id,revoked_at:grant.revoked_at};
}
function visible(grant) {
  if (!grant) return null;
  return {grant_id:grant.grant_id,device_id:grant.device_id,owner:grant.owner,account_id:grant.account_id,
    expires_at:grant.expires_at,targets:grant.targets.map(({reply_id,snapshot_digest,status}) =>
      ({reply_id,snapshot_digest,status}))};
}
function permit(state, device, data, now, command) {
  const grant = activeGrant(state, device, now);
  if (!grant || data?.authorized !== true || data.account_id !== grant.account_id) return null;
  const target = grant.targets.find(row => row.reply_id === data.reply_id &&
    (row.status === 'available' || command && ['reserved','claimed'].includes(row.status) && row.command_id === command.id));
  if (!target) return null;
  if (command && command.reply_trial_grant_id !== grant.grant_id) return null;
  return {grant,target};
}
function claim(state, command, device, now) {
  const match = permit(state, device, command.data, now, command);
  if (!match || match.target.status !== 'reserved') return null;
  match.target.status = 'claimed';
  match.target.command_id = command.id;
  match.target.claimed_at = now;
  return {grant_id:match.grant.grant_id,reply_id:match.target.reply_id,
    snapshot_digest:match.target.snapshot_digest,account_id:match.grant.account_id,
    expires_at:match.grant.expires_at};
}
function consume(state, command, now) {
  const grant = state.reply_trial_grant;
  if (!grant || grant.grant_id !== command.reply_trial_grant_id) return;
  const target = grant.targets.find(row => row.command_id === command.id && row.status === 'claimed');
  if (target) { target.status = 'consumed'; target.consumed_at = now; }
}
module.exports = {authorize, revoke, activeGrant, visible, permit, claim, consume};
