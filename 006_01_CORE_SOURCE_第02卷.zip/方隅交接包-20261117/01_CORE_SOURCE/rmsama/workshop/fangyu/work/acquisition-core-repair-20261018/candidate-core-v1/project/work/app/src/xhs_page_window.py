"""Source-only owned WebView2 page helper for the opt-in XHS read-only bridge.

The parent owns authorization, the account lock, and the loopback IPC server.
This process owns one account-scoped browser window. It never reads cookies,
issues independent HTTP platform calls, or accepts page-supplied IPC secrets.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
import json
import os
from pathlib import Path
import re
import secrets
import stat
import subprocess
import sys
from threading import Event, Lock, Thread
import time
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit
from urllib.request import HTTPRedirectHandler, ProxyHandler, Request, build_opener


PAGE_URL = 'https://www.xiaohongshu.com/explore'
PAGE_SCRIPT = Path(__file__).resolve().parent / 'resources' / 'xhs-page-bridge.js'
DIAGNOSTIC_NAME = 'xhs-page-diagnostic.json'
MAX_SPEC_BYTES = 8192
MAX_IPC_BYTES = 4_500_000
PAGE_CALL_TIMEOUT = 30.0
READINESS_TIMEOUT = 15.0
POLL_DELAY = 0.4
READINESS_DELAY = 0.8
ACTIONS = frozenset({'status', 'search', 'comments', 'sub_comments'})
DIAGNOSTIC_FLAGS = ('ready', 'trusted_origin', 'webpack_chunk', 'webpack_require',
                    'webpack_cache', 'request_interceptor_present',
                    'public_signer_present', 'export_scan_truncated')
DIAGNOSTIC_COUNTS = ('module_count', 'axios_candidate_count',
                     'base_url_edith_count', 'base_url_empty_count',
                     'export_root_function_count', 'export_root_object_count',
                     'export_own_data_count', 'export_own_accessor_count',
                     'export_nested_function_count', 'export_nested_object_count',
                     'export_get_post_count', 'export_defaults_object_count',
                     'export_interceptors_object_count', 'request_interceptor_object_count',
                     'request_interceptor_use_count', 'request_handlers_array_count',
                     'request_fulfilled_handler_count', 'response_interceptor_object_count')
_OPENER = build_opener(ProxyHandler({}), type('NoRedirect', (HTTPRedirectHandler,), {
    'redirect_request': lambda self, req, fp, code, msg, headers, newurl: None,
})())


class PageBridgeError(Exception):
    def __init__(self, code: str):
        super().__init__(code)
        self.code = code


@dataclass(frozen=True)
class BridgeSpec:
    endpoint: str
    bootstrap_secret: str
    tenant_id: str
    account_id: str
    bound_uid: str
    profile_dir: Path
    cancel_file: Path
    spec_path: Path
    read_mode: str = 'legacy'
    purpose: str = 'collection_read'


def _reparse(path: Path) -> bool:
    return bool(path.is_symlink() or (hasattr(path, 'is_junction') and path.is_junction())
                or path.exists() and getattr(os.lstat(path), 'st_file_attributes', 0)
                   & getattr(stat, 'FILE_ATTRIBUTE_REPARSE_POINT', 0))


def _job_scope(path: Path) -> tuple[Path, Path]:
    if not isinstance(path, Path) or not path.is_absolute() or path.name != 'spec.json':
        raise PageBridgeError('spec_path_invalid')
    job = path.parent
    account = job.parent.parent.parent
    if (not re.fullmatch(r'[a-f0-9]{24}', job.name)
            or job.parent.name != 'xhs-page-bridge' or job.parent.parent.name != 'work'
            or not re.fullmatch(r'[a-f0-9]{32}', account.name)
            or account.parent.parent.name != 'accounts'):
        raise PageBridgeError('spec_path_invalid')
    for item in (account.parent.parent.parent, account.parent.parent, account.parent,
                 account, account / 'work', job.parent, job, path,
                 account / 'xhs-browser-profile'):
        if _reparse(item):
            raise PageBridgeError('spec_path_invalid')
    if (not job.is_dir() or not path.is_file()
            or path.resolve() != job.resolve() / 'spec.json'):
        raise PageBridgeError('spec_path_invalid')
    return job, account


def _diagnostic_account_scope(path: Path) -> Path:
    """Accept one existing, literal account and its owned persistent profile."""
    if (not isinstance(path, Path) or not path.is_absolute()
            or path != path.resolve(strict=False)
            or not re.fullmatch(r'[a-f0-9]{32}', path.name)
            or path.parent.parent.name != 'accounts'
            or not re.fullmatch(r'[A-Za-z0-9_-]{1,80}', path.parent.name)):
        raise PageBridgeError('diagnostic_scope_invalid')
    profile = path / 'xhs-browser-profile'
    for item in (*reversed(path.parents), path, profile, path / 'work',
                 path / 'platform-command.lock', path / 'work' / DIAGNOSTIC_NAME):
        if _reparse(item):
            raise PageBridgeError('diagnostic_scope_invalid')
    if not path.is_dir() or not profile.is_dir():
        raise PageBridgeError('diagnostic_scope_invalid')
    return path


def _diagnostic_report(raw: object, code: str) -> dict:
    """Keep only small booleans/counts; never persist page strings or module IDs."""
    source = raw if isinstance(raw, dict) else {}
    report = {'code': code}
    for key in DIAGNOSTIC_FLAGS:
        report[key] = source.get(key) is True
    for key in DIAGNOSTIC_COUNTS:
        value = source.get(key)
        report[key] = value if type(value) is int and 0 <= value <= 100000 else 0
    return report


def _save_diagnostic(account: Path, report: dict) -> None:
    account = _diagnostic_account_scope(account)
    work = account / 'work'
    work.mkdir(mode=0o700, exist_ok=True)
    if _reparse(work):
        raise PageBridgeError('diagnostic_scope_invalid')
    destination = work / DIAGNOSTIC_NAME
    if _reparse(destination):
        raise PageBridgeError('diagnostic_scope_invalid')
    temporary = work / ('.xhs-page-diagnostic-' + secrets.token_hex(8) + '.tmp')
    payload = json.dumps(report, ensure_ascii=True, allow_nan=False,
                         separators=(',', ':')).encode('ascii')
    if len(payload) > 1024:
        raise PageBridgeError('diagnostic_invalid')
    try:
        handle = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(handle, 'wb') as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        _diagnostic_account_scope(account)
        if _reparse(destination):
            raise PageBridgeError('diagnostic_scope_invalid')
        os.replace(temporary, destination)
    finally:
        temporary.unlink(missing_ok=True)


def _unique_object(pairs):
    value = {}
    for key, item in pairs:
        if key in value:
            raise ValueError('duplicate key')
        value[key] = item
    return value


def load_spec(path: Path) -> BridgeSpec:
    """Read only a private account job spec, rejecting redirects and broad paths."""
    try:
        job, account = _job_scope(path)
        if path.stat().st_size > MAX_SPEC_BYTES:
            raise PageBridgeError('spec_invalid')
        raw = json.loads(path.read_text(encoding='utf-8'), object_pairs_hook=_unique_object)
        required = {'version', 'endpoint', 'bootstrap_secret', 'tenant_id', 'account_id',
                    'bound_uid', 'profile_dir', 'cancel_file'}
        if not isinstance(raw, dict) or not required.issubset(raw) or set(raw) - required - {'job_id', 'read_mode', 'purpose'}:
            raise PageBridgeError('spec_invalid')
        if type(raw['version']) is not int or not (
                raw['version'] == 1 and 'read_mode' not in raw and 'purpose' not in raw or
                raw['version'] == 2 and raw.get('read_mode') == 'natural' and 'purpose' not in raw or
                raw['version'] == 3 and raw.get('read_mode') == 'natural'
                    and raw.get('purpose') == 'identity_observation' or
                raw['version'] == 4 and raw.get('read_mode') == 'natural'
                    and raw.get('purpose') == 'session_recovery'):
            raise PageBridgeError('spec_invalid')
        endpoint = raw['endpoint']
        parsed = urlsplit(endpoint)
        if (not isinstance(endpoint, str) or parsed.scheme != 'http'
                or parsed.hostname != '127.0.0.1' or parsed.port is None or parsed.port < 1
                or parsed.username or parsed.password or parsed.path not in ('', '/')
                or parsed.query or parsed.fragment):
            raise PageBridgeError('spec_invalid')
        secret, tenant, account_id, uid = (raw[key] for key in
                                           ('bootstrap_secret', 'tenant_id', 'account_id', 'bound_uid'))
        if (not isinstance(secret, str) or not 32 <= len(secret) <= 512
                or not isinstance(tenant, str) or tenant != account.parent.name
                or not re.fullmatch(r'[A-Za-z0-9_-]{1,80}', tenant)
                or not isinstance(account_id, str) or account_id != account.name
                or not isinstance(uid, str) or not (re.fullmatch(r'[A-Za-z0-9_-]{1,128}', uid)
                    or raw.get('purpose') in ('identity_observation','session_recovery') and uid == '')):
            raise PageBridgeError('spec_invalid')
        profile, cancel = Path(raw['profile_dir']), Path(raw['cancel_file'])
        if (profile != account / 'xhs-browser-profile' or cancel != job / 'cancel.flag'
                or _reparse(profile) or _reparse(cancel)):
            raise PageBridgeError('spec_path_invalid')
        return BridgeSpec(endpoint.rstrip('/'), secret, tenant, account_id, uid,
                          profile, cancel, path, raw.get('read_mode', 'legacy'),
                          raw.get('purpose', 'collection_read'))
    except PageBridgeError:
        raise
    except (OSError, ValueError, TypeError, KeyError):
        raise PageBridgeError('spec_invalid') from None


def _trusted(url: str) -> bool:
    try:
        parsed = urlsplit(url)
        return (parsed.scheme == 'https' and parsed.hostname == 'www.xiaohongshu.com'
                and parsed.port in (None, 443) and not parsed.username and not parsed.password)
    except (ValueError, TypeError):
        return False


def _post(spec: BridgeSpec, path: str, payload: dict, timeout: float = 5.0) -> dict:
    """Use only the spec's exact loopback origin; never follow a redirect."""
    data = json.dumps(payload, ensure_ascii=True, allow_nan=False,
                      separators=(',', ':')).encode('utf-8')
    if len(data) > MAX_IPC_BYTES:
        raise PageBridgeError('ipc_payload_invalid')
    req = Request(spec.endpoint + path, data=data, method='POST',
                  headers={'Content-Type': 'application/json', 'Accept': 'application/json'})
    try:
        with _OPENER.open(req, timeout=timeout) as response:
            if response.status != 200:
                raise PageBridgeError('ipc_failed')
            raw = response.read(MAX_IPC_BYTES + 1)
        if len(raw) > MAX_IPC_BYTES:
            raise PageBridgeError('ipc_failed')
        result = json.loads(raw)
        if not isinstance(result, dict):
            raise PageBridgeError('ipc_failed')
        return result
    except PageBridgeError:
        raise
    except (HTTPError, URLError, OSError, ValueError, TimeoutError):
        raise PageBridgeError('ipc_failed') from None


def _fixed_request(command: dict) -> dict:
    """Native side enforces the same fixed schema before building JS literals."""
    if not isinstance(command, dict) or command.get('action') not in ACTIONS:
        raise PageBridgeError('action_denied')
    action, params = command['action'], command.get('params')
    if not isinstance(params, dict) or any(not isinstance(k, str) for k in params):
        raise PageBridgeError('invalid_request')
    shapes = {'status': (set(), set()), 'search': ({'keyword', 'page'}, {'keyword', 'page'}),
              'comments': ({'noteId', 'cursor', 'token'}, {'noteId', 'token'}),
              'sub_comments': ({'noteId', 'rootCommentId', 'cursor', 'token'},
                               {'noteId', 'rootCommentId', 'token'})}
    allowed, required = shapes[action]
    if not required.issubset(params) or set(params) - allowed:
        raise PageBridgeError('invalid_request')
    def text(key, limit, empty=False):
        value = params.get(key)
        return isinstance(value, str) and len(value) <= limit and (empty or bool(value))
    if action == 'search':
        valid = text('keyword', 200) and type(params['page']) is int and 1 <= params['page'] <= 2**53 - 1
    elif action == 'status':
        valid = True
    else:
        valid = text('noteId', 256) and text('token', 2048)
        valid = valid and ('cursor' not in params or text('cursor', 2048, True))
        if action == 'sub_comments':
            valid = valid and text('rootCommentId', 256)
    if not valid:
        raise PageBridgeError('invalid_request')
    return {'action': action, 'params': params}


class OwnedPageWindow:
    """One native window; IPC is native-only and every document has an epoch."""

    def __init__(self, spec: BridgeSpec, post=_post):
        self.spec, self.post = spec, post
        self.window = None
        self.lock = Lock()
        self.closed = Event()
        self.epoch = 0
        self.ready = False
        self.loading = False
        self.url = ''
        self.injected = False
        self.session_token = ''
        self.connected_epoch = 0
        self.invalidated_epoch = 0
        self.page_call_active = False

    def attach(self, window):
        self.window = window
        window.events.before_load += self.before_load
        window.events.loaded += self.loaded
        window.events.closed += self.on_closed

    def before_load(self, *_):
        with self.lock:
            self.epoch += 1
            self.ready = False
            self.loading = True
            self.injected = False

    def loaded(self, *_):
        try:
            url = self.window.get_current_url()
        except Exception:
            url = ''
        with self.lock:
            if not self.loading:
                self.epoch += 1
            self.loading = False
            self.ready = True
            self.url = url
            self.injected = False

    def on_closed(self, *_):
        self.closed.set()

    def snapshot(self):
        try:
            current = self.window.get_current_url()
        except Exception:
            current = ''
        with self.lock:
            if self.ready and current and current != self.url:
                # SPA navigation may not fire pywebview's document events.
                self.epoch += 1
                self.url = current
            return self.epoch, self.ready, self.url

    def _current(self, epoch: int) -> bool:
        current, ready, url = self.snapshot()
        return current == epoch and ready and _trusted(url) and not self.closed.is_set()

    def _window_ready(self, epoch: int) -> bool:
        if not self._current(epoch):
            return False
        with self.lock:
            inject = not self.injected
        try:
            if inject:
                self.window.evaluate_js(PAGE_SCRIPT.read_text(encoding='utf-8'))
                with self.lock:
                    if self.epoch != epoch:
                        return False
                    self.injected = True
        except Exception:
            # Trusted navigation may be in a temporary verification page.
            # Connect natively, then let the pending status check bound local
            # script/client readiness for 15 seconds without a platform call.
            pass
        return self._current(epoch)

    def _page_call(self, epoch: int, request: dict) -> dict:
        safe = _fixed_request(request)
        if not self._current(epoch):
            raise PageBridgeError('document_changed')
        if safe['action'] == 'status':
            deadline = time.monotonic() + READINESS_TIMEOUT
            while True:
                if not self._current(epoch):
                    raise PageBridgeError('document_changed')
                if self.spec.cancel_file.exists():
                    raise PageBridgeError('cancelled')
                self._window_ready(epoch)
                try:
                    ready = self.window.evaluate_js('window.__fangyuXhsPageBridge.ready()')
                except Exception:
                    ready = None
                if isinstance(ready, dict) and ready.get('ready') is True:
                    break
                if time.monotonic() >= deadline:
                    return {'_page_error': 'page_client_unavailable'}
                self.closed.wait(READINESS_DELAY)
        expression = ('window.__fangyuXhsPageBridge.run('
                      + json.dumps(safe, ensure_ascii=True, allow_nan=False,
                                   separators=(',', ':')) + ')')
        done = Event()
        answer = {}
        def callback(value):
            answer['value'] = value
            done.set()
        try:
            self.window.evaluate_js(expression, callback=callback)
        except Exception:
            return {'_page_error': 'page_client_unavailable'}
        deadline = time.monotonic() + PAGE_CALL_TIMEOUT
        while not done.wait(0.1):
            if not self._current(epoch):
                raise PageBridgeError('document_changed')
            if self.spec.cancel_file.exists():
                raise PageBridgeError('cancelled')
            if time.monotonic() >= deadline:
                return {'_page_error': 'page_timeout'}
        if not self._current(epoch):
            raise PageBridgeError('document_changed')
        value = answer.get('value')
        if not isinstance(value, dict):
            return {'_page_error': 'invalid_response'}
        data = json.dumps(value, ensure_ascii=True, allow_nan=False)
        if len(data.encode('utf-8')) > MAX_IPC_BYTES:
            return {'_page_error': 'response_oversize'}
        return value

    def _destroy(self):
        try:
            self.window.destroy()
        except Exception:
            pass

    def run(self) -> str:
        """Poll a single parent; never poll or retry the platform independently."""
        try:
            while not self.closed.is_set():
                if self.spec.cancel_file.exists():
                    self._destroy()
                    return 'cancelled'
                _job_scope(self.spec.spec_path)
                epoch, ready, url = self.snapshot()
                if self.session_token and self.connected_epoch and self.connected_epoch != epoch:
                    invalidated = self.post(self.spec, '/invalidate', {
                        'session_token': self.session_token, 'doc_epoch': self.connected_epoch,
                    })
                    if invalidated.get('ok') is not True:
                        raise PageBridgeError('ipc_failed')
                    if self.page_call_active:
                        # The old page request may still be running. No rebind.
                        self.page_call_active = False
                        self._hold()
                        return 'document_changed'
                    self.invalidated_epoch = self.connected_epoch
                    self.connected_epoch = 0
                if not ready or not _trusted(url) or not self._window_ready(epoch):
                    self.closed.wait(READINESS_DELAY)
                    continue
                if self.session_token and not self.connected_epoch:
                    rebound = self.post(self.spec, '/rebind', {
                        'session_token': self.session_token, 'old_epoch': self.invalidated_epoch,
                        'new_epoch': epoch,
                    })
                    if rebound.get('ok') is not True:
                        raise PageBridgeError('ipc_failed')
                    self.connected_epoch = epoch
                    self.invalidated_epoch = 0
                if not self.session_token:
                    connected = self.post(self.spec, '/connect', {
                        'secret': self.spec.bootstrap_secret,
                        'tenant_id': self.spec.tenant_id,
                        'account_id': self.spec.account_id,
                        'bound_uid': self.spec.bound_uid,
                        'doc_epoch': epoch,
                    })
                    token = connected.get('session_token')
                    if connected.get('ok') is not True or not isinstance(token, str) or len(token) < 32:
                        raise PageBridgeError('ipc_failed')
                    self.session_token, self.connected_epoch = token, epoch
                if not self._current(epoch):
                    continue
                command = self.post(self.spec, '/poll', {
                    'session_token': self.session_token, 'doc_epoch': epoch,
                })
                action = command.get('action')
                if action == 'stop':
                    self._destroy()
                    return 'stopped'
                if action in ('idle', 'hold'):
                    if action == 'hold' and command.get('reason') == 'verification_required':
                        try:
                            self.window.show()
                        except Exception:
                            pass
                    self.closed.wait(POLL_DELAY if action == 'idle' else 1.0)
                    continue
                call_id = command.get('call_id')
                if (command.get('ok') is not True or action not in ACTIONS
                        or not isinstance(call_id, str) or not 1 <= len(call_id) <= 100):
                    raise PageBridgeError('ipc_failed')
                if not self._current(epoch):
                    continue
                self.page_call_active = True
                try:
                    envelope = self._page_call(epoch, command)
                except PageBridgeError as error:
                    if error.code == 'document_changed':
                        # Parent must invalidate before any new document call.
                        if self.closed.is_set():
                            self.post(self.spec, '/invalidate', {
                                'session_token': self.session_token,
                                'doc_epoch': self.connected_epoch,
                            })
                            return 'closed'
                        continue
                    envelope = {'_page_error': error.code}
                if not self._current(epoch):
                    continue
                # Order the result against before_load's epoch change. Once
                # native observes navigation, an old callback cannot submit.
                try:
                    visible_url = self.window.get_current_url()
                except Exception:
                    visible_url = ''
                with self.lock:
                    if (self.epoch != epoch or not self.ready or visible_url != self.url
                            or not _trusted(visible_url)):
                        continue
                    self.post(self.spec, '/result', {
                        'session_token': self.session_token, 'doc_epoch': epoch,
                        'call_id': call_id, 'envelope': envelope,
                    })
                self.page_call_active = False
            return 'closed'
        except PageBridgeError as error:
            self._destroy()
            return error.code
        except Exception:
            self._destroy()
            return 'window_failed'

    def _hold(self):
        while not self.closed.wait(0.5):
            if self.spec.cancel_file.exists():
                self._destroy()
                return


def create_runner(spec: BridgeSpec, window, post=_post) -> OwnedPageWindow:
    """Inject an owned renderer and IPC sender for synthetic, GUI-free QA."""
    runner = OwnedPageWindow(spec, post=post)
    runner.attach(window)
    return runner


def run_window(spec: BridgeSpec) -> str:
    """Called only by the parent-owned source helper process."""
    _job_scope(spec.spec_path)
    if spec.cancel_file.exists():
        return 'cancelled'
    if _reparse(spec.profile_dir) or spec.profile_dir.exists() and not spec.profile_dir.is_dir():
        return 'profile_path_invalid'
    spec.profile_dir.mkdir(mode=0o700, exist_ok=True)
    _job_scope(spec.spec_path)
    if spec.read_mode == 'natural':
        from xhs_natural_window import run_natural_window
        return run_natural_window(spec)
    import webview
    window = webview.create_window('小红书网页验证与只读连接', PAGE_URL,
                                   width=820, height=730, js_api=None)
    controller = create_runner(spec, window)
    outcome = {'code': 'closed'}
    def worker():
        if not window.events.shown.wait(15):
            outcome['code'] = 'window_failed'
            return
        # WinForms sets shown only after the native form has appeared. Hide
        # that owned form now; hidden=True at creation can prevent shown from
        # firing and would leave the parent waiting for /connect.
        try:
            window.hide()
        except Exception:
            controller.closed.set()
            controller._destroy()
            outcome['code'] = 'window_failed'
            return
        outcome['code'] = controller.run()
    thread = Thread(target=worker, name='xhs-owned-page-ipc', daemon=True)
    thread.start()
    try:
        webview.start(gui='edgechromium', private_mode=False,
                      storage_path=str(spec.profile_dir), debug=False)
    except Exception:
        controller.closed.set()
        return 'window_failed'
    controller.closed.set()
    thread.join(timeout=8)
    return outcome['code'] if not thread.is_alive() else 'helper_shutdown_timeout'


def _wait_diagnostic_event(event, timeout: float, stop: Event) -> bool:
    deadline = time.monotonic() + timeout
    while not event.is_set() and not stop.is_set():
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            return False
        stop.wait(min(remaining, 0.1))
    return event.is_set() and not stop.is_set()


def _inspect_diagnostic_window(window, stop: Event | None = None) -> dict:
    """Inspect the loaded renderer locally; this function never calls run()."""
    stop = stop or Event()
    if not _wait_diagnostic_event(window.events.shown, 15, stop):
        return _diagnostic_report({}, 'window_unavailable')
    try:
        window.hide()
    except Exception:
        return _diagnostic_report({}, 'window_unavailable')
    if not _wait_diagnostic_event(window.events.loaded, 15, stop):
        return _diagnostic_report({}, 'page_load_timeout')
    deadline = time.monotonic() + READINESS_TIMEOUT
    report = _diagnostic_report({}, 'client_unavailable')
    script = PAGE_SCRIPT.read_text(encoding='utf-8')
    injected = False
    while time.monotonic() < deadline and not stop.is_set():
        try:
            if not _trusted(window.get_current_url()):
                return _diagnostic_report({}, 'untrusted_origin')
            if not injected:
                window.evaluate_js(script)
                injected = True
            raw = window.evaluate_js('window.__fangyuXhsPageBridge.ready()')
            report = _diagnostic_report(raw, 'ready' if isinstance(raw, dict)
                                        and raw.get('ready') is True else 'client_unavailable')
            if report['ready']:
                return report
        except Exception:
            report = _diagnostic_report({}, 'script_unavailable')
        stop.wait(READINESS_DELAY)
    return report


def run_diagnostic_window(account: Path) -> dict:
    """One GUI lifetime, no IPC and no page API; close before caller unlocks."""
    account = _diagnostic_account_scope(account)
    import webview
    window = webview.create_window('小红书页面组件诊断', PAGE_URL,
                                   width=820, height=730, js_api=None)
    outcome = {'report': _diagnostic_report({}, 'window_unavailable')}
    stop = Event()
    def worker():
        try:
            outcome['report'] = _inspect_diagnostic_window(window, stop)
        except Exception:
            outcome['report'] = _diagnostic_report({}, 'diagnostic_failed')
        finally:
            # destroy() itself waits for shown in pywebview. An unsuccessful
            # GUI start has no shown form to close and must not hang 20s here.
            if window.events.shown.is_set():
                try:
                    window.destroy()
                except Exception:
                    outcome['report'] = _diagnostic_report({}, 'window_close_failed')
    thread = Thread(target=worker, name='xhs-page-diagnostic', daemon=True)
    thread.start()
    try:
        webview.start(gui='edgechromium', private_mode=False,
                      storage_path=str(account / 'xhs-browser-profile'), debug=False)
    except Exception:
        outcome['report'] = _diagnostic_report({}, 'window_unavailable')
    finally:
        stop.set()
    thread.join(timeout=8)
    if thread.is_alive():
        raise PageBridgeError('diagnostic_shutdown_timeout')
    return outcome['report']


def diagnose_account(account: Path) -> str:
    """Standalone source entry; the existing cross-process account lock owns GUI use."""
    account = _diagnostic_account_scope(account)
    from core.adapters import AdapterBusy, account_execution_lock
    try:
        with account_execution_lock(account):
            _diagnostic_account_scope(account)
            report = run_diagnostic_window(account)
            _save_diagnostic(account, report)
    except AdapterBusy:
        return 'account_busy'
    return 'diagnostic_saved'


def launch_helper(spec_path: Path) -> subprocess.Popen:
    """Parent factory: owned source or bundled child; private spec carries secrets."""
    path = Path(spec_path)
    spec = load_spec(path)
    from assistant.owned_helper_process import page_helper_argv, OwnedHelperArgvError
    try: command=page_helper_argv(path, spec.profile_dir)
    except OwnedHelperArgvError as error:
        raise PageBridgeError(str(error)) from None
    return subprocess.Popen(list(command.argv), shell=False, cwd=command.cwd,
                            stdin=subprocess.DEVNULL,
                            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                            creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(allow_abbrev=False, description='Owned XHS page bridge helper')
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--bridge-spec', type=Path)
    mode.add_argument('--diagnose-account', type=Path)
    parser.add_argument('--profile-dir', type=Path)
    args = parser.parse_args(argv)
    if bool(args.bridge_spec) != bool(args.profile_dir):
        parser.error('bridge-spec requires profile-dir; diagnostic mode accepts neither')
    watchdog_done = Event()
    if args.diagnose_account:
        # This CLI runs in its own source Python process. A failed GUI close
        # must not hold the account lock or owned WebView2 window indefinitely.
        def watchdog():
            if not watchdog_done.wait(60):
                os.write(1, b'diagnostic_timeout\n')
                os._exit(1)
        Thread(target=watchdog, name='xhs-diagnostic-watchdog', daemon=True).start()
    try:
        if args.diagnose_account:
            code = diagnose_account(args.diagnose_account)
        else:
            spec = load_spec(args.bridge_spec)
            if (not args.profile_dir.is_absolute() or
                    str(args.profile_dir) != str(spec.profile_dir)):
                raise PageBridgeError('profile_argument_invalid')
            code = run_window(spec)
    except PageBridgeError as error:
        code = error.code
    except (OSError, RuntimeError, ValueError):
        code = 'diagnostic_failed' if args.diagnose_account else 'window_failed'
    finally:
        watchdog_done.set()
    print(code)
    return 0 if code in ('stopped', 'closed', 'cancelled', 'diagnostic_saved', 'candidate_staged_natural_verified') else 1


if __name__ == '__main__':
    raise SystemExit(main())
