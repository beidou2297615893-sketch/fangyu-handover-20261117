"""Explicit source-only local operator instance; no enterprise/device grant."""
from copy import deepcopy
from contextlib import contextmanager
import hashlib
import json
import math
from pathlib import Path
import re
import stat
import threading
import time
from uuid import uuid4

from core import CoreError
from core.platform_reads import PlatformReadService

_MARKER = 'self-operating-instance.json'
_UID = re.compile(r'[A-Za-z0-9_-]{1,160}\Z')


def _plain_directory(path, root):
    path, root = Path(path), Path(root)
    relative = path.relative_to(root)
    if not relative.parts or any(p in ('.','..') for p in relative.parts):
        raise ValueError('自营实例必须使用本项目 work 下的独立目录')
    current = root
    for part in ('', *relative.parts):
        if part: current = current / part
        attrs = current.lstat()
        if (not stat.S_ISDIR(attrs.st_mode) or current.is_symlink()
                or getattr(attrs,'st_file_attributes',0) & getattr(stat,'FILE_ATTRIBUTE_REPARSE_POINT',0)):
            raise ValueError('自营实例目录不允许链接或重定向')
    return path


class _OwnerReadInstance:
    """Minted only by the explicit local source launcher, retained by AppServer."""
    def __init__(self, directory, work_root, wrapper_sha, product="xiaohongshu_v1"):
        self.directory, self.work_root = Path(directory), Path(work_root)
        self._wrapper_sha = wrapper_sha
        self.product = product
        self._bytes = (self.directory / _MARKER).read_bytes()
        value = json.loads(self._bytes)
        if (set(value) != {'schema','instance_id','company'} or value['schema'] != ('owner_read_instance_v2' if product=='primary_platforms_v2' else 'owner_read_instance_v1')
                or re.fullmatch(r'[0-9a-f]{32}',value['instance_id']) is None):
            raise ValueError('自营实例标记无效')
        expected = _company(value['instance_id'],wrapper_sha,product)
        if value['company'] != expected: raise ValueError('自营实例配置与原始用途不匹配')
        self._company = expected
        self.check()

    def check(self):
        _plain_directory(self.directory,self.work_root)
        marker = self.directory / _MARKER
        attrs = marker.lstat()
        if (not stat.S_ISREG(attrs.st_mode) or marker.is_symlink()
                or getattr(attrs,'st_file_attributes',0)&getattr(stat,'FILE_ATTRIBUTE_REPARSE_POINT',0)
                or attrs.st_size > 8192 or marker.read_bytes() != self._bytes):
            raise ValueError('自营实例标记已变化')
        return deepcopy(self._company)

    def prepare_data(self):
        directory=self.directory/'data'
        if not directory.exists():directory.mkdir()
        _plain_directory(directory,self.work_root)
        marker=directory/'owner-data-instance.json'
        expected=json.dumps({'schema':'owner_read_data_v1','instance_id':self._company['selfOperatingRead']['instance_id']},sort_keys=True).encode()
        if not marker.exists():
            if any(directory.iterdir()):raise ValueError('已有数据未绑定此自营实例；拒绝接管或迁移')
            with marker.open('xb') as stream:stream.write(expected)
        attrs=marker.lstat()
        if (not stat.S_ISREG(attrs.st_mode) or marker.is_symlink()
                or getattr(attrs,'st_file_attributes',0)&getattr(stat,'FILE_ATTRIBUTE_REPARSE_POINT',0)
                or marker.read_bytes()!=expected):raise ValueError('自营数据实例绑定已变化')
        # Before Store/SQLite can open anything, reject redirected or aliased
        # database files even when the directory has a valid instance marker.
        for name in ('workspace.sqlite3','workspace.sqlite3-wal','workspace.sqlite3-shm','workspace.sqlite3-journal'):
            file=directory/name
            try:attrs=file.lstat()
            except FileNotFoundError:continue
            if (not stat.S_ISREG(attrs.st_mode) or file.is_symlink()
                    or getattr(attrs,'st_file_attributes',0)&getattr(stat,'FILE_ATTRIBUTE_REPARSE_POINT',0)
                    or attrs.st_nlink!=1):
                raise ValueError('自营数据库不允许链接、重定向或共享文件；未打开数据库')
        return directory


def _company(instance_id, wrapper_sha, product='xiaohongshu_v1'):
    if product not in ('xiaohongshu_v1','primary_platforms_v2'):raise ValueError('未知自营产品范围')
    config = {'id':'self-read-'+instance_id[:24], 'name':'自营获客工作台',
        'shortName':'自营只读', 'edition':'owner','personalMode':True,'authMode':'local',
        'industry':'apartment','platform':'xiaohongshu','platforms':['xiaohongshu'],
        'runtime':{'role':'self_operating_read','cli_source_sha256':wrapper_sha,
                   'xiaohongshu_automation':'enabled'},
        'selfOperatingRead':{'schema':'owner_read_instance_v1','instance_id':instance_id,
                             'archive_available':False}}
    if product=='primary_platforms_v2':
        config['platforms']=['xiaohongshu','douyin','wechat_channels']
        config['selfOperatingRead']['schema']='owner_read_instance_v2'
        config['runtime']['douyin_automation']='enabled'
    return config


def open_owner_read_instance(path, work_root, wrapper_sha, *, product='xiaohongshu_v1', existing_only=False):
    """Only a new empty directory or the exact already-minted instance is valid."""
    if (not isinstance(path,str) or not Path(path).is_absolute() or '..' in Path(path).parts
            or any(ord(c)<32 for c in path) or len(path)>500):
        raise ValueError('自营实例路径无效')
    if type(existing_only) is not bool:raise ValueError('既有自营实例模式无效')
    if product not in ('xiaohongshu_v1','primary_platforms_v2'):raise ValueError('未知自营产品范围')
    directory, root = Path(path),Path(work_root)
    directory.relative_to(root)
    _plain_directory(directory.parent,root) if directory.parent != root else None
    if not directory.exists():
        if existing_only:raise ValueError('原自营实例目录缺失；拒绝创建替代实例')
        directory.mkdir()  # Never create arbitrary parent roots.
    _plain_directory(directory,root)
    marker = directory / _MARKER
    if not marker.exists():
        if existing_only:raise ValueError('原自营实例标记缺失；拒绝创建替代实例')
        if any(directory.iterdir()): raise ValueError('自营实例必须从全新空目录创建；不会覆盖旧数据')
        instance_id = uuid4().hex
        value = {'schema':'owner_read_instance_v2' if product=='primary_platforms_v2' else 'owner_read_instance_v1',
                 'instance_id':instance_id,'company':_company(instance_id,wrapper_sha,product)}
        with marker.open('xb') as stream:
            stream.write(json.dumps(value,ensure_ascii=False,sort_keys=True).encode())
    return _OwnerReadInstance(directory,root,wrapper_sha,product)


class _OwnerXhsLocalStatusCall:
    """One owner checking frame, never a login or a user-provided approval."""
    _EXE='3dfdd20b3fe8132e1a4e33355c99ef904a672d2f174f73e7deaea69352d1e49d'
    _WRAPPER='70d6e5c797cc993f0d5b23b12affc943f099065c420f72d38c927ab9d81d04b3'
    _TREE='2382b984fc3ba35145d6849c13994e661161578e3f6a0810c89f4548c2566bb6'
    _GUARD='086f3bf25614149256c1955d823c70073178596526f15301bf014ef25d98cd45'

    @classmethod
    def supports(cls, workspace):
        binding=workspace.server._runtime_license_review_binding
        review=binding.review if binding is not None else None
        artifact=review.get('artifact') if type(review) is dict else None
        return (type(artifact) is dict and artifact.get('exe_sha256')==cls._EXE
                and artifact.get('wrapper_sha256')==cls._WRAPPER
                and artifact.get('runtime_tree_sha256')==cls._TREE
                and artifact.get('guard_manifest_sha256')==cls._GUARD)

    def __init__(self, workspace, account, directory):
        self.workspace,self.account,self.directory=workspace,deepcopy(account),Path(directory)
        self.frame=getattr(workspace._tls,'call',None)

    def check(self, adapters, platform, args, directory, job_id, spec):
        workspace=self.workspace
        frame=getattr(workspace._tls,'call',None)
        if (type(workspace) is not OwnerReadWorkspace or workspace.server._self_operating_reads is not workspace
                or frame is not self.frame or type(frame) is not tuple or len(frame)!=4
                or frame[2] is not True or frame[3] is not False or frame[1]!=self.account
                or adapters is not workspace.server.core.adapters or platform!='xiaohongshu'
                or type(args) is not list or args!=['status','--json'] or job_id is not None
                or Path(directory)!=self.directory or adapters.xhs_page_runtime is not None
                or not self.supports(workspace)):
            raise CoreError('本机状态核对不在原本人调用内')
        user=workspace._actor(frame[0])
        if (workspace._account(user,self.account['id'],checking=True)!=self.account
                or self.directory!=workspace.server.core.store.directory/'accounts'/user['tenant_id']/self.account['id']
                or any(part=='..' for part in self.directory.parts)):
            raise CoreError('本机状态核对的账号归属已变化')
        root=str(self.directory)
        expected_env={'HOME':root,'USERPROFILE':root,'XDG_CONFIG_HOME':str(self.directory/'.config'),
            'APPDATA':str(self.directory/'AppData'/'Roaming'),'LOCALAPPDATA':str(self.directory/'AppData'/'Local'),
            'LEADSTUDIO_ISOLATED':'1','PYTHONUTF8':'1','PYTHONIOENCODING':'utf-8',
            'WORKSPACE_ACTIVITY_LOG':str(self.directory/'platform-activity.jsonl'),'WORKSPACE_ACTIVITY_KIND':'status'}
        if (type(spec) is not dict or spec.get('argv')!=[str(workspace.server.guarded_cli_executable),
                'xiaohongshu','status','--json'] or spec.get('cwd')!=root or spec.get('env')!=expected_env):
            raise CoreError('本机状态核对的固定命令或独立HOME已变化')


class _OwnerXhsRequestScope:
    """Stable metadata ownership, separate from the existing execution frame."""
    ACTIONS=frozenset(('owner_xhs_read_status','owner_xhs_read_cancel'))
    def __init__(self,workspace):
        self.workspace,self.core=workspace,workspace.server.core
        self.reads=None

    def bind_read_service(self,reads):
        if self.reads is not None or reads.core is not self.core or self.workspace._reads is not reads:
            raise CoreError('本人请求只绑定原读取服务一次')
        self.reads=reads

    def binding(self,user,account,key):
        company=self.workspace.instance.check()
        if (self.workspace.server._self_operating_reads is not self.workspace
                or self.workspace.server.company!=company
                or account.get('platform')!='xiaohongshu'
                or account.get('tenant_id')!=user.get('tenant_id')
                or account.get('cloud_owner')!=user.get('username')):
            raise CoreError('本人请求归属已变化')
        return (company['selfOperatingRead']['instance_id'],company['id'],
            *(user.get(k) for k in ('id','tenant_id','username','role','personal_owner','cloud_bound')),
            *(account.get(k) for k in ('id','tenant_id','cloud_owner','platform')),key)

    def execution_check(self,entry):
        frame=getattr(self.workspace._tls,'call',None)
        if frame is None or frame[2] or frame[3]:raise CoreError('本人请求不在原评论执行范围')
        user=self.workspace._actor(frame[0])
        account=self.workspace._account(user,entry['account_id'])
        with self.reads._lock:
            if (not any(value is entry for value in self.reads._operations.values())
                    or not entry.get('running') or entry.get('cancelled')
                    or entry.get('_owner_binding')!=self.binding(user,account,entry['_owner_request_id'])):
                raise CoreError('本人本次采集范围已失效')
        # Original Adapter.execute/_execute each invoke the host's complete
        # fresh platform guard, including immediately before Popen. This private
        # structural check does not add redundant runtime-tree hash passes.
        if account!=frame[1]:raise CoreError('本人本次采集账号记录已变化')

class OwnerReadWorkspace:
    def __init__(self, server, instance):
        if type(instance) is not _OwnerReadInstance: raise ValueError('自营实例绑定无效')
        self.server,self.instance=server,instance
        self._tls=threading.local()
        self._lock=threading.RLock()
        self._reads=None
        self._xhs_requests=_OwnerXhsRequestScope(self)
        self._archive=None
        self._acquisition=None
        self._web_contact_observation=None
        self._keyword_search=None
        self._keyword_source_trace=None
        self._douyin=None
        self._douyin_archive=None
        self._channels=None
        self._channels_preview_archive=None
        self._intent=None
        self._source_export=None
        self._keyword_workflow=None
        self._source_people=None
        self._identity=None
        from .owner_qr_login import OwnerQRLogin
        self._login=OwnerQRLogin(self)

    def _actor(self, token):
        if self.server.closing or self.server.company != self.instance.check():
            raise CoreError('自营工作台用途已变化')
        user=self.server.core.session(token)
        saved=self.server.core.store.get('users',user['id']) if user else None
        if (not saved or saved.get('disabled') or saved.get('personal_owner') is not True
                or saved.get('role')!='admin' or saved.get('cloud_bound') not in (None,False)
                or any(saved.get(k)!=user.get(k) for k in ('id','tenant_id','username','role'))):
            raise CoreError('请先进入本人的自营工作台')
        return saved

    def _account(self, user, account_id, *, checking=False, cleanup=False, login=False):
        core=self.server.core
        with core.lock:
            account=core._get('accounts',account_id,user['tenant_id'])
            core._account_access(user,account)
            if account.get('platform')!='xiaohongshu' or account.get('cloud_owner')!=user['username']:
                raise CoreError('此账号不属于本人的小红书只读范围')
            if not cleanup:
                uid=account.get('platform_uid')
                if (type(uid) is not str or not _UID.fullmatch(uid)
                        or account.get('requires_review') not in (None,False)
                        or account.get('risk_state') not in (None,'','normal','safe')
                        or account.get('status') not in (('login_required','ready','logging_in') if login else ('login_required','ready') if checking else ('ready',))):
                    raise CoreError('账号身份、风险或会话尚未核实；保留原状态')
                if any(a['id']!=account['id'] and a.get('platform')=='xiaohongshu'
                       and a.get('platform_uid')==uid for a in core.store.list('accounts',user['tenant_id'])):
                    raise CoreError('同一本人UID有重复记录；已暂停读取')
            return deepcopy(account)

    @contextmanager
    def _call(self, token, account, checking=False, login=False):
        if getattr(self._tls,'call',None) is not None: raise CoreError('自营读取不能嵌套')
        frame=(token,deepcopy(account),checking,login)
        self._tls.call=frame
        try:
            self.execution_guard('xiaohongshu')
            yield
        finally:
            if getattr(self._tls,'call',None) is frame: del self._tls.call

    def execution_guard(self, platform):
        if platform=='douyin' and self._douyin is not None:return self._douyin.execution_guard()
        if platform=='wechat_channels' and self._channels is not None:return self._channels.scope.check()
        frame=getattr(self._tls,'call',None)
        if platform!='xiaohongshu' or frame is None: raise CoreError('平台操作不在本次自营只读用途内')
        token,original,checking,login=frame
        user=self._actor(token)
        current=self._account(user,original['id'],checking=checking,login=login)
        if current != original: raise CoreError('读取期间账号记录已变化')
        self._require_activity_safe(user,current)
        self.server.core._platform_execution_guard(platform)
        policy=self.server.platform_read_license_policy
        if type(policy) is not dict or policy.get(platform) is not True:
            raise CoreError('本自营实例的固定组件内部使用审查尚未通过')

    def _require_activity_safe(self, user, account):
        # Reuse the original account-local safety decision. This runs before
        # transport, on cached returns and after original physical cleanup;
        # cancellation/close never depend on a current risk approval.
        directory=self.server.core.store.directory/'accounts'/user['tenant_id']/account['id']
        try:self.server.core.adapters.require_account_safe('xiaohongshu',directory)
        except (OSError,ValueError,UnicodeError):
            raise CoreError('此账号运行记录需人工核实；保留原状态并暂停读取') from None

    def _saved_analysis(self, user, instance_id, pairs):
        """Join existing durable facts once. This is metadata, never an AI call.

        An attempt covers only the model's missing subset of a mixed cache
        batch. Rows without a unique retained link stay visible for review.
        """
        from .ai_workflow import digest, LEVELS
        from .self_operating_source_intent import _stable_actor, _account_identity
        from .source_intent_analysis import ENTITY, ACTION
        from .platform_receipt_archive import _safe_text, BATCHES, RECEIPTS, _hash
        store=self.server.core.store
        actor=digest(_stable_actor(user));session=digest(['local_owner_source_intent_v1',instance_id,actor])
        principal=digest({k:user.get(k) for k in ('id','tenant_id','username','role','cloud_bound')})
        hex64=lambda value:type(value) is str and re.fullmatch(r'[a-f0-9]{64}',value) is not None
        index={};lookups={}
        def get(entity,ident):
            key=(entity,ident)
            if key not in lookups:lookups[key]=store.get(entity,ident)
            return lookups[key]
        rated={digest([user['tenant_id'],user['username'],lead['id']]):(lead,source,account)
               for lead,source,account in pairs if isinstance(lead.get('ai_intent'),dict)}
        if not rated:return index
        archive_actor={k:user.get(k) for k in ('id','tenant_id','username','role','cloud_bound')}
        batches={row['id']:row for row in store.list(BATCHES,user['tenant_id'])
                 if row.get('cloud_owner')==user['username'] and row.get('device_id')==instance_id
                 and row.get('actor')==archive_actor and type(row.get('lead_ids')) is list
                 and type(row.get('source_count')) is int and row['source_count']==len(row['lead_ids'])
                 and 1<=row['source_count']<=100}
        archive_members={}
        for receipt in store.list(RECEIPTS,user['tenant_id']):
            batch=batches.get(receipt.get('batch_id'));result=receipt.get('result');scope=receipt.get('local_owner_scope')
            if (batch and receipt.get('tenant_id')==user['tenant_id'] and receipt.get('cloud_owner')==user['username']
                    and receipt.get('device_id')==instance_id and receipt.get('actor')==archive_actor
                    and receipt.get('state')=='succeeded' and type(result) is dict and type(scope) is dict
                    and result.get('lead_ids')==batch['lead_ids'] and result.get('accepted_count')==batch['source_count']
                    and result.get('reply_allowed') is False and result.get('real_platform_verified') is False):
                for ident in batch['lead_ids']:
                    if hex64(ident):archive_members.setdefault(ident,[]).append((batch,scope))
        for record in store.list(ENTITY,user['tenant_id']):
            scope=record.get('owner_source_scope');ident=record.get('id')
            if (not hex64(ident) or record.get('cloud_owner')!=user['username']
                    or record.get('tenant_id')!=user['tenant_id'] or record.get('device_id')!=instance_id
                    or record.get('actor_digest')!=actor or record.get('session_binding')!=session
                    or record.get('analysis_committed') is not True or type(scope) is not dict
                    or set(scope)!={'schema','local_instance_id','account_id','account_digest','actor_digest','provider_binding_digest'}
                    or scope.get('schema')!='local_owner_source_intent_v1' or scope.get('local_instance_id')!=instance_id
                    or scope.get('actor_digest')!=actor or not hex64(scope.get('provider_binding_digest'))
                    or type(record.get('selected_count')) is not int or not 1<=record['selected_count']<=20
                    or record.get('analyzed')!=record['selected_count'] or not hex64(record.get('attempt_id'))):continue
            receipt=get('product_operation_receipts',ident);attempt=get('ai_attempts',record['attempt_id'])
            if (not receipt or receipt.get('id')!=ident or receipt.get('tenant_id')!=user['tenant_id']
                    or receipt.get('cloud_owner')!=user['username'] or receipt.get('original_action')!=ACTION
                    or receipt.get('state')!='succeeded'
                    or ident!=digest([user['tenant_id'],user['username'],ACTION,receipt.get('idempotency_key')])
                    or (receipt.get('result') or {}).get('counts')!={'selected':record['selected_count'],'analyzed':record['analyzed'],'cache_hits':record.get('cache_hits')}
                    or not attempt or attempt.get('id')!=record['attempt_id'] or attempt.get('tenant_id')!=user['tenant_id']
                    or attempt.get('owner')!=user['username'] or attempt.get('operation')!='intent_analyze'
                    or attempt.get('state')!='validated' or attempt.get('principal_digest')!=principal
                    or attempt.get('request_id')!=record.get('original_request_id')
                    or not hex64(attempt.get('host_digest')) or not hex64(record.get('source_digest'))
                    or not hex64(attempt.get('input_digest')) or not hex64(attempt.get('context_digest'))
                    or type(attempt.get('lead_digests')) is not list
                    or any(not hex64(x) for x in attempt['lead_digests'])
                    or len(set(attempt['lead_digests']))!=len(attempt['lead_digests'])
                    or len(attempt['lead_digests'])>20):continue
            for lead_digest in set(x for x in attempt['lead_digests'] if hex64(x))&rated.keys():
                lead,source,account=rated[lead_digest];value=lead['ai_intent']
                if scope.get('account_id')!=account['id'] or scope.get('account_digest')!=digest(_account_identity(account)):continue
                if account.get('platform')=='douyin':
                    from core.platform_reads import _digest as archive_digest
                else:archive_digest=digest
                expected_archive={'schema':('local_owner_douyin_archive_v1' if account.get('platform')=='douyin' else
                    'local_owner_archive_v2'),'local_instance_id':instance_id,
                    'account_id':account['id'],'account_digest':archive_digest(_account_identity(account)),
                    'actor_digest':archive_digest({k:user.get(k) for k in ('id','tenant_id','username','role','cloud_bound','personal_owner')})}
                if (lead.get('privacy_redacted') is not False or source.get('privacy_redacted') is not False
                        or source.get('safe_text_hash')!=_hash(lead.get('text'))
                        or source.get('original_text_hash')!=_hash(lead.get('text'))
                        or not any(bound==expected_archive and
                                   ((type(batch.get('source_count')) is int and batch['source_count']<=20 and hex64(batch.get('input_digest')))
                                    if account.get('platform')=='douyin' else batch.get('input_digest')==source.get('input_digest'))
                                   for batch,bound in archive_members.get(lead['id'],[]))):continue
                key=value.get('cache_key');cache=get('ai_cache',key) if hex64(key) else None
                cached=cache.get('value') if isinstance(cache,dict) else None
                if (not cache or cache.get('id')!=key or cache.get('tenant_id')!=user['tenant_id']
                        or type(cached) is not dict or not {'status','level','reason','evidence','region_status','content_region','key_info'}<=cached.keys()
                        or any(value.get(k)!=v for k,v in cached.items())
                        or value.get('status')!=lead.get('analysis_status')
                        or value.get('status') not in ('graded','uncertain','unrelated')
                        or (value.get('status')=='graded' and value.get('level') not in LEVELS)
                        or (value.get('status')!='graded' and value.get('level') is not None)
                        or type(value.get('reason')) is not str
                        or not value['reason'] or len(value['reason'])>1000
                        or type(value.get('rules_version')) is not str or not value['rules_version']
                        or type(value.get('analyzed_at')) is not str):continue
                applied=value.get('applied_policy')
                if applied is not None and (type(applied) is not dict or applied.get('original_request_id')!=attempt['request_id']):continue
                reason,changed=_safe_text(value['reason'],1000)
                if changed:continue
                index.setdefault(lead['id'],[]).append({'analysis_status':value['status'],
                    'intent_level':value['level'],'analysis_reason':reason,'analysis_verified':True})
        return {ident:values[0] for ident,values in index.items() if len(values)==1}

    def _source_page(self, token, user, limit, cursor, *, priority=False):
        # A bounded local seek, not a permission token or an MVCC snapshot.
        # Keep the original archive/privacy/analysis proof before projecting.
        from .platform_receipt_archive import SOURCES, _hash, _safe_text
        if type(limit) is not int or not 1<=limit<=50:
            raise CoreError('来源每页数量须为1至50')
        if cursor is None:
            after='';cutoff=time.time()
        elif (type(cursor) is dict and set(cursor)=={'schema','after','cutoff'}
                and cursor['schema']==('owner_priority_source_cursor_v1' if priority else 'owner_source_cursor_v1')
                and type(cursor['after']) is str and re.fullmatch(r'[0-9a-f]{64}',cursor['after'])
                and type(cursor['cutoff']) in (int,float) and math.isfinite(cursor['cutoff'])
                and 0<cursor['cutoff']<=time.time()
                and len(json.dumps(cursor,ensure_ascii=True))<=256):
            after=cursor['after'];cutoff=cursor['cutoff']
        else:raise CoreError('来源分页位置无效，请明确刷新来源')
        core=self.server.core
        rows=[];pairs=[];needs_review=0;examined=0;last=after
        instance_id=self.instance.check()['selfOperatingRead']['instance_id']
        with core.lock:
            current=self._actor(token)
            if any(current.get(k)!=user.get(k) for k in ('id','tenant_id','username','role')):
                raise CoreError('来源工作池本人身份已变化')
            platforms=('xiaohongshu','douyin') if self._douyin_archive is not None else ('xiaohongshu',)
            accounts={a['id']:a for a in core.store.list('accounts',current['tenant_id'])
                      if a.get('platform') in platforms and a.get('cloud_owner')==current['username']}
            with core.store.connect() as db:
                candidates=db.execute('SELECT id,body FROM records WHERE entity=? AND tenant_id=? AND id>? ORDER BY id LIMIT ?',
                    (SOURCES,current['tenant_id'],after,200)).fetchall()
            for candidate in candidates:
                last=candidate['id'];examined+=1
                if type(last) is not str or re.fullmatch(r'[0-9a-f]{64}',last) is None:
                    raise CoreError('来源分页位置需要核对')
                source=json.loads(candidate['body'])
                if type(source) is not dict or source.get('cloud_owner')!=current['username']:
                    continue
                created=source.get('created_at')
                if type(created) not in (int,float) or not math.isfinite(created) or created<=0:
                    needs_review+=1;continue
                if created>cutoff:continue
                lead=core.store.get('leads',source.get('lead_id'))
                if (type(lead) is not dict or lead.get('tenant_id')!=current['tenant_id']
                        or lead.get('cloud_owner')!=current['username'] or lead.get('readonly_archive') is not True):
                    needs_review+=1;continue
                source_uid=lead.get('source_uid')
                if type(source_uid) is not str or not source_uid:
                    needs_review+=1;continue
                account=accounts.get(source.get('account_id'))
                platform=source.get('platform')
                uid=account.get('platform_uid') if account else None
                uid_valid=(type(uid) is str and ((_UID.fullmatch(uid) is not None) if platform=='xiaohongshu' else
                    (re.fullmatch(r'[0-9]{1,160}',uid) is not None and bool(uid.strip('0')))))
                if (source.get('id')!=last or source.get('id')!=_hash([current['tenant_id'],source_uid])
                        or type(lead.get('id')) is not str or re.fullmatch(r'[a-f0-9]{64}',lead['id']) is None
                        or source.get('tenant_id')!=current['tenant_id']
                        or source.get('cloud_owner')!=current['username'] or source.get('device_id')!=instance_id
                        or source.get('actor_id')!=current['id'] or source.get('actor_role')!=current['role']
                        or source.get('lead_id')!=lead.get('id')
                        or source.get('source_uid')!=source_uid or platform not in platforms
                        or not account or account.get('platform_uid')!=source.get('account_uid')
                        or account.get('platform')!=platform or not uid_valid
                        or lead.get('platform')!=platform or lead.get('demo') or lead.get('task_id')
                        or lead.get('grade')!='C'
                        or lead.get('can_reply') is not False
                        or any(lead.get(k) for k in ('author_id','comment_id','target_comment_id','target_author_id'))
                        or source.get('lead_text_hash')!=_hash(lead.get('text') or '')
                        or source.get('lead_source_digest')!=_hash({key:lead.get(key) for key in
                            ('platform','source_id','source_type','note_url','url','comment_id','author_id','target_comment_id','target_author_id')})):
                    needs_review+=1;continue
                if platform=='douyin':
                    try:self._douyin_archive.source_pool_item(token,current,account,lead['id'],source)
                    except (CoreError,ValueError,TypeError,KeyError):
                        needs_review+=1;continue
                safe={}
                for key,maximum in (('title',1000),('text',3000),('author',300)):
                    value=lead.get(key,'')
                    if type(value) is not str or len(value)>maximum:
                        safe=None;break
                    clean,changed=_safe_text(value,maximum)
                    if changed:
                        safe=None;break
                    safe[key]=clean
                if safe is None:
                    needs_review+=1;continue
                from .ai_workflow import digest
                group=digest({key:source.get(key) for key in ('platform','post_id','account_id','account_uid',
                    'account_binding_digest','connection_digest','license_digest','input_digest','read_operation_id')})
                pairs.append((lead,source,account))
                rows.append({'id':lead['id'],'account_id':account['id'],'group_id':group,'platform':platform,**safe,'grade':'C',
                    'analysis_status':'privacy_review_required' if lead.get('privacy_redacted') is True else 'pending_analysis',
                    'analysis_verified':False,'intent_level':None,'analysis_reason':'',
                    'readonly_archive':True,'can_reply':False})
                if not priority and len(rows)==limit:break
            saved=self._saved_analysis(current,instance_id,pairs)
            for row,(lead,source,account) in zip(rows,pairs):
                if row['id'] in saved:row.update(saved[row['id']])
                elif lead.get('ai_intent') or lead.get('analysis_status') not in ('pending','privacy_review_required'):
                    row['analysis_status']='rating_review_required';needs_review+=1
            self._actor(token)  # Permission/session loss cannot publish a cached list.
        more=examined<len(candidates) or len(candidates)==200
        if priority:
            # Original archive/attempt/cache join has already classified every
            # bounded candidate. Retain the cursor at the last returned SOURCE,
            # never at the 200-window tail when matches remain unreturned.
            matched=[(row,source['id']) for row,(_,source,_) in zip(rows,pairs)
                if row['analysis_verified'] is True and row['analysis_status']=='graded'
                and row['intent_level'] in ('high','super_high')]
            if len(matched)>=limit:
                selected=matched[:limit];last=selected[-1][1]
                rows=[row for row,_ in selected]
                more=last!=candidates[-1]['id'] or len(candidates)==200
            else:
                rows=[row for row,_ in matched]
                more=len(candidates)==200
        next_cursor={'schema':'owner_priority_source_cursor_v1' if priority else 'owner_source_cursor_v1',
            'after':last,'cutoff':cutoff} if more else None
        return {'purpose':'owner_priority_source_pool_page' if priority else 'owner_source_pool_page','leads':rows,
            'returned_count':len(rows),'scanned_count':examined,'needs_review_count':needs_review,
            'page':{'has_more':more,'next_cursor':next_cursor,'cutoff':cutoff,
                    'scope':'this_instance_owner','snapshot_verified':False},
            'scope':'this_instance_owner','can_reply':False,'AI_started':False,'auto_retry':False}

    def _source_pool(self, token, user):
        page=self._source_page(token,user,50,None)
        return page['leads'],{'returned_count':page['returned_count'],'truncated':page['page']['has_more'],
            'needs_review_count':page['needs_review_count'],'scope':page['scope'],
            'can_reply':False,'AI_started':False,'scanned_count':page['scanned_count'],'page':page['page']}

    def dispatch(self, token, operation, data):
        if type(data) is not dict: raise CoreError('自营只读参数无效')
        if operation=='product_action' and data.get('action') in ('owner_source_export_begin','owner_source_export_page','owner_source_export_confirm'):
            if set(data)!={'action','data'} or type(data['data']) is not dict:
                raise CoreError('本人导出参数无效')
            from .owner_source_export import OwnerSourceExport
            with self._lock:
                if self._source_export is None:self._source_export=OwnerSourceExport(self)
                return {'result':self._source_export(token,data['action'],data['data'])}
        user=self._actor(token)
        core=self.server.core
        with self._lock:
            identity=tuple(user.get(k) for k in ('id','tenant_id','username'))
            if self._identity is None:
                self._identity=identity
                from .self_operating_archive import OwnerSourceArchive
                self._archive=OwnerSourceArchive(self)
                from .owner_single_keyword_search import OwnerSingleKeywordSearch
                self._keyword_search=OwnerSingleKeywordSearch(self)
                if self.instance.check()['selfOperatingRead']['schema']=='owner_read_instance_v2':
                    from .owner_douyin_read import OwnerDouyinRead
                    self._douyin=OwnerDouyinRead(self)
                    from .owner_channels_read import OwnerChannelsRead
                    self._channels=OwnerChannelsRead(self)
                self._reads=PlatformReadService(core,user['tenant_id'],user['username'],
                    license_policy_provider=lambda:self.server.platform_read_license_policy,
                    execution_guard=self.execution_guard,owner_xhs_request_scope=self._xhs_requests,
                    **self._archive.read_service_options(),
                    **self._keyword_search.read_service_options(),
                    **(self._douyin.read_service_options() if self._douyin else {}),
                    **(self._channels.read_service_options() if self._channels else {}))
                self._xhs_requests.bind_read_service(self._reads)
                self._archive.bind_read_service(self._reads)
                self._keyword_search.bind_read_service(self._reads)
                if self._douyin:self._douyin.bind_read_service(self._reads)
                if self._douyin:
                    from .owner_douyin_source_archive import OwnerDouyinSourceArchive
                    self._douyin_archive=OwnerDouyinSourceArchive(self)
                if self._channels:
                    self._channels.bind_read_service(self._reads)
                    from .owner_channels_preview_archive import OwnerChannelsPreviewArchive
                    self._channels_preview_archive=OwnerChannelsPreviewArchive(self)
                from .owner_keyword_source_trace import OwnerKeywordSourceTrace
                self._keyword_source_trace=OwnerKeywordSourceTrace(self)
                from .self_operating_source_intent import OwnerSourceIntent
                self._intent=OwnerSourceIntent(self,self._archive)
                from .self_operating_acquisition import OwnerAcquisition
                self._acquisition=OwnerAcquisition(self,self._archive)
                from .owner_web_contact_observation import OwnerWebContactObservation
                self._web_contact_observation=OwnerWebContactObservation(self)
            elif self._identity!=identity:raise CoreError('自营实例本人身份已变化')
        if operation=='product_action' and data.get('action')=='owner_source_person_groups':
            if set(data)!={'action','data'} or type(data['data']) is not dict:
                raise CoreError('本人来源分组参数需核对')
            from .owner_source_people import OwnerSourcePeople
            with self._lock:
                if self._source_people is None:self._source_people=OwnerSourcePeople(self)
                return {'result':self._source_people.execute(token,data['data'])}
        if operation=='product_action' and data.get('action') in ('keyword_recommend','keyword_library','keyword_state','owner_keyword_attempt_status'):
            if set(data)!={'action','data'} or type(data['data']) is not dict:
                raise CoreError('本人关键词参数无效')
            from .owner_keyword_workflow import OwnerKeywordWorkflow
            with self._lock:
                if self._keyword_workflow is None:self._keyword_workflow=OwnerKeywordWorkflow(self)
                return {'result':self._keyword_workflow.execute(token,data['action'],data['data'])}
        if operation=='owner_priority_source_pool_page':
            if set(data)!={'limit','cursor'}:raise CoreError('优先来源分页仅接受每页数量和原分页位置')
            return self._source_page(token,user,data['limit'],data['cursor'],priority=True)
        if operation=='owner_source_pool_page':
            if set(data)!={'limit','cursor'}:raise CoreError('来源分页仅接受每页数量和分页位置')
            return self._source_page(token,user,data['limit'],data['cursor'])
        if operation=='workspace_state':
            if data:raise CoreError('工作台状态不接受额外参数')
            accounts=[{k:a.get(k) for k in ('id','name','platform','status','platform_uid','requires_review','risk_state')}
                      for a in core.store.list('accounts',user['tenant_id']) if a.get('cloud_owner')==user['username']]
            leads,pool=self._source_pool(token,user)
            return {'user':core._public(user),'accounts':accounts,'tasks':[], 'leads':leads,'source_pool':pool,
                    'self_operating_read':True,'archive_available':False,'auto_retry':False,
                    'owner_priority_source_pool_available':True,
                    'owner_business_reconciliation':__import__('assistant.owner_business_view',fromlist=['CAP']).CAP.copy(),
                    'owner_web_contact_observation':self._web_contact_observation.describe(),
                    'owner_source_locator':{'contract':('owner_source_locator_v2' if self._douyin_archive else
                        'owner_xhs_source_locator_v1'),'available':True,
                        'read_only':True,'canonical_only':True,'platform_requests_started':False},
                    'keyword_search':self._keyword_search.describe(),
                    'keyword_source_trace':self._keyword_source_trace.describe(),
                    **({'owner_primary_platforms':True,'douyin_read':self._douyin.describe()} if self._douyin else {}),
                    **({'owner_douyin_source_archive':self._douyin_archive.describe()} if self._douyin_archive else {}),
                    **({'owner_douyin_saved_history':self._douyin_archive.describe_history()} if self._douyin_archive else {}),
                    **({'channels_preview':self._channels.describe(user)} if self._channels else {}),
                    **({'owner_channels_preview_archive':self._channels_preview_archive.describe()}
                       if self._channels_preview_archive else {})}
        if operation=='account_create' and data.get('platform')=='douyin':
            if (self._douyin is None or set(data)!={'name','expected_uid','platform'}
                    or type(data['name']) is not str or not 1<=len(data['name'].strip())<=80
                    or type(data['expected_uid']) is not str or not re.fullmatch(r'[0-9]{1,160}',data['expected_uid'])
                    or not data['expected_uid'].strip('0')):raise CoreError('请明确登记本人抖音账号和已知UID')
            if any(a.get('platform')=='douyin' and a.get('platform_uid')==data['expected_uid']
                   for a in core.store.list('accounts',user['tenant_id'])):raise CoreError('本人UID已有抖音记录')
            return core.handle('save',{'entity':'accounts','record':{'name':data['name'].strip(),
                'platform':'douyin','platform_uid':data['expected_uid'],'status':'login_required','cloud_owner':user['username']}},user)
        if operation=='account_create':
            if set(data)!={'name','expected_uid'} or type(data['name']) is not str or not 1<=len(data['name'].strip())<=80 or type(data['expected_uid']) is not str or not _UID.fullmatch(data['expected_uid']):
                raise CoreError('请明确填写本人账号名称与已知UID；未知身份不自动登记')
            if any(a.get('platform_uid')==data['expected_uid'] for a in core.store.list('accounts',user['tenant_id'])):
                raise CoreError('本人UID已有记录，请使用原记录')
            return core.handle('save',{'entity':'accounts','record':{'name':data['name'].strip(),
                'platform':'xiaohongshu','platform_uid':data['expected_uid'], 'status':'login_required',
                'cloud_owner':user['username']}},user)
        if operation in ('account_login_start','account_login_status','account_login_cancel','account_login_recover'):
            return self._login.dispatch(token,operation,data)
        if operation=='account_check':
            if set(data)!={'account_id'}:raise CoreError('账号核对仅接受已创建的本人账号编号')
            account=self._account(user,data['account_id'],checking=True)
            with self._call(token,account,checking=True):
                directory=core.store.directory/'accounts'/user['tenant_id']/account['id']
                manifest=core.adapters.manifest('xiaohongshu')
                status_call=(_OwnerXhsLocalStatusCall(self,account,directory)
                    if core.adapters.xhs_page_runtime is None and _OwnerXhsLocalStatusCall.supports(self) else None)
                from core.adapters import _OwnerXhsLocalCredentialMissing
                local_missing=False
                try:
                    payload=core.adapters.execute('xiaohongshu',manifest.get('status_args',['status','--json']),directory,
                        **({'_owner_xhs_status_call':status_call} if status_call is not None else {}))
                except _OwnerXhsLocalCredentialMissing as error:
                    if (status_call is None or type(error) is not _OwnerXhsLocalCredentialMissing
                            or error.call is not status_call):
                        raise CoreError('本机缺登录观察未绑定本次本人核对') from None
                    local_missing=True
                    payload={'authenticated':False}
                result=payload.get('data',payload) if type(payload) is dict else {}
                if type(result) is not dict:result={}
                # Original pure status decision; physical execute finally has
                # returned before any identity write. Recheck before publish.
                self.execution_guard('xiaohongshu')
                with core.lock:
                    fresh_user=self._actor(token)
                    current=self._account(fresh_user,account['id'],checking=True)
                    if current!=account:raise CoreError('身份核对期间账号已变化，未保存观察')
                    binding=self.server._runtime_license_review_binding
                    if binding is None or not binding.current(self.server.company):
                        raise CoreError('组件审核文件已变化，未保存身份观察')
                    self._require_activity_safe(fresh_user,current)
                    from core.engine import evaluate_xhs_identity, now
                    decision=evaluate_xhs_identity(current,result,core.store.list('accounts',user['tenant_id']))
                    current.update(status=decision['status'],checked_at=now())
                    if decision['verified']:
                        # Known UID must already equal the authoritative result.
                        if decision['uid']!=account['platform_uid']:raise CoreError('本人UID不一致')
                        if decision['nickname']:current['platform_nickname']=decision['nickname']
                    core.store.put('accounts',current)
                return {'authenticated':decision['authenticated'],'verified':decision['verified'],
                        'account':current,'message':('本机尚未建立登录会话，请本人扫码登录'
                            if local_missing else decision['message'])}
        if operation!='product_action' or set(data)!={'action','data'} or (type(data['action']) is not str or (data['action'] not in ('platform_read_comments','platform_read_status','platform_read_cancel','platform_read_archive','platform_read_archive_status','owner_source_ai_connect','owner_source_ai_status','source_intent_analyze_selected','source_intent_analysis_status') and data['action'] not in (self._acquisition.ACTIONS | self._acquisition.HISTORY_ACTIONS) and data['action'] not in self._web_contact_observation.ACTIONS and data['action'] not in self._xhs_requests.ACTIONS and data['action'] not in self._keyword_source_trace.ACTIONS and data['action'] not in self._keyword_search.ACTIONS and data['action'] not in ((self._douyin_archive.ACTIONS | self._douyin_archive.HISTORY_ACTIONS) if self._douyin_archive else ()) and data['action'] not in (self._douyin.ACTIONS if self._douyin else ()) and data['action'] not in (self._channels.ACTIONS if self._channels else ()) and data['action'] not in (self._channels_preview_archive.ACTIONS if self._channels_preview_archive else ()))) or type(data['data']) is not dict:
            raise CoreError('自营仅开放本人来源、明确分析与本机业务记录；平台发送未启用')
        action,fields=data['action'],data['data']
        if self._channels_preview_archive and action in self._channels_preview_archive.ACTIONS:
            return {'result':self._channels_preview_archive.execute(token,action,fields)}
        if action in self._web_contact_observation.ACTIONS:
            # Metadata never borrows a read/employee TLS or opens Native. The
            # explicit start owns its separate pending purpose/retained key.
            return {'result':self._web_contact_observation.execute(token,action,fields)}
        if self._douyin_archive and action in self._douyin_archive.HISTORY_ACTIONS:
            return {'result':self._douyin_archive.execute_history(token,action,fields)}
        if self._douyin_archive and action in self._douyin_archive.ACTIONS:
            return {'result':self._douyin_archive.execute(token,action,fields)}
        if action in self._keyword_source_trace.ACTIONS:
            # This bridge resolves only a current original search member. The
            # original comments action still owns all independent read guards.
            return {'result':self._keyword_source_trace.execute(token,action,fields)}
        if action in self._keyword_search.ACTIONS:
            # The exact owner purpose owns its own frame. Status/cancel cannot
            # borrow a new execution review or re-submit a lost search.
            return {'result':self._keyword_search.execute(token,action,fields)}
        if action in (self._acquisition.ACTIONS | self._acquisition.HISTORY_ACTIONS):
            # This metadata service owns its sealed frame; never lend a platform
            # execution grant or archive TLS to contact/draft operations.
            return {'result':self._acquisition.execute(token,action,fields)}
        if action in self._intent.ACTIONS:
            if action=='source_intent_analyze_selected' and (type(fields.get('area')) is not str or not fields['area'].strip()):
                raise CoreError('请明确本次分析区域；可填写全市或不限区，不表示房源覆盖')
            return {'result':self._intent.execute(token,action,fields)}
        if action in ('platform_read_archive','platform_read_archive_status'):
            # This trusted service enters its own execution or metadata scope;
            # no outer _call may lend a new grant to historical status.
            return {'result':self._archive.execute(token,action,fields)}
        if self._channels and action in self._channels.ACTIONS:
            if action=='owner_channels_comments' and self._channels_preview_archive:
                self._channels_preview_archive.read_preflight(token,fields.get('account_id'))
            return {'result':self._channels.execute(token,action,fields)}
        if self._douyin and action in self._douyin.ACTIONS:
            return {'result':self._douyin.execute(token,action,fields)}
        if action in self._xhs_requests.ACTIONS:
            # Only the saved current本人/session may inspect or stop its own key.
            # Risk/UID/review changes cannot lend execution or block its cleanup.
            self._account(user,fields.get('account_id'),cleanup=True)
            result=self._reads.owner_xhs_metadata(action,fields,core._public(user))
            fresh=self._actor(token)
            current=self._account(fresh,fields.get('account_id'),cleanup=True)
            if self._xhs_requests.binding(fresh,current,fields.get('request_id')) != self._xhs_requests.binding(user,current,fields.get('request_id')):
                raise CoreError('本人请求归属已变化')
            return {'result':result}
        reservation=None
        if action=='platform_read_comments' and core.adapters.xhs_page_runtime is None:
            stable=self._account(user,fields.get('account_id'),cleanup=True)
            reservation=self._reads.owner_xhs_prepare(fields,core._public(user))
        try:
            return self._dispatch_xhs_read(token,user,action,fields)
        finally:
            if reservation is not None:self._reads.owner_xhs_reject(reservation)

    def _dispatch_xhs_read(self,token,user,action,fields):
        core=self.server.core
        cleanup=action=='platform_read_cancel'
        account=self._account(user,fields.get('account_id'),checking=action=='platform_read_status',cleanup=cleanup)
        if cleanup:return {'result':self._reads.execute(action,fields,core._public(user))}
        if action=='platform_read_comments' and (fields.get('page',1)!=1 or fields.get('cursor','') or type(fields.get('limit',20)) is not int or not 1<=fields.get('limit',20)<=20):
            raise CoreError('自营首批仅请求第一页、请求数量不超过20条评论')
        with self._call(token,account,checking=action=='platform_read_status'):
            result=self._reads.execute(action,fields,core._public(user))
            self.execution_guard('xiaohongshu')
        return {'result':result}

    def close(self):
        # Cancel all exact owned resources, even when one cleanup stays pending.
        # No fresh purpose/risk grant is needed and no unknown receipt is cleared.
        complete=True
        if self._web_contact_observation is not None:
            complete=self._web_contact_observation.close() is True and complete
        if self._douyin is not None:complete=self._douyin.close() is True and complete
        entries=[]
        if self._reads is not None:
            with self._reads._lock:
                entries=list(self._reads._operations.values())
                for entry in entries:entry['cancelled']=True
            for entry in entries:
                if entry.get('running') and entry.get('operation_id'):
                    self.server.core.adapters.cancel(entry['operation_id'])
        complete=self._login.close() is True and complete
        if self._reads is not None:
            with self._reads._lock:
                complete=not any(entry.get('running')
                                 for entry in entries) and complete
        return complete
