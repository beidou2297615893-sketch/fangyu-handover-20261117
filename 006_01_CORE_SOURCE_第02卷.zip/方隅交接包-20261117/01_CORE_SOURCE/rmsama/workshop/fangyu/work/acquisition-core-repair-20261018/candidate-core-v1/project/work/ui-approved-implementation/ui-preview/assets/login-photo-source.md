# 登录摄影资产来源

生成日期：2026-10-16（北京时间）。工具：内置 imagegen 编辑；未暴露可核验具体模型型号。

最终资产：`login-approved-photo.png`。实际尺寸1148×1371（接近4:5竖幅），保留工具生成原始PNG，未缩放或重新压缩。

输入参考/编辑源：`C:/积木软件工坊/项目/方隅公寓客户版/outputs/新UI第三轮（完整修订）/01-登录.png`，生成前已真实查看。以已认可登录图左侧室内照片为依据提取/还原照片资产，没有重新设计登录界面。保持米色沙发、橄榄绿抱枕、毯子、深色落地窗、窗外城市、餐桌/铜吊灯、木茶几/书/杯/绿植、暖阳和地毯的同一场景风格。移除了表单/品牌/中文覆盖文字；墙上画框改为无字抽象画。

首版生成原图：`C:/Users/rmsama/.codex/generated_images/01a1406d-d5a5-7670-91ce-ec9e7e4379df/exec-d01e9f86-ff05-481a-8074-d93e17c0b4df.png`。检查发现圆茶几最右缘仍贴边，因此仅作一次桌子留边编辑。

最终原图：`C:/Users/rmsama/.codex/generated_images/01a1406d-d5a5-7670-91ce-ec9e7e4379df/exec-f25ac2a1-b989-484e-a728-5f49aaded34d.png`。实际查看检查：独立竖幅照片，无表单/界面/边框/水印/可辨认文字，沙发在左、落地窗在右，完整圆茶几及腿部在画内，桌沿右侧有地毯余量。Copy-Item原样复制，源/目标SHA256相同。该检查为助手资产检查，未冒称用户逐张认可；UI实际铺图效果由根任务截图验收。

## 提取/还原提示词

EDIT the supplied approved login mockup image. The requested output is ONLY the photorealistic apartment interior photograph from the LEFT side of that reference, as one independent portrait photograph. Preserve the same room identity and composition as faithfully as possible: pale beige linen sofa on the left half with cream and muted olive pillows and knitted throw; very tall dark metal floor-to-ceiling windows on the right, sliding balcony glazing, city skyline and trees outside; warm golden afternoon sunlight; back dining table and brass pendant lamp; neutral rug; foreground low ROUND wooden coffee table with books, a cup, and green potted trailing plant. Keep the sofa large, keep the full window height and city view. Include the complete circular tabletop and visible legs near the lower portion rather than cutting its right edge. Use only minimal natural reframing/edge reconstruction needed to fit this complete room composition in a 4:5 portrait canvas, approximately 848 pixels wide by 1058 pixels high. Do NOT create a website or redesign a login. Completely remove the entire right white login form panel, all logo/brand elements, ALL overlaid Chinese text, ALL interface elements, and the words within the framed wall poster (retain the frame with a simple non-text abstract beige print). NO text of any kind, no letters, no captions, no typography, no watermark, no border, no split composition. Output one standalone portrait apartment interior photo, filling the entire 4:5 image from edge to edge. Match original warm light, furniture materials, and realistic photographic detail.

## 茶几留边编辑提示词

Edit this existing portrait interior photo with ONE very small composition fix. Preserve the entire approved room, furniture, sofa, windows, city, lighting, colors, textures and photo realism. The round wooden coffee table currently reaches the far right image edge: shift ONLY this foreground coffee table, together with its books, cup and potted plant, slightly LEFT, and very slightly reduce its apparent size if needed, until the entire circular tabletop and every table leg are fully visible with a clear background/rug margin of at least 6 percent of the image width on the table's RIGHT side. Keep the table in the lower foreground and keep realistic perspective, round top and natural shadows. The round table must not touch any image edge. Keep the sofa large on the left, windows on the right, warm sun and city. Frame the overall photo as a vertical 4:5 portrait suitable for an approximately 848x1058 display region. No letters anywhere, no words on book covers, no UI, no text, no logos, no watermark, no borders. Return only the one standalone interior photo.

