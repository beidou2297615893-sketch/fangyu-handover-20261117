"""Install the reviewed fixed local entry; no build, grant or data migration.

Only the existing canonical launcher and FROZEN descriptor are replaced.
Expected-old and expected-new hashes bound the operation; original bytes are
saved exclusively before replacement, and a failed transaction restores only
files still matching this operation's old/new versions.
"""
from pathlib import Path
import argparse
import datetime
import hashlib
import json
import os
import stat
import sys
import uuid

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
P = HERE.parents[2]
NATIVE = P / 'work/ui-native-r57'
OUT = P / 'work/acquisition-core-repair-20261018/candidate-core-v4'


def digest(raw):
    return hashlib.sha256(raw).hexdigest().upper()


def exact(path, expected):
    for item in (path, *path.parents):
        info = item.lstat()
        if item.is_symlink() or getattr(info, 'st_file_attributes', 0) & 0x400:
            raise RuntimeError('Entry path cannot be a link')
    before = path.stat()
    if not stat.S_ISREG(before.st_mode) or before.st_nlink != 1:
        raise RuntimeError('Entry input must be a regular single-link file')
    raw = path.read_bytes()
    after = path.stat()
    if (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) != (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns):
        raise RuntimeError('Input changed while reading')
    if digest(raw) != expected.upper():
        raise RuntimeError('Expected entry hash changed: ' + path.name)
    return raw


def replace(path, raw):
    temporary = path.parent / (path.name + '.' + uuid.uuid4().hex + '.tmp')
    with temporary.open('xb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--install', action='store_true')
    if not parser.parse_args().install:
        parser.error('Use --install only for the reviewed local entry transaction')
    plan = json.loads((HERE / 'CANONICAL-DELEGATION-PREPARED.json').read_text('utf-8'))
    assert plan['status'] == 'PREPARED_NOT_INSTALLED'
    launcher = NATIVE / 'run_workbench.py'
    frozen = NATIVE / 'FROZEN.json'
    candidate = Path(plan['launcher'])
    assert candidate.parent == NATIVE
    old = {
        launcher: exact(launcher, plan['expected_previous_launcher_sha256']),
        frozen: exact(frozen, plan['expected_previous_frozen_sha256']),
    }
    new_launcher = exact(candidate, plan['launcher_sha256'])
    exact(OUT / 'UNIFIED-PINS.json', plan['full_closure_manifest_sha256'])
    exact(NATIVE / 'state/production-workspace.json', plan['workspace_binding_sha256'])
    exact(Path(plan['runtime_project_root']) / 'work/ui-native-r57/state/production-workspace.json', plan['workspace_binding_sha256'])
    staged = json.loads((OUT / 'STAGED.json').read_text('utf-8'))
    assert staged['release_id'] == plan['release_id'] and staged['manifest_sha256'] == plan['manifest_sha256']
    exact(Path(plan['release']) / 'RELEASE.json', plan['manifest_sha256'])
    company = P / 'work/app/company.json'
    company_before = digest(company.read_bytes())
    metadata = {**staged,
        'status': 'FROZEN', 'launcher': str(launcher), 'launcher_sha256': plan['launcher_sha256'],
        'promoted_from': str(HERE / 'CANONICAL-DELEGATION-PREPARED.json'),
        'local_entry_schema': 'fangyu-local-delegated-entry/1',
        'runtime_project_root': plan['runtime_project_root'],
        'installation_state_root': plan['installation_state_root'],
        'workspace_binding_sha256': plan['workspace_binding_sha256'],
        'full_closure_files': plan['full_closure_files_verified'],
        'full_closure_manifest_sha256': plan['full_closure_manifest_sha256'],
        'component_use_policy': 'pending', 'production_pin_acceptance': False,
        'production_cloud_activation': False, 'compiled_cli_executed': False,
        'installer_created': False, 'distribution_approved': False,
    }
    new = {launcher: new_launcher, frozen: (json.dumps(metadata, ensure_ascii=False, indent=2) + '\n').encode('utf-8')}
    backup = HERE / 'canonical-entry-before'
    backup.mkdir(exist_ok=False)
    for path, raw in old.items():
        with (backup / path.name).open('xb') as stream:
            stream.write(raw)
    journal = {
        'schema': 'fangyu-local-entry-transaction/1', 'status': 'BACKED_UP_NOT_REPLACED',
        'at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'targets': [{'path': str(path), 'old_sha256': digest(old[path]), 'new_sha256': digest(raw)} for path, raw in new.items()],
        'backup': str(backup), 'production_data_migration': False,
        'company_sha256': company_before,
    }
    journal_path = HERE / 'CANONICAL-DELEGATION-INSTALL.json'
    journal_path.write_text(json.dumps(journal, ensure_ascii=False, indent=2) + '\n', 'utf-8')
    try:
        for path, raw in new.items():
            exact(path, digest(old[path]))  # CAS immediately before each write.
            replace(path, raw)
        for path, raw in new.items():
            exact(path, digest(raw))
        assert digest(company.read_bytes()) == company_before
    except BaseException as error:
        conflicts = []
        for path, raw in old.items():
            if digest(path.read_bytes()) in (digest(raw), digest(new[path])):
                replace(path, raw)
            else:
                conflicts.append(str(path))
        journal.update(status='ROLLBACK_CONFLICT' if conflicts else 'ROLLED_BACK', error_type=type(error).__name__, conflicts=conflicts)
        journal_path.write_text(json.dumps(journal, ensure_ascii=False, indent=2) + '\n', 'utf-8')
        raise
    journal.update(status='INSTALLED_AWAITING_ACTUAL_ORIGINAL_ENTRY_VERIFICATION',
        original_company_unchanged=True, old_90a_and_old_CLI_unchanged=True,
        production_cloud_activation=False, production_pin_acceptance=False,
        component_use_policy='pending', compiled_cli_executed=False,
        desktop_shortcut_changed=False, distribution_approved=False)
    journal_path.write_text(json.dumps(journal, ensure_ascii=False, indent=2) + '\n', 'utf-8')
    print(json.dumps({'status': journal['status'], 'launcher_sha256': digest(new_launcher), 'backup': str(backup)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
