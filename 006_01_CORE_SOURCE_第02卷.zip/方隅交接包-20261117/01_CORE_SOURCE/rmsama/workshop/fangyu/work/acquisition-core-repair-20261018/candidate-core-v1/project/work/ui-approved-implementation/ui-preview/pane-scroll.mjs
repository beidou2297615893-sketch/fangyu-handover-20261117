// Keep the user's place when a selected customer or background status rerenders.
// Query, page, identity and detail-target changes each begin at their own top.
export function createPaneScroll(root,readState){
  const selectors=['.cs-table-wrap','.cs-detail-panel','[data-live-list]','.rp-editor'];
  const displayed=new Map(),saved=new Map();
  function key(selector){
    const s=readState(),c=s.customers||{},r=s.replyLive||{};
    const actor=[s.connection,s.user,s.storeId,s.page];
    if(selector==='.cs-table-wrap')return JSON.stringify([...actor,c.query,c.filter,c.sort,c.sortDirection,c.page,c.pageSize]);
    if(selector==='.cs-detail-panel')return JSON.stringify([...actor,c.selectedId]);
    if(selector==='[data-live-list]')return JSON.stringify([...actor,r.tab,r.query,r.groupBy,r.page]);
    return JSON.stringify([...actor,r.selectedId,r.leadId]);
  }
  return {
    save(){for(const selector of selectors){const e=root.querySelector(selector),scope=displayed.get(selector);if(e&&scope)saved.set(selector,{scope,top:e.scrollTop,left:e.scrollLeft});}},
    restore(){for(const selector of selectors){const scope=key(selector),e=root.querySelector(selector),p=saved.get(selector);displayed.set(selector,scope);if(e){e.scrollTop=p?.scope===scope?p.top:0;e.scrollLeft=p?.scope===scope?p.left:0;}}}
  };
}
