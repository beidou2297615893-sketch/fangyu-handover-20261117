/* Owner-scoped review of stored software output; no model or platform calls. */
const MUTATIONS=new Set(['intent_quality_batch_create','intent_quality_label']);
const LEVELS=[['super_high','超高意向'],['high','高意向'],['medium','中意向'],['low','低意向'],['very_low','极低意向'],['uncertain','待核实'],['unrelated','无关']];
const STATES=new Set(['current','stale','unavailable']);
const opaque=value=>typeof value==='string'&&/^[a-f0-9]{64}$/.test(value);
const integer=(value,min,max)=>Number.isSafeInteger(value)&&value>=min&&value<=max;
const node=(tag,text='',className='')=>{const value=document.createElement(tag);value.textContent=String(text);if(className)value.className=className;return value;};
const flags=value=>value?.local_only===true&&value.storage_scope==='this_device'&&value.cross_machine_verified===false&&['provider_requests_started','platform_requests_started','ratings_modified','contacts_modified','handoffs_modified','auto_retry','real_platform_verified'].every(key=>value[key]===false);
export function checkedQualityReceipt(value,key,action){
  if(!value||!MUTATIONS.has(action)||value.operation_action!==action||value.idempotency_key!==key||typeof key!=='string'||!/^[A-Za-z0-9_-]{8,128}$/.test(key)||!flags(value)||typeof value.replayed!=='boolean'||value.refresh_required!==true||!/^[a-f0-9]{64}$/.test(String(value.operation_id)))throw Error('抽检保存回执未通过核对，继续保留原编号。');
  if(value.state==='not_committed'){if(value.mutation_committed!==false||value.cancellation_tombstone!==true)throw Error('抽检原操作的取消证明无效。');return value;}
  if(value.state!=='succeeded'||value.mutation_committed!==true||value.cancellation_tombstone!==false||!opaque(value.batch_id))throw Error('抽检保存结果未确认。');
  if(action==='intent_quality_batch_create'&&(!['all_ai','high_ai'].includes(value.cohort)||!integer(value.limit,1,100)||!integer(value.sample_count,0,value.limit)||!integer(value.frame_count,value.sample_count,1000000)))throw Error('抽检批次范围未通过核对。');
  if(action==='intent_quality_label'&&(!opaque(value.sample_id)||!integer(value.revision,1,1000000)))throw Error('人工核验版本未通过核对。');
  return value;
}

export function qualityRate(value){if(value===null)return '暂无可计算样本';if(typeof value!=='number'||!Number.isFinite(value)||value<0||value>1)throw Error('抽检比率格式无效。');return `${(value*100).toFixed(1)}%`;}

export function checkedQualitySummary(value,id){
  const levels=LEVELS.map(([key])=>key),countKeys=['sample_count','labeled_count','stale_count','context_stale_count','unavailable_count'];
  if(!value||value.batch_id!==id||!flags(value)||value.metrics_scope!=='this_frozen_local_comment_sample'||value.evaluation_scope!=='current_stored_output_vs_current_frozen_source'||value.prediction_stage!=='post_local_policy'||value.prediction_input_binding!=='legacy_unverified'||value.human_labels_independently_verified!==false||value.conversion_rate!==null||value.settlement_cents!==null||value.orders_verified!==false||value.revenue_verified!==false||value.revenue_cents!==null||value.model_profile_live_checked!==false||!['all_ai','high_ai'].includes(value.cohort)||countKeys.some(key=>!integer(value[key],0,100))||value.labeled_count>value.sample_count)throw Error('抽检指标证据范围无效。');
  if(!value.frame_counts||!integer(value.frame_count,value.sample_count,1000000)||Object.values(value.frame_counts).some(count=>!integer(count,0,1000000))||value.frame_counts.eligible_ai!==value.frame_count)throw Error('抽检抽样范围无效。');
  for(const name of ['historical','current']){
    const metric=value[name],counts=['decisive_denominator','undecided_labels','labeled_pair_count','agreement_denominator','agreement_count','software_abstention_count','software_decided_count','high_precision_denominator','true_positive','false_positive'];
    if(!metric||counts.some(key=>!integer(metric[key],0,100))||metric.recall_estimable!==(value.cohort==='all_ai')||metric.decisive_denominator+metric.undecided_labels!==metric.labeled_pair_count||metric.agreement_denominator!==metric.software_decided_count||metric.software_decided_count+metric.software_abstention_count!==metric.decisive_denominator||metric.agreement_count>metric.agreement_denominator||metric.high_precision_denominator!==metric.true_positive+metric.false_positive)throw Error('抽检指标分母无效。');
    if(metric.labeled_pair_count>value.labeled_count||metric.high_precision_denominator>metric.decisive_denominator)throw Error('抽检指标分母超过已核验样本。');
    const rate=(actual,numerator,denominator)=>actual===(denominator?numerator/denominator:null);
    if(!rate(metric.agreement_rate,metric.agreement_count,metric.agreement_denominator)||!rate(metric.high_precision,metric.true_positive,metric.high_precision_denominator)||!rate(metric.software_coverage,metric.software_decided_count,metric.decisive_denominator))throw Error('抽检指标计算无法核对。');
    if(metric.recall_estimable){if(!integer(metric.false_negative,0,100)||metric.high_recall_denominator!==metric.true_positive+metric.false_negative||metric.high_recall_denominator>metric.decisive_denominator||!rate(metric.high_recall,metric.true_positive,metric.high_recall_denominator))throw Error('抽检召回分母无法核对。');}else if(metric.false_negative!==null||metric.high_recall_denominator!==null||metric.high_recall!==null)throw Error('筛选组不能推断召回。');
    const matrix=metric.confusion_matrix;if(!matrix||JSON.stringify(matrix.levels)!==JSON.stringify(levels)||matrix.matrix_scope!=='all_labeled_pairs;human_uncertain_not_correct_or_wrong'||matrix.axes!=='rows_software_columns_human'||!Array.isArray(matrix.rows)||matrix.rows.length!==7||matrix.rows.some(row=>!Array.isArray(row)||row.length!==7||row.some(count=>!integer(count,0,100)))||matrix.rows.flat().reduce((total,count)=>total+count,0)!==metric.labeled_pair_count)throw Error('抽检等级矩阵无法核对。');
    if(!metric.matching||!integer(metric.matching.decisive_denominator,0,metric.decisive_denominator)||metric.matching.decisive_denominator===0&&metric.matching.agreement_rate!==null)throw Error('资料匹配指标分母无效。');qualityRate(metric.matching.agreement_rate);
  }
  if(value.current.labeled_pair_count>value.historical.labeled_pair_count)throw Error('当前指标超过本批历史核验范围。');
  if(!Array.isArray(value.comparisons)||value.comparisons.length>value.labeled_count||value.comparisons.some(row=>!opaque(row.sample_id)||!levels.includes(row.prediction_level)||!levels.includes(row.human_level)||!['current','stale'].includes(row.source_state)||typeof row.context_stale!=='boolean'))throw Error('已标注样本对照范围无效。');
  return value;
}

export function createIntentQualityUI({createDialog,read,write,scope,perform,pending,recover}){
  let generation=0,active=null,disposed=false;
  function clear(){generation++;if(active){for(const field of active.root.querySelectorAll('input,textarea'))field.value='';active.root.replaceChildren();active.root.close?.();active.root.remove();active=null;}}
  async function open(){
    if(disposed)return;clear();const own=++generation,principal=scope(),view=createDialog('软件意向抽检');active=view;let batch=null,readGeneration=0;
    const current=()=>!disposed&&own===generation&&active===view&&principal===scope()&&view.current();
    const guard=()=>{if(current())return true;if(own===generation)clear();return false;};
    const report=(text,error=false)=>{if(!guard())return;view.status.textContent=text;view.status.dataset.state=error?'error':'ready';};
    const load=async(action,data)=>{const answer=await read(action,data);if(!guard())throw Error('抽检账号或电脑已变化。');if(!flags(answer))throw Error('抽检本机证据范围无效。');return answer;};
    const form=node('form','','upgrade-operation-form');form.addEventListener('submit',event=>event.preventDefault());view.root.append(form);
    function input(label,{value='',type='text',maxLength=160,min,max,required=false}={}){const wrap=node('label',label),field=node('input');field.type=type;field.value=String(value);field.required=required;if(maxLength)field.maxLength=maxLength;if(min!==undefined)field.min=String(min);if(max!==undefined)field.max=String(max);wrap.append(field);form.append(wrap);return field;}
    function select(parent,label,choices,value){const wrap=node('label',label),field=node('select');for(const [key,text]of choices)field.append(new Option(text,key));field.value=value;wrap.append(field);parent.append(wrap);return field;}
    function button(parent,label,fn){const control=node('button',label,'secondary');control.type='button';control.onclick=()=>void fn(control);parent.append(control);return control;}
    view.root.append(node('p','先阅读本人原评论并作人工判断，软件预测暂时隐藏。记录独立保存，不改客户意向、回复或交接，也不调用模型或平台。','upgrade-muted'));
    const cohort=select(form,'抽检范围',[['all_ai','全部已有 AI 输出的评论'],['high_ai','仅软件高意向评论']],'all_ai');
    const size=input('本批评论数（1–100）',{type:'number',value:20,min:1,max:100,required:true});
    const batchId=input('已有批次编号',{maxLength:160});
    const history=node('div','','upgrade-record-list'),recovery=node('div','','upgrade-operation-recovery'),sampleHost=node('section'),summaryHost=node('section');view.root.append(recovery,history,sampleHost,summaryHost);
    const target='quality-batch';
    async function recoverOriginal(action,target,after){const original=pending(action,target);if(!original){report('当前没有需要核对的原操作。');return;}const result=await recover(action,target);if(!guard())return;const receipt=checkedQualityReceipt(result.result||result,original.idempotency_key,action);if(receipt.state==='succeeded'){report('原操作已确认保存，请查看本机结果。');await after(receipt);}else report('原操作未提交，同编号的迟到保存已被阻止；可重新核对资料。');}
    function redrawRecovery(){if(!guard())return;recovery.replaceChildren();const original=pending('intent_quality_batch_create',target);if(!original)return;recovery.append(node('p',`新建批次结果待核对。原操作编号：${original.idempotency_key}`,'upgrade-muted'));button(recovery,'核对原批次保存',control=>perform(view,control,async()=>{await recoverOriginal('intent_quality_batch_create',target,async receipt=>{batchId.value=receipt.batch_id;await loadBatch(receipt.batch_id);await loadHistory();});redrawRecovery();}));}
    async function loadHistory(){const result=await load('intent_quality_batch_list',{offset:0,limit:20});if(!guard())return;if(!Array.isArray(result.items)||result.items.length>20||!integer(result.total,result.items.length,1000000))throw Error('抽检历史清单无效。');for(const row of result.items)if(!opaque(row.batch_id)||!['all_ai','high_ai'].includes(row.cohort)||!integer(row.sample_count,0,100)||typeof row.scope_matches!=='boolean')throw Error('抽检历史记录无效。');history.replaceChildren(node('h3','最近的本人抽检批次'));if(!result.items.length)history.append(node('p','尚无抽检批次。没有人工标注时不显示准确率。','upgrade-muted'));for(const row of result.items){const line=node('div','','upgrade-record-line');line.append(node('span',`${row.cohort==='high_ai'?'高意向组':'全部 AI 输出组'} · ${row.sample_count}条评论`));const control=button(line,'打开此批次',async control=>{control.disabled=true;try{await loadBatch(row.batch_id);}catch(error){report(error.message,true);}finally{if(guard())control.disabled=!row.scope_matches;}});control.disabled=!row.scope_matches;if(!row.scope_matches)line.append(node('small','原电脑或员工范围待核对'));history.append(line);}}
    async function loadBatch(id){if(!opaque(id)){report('请填写有效的已有批次编号。',true);return;}const sequence=++readGeneration,value=await load('intent_quality_batch_get',{batch_id:id});if(!guard()||sequence!==readGeneration)return;if(value.batch_id!==id||value.prediction_hidden!==true||value.prediction_stage!=='post_local_policy'||value.evaluation_scope!=='current_stored_output_vs_current_frozen_source'||!integer(value.sample_count,0,100)||!Array.isArray(value.samples)||value.samples.length!==value.sample_count)throw Error('抽检批次身份或盲标范围无效。');for(const sample of value.samples)if(!opaque(sample.sample_id)||!integer(sample.revision,0,1000000)||!STATES.has(sample.source_state)||typeof sample.context_stale!=='boolean'||sample.source_state==='current'&&(typeof sample.text!=='string'||sample.text.length>6000))throw Error('抽检样本资料无效。');batch=value;batchId.value=id;renderSamples();await loadSummary(id,sequence);report('已读取固定的本机评论样本。历史模型输入绑定未核验；仅评估当前保存的最终输出与本批原文。');}
    function renderSamples(){if(!guard()||!batch)return;sampleHost.replaceChildren(node('h3',`本批${batch.sample_count}条评论`));if(!batch.sample_count)sampleHost.append(node('p','本批没有符合范围的有效软件AI输出；不能计算核验比例。请先补齐原评论和已有分析结果。','upgrade-muted'));for(const sample of batch.samples){
      const card=node('article','','card');card.append(node('strong',`样本编号：${sample.sample_id}`));
      if(sample.source_state==='unavailable'){card.append(node('p','原来源已不可读或权限不足，不能标注或用于当前指标。','upgrade-muted'));sampleHost.append(card);continue;}
      if(sample.source_state==='current')card.append(node('p',sample.text,'reply-source-comment'));else card.append(node('p','原文或软件输出已变化；本批历史依据仍保留，当前不能标注。','upgrade-muted'));
      const context=sample.context_public||{};if(context.parent_text||context.post_title){const details=node('details');details.append(node('summary','参考上下文（不作为本人找房依据）'));if(typeof context.parent_text==='string')details.append(node('p',context.parent_text));if(typeof context.post_title==='string')details.append(node('p',context.post_title));card.append(details);}
      if(sample.source_state==='stale')card.append(node('p','原文或保存的预测已变化，此样本当前失效，请另建批次。','upgrade-muted'));
      if(sample.context_stale)card.append(node('p','本机规则或公寓资料已变化；旧批次依据保留，当前房源匹配需重核。','upgrade-muted'));
      const review=node('form','','upgrade-operation-form');review.addEventListener('submit',event=>event.preventDefault());card.append(review);
      const label=sample.label||{},level=select(review,'人工意向等级',LEVELS,label.human_level||'uncertain'),self=select(review,'是否本人正在找房',[['yes','是'],['no','不是'],['uncertain','信息不足']],label.self_search||'uncertain'),matching=select(review,'与公寓资料的匹配',[['matches','可匹配'],['mismatch','不匹配'],['insufficient','资料不足']],label.matching||'insufficient');
      const textField=(caption,maximum,value='')=>{const wrap=node('label',caption),field=node('textarea');field.rows=2;field.maxLength=maximum;field.value=value;field.autocomplete='off';wrap.append(field);review.append(wrap);return field;};
      const reason=textField('人工核验理由',500,label.reason||''),quote=textField('本人评论中的原文依据',300,label.quote||'');reason.required=true;
      review.append(node('p','高/超高意向必须是本人找房，并有该条评论的明确原文依据。人工标注不是客户真实回应或成交。','upgrade-muted'));
      const reviewTarget=`${batch.batch_id}:${sample.sample_id}`,ownBatch=batch.batch_id;
      const refreshSample=async()=>{await loadBatch(ownBatch);};
      const save=button(review,'保存独立人工核验',async control=>{if(!review.reportValidity())return;await perform(view,control,async()=>{if(sample.source_state!=='current'){report('此来源已失效，未提交标注。',true);return;}if(['super_high','high'].includes(level.value)&&(self.value!=='yes'||!quote.value.trim()||!sample.text.includes(quote.value.trim()))){report('高意向需本人找房和这条评论的明确原文依据。',true);return;}await write('intent_quality_label',{batch_id:ownBatch,sample_id:sample.sample_id,expected_revision:sample.revision,human_level:level.value,self_search:self.value,matching:matching.value,reason:reason.value.trim(),quote:quote.value.trim()},reviewTarget);if(!guard())return;await refreshSample();report('已保存独立核验，原客户意向未改写。');});if(guard())renderSamples();});
      if(sample.source_state!=='current')for(const control of review.querySelectorAll('input,textarea,select,button'))control.disabled=true;
      const original=pending('intent_quality_label',reviewTarget);if(original){save.disabled=true;card.append(node('p',`人工标注保存结果待核对，继续保留原编号：${original.idempotency_key}`,'upgrade-muted'));button(card,'核对原人工标注',control=>perform(view,control,async()=>{await recoverOriginal('intent_quality_label',reviewTarget,refreshSample);}));}
      sampleHost.append(card);
    }}
    async function loadSummary(id,sequence){
      const raw=await load('intent_quality_summary',{batch_id:id});if(!guard()||sequence!==readGeneration)return;const value=checkedQualitySummary(raw,id),metric=value.current;
      const cards=[['抽样范围内可用评论',value.frame_count],['本批抽到的评论',value.sample_count],['已人工核验',value.labeled_count],['原文或预测失效',value.stale_count],['原来源不可读',value.unavailable_count],['资料版本变化',value.context_stale_count],['当前人工可判断分母',metric.decisive_denominator],['软件有明确输出分母',metric.agreement_denominator],['软件待核实输出',metric.software_abstention_count],['软件明确输出覆盖',qualityRate(metric.software_coverage)],['等级一致率',qualityRate(metric.agreement_rate)],['高意向确认分母',metric.high_precision_denominator],['高意向人工确认率',qualityRate(metric.high_precision)],['样本内高意向召回',metric.recall_estimable?qualityRate(metric.high_recall):'高意向筛选组不可估计'],['资料匹配可判断分母',metric.matching.decisive_denominator],['候选资料匹配一致',qualityRate(metric.matching.agreement_rate)]];
      summaryHost.replaceChildren(node('h3','当前有效样本的软件输出核验'));for(const [title,text]of cards){const line=node('div','','upgrade-record-line');line.append(node('span',title),node('strong',text));summaryHost.append(line);}
      const history=node('details');history.append(node('summary','查看原批次历史口径'),node('p',`可判断 ${value.historical.decisive_denominator} 条；明确输出 ${value.historical.agreement_denominator} 条；等级一致 ${qualityRate(value.historical.agreement_rate)}。原文或资料变化的样本保留历史，但不并入当前指标。`));summaryHost.append(history);
      const details=node('details');details.append(node('summary','查看已标注样本等级对照'));const table=node('table'),header=node('tr');header.append(node('th','软件输出 \ 人工判断'));for(const [,label]of LEVELS)header.append(node('th',label));table.append(header);metric.confusion_matrix.rows.forEach((row,index)=>{const line=node('tr');line.append(node('th',LEVELS[index][1]));for(const count of row)line.append(node('td',count));table.append(line);});details.append(table,node('p','行是软件最终输出，列是人工标注；待核实栏不作为判断正确或错误。仅完成标注且来源仍有权限的样本显示对照。','upgrade-muted'));summaryHost.append(details);
      summaryHost.append(node('p','评论样本统计；不代表全体客户、裸模型准确率、实际回应、资源部接收、成交或到账。历史输入绑定与实时云模型状态仍未核验。','upgrade-muted'));
    }
    button(form,'新建本批抽检',async control=>{if(!size.reportValidity())return;await perform(view,control,async()=>{const value=await write('intent_quality_batch_create',{limit:Number(size.value),cohort:cohort.value},target);if(!guard())return;batchId.value=value.batch_id;await loadBatch(value.batch_id);await loadHistory();redrawRecovery();});if(guard())redrawRecovery();});
    button(form,'打开已有批次',async control=>{control.disabled=true;try{await loadBatch(batchId.value.trim());}catch(error){report(error.message,true);}finally{if(guard())control.disabled=false;}});
    redrawRecovery();try{await loadHistory();if(guard())report('从已有软件AI输出建立固定抽检批次，或打开本人历史批次；未触发新分析。');}catch(error){report(error.message,true);}
  }
  return {open,reset:clear,dispose(){disposed=true;clear();}};
}
