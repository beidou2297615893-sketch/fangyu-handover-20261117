"""Current owner-visible source grouping only; no customer/contact/permission creation."""
from copy import deepcopy
import math,re,time
from core import CoreError
from .platform_receipt_archive import SOURCES,_hash
from .customer_list import _person

ACTION='owner_source_person_groups'
_FIELDS=frozenset(('id','account_id','group_id','platform','title','text','author','grade','analysis_status','analysis_verified','intent_level','analysis_reason','readonly_archive','can_reply'))
_ACTOR=('id','tenant_id','username','role','personal_owner','cloud_bound','disabled','permission_revision')

class OwnerSourcePeople:
    def __init__(self,workspace):
        from .self_operating_read import OwnerReadWorkspace
        if type(workspace) is not OwnerReadWorkspace or workspace.server._self_operating_reads is not workspace:
            raise CoreError('来源分组只能由本人工作台创建')
        self.workspace,self.core,self.instance=workspace,workspace.server.core,workspace.instance

    def _principal(self,token):
        w=self.workspace;user=w._actor(token)
        if (w.server._self_operating_reads is not w or w.server.core is not self.core or w.instance is not self.instance
            or w._identity!=(user['id'],user['tenant_id'],user['username']) or w._intent is None):
            raise CoreError('本人来源范围已变化')
        return user,_hash([self.instance.check()['selfOperatingRead'],{k:user.get(k) for k in _ACTOR}])

    def _capture(self,token,user,rows,cutoff):
        scope=[]
        for requested in rows:
            ident=requested['id'];lead=self.core._get('leads',ident,user['tenant_id']);uid=lead.get('source_uid')
            if type(uid) is not str or not uid:raise CoreError('原来源需核对')
            source_id=_hash([user['tenant_id'],uid]);source=self.core._get(SOURCES,source_id,user['tenant_id'])
            previous=int(source_id,16)-1
            if previous<0:raise CoreError('原来源位置需核对')
            page=self.workspace._source_page(token,user,1,{'schema':'owner_source_cursor_v1','after':format(previous,'064x'),'cutoff':cutoff})
            values=page.get('leads')
            if type(values) is not list or len(values)!=1 or values[0]!=requested:
                raise CoreError('原显示来源、分析证据或权限已变化')
            row=values[0]
            account=self.workspace._intent._source_account(token,user,row['account_id'])
            if account['platform']=='xiaohongshu':self.workspace._require_activity_safe(user,account)
            else:self.workspace._douyin._safe(user,account)
            author=source.get('author_id');kind=source.get('author_identity')
            if author in (None,''):
                if kind=='platform_id':raise CoreError('原作者标识需核对')
                author=''
            elif (type(author) is not str or re.fullmatch(r'[A-Za-z0-9_-]{1,160}',author) is None
                or author.casefold() in ('0','unknown','null','none','-') or kind!='platform_id'):
                raise CoreError('原作者标识需核对')
            provisional=not author or lead.get('privacy_redacted') is True or row['analysis_status']=='privacy_review_required'
            if provisional:key=_hash(['owner_source_person_temporary_v1',user['tenant_id'],ident])
            else:
                # Reuse the mature platform+UID identity rule on the existing
                # canonical archive value, never on the intentionally scrubbed
                # lead routing fields, nickname, work group or client payload.
                key,temporary,_=_person({'platform':row['platform'],'author_id':author})
                if temporary:raise CoreError('原作者标识需核对')
            opaque=_hash(['owner_source_person_group_v1',self.instance.check()['selfOperatingRead']['instance_id'],user['id'],user['tenant_id'],key])
            scope.append({'key':opaque,'provisional':provisional,'source':deepcopy(source),'lead':deepcopy(lead),'account':deepcopy(account)})
        return scope

    def execute(self,token,data):
        if type(data) is not dict or set(data)!={'request_id','cutoff','sources'}:
            raise CoreError('本人来源分组参数需核对')
        request=data['request_id'];cutoff=data['cutoff'];rows=deepcopy(data['sources'])
        if (type(request) is not str or re.fullmatch(r'[A-Za-z0-9_-]{8,128}',request) is None
            or type(cutoff) not in (int,float) or not math.isfinite(cutoff) or not 0<cutoff<=time.time()
            or type(rows) is not list or len(rows)>50
            or any(type(row) is not dict or set(row)!=_FIELDS or type(row.get('id')) is not str
                or re.fullmatch(r'[0-9a-f]{64}',row['id']) is None
                or any(type(row.get(k)) is not bool for k in ('analysis_verified','readonly_archive','can_reply')) for row in rows)
            or len({row['id'] for row in rows})!=len(rows)):
            raise CoreError('只接受本视图已有至多50条安全来源')
        with self.workspace._lock,self.core.lock:
            try:
                user,principal=self._principal(token)
                scope=self._capture(token,user,rows,cutoff)
                # Current checks span every contributor, including rows outside
                # the first returned group. Caller metadata never grants scope.
                current,now=self._principal(token)
                if now!=principal or self._capture(token,current,rows,cutoff)!=scope:
                    raise CoreError('原来源完整范围已变化')
                _,now=self._principal(token)
                if now!=principal:raise CoreError('本人范围已变化')
                groups=[];by_key={}
                for row,saved in zip(rows,scope):
                    key=saved['key']
                    if key not in by_key:
                        item={'person_key':key,'provisional':saved['provisional'],'display_name':row['author'],'source_ids':[],'source_count':0}
                        by_key[key]=item;groups.append(item)
                    by_key[key]['source_ids'].append(row['id']);by_key[key]['source_count']+=1
                return {'purpose':ACTION,'request_id':request,'source_ids':[row['id'] for row in rows],
                    'groups':groups,'source_count':len(rows),'person_count':len(groups),'coverage':'provided_sources_only',
                    'scope':'this_instance_owner','read_only':True,'local_only':True,'can_reply':False,'AI_started':False,
                    'platform_requests_started':False,'auto_retry':False,'identity_verified':False,'snapshot_verified':False}
            except Exception:
                raise CoreError('本人来源分组结果未确认；原来源或权限需核对，未生成客户或联系状态') from None
