const escape=value=>String(value??'').replace(/[&<>"']/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
const icon=name=>`<img class="mr-icon" src="/assets/${name}" alt="" aria-hidden="true">`;
const list=value=>Array.isArray(value)?value:[];
const scope=state=>JSON.stringify([state.user||'',state.storeId||'']);
const disabledIntent=item=>!item||item.disabled===true||item.enabled===false||(item.id==='rental-evidence'&&item.assessmentEnabled!==true);
function ui(state){
  state.managementRules??={};
  if(state.managementRules.actor!==scope(state))state.managementRules={actor:scope(state),storeChoice:state.storeId||'',phase:'idle',message:''};
  return state.managementRules;
}
function eligibleWords(material,searchId){
  return list(material?.keywords).filter(word=>word.eligible===true&&list(word.bindings).some(binding=>list(binding.presetIds).includes(searchId)&&(!binding.materialKey||binding.materialKey===material.key)));
}
function automaticWords(current,search,storeId,materialKey){
  const reference=search?.libraryReference,preset=current?.searchPresets?.[search?.id];
  if(current?.automaticProfile!==true||current.currentBindingConfirmed!==true||search?.automaticProfile!==true
    ||typeof current.profileDigest!=='string'||!current.profileDigest||search.profileDigest!==current.profileDigest
    ||reference?.profileDigest!==current.profileDigest||reference.storeId!==storeId||reference.id!==materialKey
    ||reference.bindingConfirmed!==true||current.storeId!==storeId||current.materialKey!==materialKey)return [];
  const names=list(search.keywords),ids=list(preset?.keywordIds),storedNames=list(preset?.keywords);
  if(names.length!==ids.length||names.length!==storedNames.length||new Set(ids).size!==ids.length
    ||names.some((word,index)=>typeof word!=='string'||!word.trim()||word!==storedNames[index])
    ||ids.some(id=>typeof id!=='string'||!id))return [];
  return names.map((keyword,index)=>({id:ids[index],keyword}));
}
function assessment(v){
  const policy=v.intent?.policyReference?.runtimeAssessment||{};
  const active=v.intent?.assessmentEnabled===true&&policy.supported===true&&policy.enabled===true;
  return {policy,active,label:active?'查看当前判断依据':policy.supported===false?'判断规则需要更新':'中央规则未启用'};
}
function view(state){
  const p=state.presets||{},current=state.materials?.currentSelection,stores=list(state.stores),searches=list(state.catalog?.search),intents=list(state.catalog?.intent);
  const searchId=p.search??state.selection?.searchPresetId??'',intentId=p.intent??state.selection?.intentPresetId??'';
  const search=searches.find(item=>item.id===searchId),intent=intents.find(item=>item.id===intentId);
  const materialKey=p.materialKey||current?.materialKey||'',material=list(state.materials?.materials).find(item=>item.key===materialKey);
  const automatic=current?.automaticProfile===true;
  const eligible=automatic?automaticWords(current,search,state.storeId,materialKey):eligibleWords(material,searchId),stored=list(p.keywordIds).length?list(p.keywordIds):list(current?.selectedKeywordIds);
  const ids=automatic?eligible.map(word=>word.id):stored.length?[...stored]:eligible.slice(0,100).map(word=>word.id);
  const selected=eligible.filter(word=>ids.includes(word.id));
  const actorMatches=current?.storeId===state.storeId&&current.materialKey===materialKey&&stores.some(store=>store.id===state.storeId);
  const invalidIds=automatic?false:ids.some(id=>!list(material?.keywords).some(word=>word.id===id&&word.eligible===true));
  const ready=state.connection==='connected'&&Boolean(state.storeId&&state.capabilities?.presets&&material&&actorMatches&&search&&!disabledIntent(intent)&&selected.length&&(automatic||ids.length<=100)&&!invalidIds);
  return {p,current,stores,searches,intents,searchId,intentId,search,intent,materialKey,material,eligible,ids,selected,ready,automatic};
}
function notice(state,v,u){
  if(state.connection==='loading'||state.busy)return u.phase==='saving'?'正在保存…':'正在加载…';
  if(u.message)return u.message;
  if(state.workspaceError)return '门店资料暂未加载';
  if(!v.stores.length)return '暂未分配门店';
  if(!state.storeId)return '请选择门店';
  if(!v.material||!v.search)return '门店方案待加载';
  if(disabledIntent(v.intent))return '请选择已开放的意向方案';
  if(!v.selected.length)return '当前方案暂无可用词';
  if(!v.automatic&&v.ids.length>100)return '本次选词超过100个，请在门店预设调整';
  return '';
}
function choice(item,current,kind,busy,index){
  const disabled=busy||(kind==='intent'&&disabledIntent(item));
  return `<label class="mr-choice ${current===item.id?'is-selected':''} ${disabled?'is-disabled':''}" for="mr-${kind}-${index}"><input id="mr-${kind}-${index}" type="radio" name="mr-${kind}" data-mr-${kind} value="${escape(item.id)}" ${current===item.id?'checked':''} ${disabled?'disabled':''}><span>${escape(item.name||item.id)}${kind==='intent'&&disabledIntent(item)?'（未启用）':''}</span></label>`;
}
export function render(state){
  const u=ui(state),v=view(state),busy=Boolean(state.busy||u.phase==='saving'||u.phase==='switching'),message=notice(state,v,u);
  const rule=state.materials?.intentRule||{},summary=state.materials?.rulesSummary||{};
  const status=assessment(v),activeRule=status.active;
  const priceVerified=(activeRule?status.policy.currentPricesVerified===true:summary.priceVerified===true&&rule.currentPricesVerified===true)&&v.material?.priceVerified===true;
  const evidenceText=status.label;
  const availableIntents=v.intents.filter(item=>['standard','recent','rental-evidence'].includes(item.id)||!disabledIntent(item));
  return `<div class="management-rules" data-management-rules>
    <section class="mr-card mr-store-bar" aria-label="当前门店">
      <div class="mr-store-heading"><h2>当前门店</h2><span class="mr-neutral">按门店保存</span></div>
      <div class="mr-store-controls"><label class="mr-store-select" for="mr-store-choice">${icon('tabler-upgrade-pin.svg')}<select id="mr-store-choice" data-mr-store aria-label="当前门店" ${busy||!v.stores.length?'disabled':''}><option value="" ${!u.storeChoice?'selected':''} disabled>选择门店</option>${v.stores.map(store=>`<option value="${escape(store.id)}" ${u.storeChoice===store.id?'selected':''}>${escape(store.name||store.id)}</option>`).join('')}</select>${icon('tabler-chevron-down.svg')}</label><button type="button" class="mr-switch" data-mr-switch ${busy||!u.storeChoice||u.storeChoice===state.storeId?'disabled':''}>${icon('fy-icon-63-refresh.png')}切换门店</button></div>
    </section>
    <div class="mr-columns">
      <section class="mr-card mr-column" aria-label="搜索方案">
        <header class="mr-card-heading">${icon('approved-icon-search.svg')}<h2>搜索方案</h2></header>
        <div class="mr-column-content">
          <section class="mr-field"><h3>搜索模式</h3><div class="mr-choices" role="group" aria-label="搜索模式">${v.searches.map((item,index)=>choice(item,v.searchId,'search',busy,index)).join('')||'<span class="mr-empty">暂无搜索方案</span>'}</div></section>
          <section class="mr-field"><h3>实际搜索词</h3><div class="mr-tags">${v.selected.slice(0,3).map(word=>`<span title="${escape(word.keyword)}">${escape(word.keyword)}</span>`).join('')||'<span class="mr-empty">当前方案暂无可用词</span>'}</div></section>
          <section class="mr-field"><h3>排除内容</h3><button type="button" class="mr-overview" data-mr-detail="exclude">${list(v.search?.excludeTerms).length?'已启用 '+list(v.search?.excludeTerms).length+' 个排除词':'当前服务器未配置排除词'}${icon('tabler-chevron-down.svg')}</button></section>
        </div>
        <button type="button" class="mr-card-summary" data-mr-detail="words">${icon('approved-icon-search.svg')}<span>${v.selected.length?escape(v.search?.name||'搜索方案')+' · '+v.selected.length+'个搜索词':'查看当前搜索方案'}</span></button>
      </section>
      <section class="mr-card mr-column" aria-label="客户判断">
        <header class="mr-card-heading">${icon('tabler-upgrade-user.svg')}<h2>客户判断</h2>${state.session?.user?.role==='admin'?'<button type="button" class="mr-overview" data-mr-central>中央规则文件</button>':''}</header>
        <div class="mr-column-content">
          <section class="mr-field"><h3>意向方案</h3><div class="mr-choices" role="group" aria-label="意向方案">${availableIntents.map((item,index)=>choice(item,v.intentId,'intent',busy,index)).join('')||'<span class="mr-empty">暂无意向方案</span>'}</div></section>
          <section class="mr-field"><h3>判断依据</h3><button type="button" class="mr-overview" data-mr-detail="evidence">${evidenceText}${icon('tabler-chevron-down.svg')}</button></section>
          <section class="mr-field"><h3>预算依据</h3><div class="mr-budget"><button type="button" class="mr-overview" data-mr-detail="budget">门店预算规则${icon('tabler-chevron-down.svg')}</button><span class="mr-budget-state ${priceVerified?'is-verified':''}">${priceVerified?'资料已核价':'待核实'}</span></div></section>
        </div>
        <button type="button" class="mr-card-summary" data-mr-detail="evidence">${icon('tabler-upgrade-user.svg')}<span>${activeRule?'查看当前判断规则':'沿用历史意向偏好'}</span></button>
      </section>
    </div>
    <section class="mr-card mr-save-bar" aria-label="方案保存"><div class="mr-save-copy"><strong><span>当前方案：</span>${escape(v.search?.name||'待选择')} · ${escape(v.intent?.name||'待选择')}</strong><small>本机保存搜索模式、意向偏好及本门店选词；开始获客会自动读取服务器最新有效词库。</small><span class="mr-status" role="${u.phase==='error'?'alert':'status'}" aria-live="polite">${escape(message)}</span></div><button type="button" class="mr-save" data-mr-save ${busy||!v.ready?'disabled':''}>${icon('tabler-upgrade-file.svg')}${u.phase==='saving'?'保存中…':'保存本门店方案'}</button></section>
  </div>`;
}
function details(state,kind){
  const v=view(state),rule=state.materials?.intentRule||{},summary=state.materials?.rulesSummary||{};
  const status=assessment(v);
  const priceVerified=(status.active?status.policy.currentPricesVerified===true:summary.priceVerified===true&&rule.currentPricesVerified===true)&&v.material?.priceVerified===true;
  if(kind==='exclude')return {title:'当前排除词',html:`<p>随当前搜索方案传入采集过滤。</p><div class="mr-detail-words">${list(v.search?.excludeTerms).map(word=>`<span>${escape(word)}</span>`).join('')||'服务器当前未配置排除词；仍按客户角色与意向结果筛选回复候选。'}</div>`};
  if(kind==='words')return {title:'实际关键词与来源',html:`<p>当前：${escape(v.search?.name||'暂未选择')} · ${v.selected.length}个搜索词</p>${v.searches.map(search=>`<section><h3>${escape(search.name||search.id)}</h3><div class="mr-detail-words">${list(search.keywords).map(word=>`<span>${escape(word)}</span>`).join('')||'暂无有效关键词'}</div>${list(search.sourceBindings).map(binding=>`<p>${escape(binding.keyword||'')} · ${escape(list(binding.sourceRefs).join('、'))}</p>`).join('')}</section>`).join('')}<p>词库版本：${escape(state.materials?.central?.revision||v.search?.libraryReference?.version||state.materials?.version||'未提供')}；来源：${escape(v.search?.materialName||v.material?.name||'当前门店资料')}。</p>${v.automatic?'<p>完整词库按方案保留，每次任务最多100个词，其余词按原方案分批使用。</p>':''}`};
  if(kind==='budget')return {title:'预算依据',html:`<p>${priceVerified?'门店资料已核价。':'门店价格尚未核实，预算匹配保持待确认。'}</p>${list(rule.budgetPrinciples).map(text=>`<p>${escape(text)}</p>`).join('')}${list(rule.incomePrinciples).map(text=>`<p>${escape(text)}</p>`).join('')}`};
  const overview=state.materials?.intentPolicyOverview||{},local=state.materials?.localAssessmentOverview||{},labels={super_high:'超高',high:'高',medium:'中',low:'低',very_low:'极低'};
  return {title:'意向标准与执行来源',html:`<p>每批保存后调用企业已配置AI进行结构化意向分析，再继续采集。AI使用服务器当前发布的规则与提示词；此接口未返回完整远端提示词，不把本地规则当作远端提示词。</p><h3>${overview.source==='unavailable'?'本地规则暂未读取':Number(overview.revision)>0?'本地已保存的五级分级标准':'本地初始分级标准（尚未保存）'}</h3>${overview.can_manage&&overview.criteria?Object.entries(overview.criteria).map(([level,text])=>`<p><strong>${escape(labels[level]||level)}：</strong>${escape(text)}</p>`).join(''):'<p>详细企业分级标准仅策略管理员可见。</p>'}<p>本地规则版本：${escape(overview.revision??'未提供')}；摘要：${escape(overview.digest||'未提供')}。</p><h3>本机客户证据筛选</h3>${list(local.standards).map(row=>`<p><strong>${escape(row.label)}（${escape(row.code)}）：</strong>${escape(row.description)}</p>`).join('')}<p>引擎：${escape(local.engineVersion||status.policy.engineVersion||'未提供')}。${escape(local.budget||'')}${escape(local.income||'')}</p><p>原始资料版本：${escape(rule.version||'未提供')}；信号：${escape(list(rule.signals).join('；'))}。</p>`};
}
export function bind(root,ctx){
  let disposed=false;
  const boundUser=ctx.state.user||'';
  const boundScope=scope(ctx.state);
  const change=fn=>ctx.update(state=>{fn(ui(state),state);});
  const canMutate=()=>!disposed&&scope(ctx.state)===boundScope&&!ctx.state.busy&&!['saving','switching'].includes(ui(ctx.state).phase);
  root.querySelector('[data-mr-store]')?.addEventListener('change',event=>{if(canMutate())change(u=>{u.storeChoice=event.target.value;u.message='';});});
  root.querySelector('[data-mr-switch]')?.addEventListener('click',async()=>{
    if(!canMutate())return;
    const v=view(ctx.state),id=ui(ctx.state).storeChoice;
    if(!id||id===ctx.state.storeId||!v.stores.some(store=>store.id===id))return;
    if(typeof ctx.actions?.selectStore!=='function'){change(u=>{u.phase='error';u.message='切换暂不可用';});return;}
    change(u=>{u.phase='switching';u.message='';});
    try{await ctx.actions.selectStore(id);if((ctx.state.user||'')===boundUser&&ctx.state.storeId!==id)change(u=>{u.phase='error';u.message='门店尚未切换，请核对后重试';});}
    catch(error){if((ctx.state.user||'')===boundUser)change(u=>{u.phase='error';u.message=error?.message||'门店切换失败';});}
    finally{if((ctx.state.user||'')===boundUser&&ui(ctx.state).phase==='switching')change(u=>{u.phase='idle';});}
  });
  root.querySelectorAll('[data-mr-search]').forEach(input=>input.addEventListener('click',()=>{
    if(!canMutate())return;
    const v=view(ctx.state),id=input.value;
    if(!v.searches.some(item=>item.id===id)||!v.material)return;
    const selected=v.automatic?automaticWords(v.current,v.searches.find(item=>item.id===id),ctx.state.storeId,v.materialKey):eligibleWords(v.material,id).slice(0,100);
    change((u,state)=>{state.presets??={};Object.assign(state.presets,{search:id,materialKey:v.material.key,keywordIds:selected.map(word=>word.id)});u.phase='idle';u.message='';});
  }));
  root.querySelectorAll('[data-mr-intent]').forEach(input=>input.addEventListener('click',()=>{
    if(!canMutate())return;
    const option=view(ctx.state).intents.find(item=>item.id===input.value);
    if(disabledIntent(option))return;
    change((u,state)=>{state.presets??={};state.presets.intent=option.id;u.phase='idle';u.message='';});
  }));
  root.querySelector('[data-mr-central]')?.addEventListener('click',()=>{
    if(!disposed&&scope(ctx.state)===boundScope&&ctx.state.session?.user?.role==='admin')ctx.actions?.openRuleFiles?.();
  });
  root.querySelectorAll('[data-mr-detail]').forEach(button=>button.addEventListener('click',()=>{
    if(disposed||scope(ctx.state)!==boundScope)return;
    const info=details(ctx.state,button.dataset.mrDetail);
    ctx.modal?.({...info,confirmLabel:'知道了'});
  }));
  root.querySelector('[data-mr-save]')?.addEventListener('click',async()=>{
    if(!canMutate())return;
    const v=view(ctx.state);if(!v.ready)return;
    if(typeof ctx.actions?.applyPreset!=='function'){change(u=>{u.phase='error';u.message='保存暂不可用';});return;}
    const expected={actor:scope(ctx.state),storeId:ctx.state.storeId,search:v.searchId,intent:v.intentId,revision:ctx.state.selection?.revision??0};
    change((u,state)=>{state.presets??={};Object.assign(state.presets,{search:v.searchId,intent:v.intentId,materialKey:v.materialKey,keywordIds:[...v.ids]});u.phase='saving';u.message='';});
    try{
      const result=await ctx.actions.applyPreset();
      if(scope(ctx.state)!==expected.actor)return;
      const saved=ctx.state.selection,confirmed=saved?.storeId===expected.storeId&&saved.searchPresetId===expected.search&&saved.intentPresetId===expected.intent&&Number(saved.revision)>expected.revision;
      change(u=>{u.phase=confirmed||result===true||result?.ok===true?'saved':'error';u.message=u.phase==='saved'?'本门店方案已保存':'保存结果待确认，请核对状态';});
    }catch(error){if(scope(ctx.state)===expected.actor)change(u=>{u.phase='error';u.message=error?.message||'保存失败，请稍后重试';});}
  });
  return ()=>{disposed=true;};
}

