"""Evidence catalog and explicit employee/store material selection.

Material keys identify public source groups, never cloud store permissions.
The caller must freshly authorize each actual store ID before passing it here.
No collection, messaging, AI, policy activation or verified price write occurs.
"""
import hashlib
import json
import re
import threading
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path

from assistant.acquisition_strategy import normalize_keywords, StrategyError

ENTITY = 'store_material_selections_v1'
SCHEMA = 'fangyu-store-materials-catalog/1'
STORE_ID = re.compile(r'[A-Za-z0-9_-]{1,80}\Z')


class StoreMaterialsError(ValueError):
    def __init__(self, code, message, status=400):
        super().__init__(message)
        self.code, self.status = code, status
        self.mutation_committed = False


def _digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
        separators=(',', ':'), allow_nan=False).encode('utf-8')).hexdigest()


class StoreMaterials:
    def __init__(self, core, catalog_path=None, *, expected_sha256=None):
        self.core, self.lock = core, threading.RLock()
        self.catalog_path = Path(catalog_path or Path(__file__).with_name('store_materials_catalog.json'))
        try:
            raw = self.catalog_path.read_bytes()
            if expected_sha256 is not None and (not isinstance(expected_sha256, str)
                    or hashlib.sha256(raw).hexdigest() != expected_sha256.lower()):
                raise ValueError('catalog file pin')
            package = json.loads(raw.decode('utf-8-sig'))
            body = {key: value for key, value in package.items() if key != 'digest'}
            if package.get('schema_version') != SCHEMA or package.get('digest') != _digest(body):
                raise ValueError('catalog digest')
            self.materials = {row['key']: row for row in package['materials']}
            self.keywords = {row['id']: row for row in package['keywords']}
            if len(self.materials) != len(package['materials']) or len(self.keywords) != len(package['keywords']):
                raise ValueError('duplicate catalog IDs')
        except (OSError, ValueError, KeyError, TypeError):
            raise StoreMaterialsError('MATERIAL_CATALOG_INVALID', '门店资料目录暂不可用，请联系管理员', 503) from None
        self.package = package
        self.rule_version = package.get('intentRule', {}).get('version', package['rulesSummary'].get('version'))

    def use_central_config(self, config, metadata):
        """Consume a freshly authorized server mapping; it does not grant access itself."""
        package = deepcopy(config.get('package'))
        if (not isinstance(package,dict) or package.get('schema_version') != SCHEMA
                or package.get('digest') != _digest({k:v for k,v in package.items() if k!='digest'})
                or len(package.get('materials',[])) != 1
                or package['materials'][0].get('key') != config.get('material_key')
                or not isinstance(config.get('store_id'),str) or not STORE_ID.fullmatch(config['store_id'])):
            raise StoreMaterialsError('CENTRAL_CONFIG_INVALID','中央门店配置未通过核对',503)
        assessment=config.get('runtimeAssessment') or {}
        if not isinstance(assessment,dict):
            raise StoreMaterialsError('CENTRAL_CONFIG_INVALID','中央判断执行契约结构无效',503)
        runtime=self._validate_runtime(config.get('runtimeSearch'),config['material_key'])
        with self.lock:
            self.package=package
            self.materials={row['key']:row for row in package['materials']}
            self.keywords={row['id']:row for row in package['keywords']}
            self.central={**deepcopy(metadata),'storeId':config['store_id'],'materialKey':config['material_key'],
                'evaluatorVersion':config.get('evaluator_version')}
            self.runtime_search = runtime
            self.runtime_assessment = deepcopy(config.get('runtimeAssessment') or {})
            if self.runtime_search:
                self.central.update(runtimeSearchRevision=self.runtime_search['revision'], runtimeSearchDigest=_digest(self.runtime_search))
            self.rule_version = self.runtime_assessment.get('engineVersion')
            self.automatic_profile = self._automatic_profile(config['material_key']) if self.runtime_search else None

    @staticmethod
    def _validate_runtime(runtime, material_key):
        if runtime is None:
            return None
        def text(value, limit=200):
            return isinstance(value,str) and 0<len(value)<=limit and not any(ord(c)<32 or ord(c)==127 for c in value)
        def refs(value):
            return isinstance(value,list) and 0<len(value)<=200 and all(text(v) for v in value)
        valid = (isinstance(runtime,dict) and runtime.get('schema')=='fangyu-runtime-search/1'
            and runtime.get('material_key')==material_key and text(runtime.get('revision'))
            and isinstance(runtime.get('queries'),list) and len(runtime['queries'])<=10000
            and isinstance(runtime.get('excludeTerms'),list) and len(runtime['excludeTerms'])<=1000
            and all(text(v,100) for v in runtime['excludeTerms']))
        if valid:
            for row in runtime['queries']:
                if (not isinstance(row,dict) or not text(row.get('query'),80) or row['query']!=row['query'].strip()
                        or row.get('tier') not in ('direct','context','exploratory') or not refs(row.get('sourceRefs'))
                        or not text(row.get('source')) or not isinstance(row.get('holdReasons',[]),list)):
                    valid=False;break
                bindings=row.get('sourceBindings')
                if (not isinstance(bindings,list) or not bindings or len(bindings)>200 or any(
                    not isinstance(b,dict) or b.get('materialKey')!=material_key
                    or b.get('tier') not in ('direct','context','exploratory') or not refs(b.get('sourceRefs'))
                    or not text(b.get('sourceArtifactId')) or not text(b.get('sourcePointer'),1000)
                    for b in bindings)):
                    valid=False;break
        if not valid:
            raise StoreMaterialsError('CENTRAL_CONFIG_INVALID','中央可执行词与门店来源未通过核对',503)
        return deepcopy(runtime)

    def _automatic_profile(self, material_key):
        # Retain all qualifying bindings before deduplicating literal queries.
        runtime=self.runtime_search; groups={}
        def add(query, ident, binding, presets):
            item=groups.setdefault(query,{'id':ident,'keyword':query,'bindings':[],'presets':set()})
            item['bindings'].append(binding);item['presets'].update(presets)
        material=self.materials[material_key]
        for ident in material['keywordIds']:
            word=self.keywords[ident]
            if word.get('csvCandidateEligible') is not True:continue
            for binding in word['bindings']:
                if binding.get('materialKey')!=material_key or binding.get('csvCandidateEligible') is not True or binding.get('holdReasons'):continue
                add(word['keyword'].strip(),ident,{**deepcopy(binding),'keywordId':ident,'source':'catalog_candidate',
                    'bundleRevision':self.central['revision'],'runtimeRevision':runtime['revision']},binding.get('presetIds',[]))
        for row in runtime['queries']:
            if row.get('eligibleHypothesis') is not True or row.get('holdReasons'):continue
            ident='runtime-'+_digest([material_key,row['query']])[:32]
            for binding in row['sourceBindings']:
                add(row['query'],ident,{**deepcopy(binding),'keywordId':ident,'source':row['source'],
                    'eligibleHypothesis':True,'holdReasons':[], 'bundleRevision':self.central['revision'],
                    'runtimeRevision':runtime['revision']},['precise','commute'])
        words=list(groups.values())
        presets={key:{'keywords':[],'keywordIds':[],'sourceBindings':[]} for key in ('precise','commute')}
        bindings=[]
        for word in words:
            item={'keywordId':word['id'],'keyword':word['keyword'],'materialKey':material_key,
                'sourceRefs':list(dict.fromkeys(ref for b in word['bindings'] for ref in b['sourceRefs'])),
                'bindings':word['bindings']}
            bindings.append(item)
            for key in word['presets']:
                if key not in presets:continue
                presets[key]['keywords'].append(word['keyword']);presets[key]['keywordIds'].append(word['id'])
                presets[key]['sourceBindings'].append(deepcopy(item))
        digest=_digest({'keywords':[w['keyword'] for w in words],'bindings':bindings,'central':self.central})
        return {'selectedKeywordIds':[w['id'] for w in words],'selectedKeywords':[w['keyword'] for w in words],
            'keywordBindings':bindings,'searchPresets':presets,'automaticProfile':True,'profileDigest':digest,
            'totalEligible':len(words),'runLimit':100,'sourceRevision':runtime['revision']}

    def _authorize(self, user, db=None):
        if not isinstance(user, dict) or not all(isinstance(user.get(k), str) and user[k]
                for k in ('id', 'tenant_id', 'username')):
            raise StoreMaterialsError('AUTH_REQUIRED', '请先使用企业员工账号登录', 401)
        if db is None:
            current = self.core.store.get('users', user['id'])
        else:
            found = db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
                ('users', user['id'], user['tenant_id'])).fetchone()
            current = json.loads(found['body']) if found else None
        identity = ('id', 'tenant_id', 'username', 'role', 'cloud_bound')
        if (not isinstance(current, dict) or current.get('disabled')
                or current.get('role') not in ('operator','admin') or current.get('cloud_bound') is not True
                or any(current.get(key) != user.get(key) for key in identity)):
            raise StoreMaterialsError('AUTH_REQUIRED', '员工身份或资料归属已变化，请重新登录', 401)

    @staticmethod
    def _store_id(value):
        if not isinstance(value, str) or not STORE_ID.fullmatch(value):
            raise StoreMaterialsError('STORE_FORBIDDEN', '需要已核对的实际授权门店', 403)
        return value

    def catalog(self, user, authorized_stores, selection=None):
        """Return public evidence only; authorized_stores is a trusted caller input."""
        self._authorize(user)
        if not isinstance(authorized_stores, list):
            raise StoreMaterialsError('STORE_FORBIDDEN', '授权门店列表无效', 403)
        stores = [{'id': self._store_id(row.get('id')), 'name': row.get('name', row['id'])}
                  for row in authorized_stores if isinstance(row, dict)]
        materials = deepcopy(self.package['materials'])
        for row in materials:
            row['selectableKeywordIds'] = list(row['keywordIds'])
            row['captureStatus'] = row.get('captureStatus', row.get('status', 'candidate'))
            row['keywords'] = []
            for ident in [*row['keywordIds'], *row['heldKeywordIds']]:
                word = self.keywords[ident]
                matching = [binding for binding in word['bindings'] if binding['materialKey'] == row['key']]
                row['keywords'].append({'id': ident, 'keyword': word['keyword'],
                    'eligible': (ident in row['keywordIds'] and word.get('csvCandidateEligible') is True
                        and any(binding.get('csvCandidateEligible') is True and not binding.get('holdReasons')
                                for binding in matching)),
                    'enabled': False, 'clusters': word.get('clusters', []),
                    'priority': word['priority'], 'priorityBasis': 'manual_validation_order_not_search_popularity',
                    'sourceRefs': list(dict.fromkeys(ref for binding in matching for ref in binding['sourceRefs'])),
                    'bindings': deepcopy(matching)})
        current = None
        selected_store = selection.get('storeId') if isinstance(selection, dict) else stores[0]['id'] if stores and user.get('role') == 'operator' else None
        if selected_store in {row['id'] for row in stores}:
            current = self.read_selection(user, selected_store)
        return {'version': self.package['version'], 'digest': self.package['digest'],
            'cities': list(dict.fromkeys(row['city'] for row in materials if row['city'])),
            'materials': materials, 'keywords': deepcopy(self.package['keywords']),
            'authorizedStores': stores, 'currentSelection': current,
            'storeIdMappingStatus': 'server_internal_mapping' if getattr(self,'central',None) else 'pending_explicit_confirmation',
            'central':deepcopy(getattr(self,'central',None)), 'saveScope':'local_store_selection',
            'intentRule':{key:deepcopy(value) for key,value in self.package.get('intentRule',{}).items()
                if key in ('version','description','signals','budgetPrinciples','incomePrinciples',
                           'currentPricesVerified','status','enabled','changesIntentPolicy')},
            'rulesSummary': deepcopy(self.package['rulesSummary']),
            'runtimeAssessment': deepcopy(getattr(self,'runtime_assessment',{}))}

    @staticmethod
    def _selection_id(user, store_id):
        return _digest(['store-material-selection-v1', user['tenant_id'], user['username'], store_id])

    def _read_row(self, user, store_id, db=None):
        ident = self._selection_id(user, store_id)
        if db is None:
            row = self.core.store.get(ENTITY, ident)
        else:
            found = db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
                (ENTITY, ident, user['tenant_id'])).fetchone()
            row = json.loads(found['body']) if found else None
        if row and (row.get('tenant_id') != user['tenant_id'] or row.get('owner') != user['username']
                or row.get('storeId') != store_id):
            raise StoreMaterialsError('MATERIAL_SCOPE_INVALID', '门店资料归属无法核对', 409)
        if row and (type(row.get('revision')) is not int or row['revision'] < 1):
            raise StoreMaterialsError('MATERIAL_SELECTION_INVALID', '门店资料版本无法核对', 409)
        return row

    def _public_selection(self, store_id, row):
        value = {'storeId': store_id, 'revision': 0, 'materialKey': None,
            'materialVersion': None, 'catalogDigest': None, 'source_material_name': '',
            'bindingStatus': 'unbound', 'bindingConfidence': 'unconfirmed',
            'bindingConfirmed': False, 'currentBindingConfirmed': False,
            'selectedKeywordIds': [], 'selectedKeywords': [], 'keywordBindings': [],
            'searchPresets': {key: {'keywords': [], 'keywordIds': [], 'sourceBindings': []}
                              for key in ('precise', 'commute')},
            'needsReapply': False, 'priceVerified': False, 'verifiedMonthlyPrice': None,
            'startsCollection': False, 'sendsMessages': False, 'callsAI': False,
            'savedAt': None}
        central=getattr(self,'central',None)
        if central and central['storeId']==store_id:
            material=self.materials[central['materialKey']]
            value.update(materialKey=central['materialKey'],materialVersion=self.package['version'],
                catalogDigest=self.package['digest'],source_material_name=material['name'],
                bindingStatus='server_internal_mapping',bindingConfidence='server_internal_mapping',
                bindingConfirmed=True,currentBindingConfirmed=True)
            if row and row.get('materialKey')!=central['materialKey']:
                row=None
        if row:
            value.update({key: deepcopy(row[key]) for key in value if key in row})
            value['needsReapply'] = row.get('catalogDigest') != self.package['digest']
            value['currentBindingConfirmed'] = not value['needsReapply']
            if value['needsReapply']:
                value['bindingStatus'] = 'catalog_changed_reapply_required'
                value['selectedKeywords'] = []
                value['searchPresets'] = {key: {'keywords': [], 'keywordIds': [], 'sourceBindings': []}
                                          for key in ('precise', 'commute')}
        automatic=getattr(self,'automatic_profile',None)
        if central and central['storeId']==store_id and automatic:
            value.update(deepcopy(automatic),needsReapply=False,currentBindingConfirmed=True)
        return value

    def read_selection(self, user, authorized_store_id):
        """Caller must recheck this actual store ID against the fresh cloud profile."""
        with self.core.lock, self.lock:
            self._authorize(user)
            store_id = self._store_id(authorized_store_id)
            return self._public_selection(store_id, self._read_row(user, store_id))

    def _chosen_keywords(self, material_key, keyword_ids):
        automatic=getattr(self,'automatic_profile',None)
        if automatic and material_key==(getattr(self,'central',None) or {}).get('materialKey'):
            return deepcopy(automatic['selectedKeywords']),deepcopy(automatic['keywordBindings']),deepcopy(automatic['searchPresets'])
        if not isinstance(keyword_ids, list) or len(keyword_ids) > 100:
            raise StoreMaterialsError('MATERIAL_KEYWORDS_INVALID', '每个门店最多选择100个关键词')
        if any(not isinstance(ident, str) for ident in keyword_ids) or len(set(keyword_ids)) != len(keyword_ids):
            raise StoreMaterialsError('MATERIAL_KEYWORDS_INVALID', '请选择有效且不重复的关键词')
        bindings, selected, presets = [], [], {key: {'keywords': [], 'keywordIds': [], 'sourceBindings': []}
                                             for key in ('precise', 'commute')}
        material = self.materials[material_key]
        for ident in keyword_ids:
            keyword = self.keywords.get(ident)
            if (keyword is None or ident not in material['keywordIds']
                    or keyword.get('csvCandidateEligible') is not True or keyword.get('enabled') is not False):
                raise StoreMaterialsError('MATERIAL_KEYWORD_HELD', '此关键词不属于可选门店候选词')
            matches = [row for row in keyword['bindings'] if row['materialKey'] == material_key
                       and row.get('csvCandidateEligible') is True and not row.get('holdReasons')]
            if not matches:
                raise StoreMaterialsError('MATERIAL_KEYWORD_HELD', '该门店关键词证据仍待核对')
            try:
                normalized = normalize_keywords([{'keyword': keyword['keyword'], 'group': keyword['group'],
                    'priority': keyword['priority'], 'enabled': False}])[0]['keyword']
            except (StrategyError, IndexError, KeyError, TypeError):
                raise StoreMaterialsError('MATERIAL_KEYWORDS_INVALID', '关键词不符合既有导入格式') from None
            if len(normalized) > 80:
                raise StoreMaterialsError('MATERIAL_KEYWORDS_INVALID', '采集关键词最多80字')
            source = {'keywordId': ident, 'keyword': normalized, 'materialKey': material_key,
                'sourceRefs': list(dict.fromkeys(ref for row in matches for ref in row['sourceRefs'])),
                'noteIds': list(dict.fromkeys(ref for row in matches for ref in row['noteIds'])),
                'sourceArtifactIds': list(dict.fromkeys(row['sourceArtifactId'] for row in matches)),
                'rawKeywordIds': list(dict.fromkeys(row['rawKeywordId'] for row in matches if row['rawKeywordId'])),
                'rawKeywordPointers': list(dict.fromkeys(row['rawKeywordPointer'] for row in matches if row['rawKeywordPointer']))}
            bindings.append(source)
            selected.append(normalized)
            for preset in presets:
                if any(preset in row['presetIds'] for row in matches):
                    presets[preset]['keywords'].append(normalized)
                    presets[preset]['keywordIds'].append(ident)
                    presets[preset]['sourceBindings'].append(deepcopy(source))
        return selected, bindings, presets

    def save_selection(self, user, authorized_store_id, material_key, keyword_ids, expected_revision,
                       *, confirm_binding=False, expected_catalog_digest=None, db=None):
        """CAS-save an explicit material binding without starting collection.

        db=None owns BEGIN IMMEDIATE and commit. A supplied active connection
        belongs to the caller: no BEGIN/commit is issued, so later prefs failures
        roll this selection back together. The caller holds core.lock in that mode.
        """
        if db is None:
            with self.core.lock, self.lock, self.core.store.connect() as connection:
                connection.execute('BEGIN IMMEDIATE')
                return self.save_selection(user, authorized_store_id, material_key, keyword_ids,
                    expected_revision, confirm_binding=confirm_binding,
                    expected_catalog_digest=expected_catalog_digest, db=connection)
        if not db.in_transaction:
            raise StoreMaterialsError('MATERIAL_TRANSACTION_REQUIRED', '资料应用需要当前有效事务', 409)
        self._authorize(user, db)
        store_id = self._store_id(authorized_store_id)
        if type(expected_revision) is not int or expected_revision < 0:
            raise StoreMaterialsError('MATERIAL_REVISION_INVALID', '需要当前门店资料版本')
        current = self._read_row(user, store_id, db)
        if expected_revision != (current['revision'] if current else 0):
            raise StoreMaterialsError('MATERIAL_REVISION_CONFLICT', '资料已在其他窗口更新，请重新读取', 409)
        if expected_catalog_digest != self.package['digest']:
            raise StoreMaterialsError('MATERIAL_CATALOG_STALE', '资料目录已更新，请重新读取后确认', 409)
        central=getattr(self,'central',None)
        if central and (central['storeId']!=store_id or central['materialKey']!=material_key):
            raise StoreMaterialsError('MATERIAL_SCOPE_INVALID','资料不属于服务器当前门店映射',403)
        if central:
            confirm_binding=True
        same_confirmed_binding = bool(current and current.get('bindingConfirmed') is True
            and current.get('materialKey') == material_key and current.get('catalogDigest') == self.package['digest'])
        if type(confirm_binding) is not bool or (not confirm_binding and not same_confirmed_binding):
            raise StoreMaterialsError('MATERIAL_BINDING_CONFIRMATION_REQUIRED', '请明确确认资料与授权门店的对应关系')
        if not isinstance(material_key, str) or material_key not in self.materials:
            raise StoreMaterialsError('MATERIAL_INVALID', '请选择当前目录中的门店资料')
        material = self.materials[material_key]
        if material.get('status') == 'expired':
            raise StoreMaterialsError('MATERIAL_UNAVAILABLE', '笔记已过期，尚无可应用的门店资料')
        selected, bindings, presets = self._chosen_keywords(material_key, keyword_ids)
        record = {**self._public_selection(store_id, None),
            'id': self._selection_id(user, store_id), 'tenant_id': user['tenant_id'],
            'owner': user['username'], 'revision': expected_revision + 1,
            'materialKey': material_key, 'materialVersion': self.package['version'],
            'catalogDigest': self.package['digest'], 'source_material_name': material['name'],
            'bindingStatus': 'server_internal_mapping' if central else 'confirmed', 'bindingConfidence': ('server_internal_mapping' if central else 'explicit_user_confirmed'
                if confirm_binding else 'existing_user_confirmed'),
            'bindingConfirmed': True, 'currentBindingConfirmed': True,
            'selectedKeywordIds': list(keyword_ids), 'selectedKeywords': selected,
            'keywordBindings': bindings, 'searchPresets': presets,
            'savedAt': datetime.now(timezone.utc).isoformat()}
        db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',
            (ENTITY, record['id'], record['tenant_id'], json.dumps(record, ensure_ascii=False, allow_nan=False)))
        return self._public_selection(store_id, record)


def build_runtime_catalog(pack, rules):
    """Project the handoff into public runtime data, omitting paths and contacts."""
    phone = re.compile(r'(?<!\d)(?:\+?86[- ]?)?1[3-9]\d{9}(?!\d)|(?<!\d)0\d{2,3}[- ]?\d{7,8}(?!\d)')
    def text(value):
        return phone.sub('[联系人已省略]', value) if isinstance(value, str) else ''
    def unique(values):
        return list(dict.fromkeys(values))
    source_notes = {source['source_ref']: source.get('note_id') for source in pack['sources']}
    artifacts = {source['path']: source['artifact_id'] for source in pack['source_artifacts']}
    keywords = []
    for word in pack['keywords']:
        rows = []
        for binding in word['bindings']:
            refs = list(binding['source_refs'])
            cluster = text(binding.get('cluster', ''))
            query = text(word['keyword'])
            commute = bool(re.search(r'地铁|通勤|公交|轨道|高铁|火车|机场|号线|沿线|站(?:附近|周边|租房|公寓)|大学|医院|产业园|科技园|软件园|上班', query)
                or cluster in ('交通', '轨道交通', '广域交通', '就业地点', '跨区通勤', '公交场景'))
            for material_key in binding['local_store_refs']:
                rows.append({'materialKey': material_key,
                    'csvCandidateEligible': bool(word['csv_candidate_eligible'] and binding['csv_candidate_eligible']
                        and not binding.get('hold_reasons')),
                    'presetIds': ['precise', 'commute'] if commute else ['precise'],
                    'sourceRefs': refs, 'noteIds': unique(source_notes.get(ref) for ref in refs if source_notes.get(ref)),
                    'factRefs': list(binding.get('fact_refs', [])),
                    'sourceArtifactId': binding.get('source_artifact_id') or artifacts[binding['source_artifact']],
                    'rawKeywordId': binding.get('raw_keyword_id'),
                    'rawKeywordPointer': binding.get('raw_keyword_pointer'),
                    'cluster': cluster, 'holdReasons': [text(reason) for reason in binding.get('hold_reasons', [])]})
        if word['enabled'] is not False:
            raise ValueError('Source candidates must remain disabled')
        normalized = normalize_keywords([{'keyword': text(word['keyword']), 'group': text(word['import_group']),
            'priority': word['priority'], 'enabled': False}])[0]
        if len(normalized['keyword']) > 80:
            raise ValueError('Runtime word exceeds collection limit')
        keywords.append({'id': word['keyword_id'], 'keyword': normalized['keyword'],
            'group': normalized['group'], 'priority': normalized['priority'],
            'priorityBasis': 'manual_validation_order_not_search_popularity',
            'enabled': False, 'csvCandidateEligible': word['csv_candidate_eligible'],
            'clusters': [text(value) for value in word['clusters']], 'bindings': rows,
            'volume': 'Unknown', 'difficulty': 'Unknown'})
    word_map = {row['id']: row for row in keywords}
    notes_by_id = {row['note_id']: row for row in pack['source_notes']}
    materials = []
    for store in pack['stores']:
        eligible = [ident for ident in store['csv_candidate_keyword_ids'] if any(
            row['materialKey'] == store['local_store_ref'] and row['csvCandidateEligible']
            for row in word_map[ident]['bindings'])]
        if len(eligible) > 100:
            raise ValueError('Runtime material exceeds 100-word limit')
        expired = store['group_status'] == 'expired_name_candidate_only'
        missing_media = sum(notes_by_id[ident].get('counts', {}).get('missing', 0)
            + notes_by_id[ident].get('coverage', {}).get('media_missing', 0) for ident in store['note_ids'])
        facts = []
        for field, source_field in [('资料地址（待核）', 'address_raw'), ('资料地点名称（待核）', 'poi_name_raw')]:
            if store.get(source_field):
                facts.append({'field': field, 'value': text(store[source_field]), 'verified': False,
                    'sourceRefs': list(store['source_refs'])})
        materials.append({'key': store['local_store_ref'], 'name': text(store['name']),
            'aliases': [text(value) for value in store.get('aliases_from_material', [])],
            'city': text(store.get('city', '')), 'district': text(store.get('district', '')),
            'status': 'expired' if expired else 'candidate',
            'captureStatus': 'expired' if expired else 'partial_media' if missing_media else 'archived_evidence',
            'missingOriginalMediaCount': missing_media,
            'noteIds': list(store['note_ids']), 'sourceRefs': list(store['source_refs']),
            'factRefs': list(store.get('fact_refs', [])), 'keywordIds': eligible,
            'heldKeywordIds': [ident for ident in store['keyword_ids'] if ident not in eligible],
            'publicFactsSummary': facts, 'priceVerified': False, 'verifiedMonthlyPrice': None,
            'storeIdMappingStatus': 'pending_explicit_confirmation'})
    intent_rule = {'version': rules['version'],
        'description': '初始意向规则结合求租角色、当前需求、咨询及行动语境；尚未经真实客户业务校准。',
        'signals': [text(row['meaning']) for row in rules['signals']],
        'budgetPrinciples': [
            '只从客户自身或明确共同求租者的预算原话提取，保留范围、上下限及修改否定。',
            '区分币种、周期、费用口径及整套/每人；未写单位不默认元/月。',
            '未确认门店映射和有效月租报价时，预算匹配保持不可比较。'],
        'incomePrinciples': [
            '只记录客户明确自报且属于本人的收入原话；没有原话保持未知。',
            '不把家庭、夫妻或他人收入改为本人收入。',
            '不从职业、年龄、头像、车房或门店价格推算收入。'],
        'currentPricesVerified': False, 'status': 'initial_rule_not_business_calibrated',
        'enabled': False, 'changesIntentPolicy': False}
    result = {'schema_version': SCHEMA,
        'version': pack['version'] + '+' + rules['version'], 'materialsVersion': pack['version'],
        'ruleVersion': rules['version'], 'materials': materials, 'keywords': keywords,
        'intentRule': intent_rule, 'rulesSummary': {'version': rules['version'], 'enabled': False,
            'priceVerified': False, 'incomeInferenceAllowed': False, 'budgetComparison': 'not_comparable'},
        'sourceArtifacts': [{key: row[key] for key in ('artifact_id', 'version', 'sha256')}
                            for row in pack['source_artifacts']],
        'sourceNotes': [{'noteId': row['note_id'], 'title': text(row.get('title', '')),
            'duplicateOf': row.get('duplicate_of'), 'sourceRefs': list(row['source_refs']),
            'originalMediaCounts': deepcopy(row.get('counts') or row.get('coverage') or {}),
            'publicationDateStatus': 'Unknown'} for row in pack['source_notes']],
        'sources': [{'sourceRef': row['source_ref'], 'sourceId': row.get('raw_source_id') or row.get('source_id') or row['source_ref'],
            'noteId': row.get('note_id'), 'kind': row.get('kind', 'unknown')}
            for row in pack['sources']],
        'counts': {'materials': len(materials), 'keywords': len(keywords),
            'selectableUniqueKeywords': sum(row['csvCandidateEligible'] for row in keywords),
            'heldUniqueKeywords': sum(not row['csvCandidateEligible'] for row in keywords)},
        'boundaries': {'automaticStoreMapping': False, 'startsCollection': False,
            'sendsMessages': False, 'callsAI': False, 'priceVerified': False}}
    result['digest'] = _digest(result)
    return result


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description='Build safe store material runtime catalog without database access')
    parser.add_argument('--pack', required=True)
    parser.add_argument('--rules', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    package = build_runtime_catalog(json.loads(Path(args.pack).read_text('utf-8-sig')),
                                   json.loads(Path(args.rules).read_text('utf-8-sig')))
    destination = Path(args.output)
    destination.write_text(json.dumps(package, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    print(json.dumps({'output': str(destination), 'counts': package['counts'], 'digest': package['digest']}, ensure_ascii=False))
