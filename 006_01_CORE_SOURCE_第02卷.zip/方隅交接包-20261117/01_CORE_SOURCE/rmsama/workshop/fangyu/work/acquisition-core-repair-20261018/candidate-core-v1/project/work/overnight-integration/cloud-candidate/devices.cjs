const {adminWorkbenchFor,sourceFields}=require('./admin_workbench_policy.cjs');
/* Device control plane. Reuses the workspace transaction and authenticated users.
 * Device credentials never grant access to members, cloud sessions or arbitrary code.
 */
const crypto=require('node:crypto');
const replyTrial=require('./reply_trial.cjs');
const digest=v=>crypto.createHash('sha256').update(String(v)).digest('hex');
const uid=()=>crypto.randomBytes(18).toString('base64url');
const validId=v=>typeof v==='string'&&/^[A-Za-z0-9_-]{16,80}$/.test(v);
const TERMINAL_COMMANDS=new Set(['succeeded','failed','cancelled','expired']);
const terminalCommand=c=>TERMINAL_COMMANDS.has(c.status);
const COMMAND_ACTIVE_LIMIT=200,DEVICE_ACTIVE_LIMIT=20,COMMAND_HISTORY_LIMIT=5000;
const COMMAND_BYTES_LIMIT=1350000,READ_CACHE_SECONDS=5,READ_CACHE_ALIASES=10;
const fields={
  diagnostics:[], account_create:['name','platform'], account_connect:['account_id'], account_status:['account_id'], keyword_suggest:['seed'],
  task_save:['id','name','platform','account_id','keywords','excludes','region','intent_mode','date_from','date_to','daily_limit','scope','note_url','search_pages','target_count','time_start','time_end','unknown_policy','excluded_authors','excluded_bloggers','high_intent_words','medium_intent_words','negative_intent_words','comment_keyword_mode','comment_depth','source_blogger','blogger_unknown_policy'],
  task_run:['task_id','max_batches'], task_stop:['task_id'], task_resume:['task_id'], leads_list:['query','platform','grade','task_id','region','date_from','date_to','offset','limit','snapshot','sort','reply_state'],
  lead_score:['lead_id','grade'], reply_status:['lead_id'], reply_prepare:['lead_id','text'], reply_pending:[], reply_approve:['reply_id'], reply_send:['reply_id','account_id','authorized'], update_check:[], workspace_state:[]
};
fields.task_save.push('continuous_enabled','city','area','comment_date_range','comment_date_from','comment_date_to');
fields.leads_list.push('group_by','group_key','group_offset','intent_level','worklist');
Object.assign(fields,{
 continuous_start:['task_id'],continuous_pause:['task_id'],continuous_resume:['task_id'],continuous_status:['task_id'],
 keyword_recommend:['city','area','seeds','count','exclude_keywords'],keyword_library:['library_id','selected'],
 intent_correct:['lead_id','level','status','reason'],lead_handle:['lead_id','status'],intent_analyze_pending:['task_id'],
 update_download:[],update_install:[],update_status:[]
});
Object.assign(fields,{reply_review:['reply_id','account_id','confirmed'],reply_queue_prepare:['reply_ids','account_id','confirmed'],
 reply_queue_send:['queue_id','authorized'],reply_queue_cancel:['queue_id'],reply_queue_status:['queue_id']});
const maintenance=new Set(['diagnostics','update_check']);
const review=new Set(['reply_pending','reply_approve']);
// Fail closed: future commands must be reviewed before they are allowed during the hold.
const safetyHoldAllowedActions=new Set(['diagnostics','update_check','keyword_suggest','task_stop','leads_list','lead_score','reply_status','reply_prepare','reply_pending','reply_approve','workspace_state']);
for(const action of ['continuous_pause','continuous_status','keyword_recommend','keyword_library','intent_correct','lead_handle','intent_analyze_pending','update_download','update_install','update_status'])safetyHoldAllowedActions.add(action);
for(const action of ['update_download','update_install','update_status'])maintenance.add(action);
for(const action of ['reply_review','reply_queue_prepare','reply_queue_cancel','reply_queue_status'])safetyHoldAllowedActions.add(action);
const platformQaActions=new Set(['account_create','account_connect','account_status','task_save','task_run']);
const employeeReadActions=new Set(['account_create','account_connect','account_status','task_save',
 'task_run','task_resume','continuous_start','continuous_resume']);
// Internal platform QA is read-only and each collection must be explicitly one batch.
// Apply the same predicate to submissions and existing queues so older QA work cannot replay.
const platformQaAllows=(action,data,continuous=false)=>(platformQaActions.has(action)&&(action!=='task_run'||data?.max_batches===1))
  ||(continuous&&(action==='continuous_start'||action==='continuous_resume'));
const safetyHoldMessage='当前版本正在验收，小红书自动采集与发送暂缓';
const platformQaMessage='当前仅允许扫码、身份核对和手动单次读取；连续采集与公开发送暂缓';
function validateCommand(action,data){
 if(!Object.hasOwn(fields,action)||!data||Array.isArray(data)||typeof data!=='object')throw Error('invalid command');
 const keywordPoolAction=action==='task_save'||action==='keyword_recommend';
 if(Object.keys(data).some(k=>!fields[action].includes(k))||Buffer.byteLength(JSON.stringify(data))>(keywordPoolAction?180000:12000))throw Error('invalid parameters');
 for(const name of action==='task_save'?['keywords']:action==='keyword_recommend'?['exclude_keywords']:[]){
  if(Object.hasOwn(data,name)&&(!Array.isArray(data[name])||data[name].length>500||data[name].some(word=>typeof word!=='string'||!word.trim()||word.length>80)))throw Error('invalid parameters');
 }
 if(action==='leads_list'&&(Object.hasOwn(data,'sort')&&!['intent','newest'].includes(data.sort)||Object.hasOwn(data,'reply_state')&&!['','unreplied','sent'].includes(data.reply_state)||Object.hasOwn(data,'grade')&&!['','A','B','C'].includes(data.grade)))throw Error('invalid parameters');
 if(action==='leads_list'&&(
  Object.hasOwn(data,'group_by')&&!['','note','blogger','date','intent'].includes(data.group_by)||
  Object.hasOwn(data,'group_key')&&(typeof data.group_key!=='string'||data.group_key!==''&&!/^g_[a-f0-9]{32}$/.test(data.group_key))||
  Object.hasOwn(data,'group_offset')&&(!Number.isSafeInteger(data.group_offset)||data.group_offset<0)||
  data.group_key&&!data.group_by||
  Object.hasOwn(data,'intent_level')&&!['','super_high','high','medium','low','very_low','pending','uncertain','unrelated'].includes(data.intent_level)||
  Object.hasOwn(data,'worklist')&&!['','pending','all'].includes(data.worklist)))throw Error('invalid parameters');
 return structuredClone(data);
}
const publicDevice=d=>({id:d.id,name:d.name,owner:d.owner,version:d.version||'',last_seen:d.last_seen||0,revoked:!!d.revoked,
 ...(d.contact_sync?{contact_sync:d.contact_sync}:{})});
function handleDevices({state,payload,bearer,user,now,reply,companyId,releaseApproved=false,releaseVersion='',
 pairingApproved=false,pairingVersion='',employeeReleaseEnabled=false,employeeReleaseVersion='',
 platformQaDeviceId='',qaContinuousUntil=0,continuousReadonlyDeviceId=''}){
 const op=payload.operation;
 if(!['pair_create','device_enroll','device_identity','device_poll','device_result','device_account_claim','device_account_lookup','devices','device_revoke','device_claims_release','command_submit','command_get','reply_trial_authorize','reply_trial_revoke'].includes(op))return null;
 const safetyHold=companyId==='fangyu-apartment-client'&&releaseApproved!==true;
 const qaPairing=safetyHold&&pairingApproved===true
  && /^[0-9]+\.[0-9]+\.[0-9]+-qa\.[1-9][0-9]{0,5}$/.test(pairingVersion);
 const employeePolicy=safetyHold&&employeeReleaseEnabled===true&&employeeReleaseVersion==='1.1.8-pilot.1';
 state.devices??=[];state.pairings??=[];state.commands??=[];state.xhs_claims??=[];
 const qaDeviceId=qaPairing&&pairingVersion==='1.1.7-qa.1'&&validId(platformQaDeviceId)?platformQaDeviceId:'';
 const qaForDevice=d=>!!(qaDeviceId&&d&&!d.revoked&&d.id===qaDeviceId&&d.version==='1.1.7-qa.1'
  &&state.users.some(u=>u.username===d.owner&&!u.disabled));
 const qaContinuousForDevice=d=>qaForDevice(d)&&Number.isSafeInteger(qaContinuousUntil)
  &&qaContinuousUntil>now&&qaContinuousUntil-now<=1800;
 const continuousReadonlyForDevice=d=>qaForDevice(d)&&continuousReadonlyDeviceId===qaDeviceId;
 const continuousForDevice=d=>continuousReadonlyForDevice(d)||qaContinuousForDevice(d);
 const employeeRelease=d=>{
  const base={allowed:false,device_id:d?.id||'',version:employeeReleaseVersion||'',
   continuous_read:false,lease_seconds:0};
  if(!employeePolicy)return {...base,reason:'POLICY_DISABLED'};
  if(!d||d.revoked)return {...base,reason:'DEVICE_REVOKED'};
  const owner=state.users.find(u=>u.username===d.owner&&!u.disabled);
  if(!owner)return {...base,reason:'OWNER_INACTIVE'};
  const adminWorkbench=adminWorkbenchFor(companyId,d,owner);
   if(owner.role!=='operator'&&!adminWorkbench)return {...base,reason:'ROLE_INELIGIBLE'};
  if(d.version!==employeeReleaseVersion)return {...base,reason:'VERSION_MISMATCH'};
  if(!d.last_seen||now-d.last_seen>90)return {...base,reason:'DEVICE_OFFLINE'};
  return {...base,...(adminWorkbench?sourceFields():{}),allowed:true,continuous_read:true,lease_seconds:45,reason:'ALLOWED'};
 };
 const employeeForDevice=d=>employeeRelease(d).allowed;
 const visibleDevice=d=>({...publicDevice(d),platform_qa:qaForDevice(d),continuous_qa:continuousForDevice(d),
  employee_release:employeeRelease(d)});
 const pollingDevice=op==='device_poll'&&state.devices.find(d=>!d.revoked&&d.digest===digest(bearer)
  &&state.users.some(u=>u.username===d.owner&&!u.disabled));
 const trialForDevice=d=>qaForDevice(d)?replyTrial.activeGrant(state,d,now):null;
 const trialAllows=c=>c.action==='reply_send'&&!!c.reply_trial_grant_id&&
  qaForDevice(state.devices.find(d=>d.id===c.device_id))&&
  !!replyTrial.permit(state,state.devices.find(d=>d.id===c.device_id),c.data,now,c);
 // Use the version from this heartbeat, not the preceding heartbeat, to revoke QA.
 if(pollingDevice)pollingDevice.version=typeof payload.version==='string'&&/^[0-9A-Za-z.+_-]{1,60}$/.test(payload.version)?payload.version:'';
  if(pollingDevice)pollingDevice.workbench_source_release=payload.workbench_source_release==='fangyu-admin-local-v1'?'fangyu-admin-local-v1':'';
 const commandHeld=c=>safetyHold&&!safetyHoldAllowedActions.has(c.action)
  &&!(qaForDevice(state.devices.find(d=>d.id===c.device_id))
      &&platformQaAllows(c.action,c.data,continuousForDevice(state.devices.find(d=>d.id===c.device_id)))
      &&c.platform_qa_device_id===qaDeviceId)
  &&!(employeeForDevice(state.devices.find(d=>d.id===c.device_id))
      &&employeeReadActions.has(c.action)
      &&c.employee_release_version===employeeReleaseVersion
      &&c.employee_release_device_id===c.device_id)
  &&!trialAllows(c);
 const respond=(status,data)=>({state,result:reply(status,
  status===200&&op==='device_poll'?{...data,safety_hold:safetyHold&&!qaForDevice(pollingDevice)&&!employeeForDevice(pollingDevice),
   employee_release:employeeRelease(pollingDevice),
   platform_qa_device_id:qaForDevice(pollingDevice)?qaDeviceId:'',
   platform_qa_version:qaForDevice(pollingDevice)?'1.1.7-qa.1':'',
   continuous_qa:continuousForDevice(pollingDevice),
   continuous_qa_mode:continuousReadonlyForDevice(pollingDevice)?'device_readonly':qaContinuousForDevice(pollingDevice)?'qa_trial':'',
   continuous_qa_max_batches:continuousReadonlyForDevice(pollingDevice)?0:2,
   continuous_qa_until:!continuousReadonlyForDevice(pollingDevice)&&qaContinuousForDevice(pollingDevice)?qaContinuousUntil:0,
   continuous_qa_remaining_seconds:continuousReadonlyForDevice(pollingDevice)?45:qaContinuousForDevice(pollingDevice)?qaContinuousUntil-now:0,
   owner_permissions:pollingDevice?{can_reply:state.users.find(u=>u.username===pollingDevice.owner)?.can_reply!==false}:null,
   reply_trial:trialForDevice(pollingDevice)?{...replyTrial.visible(trialForDevice(pollingDevice)),
    remaining_seconds:trialForDevice(pollingDevice).expires_at-now}:null}:data)});
 state.pairings=state.pairings.filter(p=>p.expires>now);
 // On first activation (or after a hold), discard platform work left in the
 // old queue. A release must never replay an operation submitted earlier.
 if(companyId==='fangyu-apartment-client'&&releaseApproved===true&&state.release_version_seen!==releaseVersion){
  for(const c of state.commands.filter(c=>c.status==='queued'&&!safetyHoldAllowedActions.has(c.action))){
   c.status='cancelled';c.error='发布状态已改变，请重新提交并核对操作';c.finished_at=now;
  }
  state.release_version_seen=releaseVersion;
 }else if(safetyHold&&state.release_version_seen){state.release_version_seen='';}
 if((state.platform_qa_device_seen||'')!==qaDeviceId){
  for(const c of state.commands.filter(c=>c.status==='queued'&&!safetyHoldAllowedActions.has(c.action))){
   c.status='cancelled';c.error='内部验收设备已改变，请重新核对并提交操作';c.finished_at=now;
  }
  state.platform_qa_device_seen=qaDeviceId;
 }
 if((state.employee_release_seen||'')!==(employeePolicy?employeeReleaseVersion:'')){
  for(const c of state.commands.filter(c=>c.status==='queued'&&!safetyHoldAllowedActions.has(c.action))){
   c.status='cancelled';c.error='员工设备授权状态已改变，请核对后重新提交操作';c.finished_at=now;
  }
  state.employee_release_seen=employeePolicy?employeeReleaseVersion:'';
 }
 for(const c of state.commands){
  if(commandHeld(c)&&c.status==='queued'){
   c.status='cancelled';c.error=qaForDevice(state.devices.find(d=>d.id===c.device_id))?platformQaMessage:safetyHoldMessage;c.finished_at=now;
  }
  if(commandHeld(c)&&c.status==='running'){
   c.status='uncertain';c.error='安全暂停已通知助手停机；已执行动作结果待人工核实';c.finished_at=now;
  }
  if(c.status==='running'&&c.lease_until<=now){c.status='uncertain';c.error='助手失联，执行结果待确认；不会自动重试';c.finished_at=now;}
  if(c.status==='queued'&&c.expires<=now){c.status='expired';c.finished_at=now;}
  if(terminalCommand(c)&&c.finished_at&&c.finished_at<now-900){
   if(Object.hasOwn(c,'result')){delete c.result;c.result_expired=true;}
   delete c.data;
  }
 }
 if(op==='device_enroll'){
  if(safetyHold&&!qaPairing&&!employeePolicy)return respond(423,{error:'当前版本验收中，暂不连接新电脑或启用旧版助手'});
  if(companyId==='fangyu-apartment-client'&&!(employeePolicy&&payload.version===employeeReleaseVersion)
      &&!(qaPairing&&payload.version===pairingVersion)&&!(releaseApproved&&payload.version===releaseVersion))
   return respond(426,{error:'请安装当前允许的方隅工作台版本后再连接电脑'});
  const p=state.pairings.find(p=>p.digest===digest(bearer));
  const owner=p&&state.users.find(u=>u.username===p.owner&&!u.disabled);
  if(!p||!owner||typeof payload.device_token!=='string'||!/^[A-Za-z0-9_-]{40,100}$/.test(payload.device_token))return respond(401,{error:'配对材料无效或已过期'});
  const key=digest(payload.device_token);
  if(p.device_id){
   const d=state.devices.find(d=>d.id===p.device_id&&!d.revoked&&d.digest===key);
   return d?respond(200,{device:visibleDevice(d)}):respond(409,{error:'配对已使用'});
  }
  if(state.devices.filter(d=>!d.revoked).length>=100)return respond(409,{error:'设备数量已达当前容量'});
  const d={id:uid(),name:p.name,owner:p.owner,digest:key,created_at:now,last_seen:now,version:'',revoked:false};
  state.devices.push(d);p.device_id=d.id;return respond(200,{device:visibleDevice(d)});
 }
 if(op==='device_identity'||op==='device_poll'||op==='device_result'||op==='device_account_claim'||op==='device_account_lookup'){
  const d=state.devices.find(d=>!d.revoked&&d.digest===digest(bearer));
  if(!d||!state.users.some(u=>u.username===d.owner&&!u.disabled))return respond(401,{error:'设备已撤销或员工已停用',
   employee_release:{allowed:false,device_id:'',version:employeeReleaseVersion||'',continuous_read:false,
    lease_seconds:0,reason:'DEVICE_AUTH_REQUIRED'}});
  if(companyId==='fangyu-apartment-client'&&releaseApproved===true&&op==='device_poll'&&payload.version!==releaseVersion)
   return respond(426,{error:'本机助手版本不匹配，请更新后继续'});
  if(op==='device_account_lookup'){
   if(companyId!=='fangyu-apartment-client')return respond(400,{error:'此企业未启用小红书设备身份登记'});
   const uidHash=payload.uid_hash;
   if(typeof uidHash!=='string'||!/^[a-f0-9]{64}$/.test(uidHash))return respond(400,{error:'账号身份摘要无效'});
   const own=state.xhs_claims.find(c=>c.device_id===d.id&&c.uid_hash===uidHash);
   return respond(200,{account_id:own?.account_id||''});
  }
  if(op==='device_account_claim'){
   if(companyId!=='fangyu-apartment-client')return respond(400,{error:'此企业未启用小红书设备身份登记'});
   const accountId=payload.account_id,uidHash=payload.uid_hash;
   if(!validId(accountId)||typeof uidHash!=='string'||!/^[a-f0-9]{64}$/.test(uidHash))return respond(400,{error:'账号身份摘要无效'});
   d.last_seen=now;
   // Keep claims after a device is revoked. A stale machine must be inspected
   // before this platform identity can be transferred to another machine.
   const conflict=state.xhs_claims.find(c=>c.uid_hash===uidHash&&c.device_id!==d.id
     ||c.device_id===d.id&&c.account_id===accountId&&c.uid_hash!==uidHash);
   if(conflict)return respond(409,{error:'小红书身份与企业登记冲突；停止平台操作并请管理员核对'});
   const previous=state.xhs_claims.find(c=>c.device_id===d.id&&c.uid_hash===uidHash);
   if(previous&&previous.account_id!==accountId){
    if(payload.replaces_account_id!==previous.account_id||!validId(payload.replaces_account_id))
     return respond(409,{error:'本机已有此小红书身份登记；需先核对原账号已删除'});
    const replaced=previous.account_id;
    previous.account_id=accountId;previous.checked_at=now;
    state.audit??=[];state.audit.push({user:d.owner,operation:'device_account_rebind',time:now,device_id:d.id,old_account_id:replaced,new_account_id:accountId});state.audit=state.audit.slice(-300);
    return respond(200,{claimed:true,rebound:true});
   }
   const existing=state.xhs_claims.find(c=>c.device_id===d.id&&c.account_id===accountId);
   if(existing){existing.checked_at=now;return respond(200,{claimed:true});}
   if(state.xhs_claims.length>=200)return respond(503,{error:'账号身份登记容量已满，请管理员处理'});
   state.xhs_claims.push({device_id:d.id,account_id:accountId,uid_hash:uidHash,created_at:now,checked_at:now});
   return respond(200,{claimed:true});
  }
  // The UI treats a heartbeat as online for 90 seconds. Persist at most once
  // every 30 seconds when no command or other device state has changed.
  if(!d.last_seen||now-d.last_seen>=30)d.last_seen=now;
  if(op==='device_identity')return respond(200,{device:visibleDevice(d)});
  if(op==='device_result'){
   const c=state.commands.find(c=>c.id===payload.command_id&&c.device_id===d.id);
   if(!c)return respond(404,{error:'任务不存在'});
   if(['succeeded','failed'].includes(c.status))return respond(200,{accepted:true,status:c.status});
   if(!['running','uncertain'].includes(c.status))return respond(409,{error:'任务未领取'});
   if(!['succeeded','failed'].includes(payload.status))return respond(400,{error:'结果状态无效'});
   const value=payload.result??null;
   if(Buffer.byteLength(JSON.stringify(value))>120000||Buffer.byteLength(JSON.stringify(state.commands))+Buffer.byteLength(JSON.stringify(value))>1500000)return respond(413,{error:'结果过大或缓存已满，请分页并稍后读取'});
   // The assistant supplies per-action sanitized result objects, never raw process logs.
   c.status=payload.status;c.result=structuredClone(value);c.finished_at=now;
   if(c.reply_trial_grant_id)replyTrial.consume(state,c,now);
   return respond(200,{accepted:true,status:c.status});
  }
  if(typeof payload.version==='string'&&/^[0-9A-Za-z.+_-]{1,60}$/.test(payload.version))d.version=payload.version;
  if(op==='device_poll'&&payload.contact_sync&&typeof payload.contact_sync==='object'&&!Array.isArray(payload.contact_sync)){
   const keys=['pending_contacts','needs_identity','pending_responses','blocked_responses'];
   if(Object.keys(payload.contact_sync).length===keys.length&&keys.every(key=>
      Object.hasOwn(payload.contact_sync,key)&&Number.isSafeInteger(payload.contact_sync[key])&&
      payload.contact_sync[key]>=0&&payload.contact_sync[key]<=1000000)&&
      (!d.contact_sync||now-(d.contact_sync.reported_at||0)>=30||
       keys.some(key=>d.contact_sync[key]!==payload.contact_sync[key])))
    d.contact_sync={...Object.fromEntries(keys.map(key=>[key,payload.contact_sync[key]])),reported_at:now};
  }
  const principal=state.users.find(u=>u.username===d.owner&&!u.disabled);
  const claim=c=>{
   const issuer=state.users.find(u=>u.username===c.requested_by&&!u.disabled);
   if(!issuer||(c.action.startsWith('update_')&&issuer.role!=='admin')||(review.has(c.action)&&issuer.role!=='admin')||(c.requested_by!==d.owner&&(issuer.role!=='admin'||!(maintenance.has(c.action)||review.has(c.action))))){
    c.status='cancelled';c.finished_at=now;return respond(200,{command:null,poll_after:1});
   }
   let trial=null;
   if(c.action==='reply_send'&&c.reply_trial_grant_id){
    trial=replyTrial.claim(state,c,d,now);
    if(!trial){c.status='cancelled';c.finished_at=now;c.error='回复试验授权已失效；禁止自动重试';return respond(200,{command:null,poll_after:1});}
   }
   c.status='running';c.lease_until=now+120;c.started_at=now;
   const actor=review.has(c.action)||maintenance.has(c.action)&&issuer.role==='admin'?issuer:principal;
   return respond(200,{command:{id:c.id,action:c.action,data:c.data,owner:d.owner,principal:{username:actor.username,role:actor.role,can_reply:actor.can_reply!==false},
    ...(trial?{reply_trial:trial}:{}),control:c.action==='task_stop'},poll_after:5});
  };
  let active=state.commands.find(c=>c.device_id===d.id&&c.status==='running'&&c.action!=='task_stop');
  if(active){
   if(payload.running_id===active.id)active.lease_until=now+120;
   const stop=state.commands.find(c=>c.device_id===d.id&&c.status==='queued'&&c.action==='task_stop');
   if(stop)return claim(stop);
   return respond(200,{command:null,active_id:active.id,poll_after:5});
  }
  if(payload.busy===true){
   const stop=state.commands.find(c=>c.device_id===d.id&&c.status==='queued'&&c.action==='task_stop');
   return stop?claim(stop):respond(200,{command:null,poll_after:5});
  }
  const c=state.commands.find(c=>c.device_id===d.id&&c.status==='queued');
  if(!c)return respond(200,{command:null,poll_after:15});
  return claim(c);
 }
 if(!user)return respond(401,{error:'请重新登录'});
 if(op==='reply_trial_authorize'){
  const outcome=replyTrial.authorize(state,payload,user,now,qaForDevice);
  return respond(outcome.status,outcome.status===200?{reply_trial:outcome.reply_trial}:{error:outcome.error});
 }
 if(op==='reply_trial_revoke'){
  const outcome=replyTrial.revoke(state,payload,user,now);
  return respond(outcome.status,outcome.status===200
   ?{revoked:true,grant_id:outcome.grant_id,revoked_at:outcome.revoked_at}:{error:outcome.error});
 }
 if(op==='pair_create'){
  if(safetyHold&&!qaPairing&&!employeePolicy)return respond(423,{error:'当前版本验收中，暂不连接新电脑或启用旧版助手'});
  if(typeof payload.name!=='string'||!payload.name.trim()||payload.name.length>60)return respond(400,{error:'设备名称需要1至60个字符'});
  if(state.pairings.filter(p=>p.owner===user.username).length>=5)return respond(429,{error:'待绑定设备过多，请等待配对材料过期'});
  const code=crypto.randomBytes(32).toString('base64url');
  state.pairings.push({digest:digest(code),owner:user.username,name:payload.name.trim(),expires:now+600});
  return respond(200,{pair_code:code,expires:now+600});
 }
 if(op==='devices')return respond(200,{devices:state.devices.filter(d=>user.role==='admin'||d.owner===user.username)
  .map(d=>({...visibleDevice(d),...(user.role==='admin'?{
   xhs_claim_count:state.xhs_claims.filter(c=>c.device_id===d.id).length,
   active_command_count:state.commands.filter(c=>c.device_id===d.id&&['queued','running'].includes(c.status)).length,
   uncertain_count:state.commands.filter(c=>c.device_id===d.id&&c.status==='uncertain').length,
  }:{})}))});
 if(op==='device_claims_release'){
  if(companyId!=='fangyu-apartment-client'||user.role!=='admin')return respond(403,{error:'仅方隅管理员可处理小红书设备身份登记'});
  const d=state.devices.find(d=>d.id===payload.device_id);
  if(!d)return respond(404,{error:'设备不存在'});
  if(!d.revoked)return respond(409,{error:'请先停用旧设备'});
  if(d.last_seen&&now-d.last_seen<90)return respond(409,{error:'设备最近仍在线，请等待离线确认后再处理'});
  if(payload.confirmed_stopped!==true)return respond(400,{error:'请先确认旧电脑上的助手已完全退出'});
  const commands=state.commands.filter(c=>c.device_id===d.id);
  if(commands.some(c=>c.status==='running'||c.status==='queued'))return respond(409,{error:'设备仍有未结束的指令'});
  const uncertain=commands.filter(c=>c.status==='uncertain').length;
  if(uncertain&&payload.uncertain_reviewed!==true)return respond(409,{error:'请先核实结果不明的指令'});
  const released=state.xhs_claims.filter(c=>c.device_id===d.id).length;
  state.xhs_claims=state.xhs_claims.filter(c=>c.device_id!==d.id);
  if(released){state.audit??=[];state.audit.push({user:user.username,operation:'device_claims_release',time:now,device_id:d.id,released,uncertain_reviewed:uncertain>0});state.audit=state.audit.slice(-300);}
  return respond(200,{released});
 }
 if(op==='device_revoke'){
  const d=state.devices.find(d=>d.id===payload.device_id&&(user.role==='admin'||d.owner===user.username));
  if(!d)return respond(404,{error:'设备不存在'});
  d.revoked=true;d.revoked_at=now;
  for(const c of state.commands.filter(c=>c.device_id===d.id)){
   if(c.status==='queued'){c.status='cancelled';c.finished_at=now;}
   if(c.status==='running'){c.status='uncertain';c.error='设备已撤销，已执行动作结果待确认';c.finished_at=now;}
  }
  return respond(200,{ok:true});
 }
 if(op==='command_get'){
  const c=state.commands.find(c=>c.id===payload.command_id&&c.requested_by===user.username);
  if(!c)return respond(404,{error:'任务不存在'});
  return respond(200,{command:{id:c.id,action:c.action,device_id:c.device_id,status:c.status,result:c.result??null,
   result_expired:!!c.result_expired,error:c.error||'',created_at:c.created_at}});
 }
 const d=state.devices.find(d=>d.id===payload.device_id&&!d.revoked);
 if(!d||!(d.owner===user.username||(user.role==='admin'&&(maintenance.has(payload.action)||review.has(payload.action)))))return respond(403,{error:'不能操作此设备的平台账号'});
 if(companyId==='fangyu-apartment-client'&&releaseApproved===true&&!safetyHoldAllowedActions.has(payload.action)&&d.version!==releaseVersion)
  return respond(426,{error:'这台电脑的助手未上报当前正式版本，请更新后继续'});
 if(payload.action.startsWith('update_')&&user.role!=='admin')return respond(403,{error:'更新由管理员管理'});
 if(review.has(payload.action)&&user.role!=='admin')return respond(403,{error:'回复审核由管理员管理'});
 if(!validId(payload.request_id))return respond(400,{error:'需要有效幂等请求ID'});
 let data;
 try{data=validateCommand(payload.action,payload.data||{});}catch{return respond(400,{error:'不支持此动作或参数'});}
 const fingerprint=digest(JSON.stringify({device:d.id,action:payload.action,data}));
 const old=state.commands.find(c=>c.requested_by===user.username&&(c.request_id===payload.request_id||c.read_aliases?.includes(payload.request_id)));
 if(old)return old.fingerprint===fingerprint?respond(200,{command_id:old.id,status:old.status}):respond(409,{error:'同一请求ID不能用于不同任务'});
 const trialSubmission=safetyHold&&payload.action==='reply_send'&&qaForDevice(d)
  ?replyTrial.permit(state,d,data,now,null):null;
 if(safetyHold&&!safetyHoldAllowedActions.has(payload.action)
     &&!(qaForDevice(d)&&platformQaAllows(payload.action,data,continuousForDevice(d)))
     &&!(employeeForDevice(d)&&employeeReadActions.has(payload.action))
     &&!trialSubmission)return respond(423,employeeReadActions.has(payload.action)
      ?{error:safetyHoldMessage,code:'EMPLOYEE_RELEASE_DENIED',employee_release:employeeRelease(d)}
      :{error:qaForDevice(d)?platformQaMessage:safetyHoldMessage});
 if(trialSubmission&&(!d.last_seen||now-d.last_seen>90||state.commands.some(c=>c.device_id===d.id&&!terminalCommand(c))))
  return respond(409,{error:'试验发送要求设备在线且无其他待执行指令'});
 // A terminal command remains findable for 24 hours. Unknown outcomes and
 // unfinished work are never removed by the history maintenance path.
 state.commands=state.commands.filter(c=>!terminalCommand(c)||!c.finished_at||c.finished_at>now-86400);
 const active=state.commands.filter(c=>!terminalCommand(c));
 const historyCount=state.commands.length-active.length;
 const cached=payload.action==='continuous_status'&&state.commands.find(c=>c.requested_by===user.username&&c.device_id===d.id&&c.action==='continuous_status'&&c.fingerprint===fingerprint&&c.status==='succeeded'&&c.finished_at&&c.finished_at<=now&&now-c.finished_at<=READ_CACHE_SECONDS&&Object.hasOwn(c,'result')&&c.result!==null&&!c.result_expired&&(c.read_aliases?.length||0)<READ_CACHE_ALIASES&&!state.commands.some(other=>other!==c&&other.device_id===d.id&&other.action!=='continuous_status'&&(!terminalCommand(other)||!other.finished_at||other.created_at>=c.finished_at||other.finished_at>=c.finished_at)));
 if(cached&&Buffer.byteLength(JSON.stringify(state.commands))+Buffer.byteLength(payload.request_id)+120000<COMMAND_BYTES_LIMIT){
  (cached.read_aliases??=[]).push(payload.request_id);
  return respond(200,{command_id:cached.id,status:cached.status});
 }
 if(active.length>=COMMAND_ACTIVE_LIMIT||active.filter(c=>c.device_id===d.id).length>=DEVICE_ACTIVE_LIMIT)return respond(429,{error:'活动任务队列已满，请等待当前任务结束或核对未知结果'});
 if(historyCount>=COMMAND_HISTORY_LIMIT)return respond(429,{error:'任务历史已达到容量，请等待24小时保留期结束'});
 const c={id:uid(),request_id:payload.request_id,requested_by:user.username,device_id:d.id,action:payload.action,data,fingerprint,status:'queued',created_at:now,expires:now+3600};
 if(trialSubmission)c.reply_trial_grant_id=trialSubmission.grant.grant_id;
 if(qaForDevice(d)&&platformQaAllows(payload.action,data,continuousForDevice(d)))c.platform_qa_device_id=qaDeviceId;
 if(employeeForDevice(d)&&employeeReadActions.has(payload.action)){
  c.employee_release_version=employeeReleaseVersion;c.employee_release_device_id=d.id;
 }
 if(Buffer.byteLength(JSON.stringify(state.commands))+Buffer.byteLength(JSON.stringify(c))+120000>=COMMAND_BYTES_LIMIT)return respond(429,{error:'任务记录容量已满，请稍后再试或联系管理员核对'});
 if(trialSubmission){trialSubmission.target.status='reserved';trialSubmission.target.command_id=c.id;trialSubmission.target.reserved_at=now;}
 state.commands.push(c);return respond(200,{command_id:c.id,status:c.status});
}
module.exports={handleDevices,validateCommand};
