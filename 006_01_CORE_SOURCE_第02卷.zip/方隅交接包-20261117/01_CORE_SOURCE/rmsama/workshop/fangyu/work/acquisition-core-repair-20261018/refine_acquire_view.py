from pathlib import Path
import shutil
W=Path(__file__).resolve().parent;P=W.parents[1]
name='work/ui-approved-implementation/ui-preview/pages/acquire.mjs';p=P/name;b=W/'before'/name
b.parent.mkdir(parents=True,exist_ok=True)
if not b.exists():shutil.copy2(p,b)
s=p.read_text('utf-8').replace('save:2,saving:2,complete:3','save:2,saving:2,analyzing:2,complete:3')
s=s.replace('unconfirmed||resume||!locked','unconfirmed||resume||(!locked&&live.canStart!==false)')
s=s.replace("['搜索','读取','保存','完成']", "['搜索','读取','意向分析','完成']")
s=s.replace("liveStatus(status))}","live.phase==='analyzing'?(status==='running'?'意向分析中':'意向分析待继续'):liveStatus(status))}")
p.write_text(s,'utf-8')
print('Analysis phase and pending-page start control aligned.')
