/* Browser transport: credentials stay in memory, never localStorage or URLs. */
export class WorkspaceError extends Error {
  constructor(message,details={}){super(message);Object.assign(this,details);}
}
export class WorkspaceCloud {
  constructor({endpoint,environmentId,companyId,onSessionExpired=()=>{},requestTimeoutMs=15000},fetcher=globalThis.fetch.bind(globalThis)){
    const url=new URL(endpoint);
    if(url.protocol!=='https:'||url.username||url.password||url.hash||url.search)throw new WorkspaceError('企业服务地址无效');
    this.endpoint=endpoint;this.environmentId=environmentId;this.companyId=companyId;this.fetcher=fetcher;this.token='';this.user=null;
    this.onSessionExpired=onSessionExpired;
    this.requestTimeoutMs=Number.isFinite(requestTimeoutMs)&&requestTimeoutMs>0?requestTimeoutMs:15000;
  }
  async call(operation,data={},signal){
    const sessionToken=this.token;
    const headers={'Content-Type':'application/json','Accept':'application/json'};
    if(this.token)headers.Authorization=`Bearer ${this.token}`;
    const controller=new AbortController();
    const abort=()=>controller.abort();
    if(signal){if(signal.aborted)abort();else signal.addEventListener('abort',abort,{once:true});}
    let expired=false,timer;
    const timeoutError=()=>new WorkspaceError(operation==='command_submit'?'指令提交等待超时，结果未确认；请先核对状态，不要重复提交。':'读取超时，请稍后刷新状态。',{timeout:true});
    const deadline=new Promise((_,reject)=>{timer=setTimeout(()=>{expired=true;controller.abort();reject(timeoutError());},this.requestTimeoutMs);});
    const request=(async()=>{try{
      const response=await this.fetcher(this.endpoint,{method:'POST',headers,credentials:'omit',redirect:'error',cache:'no-store',signal:controller.signal,body:JSON.stringify({...data,operation,environment_id:this.environmentId})});
      if(expired)throw timeoutError();
      if(this.token!==sessionToken)throw new WorkspaceError('登录状态已变化，请重新操作');
      if(response.status===401&&sessionToken&&operation!=='login'){
        this.token='';this.user=null;
        const error=new WorkspaceError('登录已过期，请重新登录。系统不会自动重试刚才的操作；登录后请先核对任务或回复状态。',{status:401,sessionExpired:true});
        this.onSessionExpired(error);
        throw error;
      }
      const value=await response.json();
      if(expired)throw timeoutError();
      if(this.token!==sessionToken)throw new WorkspaceError('登录状态已变化，请重新操作');
      if(!response.ok)throw new WorkspaceError(value.error||'请求未完成',{status:response.status});
      if(value.contract!=='fangyu-workspace-v1'||value.environment_id!==this.environmentId||value.company_id!==this.companyId)throw new WorkspaceError('企业服务身份不匹配');
      return value;
    }catch(error){if(expired)throw timeoutError();throw error;}
    })();
    try{return await Promise.race([request,deadline]);}
    finally{clearTimeout(timer);if(signal)signal.removeEventListener('abort',abort);}
  }
  async login(username,password){
    this.token='';this.user=null;
    const value=await this.call('login',{username,password});
    if(typeof value.token!=='string'||!value.token||!['admin','operator'].includes(value.user?.role))throw new WorkspaceError('登录响应无效');
    this.token=value.token;this.user=value.user;return value.user;
  }
  async logout(){try{if(this.token)await this.call('logout');}finally{this.token='';this.user=null;}}
  async submit(deviceId,action,data={},requestId=crypto.randomUUID()){
    // Caller retains requestId until the outcome is known; never silently mint a
    // replacement after a lost response for a possibly non-idempotent operation.
    try{return {...await this.call('command_submit',{device_id:deviceId,action,data,request_id:requestId}),requestId};}
    catch(error){error.requestId=requestId;throw error;}
  }
  async inspect(commandId){return (await this.call('command_get',{command_id:commandId})).command;}
}
