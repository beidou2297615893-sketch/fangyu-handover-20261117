const {config} = await import(new URL('?asset=config.mjs', import.meta.url));
const {WorkspaceCloud} = await import(new URL(config.localWorkspace?'?asset=local-transport.mjs':'?asset=transport.mjs', import.meta.url));
const {createCollectionProgress} = await import(new URL('?asset=collection-progress.mjs', import.meta.url));
const {createEnterpriseWorkspace,requireAccountReviewClear,employeeAiFinancialText,collectionProgramFailureText} = await import(new URL('?asset=enterprise-ui.mjs', import.meta.url));
const {createPlatformAccount} = config.localWorkspace?await import(new URL('?asset=platform-account.mjs', import.meta.url)):{createPlatformAccount:null};
const {createCustomerWorkspace}=await import(new URL('?asset=customer-ui.mjs',import.meta.url));
const {customerPrincipalSignature}=await import(new URL('?asset=enterprise-model.mjs',import.meta.url));
const SAFETY_HOLD = config.companyId === 'fangyu-apartment-client' && config.safetyHold !== false;
const CAN_PAIR = !SAFETY_HOLD || (config.companyId === 'fangyu-apartment-client' && config.pairingAllowed === true);

const $ = id => document.getElementById(id);
const cloud = new WorkspaceCloud({endpoint: location.origin + location.pathname,
  environmentId: config.environmentId, companyId: config.companyId,onSessionExpired:expireSession,
  onConnectionState:localOnly=>{startDevelopmentIdentityWatch();if(!bootingDevelopmentWorkspace&&!developmentIdentityClosing&&cloud.user){
    if(localOnly)say('企业服务暂不可用，已保留本机评论资料；云端操作等待连接恢复。',true);
    else if(['企业服务暂不可用，已保留本机评论资料；云端操作等待连接恢复。','已进入本机工作台。企业服务暂不可用，评论资料可查看；云端操作等待连接恢复。'].includes($('notice').textContent))say('',false);
  }}});
let accountSnapshotKnown=false,deviceAuthReadFailed=false;
let setupInitialized=false,renderedDeviceSignature='',devicePresenceRefreshBusy=false,sessionExpiryNotice='';
let bootingDevelopmentWorkspace=config.developmentWorkspace===true;
let developmentIdentityWatch=0,developmentIdentityRequest=null,developmentIdentityGeneration=0,developmentIdentityClosing=false;
function stopDevelopmentIdentityWatch(){
 clearInterval(developmentIdentityWatch);developmentIdentityWatch=0;developmentIdentityGeneration++;
 developmentIdentityRequest?.abort();developmentIdentityRequest=null;
}
async function checkDevelopmentIdentity(generation){
 if(generation!==developmentIdentityGeneration)return;
 if(!cloud.user||document.hidden||developmentIdentityClosing){stopDevelopmentIdentityWatch();return;}
 if(developmentIdentityRequest)return;
 const epoch=cloud.epoch,{id,tenant_id,username}=cloud.user,wasLocalOnly=cloud.localOnly;
 const controller=new AbortController();developmentIdentityRequest=controller;
 const sameSession=()=>generation===developmentIdentityGeneration&&!document.hidden&&!developmentIdentityClosing
   &&epoch===cloud.epoch&&cloud.user?.id===id&&cloud.user?.tenant_id===tenant_id&&cloud.user?.username===username;
 try{
  const value=await cloud.call('me',{},controller.signal);
  if(!sameSession()||!wasLocalOnly||value.development_local_only!==false
     ||value.user?.id!==id||value.user?.tenant_id!==tenant_id||value.user?.username!==username)return;
  cloud.user=value.user;
  await refreshDevices();
  if(!sameSession())return;
  if(state.selected)await refreshTasks();
  if(!sameSession())return;
  void enterpriseWorkspace?.profile();
  void enterpriseWorkspace?.latest();
 }catch{/* Read-only local identity checks never replay tasks or replies. */}
 finally{if(developmentIdentityRequest===controller)developmentIdentityRequest=null;}
}
function startDevelopmentIdentityWatch(checkNow=false){
 if(!config.developmentWorkspace||!cloud.user||document.hidden||developmentIdentityClosing||developmentIdentityWatch)return;
 const generation=developmentIdentityGeneration;
 developmentIdentityWatch=setInterval(()=>checkDevelopmentIdentity(generation),5000);
 if(checkNow)void checkDevelopmentIdentity(generation);
}
let pageGeneration=0,deviceRefreshStarted=0,deviceRefreshApplied=0,taskReadGeneration=0,taskSnapshotInFlight=null;
let desktopDeviceHint='',desktopBindingBlocked=false;
let collectionProgress=null,activeCollection=null,localLeadReadGeneration=0,pendingTaskSave=null,verifiedTaskToStart=null;
let enterpriseWorkspace=null,platformAccount=null,customerWorkspace=null;
const state = {devices: [], selected: '', deviceGeneration: 0, pendingRequests: new Map(), job: null, accounts:[],tasks:[], localLeads: new Map(), selectedLeads: new Map(), leadsLoaded: false, taskProgress: new Map(), maintenanceSignature: '', leadOffset: 0, leadTotal: 0, leadFilters: {},leadGroupingContract:null,leadGroups:[],leadGroupsTotal:0,leadGroupOffset:0,leadGroupLabel:''};
function devicePlatformQa(deviceId){const device=state.devices.find(item=>item.id===deviceId);return config.companyId==='fangyu-apartment-client'&&device?.platform_qa===true&&device.version==='1.1.7-qa.1'&&!device.revoked;}
function selectedPlatformQa(){return devicePlatformQa(state.selected)&&state.devices.some(device=>device.id===state.selected&&device.owner===cloud.user?.username);}
function deviceEmployeeRelease(deviceId){const device=state.devices.find(item=>item.id===deviceId);return config.employeeReleaseEnabled===true
 &&device?.employee_release?.allowed===true&&device.employee_release.device_id===device.id
 &&device.employee_release.version===config.employeeReleaseVersion&&device.version===config.employeeReleaseVersion
 &&device.owner===cloud.user?.username&&!device.revoked;}
function selectedEmployeeRelease(){return deviceEmployeeRelease(state.selected);}
function selectedPlatformAccess(){return selectedPlatformQa()||selectedEmployeeRelease();}
function employeeReleaseReasonText(reason){return ({POLICY_DISABLED:'员工采集授权已暂停，请联系管理员。',
 VERSION_MISMATCH:'当前电脑版本与云端要求不一致，请更新工作台。',
 DEVICE_OFFLINE:'电脑连接已中断，请打开工作台等待重新连接。',
 ROLE_INELIGIBLE:'当前账号没有员工采集权限。',
 DEVICE_REVOKED:'当前电脑已停用，请重新连接。',
 OWNER_INACTIVE:'员工账号已停用，请联系管理员。',
 DEVICE_AUTH_REQUIRED:'设备身份已失效，请重新连接。'})[reason]||'当前电脑的员工采集授权尚未确认。';}
function platformActionsHeld(){return deviceAuthReadFailed||SAFETY_HOLD&&!selectedPlatformAccess();}
function continuousActionsHeld(){return deviceAuthReadFailed||SAFETY_HOLD&&!(selectedEmployeeRelease()&&state.devices.some(device=>device.id===state.selected&&device.employee_release?.continuous_read===true)
 ||selectedPlatformQa()&&state.devices.some(device=>device.id===state.selected&&device.continuous_qa===true));}
function publicRepliesHeld(){return SAFETY_HOLD;}
const sharedListState = {cursor: '', revision: null, count: 0, generation: 0, maxBatch: 100};
let pairWatchTimer=0,pairWatchExpires=0,pairWatchGeneration=0,pairKnownDevices=new Set(),pairExpectedName='',reviewGeneration=0;
function stopPairWatch(){clearTimeout(pairWatchTimer);pairWatchTimer=0;pairWatchGeneration++;}
function schedulePairWatch(generation){pairWatchTimer=setTimeout(()=>checkPairWatch(generation),5000);}
function startPairWatch(expires,name){
 stopPairWatch();pairWatchExpires=Number(expires)*1000;pairExpectedName=name;
 pairKnownDevices=new Set(state.devices.map(device=>device.id));
 schedulePairWatch(pairWatchGeneration);
}
async function checkPairWatch(generation){
 if(generation!==pairWatchGeneration)return;
 if(!cloud.user||$('pair-result').hidden){stopPairWatch();return;}
 if(Date.now()>=pairWatchExpires){
  stopPairWatch();$('pair-code').value='';$('pair-result').hidden=true;
  const box=$('pair-connected');box.hidden=false;box.classList.add('is-expired');
  $('pair-connected-name').textContent='连接码已过期，请重新生成。';$('pair-go-tasks').hidden=true;
  return;
 }
 try{
  await refreshDevices();
  if(generation!==pairWatchGeneration)return;
  const added=state.devices.find(device=>device.owner===cloud.user.username&&device.name===pairExpectedName&&!device.revoked&&!pairKnownDevices.has(device.id));
  if(added){
   stopPairWatch();$('pair-code').value='';$('pair-result').hidden=true;
   switchDevice(added.id,true);await refreshDevices().catch(()=>{});
   const box=$('pair-connected');box.hidden=false;box.classList.remove('is-expired');
   $('pair-connected-name').textContent=`已连接：${added.name||'这台电脑'}`;
   $('pair-go-tasks').hidden=false;motionIn([box]);return;
  }
 }catch{/* A transient refresh must not discard a still-valid pairing code. */}
 if(generation===pairWatchGeneration)schedulePairWatch(generation);
}

function say(message, error=false) {if(sessionExpiryNotice&&!cloud.user){message=sessionExpiryNotice;error=true;}$('notice').textContent=message;$('notice').classList.toggle('error',error);if(window.gsap&&!matchMedia('(prefers-reduced-motion: reduce)').matches)window.gsap.fromTo($('notice'),{autoAlpha:0,y:5},{autoAlpha:1,y:0,duration:.18,ease:'power2.out',overwrite:'auto'});}
const platformLabel={xiaohongshu:'小红书',douyin:'抖音',kuaishou:'快手'};
const statusLabel={ready:'已登录',logging_in:'登录中',login_required:'需要登录',identity_mismatch:'扫码账号不一致，已暂停',identity_unverified:'账号身份未核实，已暂停',duplicate_identity:'本机账号记录重复，已暂停',duplicate_identity_remote:'企业身份登记冲突，已暂停',identity_cloud_unavailable:'企业身份校验不可用，已暂停',credential_present:'待验证',unverified:'待验证',paused:'已暂停',pending:'等待处理',succeeded:'已完成',failed:'失败',cancelled:'已取消',expired:'已过期',uncertain:'需人工核实',running:'进行中',claimed:'执行中'};
const readablePlatform=value=>platformLabel[value]||value||'平台未知';
const readableStatus=value=>statusLabel[value]||value||'状态待确认';
function node(tag,text,className) {const el=document.createElement(tag);if(text!==undefined)el.textContent=String(text);if(className)el.className=className;return el;}
function inlineEmpty(asset,text){const box=node('p',undefined,'empty empty-inline'),image=node('img'),label=node('span',text);image.src='?asset='+asset;image.alt='';image.setAttribute('aria-hidden','true');box.append(image,label);return box;}
function emptyState(asset,title,description){const box=node('div',undefined,'empty-state'),image=node('img'),copy=node('div');image.src=`?asset=${asset}`;image.alt='';image.setAttribute('aria-hidden','true');copy.append(node('strong',title),node('small',description));box.append(image,copy);return box;}
function showLoggedIn(){const user=cloud.user;$('login-panel').hidden=!!user||bootingDevelopmentWorkspace;$('workspace').hidden=!user;$('logout').hidden=!user;$('header-actions').hidden=!user;const username=String(user?.username||'').trim();$('header-account-name').textContent=username||'我的账号';$('header-account-initial').textContent=Array.from(username)[0]||'';$('account-menu-button').setAttribute('aria-label',`账号菜单：${username||'我的账号'}`);if(!user)$('pending-bell-dot').hidden=true;$('who').textContent='';$('review-tab').hidden=user?.role!=='admin';$('team-tab').hidden=user?.role!=='admin';$('maintenance-tab').hidden=user?.role!=='admin';$('admin-nav').hidden=true;for(const item of document.querySelectorAll('.admin-menu-item'))item.hidden=user?.role!=='admin';const notice=$('notice');if(user)$('workspace').querySelector('nav').after(notice);else $('workspace').after(notice);}
const pageCopy={devices:config.localWorkspace?'小红书账号':'账号管理',tasks:'采集',leads:'意向评论',customers:'客户清单',review:'审核回复',team:'团队账号',maintenance:'设备状态'};
function motionIn(targets){if(!window.gsap||matchMedia('(prefers-reduced-motion: reduce)').matches)return;window.gsap.fromTo(targets,{autoAlpha:0,y:10},{autoAlpha:1,y:0,duration:.24,stagger:.045,ease:'power2.out',clearProps:'all',overwrite:'auto'});}
function motionResults(list, selector){
 if(!window.gsap||matchMedia('(prefers-reduced-motion: reduce)').matches||list.closest('.page')?.hidden)return;
 const visible=[...list.querySelectorAll(selector)].slice(0,6);
 if(visible.length)window.gsap.fromTo(visible,{autoAlpha:0,y:8},{autoAlpha:1,y:0,duration:.23,stagger:.035,ease:'power2.out',clearProps:'all',overwrite:'auto'});
}
function motionPage(name){
 if(!window.gsap||matchMedia('(prefers-reduced-motion: reduce)').matches)return;
 const gsap=window.gsap, cards=[...document.querySelectorAll(`#page-${name} .card`)];
 const sceneArts=[...document.querySelectorAll(`#page-${name} .section-art`)];
 gsap.timeline({defaults:{ease:'power2.out'}})
  .fromTo('#page-heading',{autoAlpha:0,y:9},{autoAlpha:1,y:0,duration:.27,clearProps:'all',overwrite:'auto'},0)
  .fromTo(cards,{autoAlpha:0,y:12},{autoAlpha:1,y:0,duration:.31,stagger:.055,clearProps:'all',overwrite:'auto'},.08)
  .fromTo('#title-art',{autoAlpha:0,x:12,scale:.96},{autoAlpha:1,x:0,scale:1,duration:.4,clearProps:'all',overwrite:'auto'},.04)
  .fromTo(sceneArts,{autoAlpha:0,y:7,scale:.96},{autoAlpha:1,y:0,scale:1,duration:.32,stagger:.04,clearProps:'all',overwrite:'auto'},.17);
}
function updateNavLine(animate=false){
 const workspace=$('workspace'),nav=workspace.querySelector('nav'),line=$('nav-line');
 if(workspace.hidden){line.hidden=true;line.dataset.ready='';nav.classList.remove('has-nav-line');return;}
 const active=nav.querySelector('button.active:not([hidden])');if(!active){line.hidden=true;line.dataset.ready='';nav.classList.remove('has-nav-line');return;}
 const nr=nav.getBoundingClientRect(),br=active.getBoundingClientRect();
 const x=br.left-nr.left+nav.scrollLeft+17,y=br.bottom-nr.top+nav.scrollTop-7,width=Math.max(12,br.width-34);
 const group=active.parentElement.className;
 const sameRow=line.dataset.group===group||!matchMedia('(max-width:600px)').matches;
 const move=animate&&line.dataset.ready==='1'&&sameRow&&window.gsap&&!matchMedia('(prefers-reduced-motion: reduce)').matches;
 if(window.gsap){if(move)window.gsap.to(line,{x,y,width,duration:.28,ease:'power2.out',overwrite:'auto'});else{window.gsap.killTweensOf(line);window.gsap.set(line,{x,y,width});}}
 else{line.style.transform=`translate(${x}px,${y}px)`;line.style.width=`${width}px`;}
 line.hidden=false;line.dataset.ready='1';line.dataset.group=group;nav.classList.add('has-nav-line');
}
window.addEventListener('resize',()=>requestAnimationFrame(()=>updateNavLine(false)));
$('workspace').querySelector('nav').addEventListener('scroll',()=>updateNavLine(false),{passive:true});
const pageArt={devices:'fy-scene-05-connect.png',tasks:'fy-scene-04-search.png',leads:'fy-scene-03-customers.png',customers:'fy-scene-03-customers.png',review:'fy-scene-08-team.png',team:'fy-scene-08-team.png',maintenance:'fy-scene-06-cloud-sync.png'};
function renderPage(name){pageGeneration++;enterpriseWorkspace?.onNavigate();$('notice').textContent='';$('notice').classList.remove('error');const copy=pageCopy[name]||pageCopy.devices;$('title-art').src=`?asset=${pageArt[name]||pageArt.devices}`;$('workspace').dataset.page=name;$('page-heading').textContent=copy;for(const button of document.querySelectorAll('nav button')){button.classList.toggle('active',button.dataset.page===name);if(button.dataset.page===name)button.setAttribute('aria-current','page');else button.removeAttribute('aria-current');}for(const page of document.querySelectorAll('.page'))page.hidden=page.id!==`page-${name}`;if(name==='tasks'){updateTaskPrerequisite();void enterpriseWorkspace?.profile();}if(name==='devices'&&config.localWorkspace&&cloud.user)void platformAccount?.refresh().catch(()=>{});requestAnimationFrame(()=>updateNavLine(true));motionPage(name);}
function switchDevice(id,remember=false){
 if(state.selected===id){if(remember)rememberSelectedDevice(id);return;}
  collectionProgress?.reset();activeCollection=null;
 state.selected=id;clearSelectedDeviceState();if(remember)rememberSelectedDevice(id);
}
function devicePreferenceKey(){
 if(!cloud.user?.username)return '';
 return ['fangyu-selected-device',config.environmentId,config.companyId,cloud.user.username].map(encodeURIComponent).join(':');
}
function rememberedDeviceId(){try{return localStorage.getItem(devicePreferenceKey())||'';}catch{return '';}}
function rememberSelectedDevice(id){
 if(!id||!state.devices.some(device=>device.id===id&&device.owner===cloud.user?.username&&!device.revoked))return;
 try{localStorage.setItem(devicePreferenceKey(),id);}catch{/* Storage can be unavailable; selection still works for this page. */}
}
function initialDeviceChoice(own){
 if(config.localWorkspace&&desktopBindingBlocked)return '';
 if(config.localWorkspace&&desktopDeviceHint)return own.find(device=>device.id===desktopDeviceHint)?.id||'';
 const remembered=rememberedDeviceId();
 if(own.some(device=>device.id===remembered))return remembered;
 const online=device=>Boolean(device.last_seen)&&Date.now()/1000-device.last_seen<90;
 return (own.find(device=>online(device)&&devicePlatformQa(device.id))||own.find(online)||own[0])?.id||'';
}
function clearSelectedDeviceState(){
 accountSnapshotKnown=false;state.deviceGeneration++;state.accounts=[];state.tasks=[];state.job=null;state.taskProgress.clear();
 state.leadViewContract=null;state.latestCollection=null;state.leadFilters={};
 state.leadGroupingContract=null;state.leadGroups=[];state.leadGroupsTotal=0;state.leadGroupOffset=0;state.leadGroupLabel='';
 $('task-account').replaceChildren(new Option('请选择已登录的平台账号',''));
 $('account-list').replaceChildren();$('task-list').replaceChildren(inlineEmpty('fy-icon-14-list.png','请刷新状态，读取当前电脑的账号与任务。'));
 $('job-state').textContent='暂无操作';$('keyword-suggestions').replaceChildren();$('keyword-suggestions').hidden=true;$('keyword-placeholder').hidden=false;
 state.selectedLeads.clear();state.localLeads.clear();state.leadOffset=0;state.leadTotal=0;state.leadsLoaded=false;
 renderLocalLeads();renderPlatformAvailability();
}
function updateTaskChoicePresentation(){
 const own=state.devices.filter(d=>d.owner===cloud.user?.username&&!d.revoked);
 const selected=own.find(device=>device.id===state.selected);
 const ready=(state.accounts||[]).filter(a=>a.platform==='xiaohongshu'&&a.status==='ready');
 const single=!!selected&&ready.length===1&&$('task-device').value===selected.id&&$('task-account').value===ready[0].id;
 const summary=$('task-selection-summary'),wasHidden=summary.hidden;
 const employee=cloud.user?.role!=='admin';summary.hidden=employee||!single;
 $('task-device-field').hidden=employee||single;$('task-account-field').hidden=!!selected&&ready.length<=1;
 $('task-selection-label').textContent=single?ready[0].name:'';
 if(single&&wasHidden&&!$('page-tasks').hidden)motionIn([summary]);
}
function taskSourceMode(){return $('task').elements.namedItem('source').value;}
const taskDepthBySource={keywords:'all',note:'main'};
let lastTaskSource='keywords';
function syncTaskSourceFields(){
 const source=taskSourceMode(),specific=source==='note',form=$('task');
 const keywords=form.elements.namedItem('keywords'),note=form.elements.namedItem('note_url'),pages=form.elements.namedItem('search_pages');
 const depth=form.elements.namedItem('comment_depth');
 if(source!==lastTaskSource){taskDepthBySource[lastTaskSource]=depth.value;depth.value=taskDepthBySource[source];lastTaskSource=source;}
 $('task-keywords-field').hidden=specific;$('keyword-helper').hidden=specific;
 $('task-note-field').hidden=!specific;$('task-search-pages-field').hidden=specific;
 keywords.required=!specific;note.required=specific;pages.required=!specific;
 keywords.disabled=specific;note.disabled=!specific;pages.disabled=specific;
 depth.querySelector('option[value="all"]').textContent=specific?'主评论及本页附带回复':'主评论及楼中楼（逐页读取）';
 form.elements.namedItem('name').placeholder=specific?'默认：指定帖子评论':'默认使用首个关键词命名';
 updateTaskSettingsSummary();
}
function validXhsNoteUrl(value){
 if(!value||/\s/.test(value)||!value.startsWith('https://www.xiaohongshu.com/'))return false;
 try{
  const url=new URL(value);
  return url.protocol==='https:'&&url.hostname==='www.xiaohongshu.com'&&!url.port
   &&!url.username&&!url.password
   &&/^\/(?:explore\/[A-Za-z0-9]+|discovery\/item\/[A-Za-z0-9]+)\/?$/.test(url.pathname);
 }catch{return false;}
}
function taskPayload(form){
 const source=String(form.get('source')||'');
 if(!['keywords','note'].includes(source))throw Error('请选择评论来源');
 const keywords=String(form.get('keywords')||'').split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
 const noteUrl=String(form.get('note_url')||'').trim();
 if(source==='keywords'&&!keywords.length)throw Error('请至少填写一个关键词');
 if(source==='note'&&!validXhsNoteUrl(noteUrl))throw Error('请粘贴单个小红书帖子完整链接');
 const depth=String(form.get('comment_depth')||'');
 if(!['main','all'].includes(depth))throw Error('请选择评论范围');
 const name=String(form.get('name')||'').trim()||(source==='note'?'指定帖子评论':`${keywords[0]}评论采集`);
 const data={name,account_id:String(form.get('account_id')||''),platform:'xiaohongshu',
  scope:source==='note'?'comments':'search_comments',comment_depth:depth,
  comment_keyword_mode:'all',intent_mode:'all',keywords:source==='note'?[]:keywords,
  target_count:Number(form.get('target_count')),daily_limit:Number(form.get('daily_limit'))};
 if(source==='note')data.note_url=noteUrl;
 else data.search_pages=Number(form.get('search_pages'));
 return data;
}
function updateTaskSettingsSummary(){$('task-settings-summary').textContent='按所选城市、关键词与评论日期持续采集';}
function selectedDeviceOnline(){const device=state.devices.find(d=>d.id===state.selected&&d.owner===cloud.user?.username&&!d.revoked);return !!(device?.last_seen&&Date.now()/1000-device.last_seen<90);}
function canReadDeviceData(){return config.localWorkspace?!!state.selected&&!desktopBindingBlocked&&state.selected===desktopDeviceHint&&state.devices.some(d=>d.id===state.selected&&d.owner===cloud.user?.username&&!d.revoked):selectedDeviceOnline();}
function arrangeTaskCards(){
 const grid=$('page-tasks').querySelector('.grid');
 const online=!!state.selected&&selectedDeviceOnline();
 const ready=online&&state.accounts?.some(item=>item.platform==='xiaohongshu'&&item.status==='ready');
  grid.dataset.mode=!online?'connect':!ready?'account':grid.querySelector('.task-row')?'run':'create';
}
function updateTaskPrerequisite(){
 const box=$('task-prerequisite'),text=$('task-prerequisite-text'),button=$('task-prerequisite-action'),wasHidden=box.hidden;
 const available=state.accounts?.some(account=>account.status==='ready'&&account.platform==='xiaohongshu');
 const selectedAccount=state.accounts?.find(account=>account.id===$('task-account').value&&account.platform==='xiaohongshu'),ready=selectedAccount?.status==='ready',needsReview=selectedAccount?.requires_review===true;
 button.dataset.target='';
 if(config.localWorkspace&&!desktopBindingBlocked&&state.selected&&selectedDeviceOnline()&&!accountSnapshotKnown){box.hidden=true;$('create-task').disabled=true;arrangeTaskCards();return;}
 if(desktopBindingBlocked){text.textContent='电脑归属需要管理员核对。';button.textContent='账号管理';}
 else if(!state.selected){text.textContent=cloud.user?'正在连接这台电脑…':'请登录员工账号。';button.textContent='账号管理';}
 else if(platformActionsHeld()){text.textContent=deviceAuthReadFailed?'企业授权状态读取失败，采集已暂停；请检查网络后刷新。':config.employeeReleaseEnabled
  ?employeeReleaseReasonText(state.devices.find(device=>device.id===state.selected)?.employee_release?.reason)
  :'当前暂不能采集。';button.textContent='查看账号';}
 else if(!selectedDeviceOnline()){text.textContent=config.localWorkspace?'连接中断，请重新检查。':'请打开方隅工作台后再采集。';button.textContent=config.localWorkspace?'重新检查':'查看连接';}
 else if(!available){text.textContent='先登录小红书账号。';button.textContent='登录小红书';}
 else if(!selectedAccount){text.textContent='请选择要采集的小红书账号。';button.textContent='查看账号';}
 else if(!ready){text.textContent='所选小红书账号登录状态已变化，请重新选择已登录账号。';button.textContent='查看账号';}
 else if(needsReview){text.textContent=selectedAccount.review_reason==='verification_required'?(config.localWorkspace?'采集请求暂未被小红书接受，请查看手机是否有提醒，并到小红书账号页核对。':'采集请求暂未被小红书接受，请到对应电脑的方隅工作台核对手机提示。'):(config.localWorkspace?'所选小红书账号需要人工复核。':'请在对应电脑打开方隅工作台复核所选账号。');button.textContent=config.localWorkspace?'打开小红书账号':'查看账号';button.dataset.target=config.localWorkspace?'account-safety':'account';}
 box.dataset.accountGate=String(!desktopBindingBlocked&&!platformActionsHeld()&&!!state.selected&&selectedDeviceOnline()&&(!ready||needsReview));
 box.hidden=!platformActionsHeld()&&!!state.selected&&selectedDeviceOnline()&&!!ready&&!needsReview;
 $('create-task').disabled=!box.hidden||pendingTaskSave?.deviceId===state.selected||$('create-task').dataset?.uncertain==='true'||$('create-task').getAttribute?.('aria-busy')==='true';
 arrangeTaskCards();
 if(wasHidden&&!box.hidden&&!$('page-tasks').hidden&&window.gsap&&!matchMedia('(prefers-reduced-motion: reduce)').matches){
  window.gsap.fromTo(box,{autoAlpha:0,y:6},{autoAlpha:1,y:0,duration:.2,ease:'power2.out',clearProps:'all',overwrite:'auto'});
 }
}
function devicePresentationSignature(devices){return JSON.stringify(devices.map(d=>[d.id,d.name,d.owner,d.version||'',!!d.revoked,d.platform_qa===true,d.continuous_qa===true,d.employee_release?.allowed===true,d.employee_release?.reason||'',d.xhs_claim_count||0,d.uncertain_count||0,!!d.last_seen&&Date.now()/1000-d.last_seen<90]));}
 async function refreshDevices(preloaded){const sequence=++deviceRefreshStarted;const response=Array.isArray(preloaded?.devices)?preloaded:await cloud.call('devices');if(sequence<deviceRefreshApplied)return;deviceRefreshApplied=sequence;const previousSelection=state.selected,previousAccess=selectedPlatformAccess();deviceAuthReadFailed=false;state.devices=response.devices||[];const own=state.devices.filter(d=>d.owner===cloud.user.username&&!d.revoked);if(!setupInitialized){$('pair-setup').open=CAN_PAIR&&!own.length;setupInitialized=true;}if(!own.some(d=>d.id===state.selected))switchDevice(initialDeviceChoice(own));if(previousSelection===state.selected&&previousAccess!==selectedPlatformAccess())clearSelectedDeviceState();const list=$('device-list'),shown=cloud.user.role==='admin'?state.devices:state.devices.filter(d=>d.id===state.selected);list.replaceChildren();if(!shown.length)list.append(inlineEmpty('fy-icon-38-wifi.png','请打开方隅工作台完成连接。'));
  for(const d of shown){
  const online=!d.revoked&&Boolean(d.last_seen)&&Date.now()/1000-d.last_seen<90;
  const row=node('div',undefined,'row');
  const label=node('div');
   label.append(node('strong',d.name),node('small',cloud.user.role==='admin'?`${d.owner} · ${d.revoked?'已停用':online?'在线':'离线'} · ${d.version||'版本待上报'}`:online?'已连接':'桌面未打开'));
   if(devicePlatformQa(d.id)&&cloud.user.role==='admin')label.append(node('small','指定验收电脑 · 尚未正式发布'));
  if(deviceEmployeeRelease(d.id))label.append(node('small','员工设备已获采集授权 · 公开发送仍需单独确认'));
  else if(config.employeeReleaseEnabled&&d.owner===cloud.user.username&&!d.revoked)
   label.append(node('small',employeeReleaseReasonText(d.employee_release?.reason)));
  if(!online&&!d.revoked)label.append(node('small',d.last_seen?`上次在线：${new Date(d.last_seen*1000).toLocaleString('zh-CN')}`:'尚未上报心跳'));
  if(d.revoked&&cloud.user.role==='admin'&&d.xhs_claim_count)label.append(node('small',`仍保留 ${d.xhs_claim_count} 个小红书账号占用，防止旧电脑与新电脑同时使用。`));
  if(d.revoked&&cloud.user.role==='admin'&&d.uncertain_count)label.append(node('small',`有 ${d.uncertain_count} 条结果不明的旧指令，解除前须先核对实际采集或回复结果。`));
  row.append(label);
   if(d.owner===cloud.user.username&&!d.revoked&&cloud.user.role==='admin'){
   const actions=node('div',undefined,'device-actions');
   const select=node('button',d.id===state.selected?'当前设备':'选择设备','secondary');
   select.type='button';select.addEventListener('click',()=>{switchDevice(d.id,true);refreshDevices().catch(handle);});actions.append(select);
   if(!online){
    const retire=node('button','停用旧设备','secondary retire-device');retire.type='button';
    retire.addEventListener('click',run(async()=>{
     if(!confirm(`确认停用离线设备“${d.name}”吗？它以后必须重新获取连接码才能接收任务。`))return;
     await cloud.call('device_revoke',{device_id:d.id});
     if(state.selected===d.id)switchDevice('');
     await refreshDevices();say('旧设备已停用；历史任务与共享线索保留。');
    }));actions.append(retire);
   }
   row.append(actions);
  }
  if(cloud.user.role==='admin'&&d.revoked&&d.xhs_claim_count){
   const actions=node('div',undefined,'device-actions'),release=node('button','解除账号占用','secondary');
   release.type='button';const wait=Math.max(0,90-(Date.now()/1000-(d.last_seen||0)));
   if(wait>0){release.disabled=true;release.textContent=`等待设备离线（约 ${Math.ceil(wait)} 秒）`;}
   release.addEventListener('click',run(async()=>{
    if(d.uncertain_count&&prompt(`这台旧电脑有 ${d.uncertain_count} 条结果不明指令。请先在旧电脑记录及小红书核对实际结果；完成后输入“已核对结果”。`)!=='已核对结果')return;
    if(!confirm(`请先确认旧电脑“${d.name}”上的助手已完全退出，且不会再启动。若曾有结果不明的采集或回复，请先在小红书核实。确认后解除这台旧设备的 ${d.xhs_claim_count} 个账号占用，供新电脑重新核验身份。`))return;
    const result=await cloud.call('device_claims_release',{device_id:d.id,confirmed_stopped:true,uncertain_reviewed:!!d.uncertain_count});
    await refreshDevices();say(`已解除 ${result.released||0} 个旧设备账号占用；新电脑仍须重新核验登录身份。`);
   }));actions.append(release);row.append(actions);
  }
  list.append(row);
 }
  const select=$('task-device');select.replaceChildren();select.append(new Option('请选择自己的助手设备',''));for(const d of config.localWorkspace?own.filter(item=>item.id===desktopDeviceHint):own)select.append(new Option(`${d.name} · ${d.last_seen&&Date.now()/1000-d.last_seen<90?'在线':'离线'}`,d.id));select.value=state.selected;renderPlatformAvailability();updateTaskPrerequisite();updateTaskChoicePresentation();renderedDeviceSignature=devicePresentationSignature(state.devices);
}
async function refreshDevicePresence(){
 if(devicePresenceRefreshBusy||!cloud.user||document.hidden)return;
 devicePresenceRefreshBusy=true;
 try{
  let response;
  try{response=await cloud.call('devices');}
  catch{deviceAuthReadFailed=true;renderPlatformAvailability();updateTaskPrerequisite();return;}
  if(!cloud.user)return;
  if(deviceAuthReadFailed||devicePresentationSignature(response.devices||[])!==renderedDeviceSignature)await refreshDevices(response);
  else state.devices=response.devices||[];
 }finally{devicePresenceRefreshBusy=false;}
}
setInterval(refreshDevicePresence,60000);
document.addEventListener('visibilitychange',()=>{
 if(document.hidden)stopDevelopmentIdentityWatch();
 else {startDevelopmentIdentityWatch(true);void refreshDevicePresence();}
});
window.addEventListener('pagehide',stopDevelopmentIdentityWatch);
window.addEventListener('pageshow',()=>startDevelopmentIdentityWatch(true));
const requestKey=(deviceId,action,data)=>JSON.stringify([deviceId,action,data]);
const settled=job=>job&&['succeeded','failed','cancelled','expired'].includes(job.status);
async function submit(action,data,deviceId=state.selected,onDispatch){
 if(!deviceId)throw Error('请先连接并选择本地助手');
 if(['account_status','task_save','task_resume','task_run','reply_send','continuous_start','continuous_resume'].includes(action)&&(platformActionsHeld()||deviceId!==state.selected))throw Error('当前电脑未开放小红书操作，请核对员工设备授权');
 if(['continuous_start','continuous_resume'].includes(action)&&continuousActionsHeld())throw Error('当前电脑的持续采集授权尚未确认');
 if(SAFETY_HOLD&&selectedEmployeeRelease()&&action==='reply_send')throw Error('公开发送仍需单独审核和确认');
 if(SAFETY_HOLD&&selectedPlatformQa()&&(['reply_send','task_resume'].includes(action)||(action==='task_run'&&data?.max_batches!==1)))throw Error('本轮只读验收不允许恢复旧任务或公开发送');
 const generation=state.deviceGeneration,selectedAtStart=state.selected;
 const key=requestKey(deviceId,action,data),requestId=state.pendingRequests.get(key)||crypto.randomUUID();
 state.pendingRequests.set(key,requestId);
 onDispatch?.({requestId,requestKey:key,commandId:''});
 let answer;
 try{answer=await cloud.submit(deviceId,action,data,requestId);}
 catch(error){error.requestId=requestId;if(error.status>=400&&error.status<500)state.pendingRequests.delete(key);throw error;}
 if(deviceId===selectedAtStart&&generation!==state.deviceGeneration){const error=Error('当前电脑或验收权限已变化，请重新读取状态');error.requestId=requestId;throw error;}
 state.job=answer.command_id;onDispatch?.({requestId,requestKey:key,commandId:answer.command_id});$('job-state').textContent='正在等待电脑处理。';
 try{const job=await inspect(answer.command_id);if(settled(job))state.pendingRequests.delete(key);if(deviceId===selectedAtStart&&generation!==state.deviceGeneration)throw Error('当前电脑或验收权限已变化，请重新读取状态');return {...job,requestId,requestKey:key};}
 catch(error){error.requestId=requestId;error.commandId=answer.command_id;throw error;}
}
async function inspect(id=state.job){if(!id)return null;const job=await cloud.inspect(id);$('job-state').textContent=`${readableStatus(job.status)}${job.error?' · '+job.error:''}`;return job;}
async function awaitJob(id,readDeadlineMs=0,timeoutMessage='读取超时，请刷新状态核对。'){
 if(!id)throw Error('指令编号缺失，请重新读取状态');
 let expired=false,timer;
 const poll=(async()=>{for(let i=0;i<20&&!expired;i++){
  const job=await cloud.inspect(id);if(expired)return null;
  $('job-state').textContent=`${readableStatus(job.status)}${job.error?' · '+job.error:''}`;
  if(['succeeded','failed','cancelled','expired','uncertain'].includes(job.status))return job;
  await new Promise(resolve=>setTimeout(resolve,1500));
 }if(!expired)$('job-state').textContent='处理仍在进行，请稍后核对状态。';return null;})();
 if(!readDeadlineMs)return poll;
 const deadline=new Promise((_,reject)=>{timer=setTimeout(()=>{expired=true;reject(Error(timeoutMessage));},readDeadlineMs);});
 try{return await Promise.race([poll,deadline]);}finally{clearTimeout(timer);}
}
async function execute(action,data,deviceId=state.selected,onDispatch){
 const generation=state.deviceGeneration,selectedAtStart=state.selected;
 if(config.localWorkspace&&['workspace_state','leads_list','reply_status','contact_receipt_status','customer_list','customer_detail'].includes(action)){
  const owner=cloud.user?.username;
  const valid=()=>!!owner&&!desktopBindingBlocked&&deviceId===state.selected&&deviceId===desktopDeviceHint&&state.devices.some(device=>device.id===deviceId&&device.owner===owner&&!device.revoked);
  if(!valid())throw Error('本机设备尚未确认，请在设置中核对连接状态。');
  const answer=await cloud.call('local_read',{action,data});
  if(generation!==state.deviceGeneration||selectedAtStart!==state.selected||cloud.user?.username!==owner||!valid())throw Error('当前电脑或登录状态已变化，请重新读取状态。');
  if(!answer||!Object.hasOwn(answer,'result'))throw Error('本机读取结果无效，请稍后刷新状态。');
  return {status:'succeeded',result:answer.result};
 }
 const submitted=await submit(action,data,deviceId,onDispatch);
 try{const job=['succeeded','failed','cancelled','expired','uncertain'].includes(submitted.status)?submitted:await awaitJob(submitted.id,['workspace_state','leads_list','task_save'].includes(action)?30000:0,action==='task_save'?'保存结果待核对，请刷新状态；暂勿重复开始。':undefined);if(settled(job))state.pendingRequests.delete(submitted.requestKey);if(deviceId===selectedAtStart&&generation!==state.deviceGeneration)throw Error('当前电脑或登录状态已变化，请重新读取状态');return job?{...job,commandId:submitted.id,requestId:submitted.requestId,requestKey:submitted.requestKey}:null;}
 catch(error){error.requestId=submitted.requestId;error.commandId=submitted.id;throw error;}
}
async function requestTaskStop(taskId){
 const job=await execute('task_stop',{task_id:taskId});
 if(job?.status!=='succeeded')throw Error(job?.error||'停止请求尚未由助手确认，请核对本地助手和任务状态');
 $('job-state').textContent='结束请求已处理，请核对采集状态。';
 await refreshTasks();
}
function taskSnapshot(deviceId,generation){
 if(taskSnapshotInFlight?.deviceId===deviceId&&taskSnapshotInFlight.generation===generation)return taskSnapshotInFlight.promise;
 const pending={deviceId,generation,promise:execute('workspace_state',{},deviceId)};
 taskSnapshotInFlight=pending;
 pending.promise.then(()=>{if(taskSnapshotInFlight===pending)taskSnapshotInFlight=null;},()=>{if(taskSnapshotInFlight===pending)taskSnapshotInFlight=null;});
 return pending.promise;
}
async function refreshTasks(retryScopeChange=true){
 const read=++taskReadGeneration,page=pageGeneration,pageName=$('workspace').dataset.page;
 enterpriseWorkspace?.markSnapshotUnconfirmed(true);
 await refreshDevices();
 if(read!==taskReadGeneration||page!==pageGeneration||pageName!==$('workspace').dataset.page)return;
 if(!state.selected){state.accounts=[];$('task-account').replaceChildren(new Option('先连接电脑',''));$('account-list').replaceChildren();$('task-list').replaceChildren(inlineEmpty('fy-icon-14-list.png','连接电脑后，这里显示采集任务。'));enterpriseWorkspace?.syncSnapshot({tasks:[],accounts:[],authoritative:true});updateTaskPrerequisite();updateTaskChoicePresentation();return;}
 if(!canReadDeviceData()){
  $('job-state').textContent='这台电脑已绑定，助手暂时离线；打开助手后刷新状态。';
  if(!$('task-list').querySelector('.task-row'))$('task-list').replaceChildren(inlineEmpty('fy-icon-14-list.png','连接已保留。打开本地助手后刷新状态。'));
  enterpriseWorkspace?.markSnapshotUnconfirmed();
  updateTaskPrerequisite();return;
 }
 const selected=state.selected,generation=state.deviceGeneration;
 const identity=[cloud.epoch,cloud.user?.id,cloud.user?.tenant_id,cloud.user?.username];
 const current=()=>read===taskReadGeneration&&page===pageGeneration&&pageName===$('workspace').dataset.page&&selected===state.selected&&generation===state.deviceGeneration;
 // A fresh device permission snapshot can invalidate a concurrent local read.
 // Re-read once through the normal gateway, only for the same user and device.
 // This never replays a collection or reply command.
 const sameDestination=()=>read===taskReadGeneration&&page===pageGeneration&&pageName===$('workspace').dataset.page&&selected===state.selected&&!desktopBindingBlocked&&identity.every((value,i)=>value===[cloud.epoch,cloud.user?.id,cloud.user?.tenant_id,cloud.user?.username][i]);
 $('job-state').textContent='正在读取这台电脑的账号与任务…';
 if(!$('task-list').querySelector('.task-row'))$('task-list').replaceChildren(inlineEmpty('fy-icon-14-list.png','正在读取这台电脑的任务…'));
 const pending=taskSnapshot(selected,generation);
 let timer;
 const outcome=await Promise.race([
  pending.then(result=>({result}),error=>({error})),
  new Promise(resolve=>{timer=setTimeout(()=>resolve({timeout:true}),18000);})
 ]);
 clearTimeout(timer);
 if(sameDestination()&&generation!==state.deviceGeneration){
  if(retryScopeChange)return refreshTasks(false);
  showTaskReadError(Error('连接状态正在同步，请刷新后核对已有进度。'));return;
 }
 if(outcome.timeout){
  if(current()){$('job-state').textContent='读取超过18秒，结果尚未确认；可切换页面，稍后点击“刷新状态”核对。';if(!$('task-list').querySelector('.task-row'))$('task-list').replaceChildren(inlineEmpty('fy-icon-14-list.png','读取较慢，稍后点“刷新状态”核对。'));enterpriseWorkspace?.markSnapshotUnconfirmed();}
  pending.then(result=>{if(current())renderTaskSnapshot(result);else if(retryScopeChange&&sameDestination()&&generation!==state.deviceGeneration)void refreshTasks(false).catch(handle);},error=>{if(current())showTaskReadError(error);else if(retryScopeChange&&sameDestination()&&generation!==state.deviceGeneration)void refreshTasks(false).catch(handle);});
  return;
 }
 if(outcome.error){if(current())showTaskReadError(outcome.error);return;}
 if(current())renderTaskSnapshot(outcome.result);
}
function showTaskReadError(error){$('job-state').textContent=error.message||'读取失败，请稍后刷新状态。';if(!$('task-list').querySelector('.task-row'))$('task-list').replaceChildren(inlineEmpty('fy-icon-14-list.png','读取失败，稍后点“刷新状态”核对。'));enterpriseWorkspace?.markSnapshotUnconfirmed();}
function renderTaskSnapshot(result){
 if(!result)return;
 const list=$('task-list');
 if(result.status!=='succeeded'){
  $('job-state').textContent=result.error||'助手未能读取任务，请检查本地助手状态。';
  if(!list.childElementCount)list.append(inlineEmpty('fy-icon-14-list.png','读取未完成，稍后刷新状态核对。'));
  enterpriseWorkspace?.markSnapshotUnconfirmed();
  return;
 }
 list.replaceChildren();
 const accounts=result.result?.accounts||[],select=$('task-account'),accountList=$('account-list');state.accounts=accounts;accountSnapshotKnown=true;
 platformAccount?.setAccounts(accounts);
 const previousAccount=select.value;
 select.replaceChildren(new Option('请选择已登录的平台账号',''));accountList.replaceChildren();
 if(!accounts.length)accountList.append(inlineEmpty('fy-icon-36-qr.png',platformActionsHeld()?'暂无本机账号记录。':'请在本地助手点击“登录新的小红书账号”。'));
 for(const account of accounts){
  if(account.status==='ready'&&account.platform==='xiaohongshu')select.append(new Option(`${account.name} · 小红书`,account.id));
   const row=node('div',undefined,'row account-row'),label=node('div'),actions=node('div',undefined,'account-actions');row.dataset.accountId=account.id;
   const status=node('small',`${readablePlatform(account.platform)} · ${platformActionsHeld()&&account.platform==='xiaohongshu'?'历史状态，当前未验证':account.requires_review===true?'需要账号复核':readableStatus(account.status)}`,'account-state');status.dataset.status=platformActionsHeld()?'unverified':account.requires_review===true?'check_required':account.status;
   label.append(node('strong',account.name),status);
   const hint=node('small',undefined,'account-next');hint.hidden=true;
   if(account.status!=='ready'){const hint=node('small',platformActionsHeld()?'请在设置核对设备开放状态。':'请在本地助手完成扫码登录。','account-next');actions.append(hint);}
   const check=node('button','检查状态','secondary');check.type='button';
   check.addEventListener('click',()=>execute('account_status',{account_id:account.id}).then(job=>{say(job?.result?.message||job?.result?.status||'状态已更新');return refreshTasks();}).catch(handle));
   if(!platformActionsHeld())actions.append(check);row.append(label,actions,hint);accountList.append(row);
 }
 const readyAccounts=accounts.filter(account=>account.status==='ready'&&account.platform==='xiaohongshu').map(account=>account.id);
 select.value=readyAccounts.includes(previousAccount)?previousAccount:readyAccounts.length===1?readyAccounts[0]:'';updateTaskPrerequisite();updateTaskChoicePresentation();
 const tasks=[...(result.result?.tasks||[])].sort((a,b)=>taskHistoryTime(b)-taskHistoryTime(a));state.tasks=tasks;if(!tasks.length)list.append(inlineEmpty('fy-icon-07-search.png','尚无历史采集。'));
 for(const task of tasks){
  const row=node('div',undefined,'row task-row'),label=node('div'),title=node('div',undefined,'task-title');row.dataset.taskId=task.id;
  const status={running:'采集中',queued:'等待开始',waiting:'等待下次读取',paused:'已暂停',blocked:'需要核对账号',interrupted:'已中断'}[task.continuous?.status]||'历史采集';
  title.append(node('strong',taskDisplayName(task)),node('span',status,'status-pill'));
  label.append(title,node('small',[task.city,task.area].filter(Boolean).join(' · ')),node('small',`已保存 ${Number(task.accumulated)||0} 条`));
  row.append(label);if(task.continuous_enabled){const restore=node('button','查看状态','secondary');restore.type='button';restore.addEventListener('click',()=>enterpriseWorkspace?.syncSnapshot({tasks:[task],accounts:state.accounts}));row.append(restore);}list.append(row);
 }
 arrangeTaskCards();
 enterpriseWorkspace?.syncSnapshot({tasks:state.tasks,accounts:state.accounts,authoritative:true});
 if($('workspace').dataset.page==='tasks')void enterpriseWorkspace?.latest();
}
function taskDisplayName(task){return task.scope==='comments'?'指定帖子评论':(task.keywords||[]).filter(Boolean).slice(0,3).join('、')||'关键词评论';}
function taskHistoryTime(task){for(const key of ['last_run','updated_at','created_at']){const value=task[key],time=typeof value==='number'?value*1000:Date.parse(value);if(Number.isFinite(time))return time;}return 0;}
function taskHistoryMessage(task){const value=task.sequence_message||task.last_message||'等待开始';return /已达到本次连续执行批数上限/.test(value)?'本批已结束，可继续采集':cloud.user?.role==='operator'?employeeAiFinancialText(value):value;}
function beginTaskCollection(task,baselineIds,preparedSession){
 if(!collectionProgress)return null;
 const deviceId=state.selected,generation=state.deviceGeneration;
 const session=collectionProgress.start({session:preparedSession,deviceId,taskId:task.id,task,baselineIds});
 if(!session)return null;
 activeCollection={session,deviceId,taskId:task.id,generation,baselineCount:Number(task.accumulated),showCards:Array.isArray(baselineIds),baselineIds:Array.isArray(baselineIds)?[...baselineIds]:undefined};
 return activeCollection;
}
function prepareTaskFlow(deviceId,scope){const session=collectionProgress?.prepare({deviceId,scope});if(!session)return null;activeCollection={session,deviceId,taskId:null,generation:state.deviceGeneration};return activeCollection;}
function taskFlowFailure(flow,error,message){
 if(error?.sessionExpired)return;
 const uncertain=!!error?.requestId&&!(error.status>=400&&error.status<500);
 const text=message||employeeTaskError(error,uncertain);
 $('job-state').textContent=cloud.user?.role==='operator'?employeeAiFinancialText(error?.message||text):error?.message||text;
 if(uncertain&&pendingTaskSave){$('create-task').textContent='等待结果确认';$('refresh-tasks').textContent=pendingTaskSave.action==='task_save'?'核对保存状态':'核对采集状态';}
 if(flow===activeCollection)collectionProgress?.fail({session:flow?.session,status:uncertain?'uncertain':'failed',message:text,action:/账号|登录/.test(text)?'account':undefined});
}
function employeeTaskError(error,uncertain=false){const raw=String(error?.message||'');if(uncertain)return pendingTaskSave?.action==='task_save'?'保存结果待确认。请核对状态，暂勿重复开始。':'采集结果待核对。请核对状态，暂勿重复开始。';const programFailure=collectionProgramFailureText(error);if(programFailure)return programFailure;if(/review_required|risk|验证|风控/i.test(raw))return '账号需要验证，采集已停止。';if(/打开方隅|离线|offline|连接中断/i.test(raw))return config.localWorkspace?'连接中断，请重新检查。':'电脑未连接。请打开方隅工作台后再采集。';if(/企业|云端|员工|session|401/i.test(raw))return '工作台员工会话需要恢复，请核对企业连接。小红书登录状态未因此改变。';if(/小红书|平台登录|账号登录/i.test(raw))return '请在小红书账号页核对登录状态。';if(/暂未开放|暂停|held/i.test(raw))return '采集暂未开放。请在账号管理核对状态。';if(/保存未完成/.test(raw))return '保存未完成，采集没有开始。';if(/电脑已变化/.test(raw))return '电脑已变化，请重新开始。';return '采集未完成，请核对状态后再试。';}
async function confirmTaskDevice(deviceId,generation){
 await refreshDevices();
 if(deviceId!==state.selected||generation!==state.deviceGeneration)throw Error('当前电脑已变化，请重新开始。');
 if(!selectedDeviceOnline())throw Error(config.localWorkspace?'连接中断，请重新检查。':'请打开方隅工作台后再采集。');
 if(platformActionsHeld())throw Error('采集暂未开放，请在账号管理核对状态。');
}
async function confirmContinuousDevice(deviceId,generation,accountId,action){
 await confirmTaskDevice(deviceId,generation);
 if(continuousActionsHeld())throw Error('当前电脑的持续采集授权尚未确认');
 const snapshot=await execute('workspace_state',{},deviceId);
 if(snapshot?.status!=='succeeded'||!Array.isArray(snapshot.result?.accounts))throw Error(snapshot?.error||'账号安全状态尚未确认，请刷新后再试');
 if(deviceId!==state.selected||generation!==state.deviceGeneration||action==='continuous_start'&&$('task-account').value!==accountId)throw Error('当前电脑或所选账号已变化，请重新读取状态');
 state.accounts=snapshot.result.accounts;updateTaskPrerequisite();
 return requireAccountReviewClear(state.accounts,accountId,config.localWorkspace);
}
async function startSavedTask(task,preparedSession,knownBaseline){
 const deviceId=state.selected,generation=state.deviceGeneration;
 await confirmTaskDevice(deviceId,generation);
 let baselineIds=knownBaseline===undefined&&Number(task.accumulated)===0?[]:knownBaseline;
 if(baselineIds===undefined&&Number(task.accumulated)>0&&Number(task.accumulated)<=25){try{
  const baseline=await execute('leads_list',{task_id:task.id,offset:0,limit:25},deviceId),items=baseline?.result?.items||[];
  if(baseline?.status==='succeeded'&&Number(baseline.result?.total)===items.length&&items.every(item=>item.id&&item.task_id===task.id))baselineIds=items.map(item=>item.id);
 }catch{/* Missing baseline hides cards; it never invents new comments. */}}
 if(deviceId!==state.selected||generation!==state.deviceGeneration)return;
 const flow=beginTaskCollection(task,baselineIds,preparedSession);if(collectionProgress&&!flow)return;
 if(flow)flow.dispatchStartedAt=Date.now()/1000;
 collectionProgress?.update({session:flow?.session,phase:'dispatching'});
 const job=await submit('task_run',{task_id:task.id,max_batches:1},deviceId,details=>rememberTaskOperation({flow,data:{task_id:task.id,max_batches:1},task,action:'task_run',...details}));
 if(['succeeded','failed','cancelled','expired','uncertain'].includes(job?.status)){await finishTaskRun(job,task.id);return;}
 collectionProgress?.update({session:flow?.session,phase:job?.status==='running'?'collecting':'queued'});
 updateTaskCommandLabels(job?.status);
 if(flow)flow.commandRunning=['running','claimed'].includes(job?.status);
 void updateActiveTaskProgress(flow);
 void trackJob(job?.id||state.job,task.id,job?.requestKey).catch(error=>taskFlowFailure(flow,error,'采集结果待核对，请刷新状态。'));
}
function continueTaskCollection(session){const active=activeCollection,task=active?.latestTask,summary=active?.summary;if(session!==active?.session||active.deviceId!==state.selected||active.generation!==state.deviceGeneration||summary?.can_continue!==true||summary.stop_reason!=='batch_limit'||summary.exhausted!==false||!(summary.remaining>0)||task?.status!=='ready'||task.exhausted)return;const flow=prepareTaskFlow(active.deviceId,task.scope);collectionProgress.update({session:flow?.session,phase:'dispatching'});return startSavedTask(task,flow?.session).catch(error=>taskFlowFailure(activeCollection,error));}
function savedTaskSnapshot(result,data){if(!result?.id)throw Error('保存结果缺少记录编号，请核对状态。');return {...data,...result,accumulated:result.accumulated??0};}
function updateTaskCommandLabels(status){if(!['running','claimed','queued'].includes(status))return;$('create-task').textContent=status==='queued'?'等待开始…':'采集中…';$('refresh-tasks').textContent='刷新';}
function taskOperationStorageKey(){return ['fangyu-pending-operation',config.environmentId,config.companyId,cloud.user?.username||''].map(encodeURIComponent).join(':');}
function operationTaskSummary(task){if(!task)return undefined;const fields=['id','account_id','platform','scope','keywords','comment_depth','target_count','daily_limit','accumulated'];return Object.fromEntries(fields.filter(key=>Object.hasOwn(task,key)).map(key=>[key,task[key]]));}
function persistTaskOperation(record){try{const key=taskOperationStorageKey();if(record)localStorage.setItem(key,JSON.stringify({version:1,username:cloud.user.username,deviceId:record.deviceId,action:record.action,stage:record.stage||'pending',commandId:record.commandId||'',requestId:record.requestId||'',dispatchStartedAt:record.flow?.dispatchStartedAt||record.dispatchStartedAt,data:operationTaskSummary(record.data),task:operationTaskSummary(record.task)}));else localStorage.removeItem(key);}catch{/* This page still keeps its lock if storage is unavailable. */}}
function rememberTaskOperation(details){if(details.flow&&(details.flow.deviceId!==state.selected||details.flow.generation!==state.deviceGeneration))return;pendingTaskSave={...details,deviceId:details.flow?.deviceId||state.selected,generation:details.flow?.generation??state.deviceGeneration};persistTaskOperation(pendingTaskSave);}
function restoreTaskOperation(){
 if(!cloud.user||pendingTaskSave)return;
 try{const record=JSON.parse(localStorage.getItem(taskOperationStorageKey())||'null');
  if(record?.version!==1||record.username!==cloud.user.username||record.deviceId!==state.selected||!['task_save','task_run'].includes(record.action))return;
  if(!state.devices.some(device=>device.id===record.deviceId&&device.owner===cloud.user.username&&!device.revoked))return;
  if(record.stage==='saved'&&record.task?.id){const flow=prepareTaskFlow(record.deviceId);verifiedTaskToStart={task:record.task,flow};collectionProgress.update({session:flow.session,phase:'ready',message:'设置已保存。点击继续采集开始本次任务。'});$('create-task').textContent='继续采集';return;}
  const flow=record.action==='task_run'&&record.task?.id?beginTaskCollection(record.task):prepareTaskFlow(record.deviceId);
  pendingTaskSave={...record,flow,generation:state.deviceGeneration};
  $('create-task').textContent='等待结果确认';$('refresh-tasks').textContent=record.action==='task_save'?'核对保存状态':'核对采集状态';
  collectionProgress.fail({session:flow?.session,status:'uncertain',message:record.action==='task_save'?'保存结果待确认。请核对状态，暂勿重复开始。':'采集结果待确认。请核对原任务，暂勿重复开始。'});updateTaskPrerequisite();
 }catch{/* Malformed metadata never creates or starts a task. */}
}
function holdTaskSave(flow,data,details){
 if(flow&&(flow.deviceId!==state.selected||flow.generation!==state.deviceGeneration))return;
 rememberTaskOperation({flow,data,action:'task_save',commandId:details.commandId||details.id||'',requestId:details.requestId||''});
 $('create-task').textContent='等待保存确认';$('create-task').disabled=true;$('refresh-tasks').textContent='核对保存状态';
 collectionProgress?.fail({session:flow?.session,status:'uncertain',message:'保存结果待确认。请核对状态，暂勿重复开始。'});
 $('job-state').textContent='保存结果待确认。';
}
async function verifyTaskSave(){
 const pending=pendingTaskSave;if(!pending||pending.deviceId!==state.selected)return refreshTasks();
 if(!pending.commandId){collectionProgress?.fail({session:pending.flow?.session,status:'uncertain',message:'结果待确认，请联系管理员核对；暂勿重复开始。'});return;}
 const job=await cloud.inspect(pending.commandId);
 if(pending!==pendingTaskSave||pending.deviceId!==state.selected||pending.generation!==state.deviceGeneration)return;
 if(pending.action==='task_run'){
  if(['succeeded','failed','cancelled','running','claimed','queued'].includes(job?.status)){
   const dispatchStartedAt=pending.dispatchStartedAt||pending.flow?.dispatchStartedAt,flow=beginTaskCollection(pending.task);pending.flow=flow;if(flow){flow.dispatchStartedAt=dispatchStartedAt||Infinity;flow.commandRunning=['running','claimed'].includes(job.status);}
   if(['succeeded','failed','cancelled'].includes(job.status)){pendingTaskSave=null;persistTaskOperation(null);$('create-task').textContent='开始采集';$('refresh-tasks').textContent='刷新状态';await finishTaskRun(job,pending.task.id);updateTaskPrerequisite();}
   else{updateTaskCommandLabels(job.status);collectionProgress?.update({session:flow?.session,phase:job.status==='running'?'collecting':'queued'});void trackJob(pending.commandId,pending.task.id).catch(error=>taskFlowFailure(flow,error,'采集结果待核对。请核对状态，暂勿重复开始。'));}
  }
  else collectionProgress?.fail({session:pending.flow?.session,status:'uncertain',message:'采集结果仍待确认。请核对原任务，暂勿重复开始。'});
 }else if(job?.status==='succeeded'){
  const task=savedTaskSnapshot(job.result,pending.data),flow=prepareTaskFlow(pending.deviceId);
  verifiedTaskToStart={task,flow};pendingTaskSave=null;
  persistTaskOperation({action:'task_save',stage:'saved',deviceId:pending.deviceId,task,data:pending.data,commandId:pending.commandId,requestId:pending.requestId});
  collectionProgress?.update({session:flow?.session,phase:'ready',message:'设置已保存。点击继续采集开始本次任务。'});
  $('job-state').textContent='设置已保存，尚未开始采集。';$('create-task').textContent='继续采集';$('refresh-tasks').textContent='刷新状态';updateTaskPrerequisite();
 }else if(['failed','cancelled'].includes(job?.status)){
  pendingTaskSave=null;persistTaskOperation(null);$('create-task').textContent='开始采集';$('refresh-tasks').textContent='刷新状态';
  const flow=prepareTaskFlow(pending.deviceId);collectionProgress?.fail({session:flow?.session,status:job.status,message:'保存未完成，采集没有开始。'});updateTaskPrerequisite();
 }else collectionProgress?.fail({session:pending.flow?.session,status:'uncertain',message:'保存结果仍待确认。请稍后核对，暂勿重复开始。'});
}
async function createAndStartTask(event){
 const button=$('create-task');let flow=null,data,saveStarted=false,savedConfirmed=false;
 try{
  if(pendingTaskSave?.deviceId===state.selected)return;
  if(verifiedTaskToStart){const verified=verifiedTaskToStart;verifiedTaskToStart=null;flow=verified.flow;await startSavedTask(verified.task,flow?.session,[]);return;}
  const form=new FormData(event.currentTarget);data=taskPayload(form);
  const deviceId=String(form.get('device')),generation=state.deviceGeneration;
  flow=prepareTaskFlow(deviceId,data.scope);button.textContent='正在准备…';$('job-state').textContent='正在准备采集。';
  const account=state.accounts.find(item=>item.id===data.account_id);
  if(account?.platform!=='xiaohongshu'||account?.status!=='ready')throw Error('先在账号管理登录小红书。');
  await confirmTaskDevice(deviceId,generation);
  button.textContent='正在保存…';collectionProgress?.update({session:flow?.session,phase:'saving_config'});
  saveStarted=true;const job=await execute('task_save',data,deviceId,details=>rememberTaskOperation({flow,data,action:'task_save',...details}));
  if(!job||['uncertain','expired','queued','claimed','running'].includes(job.status)){holdTaskSave(flow,data,job||{commandId:state.job});return;}
  if(job.status!=='succeeded')throw Error('保存未完成，采集没有开始。');
  savedConfirmed=true;
  pendingTaskSave=null;
  const task=savedTaskSnapshot(job.result,data);
  if(deviceId!==state.selected||generation!==state.deviceGeneration)return;
  state.tasks=[task,...state.tasks.filter(item=>item.id!==task.id)];
  button.textContent='正在开始…';
  await startSavedTask(task,flow?.session,[]);
 }catch(error){
  if(error.sessionExpired)return;
  if(saveStarted&&!savedConfirmed&&error.requestId&&!(error.status>=400&&error.status<500)){holdTaskSave(flow,data,error);return;}
  if(saveStarted&&!savedConfirmed){pendingTaskSave=null;persistTaskOperation(null);}
  taskFlowFailure(flow&&flow.deviceId===state.selected&&flow.generation===state.deviceGeneration?activeCollection:flow,error);
 }finally{if(!pendingTaskSave&& !verifiedTaskToStart)button.textContent='开始采集';updateTaskPrerequisite();}
}
function currentCollection(taskId){const active=activeCollection;return active?.taskId===taskId&&active.deviceId===state.selected&&active.generation===state.deviceGeneration?active:null;}
function effectiveTaskJob(job){const business=job?.status==='succeeded'?job.result?.status:null;return ['paused','failed','cancelled','expired','uncertain'].includes(business)?{...job,status:business}:job;}
const taskRunOutcomes=new Map();
const taskRunKey=taskId=>JSON.stringify([state.selected,taskId]);
function taskTerminalMessage(job){
 if(/review_required|risk|验证|风控/i.test(String(job?.error||job?.result?.message||'')))return '账号需要验证，采集已停止。';
 const messages={paused:'采集已结束。请在账号管理核对状态。',failed:'采集未完成，请核对账号状态。',cancelled:'已结束本次采集。',expired:'采集结果待核对，暂勿重复开始。',uncertain:'采集结果待核对，暂勿重复开始。'};
 return messages[job?.status]||(job?.status==='succeeded'?'本次采集已完成。':'采集结果待核对。');
}
function applyTaskTerminalState(row,job){
 if(!row||!job||job.status==='succeeded')return;
 const pill=row.querySelector('.status-pill'),note=row.querySelector('.task-sequence-note'),button=row.querySelector('.task-start');
 if(pill)pill.textContent=readableStatus(job.status);
 if(note)note.textContent=taskTerminalMessage(job);
 if(button){button.textContent='请先核实';button.disabled=true;}
 row.classList.remove('is-submitted');row.classList.add('is-submit-error');row.setAttribute('aria-busy','false');
}
async function finishTaskRun(job,taskId){
 if(pendingTaskSave?.action==='task_run'&&pendingTaskSave.task?.id===taskId&&['succeeded','failed','cancelled'].includes(job.status)){pendingTaskSave=null;persistTaskOperation(null);$('create-task').textContent='开始采集';$('refresh-tasks').textContent='刷新状态';updateTaskPrerequisite();}
 job=effectiveTaskJob(job);
 const key=taskRunKey(taskId),generation=state.deviceGeneration;
 if(job.status==='succeeded')taskRunOutcomes.delete(key);else taskRunOutcomes.set(key,{status:job.status});
 const message=taskTerminalMessage(job);
 $('job-state').textContent=message;
 const row=[...$('task-list').querySelectorAll('.task-row')].find(item=>item.dataset.taskId===taskId);
 applyTaskTerminalState(row,job);
 const active=currentCollection(taskId);
 if(active&&job.status==='succeeded'){
  collectionProgress.update({session:active.session,phase:'reading'});
  try{
   const snapshot=await execute('workspace_state',{},active.deviceId);
   if(snapshot?.status!=='succeeded')throw Error('任务结果尚未确认');
   const task=(snapshot.result?.tasks||[]).find(item=>item.id===taskId);
   if(!task)throw Error('当前任务结果尚未读取');
   let leads;
   if(active.showCards){const answer=await execute('leads_list',{task_id:taskId,offset:0,limit:25},active.deviceId);if(answer?.status!=='succeeded')throw Error('评论结果尚未确认');leads=answer.result;}
   if(currentCollection(taskId)===active){active.latestTask=task;active.summary=job.result?.summary;state.latestCollection={taskId,added:Number(task.accumulated)-active.baselineCount,baselineIds:active.baselineIds};collectionProgress.complete({session:active.session,job,task,leads,summary:job.result?.summary});if($('workspace').dataset.page==='tasks'){taskReadGeneration++;taskSnapshotInFlight=null;renderTaskSnapshot(snapshot);}}
   }catch(error){if(currentCollection(taskId)===active)collectionProgress.fail({session:active.session,status:'uncertain',message:'采集已结束，评论结果待核对；请刷新状态。'});}
 }else{
   if(active)collectionProgress.fail({session:active.session,status:job.status,message,action:/账号/.test(message)?'account':undefined});
  await refreshTasks().catch(error=>{$('job-state').textContent=error.message;});
 }
 if(generation===state.deviceGeneration)$('job-state').textContent=`采集：${message}`;
}
function setTaskDispatchState(row,phase){
 if(!row?.isConnected)return;
 const button=row.querySelector('.task-start');if(!button)return;
 const pill=row.querySelector('.status-pill'),note=row.querySelector('.task-sequence-note');
 const stages={submitting:['提交中','正在发送采集指令。','提交中'],queued:['等待助手','指令已提交，等待助手接收。','等待助手'],running:['助手处理中','助手已接收，正在处理采集。','处理中'],error:['可开始','提交失败，请检查后重试。','重试采集']};
 const [title,message,action]=stages[phase==='running'||phase==='claimed'?'running':phase==='submitting'?'submitting':phase==='error'?'error':'queued'];
 if(note.textContent!==message&&window.gsap&&!matchMedia('(prefers-reduced-motion: reduce)').matches)window.gsap.fromTo(note,{autoAlpha:.35,y:3},{autoAlpha:1,y:0,duration:.2,ease:'power2.out',clearProps:'all',overwrite:'auto'});
 pill.textContent=title;note.textContent=message;button.textContent=action;button.disabled=phase!=='error';
 row.classList.toggle('is-submitted',phase!=='error');row.classList.toggle('is-submit-error',phase==='error');row.setAttribute('aria-busy',phase==='error'?'false':'true');
}
async function updateActiveTaskProgress(active){
 if(!config.localWorkspace||!active?.taskId||!active.commandRunning||active.progressInFlight||active!==activeCollection||active.deviceId!==desktopDeviceHint)return;
 active.progressInFlight=true;
 try{const answer=await cloud.call('local_read',{action:'task_progress',data:{task_id:active.taskId}});
  if(active!==currentCollection(active.taskId)||answer.result?.task_id!==active.taskId||!answer.result?.progress)return;
  const progress=answer.result.progress;
  const epoch=Number.isFinite(Number(progress.started_at_epoch))?Number(progress.started_at_epoch):Date.parse(progress.started_at)/1000;
  const revision=Number(progress.revision);
  if(!progress.run_id||!Number.isFinite(epoch)||epoch<active.dispatchStartedAt||!Number.isInteger(revision)||revision<1)return;
  if(active.runId&&active.runId!==progress.run_id)return;
  if(active.progressRevision&&revision<=active.progressRevision)return;
  active.runId=progress.run_id;active.progressRevision=revision;
  const imported=Number(progress.imported),baseline=active.baselineCount;
  const task=Number.isFinite(baseline)&&Number.isInteger(imported)&&imported>=0?{id:active.taskId,accumulated:baseline+imported}:undefined;
  collectionProgress.update({session:active.session,phase:progress.stage,task,progress});
 }catch{/* A phase read cannot retry the collection or change its result. */}finally{active.progressInFlight=false;}
}
async function trackJob(id,taskId,key){
 const generation=state.deviceGeneration,deadline=Date.now()+300000;
 while(Date.now()<deadline){
  await new Promise(resolve=>setTimeout(resolve,3000));if(generation!==state.deviceGeneration)return;
  const active=currentCollection(taskId);void updateActiveTaskProgress(active);
  const job=await cloud.inspect(id);if(generation!==state.deviceGeneration)return;
  if(active)active.commandRunning=['running','claimed'].includes(job.status);
  if(active)updateTaskCommandLabels(job.status);
  $('job-state').textContent=readableStatus(job.status);
  if(['succeeded','failed','cancelled','expired','uncertain'].includes(job.status)){if(settled(job)&&key)state.pendingRequests.delete(key);await finishTaskRun(job,taskId);return;}
  if(active&&!config.localWorkspace)collectionProgress.update({session:active.session,phase:job.status==='running'?'collecting':'queued'});
  const row=[...$('task-list').querySelectorAll('.task-row')].find(item=>item.dataset.taskId===taskId);setTaskDispatchState(row,job.status);
 }
 await finishTaskRun({status:'uncertain'},taskId);
}
function updateSharedPaging(){
 let info=$('shared-page-info'),more=$('more-shared-leads');
 if(!info){info=node('p',undefined,'help');info.id='shared-page-info';$('lead-list').after(info);}
 if(!more){more=node('button','继续加载共享线索','secondary');more.id='more-shared-leads';info.after(more);more.addEventListener('click',run(loadMoreSharedLeads));}
 info.textContent=sharedListState.count?`已加载 ${sharedListState.count} 条共享线索${sharedListState.cursor?'；可继续加载':''}`:'';
 more.hidden=!sharedListState.cursor;
}
function appendSharedLeadRows(items){
 const list=$('lead-list'),start=sharedListState.count;
 for(const [index,lead] of items.entries()){
  const row=node('article',undefined,'row shared-lead-row'),head=node('div',undefined,'shared-lead-head'),badges=node('div',undefined,'shared-lead-badges');
  const grade=lead.grade||'待评分',gradeBadge=node('span',grade,'shared-lead-grade');gradeBadge.dataset.grade=['A','B','C'].includes(grade)?grade:'pending';
  badges.append(node('span',readablePlatform(lead.platform),'shared-lead-platform'),gradeBadge);
  head.append(node('strong',lead.author||lead.source_id||'用户未提供'),badges);
  const comment=node('p',lead.text||'（评论正文为空）','shared-lead-text');
  const long=String(lead.text||'').length>180;
  if(long)comment.classList.add('is-clamped');comment.id=`shared-comment-${start+index}`;
  const meta=node('div',undefined,'shared-lead-meta');
  meta.append(node('span',lead.published_at||'时间未提供'),node('span',`IP ${lead.region||'未提供'}`));
  if(lead.author_id)meta.append(node('span',`用户 ID ${lead.author_id}`));
  row.append(head,comment);
  if(long){const toggle=node('button','展开全文','shared-lead-toggle');toggle.type='button';toggle.setAttribute('aria-controls',comment.id);toggle.setAttribute('aria-expanded','false');toggle.addEventListener('click',()=>{const expanded=comment.classList.toggle('is-clamped')===false;toggle.textContent=expanded?'收起全文':'展开全文';toggle.setAttribute('aria-expanded',String(expanded));if(window.gsap&&!matchMedia('(prefers-reduced-motion: reduce)').matches)window.gsap.fromTo(comment,{autoAlpha:.6},{autoAlpha:1,duration:.18,ease:'power2.out',clearProps:'opacity,visibility',overwrite:'auto'});});row.append(toggle);}
  row.append(meta);
  if(lead.content_title||lead.content_author)row.append(node('small',`来源：${[lead.content_title,lead.content_author].filter(Boolean).join(' · ')}`,'shared-lead-source'));
  if(/^https:\/\//.test(lead.url||'')){const link=node('a','打开原帖 ↗','shared-lead-link');link.href=lead.url;link.target='_blank';link.rel='noopener noreferrer';row.append(link);}
  list.append(row);
 }
 sharedListState.count+=items.length;updateSharedPaging();
 motionResults(list,'.shared-lead-row');
}
async function refreshLeads(){
 const generation=++sharedListState.generation,response=await cloud.call('list'),list=$('lead-list');
 if(generation!==sharedListState.generation)return;
 list.replaceChildren();sharedListState.cursor=response.next_cursor||'';sharedListState.revision=response.revision;sharedListState.count=0;sharedListState.maxBatch=response.max_batch||100;
 if(!response.items?.length){list.append(emptyState('fy-state-01-empty-customers.png','企业清单暂无线索','从本机清单勾选并共享后显示在这里。'));updateSharedPaging();motionResults(list,'.empty-state');return;}
 appendSharedLeadRows(response.items);
}
async function loadMoreSharedLeads(){
 const cursor=sharedListState.cursor,generation=sharedListState.generation;
 if(!cursor)return;
 const more=$('more-shared-leads');more.disabled=true;
 try{
  const response=await cloud.call('list',{cursor,revision:sharedListState.revision});
  if(generation!==sharedListState.generation)return;
  sharedListState.cursor=response.next_cursor||'';appendSharedLeadRows(response.items||[]);
 }catch(error){
  if(error.status===409){await refreshLeads();say('共享清单刚被同事更新，已从第一页重新读取。');return;}
  throw error;
 }finally{if(more.isConnected)more.disabled=false;}
}
function updateLeadActions(){
 const bar=$('lead-actions'),share=$('publish-leads'),wasHidden=bar.hidden,shareWasHidden=share.hidden;
 const hasResults=state.leadTotal>0,selected=state.selectedLeads.size>0;
 bar.hidden=!(hasResults||selected);
 $('export-leads').hidden=!hasResults;
 share.hidden=!selected;
 $('local-lead-count').hidden=!selected;
 $('local-lead-count').textContent=selected?`已选 ${state.selectedLeads.size} 条线索`:'';
 if(!bar.hidden&&!$('page-leads').hidden&&window.gsap&&!matchMedia('(prefers-reduced-motion: reduce)').matches){
  const target=wasHidden?bar:shareWasHidden&&selected?share:null;
  if(target)window.gsap.fromTo(target,{autoAlpha:0,y:6},{autoAlpha:1,y:0,duration:.2,ease:'power2.out',clearProps:'all',overwrite:'auto'});
 }
}
function leadIntentPresentation(lead){const grade=['A','B','C'].includes(lead.grade)?lead.grade:'pending';const labels={A:'A · 高意向',B:'B · 待核实',C:'C · 暂无明确意向',pending:'待评分'};const score=(typeof lead.score==='number'||typeof lead.score==='string'&&lead.score.trim()!=='' )&&Number.isFinite(Number(lead.score))?Number(lead.score):null;return {grade,label:labels[grade],score};}
function commentDateText(value){return String(value||'').replace(/^(\d{4}-\d{2}-\d{2})[T ](\d{2}:\d{2})(?::\d{2}(?:\.\d+)?)?(Z|[+-]\d{2}:?\d{2})?$/,(_,date,time,zone)=>`${date} ${time}${zone?(zone==='Z'?' UTC':' '+zone):''}`);}
function renderLeadGroups(){
 const control=$('lead-group-by'),list=$('lead-groups'),paging=$('lead-group-pagination'),selected=$('lead-group-selection');if(!control||!list)return;
 if($('lead-group-controls'))$('lead-group-controls').hidden=!state.leadsLoaded&&!canReadDeviceData();
 control.value=state.leadFilters.group_by||'';for(const option of control.querySelectorAll?.('option')||[])if(option.value)option.disabled=state.leadGroupingContract==='legacy';
 const grouped=!!state.leadFilters.group_by&&state.leadGroupingContract==='lead-groups-v1';list.hidden=!grouped;list.replaceChildren();
 if(grouped)for(const group of state.leadGroups||[]){const button=node('button',undefined,'comment-group');button.type='button';button.append(node('span',group.label),node('small',String(group.count)));button.setAttribute('aria-pressed',String(group.key===state.leadFilters.group_key));button.addEventListener('click',run(async()=>{state.leadFilters.group_key=group.key;state.leadGroupLabel=group.label;await loadLocalLeads(0);}));list.append(button);}
 if(paging){const total=state.leadGroupsTotal||0,offset=state.leadGroupOffset||0;paging.hidden=!grouped||total<=30;$('lead-group-prev').disabled=offset===0;$('lead-group-next').disabled=offset+30>=total;$('lead-group-page').textContent=`${total?offset+1:0}–${Math.min(offset+(state.leadGroups?.length||0),total)} / ${total}`;}
 if(selected){selected.hidden=!grouped||!state.leadFilters.group_key;$('lead-group-label').textContent=selected.hidden?'':state.leadGroupLabel;}
}
function renderLocalLeads(){
 renderLeadGroups();
 if($('saved-comment-total'))$('saved-comment-total').textContent=state.leadsLoaded?`${state.leadTotal} 条`:'';
  const filter=$('lead-filter'),showFilter=state.leadsLoaded&&canReadDeviceData();
 const revealFilter=filter.hidden&&showFilter;
 filter.hidden=!showFilter;
 if(revealFilter)motionIn([filter]);
 document.querySelector('.lead-pagination').hidden=!state.leadTotal;
 const list=$('local-lead-list');list.replaceChildren();
 const items=[...state.localLeads.values()];if(!items.length){
  const hasFilter=Object.entries(state.leadFilters).some(([key,value])=>key!=='sort'&&Boolean(value));
   const ready=canReadDeviceData();
  const blank=state.leadsLoaded?emptyState('fy-state-06-no-results.png',hasFilter?'没有匹配的评论':'还没有采集到评论',hasFilter?'调整筛选后再查看。':'运行采集任务后，评论会保存在这台电脑。'):ready?emptyState('fy-state-01-empty-customers.png','还没读取评论','从这台电脑载入已采集的内容。'):state.selected?emptyState('fy-state-05-offline.png','本地助手暂时离线','设备连接已保留；打开这台电脑的本地助手，在线后刷新评论。'):emptyState('fy-state-05-offline.png','尚未连接本机设备','到设置中确认本机设备后读取评论。');
  const action=node('button',state.leadsLoaded?(hasFilter?'清除筛选':'去找评论'):(ready?'读取评论':state.selected?'查看设备状态':'查看设置'),'secondary empty-action');action.type='button';
   action.addEventListener('click',run(async()=>{if(!state.leadsLoaded){if(!canReadDeviceData()){renderPage('devices');await refreshDevices();return;}action.textContent='正在读取…';try{await loadLocalLeads(0);}catch(error){action.textContent='重试读取';throw error;}return;}if(hasFilter){$('lead-filter').reset();state.leadFilters={};state.leadGroupOffset=0;state.leadGroupLabel='';updateLeadFilterLabel();await loadLocalLeads(0);}else{renderPage('tasks');await refreshTasks();}}));blank.lastElementChild.append(action);  list.append(blank);motionResults(list,'.empty-state');
 }
 for(const [index,lead] of items.entries()){
  const card=node('article',undefined,'comment-card');
  const head=node('div',undefined,'comment-head');
  const box=document.createElement('input');
  const person=node('div',undefined,'comment-person');
  const badges=node('div',undefined,'comment-badges');
  const intent=leadIntentPresentation(lead),intentBadge=node('span',intent.label,'comment-intent-badge');intentBadge.dataset.grade=intent.grade;
  badges.append(intentBadge);if(intent.score!==null)badges.append(node('span',`评分 ${intent.score}`,'comment-score'));
  const replyBadge=node('span',undefined,'comment-reply-badge');badges.append(replyBadge);
  const info=node('div',undefined,'comment-info');
  const action=node('div',undefined,'comment-action');
  const source=node('div',undefined,'comment-source');
  const reply=node('button',publicRepliesHeld()?'准备回复草稿':'回复这条','secondary');
  box.type='checkbox';
  box.checked=state.selectedLeads.has(lead.id);
  card.classList.toggle('is-selected',box.checked);
  box.setAttribute('aria-label',`选择 ${lead.author||'评论'}`);
  box.addEventListener('change',()=>{
   if(box.checked)state.selectedLeads.set(lead.id,lead);
   else state.selectedLeads.delete(lead.id);
   card.classList.toggle('is-selected',box.checked);
   updateLeadActions();
  });
  person.append(node('strong',lead.author||'昵称未提供'));
  if(state.latestCollection&&state.latestCollection.taskId===lead.task_id&&Array.isArray(state.latestCollection.baselineIds)&&!state.latestCollection.baselineIds.includes(lead.id))person.append(node('small','本批新增','comment-new'));
  head.append(box,person,badges);
  if(lead.published_at)info.append(node('span',commentDateText(lead.published_at)));
  if(lead.region)info.append(node('span',lead.region));
  info.append(node('span',lead.comment_level===2?'楼中楼':'主评论'));
  reply.type='button';
  reply.disabled=lead.platform!=='xiaohongshu'||!lead.comment_id;
  reply.setAttribute('aria-expanded','false');
  reply.addEventListener('click',run(async()=>{
   const existing=card.querySelector('.reply-editor');
   if(existing){
    existing.hidden=!existing.hidden;
    reply.textContent=existing.hidden?(publicRepliesHeld()?'准备回复草稿':'回复这条'):(publicRepliesHeld()?'收起草稿':'收起回复');
    reply.setAttribute('aria-expanded',String(!existing.hidden));
    if(!existing.hidden){motionIn([existing]);existing.querySelector('textarea')?.focus({preventScroll:true});}
    return;
   }
   reply.textContent='正在读取…';
   try{
    await openReply(card,lead);
    const panel=card.querySelector('.reply-editor');
    if(panel){panel.id=`reply-panel-${index}`;reply.setAttribute('aria-controls',panel.id);reply.setAttribute('aria-expanded','true');reply.textContent=publicRepliesHeld()?'收起草稿':'收起回复';motionIn([panel]);panel.querySelector('textarea')?.focus({preventScroll:true});}
   }finally{if(!card.querySelector('.reply-editor'))reply.textContent=publicRepliesHeld()?'准备回复草稿':'回复这条';}
  }));
  action.append(reply);
  const origin=[lead.content_title,lead.content_author].filter(Boolean).join(' · ');if(origin)source.append(node('span',origin));
  if(/^https:\/\//.test(lead.url||'')){
   const link=node('a','打开原帖','source-link');
   link.href=lead.url;
   link.target='_blank';
   link.rel='noopener noreferrer';
   source.append(link);
  }
  const details=node('details',undefined,'comment-details'),detailBody=node('div',undefined,'comment-details-body');details.append(node('summary','详情'));
  for(const [label,value] of [['保存时间',lead.created_at&&commentDateText(lead.created_at)],['用户 ID',lead.author_id],['评论 ID',lead.comment_id],['评分依据',lead.grade_reason]])if(value)detailBody.append(node('p',`${label}：${value}`));
  if(detailBody.childElementCount||detailBody.children?.length){details.append(detailBody);action.append(details);}
  card.append(head,node('p',lead.text||'（评论正文为空）','comment-text'),info,action,source);
  updateLeadReplyBadge(card,canonicalLeadReplyState(lead));
  list.append(card);
 }
 motionResults(list,'.comment-card');updateLeadActions();$('local-lead-page').textContent=`${state.leadTotal?state.leadOffset+1:0}–${Math.min(state.leadOffset+items.length,state.leadTotal)} / ${state.leadTotal}`;syncLeadPagination();$('lead-filter-state').hidden=!state.leadFilters.task_id;$('lead-filter-state').textContent=state.leadFilters.task_id?`本任务评论${state.latestCollection?.taskId===state.leadFilters.task_id&&Number.isSafeInteger(state.latestCollection.added)&&state.latestCollection.added>=0?' · 本批新增 '+state.latestCollection.added+' 条':''}`:'';if($('clear-task-filter'))$('clear-task-filter').hidden=!state.leadFilters.task_id;}
function syncLeadPagination(){$('local-lead-prev').disabled=state.leadOffset===0;$('local-lead-next').disabled=state.leadOffset+25>=state.leadTotal;}
function updateLeadViewCapabilities(contract){state.leadViewContract=contract;const sort=$('lead-sort'),reply=$('lead-reply-filter');if(sort){const option=sort.querySelector('option[value="intent"]');if(option)option.disabled=contract==='legacy';if(contract==='legacy')sort.value='newest';}if(reply)reply.disabled=contract==='legacy';if(contract==='legacy'){state.leadFilters.sort='newest';delete state.leadFilters.reply_state;if(reply)reply.value='';}updateLeadReadNotice();}
function updateLeadReadNotice(){const notice=$('lead-read-notice');if(!notice)return;const text=state.leadGroupingContract==='legacy'?'重新打开工作台后可使用分类。':state.leadViewContract==='legacy'?'更新助手后可按意向及回复筛选。':'';notice.hidden=!text;notice.textContent=text;}
function updateLeadGroupingCapabilities(contract){state.leadGroupingContract=contract;if(contract==='legacy'){delete state.leadFilters.group_by;delete state.leadFilters.group_key;state.leadGroups=[];state.leadGroupsTotal=0;state.leadGroupOffset=0;state.leadGroupLabel='';}const control=$('lead-group-by');if(control){for(const option of control.querySelectorAll?.('option')||[])if(option.value)option.disabled=contract==='legacy';if(contract==='legacy')control.value='';}updateLeadReadNotice();}
function validateLeadGroups(result,data){
 const groups=result.groups,total=result.groups_total,offset=result.group_offset,keys=new Set();
 if(result.group_by!==(data.group_by||'')||result.group_key!==(data.group_key||'')||result.group_limit!==30||!Number.isSafeInteger(total)||total<0||!Number.isSafeInteger(offset)||offset!==(data.group_offset||0)||!Array.isArray(groups)||groups.length!==Math.min(30,Math.max(0,total-offset)))throw Error('分类结果尚未确认，请重新检查。');
 for(const group of groups){if(typeof group?.key!=='string'||!group.key||keys.has(group.key)||typeof group.label!=='string'||!group.label.trim()||!Number.isSafeInteger(group.count)||group.count<0)throw Error('分类结果尚未确认，请重新检查。');keys.add(group.key);}
}
async function readLeadPage(offset,options={}){
 const data={sort:'intent',group_by:'',...(options.filters||state.leadFilters),offset,limit:25};if(data.group_by)data.group_offset=options.groupOffset??state.leadGroupOffset??0;if(options.snapshot)data.snapshot=options.snapshot;
 if(state.leadViewContract==='legacy'){delete data.sort;delete data.reply_state;}
 if(state.leadGroupingContract==='legacy'){if(options.snapshot&&data.group_by)throw Error('分类导出尚未支持，请重新打开工作台后再试。');delete data.group_by;delete data.group_key;delete data.group_offset;}
 let job;
 try{job=await execute('leads_list',data);}catch(error){if(error.status!==403||!(/参数|字段/.test(error.message))||!('sort' in data||'reply_state' in data||'group_by' in data))throw error;if(options.snapshot&&data.group_by)throw Error('分类导出尚未支持，请重新打开工作台后再试。');delete data.group_by;delete data.group_key;delete data.group_offset;updateLeadGroupingCapabilities('legacy');if(state.leadViewContract!=='lead-view-v1'){delete data.sort;delete data.reply_state;updateLeadViewCapabilities('legacy');}job=await execute('leads_list',data);}
 if(job?.status!=='succeeded')throw Error(job?.error||'助手未能读取评论，请检查连接状态');const result=job.result||{items:[],total:0};
 if(result.view_contract==='lead-view-v1'){if(data.sort&&result.sort!==data.sort||data.reply_state&&result.reply_state!==data.reply_state)throw Error('排序或筛选结果尚未确认，请更新助手后核对。');updateLeadViewCapabilities('lead-view-v1');}
 else updateLeadViewCapabilities('legacy');
 if(result.grouping_contract==='lead-groups-v1'){validateLeadGroups(result,data);updateLeadGroupingCapabilities('lead-groups-v1');}
 else{updateLeadGroupingCapabilities('legacy');if(options.snapshot&&data.group_by)throw Error('分类导出尚未支持，请重新打开工作台后再试。');}return result;
}
async function loadLocalLeads(offset=0,options={}){const read=++localLeadReadGeneration,page=pageGeneration,device=state.selected,generation=state.deviceGeneration;const result=await readLeadPage(offset,options);if(read!==localLeadReadGeneration||page!==pageGeneration||device!==state.selected||generation!==state.deviceGeneration)return;state.leadOffset=offset;state.leadTotal=result.total||0;state.localLeads=new Map((result.items||[]).map(item=>[item.id,item]));state.leadGroups=result.grouping_contract==='lead-groups-v1'?result.groups:[];state.leadGroupsTotal=result.groups_total||0;state.leadGroupOffset=result.group_offset||0;const selectedGroup=state.leadGroups.find(group=>group.key===state.leadFilters.group_key);if(selectedGroup)state.leadGroupLabel=selectedGroup.label;state.leadsLoaded=true;renderLocalLeads();}
function replyStatusText(){return {none:'尚无草稿',draft:'草稿已保存，待审核',approved:publicRepliesHeld()?'已审核；公开发送暂停':'已审核，待发送',copied:publicRepliesHeld()?'已复制；对外发送暂停':'已复制，待人工发送',sending:publicRepliesHeld()?'历史发送状态待核实':'发送中',sent:'已发送',unknown:'发送结果待人工核实'};}
function canonicalLeadReplyState(lead){const canonical=Object.hasOwn(lead,'reply_state'),value=canonical?lead.reply_state:lead.reply_status;if(!canonical&&(value==='未回复'||value===undefined||value===null||value===''))return 'none';return ['none','draft','approved','copied','sending','sent','unknown'].includes(value)?value:'unknown';}
function leadReplyStateText(status){return {none:'未回复',draft:'草稿待审',approved:'已审核 · 未发送',copied:'已复制 · 未发送',sending:'发送待确认',sent:'已回复',unknown:'结果待核对'}[status]||'结果待核对';}
function updateLeadReplyBadge(card,status){const badge=card.querySelector('.comment-reply-badge');if(!badge)return;badge.dataset.state=['none','draft','approved','copied','sending','sent','unknown'].includes(status)?status:'unknown';badge.textContent=leadReplyStateText(badge.dataset.state);}
async function openReply(card,lead){
 const job=await execute('reply_status',{lead_id:lead.id});
 if(job?.status!=='succeeded')throw Error('无法读取回复状态');
 let current=job.result?.status?job.result:{status:'none'};
 const panel=node('div',undefined,'reply-editor'),status=node('p',`回复状态：${replyStatusText()[current.status]||'待核实'}`,'help reply-status'),area=node('textarea');
 status.setAttribute('role','status');status.setAttribute('aria-live','polite');
 area.rows=3;area.maxLength=1000;
 area.placeholder='写给这条评论的回复。请先保存草稿，再由管理员审核。';
 area.value=current.text||'';panel.append(status,area);
 const actions=node('div',undefined,'toolbar');
 const save=node('button','保存回复草稿','secondary'),refresh=node('button','刷新审核状态','secondary');
 const approve=node('button','管理员审核','secondary'),send=node('button','确认发送这条回复');
 save.type=refresh.type=approve.type=send.type='button';
 const confirm=node('div',undefined,'reply-confirm'),accountField=node('label',undefined,'reply-account-field');
 const accountSelect=node('select'),consent=node('label',undefined,'send-consent'),check=document.createElement('input');
 accountField.append(node('span','公开回复账号'),accountSelect);
 check.type='checkbox';consent.append(check,node('span','我确认用所选账号把以上内容公开回复到这条小红书评论'));
 confirm.hidden=true;
 const readyAccounts=(state.accounts||[]).filter(item=>item.platform==='xiaohongshu'&&item.status==='ready');
 accountSelect.append(new Option(readyAccounts.length?'请选择公开回复账号':'暂无已登录账号，请到采集任务页检查',''));
 for(const item of readyAccounts)accountSelect.append(new Option(item.name||item.id,item.id));
 if(readyAccounts.length===1)accountSelect.value=readyAccounts[0].id;
 accountSelect.addEventListener('change',()=>{check.checked=false;});
 const update=()=>{
  updateLeadReplyBadge(card,current.status);lead.reply_state=current.status;
  approve.hidden=cloud.user?.role!=='admin'||current.status!=='draft';
  const wasHidden=confirm.hidden;
  confirm.hidden=publicRepliesHeld()||!['approved','copied'].includes(current.status);
  send.hidden=confirm.hidden;
  if(wasHidden&&!confirm.hidden)motionIn([confirm]);
  save.disabled=['sent','unknown','sending'].includes(current.status);
  status.textContent=`回复状态：${replyStatusText()[current.status]||'待核实'}${current.last_error?' · '+current.last_error:''}`;
  status.classList.toggle('is-error',current.status==='unknown');
 };
 const actionResult=async work=>{
  try{await work();motionIn([status]);}
  catch(error){
   if(error.sessionExpired)return;
   status.textContent=error.requestId?'结果未确认，请先核对最近操作，再决定是否重试。':error.message||'操作未完成';
   status.classList.add('is-error');motionIn([status]);
  }
 };
 refresh.addEventListener('click',run(()=>actionResult(async()=>{
  const answer=await execute('reply_status',{lead_id:lead.id});
  if(answer?.status!=='succeeded')throw Error(answer?.error||'审核状态读取失败');
  current=answer.result?.status?answer.result:{status:'none'};
  if(current.text!==undefined)area.value=current.text;
  check.checked=false;update();
 })));
 save.addEventListener('click',run(()=>actionResult(async()=>{
  const answer=await execute('reply_prepare',{lead_id:lead.id,text:area.value.trim()});
  if(answer?.status!=='succeeded')throw Error(answer?.error||'草稿保存失败');
  current=answer.result;update();
 })));
 approve.addEventListener('click',run(()=>actionResult(async()=>{
  const answer=await execute('reply_approve',{reply_id:current.id});
  if(answer?.status!=='succeeded')throw Error(answer?.error||'审核未完成');
  current=answer.result;update();
 })));
 send.addEventListener('click',run(()=>actionResult(async()=>{
  if(publicRepliesHeld())throw Error('当前版本验收中，暂不能公开发送回复');
  if(!check.checked)throw Error('请先勾选确认真实对外发送');
  if(!current.id)throw Error('请先保存并审核草稿');
  if(area.value.trim()!==String(current.text||'').trim())throw Error('输入内容已改变，请重新保存草稿并等待管理员审核');
  const snapshot=await execute('workspace_state',{});
  if(snapshot?.status!=='succeeded')throw Error('无法确认平台账号状态');
  state.accounts=snapshot.result?.accounts||[];
  const available=state.accounts.filter(item=>item.platform==='xiaohongshu'&&item.status==='ready');
  if(!available.length)throw Error('请先在关键词采集页确认小红书账号已登录');
  if(!accountSelect.value)throw Error('请先选择公开回复的小红书账号');
  const account=available.find(item=>item.id===accountSelect.value);
  if(!account)throw Error('所选小红书账号状态已变化；请到采集任务页检查后重新打开回复');
  const answer=await execute('reply_send',{reply_id:current.id,account_id:account.id,authorized:true});
  if(answer?.status!=='succeeded')throw Error(answer?.error||'发送结果待核实');
  current=answer.result;update();
 })));
 actions.append(save,refresh,approve);
 confirm.append(accountField,consent,send);
 panel.append(actions,confirm);card.append(panel);update();
}
function localCalendarDate(date){return [date.getFullYear(),String(date.getMonth()+1).padStart(2,'0'),String(date.getDate()).padStart(2,'0')].join('-');}
function csvCell(value){const raw=String(value??'');const safe=/^[\s\uFEFF]*[=+\-@]/u.test(raw)||/^[\t\r\n]/.test(raw)?"'"+raw:raw;return '"'+safe.replaceAll('"','""')+'"';}
async function exportLeads(){
 const status=$('lead-filter-state');status.hidden=false;
 try{
  const rows=[],seen=new Set(),filters={...state.leadFilters},groupOffset=state.leadGroupOffset||0;let offset=0,total=null,snapshot='begin';
  do{
   const result=await readLeadPage(offset,{snapshot,filters,groupOffset}),count=Number(result.total),items=result.items;
   if(typeof result.snapshot!=='string'||!result.snapshot||snapshot!=='begin'&&result.snapshot!==snapshot)throw Error('本地助手不支持一致性导出，请更新助手后重试');
   snapshot=result.snapshot;
   if(!Number.isSafeInteger(count)||count<0||!Array.isArray(items)||items.length!==Math.min(25,count-offset)||total!==null&&total!==count)throw Error('导出期间评论列表发生变化，请刷新后重试');
   if(total===null)total=count;
   for(const row of items){const id=String(row?.id||'');if(!id||seen.has(id))throw Error('导出发现重复或缺失的评论，请刷新后重试');seen.add(id);rows.push(row);}
   offset+=items.length;
   status.textContent=`正在导出 ${Math.min(offset,total)}/${total} 条…`;
  }while(offset<total);
  const confirmation=await readLeadPage(0,{snapshot,filters,groupOffset});
  if(confirmation.snapshot!==snapshot||Number(confirmation.total)!==total||!Array.isArray(confirmation.items)||confirmation.items.length!==Math.min(25,total)
   ||confirmation.items.some((row,index)=>row?.id!==rows[index]?.id))throw Error('导出期间评论列表发生变化，请刷新后重试');
  const columns=[['content_title','来源帖子'],['content_author','博主'],['author','评论用户'],['author_id','用户ID'],['published_at','评论时间'],['region','IP属地'],['text','评论内容'],['comment_level','层级'],['parent_id','主评论ID'],['comment_id','评论ID'],['url','原帖链接'],['grade','意向等级'],['reply_state','回复状态']];
  const csv='\ufeff'+[columns.map(x=>csvCell(x[1])).join(','),...rows.map(row=>columns.map(([key])=>csvCell(key==='reply_state'?leadReplyStateText(canonicalLeadReplyState(row)):row[key])).join(','))].join('\r\n');
  const link=document.createElement('a'),url=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));
  link.href=url;link.download=`方隅小红书评论-${localCalendarDate(new Date())}.csv`;
  document.body.append(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),60000);
  status.textContent=`已导出 ${rows.length} 条评论。`;
 }catch(error){status.textContent='导出失败，请稍后重试。';throw error;}
}
function requireXiaohongshuShareSelection(){if([...state.selectedLeads.values()].some(lead=>lead.platform!=='xiaohongshu'))throw Error('方隅首版只共享小红书线索，请取消其他平台记录的勾选');}
async function publishSelectedLeads(){const chosen=[...state.selectedLeads.values()];if(!chosen.length)throw Error('请先勾选要共享的线索');const current=await cloud.call('list');const maxBatch=current.max_batch||100;if(chosen.length>maxBatch)throw Error(`每次最多共享${maxBatch}条线索，请分批选择`);const items=chosen.map(x=>({platform:x.platform,source_id:x.source_id,author:x.author||'',author_id:x.author_id||'',text:x.text||'',url:x.url||'',grade:x.grade||'',reason:x.grade_reason||'',content_title:x.content_title||'',content_author:x.content_author||'',published_at:x.published_at||'',region:x.region||'',comment_id:x.comment_id||'',parent_id:x.parent_id||'',comment_level:x.comment_level||1,reply_status:x.reply_status||''}));const saved=await cloud.call('publish',{items,revision:current.revision});state.selectedLeads.clear();renderLocalLeads();
 const feedback=$('shared-feedback');feedback.textContent=`已共享 ${saved.shared} 条线索`;feedback.hidden=false;
 $('notice').textContent='';$('notice').classList.remove('error');
 try{await refreshLeads();}catch{say('共享已成功，但清单刷新失败；请稍后点击“刷新共享清单”。',true);return;}
 if(!$('page-leads').hidden){$('shared-leads-card').scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth',block:'start'});motionIn([feedback]);}}
async function refreshTeam(highlightUsername=''){
 const response=await cloud.call('members'),users=response.users||[],list=$('member-list');
 list.replaceChildren();$('team-count').textContent=`${users.filter(member=>!member.disabled).length} 位可登录`;
 if(!users.length)list.append(inlineEmpty('fy-icon-41-add-user.png','还没有成员。'));
 for(const member of users.slice().sort((a,b)=>Number(a.role!=='admin')-Number(b.role!=='admin')||a.username.localeCompare(b.username))){
  const row=node('div',undefined,'row member-row'),label=node('div'),role=node('span',member.role==='admin'?'管理员':'员工','member-role');
  if(highlightUsername===member.username)row.classList.add('is-new');
  role.dataset.role=member.role;label.append(node('strong',member.username),node('small',member.disabled?'已停用':'可登录'));
  row.append(label,role);list.append(row);
 }
}
async function refreshMaintenance(){
 if(cloud.user?.role!=='admin')throw Error('需要管理员权限');
 await refreshDevices();const list=$('maintenance-list'),devices=state.devices;
 list.replaceChildren();if(!devices.length)list.append(inlineEmpty('fy-icon-47-settings.png','当前没有助手设备。'));
 const online=devices.filter(device=>!device.revoked&&device.last_seen&&Date.now()/1000-device.last_seen<90).length;
 const revoked=devices.filter(device=>device.revoked).length;
 const counts=[online,devices.length-online-revoked,revoked];
 const signature=counts.join('/'),changed=state.maintenanceSignature!==signature;state.maintenanceSignature=signature;
 [$('maintenance-online'),$('maintenance-offline'),$('maintenance-revoked')].forEach((cell,index)=>{cell.textContent=String(counts[index]);});
 $('maintenance-summary').hidden=false;
 if(changed&&window.gsap&&!matchMedia('(prefers-reduced-motion: reduce)').matches)window.gsap.fromTo('#maintenance-summary strong',{autoAlpha:.45,y:5},{autoAlpha:1,y:0,duration:.22,stagger:.045,ease:'power2.out',clearProps:'all',overwrite:'auto'});
 for(const device of devices){
  const row=node('div',undefined,'row maintenance-row'),label=node('div');
  const status=device.revoked?'已停用':device.last_seen&&Date.now()/1000-device.last_seen<90?'在线':'离线';
  const version=device.version?`${status==='在线'?'当前':'上次上报'}版本 ${device.version}`:'版本待上报';
  label.append(node('strong',device.name),node('small',`${device.owner} · ${status} · ${version}`));
  if(device.revoked&&device.xhs_claim_count)label.append(node('small',`小红书账号占用 ${device.xhs_claim_count} 个，需到“连接电脑”页确认旧电脑停用后处理。`));
  if(device.revoked&&device.uncertain_count)label.append(node('small',`结果不明的旧指令 ${device.uncertain_count} 条，解除账号占用前请先核对。`));
  if(device.last_seen)label.append(node('small',`上次在线：${new Date(device.last_seen*1000).toLocaleString('zh-CN')}`));
  row.append(label);list.append(row);
 }
}
async function refreshReviewDevices(){
 if(cloud.user?.role!=='admin')throw Error('需要管理员权限');
 await refreshDevices();
 const select=$('review-device'),previous=select.value;
 select.replaceChildren();
 for(const device of state.devices.filter(item=>!item.revoked)){
  const online=!!device.last_seen&&Date.now()/1000-device.last_seen<90;
  const option=node('option',`${device.owner} · ${device.name} · ${online?'在线':'离线'}`);
  option.value=device.id;select.append(option);
 }
 if([...select.options].some(option=>option.value===previous))select.value=previous;
 if(previous&&select.value!==previous)clearReviewDisplay('原员工电脑已不可选，请重新读取草稿。');
 if(!select.options.length)$('review-feedback').textContent='还没有可审核的员工电脑。';
}
function clearReviewDisplay(message='已切换员工电脑，请重新读取草稿。'){
 reviewGeneration++;
 $('review-list').replaceChildren();
 $('review-feedback').textContent=message;
 $('review-feedback').classList.remove('is-error');
}
async function loadPendingReviews(){
 if(cloud.user?.role!=='admin')throw Error('需要管理员权限');
 const feedback=$('review-feedback'),list=$('review-list');
 clearReviewDisplay('正在读取待审核草稿…');const generation=reviewGeneration;
 try{
  await refreshReviewDevices();
  if(generation!==reviewGeneration)return;
  const deviceId=$('review-device').value,device=state.devices.find(item=>item.id===deviceId);
  if(!device)throw Error('请先选择员工电脑');
  if(!device.last_seen||Date.now()/1000-device.last_seen>=90)throw Error('这台电脑离线，请员工打开本地助手后再读取');
  const job=await execute('reply_pending',{},deviceId);
  if(generation!==reviewGeneration)return;
  if(job?.status!=='succeeded')throw Error(job?.error||'读取待审核草稿未完成');
  const drafts=job.result?.items||[];
  feedback.textContent=drafts.length?`这台电脑有 ${job.result?.total||drafts.length} 条待审核草稿，当前显示 ${drafts.length} 条。`:'这台电脑暂无待审核草稿。';
  for(const draft of drafts){
  const row=node('article',undefined,'row review-row');
  const source=node('div',undefined,'review-source');
  source.append(node('strong',draft.author||'评论用户'),node('small',[draft.content_title,draft.content_author].filter(Boolean).join(' · ')||'来源帖子未命名'));
  const comment=node('p',(draft.comment_text||'（原评论为空）')+(draft.comment_truncated?'…（原评论较长，请打开原帖核对）':''),'review-comment');
  const reply=node('p',draft.text||'（草稿为空）','review-draft');
  const identity=node('small',[draft.author_id?`用户 ID ${draft.author_id}`:'',draft.comment_id?`评论 ID ${draft.comment_id}`:'',draft.updated_at?`草稿更新 ${draft.updated_at}`:''].filter(Boolean).join(' · '));
  const label=node('small',draft.needs_rewrite?'旧草稿过长；请员工重新保存，当前不能审核':SAFETY_HOLD&&!devicePlatformQa(deviceId)?'待审核回复 · 审核仅保存内部状态，公开发送暂停':'待审核回复 · 审核后仍需员工确认公开发送');
  row.append(source,identity,comment,reply,label);
  if(/^https:\/\//.test(draft.source_url||'')){
   const link=node('a','核对原帖 ↗','shared-lead-link');link.href=draft.source_url;link.target='_blank';link.rel='noopener noreferrer';row.append(link);
  }
  const approve=node('button','审核通过','secondary');approve.type='button';approve.disabled=!!draft.needs_rewrite;
  approve.addEventListener('click',run(async()=>{
   if($('review-device').value!==deviceId||generation!==reviewGeneration)throw Error('已切换电脑，请重新读取草稿');
   const answer=await execute('reply_approve',{reply_id:draft.id},deviceId);
   if(answer?.status!=='succeeded'||answer.result?.status!=='approved')throw Error(answer?.error||'审核结果待核实，请重新读取草稿');
   if(generation!==reviewGeneration)return;
   row.remove();feedback.textContent=SAFETY_HOLD&&!devicePlatformQa(deviceId)?'已审核通过；公开发送暂停，员工可查看已审核草稿。':'已审核通过；员工仍需在自己的电脑确认是否公开发送。';
  }));
  row.append(approve);list.append(row);
  }
  motionResults(list,'.review-row');
 }catch(error){
  if(generation===reviewGeneration){feedback.textContent=error.message||'读取失败，请重试。';feedback.classList.add('is-error');}
  throw error;
 }
}
function resetWorkspaceSession(){
 developmentIdentityClosing=true;
 stopDevelopmentIdentityWatch();
 enterpriseWorkspace?.reset();platformAccount?.reset();$('account-menu').hidden=true;$('account-menu-button').setAttribute('aria-expanded','false');
 clearReviewDisplay();
 collectionProgress?.reset();activeCollection=null;
 desktopDeviceHint='';desktopBindingBlocked=false;pendingTaskSave=null;verifiedTaskToStart=null;
 accountSnapshotKnown=false;state.deviceGeneration++;state.devices=[];state.selected='';state.accounts=[];state.tasks=[];state.job=null;state.pendingRequests.clear();
 state.localLeads.clear();state.selectedLeads.clear();state.taskProgress.clear();state.maintenanceSignature='';state.leadFilters={};state.leadViewContract=null;state.latestCollection=null;
 state.leadGroupingContract=null;state.leadGroups=[];state.leadGroupsTotal=0;state.leadGroupOffset=0;state.leadGroupLabel='';
 state.leadOffset=0;state.leadTotal=0;state.leadsLoaded=false;setupInitialized=false;renderedDeviceSignature='';
 sharedListState.cursor='';sharedListState.revision=null;sharedListState.count=0;sharedListState.generation++;
 for(const id of ['device-list','account-list','task-list','lead-list','member-list','maintenance-list','review-list','review-device','keyword-suggestions'])$(id).replaceChildren();
 for(const id of ['pair','task','lead-filter','member'])$(id).reset();$('member-feedback').hidden=true;$('member-feedback').textContent='';$('member-feedback').classList.remove('is-error');$('account-feedback').hidden=true;$('account-feedback').textContent='';$('account-feedback').classList.remove('is-error');updateLeadFilterLabel();
 $('task-device').replaceChildren();$('task-account').replaceChildren();updateTaskChoicePresentation();$('keyword-placeholder').hidden=false;$('keyword-suggestions').hidden=true;
 stopPairWatch();$('pair-code').value='';$('pair-expiry').textContent='';$('pair-result').hidden=true;$('copy-pair').textContent='复制连接码';$('pair-copy-error').hidden=true;$('pair-connected').hidden=true;
 $('shared-feedback').hidden=true;$('shared-feedback').textContent='';$('review-feedback').textContent='选择一台员工电脑后读取草稿。';
 $('job-state').textContent='暂无操作';$('keyword-helper').open=false;updateTaskPrerequisite();
 renderLocalLeads();renderPlatformAvailability();showLoggedIn();updateNavLine(false);
}
function expireSession(error){sessionExpiryNotice=error.message;resetWorkspaceSession();say(sessionExpiryNotice,true);}
function handle(error){if(error.sessionExpired)return;const message=error.message||'操作未完成，请核对状态';say(cloud.user?.role==='operator'?employeeAiFinancialText(message):message,true);if(error.requestId&&[...state.pendingRequests.values()].includes(error.requestId)){$('job-state').textContent='结果未确认，请核对状态，暂勿重复操作。';}}
function run(fn,after){const locks=new WeakSet();return async event=>{event?.preventDefault();const source=event?.currentTarget||event?.submitter,lock=source&&typeof source==='object'?source:null;if(lock&&locks.has(lock))return;if(lock)locks.add(lock);const page=pageGeneration;const trigger=event?.submitter||source;const button=trigger instanceof HTMLButtonElement?trigger:trigger?.querySelector?.('button[type=submit],button:not([type])');if(button){button.disabled=true;button.classList.add('is-busy');button.setAttribute('aria-busy','true');}try{await fn(event);}catch(error){if(page===pageGeneration)handle(error);}finally{if(lock)locks.delete(lock);if(button){button.disabled=false;button.classList.remove('is-busy');button.removeAttribute('aria-busy');}after?.();if(button?.id==='create-task')updateTaskPrerequisite();}};}
async function loadDesktopDeviceHint(allowPair=false){
 if(!config.localWorkspace||!cloud.user)return;
 let device=await cloud.call('local_device');
 if(!device.bound&&allowPair&&cloud.user.role==='operator')try{device=await cloud.call('local_pair');}catch(error){desktopBindingBlocked=true;throw error;}
 if(device.bound&&device.owner&&device.owner!==cloud.user.username){desktopBindingBlocked=true;throw Error('这台电脑已由其他员工绑定；请联系管理员核对，不能自动改绑。');}
 desktopBindingBlocked=!device.bound;
 desktopDeviceHint=device.bound&&device.owner===cloud.user.username?device.device_id||'':'';
}
async function initDesktopSession(){
 if(!config.localWorkspace)return;
 try{
  if(!await cloud.restore()){bootingDevelopmentWorkspace=false;showLoggedIn();return;}
  startDevelopmentIdentityWatch();
  bootingDevelopmentWorkspace=false;
  let localError=null;
  try{await loadDesktopDeviceHint(true);}catch(error){localError=error;}
  await enterWorkspace();
  if(cloud.user?.development_local_only)say('已进入本机工作台。企业服务暂不可用，评论资料可查看；云端操作等待连接恢复。',true);
  if(localError)say(localError.message,true);
 }catch(error){bootingDevelopmentWorkspace=false;showLoggedIn();handle(error);}
}
async function enterWorkspace(){
 try{await refreshDevices();}
 catch(error){showLoggedIn();renderPage('devices');throw error;}
 renderPage('leads');showLoggedIn();
 restoreTaskOperation();
 if(state.selected)await refreshTasks();
 if(config.localWorkspace)try{await enterpriseWorkspace?.restorePool();}catch(error){handle(error);}
 if(state.selected)await enterpriseWorkspace?.loadWorklist();
 void enterpriseWorkspace?.profile();void enterpriseWorkspace?.latest();
}
$('login').addEventListener('submit',run(async event=>{const element=event.currentTarget,form=new FormData(element);sessionExpiryNotice='';developmentIdentityClosing=false;await cloud.login(String(form.get('username')).trim(),String(form.get('password')));startDevelopmentIdentityWatch();let localError=null;if(config.localWorkspace)try{await loadDesktopDeviceHint(true);}catch(error){localError=error;}element.reset();$('notice').textContent='';$('notice').classList.remove('error');await enterWorkspace();if(localError)say(localError.message,true);}));
$('logout').addEventListener('click',run(async()=>{
 developmentIdentityClosing=true;stopDevelopmentIdentityWatch();
 let remoteLogoutOk=true;
 try{await cloud.logout();}catch{remoteLogoutOk=false;}
 resetWorkspaceSession();say(remoteLogoutOk?'已退出登录':'本机已退出；服务端注销未确认，请稍后核对',!remoteLogoutOk);
}));
$('account-menu-button').addEventListener('click',()=>{const menu=$('account-menu');menu.hidden=!menu.hidden;$('account-menu-button').setAttribute('aria-expanded',String(!menu.hidden));});
$('pending-bell').addEventListener('click',run(async()=>{renderPage('leads');const generation=pageGeneration;if(!canReadDeviceData())await refreshDevices();if(generation!==pageGeneration)return;await enterpriseWorkspace?.openPending();}));
$('open-platform-account').addEventListener('click',()=>{$('account-menu').hidden=true;renderPage('devices');const generation=pageGeneration;void refreshDevices().then(()=>generation===pageGeneration&&canReadDeviceData()?refreshTasks():undefined).catch(error=>{if(generation===pageGeneration)handle(error);});});
for(const button of document.querySelectorAll('[data-menu-page]'))button.addEventListener('click',run(async()=>{$('account-menu').hidden=true;renderPage(button.dataset.menuPage);if(button.dataset.menuPage==='team')await refreshTeam();if(button.dataset.menuPage==='maintenance')await refreshMaintenance();}));
document.addEventListener('click',event=>{if(!$('account-menu').hidden&&!event.target.closest('#account-menu,#account-menu-button')){$('account-menu').hidden=true;$('account-menu-button').setAttribute('aria-expanded','false');}});
document.addEventListener('keydown',event=>{if(event.key==='Escape'&&$('workspace-help').open){$('workspace-help').open=false;$('workspace-help').querySelector('summary')?.focus({preventScroll:true});}});
const workspaceNav=$('workspace').querySelector('nav');
workspaceNav.addEventListener('click',event=>{
 const tab=event.target?.closest?.('button[data-page]');
 if(!tab||!workspaceNav.contains(tab))return;
 event.preventDefault();
 const page=tab.dataset.page;
 renderPage(page);
 const generation=pageGeneration;
 void (async()=>{
  if(page==='devices')await refreshDevices();
  if(page==='tasks')await refreshTasks();
  if(page==='leads'){
   if(!canReadDeviceData())await refreshDevices();if(generation!==pageGeneration)return;
   await enterpriseWorkspace.onPage('leads');
  }
  if(page==='customers'){
   if(!canReadDeviceData())await refreshDevices();if(generation!==pageGeneration)return;
   if(!config.localWorkspace)throw Error('请在桌面工作台查看本机客户清单');
   await customerWorkspace.load();
  }
  if(page==='review')await refreshReviewDevices();
  if(page==='team')await refreshTeam();
  if(page==='maintenance')await refreshMaintenance();
 })().catch(error=>{if(generation===pageGeneration)handle(error);});
});
$('refresh-reviews').addEventListener('click',run(loadPendingReviews));
$('review-device').addEventListener('change',()=>clearReviewDisplay());
$('pair').addEventListener('submit',run(async event=>{
 if(config.localWorkspace)throw Error('本机连接由系统自动完成，不需要连接码。');
 if(!CAN_PAIR)throw Error('当前版本验收中，暂不连接新电脑或打开旧版助手');
 const name=String(new FormData(event.currentTarget).get('name')).trim();
 const result=await cloud.call('pair_create',{name});
 $('pair-code').value=result.pair_code;$('copy-pair').disabled=false;
 $('copy-pair').textContent='复制连接码';$('pair-copy-error').hidden=true;
 $('pair-connected').hidden=true;$('pair-connected').classList.remove('is-expired');
 $('pair-result').hidden=false;
 $('pair-expiry').textContent=`有效期至 ${new Date(result.expires*1000).toLocaleTimeString()}`;
 motionIn([$('pair-result')]);startPairWatch(result.expires,name);
 requestAnimationFrame(()=>{
  const box=$('pair-result'),bounds=box.getBoundingClientRect();
  if(bounds.bottom>innerHeight-24||bounds.top<80)box.scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth',block:'center'});
  setTimeout(()=>{if(!box.hidden&&document.activeElement===document.body)$('copy-pair').focus({preventScroll:true});},270);
 });
}));
$('pair-setup').addEventListener('toggle',()=>{if($('pair-setup').open)motionIn([$('pair-setup').querySelector('.details-body')]);});
$('keyword-helper').addEventListener('toggle',()=>{if($('keyword-helper').open)motionIn([$('keyword-helper').querySelector('.details-body')]);});
$('task-prerequisite-action').addEventListener('click',run(async()=>{if(config.localWorkspace&&$('task-prerequisite-action').dataset.target==='account-safety'){const accountId=$('task-account').value;renderPage('devices');platformAccount?.openReview(accountId);return;}if(config.localWorkspace&&!selectedDeviceOnline()&&!desktopBindingBlocked){await refreshDevices();if(canReadDeviceData())await refreshTasks();return;}renderPage('devices');await refreshDevices();if(canReadDeviceData())await refreshTasks();}));
$('copy-pair').addEventListener('click',run(async()=>{
 const button=$('copy-pair'),input=$('pair-code'),error=$('pair-copy-error');
 try{
  if(!navigator.clipboard?.writeText)throw Error('clipboard unavailable');
  await navigator.clipboard.writeText(input.value);
  error.hidden=true;error.textContent='';button.textContent='已复制 ✓';
  if(window.gsap&&!matchMedia('(prefers-reduced-motion: reduce)').matches)window.gsap.fromTo(button,{scale:.96},{scale:1,duration:.24,ease:'back.out(1.7)',clearProps:'transform',overwrite:'auto'});
 }catch{
  input.focus();input.select();error.textContent='自动复制失败，请按 Ctrl+C 复制选中的连接码。';error.hidden=false;
 }
}));
$('pair-go-tasks').addEventListener('click',run(async()=>{renderPage('tasks');await refreshTasks();}));
$('refresh-devices').addEventListener('click',run(refreshDevices));
$('refresh-tasks').addEventListener('click',run(async()=>{await refreshTasks();await enterpriseWorkspace.refresh();}));
$('task-device').addEventListener('change',run(async event=>{const id=event.currentTarget.value;if(!id||id===state.selected)return;switchDevice(id,true);await refreshDevices();await refreshTasks();}));
$('task-account').addEventListener('change',updateTaskPrerequisite);
$('refresh-leads').addEventListener('click',run(refreshLeads));

function updateLeadFilterLabel(){const form=$('lead-filter'),hasFilter=['date_from','date_to','region'].some(name=>Boolean(form.elements.namedItem(name)?.value));$('lead-filter-more').querySelector('summary').textContent=hasFilter?'时间与 IP 筛选 · 已设置':'时间与 IP 筛选';}
async function changeLeadGrouping(direction){if(!['','note','blogger','date','intent'].includes(direction))throw Error('查看方式无效');if(state.leadGroupingContract==='legacy'){renderLeadGroups();return;}delete state.leadFilters.group_key;state.leadGroupLabel='';state.leadGroupOffset=0;if(direction)state.leadFilters.group_by=direction;else delete state.leadFilters.group_by;await loadLocalLeads(0);}
$('lead-filter').addEventListener('input',updateLeadFilterLabel);$('lead-filter').addEventListener('change',updateLeadFilterLabel);
$('lead-filter-more').addEventListener('toggle',()=>{if($('lead-filter-more').open)motionIn([$('lead-filter-more').querySelector('.lead-filter-extra')]);});
$('lead-filter').addEventListener('submit',run(async event=>{const form=new FormData(event.currentTarget),scope=Object.fromEntries(['task_id','group_by','group_key'].filter(key=>state.leadFilters[key]).map(key=>[key,state.leadFilters[key]]));state.leadFilters={...scope,...Object.fromEntries(['query','date_from','date_to','region','grade','reply_state','sort'].map(key=>[key,String(form.get(key)||'').trim()]).filter(([,value])=>value))};state.leadGroupOffset=0;if(state.leadFilters.date_from&&state.leadFilters.date_to&&state.leadFilters.date_from>state.leadFilters.date_to)throw Error('评论日期起不能晚于日期止');await loadLocalLeads(0);}));
for(const id of ['lead-grade-filter','lead-reply-filter','lead-sort'])$(id).addEventListener('change',()=>$('lead-filter').requestSubmit());
$('clear-task-filter').addEventListener('click',run(async()=>{delete state.leadFilters.task_id;state.leadGroupOffset=0;await loadLocalLeads(0);}));
$('lead-group-by').addEventListener('change',run(event=>changeLeadGrouping(event.currentTarget.value)));
$('clear-lead-group').addEventListener('click',run(async()=>{delete state.leadFilters.group_key;state.leadGroupLabel='';await loadLocalLeads(0);}));
$('lead-group-prev').addEventListener('click',run(()=>loadLocalLeads(state.leadOffset,{groupOffset:Math.max(0,state.leadGroupOffset-30)})));
$('lead-group-next').addEventListener('click',run(()=>loadLocalLeads(state.leadOffset,{groupOffset:state.leadGroupOffset+30})));
$('export-leads').addEventListener('click',run(exportLeads));
$('local-lead-prev').addEventListener('click',run(()=>loadLocalLeads(Math.max(0,state.leadOffset-25)),syncLeadPagination));
$('local-lead-next').addEventListener('click',run(()=>loadLocalLeads(state.leadOffset+25),syncLeadPagination));
$('publish-leads').addEventListener('click',run(async()=>{requireXiaohongshuShareSelection();await publishSelectedLeads();}));
$('refresh-team').addEventListener('click',run(refreshTeam));
$('refresh-maintenance').addEventListener('click',run(refreshMaintenance));
function accountFeedback(message,isError=false){const feedback=$('account-feedback');feedback.textContent=message;feedback.hidden=false;feedback.classList.toggle('is-error',isError);motionIn([feedback]);}
function syncKeywordSuggestions(){
 const keywords=new Set($('task').elements.namedItem('keywords').value.split(/\r?\n/).map(x=>x.trim()).filter(Boolean));
 for(const chip of $('keyword-suggestions').querySelectorAll('button[data-keyword]')){
  const added=keywords.has(chip.dataset.keyword);chip.classList.toggle('is-added',added);
  chip.setAttribute('aria-pressed',String(added));chip.textContent=added?`${chip.dataset.keyword} ✓`:chip.dataset.keyword;
 }
}
$('task').elements.namedItem('keywords').addEventListener('input',syncKeywordSuggestions);
$('task').elements.namedItem('source').addEventListener('change',syncTaskSourceFields);
syncTaskSourceFields();
for(const name of ['search_pages','target_count','daily_limit']){
 const input=$('task').elements.namedItem(name);
 input.addEventListener('input',updateTaskSettingsSummary);
 input.addEventListener('change',updateTaskSettingsSummary);
}
window.addEventListener('pageshow',updateTaskSettingsSummary);
updateTaskSettingsSummary();
$('task').addEventListener('submit',run(event=>enterpriseWorkspace.start(event)));
function memberFeedback(message,isError=false){
 const feedback=$('member-feedback');feedback.textContent=message;feedback.hidden=false;
 feedback.classList.toggle('is-error',isError);motionIn([feedback]);
}
$('member').addEventListener('submit',run(async event=>{
 const element=event.currentTarget,form=new FormData(element);
 const username=String(form.get('username')).trim(),role=String(form.get('role'));
 $('member-feedback').hidden=true;
 try{await cloud.call('member_save',{username,password:String(form.get('password')),role,can_reply:form.get('can_reply')==='on'});}
 catch(error){
  memberFeedback(error.status?error.message||'账号创建未完成，请检查后重试。':'创建结果未确认。请先刷新成员名单核对，再决定是否重试。',true);
  return;
 }
 element.reset();memberFeedback(`已创建 ${username} · ${role==='admin'?'管理员':'员工'}。请单独交付初始密码。`);
 try{await refreshTeam(username);}
 catch{memberFeedback(`已创建 ${username}，但名单刷新失败。请点“刷新成员”核对。`,true);}
}));
const lists=new MutationObserver(records=>{
  if(!window.gsap||matchMedia('(prefers-reduced-motion: reduce)').matches)return;
  const items=[...new Set(records.flatMap(record=>[...record.addedNodes]).filter(item=>item.nodeType===1&&item.matches('.row,.comment-card,.empty,.empty-state')))].slice(0,18);
  const visible=items.filter(item=>!item.closest('[hidden]'));
  if(visible.length)window.gsap.fromTo(visible,{autoAlpha:0,y:6},{autoAlpha:1,y:0,duration:.18,stagger:.02,ease:'power2.out',clearProps:'all',overwrite:'auto'});
});
for(const list of document.querySelectorAll('.list'))lists.observe(list,{childList:true});
matchMedia('(max-width:850px)').addEventListener('change',arrangeTaskCards);
function renderPlatformAvailability(){
 const qa=selectedPlatformQa(),employee=selectedEmployeeRelease(),held=platformActionsHeld();
 document.body.classList.toggle('safety-hold-active',held);
  document.body.dataset.releaseState=SAFETY_HOLD?(employee?'employee-pilot':qa?'internal-platform-qa':'safety-hold'):'released';
  for(const old of document.querySelectorAll?.('.safety-hold')||[])old.remove();
  const help=$('workspace-help-copy');if(help)help.textContent='填写城市和需求，确认关键词后开始采集。意向评论按帖子跟进；客户清单汇总同一个人的评论与联系记录。';
  const connection=$('connection-card');if(connection)connection.hidden=!cloud.user||(cloud.user.role!=='admin'&&!!state.selected&&!desktopBindingBlocked&&selectedDeviceOnline());
 $('pair-setup').hidden=config.localWorkspace||!CAN_PAIR;
 if(CAN_PAIR&&!config.localWorkspace){
   document.querySelector('.assistant-download span').textContent=`使用管理员交付的助手 ${config.pairingVersion} 连接这台电脑。`;
   document.querySelector('#pair-setup .help').textContent='保留已有资料；平台操作是否开放以账号状态为准。';
   $('pair-go-tasks').textContent='返回采集';
 }
  document.querySelector('.task-create-card').hidden=false;
 const guide=document.querySelector('.account-login-guide');
  if(config.localWorkspace){const button=node('button','登录或更换账号','account-login-link');button.type='button';button.addEventListener('click',()=>renderPage('devices'));guide.replaceChildren(button);}
  else guide.textContent='请在桌面工作台管理账号。';
}
renderPlatformAvailability();
collectionProgress=createCollectionProgress($('collection-progress-host'),{
 onStop(session){if(session!==activeCollection?.session||activeCollection.deviceId!==state.selected)return;void requestTaskStop(session.taskId).catch(handle);},
 onOpenResults(session){if(session!==activeCollection?.session||activeCollection.deviceId!==state.selected)return;state.leadFilters={task_id:activeCollection.taskId};state.leadGroupOffset=0;state.leadGroupLabel='';$('lead-filter').reset();renderPage('leads');if(canReadDeviceData())void loadLocalLeads(0).catch(handle);else renderLocalLeads();},
 onContinue:continueTaskCollection,
 onOpenAccount(session){if(session!==activeCollection?.session)return;renderPage('devices');void refreshDevices().then(()=>canReadDeviceData()?refreshTasks():undefined).catch(handle);}
});
enterpriseWorkspace=createEnterpriseWorkspace({execute,cloud,getState:()=>state,getUser:()=>cloud.user,held:publicRepliesHeld,collectionHeld:continuousActionsHeld,onError:handle,onPage:renderPage,pageVersion:()=>pageGeneration,onCustomerRecord:async key=>{if(!config.localWorkspace)return;renderPage('customers');const generation=pageGeneration,principal=customerPrincipalSignature(cloud.user),current=()=>generation===pageGeneration&&principal===customerPrincipalSignature(cloud.user)&&$('workspace').dataset.page==='customers';await customerWorkspace.load();if(!current())return;await customerWorkspace.open(key);if(!current())return;},onWorkspaceAccounts(accounts){state.accounts=accounts;updateTaskPrerequisite();},localWorkspace:config.localWorkspace,beforeStart:(accountId,action)=>confirmContinuousDevice(state.selected,state.deviceGeneration,accountId,action)});
// The customer UI uses getUser().username only as its in-flight read scope.
customerWorkspace=createCustomerWorkspace({root:$('page-customers'),execute,cloud,getUser:()=>cloud.user?{username:customerPrincipalSignature(cloud.user)}:null,localWorkspace:config.localWorkspace,onError:handle,onComment:lead=>{void enterpriseWorkspace.openLead(lead).catch(handle);}});
if(config.localWorkspace)platformAccount=createPlatformAccount({root:$('page-devices'),onOpenCollection(){renderPage('tasks');void refreshTasks().catch(handle);},onAccountsChanged(accounts){
 accountSnapshotKnown=true;state.accounts=accounts;
 const select=$('task-account'),previous=select.value,ready=accounts.filter(account=>account.platform==='xiaohongshu'&&account.status==='ready');
 select.replaceChildren(new Option('请选择已登录的平台账号',''));
 for(const account of ready)select.append(new Option(`${account.platform_nickname||account.name||'小红书账号'} · 小红书`,account.id));
 select.value=ready.some(account=>account.id===previous)?previous:ready.length===1?ready[0].id:'';
 updateTaskPrerequisite();enterpriseWorkspace?.syncSnapshot({accounts:state.accounts,tasks:state.tasks});
},async checkAccount(accountId){
 const job=await execute('account_status',{account_id:accountId});
 if(job?.status!=='succeeded')throw Error(job?.error||'连接检查未确认，请刷新状态，暂勿重复提交。');
 return job.result;
}});
showLoggedIn();
if(config.localWorkspace)void initDesktopSession();





