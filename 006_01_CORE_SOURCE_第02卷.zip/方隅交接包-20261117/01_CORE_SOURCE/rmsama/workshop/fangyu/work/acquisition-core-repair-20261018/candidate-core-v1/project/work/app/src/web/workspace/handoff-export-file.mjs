/* Literal local file export: the browser never treats a file as a delivery ACK. */
const TYPES = Object.freeze({xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', csv: 'text/csv;charset=utf-8'});
export async function handoffExportFile(result, {format, mode, limit=1000}) {
  const mime = TYPES[format], filename = `交接核对清单_不含联系方式.${format}`;
  if (!mime || !['delivery', 'audit'].includes(mode) || !Number.isSafeInteger(limit) || limit < 1 || limit > 1000 ||
      !result || result.filename !== filename ||
      result.mime_type !== mime || result.encoding !== 'base64' || result.mode !== mode ||
      result.local_only !== true || result.contains_contact_plaintext !== false ||
      result.cross_machine_verified !== false || result.delivery_confirmed !== false ||
      !Number.isSafeInteger(result.rows) || result.rows < 0 || result.rows > limit ||
      !Number.isSafeInteger(result.total_in_scope) || result.total_in_scope < result.rows ||
      result.has_more !== (result.total_in_scope > result.rows) ||
      typeof result.sha256 !== 'string' || !/^[a-f0-9]{64}$/.test(result.sha256) ||
      typeof result.content_base64 !== 'string' || result.content_base64.length > Math.ceil(8 * 1024 * 1024 / 3) * 4 ||
      result.content_base64.length % 4 !== 0 || /[^A-Za-z0-9+/=]/.test(result.content_base64)) {
    throw Error('导出文件、范围或核对信息不完整，尚未下载，请重新读取。');
  }
  const padding=result.content_base64.indexOf('=');
  if(padding>=0&&!['=','=='].includes(result.content_base64.slice(padding)))
    throw Error('导出文件编码需核对，尚未下载，请重新读取。');
  const bytes = Uint8Array.from(atob(result.content_base64), char => char.charCodeAt(0));
  if (!bytes.length || bytes.length > 8 * 1024 * 1024) throw Error('导出文件大小需核对，请缩小本批范围。');
  const digest = Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', bytes)), value => value.toString(16).padStart(2, '0')).join('');
  if (digest !== result.sha256) throw Error('导出文件内容核对失败，尚未下载，请重新读取。');
  return {blob: new Blob([bytes], {type: mime}), filename, rows: result.rows, hasMore: result.has_more};
}
