from pathlib import Path
import json,datetime,hashlib
W=Path(__file__).resolve().parent;P=W.parents[1];H=P/'work/overnight-integration/continuation-20261018'
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n','utf-8')
p=json.loads((W/'PROGRESS.json').read_text('utf-8'));p.update(at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
 status='ACTIVE_V4_GUI_AND_ENTRY_ACCEPTANCE',candidate='candidate-core-v4',release='ui-r57-20261018T020223Z-45516587',
 pins_sha256='50d1c122066e742cf2a52a7c2ddea72f4398bb42563e7ed52f752f18a0f93ec5',
 core_integration='CORE-AI-RENTAL-1000-RESULT.json: 1000/50pages/actualCore+Rental+AI attempts all validated, next page after both saved; fake platform/provider, no real admission; final nine sources stable',
 assessment_lock='Real v2 GUI exposed transaction second-connection account read lock; Core optional db and rental same-tx auth fixed. 1000real local writes2.55s +same-tx owner/tenant/delete refusals GREEN; RENTAL-ACCOUNT-1000-GREEN.json',
 gui_findings='v3 native rendered1000 counts+saved images but Reply gateway rejected audience; fixed backend whitelist+recent-prospects. PROSPECT-GATEWAY2+independent3 GREEN. No early GUI success claimed.',
 gui_state='v4 native fixture currently starting exec session93708; wait READY/public latest, then browser coreTab exists but points stopped v3URL. Need goto new observed URL. Original real window49485052 untouched.',
 previous_gui_runs='v2 8833...exit1 locked; v3 78ed...exit1 QAwebview auditNUL; v3 c171...ownSTOP exit0 after Reply bug. Launch preinitializes installedwebview before unchanged audit, no Fence loosened.',
 current_reviews='CORE-CANDIDATE-V3-REVIEW done0findings; media final38 distinct GREEN; v4 closure agent in progress',
 quota_remaining_percent=84,
 remaining=['finish v4 changed-scope native+browser GUI/media/customer/rules/account navigation','save GUI-RESULT status PASS_CHANGED_SCOPE_GUI only after actual observation; candidate release exact','run adapt_entry_tools.py(v4), new prepare with GUI gate and fresh CAS old hashes; candidate launcher --check; independent entry review; install only reviewed two files','canonical --check, preserve original running window, stop only own QA and close own browser; honest delivery / final checkpoint'])
write(W/'PROGRESS.json',p)
(H/'NEXT.md').write_text('''# 本轮最新：v4原生/浏览器验收与原入口交付未完成
W=work/acquisition-core-repair-20261018。先读W/PROGRESS.json，优先于旧checkpoint脚本/旧总控。不运行旧refresh_checkpoint.py或checkpoint.py覆盖最新进度，不读29.7MB聊天。

核心已修：XHS无10页/60秒/3空新增人为终止；每页固定IDs/journal→实际本地assessment→原AIworkflow/attempt落库后再翻页；旧明确当前任务恢复补分析、未知费用不重提。完整1000/50页Core+Rental+AI合成外部callback集成55.59s通过，下一页前均校验双保存；不是实平台/付费验收。真实1000本地写库另发现跨连接账号检查锁冲突，Core/rental同事务db修复并有同事务owner/tenant/delete拒绝证据，保持原auth。

当前最终candidate-core-v4 release ui-r57-20261018T020223Z-45516587，全2216pins/245parents/117frozen和原validators22已通过。v3原生页曾显示1000与示意头像；真UI查出audience字段漏传，现已补gateway与recent仅prospects，2+3新focused通过。媒体/导航/规则38不同focused均过。v4独立closure复审在进行；原生产入口尚employee-simple-flow旧版，尚未安装本轮，不冒称原窗口已更新。

GUI：W/gui-fixture launch已root用--source --project-root v4 --native启动，exec session93708，等READY（1000seed约1min）。读取LATEST得到准确新URL/instance，cua coreTab仍指向已停v3URL，goto新观察URL；Sky从list_apps唯一去重title“方隅工作台 · 本轮隔离验收”取窗。原真实window49485052不可关闭/登录/采集。假fixture-operator/fixture-password-123公开合成凭据；serverstandin禁止真实采集。查看avatar/cover、回复900排掉100供给方、完整评论/右栏源帖、客户、账号同级切回、管理实际词/排除/标准/保存。本轮真实GUI通过再写W/GUI-RESULT.json的PASS_CHANGED_SCOPE_GUI/browser_verified/isolated_native_verified/release/zero real+paid，这才准入口prepare。

后续：run adapt_entry_tools.py（已改v4，复制仅原binding声明非DB/vault）、entry/prepare_canonical_delegation.py，复用fresh expected-old/new CAS且新GUI gate，先candidate launcher --check和独立review再install --install。仅原launcher+FROZEN两文件，原state/resolver/company/旧90a/CLI/旧完整载体保留；不得伪造pins/原位patch冻结载体/清目录。安装后--check；保留原运行旧窗口，声明下次正常打开新版，不偷偷重启。完成关闭自己的QA(精确instanceSTOP等CLOSED+cloudexit0)与自己tab，保存诚实交付。

本人授权并行者只读+W测试，root唯一产品作者。不要重复旧无关GUI/导出/CLI查询或重编CLI；禁真实外发/付费AI验收/别的客户聊天/扩大设备角色云权。原component-use pending、生产新云规则未激活、真实verification_required未重放、许可原件缺口继续保留；缺认证不问不找不代扫码。总控合并曾自动拒绝无理由，勿换工具路径重试，仅本轮独立证据。
准确截止2026-10-18 21:36:54 Asia/Shanghai；最近周窗剩84%，secondary未知不重测、不用reset。<=1%保存停并尝试PAUSED心跳；automation12曾NOT_FOUND不新建不冒称有效。完成/截止诚实收口不归档/不关原真实窗口。
''','utf-8')
b=json.loads((H/'BATCH-RESULT.json').read_text('utf-8-sig'));b.update(status=p['status'],checkpoint_at_utc=p['at_utc'],core_repair=p);write(H/'BATCH-RESULT.json',b)
hp=json.loads((H/'UNIFIED-CHECKPOINT-PINS.json').read_text('utf-8-sig'))
for n in ('NEXT.md','BATCH-RESULT.json'):hp[n]=hashlib.sha256((H/n).read_bytes()).hexdigest()
write(H/'UNIFIED-CHECKPOINT-PINS.json',hp)
print('v4 exact active checkpoint saved.')
