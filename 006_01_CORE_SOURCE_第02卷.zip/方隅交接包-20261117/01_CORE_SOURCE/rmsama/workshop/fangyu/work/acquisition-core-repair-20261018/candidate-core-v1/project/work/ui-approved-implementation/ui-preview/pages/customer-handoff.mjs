import {escape as esc,actorMatches,customerControls} from './customers-data.mjs';
const scope=state=>JSON.stringify([state.user,state.storeId]);
const snapshot=value=>`<h3>${esc(value?.name||'客户昵称未记录')}</h3><p>${esc(value?.need||'需求尚未整理')}</p><blockquote style="white-space:pre-wrap;overflow-wrap:anywhere">${esc(value?.quote||'原评论未记录')}</blockquote><p>来源：${esc(value?.channel)} · ${esc(value?.postTitle)}</p><p>${esc(value?.postUrl)}</p>`;
function owns(ctx,h){return ctx.state.customerHandoff===h&&scope(ctx.state)===h.scope&&ctx.state.page==='customers'&&customerControls(ctx.state).selectedId===h.id&&!h.closed&&h.dialog?.open!==false&&h.modalOwner===h.dialog?.__modalOwner;}
function historyHtml(rows){return rows.length?rows.map(r=>`<section class="cs-record-line"><h3>第 ${r.version} 版 · ${esc(r.author)} · ${esc(r.createdAt)}</h3><p>整理时门店：${esc(r.storeContext?.id)}</p>${snapshot(r.snapshot)}<p style="white-space:pre-wrap;overflow-wrap:anywhere">内部备注：${esc(r.note||'未填写')}</p><p style="white-space:pre-wrap;overflow-wrap:anywhere">下一步：${esc(r.nextStep||'未填写')}</p></section>`).join(''):'<p>尚未保存内部交接记录。</p>';}
function show(ctx,h){
  if(ctx.state.customerHandoff!==h||scope(ctx.state)!==h.scope||customerControls(ctx.state).selectedId!==h.id||h.closed)return;
  const view=h.view,locked=h.busy||Boolean(h.pending),history=h.historyOnly;
  const html=`<div class="cs-handoff-preview" style="max-height:55vh;overflow:auto;overflow-wrap:anywhere"><p role="status" data-handoff-message>${esc(h.message||'')}</p>${view?`<p>当前门店：${esc(view.storeContext?.id)} · ${esc(view.storeContext?.meaning)}</p>${history?historyHtml(view.history):`${snapshot(view.snapshot)}<p>当前交接版本：${view.version}。内部整理不会修改联系或发送状态。</p>${view.latest?`<p>最近整理：${esc(view.latest.author)} · ${esc(view.latest.createdAt)}</p>`:''}<label for="cs-handoff-note">内部交接备注</label><textarea id="cs-handoff-note" maxlength="4000" rows="4" ${locked?'readonly':''}>${esc(h.note)}</textarea><label for="cs-handoff-next">下一步</label><textarea id="cs-handoff-next" maxlength="1000" rows="2" ${locked?'readonly':''}>${esc(h.nextStep)}</textarea>${h.pending?'<p>上次保存结果未确认。输入已保留，请只核对原操作，不要重复保存。</p>':''}${view.latest&&h.superseded?`<p>另一窗口已有更新的交接记录，以下为当前保存内容；请核对后决定是否再次保存。</p><p>${esc(view.latest.note)}</p><p>${esc(view.latest.nextStep)}</p>`:''}<button type="button" class="cs-secondary" data-handoff-reload ${locked?'disabled':''}>读取当前记录并保留输入</button><button type="button" class="cs-secondary" data-handoff-discard ${locked?'disabled':''}>放弃本次未保存输入并关闭</button>`}`:'<p>正在核对当前员工、门店与客户…</p>'}</div>`;
  const dialog=ctx.modal({title:history?'交接记录':'整理内部交接',html,confirmLabel:h.pending?'核对上次保存':h.busy?'正在保存…':'保存交接',
    canClose:()=>{if(!owns(ctx,h))return true;if(h.busy||h.pending||h.dirty){ctx.toast('输入已保留，请先核对保存结果，或明确放弃未保存输入。');return false;}return true;},
    onConfirm:view&&!history?async()=>{if(!owns(ctx,h)||h.busy)return false;capture(h);if(h.pending)await read(ctx,h);else await save(ctx,h);return false;}:undefined});
  h.dialog=dialog;h.modalOwner=dialog?.__modalOwner;
  if(!h.closeBound){h.closeBound=true;dialog?.addEventListener?.('close',()=>{h.closed=true;if(ctx.state.customerHandoff===h&&scope(ctx.state)===h.scope&&ctx.state.page==='customers'&&customerControls(ctx.state).selectedId===h.id)globalThis.document?.querySelector(h.historyOnly?'[data-customer-history]':'[data-customer-handoff]')?.focus();},{once:true});}
  if(!history){
    for(const [key,selector] of [['note','#cs-handoff-note'],['nextStep','#cs-handoff-next']]){const input=dialog?.querySelector(selector);if(input){input.value=h[key];input.addEventListener('input',()=>{if(!owns(ctx,h)||h.busy||h.pending)return;h[key]=input.value;h.dirty=true;});}}
    dialog?.querySelector('[data-handoff-reload]')?.addEventListener('click',()=>{if(owns(ctx,h)&&!h.busy&&!h.pending){capture(h);read(ctx,h);}});
    dialog?.querySelector('[data-handoff-discard]')?.addEventListener('click',()=>{if(owns(ctx,h)&&!h.busy&&!h.pending){h.dirty=false;h.closed=true;dialog.close();}});
  }
  const confirm=dialog?.querySelector('.modal-confirm');if(confirm)confirm.disabled=h.busy;
}
function capture(h){if(h.pending||h.busy)return;for(const [key,selector] of [['note','#cs-handoff-note'],['nextStep','#cs-handoff-next']]){const input=h.dialog?.querySelector(selector);if(input&&input.value!==h[key]){h[key]=input.value;h.dirty=true;}}}
function accept(ctx,h,result,initial=false){
  const value=result?.handoff;
  if(!actorMatches(ctx.state,value)||value.id!==h.id)throw new Error('交接回执的员工、门店或客户不一致。');
  h.view=value;
  if(initial&&!h.dirty&&!h.pending){h.note=value.latest?.note||'';h.nextStep=value.latest?.nextStep||'';}
}
async function read(ctx,h,initial=false){
  if(h.busy)return;h.busy=true;const requestId=h.pending?.requestId;h.message=requestId?'正在核对原保存操作…':'正在读取当前交接记录…';show(ctx,h);
  try{
    const result=await ctx.actions.handoffAction('read',{storeId:ctx.state.storeId,id:h.id,...(requestId?{requestId}:{})});
    if(!owns(ctx,h))return;accept(ctx,h,result,initial);
    if(requestId){
      if(result.handoff.receipt?.requestId!==requestId||!['accepted','not_found'].includes(result.handoff.receipt.state))throw new Error('未取得原保存操作的明确回执，请保留输入继续核对。');
      h.pending=null;h.superseded=result.handoff.receipt.state==='accepted'&&result.handoff.version>result.handoff.receipt.version;
      h.dirty=result.handoff.receipt.state==='not_found'||h.superseded;
      h.message=result.handoff.receipt.state==='accepted'?'已核对：原操作已保存；不会重复保存。':'已核对：原操作未落盘。输入已保留，可核对后手动保存。';
      ctx.actions.loadCustomers?.();
    }else h.message='已读取真实内部记录。历史来源门店不作推断。';
  }catch(error){if(owns(ctx,h)){h.message=error.message;ctx.actions.replyError?.(error);}}
  finally{if(ctx.state.customerHandoff===h){h.busy=false;if(owns(ctx,h))show(ctx,h);}}
}
async function save(ctx,h){
  if(!h.view||h.pending||h.busy)return;
  if(!h.note.trim()&&!h.nextStep.trim()){h.message='请填写内部备注或下一步。';show(ctx,h);return;}
  const data={storeId:ctx.state.storeId,id:h.id,expectedVersion:h.view.version,sourceDigest:h.view.sourceDigest,note:h.note,nextStep:h.nextStep,requestId:crypto.randomUUID()};
  h.pending=data;h.busy=true;h.message='正在保存内部交接…';show(ctx,h);
  try{
    const result=await ctx.actions.handoffAction('save',data);if(!owns(ctx,h))return;accept(ctx,h,result);
    h.pending=null;h.dirty=false;h.message='内部交接已保存，未修改回复或发送状态。';ctx.actions.loadCustomers?.();
  }catch(error){if(owns(ctx,h)){if(!['RESULT_UNCONFIRMED','HANDOFF_RESULT_UNCONFIRMED'].includes(error.code))h.pending=null;h.message=error.message;ctx.actions.replyError?.(error);}}
  finally{if(ctx.state.customerHandoff===h){h.busy=false;if(owns(ctx,h))show(ctx,h);}}
}
export function openHandoff(ctx,id,historyOnly=false){
  const prior=ctx.state.customerHandoff;
  if(prior&&prior.scope===scope(ctx.state)&&(prior.dirty||prior.pending||prior.busy)&&!prior.closed){
    if(prior.id!==id||historyOnly){ctx.toast('请先处理原客户未保存或待核对的内部交接。');return;}
    show(ctx,prior);return;
  }
  const h={id,scope:scope(ctx.state),historyOnly,view:null,note:'',nextStep:'',dirty:false,pending:null,busy:false,closed:false,message:''};
  ctx.state.customerHandoff=h;show(ctx,h);read(ctx,h,true);
}
