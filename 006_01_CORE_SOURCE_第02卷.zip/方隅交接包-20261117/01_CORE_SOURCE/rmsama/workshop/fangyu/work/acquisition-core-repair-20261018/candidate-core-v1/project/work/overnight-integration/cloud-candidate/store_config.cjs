'use strict';
// Pure reads from the existing private collection. Never runs workspace housekeeping.
const crypto=require('node:crypto');
const SCHEMA='store-config-v1';
const COMPANY='fangyu-apartment-client';
const canonical=v=>Array.isArray(v)?'['+v.map(canonical).join(',')+']':v&&typeof v==='object'?'{'+Object.keys(v).sort().filter(k=>v[k]!==undefined).map(k=>JSON.stringify(k)+':'+canonical(v[k])).join(',')+'}':JSON.stringify(v);
const hash=v=>crypto.createHash('sha256').update(typeof v==='string'||Buffer.isBuffer(v)?v:canonical(v)).digest('hex');
const manifestId=company=>'scfg_manifest_'+hash(company).slice(0,32);
const versionId=(company,revision,storeId)=>'scfg_version_'+hash([company,revision,storeId]);
const sourceId=(company,revision)=>'scfg_source_'+hash([company,revision]);
class ConfigError extends Error{constructor(code,status=503){super(code);this.code=code;this.status=status;}}
const fail=(code,status)=>{throw new ConfigError(code,status);};
function authority(state,bearer,company,now){
 if(!state||state.companyId!==company||!Array.isArray(state.users)||!Array.isArray(state.sessions))fail('STORE_CONFIG_AUTH_REQUIRED',401);
 if(typeof bearer!=='string'||!bearer||bearer.length>65536)fail('STORE_CONFIG_AUTH_REQUIRED',401);
 const sessions=state.sessions.filter(s=>s&&s.digest===hash(bearer)&&s.expires>now);
 if(sessions.length!==1)fail('STORE_CONFIG_AUTH_REQUIRED',401);
 const session=sessions[0],users=state.users.filter(u=>u&&u.username===session.username&&!u.disabled);
 if(users.length!==1||!['admin','operator'].includes(users[0].role))fail('STORE_CONFIG_AUTH_REQUIRED',401);
 const user=users[0];
 const grants=user.role==='admin'?null:(typeof user.store_id==='string'&&/^[A-Za-z0-9_-]{1,80}$/.test(user.store_id)?[user.store_id]:[]);
 return {user,grants,fingerprint:hash({username:user.username,role:user.role,disabled:!!user.disabled,
  grants,sessionDigest:session.digest,expires:session.expires})};
}
function validateManifest(row,company){
 if(!row||row.disabled===true||row.doc_type!=='store_config_manifest'||row.schema!==SCHEMA||row.companyId!==company
  ||typeof row.active_revision!=='string'||!/^[a-f0-9]{64}$/.test(row.catalog_digest||'')
  ||!Array.isArray(row.stores)||new Set(row.stores.map(r=>r.id)).size!==row.stores.length
  ||row.stores.some(r=>!/^fy_s_[a-f0-9]{24}$/.test(r.id)||!/^[a-f0-9]{64}$/.test(r.config_digest||'')))fail('STORE_CONFIG_UNAVAILABLE');
 return row;
}
function createStoreConfigRead({store,companyId,environmentId,clock=Date.now}){
 return async function read(payload,bearer){
  const flags={schema:SCHEMA,read_only:true,mutation_committed:false,auto_retry:false};
  try{
   if(companyId!==COMPANY||payload.environment_id!==environmentId||Object.keys(payload).some(k=>!['environment_id','operation','store_id','known_digest'].includes(k))
    ||payload.operation!=='store_config_read'||payload.store_id!==undefined&&!/^fy_s_[a-f0-9]{24}$/.test(payload.store_id)
    ||payload.known_digest!==undefined&&!/^[a-f0-9]{64}$/.test(payload.known_digest))fail('STORE_CONFIG_REQUEST_INVALID',400);
   if(typeof store.readStoreConfigState!=='function'||typeof store.readStoreConfigDocument!=='function')fail('STORE_CONFIG_UNAVAILABLE');
   const first=authority(await store.readStoreConfigState(),bearer,companyId,Math.floor(clock()/1000));
   const manifest=validateManifest(await store.readStoreConfigDocument(manifestId(companyId)),companyId);
   const allowed=manifest.stores.filter(row=>first.grants===null||first.grants.includes(row.id));
   if(first.grants!==null&&!allowed.length)fail('STORE_SCOPE_REQUIRED',403);
   let config;
   if(payload.store_id){
    const entry=allowed.find(row=>row.id===payload.store_id);if(!entry)fail('STORE_FORBIDDEN',403);
    const row=await store.readStoreConfigDocument(versionId(companyId,manifest.active_revision,entry.id));
    if(!row||row.companyId!==companyId||row.doc_type!=='store_config_version'||row.revision!==manifest.active_revision
     ||row.store_id!==entry.id||hash(row.config)!==entry.config_digest||row.config?.schema!==SCHEMA
     ||row.config.store_id!==entry.id||row.config.material_key!==entry.materialKey)fail('STORE_CONFIG_UNAVAILABLE');
    config=row.config;
   }
   // Both the authority and active directory must still be the same after data reads.
   const last=authority(await store.readStoreConfigState(),bearer,companyId,Math.floor(clock()/1000));
   if(last.fingerprint!==first.fingerprint)fail('STORE_AUTHORITY_CHANGED',403);
   const latest=validateManifest(await store.readStoreConfigDocument(manifestId(companyId)),companyId);
   if(latest.catalog_digest!==manifest.catalog_digest||latest.active_revision!==manifest.active_revision)fail('STORE_CONFIG_CHANGED',409);
   return {status:200,data:{...flags,catalog_revision:manifest.active_revision,catalog_digest:manifest.catalog_digest,
    source_versions:manifest.source_versions,counts:manifest.counts,
    actor:{username:last.user.username,role:last.user.role},
    scope:{type:last.user.role==='admin'?'company':'store',store_ids:allowed.map(row=>row.id),grant_revision:last.fingerprint,issued_at:Math.floor(clock()/1000)},
    stores:allowed,...(config?{store_id:payload.store_id,config_digest:hash(config),config}:{}),
    not_modified:!!payload.known_digest&&payload.known_digest===(config?hash(config):manifest.catalog_digest)}};
  }catch(error){return {status:error instanceof ConfigError?error.status:503,data:{...flags,
   code:error instanceof ConfigError?error.code:'STORE_CONFIG_UNAVAILABLE',stores:[]}};}
 };
}
module.exports={SCHEMA,COMPANY,canonical,hash,manifestId,versionId,sourceId,authority,createStoreConfigRead};
