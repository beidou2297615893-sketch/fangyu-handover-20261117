"""Offline integration of real r55 ingestion/AI with the Runtime page journal.

Only synthetic temporary Core data, adapter search/comments, cloud callback, and
explicit Runtime customer/device admission seams are used. No AppServer, real
customer configuration, platform login, CLI, credential, or network is used.
This does not certify customer/platform permissions, provider availability,
pricing, real billing idempotency, local rental assessment, or native UI.
With --with-rental, the actual same-tenant rental service is included per page;
customer/device admission, real IO, and native UI remain unverified.
"""
from contextlib import ExitStack
from copy import deepcopy
from datetime import datetime
import argparse
import hashlib
import json
from pathlib import Path
import socket
import subprocess
import sys
import tempfile
import threading
import time
import traceback
import types
import unittest
from unittest.mock import patch

W = Path(__file__).resolve().parent
P = W.parents[1]
R55 = P / 'work/ui-runtime-r55/src'
sys.path.insert(0, str(R55))
sys.path.insert(0, str(P / 'work/shared-backend-integration'))
from core import Core, CoreError
from core.engine import collect_batch
from assistant.ai_workflow import LocalAIWorkflow
from assistant.ai_attempts import LocalAIAttempts
from assistant.business import BusinessExecutor
from platform_runtime import (PlatformRuntime, _COLLECTION_RUN_ENTITY,
                              _COLLECTION_ANALYSIS_ENTITY)

SOURCE_PATHS = [
    'work/ui-runtime-r55/src/core/engine.py',
    'work/ui-runtime-r55/src/core/pipeline.py',
    'work/ui-runtime-r55/src/core/store.py',
    'work/ui-runtime-r55/src/core/adapters.py',
    'work/ui-runtime-r55/src/assistant/ai_workflow.py',
    'work/ui-runtime-r55/src/assistant/ai_attempts.py',
    'work/ui-runtime-r55/src/assistant/business.py',
    'work/shared-backend-integration/platform_runtime.py',
    'work/ui-native-r57/rental_assessment.py',
]


def hashes():
    return {name: hashlib.sha256((P / name).read_bytes()).hexdigest() for name in SOURCE_PATHS}


class CoreAIIntegration(unittest.TestCase):
    count = 120
    with_rental = False
    evidence = {}

    def test_real_core_and_ai_complete_before_every_next_page(self):
        count = self.count
        self.assertIn(count, (120, 1000))
        start = time.monotonic()
        before_hashes = hashes()
        with ExitStack() as stack:
            # External IO is forbidden even if a fixture boundary is accidentally missed.
            def forbidden(*args, **kwargs):
                raise AssertionError('Real network/process IO is forbidden in this synthetic integration')
            stack.enter_context(patch.object(socket.socket, 'connect', forbidden))
            stack.enter_context(patch.object(socket, 'create_connection', forbidden))
            stack.enter_context(patch.object(subprocess, 'Popen', forbidden))
            directory = Path(stack.enter_context(tempfile.TemporaryDirectory(prefix='core-ai-owned-', dir=W)))
            self.assertEqual(directory.parent, W)
            core = Core(directory)
            stack.callback(core.adapters.close)
            actor = core.handle('bootstrap', {'username': 'synthetic-integration-owner',
                                               'password': '[REDACTED:assigned_secret]'})['user']
            synthetic_user = core.store.get('users', actor['id'])
            synthetic_user['cloud_bound'] = True
            rental_company = {'id': 'fangyu-apartment-client', 'edition': 'customer',
                'personalMode': False, 'authMode': 'managed',
                'managedWorkspace': {'environment_id': 'synthetic-core-ai-rental-fixture'}}
            if self.with_rental:
                tenant_id = 'cloud-' + hashlib.sha256((
                    rental_company['managedWorkspace']['environment_id'] + '\n' +
                    rental_company['id']).encode()).hexdigest()[:24]
                synthetic_tenant = core.store.get('tenants', actor['tenant_id'])
                synthetic_tenant.update(id=tenant_id, tenant_id=tenant_id)
                core.store.put('tenants', synthetic_tenant)
                synthetic_user['tenant_id'] = tenant_id
            core.store.put('users', synthetic_user)
            actor = core._public(synthetic_user)
            account = core.handle('save', {'entity': 'accounts', 'record': {
                'name': 'Synthetic adapter account', 'platform': 'xiaohongshu', 'status': 'ready',
                'cloud_owner': actor['username']}}, actor)
            account.update(store_id='synthetic-store', cloud_owner=actor['username'])
            core.store.put('accounts', account)
            task = core.handle('save', {'entity': 'tasks', 'record': {
                'name': 'Offline real Core and AI', 'platform': 'xiaohongshu',
                'scope': 'search_comments', 'account_id': account['id'],
                'keywords': ['古北租房'], 'comment_keyword_mode': 'all',
                'continuous_enabled': False, 'unknown_policy': 'exclude', 'region': '',
                'city': '上海', 'area': '古北', 'comment_depth': 'main',
                'search_pages': 1, 'daily_limit': 1000, 'target_count': count}}, actor)
            # Fixture-only store ownership metadata; no production company or authority changes.
            task.update(store_id='synthetic-store', cloud_owner=actor['username'])
            core.store.put('tasks', task)
            actor = {**actor, '_workbench_store_id': task['store_id']}
            tenant = actor['tenant_id']
            events, cursors, requests, profile_calls, core_calls = [], [], [], [], []
            previous_page = []
            page_count = count // 20
            synthetic_url = 'https://www.xiaohongshu.com/explore/abcdef0123456789abcdef01'

            def cloud(user, operation, data):
                self.assertEqual(user['id'], actor['id'])
                self.assertEqual(user['tenant_id'], tenant)
                if operation == 'ai_profile':
                    profile_calls.append(operation)
                    return {'config': {'provider': 'deepseek', 'model': 'deepseek-flash',
                            'enabled': True, 'configured': True, 'revision': 1,
                            'rules_version': 'synthetic-contract-v1'}}
                self.assertEqual(operation, 'intent_analyze', 'Only synthetic AI operations are implemented')
                self.assertGreater(len(data['comments']), 0)
                self.assertLessEqual(len(data['comments']), 20)
                self.assertEqual(data['expected_revision'], 1)
                self.assertEqual(data['expected_rules_version'], 'synthetic-contract-v1')
                self.assertTrue(data.get('request_id'))
                self.assertTrue(data.get('submission_id'))
                self.assertNotIn(data['request_id'], [row['request_id'] for row in requests])
                requests.append({'request_id': data['request_id'],
                                 'submission_id': data['submission_id'],
                                 'comments': len(data['comments'])})
                events.append('fake_ai:' + str(len(requests)))
                return {'rules_version': 'synthetic-contract-v1',
                        'provider': 'deepseek', 'model': 'deepseek-flash',
                        'results': [{'id': row['id'], 'status': 'graded', 'level': 'high',
                            'reason': '合成求租评论，具有本人预算证据', 'evidence': ['预算3500'],
                            'region_status': 'unknown', 'content_region': '',
                            'key_info': [{'type': 'budget', 'value': '3500', 'evidence': '预算3500'}]}
                            for row in data['comments']]}

            workflow = LocalAIWorkflow(core, cloud, company={}, host_context=lambda: {
                'environment_id': 'synthetic-environment', 'company_id': 'synthetic-company',
                'owner': actor['username'], 'device': {'id': 'synthetic-device', 'owner': actor['username']}})
            self.assertIsInstance(workflow.attempts, LocalAIAttempts)
            # Reuse actual r55 task/owner lead visibility; bypass its command/device constructor only.
            executor = object.__new__(BusinessExecutor)
            executor.core, executor.tenant, executor.owner = core, tenant, actor['username']
            executor.user_id, executor.ai = actor['id'], workflow
            runtime = object.__new__(PlatformRuntime)
            runtime.core, runtime.closed = core, False
            runtime._run_lock, runtime._run_cancels = threading.RLock(), {}
            runtime.service = types.SimpleNamespace(executor=executor, state='online', closed=False)

            def fixture_principal(user):
                # This explicit local seam is NOT real customer/cloud authentication.
                saved = core.store.get('users', user.get('id'))
                self.assertIsNotNone(saved)
                self.assertFalse(saved.get('disabled'))
                for field in ('id', 'tenant_id', 'username', 'role', 'cloud_bound'):
                    self.assertEqual(saved.get(field), user.get(field))
                return {**core._public(saved), '_workbench_store_id': user['_workbench_store_id']}

            def fixture_executor(user, **kwargs):
                current = fixture_principal(user)
                self.assertEqual(current['id'], executor.user_id)
                self.assertEqual(current['username'], executor.owner)
                self.assertEqual(current['tenant_id'], executor.tenant)
                return executor

            runtime._principal, runtime._executor = fixture_principal, fixture_executor
            runtime._collection_readiness = lambda user, account: ('', '')
            rental_summaries = []
            if self.with_rental:
                # The real service shares the Core/task/account/SQLite transaction.
                sys.path.insert(0, str(P / 'work/ui-native-r57'))
                from rental_assessment import RentalAssessmentService, RULE_VERSION
                rental_service = RentalAssessmentService(core, rental_company,
                    store_id=task['store_id'], rule_version=RULE_VERSION)
                def assess_saved_page(user, ident):
                    result = rental_service.assess_task(user, ident)
                    rental_summaries.append(deepcopy(result))
                    return result
                runtime._rental_after_import = assess_saved_page
                core.store.put('rental_task_context_v1', {'id': task['id'],
                    'tenant_id': tenant, 'owner': actor['username'], 'enabled': True,
                    'store_id': task['store_id'], 'rule_version': RULE_VERSION})
            # Actual Runtime _task/_account/current policy/binding/journal/helper are retained.
            self.assertTrue(runtime._current_comment_policy(task))
            self.assertIsNotNone(runtime._collection_binding(task))
            self.assertEqual(core.deployment_config, {}, 'No customer guard or use constant is patched')

            def search(platform, query):
                self.assertEqual(platform, 'xiaohongshu')
                self.assertEqual(query['keywords'], ['古北租房'])
                self.assertEqual(query['next_page'], 1)
                events.append('fake_search')
                query['_page_info'] = {'has_more': False}
                return [{'url': synthetic_url, 'title': '古北租房合成讨论',
                         'author': 'Synthetic post author', 'author_id': 'synthetic-post-owner'}]

            def comments(platform, query):
                page = len(cursors)
                self.assertLess(page, page_count, 'No platform read beyond the true task target')
                expected = '' if page == 0 else f'synthetic-cursor-{page}'
                self.assertEqual(query.get('next_cursor', ''), expected)
                self.assertNotIn(expected, cursors, 'A saved cursor must never be replayed')
                self.assertEqual(query['note_url'], synthetic_url)
                # Critical ordering assertion is at the next actual adapter read boundary.
                for ident in previous_page:
                    saved = core.store.get('leads', ident)
                    self.assertIsInstance(saved.get('ai_intent'), dict)
                    self.assertIn(saved['ai_intent']['status'], ('graded', 'uncertain', 'unrelated'))
                if self.with_rental:
                    assessed_ids = {row['lead_id'] for row in core.store.list('rental_assessments_v1', tenant)}
                    self.assertTrue(set(previous_page).issubset(assessed_ids),
                                    'Real rental callback must finish before another adapter page')
                existing = core.store.list('leads', tenant)
                self.assertEqual(len(existing), page * 20)
                self.assertTrue(all(isinstance(row.get('ai_intent'), dict) for row in existing))
                cursors.append(expected)
                events.append('fake_comments:' + str(page + 1))
                more = page + 1 < page_count
                query['_page_info'] = {'has_more': more,
                                      'cursor': f'synthetic-cursor-{page+1}' if more else ''}
                query['_reply_roots'] = []
                return [{'source_id': f'synthetic-comment-{page*20+i}',
                         'comment_id': f'synthetic-comment-{page*20+i}',
                         'author': f'Synthetic renter {page*20+i}',
                         'author_id': f'synthetic-renter-{page*20+i}',
                         'text': f'本人求租一居室，预算3500，周末想约看房。合成编号{page*20+i}',
                         'published_at': datetime.now().date().isoformat()}
                        for i in range(20)]

            core.adapters.search, core.adapters.comments = search, comments

            def execute(selected_executor, user, action, payload):
                self.assertIs(selected_executor, executor)
                self.assertEqual(action, 'task_run')
                self.assertEqual(payload, {'task_id': task['id'], 'max_batches': 1})
                before_ids = {row['id'] for row in core.store.list('leads', tenant)}
                # Actual Core sequence -> _run -> collect_batch -> _import -> SQLite.
                result = core.handle('run_task_sequence', {'id': task['id'], 'max_batches': 1}, user)
                core_calls.append(deepcopy(result))
                current_ids = {row['id'] for row in core.store.list('leads', tenant)}
                previous_page[:] = sorted(current_ids - before_ids)
                self.assertEqual(len(previous_page), 20)
                return result

            runtime._execute = execute
            control = {'event': threading.Event(), 'attempt': 'synthetic-integration-attempt',
                       'binding': runtime._collection_binding(task)}
            runtime._run_cancels[task['id']] = control
            with patch('core.engine.collect_batch', wraps=collect_batch) as observed_collect:
                runtime._bounded_collection(executor, actor, task['id'], control)
                self.assertEqual(observed_collect.call_count, page_count)
            stored = core.store.list('leads', tenant)
            self.assertEqual(len(stored), count)
            self.assertEqual(len({row['source_id'] for row in stored}), count)
            self.assertTrue(all(row.get('task_id') == task['id'] for row in stored))
            self.assertTrue(all(isinstance(row.get('ai_intent'), dict) and
                                row['ai_intent'].get('status') in ('graded', 'uncertain', 'unrelated')
                                for row in stored))
            attempts = core.store.list('ai_attempts', tenant)
            self.assertEqual(len(attempts), page_count)
            self.assertTrue(all(row['state'] == 'validated' for row in attempts))
            self.assertEqual({row['request_id'] for row in attempts}, {row['request_id'] for row in requests})
            self.assertEqual(len(core.store.list('ai_cache', tenant)), count)
            rental_records = core.store.list('rental_assessments_v1', tenant)
            if self.with_rental:
                self.assertEqual(len(rental_summaries), page_count)
                self.assertEqual(len(rental_records), count)
                self.assertEqual(sum(row['written'] for row in rental_summaries), count)
                self.assertEqual(len({row['lead_id'] for row in rental_records}), count)
            self.assertEqual(len(requests), page_count)
            self.assertEqual(sum(row['comments'] for row in requests), count)
            self.assertEqual(len(set(cursors)), page_count)
            receipt = core.store.get(_COLLECTION_RUN_ENTITY, task['id'])
            page_journal = core.store.get(_COLLECTION_ANALYSIS_ENTITY, task['id'])
            self.assertEqual(receipt['status'], 'completed')
            self.assertEqual(receipt['pages'], page_count)
            self.assertEqual(receipt['counts'], {'read': count, 'imported': count, 'filtered': 0, 'duplicates': 0})
            self.assertEqual(page_journal['status'], 'completed')
            self.assertEqual(set(page_journal['lead_ids']), set(previous_page))
            current_task = core.store.get('tasks', task['id'])
            self.assertEqual(current_task['accumulated'], count)
            self.assertEqual(current_task['daily_limit'], 1000)
            self.assertEqual(current_task['target_count'], count)
            self.assertLessEqual(len(stored), current_task['daily_limit'])
            daily_guard_confirmed = False
            if count == 1000:
                before_reads = len(cursors)
                with self.assertRaisesRegex(CoreError, '今天|上限'):
                    core.handle('run_task', {'id': task['id']}, actor)
                self.assertEqual(len(cursors), before_reads)
                daily_guard_confirmed = True
            # Re-entry of the same completed page must not create another fake model request.
            before_requests = len(requests)
            repeated = runtime._analyze_collection_page(executor, actor, task['id'], previous_page)
            self.assertEqual(repeated['status'], 'completed')
            self.assertEqual(len(requests), before_requests)
            self.assertEqual(hashes(), before_hashes, 'Source bytes changed while this integration ran')
            self.evidence.update(status='PASS', count=count, pages=page_count, stored=len(stored),
                analyzed=sum(isinstance(row.get('ai_intent'), dict) for row in stored),
                fake_model_requests=len(requests), maximum_group=max(row['comments'] for row in requests),
                attempts=len(attempts), attempt_states=sorted({row['state'] for row in attempts}),
                cache_rows=len(core.store.list('ai_cache', tenant)), profile_reads=len(profile_calls),
                unique_cursors=len(set(cursors)), daily_limit=1000, target_count=count,
                daily_guard_confirmed=daily_guard_confirmed, duplicate_page_model_requests=0,
                page_journal_status=page_journal['status'], receipt=receipt['counts'],
                source_sha256=before_hashes, seconds=round(time.monotonic()-start, 3),
                real_network_calls=0, real_platform_calls=0, real_cli_executions=0,
                real_provider_calls=0, paid_ai_requested=False,
                with_rental=self.with_rental, rental_callbacks=len(rental_summaries),
                rental_records=len(rental_records),
                admission='Synthetic local bootstrap/admin with synthetic cloud_bound metadata; Runtime customer/device readiness is an explicit fixture seam',
                real_components=['r55 Core', 'collect_batch', 'run_task_sequence', 'SQLite Store',
                                 'r55 BusinessExecutor._analysis_visible_leads', 'LocalAIWorkflow',
                                 'LocalAIAttempts', 'Runtime bounded controller/page journal/page AI helper'],
                external_fakes=['adapter search/comments', 'ai_profile/intent_analyze callback'],
                unverified=['real customer/device/platform admission', 'real provider or billing',
                            *([] if self.with_rental else ['local rental assessment']), 'native UI'])


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--count', type=int, choices=(120, 1000), default=120)
    parser.add_argument('--with-rental', action='store_true', help='Include real same-tenant rental service on every page')
    parser.add_argument('--result', default='CORE-AI-120-RESULT.json')
    args = parser.parse_args()
    result_path = (W / args.result).resolve()
    if result_path.parent != W or result_path.suffix != '.json':
        raise SystemExit('Result must be a named JSON directly in the owned batch')
    CoreAIIntegration.count = args.count
    CoreAIIntegration.with_rental = args.with_rental
    evidence = CoreAIIntegration.evidence
    evidence.update(status='NOT_COMPLETED', count=args.count, source_sha256=hashes())
    outcome = unittest.TextTestRunner(verbosity=2).run(
        unittest.defaultTestLoader.loadTestsFromTestCase(CoreAIIntegration))
    if not outcome.wasSuccessful():
        evidence.update(status='FAIL', failures=outcome.failures, errors=outcome.errors)
    # TestCase objects in failure tuples stringify without touching any private data.
    result_path.write_text(json.dumps(evidence, ensure_ascii=False, indent=2, default=str) + '\n', 'utf-8')
    print(json.dumps({key: value for key, value in evidence.items()
                      if key not in ('source_sha256', 'failures', 'errors')}, ensure_ascii=False))
    raise SystemExit(0 if outcome.wasSuccessful() else 1)
