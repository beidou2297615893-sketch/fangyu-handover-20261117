// Real management-rules render/bind, synthetic approved DTOs; no network or browser.
import assert from 'node:assert/strict';
import {fileURLToPath, pathToFileURL} from 'node:url';
import {dirname, resolve} from 'node:path';

const W = dirname(fileURLToPath(import.meta.url));
const moduleURL = pathToFileURL(resolve(W, '../ui-approved-implementation/ui-preview/pages/management-rules.mjs'));
const {render, bind} = await import(moduleURL.href);
const REVIEW = '2026-10-18.intent-evidence-contract-draft-v4-review2';
const savedCriteria = {
  super_high: '已存超高：明确约看行动条件A', high: '已存高：实际房源询盘条件B',
  medium: '已存中：本人区域了解条件C', low: '已存低：明确远期计划条件D',
  very_low: '已存极低：有本人需求的条件假设E',
};

function fixture(role='admin') {
  const precise=Array.from({length:125},(_,i)=>({id:'P'+i,keyword:'精准真实词'+i}));
  const commute=Array.from({length:4},(_,i)=>({id:'C'+i,keyword:'通勤真实词'+i}));
  const provenance=(word,preset)=>({keywordId:word.id,keyword:word.keyword,materialKey:'material-a',
    sourceRefs:[`source:${preset}:${word.id}`],bindings:[{materialKey:'material-a',presetIds:[preset],
      sourceRefs:[`source:${preset}:${word.id}`],sourceArtifactId:'synthetic-artifact-'+preset,
      sourcePointer:'/keywords/'+word.id,bundleRevision:'bundle-synthetic-v7',runtimeRevision:'search-synthetic-v4'}]});
  const keywords=[...precise.map(w=>({...w,eligible:true,bindings:provenance(w,'precise').bindings})),
    ...commute.map(w=>({...w,eligible:true,bindings:provenance(w,'commute').bindings}))];
  const searchPresets=Object.fromEntries([['precise',precise],['commute',commute]].map(([id,words])=>[id,{
    keywords:words.map(w=>w.keyword),keywordIds:words.map(w=>w.id),sourceBindings:words.map(w=>provenance(w,id))}]));
  const reference={id:'material-a',storeId:'fixture-store-a',bindingConfirmed:true,profileDigest:'synthetic-profile-digest',
    version:'catalog-synthetic-v7',revision:17,digest:'c'.repeat(64)};
  const runtimeAssessment={supported:true,enabled:true,version:'2026-10-17.intent-evidence-contract-draft-v4',
    engineVersion:REVIEW,bundleRevision:'bundle-synthetic-v7',sourceDigest:'d'.repeat(64),currentPricesVerified:false};
  return {connection:'connected',user:'fixture-'+role,session:{user:{username:'fixture-'+role,role}},
    storeId:'fixture-store-a',store:'合成甲店',stores:[{id:'fixture-store-a',name:'合成甲店'}],busy:false,
    capabilities:{presets:true},selection:{storeId:'fixture-store-a',searchPresetId:'precise',intentPresetId:'standard',
      revision:17,savedAt:'2026-10-18T09:30:00Z',applied:{centralVersion:{revision:'bundle-synthetic-v7'}}},
    presets:{search:'precise',intent:'standard',materialKey:'material-a',keywordIds:precise.map(w=>w.id)},
    catalog:{search:[['precise','精准获客',precise],['commute','通勤拓展',commute]].map(([id,name,words])=>({
      id,name,keywords:words.map(w=>w.keyword),sourceBindings:words.map(w=>provenance(w,id)),materialName:'合成资料甲',
      libraryReference:reference,automaticProfile:true,profileDigest:'synthetic-profile-digest',excludeTerms:['真实排除词甲','真实排除词乙']})),
      intent:[{id:'standard',name:'标准意向',description:'真实方案描述',assessmentEnabled:true,
        policyReference:{runtimeAssessment}}]},
    materials:{central:{revision:'bundle-synthetic-v7',runtimeSearchRevision:'search-synthetic-v4'},
      materials:[{key:'material-a',name:'合成资料甲',keywords,priceVerified:false}],
      currentSelection:{storeId:'fixture-store-a',materialKey:'material-a',currentBindingConfirmed:true,
        automaticProfile:true,profileDigest:'synthetic-profile-digest',searchPresets,
        selectedKeywordIds:[...precise,...commute].map(w=>w.id),selectedKeywords:[...precise,...commute].map(w=>w.keyword),
        revision:17,savedAt:'2026-10-18T09:30:00Z',catalogDigest:'c'.repeat(64)},
      rulesSummary:{version:'source-synthetic-v7',enabled:false,priceVerified:false,incomeInferenceAllowed:false},
      intentRule:{version:'source-synthetic-v7',description:'真实源判断说明',signals:['真实源求租信号'],
        budgetPrinciples:['预算按本人原话保留币种和周期'],incomePrinciples:['不推断个人收入或支付能力'],
        enabled:false,currentPricesVerified:false,status:'initial_rule_not_business_calibrated'},runtimeAssessment,
      localAssessmentOverview:{source:'local_evidence_evaluator',engineVersion:REVIEW,
        standards:[{code:'R4',label:'高意向',description:'明确租住需求、具体条件，以及当前真实推进请求；提出约看不代表预约已确认。'},
          {code:'R5',label:'中意向',description:'明确租住需求和具体条件，尚无当前真实推进动作。'},
          {code:'R6',label:'低意向',description:'需求待条件触发，或明确远期了解。'}],
        budget:'提取客户预算原文；未获得已核同口径门店报价时，价格适配待核。',
        income:'只记录客户自报收入，不按职业、头像或租金推断收入和支付能力。'},
      intentPolicyOverview:{source:'local_evidence_policy',revision:17,digest:'e'.repeat(64),
        can_manage:role==='admin',...(role==='admin'?{criteria:structuredClone(savedCriteria)}:{}),
        providerCriteriaSource:'server',providerPromptAvailable:false}}};
}

class Element {
  constructor(tag,attrs,text='') { this.tag=tag;this.attrs=attrs;this.textContent=text.replace(/<[^>]*>/g,'').trim();
    this.value=attrs.value||'';this.dataset={};this.listeners={};this.disabled=Object.hasOwn(attrs,'disabled');
    for(const [k,v] of Object.entries(attrs))if(k.startsWith('data-'))this.dataset[k.slice(5).replace(/-([a-z])/g,(_,c)=>c.toUpperCase())]=v;
  }
  addEventListener(kind,fn){this.listeners[kind]=fn;}
  fire(kind,event={}){return this.listeners[kind]?.({target:this,...event});}
}
function fakeRoot(html) {
  const elements=[];
  for(const match of html.matchAll(/<(button|input|select|textarea)\b([^>]*)>(?:([\s\S]*?)<\/\1>)?/g)) {
    const attrs={};for(const attr of match[2].matchAll(/([\w:-]+)(?:="([^"]*)")?/g))attrs[attr[1]]=attr[2]??'';
    elements.push(new Element(match[1],attrs,match[3]||''));
  }
  const matches=(el,selector)=>selector.startsWith('#')?el.attrs.id===selector.slice(1):
    selector.startsWith('.')?String(el.attrs.class||'').split(/\s+/).includes(selector.slice(1)):
    /^\[([^\]=]+)(?:="([^"]*)")?\]$/.test(selector)&&(()=>{const [,key,value]=selector.match(/^\[([^\]=]+)(?:="([^"]*)")?\]$/);return Object.hasOwn(el.attrs,key)&&(value===undefined||el.attrs[key]===value);})();
  return {elements,open:true,querySelector:selector=>elements.find(el=>matches(el,selector))||null,
    querySelectorAll:selector=>elements.filter(el=>matches(el,selector))};
}
function harness(state) {
  const html=render(state),root=fakeRoot(html),calls=[],modals=[];
  const central=()=>calls.push(['central-rule-files']);
  const ctx={state,update:fn=>fn(state),openRuleFiles:central,toast:()=>{},actions:{openRuleFiles:central,
    applyPreset:async()=>{calls.push(['local-preset',state.storeId]);state.selection={...state.selection,
      searchPresetId:state.presets.search,intentPresetId:state.presets.intent,revision:state.selection.revision+1};return true;}},
    modal:info=>{const dialog=fakeRoot(info.html);modals.push({...info,dialog});return dialog;}};
  const cleanup=bind(root,ctx);
  return {state,html,root,calls,modals,cleanup,async detail(kind){
    const el=root.elements.find(e=>e.dataset.mrDetail===kind);assert(el,`Missing ${kind} detail control`);
    await el.fire('click');assert(modals.length,`${kind} detail must open`);return modals.at(-1);
  }};
}
const checks=[];let failed=0;
async function test(name,fn){try{await fn();checks.push({name,status:'PASS'});}catch(error){failed++;checks.push({name,status:'FAIL',error:error.message});}}
const centralButton=h=>h.root.elements.find(e=>e.tag==='button'&&/(管理员规则文件|中央规则|导入规则)/.test(e.textContent));

await test('precise and commute complete saved search words retain their provenance and source version',async()=>{
  for(const [id,last,ref] of [['precise','精准真实词124','source:precise:P124'],['commute','通勤真实词3','source:commute:C3']]) {
    const state=fixture();state.presets.search=id;state.presets.keywordIds=state.materials.currentSelection.searchPresets[id].keywordIds;
    const h=harness(state),modal=await h.detail('words');let all=modal.html;
    for(let i=0;i<8&&!all.includes(last);i++){
      const next=h.modals.at(-1).dialog.elements.find(e=>/下一|next/i.test(e.textContent)&&!e.disabled);
      if(!next)break;await next.fire('click');all+=h.modals.at(-1).html;
    }
    assert(all.includes(last),'Complete saved search list must be viewable beyond its first 100 entries');
    assert(all.includes(ref),'Saved sourceRefs must be visible for the corresponding keyword');
    assert(/bundle-synthetic-v7|catalog-synthetic-v7|search-synthetic-v4/.test(all),'The view must identify actual source version');
  }
});
await test('current central excludeTerms are shown instead of a hardcoded missing-data assertion',async()=>{
  const h=harness(fixture()),modal=await h.detail('exclude'),all=h.html+modal.html;
  assert(all.includes('真实排除词甲')&&all.includes('真实排除词乙'));
  assert(!all.includes('未提供统一排除项'),'Known exclusion data cannot be declared absent');
});
await test('administrator can read five saved local criteria and distinguish server AI prompt from review2',async()=>{
  const h=harness(fixture()),modal=await h.detail('evidence'),all=h.html+modal.html;
  for(const criterion of Object.values(savedCriteria))assert(all.includes(criterion),'Actual saved local criterion is hidden: '+criterion);
  assert(/17/.test(all)&&all.includes('e'.repeat(64)),'Saved local revision and digest must be inspectable');
  assert(/本地/.test(all)&&/(已保存|分级标准)/.test(all),'Local criteria must identify their actual local source');
  assert(/AI|模型/.test(all)&&/(服务器|服务端)/.test(all),'AI provider standards must identify the server source');
  assert(/提示词|prompt/i.test(all)&&/(未返回|未.*返回|不可.*读|不.*提供|未.*取得)/.test(all),'Full remote prompt absence must be explicit');
  assert(all.includes(REVIEW),'The local review2 engine must have its separate actual version');
  for(const row of h.state.materials.localAssessmentOverview.standards)
    assert(all.includes(row.code)&&all.includes(row.description),'The existing local evaluator explanation must remain distinct and complete');
});
await test('source budget and income principles remain readable while price is unverified',async()=>{
  const h=harness(fixture()),budget=await h.detail('budget'),evidence=await h.detail('evidence'),all=budget.html+evidence.html;
  assert(all.includes('预算按本人原话保留币种和周期'));
  assert(all.includes('不推断个人收入或支付能力'));
  assert(/未核|待核|不可比较/.test(all));
});
await test('operator keeps selecting approved local presets without receiving private criteria or central writes',async()=>{
  const h=harness(fixture('operator')),modal=await h.detail('evidence');
  for(const criterion of Object.values(savedCriteria))assert(!modal.html.includes(criterion));
  assert(/(仅管理员|管理员.*可见|无权|摘要)/.test(modal.html),'Operator explanation must disclose the private-criteria limit');
  assert.equal(centralButton(h),undefined,'Ordinary operator must not receive a central rule import control');
  const commute=h.root.elements.find(e=>e.dataset.mrSearch!==undefined&&e.value==='commute');assert(commute);
  await commute.fire('click');const save=h.root.querySelector('[data-mr-save]');assert(save&&!save.disabled);
  await save.fire('click');assert.deepEqual(h.calls,[['local-preset','fixture-store-a']]);
  assert.equal(h.state.presets.search,'commute');
});
await test('save labels state that only the current store scheme is saved locally',async()=>{
  const h=harness(fixture()),save=h.root.querySelector('[data-mr-save]');
  assert(save.textContent.includes('保存本门店方案'));
  assert(/本机|本地/.test(h.html),'Save scope must be visible before submission');
  await save.fire('click');assert.deepEqual(h.calls,[['local-preset','fixture-store-a']]);
  assert(/本门店方案|本机方案/.test(render(h.state)));
});
await test('central rule management is available to admin but checked again after role revocation',async()=>{
  const h=harness(fixture()),button=centralButton(h);assert(button,'Admin requires a visible route to the existing central rule file tool');
  await button.fire('click');assert.deepEqual(h.calls,[['central-rule-files']]);
  h.calls.length=0;h.state.session.user.role='operator';h.state.materials.intentPolicyOverview.can_manage=false;
  await button.fire('click');assert.deepEqual(h.calls,[],'A stale admin control cannot use a downgraded session');
});

console.log(JSON.stringify({passed:checks.length-failed,failed,checks,
  scope:'Actual management-rules module with synthetic approved DTOs. Saved local policy is not asserted to be the live provider prompt. No network, browser or product writes.'},null,2));
process.exitCode=failed?1:0;
