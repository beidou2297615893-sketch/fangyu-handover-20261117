# v4 安装前入口与 GUI gate 独立复核

结论：通过，Critical 0 / Important 0 / Minor 0，可继续既有已授权本地两文件安装。此报告关闭 CORE-CANDIDATE-V4-REVIEW 中当时尚未完成的 GUI/入口准备待办；不预先声称安装或新原生业务成功。

- 本轮 GUI-RESULT 为 PASS_CHANGED_SCOPE_GUI，release 为 ui-r57-20261018T020223Z-45516587 / candidate-core-v4，browser/native 标志均 true，synthetic 明确，零真实平台/付费 AI。四个 JPG/TXT 哈希与记录一致。
- 已实际目视两张原生 JPG：隔离 fixture-operator 回复页待处理/全部900，所选0470头像、对应原帖封面与右卡可见；完整评论0470尾标由该控件 UIA 文本确认。客户页客户1000/高意向900，列表和详情头像可见，右侧0499完整尾标实际可见。不是实平台或实客户数据。
- acquisition1000/1000/1000、browser admin142词/双方案引用/空排除/本地初始标准/本门店保存toast/账号导航和media fetch5来自 root 本轮保存的 GUI 记录；本审查不冒称亲自重跑浏览器或把 fixture media 当生产CDN。GUI预置合成AI与独立1000真实Core/workflow假provider集成证据分开。
- prepare/install 已实际适配至 v4。install 与既有事务模板除 P/OUT 字面量外相同，仍仅改 run_workbench.py / FROZEN.json，逐文件 CAS、独占备份与受限回滚保持。prepare 使用本轮 release GUI gate，没有旧原生成功 gate。
- 新 PREPARED 实际 launcher SHA：3FFDD38F3DFD311BC443C3E7A1BEA2F1EE69F0217F26117FBA6868738CC6E66E；pin SHA50D1C122…93EC5、release manifest SHA94458C70…C8BAA 均匹配。
- 安装前现场只读 hash 核对：原 launcher 8A71846F57C16C0FB61C4A8E13B7B8DEC6F7C4B1FB3B9C89E99722AF96109DAB、原 FROZEN 17024822D3634AE5BCB8760D1742EA19F5140CBC01609BBF6E1B22948DA59B64，均与 PREPARED 的 expected previous 相同。当次读取没有 INSTALL journal；随后实际安装由 root 的新记录负责。
- 原/候选公开 binding 哈希同为14CF53964F5D44D123E989805EA741669AB3F05054E730DDCB299A0AAC51A9CB。launcher66/67行检查两声明，75行才执行host模块，78行仍用原state并选择v4 project，没有 data_dir 覆盖或凭据复制。
- 已有 ENTRY-CANDIDATE-CHECK.log 实际 PASS117、WebView6.2.1、native_windows_opened0、business_app_imported=false；本审查只读该新结果，没有另开窗口。原真实窗口49485052保持的事实归属root GUI记录，审查者没有操作或探测真实客户端/进程。

仅写本目录报告/短JSON；未改产品、读真实DB/vault内容、调用网络/CLI/平台或付费AI。该技术结论不授予平台、许可、用途或商业分发批准。
