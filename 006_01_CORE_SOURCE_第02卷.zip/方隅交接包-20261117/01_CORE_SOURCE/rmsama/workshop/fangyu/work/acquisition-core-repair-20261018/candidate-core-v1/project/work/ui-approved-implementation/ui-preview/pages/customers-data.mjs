// Public customer envelopes are accepted only for the currently authenticated actor.
export const escape=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export const count=value=>Number.isSafeInteger(value)&&value>=0?value:'—';
export function actorMatches(state,envelope){return Boolean(state.user&&state.storeId&&envelope?.actor?.username===state.user&&envelope?.actor?.storeId===state.storeId);}
export function customerControls(state){
  const key=JSON.stringify([state.user||'',state.storeId||'']);
  if(state.customers?.actorKey!==key)state.customers={actorKey:key,query:'',filter:'all',sort:'intent',sortDirection:'desc',selectedId:'',checkedIds:[],filterOpen:false,evidenceOpen:false,page:1,pageSize:20};
  return state.customers;
}
export function customerQuery(state){const s=customerControls(state);return {query:s.query,filter:s.filter,sort:s.sort,sortDirection:s.sortDirection,page:s.page,pageSize:s.pageSize};}
export function customerModel(state){
  const controls=customerControls(state),raw=state.customerView;
  if(!actorMatches(state,raw))return {controls,status:'loading',items:[],stats:{},total:null,page:1,pages:1};
  return {...raw,controls,items:Array.isArray(raw.items)?raw.items.filter(item=>item&&typeof item.id==='string'&&item.id):[],stats:raw.stats||{},status:raw.status||'ready'};
}
