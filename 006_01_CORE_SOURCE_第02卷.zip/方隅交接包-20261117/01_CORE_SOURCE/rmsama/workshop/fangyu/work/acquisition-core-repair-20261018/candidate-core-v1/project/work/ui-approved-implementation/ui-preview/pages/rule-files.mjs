// Versioned administrator files. Text remains data; rendering is bounded to 20 rows.
const MAX=8*1024*1024,CHUNK=98304;
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export const sha256=async bytes=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),b=>b.toString(16).padStart(2,'0')).join('');
export function parseBundle(bytes){
  if(!(bytes instanceof Uint8Array)||bytes.length<2||bytes.length>MAX)throw new Error('只接受不超过8MiB的JSON规则文件。');
  const value=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(bytes));
  if(value?.schema_version!=='fangyu-rule-bundle/1'||value.company_id!=='fangyu-apartment-client'||!Array.isArray(value.catalog?.materials)||!Array.isArray(value.extensions?.stores)||!value.extensions?.common)throw new Error('规则文件版本、企业或完整结构不匹配。');
  let nodes=0;const pending=[[value,0]];
  while(pending.length){const [v,d]=pending.pop();if(++nodes>250000||d>16)throw new Error('规则文件结构超过限制。');if(typeof v==='string'&&new TextEncoder().encode(v).length>262144)throw new Error('单段文本超过限制。');if(v&&typeof v==='object')for(const item of Object.values(v))pending.push([item,d+1]);}
  return value;
}
function decode64(value){if(typeof value!=='string'||!value.length||value.length>131072||!/^([A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(value))throw new Error('规则分片编码无效。');return Uint8Array.from(atob(value),c=>c.charCodeAt(0));}
export async function readBundle(call,check=()=>{}){
  const status=(await call('rule_bundle_status',{})).ruleBundle;check();
  if(!status||typeof status.revision!=='string'||!/^[a-f0-9]{64}$/.test(status.digest)||!Number.isInteger(status.bytes)||status.bytes<2||status.bytes>MAX||status.chunkCount!==Math.ceil(status.bytes/CHUNK)||status.chunkCount>86)throw new Error('规则文件元数据无效。');
  const bytes=new Uint8Array(status.bytes);
  for(let i=0;i<status.chunkCount;i++){
    const part=(await call('rule_bundle_export_chunk',{revision:status.revision,index:i})).ruleBundle;check();
    if(!part||part.revision!==status.revision||part.digest!==status.digest||part.bytes!==status.bytes||part.chunkCount!==status.chunkCount||part.index!==i)throw new Error('导出期间版本变化，未拼接不同版本。');
    const chunk=decode64(part.dataBase64),size=Math.min(CHUNK,status.bytes-i*CHUNK);
    if(chunk.length!==size)throw new Error('导出分片长度不匹配。');bytes.set(chunk,i*CHUNK);
  }
  if(await sha256(bytes)!==status.digest)throw new Error('规则文件传输摘要不匹配。');check();
  return {status,bytes,bundle:parseBundle(bytes)};
}
export async function readResearchArtifact(row){
  if(row?.encoding!=='gzip+base64'||!Number.isInteger(row.bytes)||row.bytes<1||row.bytes>16*1024*1024||!Array.isArray(row.chunks)||row.chunks.length>300||row.chunks.some(v=>typeof v!=='string'||v.length>65536)||!/^[a-f0-9]{64}$/.test(row.sha256))throw new Error('原研究文件结构超过限制。');
  const encoded=row.chunks.join('');if(encoded.length>16*1024*1024)throw new Error('压缩内容超过限制。');
  const binary=atob(encoded),zipped=Uint8Array.from(binary,c=>c.charCodeAt(0));
  if(zipped.length!==row.compressedBytes)throw new Error('压缩内容长度不匹配。');
  const reader=new Blob([zipped]).stream().pipeThrough(new DecompressionStream('gzip')).getReader(),parts=[];let size=0;
  try{while(true){const next=await reader.read();if(next.done)break;size+=next.value.length;if(size>row.bytes||size>16*1024*1024)throw new Error('原文件展开超过声明长度。');parts.push(next.value);}}catch(error){await reader.cancel();throw error;}
  if(size!==row.bytes)throw new Error('原文件展开长度不匹配。');
  const bytes=new Uint8Array(size);let offset=0;for(const part of parts){bytes.set(part,offset);offset+=part.length;}
  if(await sha256(bytes)!==row.sha256)throw new Error('原研究文件摘要不匹配。');
  try{return {bytes,text:new TextDecoder('utf-8',{fatal:true}).decode(bytes),binaryType:null};}
  catch{if(row.relativePath?.toLowerCase().endsWith('.xlsx')&&bytes[0]===80&&bytes[1]===75)return {bytes,text:null,binaryType:'xlsx'};throw new Error('原文件不是受支持的文本或Excel，完整原件仍保留在导出JSON中。');}
}
export function downloadRuleJSON(bytes,revision){
  if(!/^[A-Za-z0-9_-]{1,160}$/.test(revision))throw new Error('规则版本名无效。');
  const url=URL.createObjectURL(new Blob([bytes],{type:'application/json'}));
  let doc=document;try{if(window.parent!==window&&window.parent.location.origin===location.origin)doc=window.parent.document;}catch{}
  const link=doc.createElement('a');link.href=url;link.download='fangyu-rules-'+revision+'.json';doc.body.append(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),30000);
}
const scope=s=>JSON.stringify([s.connection,s.session?.user?.username,s.session?.user?.role,s.storeId]);
function rowsOf(bundle,category,store){
  const common=bundle.extensions.common,material=bundle.catalog.materials.find(m=>m.key===store),extension=bundle.extensions.stores.find(m=>m.material_key===store);
  if(category==='terms')return [...(material?.keywordIds||[]),...(material?.heldKeywordIds||[])].map(id=>bundle.catalog.keywords.find(w=>w.id===id)).filter(Boolean).map(w=>({id:w.id,query:w.keyword,source:'原研究候选词',bindings:w.bindings.filter(b=>b.materialKey===store),csvCandidateEligible:w.csvCandidateEligible})).concat(extension?.searchTerms||[]);
  if(category==='store')return extension?[{evidence:extension.evidence,judgement:extension.judgement,excludeTerms:extension.excludeTerms,prompts:extension.prompts}]:[];
  if(category==='catalog_rules')return [bundle.catalog.intentRule||{}];
  if(category==='common_meta')return [Object.fromEntries(Object.entries(common).filter(([k])=>!['prompts','constraints','judgement_examples','decision_rules','decision_procedure','researchArtifacts','sourcePins','output_contract','runtimePolicy'].includes(k)))];
  return common[category]||[];
}
export function openRuleFiles(ctx){
  if(ctx.state.connection!=='connected'||ctx.state.session?.user?.role!=='admin'||ctx.state.session.user.username!==ctx.state.user){ctx.toast('规则文件仅限真实企业管理员。');return;}
  const h={scope:scope(ctx.state),busy:false,message:'完整规则按页查看；未核信息保持原状态。',category:'terms',store:'',query:'',page:0,data:null,upload:null};ctx.state.ruleFilesTool=h;
  const own=()=>ctx.state.ruleFilesTool===h&&h.scope===scope(ctx.state)&&h.dialog?.open!==false&&h.owner===h.dialog?.__modalOwner;
  const check=()=>{if(!own())throw new Error('员工、门店或弹窗已变化，本次回执不激活旧视图。');};
  const pending=()=>ctx.ruleBundlePending?.();
  const feedback=text=>{h.message=text;const el=h.dialog?.querySelector('[data-rule-status]');if(el)el.textContent=text;};
  const run=async task=>{if(!own()||h.busy)return;h.busy=true;show();try{await task();}catch(error){if(own())feedback(error.message);}finally{h.busy=false;if(own())show();}};
  const load=async()=>{h.data=await readBundle(ctx.ruleBundle,check);check();h.store||=h.data.bundle.catalog.materials[0]?.key||'';feedback('完整文件已校验SHA256，可查看或导出。');};
  const reconcile=async()=>{
    const p=pending()||h.upload;if(!p?.requestId&&!p?.uploadId)throw new Error('当前员工门店没有待核导入。');
    const value=(await ctx.ruleBundle('rule_bundle_import_status',p.uploadId?{uploadId:p.uploadId}:{requestId:p.requestId})).ruleBundle;check();
    if(value.requestId&&value.requestId!==p.requestId)throw new Error('导入回执编号不匹配。');
    if(value.state==='committed'){h.upload={...p,...value};h.data=null;h.file=null;feedback('已确认导入成功，正在刷新中央配置。');await ctx.reloadWorkspace();return;}
    h.upload={...p,...value};feedback('原导入状态：'+value.state+'；已收分片 '+(value.receivedIndices||[]).length+'。重新选择同一文件后可继续缺片；不会重新begin。');
  };
  const upload=async()=>{
    if(!h.file)throw new Error('请先选择并验证文件。');
    let receipt=h.upload||pending();
    if(receipt?.unknown)throw new Error('请先核对原导入状态。');
    if(receipt){
      if(receipt.digest!==h.file.digest||receipt.bytes!==h.file.bytes.length)throw new Error('请重新选择与原导入摘要一致的文件。');
      const value=(await ctx.ruleBundle('rule_bundle_import_status',receipt.uploadId?{uploadId:receipt.uploadId}:{requestId:receipt.requestId})).ruleBundle;check();
      receipt={...receipt,...value};h.upload=receipt;
      if(receipt.state!=='uploading')throw new Error('原导入状态为 '+receipt.state+'，请先核对状态。');
    }else{
      const current=(await ctx.ruleBundle('rule_bundle_status',{})).ruleBundle;check();
      receipt={requestId:crypto.randomUUID(),expectedRevision:current.revision,digest:h.file.digest,bytes:h.file.bytes.length,chunkCount:Math.ceil(h.file.bytes.length/CHUNK)};
      h.upload=receipt;
      const value=(await ctx.ruleBundle('rule_bundle_import_begin',receipt)).ruleBundle;check();receipt={...receipt,...value,receivedIndices:[]};h.upload=receipt;
    }
    if(!receipt.uploadId)throw new Error('begin回执待核，请使用原requestId核对。');
    for(let index=0;index<receipt.chunkCount;index++){
      if(receipt.receivedIndices?.includes(index))continue;
      const chunk=h.file.bytes.subarray(index*CHUNK,Math.min((index+1)*CHUNK,h.file.bytes.length));
      let binary='';for(let j=0;j<chunk.length;j+=8192)binary+=String.fromCharCode(...chunk.subarray(j,j+8192));
      await ctx.ruleBundle('rule_bundle_import_chunk',{uploadId:receipt.uploadId,index,dataBase64:btoa(binary)});check();feedback('上传规则分片 '+(index+1)+' / '+receipt.chunkCount);
    }
    const prepared=(await ctx.ruleBundle('rule_bundle_import_prepare',{uploadId:receipt.uploadId})).ruleBundle;check();h.upload={...receipt,...prepared};feedback('已生成预览，尚未应用。请核对摘要、待核项与执行契约后明确提交。');
  };
  function show(){
    if(ctx.state.ruleFilesTool!==h||h.scope!==scope(ctx.state))return;
    const bundle=h.data?.bundle,uploadState=h.upload||pending(),disabled=h.busy?'disabled':'';
    const options=[['terms','门店搜索词'],['prompts','营销提示词'],['constraints','判断约束'],['judgement_examples','构造示例'],['decision_rules','判断规则'],['decision_procedure','判断过程'],['store','门店资料'],['researchArtifacts','原研究文件索引'],['sourcePins','来源摘要'],['output_contract','输出契约'],['runtimePolicy','执行策略'],['catalog_rules','原规则草稿'],['common_meta','其他完整说明']];
    const dialog=ctx.modal({title:'管理员规则文件',html:`<div style="max-height:60vh;overflow:auto;overflow-wrap:anywhere"><p role="status" data-rule-status>${esc(h.message)}</p><p>未核租金、路线、经营状态与检索假设不会变为事实；判断为待人工校准的初始规则。</p><div class="rp-editor-actions"><button type="button" class="rp-secondary" data-rule-load ${disabled}>读取完整规则</button><button type="button" class="rp-secondary" data-rule-export ${disabled||(!bundle?'disabled':'')}>导出完整JSON</button><button type="button" class="rp-secondary" data-rule-reconcile ${disabled||(!uploadState?'disabled':'')}>核对原导入状态</button></div>${h.data?`<p>版本 ${esc(h.data.status.revision)} · ${h.data.bytes.length} bytes · SHA256 ${esc(h.data.status.digest)}</p><select data-rule-store aria-label="资料门店">${bundle.catalog.materials.map(m=>`<option value="${esc(m.key)}" ${m.key===h.store?'selected':''}>${esc(m.name||m.key)}</option>`).join('')}</select><select data-rule-category aria-label="资料分类">${options.map(([key,label])=>`<option value="${key}" ${key===h.category?'selected':''}>${label}${Array.isArray(bundle.extensions.common[key])?' ('+bundle.extensions.common[key].length+')':''}</option>`).join('')}</select><input data-rule-query aria-label="搜索规则文字" placeholder="搜索当前分类全文" value="${esc(h.query)}"><div data-rule-rows></div><button type="button" class="rp-secondary" data-rule-prev>上一页</button><button type="button" class="rp-secondary" data-rule-next>下一页</button>`:''}<hr><label>选择JSON规则文件（8MiB以内）<input type="file" accept=".json,application/json" data-rule-file ${disabled}></label><p data-rule-file-summary>${esc(h.file?'已校验 '+h.file.bytes.length+' bytes · '+h.file.digest:'选择文件仅本地验证，不会自动上传或提交。')}</p><button type="button" class="rp-secondary" data-rule-upload ${disabled||(!h.file?'disabled':'')}>${uploadState?'继续原上传并生成预览':'上传并生成预览'}</button>${uploadState?`<p>导入 ${esc(uploadState.requestId)} · ${esc(uploadState.state||'回执待核')}</p>`:''}${uploadState?.state==='prepared'?`<details open><summary>导入预览（尚未应用）</summary><pre style="white-space:pre-wrap">${esc(JSON.stringify({summary:uploadState.summary,warnings:uploadState.warnings,previewDigest:uploadState.previewDigest},null,2))}</pre><p>规则文本变更不会自动升级本机判断引擎；不支持的执行契约显示待升级。未核价格继续待核，历史评级保留。</p></details><button type="button" class="rp-primary" data-rule-commit ${disabled||pending()?.unknown?'disabled':''}>明确确认并应用此预览</button>`:''}</div>`});h.dialog=dialog;h.owner=dialog?.__modalOwner;
    const el=key=>dialog?.querySelector('[data-rule-'+key+']');
    const renderRows=()=>{
      if(!bundle||!own())return;
      let rows=rowsOf(bundle,h.category,h.store);if(!Array.isArray(rows))rows=[rows];
      rows=rows.filter(row=>!h.query||JSON.stringify(row).toLocaleLowerCase().includes(h.query.toLocaleLowerCase()));
      const pages=Math.ceil(rows.length/20);h.page=Math.max(0,Math.min(h.page,pages-1));
      el('rows').replaceChildren();const label=document.createElement('p');label.textContent=`共 ${rows.length} 项 · 第 ${pages?h.page+1:0}/${pages} 页`;el('rows').append(label);
      for(const row of rows.slice(h.page*20,h.page*20+20)){
        const details=document.createElement('details'),title=document.createElement('summary');title.textContent=row.id||row.query||row.keyword||row.name||row.path||row.artifact_id||'展开完整内容';details.append(title);
        details.addEventListener('toggle',()=>{if(!details.open||details.childNodes.length>1)return;const pre=document.createElement('pre');pre.style.whiteSpace='pre-wrap';const value=h.category==='researchArtifacts'?Object.fromEntries(Object.entries(row).filter(([k])=>k!=='chunks')):row;pre.textContent=JSON.stringify(value,null,2);details.append(pre);
          if(h.category==='researchArtifacts'){
            const button=document.createElement('button');button.type='button';button.textContent='校验并查看原文件全文';details.append(button);
            button.addEventListener('click',async()=>{button.disabled=true;try{const artifact=await readResearchArtifact(row);check();if(artifact.binaryType==='xlsx'){button.textContent='原Excel已校验，点击保存原文件';button.disabled=false;button.onclick=()=>{if(!own())return;const url=URL.createObjectURL(new Blob([artifact.bytes],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'}));let doc=document;try{if(window.parent!==window&&window.parent.location.origin===location.origin)doc=window.parent.document;}catch{}const link=doc.createElement('a');link.href=url;link.download='fangyu-source-'+row.id+'.xlsx';doc.body.append(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),30000);};return;}const text=artifact.text;let page=0;const content=document.createElement('pre'),next=document.createElement('button'),back=document.createElement('button'),label=document.createElement('p');content.style.whiteSpace='pre-wrap';next.type=back.type='button';next.textContent='下一段';back.textContent='上一段';const show=()=>{content.textContent=text.slice(page*20000,(page+1)*20000);label.textContent='原文件已校验SHA256 · 第 '+(page+1)+' / '+Math.ceil(text.length/20000)+' 段';back.disabled=page===0;next.disabled=(page+1)*20000>=text.length;};next.onclick=()=>{page++;show();};back.onclick=()=>{page--;show();};details.append(label,content,back,next);show();}catch(error){if(own())button.textContent=error.message;}},{once:true});
          }
        });el('rows').append(details);
      }
      el('prev').disabled=h.page===0;el('next').disabled=h.page+1>=pages;
    };
    el('load')?.addEventListener('click',()=>run(load));el('export')?.addEventListener('click',()=>{if(own()&&h.data)downloadRuleJSON(h.data.bytes,h.data.status.revision);});
    el('reconcile')?.addEventListener('click',()=>run(reconcile));el('upload')?.addEventListener('click',()=>run(upload));
    el('store')?.addEventListener('change',event=>{h.store=event.target.value;h.page=0;renderRows();});el('category')?.addEventListener('change',event=>{h.category=event.target.value;h.page=0;renderRows();});el('query')?.addEventListener('input',event=>{h.query=event.target.value;h.page=0;renderRows();});
    el('prev')?.addEventListener('click',()=>{h.page--;renderRows();});el('next')?.addEventListener('click',()=>{h.page++;renderRows();});
    el('file')?.addEventListener('change',event=>run(async()=>{const file=event.target.files?.[0];if(!file)return;if(!file.name.toLowerCase().endsWith('.json')||file.size>MAX||file.size<2)throw new Error('请选择8MiB以内的JSON规则文件。');const bytes=new Uint8Array(await file.arrayBuffer());check();const bundle=parseBundle(bytes),digest=await sha256(bytes);check();if(['committed','rejected','expired','aborted','not_found'].includes(h.upload?.state))h.upload=null;h.file={bytes,bundle,digest};feedback('文件本地验证通过；下一步上传并生成预览。');}));
    el('commit')?.addEventListener('click',()=>run(async()=>{const upload=h.upload;if(upload?.state!=='prepared'||!upload.previewDigest||pending()?.unknown)throw new Error('请先核对原导入状态。');const receipt=(await ctx.ruleBundle('rule_bundle_import_commit',{uploadId:upload.uploadId,previewDigest:upload.previewDigest})).ruleBundle;check();if(receipt.state!=='committed')throw new Error('未取得成功回执，请核对原导入状态。');h.upload={...upload,...receipt};h.data=null;h.file=null;feedback('已确认应用，正在重新读取员工与中央门店配置。');await ctx.reloadWorkspace();}));
    renderRows();
  }
  show();
}
