/* The server and browser share one default-closed release decision. */
function releaseState(env=process.env){
 const version=String(env.FANGYU_RELEASE_VERSION||'');
 const active=env.COMPANY_ID==='fangyu-apartment-client'
  && env.FANGYU_RELEASE_APPROVED==='1'
  && /^[0-9]+\.[0-9]+\.[0-9]+$/.test(version);
 const qaVersion=String(env.FANGYU_QA_PAIRING_VERSION||'');
 const pairingAllowed=env.COMPANY_ID==='fangyu-apartment-client'
  && !active && env.FANGYU_QA_PAIRING_APPROVED==='1'
  && /^[0-9]+\.[0-9]+\.[0-9]+-qa\.[1-9][0-9]{0,5}$/.test(qaVersion);
 const employeeVersion=String(env.FANGYU_EMPLOYEE_RELEASE_VERSION||'');
 const employeeReleaseEnabled=env.COMPANY_ID==='fangyu-apartment-client'
  && !active && env.FANGYU_EMPLOYEE_RELEASE_ENABLED==='1'
  && employeeVersion==='1.1.8-pilot.1';
 const qaDevice=String(env.FANGYU_PLATFORM_QA_DEVICE_ID||'');
 const platformQaDeviceId=pairingAllowed&&qaVersion==='1.1.7-qa.1'
  && /^[A-Za-z0-9_-]{16,80}$/.test(qaDevice)?qaDevice:'';
 const until=String(env.FANGYU_QA_CONTINUOUS_READONLY_UNTIL||'');
 const qaContinuousUntil=platformQaDeviceId&&/^[1-9][0-9]{9}$/.test(until)&&Number.isSafeInteger(Number(until))?Number(until):0;
 const continuousDevice=String(env.FANGYU_CONTINUOUS_READONLY_DEVICE_ID||'');
 const continuousReadonlyDeviceId=platformQaDeviceId&&continuousDevice===platformQaDeviceId?platformQaDeviceId:'';
 return {active,version:active?version:'',pairingAllowed,pairingVersion:pairingAllowed?qaVersion:'',
  employeeReleaseEnabled,employeeReleaseVersion:employeeReleaseEnabled?employeeVersion:'',
  platformQaDeviceId,qaContinuousUntil,continuousReadonlyDeviceId};
}
module.exports={releaseState};
