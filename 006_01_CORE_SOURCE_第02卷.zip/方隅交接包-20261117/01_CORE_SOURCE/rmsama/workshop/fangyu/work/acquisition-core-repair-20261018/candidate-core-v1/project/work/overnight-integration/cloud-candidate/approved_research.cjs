'use strict';
// These independently reviewed pins are code, never an authority supplied by an upload.
const {gunzipSync}=require('node:zlib');
const {hash}=require('./store_config.cjs');
const VERSION='2026-10-17.intent-evidence-contract-draft-v4';
const ENGINE_VERSION='2026-10-18.intent-evidence-contract-draft-v4-review2';
const PARENT={id:'ART-5c9defa77ce939605737',sha256:'ebb5f71e350b8fefa9b6b88b581a315a4852695005e8ad20686c9873584051ca',bytes:4068717};
const RULE={id:'ART-8a82ed253e4e486c73fd',sha256:'87d2e4c0612b5fe9113c1fdad39e66da79106fbfae6890d988f7f0c9b3447874',bytes:138373};
const FIELDS={version:'version',constraints:'constraints',decision_rules:'decisionRules',
 output_contract:'outputContract',decision_procedure:'decisionProcedure',prompts:'prompts',
 judgement_examples:'judgement_examples',questionnaire_design:'questionnaireDesign'};
function approvedArtifact(common,pin){
 const rows=common?.researchArtifacts;
 if(!Array.isArray(rows))return null;
 const found=rows.filter(a=>a?.id===pin.id);if(found.length!==1)return null;
 const a=found[0];if(a.sha256!==pin.sha256||a.bytes!==pin.bytes||a.encoding!=='gzip+base64'||!Array.isArray(a.chunks))return null;
 try{
  if(a.chunks.some(s=>typeof s!=='string'||s.length>65536))return null;
  const zipped=Buffer.from(a.chunks.join(''),'base64');
  const raw=gunzipSync(zipped,{maxOutputLength:pin.bytes});
  if(raw.length!==pin.bytes||hash(raw)!==pin.sha256)return null;
  return JSON.parse(raw.toString('utf8').replace(/^\uFEFF/,''));
 }catch{return null;}
}
function policyRequested(common){
 const p=common?.runtimePolicy;
 if(!p)return {search:false,assessment:false};
 if(p.schema!=='fangyu-approved-runtime-policy/1'||typeof p.searchHypotheses!=='boolean'||typeof p.assessment!=='boolean'
   ||Object.keys(p).some(k=>!['schema','searchHypotheses','assessment'].includes(k)))throw Error('runtime_policy_invalid');
 return {search:p.searchHypotheses,assessment:p.assessment};
}
function contractBody(common){return Object.fromEntries(Object.keys(FIELDS).map(k=>[k,common[k]]));}
function createApproval(bundle){
 const common=bundle.extensions.common,requested=policyRequested(common);
 const parent=requested.search?approvedArtifact(common,PARENT):null;
 const rules=requested.assessment?approvedArtifact(common,RULE):null;
 const expected=rules?Object.fromEntries(Object.entries(FIELDS).map(([k,v])=>[k,rules[v]])):null;
 const contractDigest=hash(contractBody(common));
 const assessment=!!(requested.assessment&&rules&&common.version===VERSION&&hash(expected)===contractDigest);
 // Resolve the original tuple. An uploaded eligibility flag, uploaded source hash,
 // or a different held binding on the same query cannot alter this result.
 function hypothesis(term,materialKey){
  if(!parent)return null;
  const eligible=[];
  for(const binding of Array.isArray(term.bindings)?term.bindings:[]){
   if(binding?.origin!=='parent_extension'||binding.provenance?.artifactId!==PARENT.id)continue;
   const match=/^\/extensions\/stores\/(\d+)\/searchTerms\/(\d+)$/.exec(binding.provenance.pointer||'');
   if(!match)continue;
   const store=parent.extensions?.stores?.[Number(match[1])],original=store?.searchTerms?.[Number(match[2])];
   if(store?.material_key!==materialKey||!original||original.query!==term.query
      ||!Array.isArray(original.holdReasons)||original.holdReasons.length
      ||!['direct','context','exploratory'].includes(original.tier)
      ||!Array.isArray(original.sourceRefs)||!original.sourceRefs.length)continue;
   eligible.push({materialKey,tier:original.tier,sourceRefs:original.sourceRefs,
    sourceArtifactId:PARENT.id,sourcePointer:binding.provenance.pointer});
  }
  if(!eligible.length)return null;
  return {query:term.query,tier:eligible[0].tier,source:'approved_search_hypothesis',eligibleHypothesis:true,holdReasons:[],
   sourceRefs:[...new Set(eligible.flatMap(x=>x.sourceRefs))],sourceBindings:eligible,
   evidenceStatus:'candidate',rentalIntentImplied:false,incomeInferenceAllowed:false};
 }
 return {hypothesis,requested,assessment,contractDigest,
  assessmentPolicy:{schema:'fangyu-runtime-assessment/1',version:VERSION,engineVersion:ENGINE_VERSION,
   enabled:assessment,contractDigest,sourceDigest:RULE.sha256,calibrated:false,
   status:assessment?'deterministic_candidate_requires_human_review':requested.assessment?'requires_engine_update':'not_enabled',
   currentPricesVerified:false,providerRequests:false},
  warnings:[...(requested.search&&!parent?['SEARCH_HYPOTHESIS_SOURCE_NOT_APPROVED']:[]),
   ...(requested.assessment&&!assessment?['ASSESSMENT_CONTRACT_REQUIRES_ENGINE_UPDATE']:[])]};
}
module.exports={VERSION,ENGINE_VERSION,PARENT,RULE,FIELDS,createApproval,contractBody};
