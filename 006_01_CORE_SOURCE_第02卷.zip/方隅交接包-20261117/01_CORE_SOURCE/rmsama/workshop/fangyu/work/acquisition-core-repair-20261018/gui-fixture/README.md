# 本轮合成 GUI 夹具

尚未启动端口、浏览器或 GUI，也未做界面验收。只由 root 启动和操作浏览器。

复用上一轮已存在的 `gui-final-fixture/launch.py` 与 `employee-simple-flow/gui-fixture/serve_fixture.py`，保留实际当前 host、backend、UI、customer/reply projections、同源媒体路由和独立 loopback memory cloud。启动时复制当前源码，前后 SHA 必须一致。旧冻结 release 仅提供经原 verify_release 核对的静态资源和依赖；该夹具不是新 release/build/promotion。

1000 条是**预置合成数据**：900 个求租者、100 个供给方，实际 Core 导入、实际本地 assessment 和客户/回复投影；AI 字段明确为 `synthetic_fixture/precomputed_gui_seed`，未再跑分页或模型。此前实际 Core/AI 集成结果在上层 `CORE-AI-1000-RESULT.json`，本夹具不能替代它。当前中央材料 14 店配置沿用原只读协议和摘要，不是实际企业授权签发；规则校准仍 false，排除词若为空照实显示。

启动（源码停止编辑后运行；仅该命令会打开专用 loopback 端口）：

```powershell
& 'C:/积木软件工坊/项目/方隅公寓客户版/work/desktop-python/Scripts/python.exe' -X utf8 -B -I 'C:/积木软件工坊/项目/方隅公寓客户版/work/acquisition-core-repair-20261018/gui-fixture/launch.py' --source --project-root 'C:/积木软件工坊/项目/方隅公寓客户版/work/acquisition-core-repair-20261018/candidate-core-v2/project'
```

`--project-root` 选择冻结 v2 的 host/UI/backend/r55/cloud/material 输入；默认从其父 `STAGED.json` 选择冻结 release，也可显式传 `--base-release`。不传 project-root 才使用 canonical 源。Python/Node/Pillow 仍复用已有外置依赖，不是 portable runtime。

若 root 同时验原生 renderer，在上述命令末尾加 `--native`。它仅打开标题为 **方隅工作台 · 本轮隔离验收** 的专用 pywebview/WebView2 窗口，使用本 run 的 `native-profile` 和 private mode，不复制原员工会话或触碰原窗口。`NATIVE-STATUS.json` 区分 REQUESTED/SHOWN/WINDOW_CLOSED/EVENT_LOOP_RETURNED；SHOWN 只说明原生窗口事件，不能代替实际界面检查。STOP 会关闭这个 QA 窗口；手动关闭这个 QA 窗口也只停止本 run。该模式不做原生保存或真实平台认证。

启动会在本目录 `runs/<随机ID>/` 创建独占数据、代码快照和状态。`LATEST.json` / run 的 `PUBLIC.json` 给出 URL、instanceId、Python/Node PID、STOP 路径。准备 1000 条规则结果可能需要数十秒；出现 READY 后才打开 URL。选择 `fixture-operator`，密码 `fixture-password-123`；这是公开合成凭据，未使用原员工会话。`fixture-admin` 可看 14 店规则，但未为管理员再生成 1000 条数据。

建议 root 检查：

1. 获客页的已读/新增/已分析均 1000，已完成；该显示是本次合成种子状态，不代表真实新采集。夹具禁用开始采集。
2. 回复页候选排除“隔离供给方”；右侧同一条来源应显示原帖标题、作者、封面、头像和完整评论，末尾含 `【完整评论尾标 SYNTHETIC-xxxx】`。
3. 客户页实际读取同源头像图片，五个主导航及规则页的精准/通勤/排除/标准可正常阅读。头像为本地生成的示意人物，封面为示意房间；均非真人照片或真实房源。
4. 登录后在同一浏览器打开 `<URL>fixture/evidence`，它经过实际 HttpOnly 会话/Host/所选门店检查。查看 counts、prospects、当前标准来源和 `media_fetch_count/media_paths`；不输出 cookie、密钥或客户正文。媒体只允许固定 `fixture.xhscdn.com` 注册表，任何其他 URL 拒绝，仍走产品的原归属/图片字节校验。

命名证据：`INPUT-SNAPSHOT.json`（捕获源码 SHA）、`SYNTHETIC-SEED-EVIDENCE.json`（实际投影汇总）、`MEDIA-REGISTRY.json`（合成图片 SHA）、`PUBLIC.json`。未执行 `--smoke`、截图、登录浏览器或 GUI 检查；准备脚本的 AST 检查不能声称服务启动通过。

正常停止：先从当前 `LATEST.json` 读出 instanceId，显式传入：

```powershell
& 'C:/积木软件工坊/项目/方隅公寓客户版/work/desktop-python/Scripts/python.exe' -X utf8 -B -I 'C:/积木软件工坊/项目/方隅公寓客户版/work/acquisition-core-repair-20261018/gui-fixture/stop_fixture.py' --instance '<当前 instanceId>'
```

脚本核对当前 READY instance、独占 run 路径及 PUBLIC 字节后仅写本实例 STOP，不杀其他进程。随后应等启动 PTY 返回，核对该 run 的 `CLOSED.json` 和 `CLOUD-CLOSED.json`。STOP 写入只代表请求关闭；没有最终回执或 PTY 退出证据时，不声明 exit0。

文件夹：`C:/积木软件工坊/项目/方隅公寓客户版/work/acquisition-core-repair-20261018/gui-fixture`
