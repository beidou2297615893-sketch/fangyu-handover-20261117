// Small behavior regressions from the final read-only review. Synthetic state; no IO.
import assert from 'node:assert/strict';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {dirname,resolve} from 'node:path';
const W=dirname(fileURLToPath(import.meta.url));
const UI=resolve(W,'../ui-approved-implementation/ui-preview');
const replies=await import(pathToFileURL(resolve(UI,'pages/reply-connected.mjs')));
const rules=await import(pathToFileURL(resolve(UI,'pages/management-rules.mjs')));
const acquire=await import(pathToFileURL(resolve(UI,'pages/acquire.mjs')));
const checks=[];let failed=0;
async function test(name,fn){try{await fn();checks.push({name,status:'PASS'});}catch(error){failed++;checks.push({name,status:'FAIL',error:error.message});}}
const node=(dataset={})=>({dataset,listeners:{},addEventListener(kind,fn){this.listeners[kind]=fn;},fire(kind){return this.listeners[kind]?.({target:this});}});

await test('both original-post controls use the currently selected source and the same URL guard',async()=>{
  const buttons=[node(),node()],opened=[],toasts=[];
  const first={id:'a',postUrl:'https://www.xiaohongshu.com/explore/'+'1'.repeat(24),platform:'xiaohongshu'};
  const second={id:'b',postUrl:'https://www.xiaohongshu.com/explore/'+'2'.repeat(24),platform:'xiaohongshu'};
  const state={connection:'connected',page:'reply',user:'alice',storeId:'store',session:{user:{username:'alice'}},
    replyLive:{actor:'alice|store',status:'ready',leadId:'a',detail:{comments:[first,second]},busy:false}};
  globalThis.window={open:(...args)=>opened.push(args)};
  const root={querySelector:selector=>selector==='[data-live-source]'?buttons[0]:null,
    querySelectorAll:selector=>selector==='[data-live-source]'?buttons:[]};
  replies.bindConnected(root,{state,update:fn=>fn?.(state),toast:text=>toasts.push(text)});
  for(const button of buttons)await button.fire('click');
  assert.deepEqual(opened,[[first.postUrl,'_blank','noopener'],[first.postUrl,'_blank','noopener']]);
  state.replyLive.leadId='b';for(const button of buttons)await button.fire('click');
  assert.deepEqual(opened.slice(2),[[second.postUrl,'_blank','noopener'],[second.postUrl,'_blank','noopener']]);
  second.postUrl='https://attacker.invalid/post';for(const button of buttons)await button.fire('click');
  assert.equal(opened.length,4);assert.equal(toasts.length,2);
});

await test('initial, persisted and unavailable local policy states are labelled accurately',async()=>{
  for(const [overview,expected,forbidden] of [
    [{source:'local_evidence_policy',revision:0,can_manage:true,criteria:{}},/本地初始.*尚未保存/,/本地已保存的五级/],
    [{source:'local_evidence_policy',revision:17,can_manage:true,criteria:{}},/本地已保存的五级/,/本地初始.*尚未保存/],
    [{source:'unavailable',providerPromptAvailable:false},/本地规则.*未读取/,/本地已保存的五级|本地初始.*尚未保存/],
  ]){
    const control=node({mrDetail:'evidence'}),modals=[];
    const state={connection:'connected',user:'alice',storeId:'store',stores:[{id:'store'}],catalog:{search:[],intent:[]},
      materials:{intentPolicyOverview:overview}};
    rules.bind({querySelector:()=>null,querySelectorAll:s=>s==='[data-mr-detail]'?[control]:[]},
      {state,update:fn=>fn(state),modal:info=>modals.push(info)});
    await control.fire('click');assert.equal(modals.length,1);
    assert.match(modals[0].html,expected);assert.doesNotMatch(modals[0].html,forbidden);
  }
});

await test('analyzing phase is visible and a stale start event cannot create another forbidden task',async()=>{
  const start=node(),calls=[];
  const state={connection:'connected',page:'acquire',user:'alice',storeId:'store',stores:[{id:'store',name:'合成门店'}],
    platform:{actor:{username:'alice',storeId:'store'},platforms:[{id:'xiaohongshu',name:'小红书',enabled:true}],
      capabilities:{timeRanges:['最近7天']},acquisition:{status:'stopped',phase:'analyzing',canStart:false,canResume:false,
        counts:{read:20,added:1,analyzed:0,duplicates:19}}}};
  const html=acquire.render(state),button=html.match(/<button\b[^>]*data-acquire-start[^>]*>/)?.[0];
  assert(button&&/\bdisabled\b/.test(button));assert(html.includes('意向分析待继续'));
  const stages=html.match(/<ol>([\s\S]*?)<\/ol>/)?.[1]||'';
  const analysis=[...stages.matchAll(/<li class="([^"]*)">([\s\S]*?)<\/li>/g)].find(m=>m[2].includes('意向分析'));
  assert(analysis&&analysis[1].includes('current'));
  acquire.bind({querySelector:s=>s==='[data-acquire-start]'?start:null,querySelectorAll:()=>[]},
    {state,update:fn=>fn?.(state),actions:{startAcquisition:()=>calls.push('new-task')}});
  await start.fire('click');assert.deepEqual(calls,[],'Live canStart=false must be enforced by the handler as well as its disabled HTML');
});

console.log(JSON.stringify({passed:checks.length-failed,failed,checks,scope:'Actual module behavior with synthetic state and in-memory controls only; no browser or network.'},null,2));
process.exitCode=failed?1:0;
