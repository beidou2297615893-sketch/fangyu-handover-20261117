/* Same-origin local QA transport. The cloud bearer never enters JavaScript. */
export class WorkspaceError extends Error {
  constructor(message, details={}) { super(message); Object.assign(this, details); }
}

const MUTATING_OPERATIONS=new Set(['command_submit','publish','member_save',
  'device_revoke','device_claims_release','local_pair','login','logout','product_action']);

export class WorkspaceCloud {
  constructor({environmentId, companyId, onSessionExpired=()=>{}, onConnectionState=()=>{}, requestTimeoutMs=15000}, fetcher=globalThis.fetch.bind(globalThis)) {
    this.environmentId=environmentId;
    this.companyId=companyId;
    this.fetcher=fetcher;
    this.onSessionExpired=onSessionExpired;
    this.onConnectionState=onConnectionState;
    this.requestTimeoutMs=Number.isFinite(requestTimeoutMs)&&requestTimeoutMs>0?requestTimeoutMs:15000;
    this.user=null;
    // Compatibility with the existing view only. It is never a credential.
    this.token='';
    this.epoch=0;
    this.localOnly=false;
  }

  async call(operation, data={}, signal) {
    const epoch=this.epoch;
    if(!data || Array.isArray(data) || typeof data!=='object') throw new WorkspaceError('请求参数格式错误');
    const controller=new AbortController();
    const abort=()=>controller.abort();
    if(signal){if(signal.aborted)abort();else signal.addEventListener('abort',abort,{once:true});}
    let expired=false,timer;
    const timeoutError=()=>new WorkspaceError(MUTATING_OPERATIONS.has(operation)
      ?'操作等待超时，结果未确认；请先核对状态，不要重复提交。'
      :'读取超时，请稍后刷新状态。',{timeout:true});
    const deadline=new Promise((_,reject)=>{timer=setTimeout(()=>{
      expired=true;controller.abort();reject(timeoutError());
    },this.requestTimeoutMs);});
    const request=(async()=>{try{
      const response=await this.fetcher('/api', {
        method:'POST', headers:{'Content-Type':'application/json','Accept':'application/json','X-Local-App':'1'},
        credentials:'same-origin', redirect:'error', cache:'no-store', signal:controller.signal,
        body:JSON.stringify({action:'desktop_workspace',data:{...data,operation}})
      });
      if(expired)throw timeoutError();
      if(this.epoch!==epoch)throw new WorkspaceError('登录状态已变化，请重新操作');
      if(response.status===401 && operation!=='login' && operation!=='me') {
        this.epoch++;this.user=null;this.token='';
        const error=new WorkspaceError('员工工作台登录已失效，请重新登录。系统不会自动重试刚才的操作；登录后请先核对任务或回复状态。',{status:401,sessionExpired:true});
        this.onSessionExpired(error);
        throw error;
      }
      let value;
      try { value=await response.json(); }
      catch(error) { if(expired)throw timeoutError();throw new WorkspaceError('本机服务没有返回有效响应'); }
      if(expired)throw timeoutError();
      if(this.epoch!==epoch)throw new WorkspaceError('登录状态已变化，请重新操作');
      if(!response.ok)throw new WorkspaceError(value?.error||'请求未完成',{status:response.status,
        mutation_committed:typeof value?.mutation_committed==='boolean'?value.mutation_committed:null});
      if(value?.contract!=='fangyu-workspace-v1' || value.environment_id!==this.environmentId || value.company_id!==this.companyId)
        throw new WorkspaceError('企业服务身份不匹配');
      if('token' in value)throw new WorkspaceError('本机服务返回了不允许的凭据字段');
      if(typeof value.development_local_only==='boolean'){
        const next=value.development_local_only;
        if(this.user&&this.user.development_local_only!==next)this.user={...this.user,development_local_only:next};
        if(next!==this.localOnly){this.localOnly=next;this.onConnectionState(next);}
      }
      return value;
    }catch(error){if(expired)throw timeoutError();throw error;}})();
    try{return await Promise.race([request,deadline]);}
    finally{clearTimeout(timer);if(signal)signal.removeEventListener('abort',abort);}
  }

  async restore() {
    try {
      const value=await this.call('me');
      if(!['admin','operator'].includes(value.user?.role))return null;
      this.user={...value.user,development_local_only:value.development_local_only===true};this.token='local-session';return this.user;
    } catch(error) {
      if(error.status===401){this.user=null;this.token='';return null;}
      throw error;
    }
  }

  async login(username,password) {
    this.epoch++;this.user=null;this.token='';
    const value=await this.call('login',{username,password});
    if(!['admin','operator'].includes(value.user?.role))throw new WorkspaceError('登录响应无效');
    this.user={...value.user,development_local_only:value.development_local_only===true};this.token='local-session';this.localOnly=false;return this.user;
  }

  async logout() {
    try { if(this.token)await this.call('logout'); }
    finally { this.epoch++;this.user=null;this.token='';this.localOnly=false; }
  }

  async submit(deviceId,action,data={},requestId=crypto.randomUUID()) {
    try { return {...await this.call('command_submit',{device_id:deviceId,action,data,request_id:requestId}),requestId}; }
    catch(error) { error.requestId=requestId;throw error; }
  }

  async inspect(commandId) { return (await this.call('command_get',{command_id:commandId})).command; }
}
