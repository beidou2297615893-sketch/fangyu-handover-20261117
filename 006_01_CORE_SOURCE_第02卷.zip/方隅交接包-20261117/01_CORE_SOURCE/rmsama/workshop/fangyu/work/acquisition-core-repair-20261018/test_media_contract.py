"""Focused saved-media contracts; synthetic storage and injected IO only.

Only this module's tests run. Existing customer fixture methods are reused,
but its unrelated test suite is not inherited. All temporary files stay in W.
No HTTP server/client, real credentials, browser, or platform action is used.
"""
from pathlib import Path
from types import SimpleNamespace
from urllib.parse import parse_qs, urlencode, urlsplit
from unittest.mock import Mock, patch
import hashlib
import io
import sys
import tempfile
import threading
import unittest

W = Path(__file__).resolve().parent
P = W.parents[1]
SOURCE = P / 'work/ui-runtime-r55/src'
NATIVE = P / 'work/ui-native-r57'
sys.dont_write_bytecode = True
sys.path.insert(0, str(SOURCE))
sys.path.insert(0, str(NATIVE))

from core.engine import Core
from customer_workbench import CustomerWorkbench, CustomerWorkbenchError
from reply_workbench import ReplyWorkbench
from workbench_backend import WorkbenchBackend, WorkbenchError
import test_customer_workbench as original_customer
import ui_native_host as host

STORE = 'fixture-store-a'
LEAD = '1' * 32
OTHER = '2' * 32
ORIGIN = 'http://127.0.0.1:54321'


def png_bytes():
    from PIL import Image
    stream = io.BytesIO()
    Image.new('RGB', (2, 2), color=(10, 120, 90)).save(stream, format='PNG')
    return stream.getvalue()


class SavedMediaContract(unittest.TestCase):
    employee = original_customer.CustomerBehavior.employee
    lead = original_customer.CustomerBehavior.lead

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='media-fixture-', dir=W)
        self.core = Core(self.temp.name, defer_startup_recovery=True)
        self.company = {'id': 'fangyu-apartment-client', 'edition': 'customer',
                        'personalMode': False, 'authMode': 'managed',
                        'managedWorkspace': {'environment_id': 'customer-fixture'}}
        self.tenant = 'cloud-' + hashlib.sha256(
            b'customer-fixture\nfangyu-apartment-client').hexdigest()[:24]
        self.user = self.employee('alice')
        self.other = self.employee('bob')
        self.workbench = CustomerWorkbench(self.core, self.company, P)
        self.row = self.lead(LEAD, 'stable-customer-uid', store=STORE, level='high')
        self.row.update(author_avatar_url='https://fixture.xhscdn.com/customer.png',
                        content_author_avatar_url='https://fixture.xhscdn.com/post-author.png',
                        content_cover_url='https://fixture.xhscdn.com/post-one.png')
        self.core.store.put('leads', self.row)
        self.body = png_bytes()
        self.fetches = []
        self.network = patch('socket.create_connection', side_effect=AssertionError('Network forbidden'))
        self.dns = patch('socket.getaddrinfo', side_effect=AssertionError('DNS forbidden'))
        self.network.start()
        self.dns.start()

    def tearDown(self):
        self.dns.stop()
        self.network.stop()
        self.core.adapters.close()
        self.temp.cleanup()

    def fetch(self, parsed, hostname):
        self.fetches.append((parsed.geturl(), hostname))
        return self.body, 'image/png'

    def media(self, lead_id=LEAD, kind='author', *, user=None, store_id=STORE, fetcher=None):
        method = getattr(self.workbench, 'media', None)
        self.assertTrue(callable(method), 'CustomerWorkbench.media interface is not connected')
        return method(user or self.user, store_id, lead_id, kind, fetcher=fetcher or self.fetch)

    def media_url(self, value, lead_id, kind):
        self.assertIsInstance(value, str)
        parsed = urlsplit(value)
        self.assertFalse(parsed.scheme or parsed.netloc, 'DTO must use a same-origin relative URL')
        self.assertEqual(parsed.path, '/api/workbench/media')
        self.assertEqual(parse_qs(parsed.query), {'storeId': [STORE], 'leadId': [lead_id], 'kind': [kind]})

    def test_author_post_author_and_cover_read_only_saved_fields(self):
        expected = {'author': 'customer.png', 'post_author': 'post-author.png', 'cover': 'post-one.png'}
        before = self.core.store.path.read_bytes()
        for kind, suffix in expected.items():
            with self.subTest(kind=kind):
                self.assertEqual(self.media(kind=kind), (self.body, 'image/png'))
                self.assertEqual(self.fetches[-1][0], 'https://fixture.xhscdn.com/' + suffix)
        self.assertEqual(self.core.store.path.read_bytes(), before, 'Media reads cannot alter customer records')

    def test_foreign_employee_store_and_task_never_reach_fetch(self):
        method = getattr(self.workbench, 'media', None)
        self.assertTrue(callable(method), 'CustomerWorkbench.media interface is not connected')
        scenarios = [('foreign-employee', {'cloud_owner': 'bob'}),
                     ('foreign-store', {'store_id': 'fixture-store-b'}),
                     ('foreign-task', {'task_id': 'foreign-fixture-task'})]
        self.core.store.put('tasks', {'id': 'foreign-fixture-task', 'tenant_id': self.tenant,
                                     'cloud_owner': 'bob', 'store_id': STORE})
        for label, changes in scenarios:
            with self.subTest(label=label):
                self.core.store.put('leads', {**self.row, **changes})
                with self.assertRaises(CustomerWorkbenchError):
                    self.media()
        self.assertEqual(self.fetches, [])

    def test_cached_bytes_still_require_current_employee_and_lead_scope(self):
        self.media()
        self.assertEqual(len(self.fetches), 1)
        self.core.store.put('users', {**self.user, 'disabled': True})
        with self.assertRaises(CustomerWorkbenchError):
            self.media()
        self.core.store.put('users', self.user)
        self.core.store.put('leads', {**self.row, 'store_id': 'fixture-store-b'})
        with self.assertRaises(CustomerWorkbenchError):
            self.media()
        self.assertEqual(len(self.fetches), 1)

    def test_store_scope_is_rechecked_after_downloading_before_bytes_return(self):
        def moved_during_fetch(parsed, hostname):
            result = self.fetch(parsed, hostname)
            self.core.store.put('leads', {**self.row, 'store_id': 'fixture-store-b'})
            return result
        with self.assertRaises(CustomerWorkbenchError):
            self.media(fetcher=moved_during_fetch)
        self.assertEqual(len(self.fetches), 1)

    def test_cover_does_not_borrow_another_post_of_the_same_customer(self):
        other = self.lead(OTHER, 'stable-customer-uid', day=2, store=STORE)
        other['note_url'] = 'https://www.xiaohongshu.com/explore/' + '2' * 24
        other['content_cover_url'] = 'https://fixture.xhscdn.com/post-two.png'
        self.core.store.put('leads', other)
        missing = {**self.row}
        missing.pop('content_cover_url')
        self.core.store.put('leads', missing)
        with self.assertRaises(ValueError):
            self.media(kind='cover')
        self.assertEqual(self.fetches, [], 'Missing source cover must not trigger another post fetch')

    def test_invalid_kinds_and_non_platform_saved_urls_do_not_fetch(self):
        method = getattr(self.workbench, 'media', None)
        self.assertTrue(callable(method), 'CustomerWorkbench.media interface is not connected')
        for kind in ('anything', 'https://attacker.invalid/image.png', '', None):
            with self.subTest(kind=kind), self.assertRaises(ValueError):
                self.media(kind=kind)
        for url in ('https://127.0.0.1/private.png', 'https://attacker.invalid/image.png',
                    'file:///C:/secret.png', 'https://fixture.xhscdn.com:8443/x.png'):
            with self.subTest(url=url):
                self.core.store.put('leads', {**self.row, 'content_cover_url': url})
                with self.assertRaises(ValueError):
                    self.media(kind='cover')
        self.assertEqual(self.fetches, [])

    def test_customer_and_reply_dtos_keep_each_original_comment_cover(self):
        other = self.lead(OTHER, 'stable-customer-uid', day=2, store=STORE)
        other.update(note_url='https://www.xiaohongshu.com/explore/' + '2' * 24,
                     author_avatar_url='https://fixture.xhscdn.com/customer-two.png',
                     content_cover_url='https://fixture.xhscdn.com/post-two.png')
        self.core.store.put('leads', other)
        listing = self.workbench.list(self.user, STORE, {})
        self.assertEqual(listing['total'], 1)
        item = listing['items'][0]
        self.media_url(item['avatarUrl'], OTHER, 'author')
        detail = self.workbench.detail(self.user, STORE, item['id'])['item']
        reply = ReplyWorkbench(self.core, self.workbench).read(self.user, STORE, item['id'])
        for comments in (detail['comments'], reply['comments']):
            self.assertEqual({c['id'] for c in comments}, {LEAD, OTHER})
            for comment in comments:
                self.media_url(comment.get('coverUrl'), comment['id'], 'cover')
        self.assertEqual(self.fetches, [], 'DTO projection cannot read platform media')


class MediaGatewayContract(unittest.TestCase):
    def setUp(self):
        self.backend = object.__new__(WorkbenchBackend)
        self.backend.lock = threading.RLock()
        self.backend.closed = False
        self.user = {'id': 'fixture-id', 'tenant_id': 'fixture-tenant',
                     'username': 'alice', 'role': 'operator', 'cloud_bound': True}
        self.profile = {**self.user, 'store_id': STORE}
        self.backend._identity = Mock(return_value=(self.user, self.profile))
        self.backend._selected_store = Mock(return_value=STORE)
        self.backend._stores = Mock(return_value=[{'id': STORE}])
        self.backend._load_selection = Mock(return_value={'storeId': STORE})
        self.boundary = Mock(return_value=(b'fixture-bytes', 'image/png'))
        self.backend.customer_workbench = SimpleNamespace(media=self.boundary)
        self.payload = {'storeId': STORE, 'leadId': LEAD, 'kind': 'cover'}

    def media(self, data=None, token='fixture-http-only-session'):
        method = getattr(self.backend, 'media', None)
        self.assertTrue(callable(method), 'WorkbenchBackend.media interface is not connected')
        return method(token, self.payload if data is None else data)

    def test_current_session_and_selected_store_are_forwarded_without_caller_authority(self):
        self.assertEqual(self.media(), (b'fixture-bytes', 'image/png'))
        self.backend._identity.assert_called_once_with('fixture-http-only-session')
        self.backend._selected_store.assert_called_once_with(self.user, self.profile)
        actor, store_id, lead_id, kind = self.boundary.call_args.args
        self.assertEqual((actor['username'], store_id, lead_id, kind), ('alice', STORE, LEAD, 'cover'))

    def test_media_payload_has_exact_shape_no_arbitrary_url_or_owner(self):
        method = getattr(self.backend, 'media', None)
        self.assertTrue(callable(method), 'WorkbenchBackend.media interface is not connected')
        for changes in ({'url': 'https://attacker.invalid/x.png'}, {'owner': 'bob'},
                        {'tenant_id': 'other'}, {'kind': 'anything'}, {'leadId': 'not-a-lead'}):
            with self.subTest(changes=changes), self.assertRaises(WorkbenchError):
                self.media({**self.payload, **changes})
        with self.assertRaises(WorkbenchError):
            self.media({'leadId': LEAD, 'kind': 'cover'})
        self.boundary.assert_not_called()

    def test_store_change_and_revoked_identity_stop_before_media_boundary(self):
        method = getattr(self.backend, 'media', None)
        self.assertTrue(callable(method), 'WorkbenchBackend.media interface is not connected')
        with self.assertRaises(WorkbenchError):
            self.media({**self.payload, 'storeId': 'fixture-store-b'})
        self.backend._identity.side_effect = WorkbenchError('AUTH_REQUIRED', 'fixture revoked', 401)
        with self.assertRaises(WorkbenchError) as caught:
            self.media()
        self.assertEqual(caught.exception.code, 'AUTH_REQUIRED')
        self.boundary.assert_not_called()


class MediaHandlerContract(unittest.TestCase):
    def handler(self, query):
        result = {'headers': {}}
        backend = SimpleNamespace(media=Mock(return_value=(b'fixture-png', 'image/png')))
        handler = object.__new__(host.StaticHandler)
        handler.command = 'GET'
        handler.path = '/api/workbench/media?' + query
        handler.headers = {'Host': '127.0.0.1:54321', 'Cookie': 'fixture_session=fixture-http-only-session'}
        handler.server = SimpleNamespace(server_port=54321, backend=backend, runtime=None,
            session_cookie='fixture_session', csp=host.CSP, counters={'blocked': 0, 'static': 0},
            read_static=Mock(side_effect=FileNotFoundError))
        handler.send_response = lambda status: result.update(status=status)
        handler.send_header = lambda key, value: result['headers'].update({key: value})
        handler.end_headers = lambda: None
        handler.wfile = io.BytesIO()
        return handler, backend, result

    def test_fixed_media_route_uses_http_only_session_and_original_security_headers(self):
        query = urlencode({'storeId': STORE, 'leadId': LEAD, 'kind': 'cover'})
        handler, backend, result = self.handler(query)
        handler.do_GET()
        self.assertEqual(result['status'], 200)
        self.assertEqual(handler.wfile.getvalue(), b'fixture-png')
        self.assertEqual(result['headers']['Content-Type'], 'image/png')
        self.assertEqual(result['headers']['Cache-Control'], 'no-store')
        self.assertEqual(result['headers']['X-Content-Type-Options'], 'nosniff')
        self.assertEqual(result['headers']['Content-Security-Policy'], host.CSP)
        backend.media.assert_called_once_with('fixture-http-only-session',
            {'storeId': STORE, 'leadId': LEAD, 'kind': 'cover'})

    def test_duplicate_missing_and_extra_media_query_fields_never_reach_backend(self):
        query = urlencode({'storeId': STORE, 'leadId': LEAD, 'kind': 'cover'})
        for invalid in (query + '&kind=author', query + '&url=https%3A%2F%2Fattacker.invalid',
                        urlencode({'leadId': LEAD, 'kind': 'cover'})):
            with self.subTest(query=invalid):
                handler, backend, result = self.handler(invalid)
                handler.do_GET()
                self.assertEqual(result['status'], 400)
                backend.media.assert_not_called()


if __name__ == '__main__':
    unittest.main(verbosity=2)
