// Actual source functions, synthetic state only; no browser, network or product writes.
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {fileURLToPath, pathToFileURL} from 'node:url';
import {resolve, dirname} from 'node:path';

const W = dirname(fileURLToPath(import.meta.url));
const P = resolve(W, '../..');
const UI = resolve(P, 'work/ui-approved-implementation/ui-preview');
const source = await readFile(resolve(UI, 'app.mjs'), 'utf8');
const start = source.indexOf('function navButton(');
const end = source.indexOf('\nfunction login(', start);
assert(start >= 0 && end > start, 'Actual app shell source must be discoverable');
const shellSource = source.slice(start, end);
const expected = [['acquire', '获客'], ['reply', '回复'], ['customers', '客户'], ['accounts', '账号'], ['rules', '管理']];
const titles = Object.fromEntries(['acquire', 'reply', 'customers', 'accounts', 'rules', 'tone', 'presets'].map(p => [p, [p, '']]));
const text = html => html.replace(/<[^>]*>/g, '').trim();
const checks = [];
let failed = 0;
async function test(name, check) {
  try { await check(); checks.push({name, status: 'PASS'}); }
  catch (error) { failed++; checks.push({name, status: 'FAIL', error: error.message}); }
}

function render(page) {
  const state = {page, connection: 'connected', session: {user: {username: 'alice', role: 'operator'}},
    user: 'alice', storeId: 'fixture-store-a', store: '合成门店', capabilities: {}};
  return new Function('state', 'localDates', 'esc', 'icon', 'titles', 'acquireStats',
    shellSource + '; return shell("<p>synthetic content</p>");')(
      state, () => ({long: '2026年10月18日', short: '10月18日', iso: '2026-10-18'}),
      value => String(value ?? ''), () => '<img alt="">', titles, () => '');
}

for (const page of ['acquire', 'reply', 'customers', 'accounts', 'rules', 'tone']) {
  await test(`five stable primary destinations while viewing ${page}`, () => {
    const html = render(page), nav = html.match(/<nav\b[^>]*aria-label="主导航"[^>]*>([\s\S]*?)<\/nav>/)?.[1];
    assert(nav, 'Primary navigation must retain its accessible name');
    const destinations = [...nav.matchAll(/<button\b[^>]*data-nav="([^"]+)"[^>]*>([\s\S]*?)<\/button>/g)]
      .map(match => [match[1], text(match[2])]);
    assert.deepEqual(destinations, expected, 'Account and management pages must keep the same five primary destinations');
  });
}

globalThis.location = {origin: 'http://127.0.0.1:54321', href: 'http://127.0.0.1:54321/'};
const avatars = await import(pathToFileURL(resolve(UI, 'avatar.mjs')).href);
const media = `/api/workbench/media?storeId=fixture-store-a&leadId=${'1'.repeat(32)}&kind=author`;
await test('avatar helper accepts the fixed authenticated same-origin media path', () => {
  const accepted = avatars.customerAvatarUrl(media);
  assert(accepted, 'Saved same-origin media path should be renderable under the existing CSP');
  const url = new URL(accepted, location.origin);
  assert.equal(url.origin, location.origin);
  assert.equal(url.pathname, '/api/workbench/media');
  const html = avatars.customerAvatar({name: '合成客户', avatarUrl: media});
  assert(html.includes('/api/workbench/media?'), 'Customer renderer must not replace a valid saved-media path with fallback');
});
await test('avatar helper refuses arbitrary media URLs, kinds and duplicate parameters', () => {
  for (const invalid of [media + '&url=https%3A%2F%2Fattacker.invalid', media + '&kind=cover',
    media.replace('kind=author', 'kind=arbitrary'), '/api/workbench/media?kind=author',
    'https://attacker.invalid/api/workbench/media?storeId=a&leadId=' + '1'.repeat(32) + '&kind=author']) {
    assert.equal(avatars.customerAvatarUrl(invalid), '', `Untrusted image path was accepted: ${invalid}`);
  }
});

console.log(JSON.stringify({passed: checks.length - failed, failed, checks, scope: 'Actual source behavior with synthetic state; no UI, network or product mutation.'}, null, 2));
process.exitCode = failed ? 1 : 0;
