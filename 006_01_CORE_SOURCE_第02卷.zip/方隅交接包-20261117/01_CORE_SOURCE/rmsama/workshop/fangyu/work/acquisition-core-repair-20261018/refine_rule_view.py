from pathlib import Path
P=Path(__file__).resolve().parents[2]
p=P/'work/ui-approved-implementation/ui-preview/pages/management-rules.mjs';s=p.read_text('utf-8')
s=s.replace('overview.canManage&&overview.criteria','overview.can_manage&&overview.criteria')
s=s.replace('保存搜索模式、意向偏好及本门店选词；','本机保存搜索模式、意向偏好及本门店选词；')
s=s.replace("state.materials?.central?.revision||state.materials?.version||'未提供'", "state.materials?.central?.revision||v.search?.libraryReference?.version||state.materials?.version||'未提供'")
s=s.replace("${status.active?'':list(rule.budgetPrinciples).slice(0,3).map(text=>`<p>${escape(text)}</p>`).join('')}","${list(rule.budgetPrinciples).map(text=>`<p>${escape(text)}</p>`).join('')}${list(rule.incomePrinciples).map(text=>`<p>${escape(text)}</p>`).join('')}")
s=s.replace('<h2>客户判断</h2></header>', '<h2>客户判断</h2>${state.session?.user?.role===\'admin\'?\'<button type="button" class="mr-overview" data-mr-central>中央规则文件</button>\':\'\'}</header>')
needle="  root.querySelectorAll('[data-mr-detail]')"
if "root.querySelector('[data-mr-central]')" not in s:
    s=s.replace(needle,"  root.querySelector('[data-mr-central]')?.addEventListener('click',()=>{\n    if(!disposed&&scope(ctx.state)===boundScope&&ctx.state.session?.user?.role==='admin')ctx.actions?.openRuleFiles?.();\n  });\n"+needle)
p.write_text(s,'utf-8')
print('Rule scope, provenance, existing admin route and public source principles refined.')
