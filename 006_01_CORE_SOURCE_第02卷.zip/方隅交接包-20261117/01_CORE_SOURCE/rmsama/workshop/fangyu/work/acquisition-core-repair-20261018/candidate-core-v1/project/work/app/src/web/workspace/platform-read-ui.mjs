/* Operator-only, one-page reads and explicit local receipt archives. IO is injected. */
const PLATFORMS={xiaohongshu:'小红书',douyin:'抖音',zhihu:'知乎',wechat_channels:'视频号',bilibili:'哔哩哔哩',kuaishou:'快手',weibo:'微博'};
const PRIMARY_PLATFORMS=new Set(['xiaohongshu','douyin','wechat_channels']);
const OPERATIONS={search:'单词搜索一页',comments:'读取指定作品一页评论',content:'读取指定作品正文'};
const STORED_STATES=new Set(['ready','unverified','connected_unverified','login_required','expired','credential_present','session_recovery_required','identity_unverified','duplicate_identity','logging_in','unknown']);
const STORED_LABELS={ready:'已有连接记录，实时状态待核对',unverified:'身份尚未核实',connected_unverified:'已有连接记录，身份待核实',login_required:'需要登录',expired:'登录已过期',credential_present:'已有凭据记录，连接待核对',session_recovery_required:'需要恢复本人会话',identity_unverified:'本人身份待核实',duplicate_identity:'账号身份重复，需核对',logging_in:'登录处理中',unknown:'状态待核对'};
const AVAILABILITY=new Set(['ready_for_guarded_read','policy_blocked','guard_hold','license_pending','not_installed','unsupported','account_unverified','contract_pending']);
const CODES={completed:'本页来源已读取；客户意向与成交尚未确认。',cancelled:'本地结果已取消，已发出的只读请求仍可能完成。',policy_blocked:'服务端尚未开放此平台。',guard_hold:'当前安全门禁暂停读取，请先核实。',scope_hold:'本人账号、电脑或授权范围已变化，读取保持暂停。',license_pending:'此路线的商业使用许可尚未确认。',not_installed:'读取运行链尚未完整安装或接线。',unsupported:'此平台尚未接入该只读能力。',account_unverified:'账号或会话身份尚未核实。',contract_pending:'此搜索路线尚未完成原契约验证。',busy:'账号已有操作，本次不自动重试。',protocol_hold:'来源结果无法可靠核对，保持暂停。',timeout_hold:'读取超时，原请求待核对；不会自动重试。',read_hold:'读取未完成，原请求待核对；不会自动重试。',ready_for_guarded_read:'本机存储与配置预检允许受控读取；不是实时登录证明。'};
const ARCHIVE_ACTION='platform_read_archive',opaque=value=>typeof value==='string'&&/^[A-Za-z0-9_-]{8,128}$/.test(value);
const TARGET_ACTION='platform_archive_reply_target_bind',TARGET_GET='platform_archive_reply_target_get',leadId=value=>typeof value==='string'&&/^[A-Za-z0-9][A-Za-z0-9_-]{0,159}$/.test(value);

const SOURCE_ACTION='source_intent_analyze_selected',SOURCE_STATUS='source_intent_analysis_status';
const sourceKey=value=>typeof value==='string'&&/^[A-Za-z0-9._:-]{8,128}$/.test(value);
export function checkedSourceAnalysis(value,{key,readOnly=false}={}){
  const fields=['operation_action','idempotency_key','operation_id','state','mutation_committed','selected_count','analyzed','cache_hits','analysis_complete','original_request_id','attempt_status','refresh_required','read_only','auto_retry','retry_allowed','billing_verified','platform_requests_started','tasks_created','reply_allowed','real_platform_verified','local_only'];
  const fail=()=>{throw Error('原意向分析回执待核对；保留原编号，暂勿重复分析。');};
  if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==fields.length||fields.some(name=>!Object.hasOwn(value,name))||value.operation_action!==SOURCE_ACTION||!sourceKey(value.idempotency_key)||key&&value.idempotency_key!==key||!/^[a-f0-9]{64}$/.test(value.operation_id||'')||!['succeeded','not_committed','unknown'].includes(value.state)||![true,false,null].includes(value.mutation_committed)||value.read_only!==readOnly||value.local_only!==true||value.tasks_created!==0)fail();
  for(const name of ['auto_retry','retry_allowed','billing_verified','platform_requests_started','reply_allowed','real_platform_verified'])if(value[name]!==false)fail();
  for(const name of ['selected_count','analyzed','cache_hits'])if(!Number.isSafeInteger(value[name])||value[name]<0||value[name]>20)fail();
  if(value.analyzed>value.selected_count||value.cache_hits>value.selected_count||typeof value.analysis_complete!=='boolean'||typeof value.refresh_required!=='boolean'||value.original_request_id!==null&&!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(value.original_request_id))fail();
  if(value.state==='succeeded'&&(value.mutation_committed!==true||value.analysis_complete!==true||value.selected_count<1||value.analyzed!==value.selected_count)||value.state==='not_committed'&&(value.mutation_committed!==false||value.analysis_complete||value.analyzed!==0)||value.analysis_complete&&(value.mutation_committed!==true||value.analyzed!==value.selected_count||value.selected_count<1))fail();
  const attempt=value.attempt_status;
  if(attempt!==null){
    const names=['request_id','operation_kind','state','execution_confirmed','execution_kind','result_available','requires_revalidation','reservation_retained','read_only','retry_allowed','billing_verified'];
    const extra=['current_submission_no_dispatch','proof_scope'];
    if(!attempt||typeof attempt!=='object'||Array.isArray(attempt)||names.some(name=>!Object.hasOwn(attempt,name))||Object.keys(attempt).some(name=>!names.includes(name)&&!extra.includes(name))||attempt.request_id!==value.original_request_id||attempt.operation_kind!=='intent_analyze'||attempt.read_only!==true||attempt.retry_allowed!==false||attempt.billing_verified!==false||!['unknown','succeeded','known_unbilled','completed_no_result','legacy_untracked'].includes(attempt.state)||![true,false,null].includes(attempt.execution_confirmed)||![true,false,null].includes(attempt.reservation_retained)||![null,'cache_hit','provider_result','known_unbilled','unknown'].includes(attempt.execution_kind)||typeof attempt.result_available!=='boolean'||typeof attempt.requires_revalidation!=='boolean')fail();
    if(extra.some(name=>Object.hasOwn(attempt,name))&&(attempt.current_submission_no_dispatch!==true||attempt.proof_scope!=='current_submission'||attempt.state!=='legacy_untracked'))fail();
  }
  return value;
}

const WX_PURPOSE='wechat_channels_single_session_preview';
const node=(tag,text='',className='')=>{const result=document.createElement(tag);result.textContent=String(text);if(className)result.className=className;return result;};
const addButton=(host,label,handler)=>{const control=node('button',label,'secondary');control.type='button';control.onclick=()=>void handler(control);host.append(control);return control;};
const field=(host,label,name,{value='',type='text',maxLength,min,max}={})=>{const wrap=node('label',label),control=node('input');control.name=name;control.type=type;control.value=String(value);if(maxLength)control.maxLength=maxLength;if(min!==undefined)control.min=String(min);if(max!==undefined)control.max=String(max);if(type==='number')control.step='1';wrap.append(control);host.append(wrap);return control;};
const choice=(host,label,name,rows,value='')=>{const wrap=node('label',label),control=node('select');control.name=name;for(const [key,text] of rows){const option=node('option',text);option.value=key;control.append(option);}control.value=value;wrap.append(control);host.append(wrap);return control;};
const textValue=(value,max,required=false)=>{if(typeof value!=='string'||value.length>max||required&&!value.trim()||/[\p{Cc}\p{Cs}]/u.test(value))throw Error('读取范围格式无效，请核对长度与内容。');return value.trim();};
const integer=(value,min,max)=>{if(!/^\d+$/.test(String(value))||!Number.isSafeInteger(Number(value))||Number(value)<min||Number(value)>max)throw Error(`数量或页码须为${min}–${max}的整数。`);return Number(value);};
const accountSignature=account=>JSON.stringify([account.id,account.platform,account.status,account.conn_id,account.platform_uid,account.tenant_id,account.cloud_owner,account.disabled,account.revoked]);
const safeLink=(value,platform)=>{try{const url=new URL(value),hosts={xiaohongshu:['xiaohongshu.com','www.xiaohongshu.com'],douyin:['douyin.com','www.douyin.com'],zhihu:['www.zhihu.com'],bilibili:['www.bilibili.com'],kuaishou:['www.kuaishou.com'],weibo:['weibo.com']}[platform]||[];if(url.protocol!=='https:'||url.username||url.password||url.port||!hosts.includes(url.hostname)||platform==='weibo'&&!/^\/[1-9][0-9]{0,31}\/[A-Za-z0-9]{1,32}$/.test(url.pathname))return '';if(platform==='weibo'){url.search='';url.hash='';}return url.href;}catch{return '';}};

function checkedStatus(value,platform){
  if(!value||value.schema_version!==1||value.platform!==platform||!STORED_STATES.has(value.stored_status)||value.status_evidence!=='stored_account_record'||value.live_checked!==false||value.platform_writes!==false||value.real_platform_verified!==false||value.dm_supported!==false||!Array.isArray(value.supported_reads)||value.supported_reads.some(item=>!Object.hasOwn(OPERATIONS,item))||!value.read_availability||Object.keys(OPERATIONS).some(item=>!AVAILABILITY.has(value.read_availability[item])))throw Error('存储状态回执待核对。');
  if(platform==='weibo'&&!AVAILABILITY.has(value.read_availability.self))throw Error('本人核实预检回执待核对。');
  return value;
}
function checkedResult(value,job){
  if(!value||value.schema_version!==1||value.platform!==job.platform||value.action!==job.operation||value.auto_retry!==false||value.platform_writes!==false||value.real_platform_verified!==false||value.receipt_scope!=='this_process_only'||!Object.hasOwn(CODES,value.code)||!['completed','cancelled','held','restricted'].includes(value.status)||!Array.isArray(value.items)||typeof value.operation_id!=='string')throw Error('读取回执范围或状态待核对。');
  const expected=value.code==='completed'?'completed':value.code==='cancelled'?'cancelled':value.code.endsWith('_hold')||value.code==='busy'?'held':'restricted';
  if(value.status!==expected||value.code!=='completed'&&value.items.length)throw Error('读取回执状态不一致。');
  if(value.code==='completed'&&job.operation==='self'){
    if(job.platform!=='weibo'||value.identity_observed!==true||value.account_uid_known!==true||value.items.length||value.archive_available!==false)throw Error('本人账号核实回执待核对。');
  }else if(value.code==='completed'){
    const page=value.page;
    if(!Number.isSafeInteger(value.observed_count)||value.observed_count!==value.items.length||value.items.length>1000||value.requested_limit!==job.data.limit||value.limit_exceeded!==(value.items.length>job.data.limit)||!page||![true,false,null].includes(page.has_more)||typeof page.cursor!=='string'||page.cursor.length>512||/[\p{Cc}\p{Cs}]/u.test(page.cursor)||typeof page.bounded!=='boolean'||page.pagination_verified!==(page.has_more!==null))throw Error('本页数量或分页证据待核对。');
    const seen=new Set();
    for(const item of value.items){
      if(!item||item.platform!==job.platform||!['note','comment'].includes(item.source_type)||typeof item.source_uid!=='string'||!new RegExp('^'+job.platform+':[a-f0-9]{64}$').test(item.source_uid)||seen.has(item.source_uid)||typeof item.post_id!=='string'||!item.post_id||typeof item.source_id!=='string'||!item.source_id||typeof item.comment_id!=='string'||item.source_type==='comment'&&item.comment_id!==item.source_id||typeof item.url!=='string'||typeof item.text!=='string'||item.text.length>32000||typeof item.author_id!=='string'||typeof item.author_uid!=='string'||item.author_identity!==(item.author_id?'platform_id':'not_provided')||item.content_status!==(item.text?'provided':'not_provided')||item.evidence_level!=='transport_reported')throw Error('本页原始来源身份待核对。');
      seen.add(item.source_uid);
      if(item.author_id&&!new RegExp('^'+job.platform+':author:[a-f0-9]{64}$').test(item.author_uid)||!item.author_id&&item.author_uid)throw Error('本页作者身份键待核对。');
    }
  }
  if(job.platform==='wechat_channels'&&value.code==='completed'&&(value.purpose!==WX_PURPOSE||value.source_verification!=='transport_reported_only'||value.identity_verified!==false||value.account_isolation!==false||value.account_ready!==false||value.archive_available!==false||value.items.length>20||value.items.length>job.data.limit||value.page.has_more!==null||value.page.cursor!==''||value.page.bounded!==true))throw Error('视频号仅限未核身份的首一页预览，不可保存来源。');
  if(value.archive_available===true&&(job.operation!=='comments'||value.code!=='completed'||value.limit_exceeded!==false||value.archive_request_id!==job.data.request_id||value.archive_account_id!==job.account_id||value.reply_target_verified!==false||!value.items.length||value.items.length>100||value.items.some(item=>item.source_type!=='comment'||!item.text.trim()||item.text.length>3000)))throw Error('来源保存许可与原读取编号不一致。');
  return value;
}

export function checkedArchive(value,key){
  if(!value||value.operation_action!==ARCHIVE_ACTION||!opaque(value.idempotency_key)||key&&value.idempotency_key!==key||!['succeeded','not_committed'].includes(value.state)||typeof value.replayed!=='boolean'||typeof value.operation_id!=='string'||!/^[a-f0-9]{64}$/.test(value.operation_id)||value.auto_retry!==false||value.local_only!==true||value.storage_scope!=='this_device'||value.cross_machine_verified!==false||value.platform_requests_started!==false)throw Error('来源保存回执待核对。');
  if(value.state==='not_committed'){if(value.mutation_committed!==false)throw Error('来源保存状态不一致。');return value;}
  const counts=['inserted','duplicate_count','accepted_count','privacy_redacted_count'],flags=['reply_allowed','reply_target_verified','customer_identity_verified','resource_receipt_verified','real_platform_verified'];
  if(value.mutation_committed!==true||value.refresh_required!==true||counts.some(name=>!Number.isSafeInteger(value[name])||value[name]<0||value[name]>100)||value.accepted_count<1||value.inserted+value.duplicate_count!==value.accepted_count||value.privacy_redacted_count>value.accepted_count||flags.some(name=>value[name]!==false)||!Array.isArray(value.lead_ids)||value.lead_ids.length!==value.accepted_count||new Set(value.lead_ids).size!==value.lead_ids.length||value.lead_ids.some(id=>typeof id!=='string'||!/^[A-Za-z0-9][A-Za-z0-9_-]{0,159}$/.test(id)))throw Error('来源保存数量或回复边界待核对。');
  return value;
}

export function checkedReplyTarget(value,{lead:expectedLead,key,readOnly=true}={}){
  const fields=['lead_id','platform','channel','state','reason','binding_id','operation_action','idempotency_key','routing_source_matched','can_prepare_comment_reply','send_allowed','send_requires_existing_confirmation','read_only','mutation_committed','refresh_required','local_only','storage_scope','cross_machine_verified','real_platform_verified','platform_requests_started','provider_requests_started','auto_retry'];
  const fail=()=>{throw Error('原评论本机回复目标回执待核对，继续保留原编号。');};
  if(!value||Object.keys(value).length!==fields.length||fields.some(name=>!Object.hasOwn(value,name))||!leadId(value.lead_id)||expectedLead&&value.lead_id!==expectedLead||value.platform!=='xiaohongshu'||value.channel!=='comment'||!['bound','not_bound','stale'].includes(value.state)||typeof value.reason!=='string'||!/^[a-z_]{1,100}$/.test(value.reason)||value.read_only!==readOnly||typeof value.mutation_committed!=='boolean'||value.refresh_required!==!readOnly||value.send_allowed!==false||value.send_requires_existing_confirmation!==true||value.local_only!==true||value.storage_scope!=='this_device'||['cross_machine_verified','real_platform_verified','platform_requests_started','provider_requests_started','auto_retry'].some(name=>value[name]!==false))fail();
  const bound=value.state==='bound',hasBinding=value.binding_id!==null;
  if(value.routing_source_matched!==bound||value.can_prepare_comment_reply!==bound||value.mutation_committed!==(!readOnly&&bound)||hasBinding&&(!/^[a-f0-9]{64}$/.test(value.binding_id)||value.operation_action!==TARGET_ACTION||!opaque(value.idempotency_key))||!hasBinding&&(value.operation_action!==null||value.idempotency_key!==null)||bound&&!hasBinding||value.state==='not_bound'&&hasBinding||key&&value.idempotency_key!==key)fail();
  return value;
}

export function createPlatformReadUI({createDialog,read,scope,getContext,write,perform,pending:pendingOperation,recover,openItem=null,closeDialog=null,onAnalyzed=null}){
  for(const [name,value] of Object.entries({createDialog,read,scope,getContext}))if(typeof value!=='function')throw Error(`平台读取缺少${name}接口`);
  let generation=0,disposed=false,activeView=null;
  function clear(){generation++;if(activeView){for(const item of activeView.root.querySelectorAll('input,textarea'))item.value='';activeView.root.replaceChildren();activeView.root.close?.();activeView.root.remove();activeView=null;}}
  async function open(){
    if(disposed)return;clear();const own=++generation,principal=scope(),view=createDialog('主平台 · 经营者单页读取');activeView=view;
    const current=()=>!disposed&&own===generation&&principal===scope()&&view.current();
    const guard=()=>{if(current())return true;if(own===generation)clear();return false;};
    const report=(message,error=false)=>{if(!guard())return;view.status.textContent=message;view.status.dataset.state=error?'error':'info';};
    const load=async(action,data)=>{if(!guard())throw Error('当前身份已变化');const result=await read(action,data);if(!guard())throw Error('当前身份已变化');return result;};
    const host=node('section','','upgrade-operation-form');view.root.append(host);
    host.append(node('h3','小红书 / 抖音 / 视频号'),node('p','当前重点为小红书，抖音和视频号为次重点。知乎、B站、微博退出本轮读取；原账号记录仍在账号页保留。快手仅有本地演示样例，不在这里真实读取。','upgrade-muted'));
    host.append(node('p','仅本人逐次读取。允许保存的评论可另存为本机来源；保存后仍须核对客户身份与回复目标，不确认客户意向、资源部接收或成交。','upgrade-muted'),node('p','读取与取消回执只在当前进程有效；重启恢复未接入。保存结果未知时只核对原编号，不自动重试；关闭窗口不会撤销已发出的读取。','upgrade-muted'));
    let status=null,statusSequence=0,inputGeneration=0,pending=null,form,account,operation,keyword,reference,limit,page,cursor,refresh,verify,selfKey,checkSelf,submit,cancel,resultHost,statusHost,archiveTarget,save,checkSave,archiveHost,archiveReceipt=null,archiveBusy=false,archiveSaved=false,archivedSelection,replyTarget,bindTarget,checkTarget,targetHost,targetBusy=false,targetGeneration=0,targetReceipt=null,savedIds=[],savedRead='',savedAccount=null,analysisBusy=false,analysisCity,analysisArea,analysisConfirm,analysisKey,analyzeSources,checkAnalysis,analysisHost,archiveSection,analysisSection,targetSection;
    const archiveEnabled=[write,perform,pendingOperation,recover].every(value=>typeof value==='function');
    const directory=()=>{const values=getContext()?.accounts;return Array.isArray(values)?values.filter(item=>item&&typeof item.id==='string'&&item.id&&Object.hasOwn(PLATFORMS,item.platform)):[];};
    const accounts=()=>directory().filter(item=>PRIMARY_PLATFORMS.has(item.platform));
    const selected=()=>accounts().find(item=>item.id===account?.value);
    const currentReadAccount=(id,platform,signature)=>{const value=selected();return !!value&&PRIMARY_PLATFORMS.has(value.platform)&&value.id===id&&value.platform===platform&&accountSignature(value)===signature;};
    const sameAccount=job=>{const value=selected();return !!value&&value.id===job.account_id&&accountSignature(value)===job.account_signature;};
    const archivePending=()=>{if(!archiveEnabled||!opaque(archiveTarget?.value))return null;try{const value=pendingOperation(ARCHIVE_ACTION,archiveTarget.value);return value?opaque(value.idempotency_key)&&value.action===ARCHIVE_ACTION?value:{invalid:true}:null;}catch{return {invalid:true};}};
    const analysisPending=()=>{if(!archiveEnabled||!opaque(savedRead))return null;try{const value=pendingOperation(SOURCE_ACTION,savedRead);return value?sourceKey(value.idempotency_key)&&value.action===SOURCE_ACTION?value:{invalid:true}:null;}catch{return {invalid:true};}};
    const analysisScope=()=>JSON.stringify([savedRead,savedIds,savedAccount,selected()?accountSignature(selected()):null]);
    const targetPending=()=>{if(!archiveEnabled||!leadId(replyTarget?.value))return null;try{const value=pendingOperation(TARGET_ACTION,replyTarget.value);return value?opaque(value.idempotency_key)&&value.action===TARGET_ACTION?value:{invalid:true}:null;}catch{return {invalid:true};}};
    let commentPreview=null,commentPreviewHost=null;
    const clearTarget=()=>{targetGeneration++;targetReceipt=null;commentPreview=null;targetHost?.replaceChildren();commentPreviewHost?.replaceChildren();};
    const invalidateArchive=()=>{archiveReceipt=null;archiveSaved=false;savedIds=[];savedRead='';savedAccount=null;if(analysisConfirm)analysisConfirm.checked=false;analysisHost?.replaceChildren();archiveHost?.replaceChildren();archivedSelection?.replaceChildren(node('option','请先保存来源'));clearTarget();};
    const sync=()=>{
      if(!guard()||!form)return;const original=archivePending(),targetOriginal=targetPending(),busy=!!pending||archiveBusy||targetBusy||analysisBusy||!!original||!!targetOriginal;
      for(const control of form.querySelectorAll('input,select'))control.disabled=busy;
      refresh.disabled=busy||!selected();
      verify.hidden=selected()?.platform!=='weibo';verify.disabled=busy||selected()?.platform!=='weibo'||status?.read_availability?.self!=='ready_for_guarded_read'||!!selfKey.value;
      checkSelf.hidden=verify.hidden;checkSelf.disabled=archiveBusy||targetBusy||!!original||!!targetOriginal||selected()?.platform!=='weibo'||!opaque(selfKey.value)||!!pending&&(pending.operation!=='self'||pending.running||pending.cancelling);
      const supported=!!status?.supported_reads?.includes(operation.value);
      submit.disabled=busy||!selected()||!supported||status?.read_availability?.[operation.value]!=='ready_for_guarded_read';
      cancel.disabled=!pending||pending.cancelling;
      keyword.disabled=busy||operation.value!=='search';reference.disabled=busy||operation.value==='search';
      page.disabled=busy||!(operation.value==='search'&&['xiaohongshu','douyin'].includes(selected()?.platform));
      cursor.disabled=busy||!(operation.value==='comments'&&['xiaohongshu','douyin'].includes(selected()?.platform));
      limit.max=selected()?.platform==='wechat_channels'?'20':'100';
      for(const section of [archiveSection,analysisSection,targetSection])if(section)section.hidden=selected()?.platform==='wechat_channels';
      archiveTarget.disabled=!!pending||archiveBusy;
      save.disabled=!archiveEnabled||busy||archiveSaved||!archiveReceipt||archiveTarget.value!==archiveReceipt.data.request_id||archiveReceipt.input_generation!==inputGeneration||!sameAccount(archiveReceipt);
      if(analyzeSources){const sourceOriginal=analysisPending(),sourceUsable=archiveSaved&&savedIds.length>0&&savedIds.length<=20&&savedAccount&&sameAccount(savedAccount)&&archiveTarget.value===savedRead;
        for(const control of [analysisCity,analysisArea,analysisConfirm])control.disabled=busy||!!sourceOriginal;
        analyzeSources.disabled=!archiveEnabled||busy||!!sourceOriginal||!sourceUsable||!analysisCity.value.trim()||!analysisConfirm.checked;
        checkAnalysis.disabled=!archiveEnabled||busy||!sourceKey(analysisKey.value)||sourceOriginal?.invalid===true;analysisKey.disabled=busy;
      }
      checkSave.disabled=!archiveEnabled||!!pending||archiveBusy||!original||original.invalid===true;
      if(replyTarget){replyTarget.disabled=!!pending||archiveBusy||targetBusy;archivedSelection.disabled=busy;bindTarget.disabled=!archiveEnabled||busy||!!targetReceipt||commentPreview?.id!==replyTarget.value||!savedIds.includes(replyTarget.value)||archiveTarget.value!==savedRead||!savedAccount||!sameAccount(savedAccount);checkTarget.disabled=!archiveEnabled||!!pending||archiveBusy||targetBusy||!leadId(replyTarget.value)||targetOriginal?.invalid===true;}
    };
    const changed=()=>{if(!guard())return;inputGeneration++;resultHost?.replaceChildren();invalidateArchive();if(pending){pending.discard=true;report('读取范围已变化，原请求待核对；请先取消原请求，暂勿重复读取。',true);}sync();};
    async function readStatus(){
      if(!guard()||pending||archiveBusy||archivePending())return;const value=selected(),seq=++statusSequence;status=null;resultHost.replaceChildren();invalidateArchive();sync();
      if(!value){statusHost.replaceChildren(node('p','当前没有本人可用账号。请在平台账号页核对现有账号，本页不新建或登录账号。'));return;}
      const signature=accountSignature(value),id=value.id;refresh.disabled=true;
      try{
        const manager=await load('strategy_get',{});if(!guard()||seq!==statusSequence||!currentReadAccount(id,value.platform,signature))return;
        if(manager?.can_manage!==true)throw Error('permission');
        const answer=await load('platform_read_status',{account_id:id});if(!guard()||seq!==statusSequence)return;
        if(selected()?.id!==id||accountSignature(selected())!==signature){report('账号记录已变化，请重新读取存储状态。',true);return;}
        status=checkedStatus(answer,value.platform);statusHost.replaceChildren(node('h3',`${PLATFORMS[value.platform]} · 账号记录：${STORED_LABELS[answer.stored_status]||'状态待核对'}`),node('p','仅已有账号记录和本地配置，未实时检查登录，也未向平台请求。','upgrade-muted'));
        for(const [name,label] of Object.entries(OPERATIONS))statusHost.append(node('p',`${label}：${CODES[answer.read_availability[name]]}`));
        if(answer.platform==='weibo')statusHost.append(node('p',`本人账号核实：${CODES[answer.read_availability.self]}`));
        statusHost.append(node('p',answer.account_uid_known===true?'已存账号平台UID；仍不是本次真人登录证明。':'账号平台UID尚未存储。'),node('p','私信与发送未在本表单接入。'));
        if(value.platform==='wechat_channels')statusHost.append(node('p','视频号仅预览当前绑定页面的第一批，最多20条；本人UID和账号隔离均未核实。没有翻页、客户保存、意向分析或发送入口。','upgrade-muted'));
        report('已读取本机状态。可逐次执行已允许的只读能力，受限原因保留。');
      }catch{if(guard()&&seq===statusSequence){status=null;statusHost.replaceChildren();report('经营者权限或存储状态未确认，请核对后重新读取。',true);}}
      finally{if(guard()&&seq===statusSequence)sync();}
    }
    function render(value,job){
      resultHost.replaceChildren(node('h3',`${OPERATIONS[job.operation]} · ${value.observed_count} 条来源`),node('p',`本次请求编号：${job.data.request_id} · 本机操作编号：${value.operation_id}`,'upgrade-muted'));
      if(value.limit_exceeded)resultHost.append(node('p',`实际返回 ${value.observed_count} 条，超过期望 ${value.requested_limit} 条；全部保留，未静默截断。`));
      resultHost.append(node('p',value.page.has_more===true?'平台报告仍有下一页。':value.page.has_more===false?'平台报告本页没有后续页。':'是否有下一页尚未核实。'),node('p',`分页证据：${value.page.pagination_verified?'有明确分页标记':'分页未核实'}；读取范围${value.page.bounded?'有界':'边界未核实'}。`));
      if(value.page.cursor)resultHost.append(node('p',`返回游标：${value.page.cursor}`));
      if(value.page.has_more===true)resultHost.append(node('p','下一页需本人核对并另点读取；本页不会自动继续。','upgrade-muted'));
      for(const item of value.items){
        const row=node('article');row.append(node('h4',item.title||'来源标题未提供'),node('p',item.author||'作者名未提供'),node('p',`来源UID：${item.source_uid}`),node('p',`作品ID：${item.post_id} · ${item.source_type==='comment'?'评论ID：'+item.comment_id:'作品正文'}`),node('p',item.author_id?`原平台作者ID：${item.author_id} · 作者身份键：${item.author_uid}`:'平台作者UID未提供，不按昵称归并客户。'),node('p',item.content_status==='not_provided'?'正文未提供，不能据此评级。':item.text),node('p','来源级别：适配器报告，未独立核验真人平台。','upgrade-muted'));
        row.append(node('p',`发布时间：${item.published_at||'未提供'} · 来源地区：${item.region||'未提供'} · 上级评论ID：${item.parent_id||'未提供'}`));
        const url=safeLink(item.url,job.platform);if(url){const link=node('a','原作品链接');link.href=url;link.target='_blank';link.rel='noopener noreferrer';link.onclick=event=>{if(!guard()||pending||!sameAccount(job))event.preventDefault();};row.append(link);}
        if(job.operation==='search'&&item.source_type==='note'&&(job.platform!=='weibo'||/^[1-9][0-9]{0,31}$/.test(item.post_id)))addButton(row,'将这篇作品填入评论范围',()=>{if(!guard()||pending||!sameAccount(job))return;operation.value='comments';reference.value=job.platform==='weibo'?item.post_id:item.url;page.value='1';cursor.value='';changed();report('已更换为指定作品评论范围；尚未向平台读取。');});
        resultHost.append(row);
      }
      if(!value.items.length)resultHost.append(node('p','本页没有返回来源，不代表平台不存在客户。'));
      if(job.platform==='wechat_channels')resultHost.append(node('p','本机页面来源仅由传输报告，身份未核；不可保存客户、分析意向、交接或发送。','upgrade-muted'));
      if(value.archive_available===true){archiveReceipt={...job,observed_count:value.observed_count};archiveTarget.value=job.data.request_id;archiveSaved=false;archiveHost.replaceChildren(node('p','服务端已允许保存此批评论来源。保存引用原回执，不提交页面评论；不会新增平台请求、采集任务、费用或回复。','upgrade-muted'));}
    }
    function savedResult(value){
      archiveSaved=true;archiveHost.replaceChildren(node('h3','已保存来源，回复目标待核对'),node('p',`本机来源 ${value.accepted_count} 条：新增 ${value.inserted} 条，重复 ${value.duplicate_count} 条；隐藏联系方式或受保护信息 ${value.privacy_redacted_count} 条。`),node('p','原评论与作者的路由保留在服务端来源证据中。逐条核对本机回复目标后，可回原详情写草稿并审核；尚未发送，私信未接通，不能据此显示已联系、已送达或已交付。','upgrade-muted'),node('p','仅本机保存；客户身份、跨机器归属与资源部接收均待核对。','upgrade-muted'));
      report('已保存来源，回复目标待核对。');
      savedIds=[...value.lead_ids];savedRead=archiveTarget.value;const account=selected();savedAccount=account?{account_id:account.id,account_signature:accountSignature(account)}:null;
      archivedSelection.replaceChildren();const empty=node('option','请选择一条已保存评论');empty.value='';archivedSelection.append(empty);for(const [index,id] of savedIds.entries()){const option=node('option',`评论 ${index+1} · ${id.slice(0,8)}`);option.value=id;archivedSelection.append(option);}archivedSelection.value='';clearTarget();if(analysisConfirm)analysisConfirm.checked=false;analysisHost?.replaceChildren();
    }

    function showAnalysis(value){
      analysisHost.replaceChildren(node('h3',value.state==='succeeded'?'已完成本机意向分析':value.state==='not_committed'?'原分析未提交':'原分析结果待核对'),node('p',`本批所选 ${value.selected_count} 条；本机已保存评级 ${value.analyzed} 条。`),node('p',`原操作编号：${value.idempotency_key}`,'upgrade-muted'));
      if(value.original_request_id)analysisHost.append(node('p',`原模型请求编号：${value.original_request_id}`,'upgrade-muted'));
      if(value.state==='succeeded')analysisHost.append(node('p','可在意向评论和客户清单按高意向筛选。评级与来源仍需人工核对；联系、资源部接收及成交尚未确认。'));
      else if(value.state==='unknown')analysisHost.append(node('p',value.analysis_complete?'本机评级已保存，完整操作回执仍待核对；保留原编号，暂勿重新分析。':'保留原编号，只核对这次结果；不会自动重新分析。'));
      analysisHost.append(node('p','费用状态沿原请求核对；本机评级成功不代表账单或真实平台身份已核实。','upgrade-muted'));
      if(value.analysis_complete&&value.mutation_committed===true&&typeof onAnalyzed==='function')onAnalyzed();
    }
    async function analyzeSaved(control){
      if(!guard()||selected()?.platform==='wechat_channels'||!archiveEnabled||analysisBusy||pending||archiveBusy||targetBusy||archivePending()||analysisPending())return;
      if(!archiveSaved||!savedIds.length||savedIds.length>20||!savedAccount||!sameAccount(savedAccount)||archiveTarget.value!==savedRead||!analysisConfirm.checked)return;
      let city,area;try{city=textValue(analysisCity.value,80,true);area=textValue(analysisArea.value,80);}catch(error){report(error.message,true);return;}
      const captured=analysisScope(),target=savedRead,ids=[...savedIds];analysisBusy=true;sync();
      try{await perform(view,control,async()=>{
        if(!guard()||analysisScope()!==captured)return;
        try{const answer=checkedSourceAnalysis(await write(SOURCE_ACTION,{lead_ids:ids,city,area},target));if(!guard()||analysisScope()!==captured)return;if(answer.state!=='succeeded'||answer.selected_count!==ids.length)throw Error('所选分析结果仍待核对。');analysisKey.value=answer.idempotency_key;analysisConfirm.checked=false;showAnalysis(answer);report('已完成本机意向分析，可回意向评论和客户清单核对评级。');}
        catch(error){if(!guard())return;const original=analysisPending();if(sourceKey(original?.idempotency_key))analysisKey.value=original.idempotency_key;report(original?`原分析结果待核对；保留操作编号：${original.idempotency_key}，请点“核对原分析结果”。`:error.message||'原分析结果待核对；不会自动重试。',true);}
      },{message:'正在分析所选本机来源…'});}finally{analysisBusy=false;if(guard())sync();}
    }
    async function checkSourceAnalysis(control){
      if(!guard()||!archiveEnabled||analysisBusy||pending||archiveBusy||targetBusy||!sourceKey(analysisKey.value))return;
      const key=analysisKey.value,captured=analysisScope(),original=analysisPending();if(original?.invalid)return;analysisBusy=true;sync();
      try{await perform(view,control,async()=>{
        if(!guard()||analysisScope()!==captured)return;
        try{const answer=original?.idempotency_key===key?await recover(SOURCE_ACTION,savedRead):await load(SOURCE_STATUS,{idempotency_key:key});if(!guard()||analysisScope()!==captured||analysisKey.value!==key)return;const value=checkedSourceAnalysis(answer.result||answer,{key,readOnly:true});showAnalysis(value);analysisConfirm.checked=false;report(value.state==='succeeded'?'原本机意向分析已确认，请核对评级。':value.state==='not_committed'?'原分析未提交；此核对没有重新分析。':'原分析仍待核对；保留原编号，暂勿重复分析。',value.state==='unknown');}
        catch(error){if(guard())report(error.message||'原分析仍待核对；原编号继续保留。',true);}
      },{message:'只核对原意向分析编号…'});}finally{analysisBusy=false;if(guard())sync();}
    }

    async function previewComment(){
      const id=replyTarget.value,seq=targetGeneration,sourceRead=savedRead;
      if(!leadId(id)||!savedIds.includes(id)||!savedAccount||!sameAccount(savedAccount))return;
      commentPreviewHost.replaceChildren(node('p','正在读取已保存的原评论…'));sync();
      try{
        const detail=await load('lead_detail',{lead_id:id});
        if(!guard()||seq!==targetGeneration||replyTarget.value!==id||savedRead!==sourceRead||!savedAccount||!sameAccount(savedAccount))return;
        if(detail?.id!==id||detail.platform!==selected()?.platform||typeof detail.text!=='string'||!detail.text.trim())throw Error('原评论尚未核对，请重新选择。');
        commentPreview={id};commentPreviewHost.replaceChildren(node('h4','当前选中的原评论'),node('p',typeof detail.author==='string'&&detail.author?detail.author:'昵称未提供'),node('p',detail.text),node('p','请先核对原文，再准备这一条评论的回复。','upgrade-muted'));
      }catch(error){if(guard()&&seq===targetGeneration){commentPreview=null;commentPreviewHost.replaceChildren(node('p','原评论尚未核对，请重新选择。'));}}
      if(guard())sync();
    }
    function showTarget(value){
      targetReceipt=value;targetHost.replaceChildren(node('h3','本机回复目标已核对'),node('p','仅核对本机保存来源与回复路由。尚未向平台发送，不代表已联系、已送达或客户回应。','upgrade-muted'));
      if(typeof openItem==='function')addButton(targetHost,'返回评论详情写草稿',async()=>{
        if(!guard()||targetBusy||targetReceipt!==value||replyTarget.value!==value.lead_id)return;
        const ownGeneration=generation,expectedScope=scope(),item={lead_id:value.lead_id,detail_view:'comment'};
        const accept=()=>!disposed&&ownGeneration===generation&&principal===scope()&&expectedScope===scope();
        // Closing the modal makes view.current false; navigation retains only its original scope/epoch.
        if(typeof closeDialog==='function')closeDialog();else{view.root.close?.();view.root.remove();activeView=null;}
        try{await openItem(item,{accept});}catch{}
      });
      report('本机回复目标已核对；可回原评论详情写草稿，发送仍须原流程确认。');
    }
    async function checkReplyTarget(control,{bind=false}={}){
      if(!guard()||!archiveEnabled||pending||archiveBusy||targetBusy)return;
      const id=replyTarget.value,original=targetPending(),own=targetGeneration;if(!leadId(id)||original?.invalid)return;
      if(bind&&(original||commentPreview?.id!==id||!savedIds.includes(id)||archiveTarget.value!==savedRead||!savedAccount||!sameAccount(savedAccount)))return;
      targetBusy=true;targetReceipt=null;sync();
      try{await perform(view,control,async()=>{
        if(!guard()||own!==targetGeneration)return;
        try{
          const answer=bind?await write(TARGET_ACTION,{lead_id:id,read_request_id:savedRead},id):original?await recover(TARGET_ACTION,id):await load(TARGET_GET,{lead_id:id});
          if(!guard()||own!==targetGeneration||replyTarget.value!==id)return;
          const value=checkedReplyTarget(answer.result||answer,{lead:id,key:original?.idempotency_key,readOnly:!bind});
          if(value.state!=='bound'||original&&answer.resolved!==true){targetHost.replaceChildren(node('p',value.state==='stale'?'原本机回复目标已变化，须核对来源；原未决编号继续保留。':'本机回复目标尚未绑定；缺少记录不表示原操作取消，原未决编号继续保留。','upgrade-muted'));report('本机回复目标仍待核对，未准备草稿或发送。',true);return;}
          showTarget(value);
        }catch{if(guard()&&own===targetGeneration){const kept=targetPending();targetHost.replaceChildren();report(kept&&!kept.invalid?`回复目标结果待核对，保留原操作编号：${kept.idempotency_key}；只按原评论核对，不自动重放。`:'回复目标未确认，请核对本机来源；未新增发送。',true);}}
      });}finally{targetBusy=false;if(guard())sync();}
    }
    async function saveSources(control){
      if(!guard()||selected()?.platform==='wechat_channels'||!archiveEnabled||pending||archiveBusy||archiveSaved||archivePending())return;
      const job=archiveReceipt;if(!job||archiveTarget.value!==job.data.request_id||job.input_generation!==inputGeneration||!sameAccount(job)){invalidateArchive();report('原读取账号或范围已变化，不能保存此批来源。',true);sync();return;}
      archiveBusy=true;sync();
      try{await perform(view,control,async()=>{
        if(!guard()||archiveReceipt!==job||!sameAccount(job)||job.input_generation!==inputGeneration)return;
        try{const value=checkedArchive(await write(ARCHIVE_ACTION,{account_id:job.account_id,read_request_id:job.data.request_id},job.data.request_id));if(!guard())return;if(value.state!=='succeeded'||value.accepted_count!==job.observed_count)throw Error('archive');if(!sameAccount(job)||archiveReceipt!==job){invalidateArchive();report('原保存已返回；账号或范围已变化，请在原账号核对记录。',true);return;}savedResult(value);}
        catch{if(!guard())return;const original=archivePending();report(original&&!original.invalid?`保存结果待核对，保留原操作编号：${original.idempotency_key}；请点“核对保存结果”，暂勿重复保存。`:'保存结果或当前权限未确认，请核对原记录；不会自动重放。',true);}
      });}finally{archiveBusy=false;if(guard())sync();}
    }
    async function checkSaved(control){
      if(!guard()||!archiveEnabled||pending||archiveBusy)return;const target=archiveTarget.value,original=archivePending();if(!original||original.invalid)return;
      archiveBusy=true;sync();
      try{await perform(view,control,async()=>{
        if(!guard())return;
        try{const answer=await recover(ARCHIVE_ACTION,target);if(!guard()||archiveTarget.value!==target)return;const value=checkedArchive(answer.result||answer,original.idempotency_key);if(answer.resolved!==true)throw Error('unknown');if(value.state==='succeeded')savedResult(value);else{invalidateArchive();archiveHost.replaceChildren(node('p','后台已确认原编号未归档，并阻止同编号的迟到保存。核对没有重新读取或保存来源；如需保存，须另行人工核对。','upgrade-muted'));report('原保存未提交；同编号的迟到归档已被阻止。');}}
        catch{if(guard())report(`保存结果仍待核对，继续保留原操作编号：${original.idempotency_key}；不会自动重放。`,true);}
      });}finally{archiveBusy=false;if(guard())sync();}
    }
    async function runRead(){
      if(!guard()||pending||archiveBusy||archivePending())return;const value=selected(),kind=operation.value;
      if(!value||!status?.supported_reads?.includes(kind)||status.read_availability[kind]!=='ready_for_guarded_read'){report('此账号的读取能力仍受限，请先核对存储状态。',true);return;}
      let data;try{data={account_id:value.id,limit:integer(limit.value,1,value.platform==='wechat_channels'?20:100),page:integer(page.value,1,100),cursor:textValue(cursor.value,512)};if(kind==='search')data.keyword=textValue(keyword.value,200,true);else data.reference=textValue(reference.value,2048,true);if(data.page!==1&&!(kind==='search'&&['xiaohongshu','douyin'].includes(value.platform)))throw Error('此路线不支持指定页码。');if(data.cursor&&!(kind==='comments'&&['xiaohongshu','douyin'].includes(value.platform)))throw Error('此路线不支持游标续读。');}catch(error){report(error.message,true);return;}
      const job={operation:kind,platform:value.platform,account_id:value.id,account_signature:accountSignature(value),input_generation:inputGeneration,data,running:true,cancelling:false,discard:false};pending=job;invalidateArchive();sync();resultHost.replaceChildren();report('正在核对经营者权限与本次读取范围…');
      try{
        const manager=await load('strategy_get',{});if(!guard()||pending!==job)return;if(!currentReadAccount(job.account_id,job.platform,job.account_signature)){pending=null;status=null;report('账号或平台范围已变化，请重新选择主平台账号。',true);return;}if(manager?.can_manage!==true){pending=null;status=null;report('当前身份没有经营者读取权限。',true);return;}
        if(job.discard||job.input_generation!==inputGeneration||!sameAccount(job)){job.discard=true;report('账号或范围已变化，未新增读取；请取消原编号后重新核对。',true);return;}
        data.request_id=crypto.randomUUID();
        const answer=await load('platform_read_'+kind,data);if(!guard()||pending!==job)return;
        if(job.platform==='wechat_channels'&&job.cancelRequested){checkedResult(answer,job);job.wechatReadReturned=true;job.discard=true;if(job.cancelAcknowledged){pending=null;status=null;report('视频号原读取已结束，取消后的来源未保存或显示。');}else report('视频号原读取已结束，仍等待取消回执；取消后的来源未保存或显示。');return;}
        if(job.discard||job.cancelling||job.input_generation!==inputGeneration||!sameAccount(job)){job.discard=true;report('账号、范围或取消状态已变化，迟到来源不显示；原请求待核对。',true);return;}
        const result=checkedResult(answer,job);
        if(result.code==='completed'){render(result,job);pending=null;report(CODES.completed);}
        else if(['timeout_hold','read_hold','protocol_hold','busy'].includes(result.code)){report(`${CODES[result.code]} 原编号：${data.request_id}`,true);}
        else{pending=null;status=null;report(CODES[result.code],result.code!=='cancelled');}
      }catch{if(guard()&&pending===job){job.discard=true;report(data.request_id?`读取结果待核对，继续保留原编号：${data.request_id}；不自动重复。`:'权限核对未完成，尚未提交平台读取；请取消本地等待后重新核对。',true);}}
      finally{job.running=false;if(guard()&&(!pending||pending===job))sync();}
    }
    async function verifyIdentity({lookup=false}={}){
      if(!guard()||archiveBusy||archivePending()||targetBusy||pending&&(pending.operation!=='self'||pending.running||pending.cancelling))return;const value=selected();if(value?.platform!=='weibo')return;
      if(lookup){if(!opaque(selfKey.value)||pending&&pending.data.request_id!==selfKey.value)return;}
      else if(pending||status?.read_availability?.self!=='ready_for_guarded_read'||selfKey.value)return;
      const data={account_id:value.id,request_id:lookup?selfKey.value:crypto.randomUUID()},job={operation:'self',platform:'weibo',account_id:value.id,account_signature:accountSignature(value),input_generation:inputGeneration,data,running:true,discard:false};
      selfKey.value=data.request_id;
      pending=job;invalidateArchive();resultHost.replaceChildren();sync();report('正在核对本人账号身份；仅由当前宿主执行一次只读核实…');
      try{
        const manager=await load('strategy_get',{});if(!guard()||pending!==job)return;
        if(manager?.can_manage!==true){pending=null;status=null;report('当前身份没有经营者读取权限。',true);return;}
        if(job.discard||job.input_generation!==inputGeneration||!sameAccount(job)){pending=null;status=null;report('账号或范围已变化，未提交身份核实。',true);return;}
        const answer=await load(lookup?'platform_read_self_status':'platform_read_self',data);if(!guard()||pending!==job)return;
        if(job.discard||job.input_generation!==inputGeneration||!sameAccount(job)){pending=null;status=null;report('账号或范围已变化，请在原账号核对身份核实结果。',true);return;}
        const result=checkedResult(answer,job);
        if(result.code==='completed'){pending=null;status=null;report('本次本人账号身份已核实。请重新读取存储状态；平台读取许可与客户身份仍须分别核对。');}
        else if(['timeout_hold','read_hold','protocol_hold','busy'].includes(result.code)){report(`${CODES[result.code]} 身份核实原编号：${data.request_id}；请核对原操作，不自动重试。`,true);}
        else{pending=null;status=null;report(CODES[result.code],true);}
      }catch{if(guard()&&pending===job){job.discard=true;report(`身份核实结果待核对，保留原编号：${data.request_id}；本表单不自动重复或重新采集。`,true);}}
      finally{job.running=false;if(guard()&&(!pending||pending===job))sync();}
    }
    async function cancelRead(){
      if(!guard()||!pending||pending.cancelling)return;const job=pending;job.discard=true;resultHost.replaceChildren();invalidateArchive();
      if(!job.data.request_id){pending=null;report('本地等待已取消，尚未提交平台读取。');sync();return;}
      job.cancelling=true;job.cancelRequested=true;sync();report('正在取消本次结果；已发出的只读请求可能仍完成。');
      try{
        const answer=await load('platform_read_cancel',{account_id:job.account_id,request_id:job.data.request_id});if(!guard()||pending!==job)return;
        const result=checkedResult(answer,{...job,operation:'cancel'});if(result.code!=='cancelled')throw Error('cancel');if(job.platform==='wechat_channels'){if(result.cancel_requested!==true||typeof result.cleanup_confirmed!=='boolean')throw Error('cancel');job.cancelAcknowledged=true;if(result.cleanup_confirmed!==true&&!job.wechatReadReturned){report('取消已请求，原读取尚未返回；继续保留本次占用，不新增预览。');return;}if(job.wechatReadReturned){pending=null;status=null;report('视频号原读取已结束，取消后的来源未保存或显示。');return;}}pending=null;report(CODES.cancelled);
      }catch{if(guard()&&pending===job)report(`取消结果仍待核对，继续保留原编号：${job.data.request_id}；可按此编号再次取消，不自动重新读取。`,true);}
      finally{job.cancelling=false;if(guard()&&(!pending||pending===job))sync();}
    }
    try{
      const permission=await load('strategy_get',{});if(!guard())return;
      if(permission?.can_manage!==true){report('此读取表单仅对当前获授权经营者开放。',true);return {root:view.root,current};}
      const excluded=directory().filter(item=>!PRIMARY_PLATFORMS.has(item.platform));if(excluded.length){const history=node('details'),list=node('section');history.append(node('summary',`其他已有账号 · ${excluded.length}（本轮不读取）`),list);for(const item of excluded)list.append(node('p',`${PLATFORMS[item.platform]} · ${item.name||item.id} · 原记录状态：${item.status||'unknown'}`));host.append(history);}
      const rows=accounts();if(!rows.length){report('当前没有本人可用账号；请在平台账号页核对现有账号。',true);return {root:view.root,current};}
      form=node('form','','upgrade-operation-form');form.addEventListener('submit',event=>{event.preventDefault();guard();});host.append(form);
      account=choice(form,'本人已有账号','account_id',rows.map(item=>[item.id,`${PLATFORMS[item.platform]} · ${item.name||item.id}`]),rows[0].id);
      operation=choice(form,'本次读取','operation',Object.entries(OPERATIONS),'search');
      keyword=field(form,'一个关键词','keyword',{maxLength:200});reference=field(form,'指定原作品链接（视频号填已有作品引用）','reference',{maxLength:2048});
      limit=field(form,'期望数量（1–100，平台实际数量另列）','limit',{value:20,type:'number',min:1,max:100});page=field(form,'搜索页码（支持时1–100）','page',{value:1,type:'number',min:1,max:100});cursor=field(form,'原返回游标（支持时由本人填写）','cursor',{maxLength:512});
      refresh=addButton(form,'重新读取存储状态',readStatus);selfKey=node('input');verify=node('button');checkSelf=node('button');submit=addButton(form,'读取这一页',runRead);cancel=addButton(form,'取消本次读取',cancelRead);cancel.disabled=true;
      selfKey.addEventListener('input',()=>{if(guard())sync();});
      statusHost=node('section');resultHost=node('section');host.append(statusHost,resultHost);
      const archiveForm=node('section','','upgrade-operation-form');archiveSection=archiveForm;archiveForm.append(node('h3','保存本机来源'),node('p','只保存已读且获许可的评论来源。核对原保存不重放操作；后台无记录时会阻止同编号的迟到归档。','upgrade-muted'));host.append(archiveForm);
      archiveTarget=field(archiveForm,'原读取编号（可粘贴编号核对已有保存）','archive_read_request_id',{maxLength:128});save=addButton(archiveForm,'保存来源',saveSources);checkSave=addButton(archiveForm,'核对保存结果',checkSaved);archiveHost=node('section');archiveForm.append(archiveHost);
      archiveTarget.addEventListener('input',()=>{if(!guard()||archiveBusy)return;if(archiveReceipt?.data.request_id!==archiveTarget.value)invalidateArchive();sync();const original=archivePending();if(original?.invalid)report('无法核对原操作编号，请检查本机保存的操作记录。',true);else if(original)report(`原保存结果待核对。操作编号：${original.idempotency_key}；请点“核对保存结果”。`);});

      const analysisForm=node('section','','upgrade-operation-form');analysisSection=analysisForm;analysisForm.append(node('h3','分析已保存评论的意向'),node('p','分析本次已保存的同作品评论，最多20条。城市和区域是本次经营分析范围，不表示评论作者的真实位置。缺少正文、标题、来源证明或已有人工评级时需先核对。','upgrade-muted'));host.append(analysisForm);
      analysisCity=field(analysisForm,'经营城市（必填）','source_intent_city',{maxLength:80});analysisArea=field(analysisForm,'经营区域（选填）','source_intent_area',{maxLength:80});
      const confirmation=node('label','','upgrade-check');analysisConfirm=node('input');analysisConfirm.name='source_intent_confirm';analysisConfirm.type='checkbox';confirmation.append(analysisConfirm,node('span','我确认按当前公司AI配置分析本次保存的评论'));analysisForm.append(confirmation);
      analyzeSources=addButton(analysisForm,'分析本次保存的评论',analyzeSaved);analysisKey=field(analysisForm,'原分析操作编号（仅核对已有结果）','source_intent_key',{maxLength:128});checkAnalysis=addButton(analysisForm,'核对原分析结果',checkSourceAnalysis);analysisHost=node('section');analysisForm.append(analysisHost);
      for(const field of [analysisCity,analysisArea])field.addEventListener('input',()=>{if(!guard()||analysisBusy)return;analysisConfirm.checked=false;sync();});analysisConfirm.addEventListener('change',()=>{if(guard())sync();});analysisKey.addEventListener('input',()=>{if(guard())sync();});

      const targetForm=node('section','','upgrade-operation-form');targetSection=targetForm;targetForm.append(node('h3','逐条核对评论回复目标'),node('p','从已保存评论中明确选择一条，核对后回原详情写草稿。重开后可填写原评论编号只读核对已有目标；不会恢复读取或自动发送。','upgrade-muted'));host.append(targetForm);
      archivedSelection=choice(targetForm,'本次已保存评论','archived_lead_id',[['','请先保存来源']]);commentPreviewHost=node('section');targetForm.append(commentPreviewHost);replyTarget=field(targetForm,'原评论编号（重开可只读核对）','reply_target_lead_id',{maxLength:160});
      bindTarget=addButton(targetForm,'核对并准备此评论回复',control=>checkReplyTarget(control,{bind:true}));checkTarget=addButton(targetForm,'核对原回复目标',checkReplyTarget);targetHost=node('section');targetForm.append(targetHost);
      archivedSelection.addEventListener('change',()=>{if(!guard()||targetBusy)return;replyTarget.value=savedIds.includes(archivedSelection.value)?archivedSelection.value:'';clearTarget();sync();void previewComment();});
      replyTarget.addEventListener('input',()=>{if(!guard()||targetBusy)return;clearTarget();sync();});
      account.addEventListener('change',()=>{if(!guard())return;statusSequence++;status=null;changed();if(!pending){keyword.value=reference.value=cursor.value='';page.value='1';void readStatus();}});
      operation.addEventListener('change',()=>{if(!guard())return;page.value='1';cursor.value='';changed();});
      for(const control of [keyword,reference,limit,page,cursor])control.addEventListener('input',changed);
      await readStatus();
    }catch{if(guard())report('经营者权限未确认，本次未开放读取。',true);}
    return {root:view.root,current};
  }
  return {open,reset:clear,dispose(){disposed=true;clear();}};
}
