/* Candidate per-lead storage. Kept separate until legacy migration and clients are ready. */
const COLLECTION = 'fangyu_shared_leads';
const MAX_BATCH = 40;
const PAGE_SIZE = 25;
const COMPANY_ID = /^[a-z0-9][a-z0-9-]{1,78}$/;
const LEAD_ID = /^[a-f0-9]{64}$/;

function checkCompany(companyId) {
  if (typeof companyId !== 'string' || !COMPANY_ID.test(companyId)) throw new Error('企业 ID 无效');
}
function checkLeadId(leadId) {
  if (typeof leadId !== 'string' || !LEAD_ID.test(leadId)) throw new Error('线索 ID 无效');
}
function docId(companyId, leadId) {
  checkCompany(companyId); checkLeadId(leadId);
  return `${companyId}--${leadId}`;
}

async function upsertBatch(transaction, companyId, rows, sequenceStart = 0) {
  checkCompany(companyId);
  if (!Array.isArray(rows) || rows.length < 1 || rows.length > MAX_BATCH) throw new Error('每批允许 1 至 40 条线索');
  if (!Number.isSafeInteger(sequenceStart) || sequenceStart < 0 || !Number.isSafeInteger(sequenceStart + rows.length)) throw new Error('共享清单排序号无效');
  const ids = new Set();
  for (const row of rows) {
    checkLeadId(row?.id);
    if (ids.has(row.id)) throw new Error('批次中有重复线索');
    ids.add(row.id);
  }
  for (const [index, row] of rows.entries()) {
    await transaction.collection(COLLECTION).doc(docId(companyId, row.id)).set({companyId, leadId: row.id, sequence: sequenceStart + index + 1, lead: row});
  }
}

async function listPage(db, companyId, cursor = '') {
  checkCompany(companyId);
  if (cursor && (typeof cursor !== 'string' || !/^[1-9][0-9]*$/.test(cursor) || !Number.isSafeInteger(Number(cursor)))) throw new Error('清单游标无效');
  const where = {companyId};
  if (cursor) where.sequence = db.command.lt(Number(cursor));
  const response = await db.collection(COLLECTION).where(where).orderBy('sequence', 'desc').limit(PAGE_SIZE + 1).get();
  if (!Array.isArray(response?.data)) throw new Error('共享清单分页响应无效');
  const page = response.data.slice(0, PAGE_SIZE);
  for (const row of page) {
    if (row.companyId !== companyId || row.lead?.id !== row.leadId || !LEAD_ID.test(row.leadId) || !Number.isSafeInteger(row.sequence) || row.sequence < 1) throw new Error('共享线索隔离检查失败');
  }
  return {items: page.map(row => row.lead), next_cursor: response.data.length > PAGE_SIZE ? String(page.at(-1).sequence) : ''};
}

function documentValue(snapshot) {
  return Array.isArray(snapshot?.data) ? snapshot.data[0] : snapshot?.data;
}

async function migrateNextBatch(db, companyId) {
  checkCompany(companyId);
  return db.runTransaction(async transaction => {
    const ref = transaction.collection('fangyu_workspace_private').doc(companyId);
    const original = documentValue(await ref.get())?.state;
    if (!original || original.companyId !== companyId || !Array.isArray(original.items)) throw new Error('旧共享清单状态无效');
    if (original.sharedLeadsMode === 'v2') throw new Error('共享清单已切换至新存储');
    const state = structuredClone(original);
    const offset = state.sharedLeadMigrationOffset === undefined ? 0 : state.sharedLeadMigrationOffset;
    if (!Number.isSafeInteger(offset) || offset < 0 || offset > state.items.length) throw new Error('迁移检查点无效');
    if (offset === state.items.length) {
      if (state.sharedLeadMigrationOffset === undefined) {
        state.sharedLeadMigrationOffset = offset;
        state.sharedLeadMigrationRevision = state.revision;
        await ref.set({state});
      }
      return {copied: offset, total: state.items.length, readyToVerify: true};
    }
    if (state.sharedLeadMigrationRevision !== undefined && state.sharedLeadMigrationRevision !== state.revision) throw new Error('迁移期间清单被修改');
    const chunk = state.items.slice(offset, offset + MAX_BATCH);
    await upsertBatch(transaction, companyId, chunk, offset);
    state.sharedLeadMigrationOffset = offset + chunk.length;
    state.sharedLeadMigrationRevision = state.revision;
    await ref.set({state});
    return {copied: state.sharedLeadMigrationOffset, total: state.items.length, readyToVerify: state.sharedLeadMigrationOffset === state.items.length};
  });
}

async function verifyAndFinalize(db, companyId) {
  checkCompany(companyId);
  const ref = db.collection('fangyu_workspace_private').doc(companyId);
  const original = documentValue(await ref.get())?.state;
  if (!original || original.companyId !== companyId || !Array.isArray(original.items) ||
      original.sharedLeadMigrationOffset !== original.items.length ||
      original.sharedLeadMigrationRevision !== original.revision) throw new Error('迁移未完成或旧清单已变化');
  const expected = new Map(original.items.map(row => [row.id, JSON.stringify(row)]));
  if (expected.size !== original.items.length) throw new Error('旧清单存在重复 ID');
  let cursor = '', counted = 0;
  do {
    const page = await listPage(db, companyId, cursor);
    for (const row of page.items) {
      if (expected.get(row.id) !== JSON.stringify(row)) throw new Error('新旧共享线索不一致');
      expected.delete(row.id);
      counted++;
    }
    cursor = page.next_cursor;
  } while (cursor);
  if (expected.size) throw new Error('迁移后仍有线索缺失');
  const source = JSON.stringify(original.items);
  return db.runTransaction(async transaction => {
    const txRef = transaction.collection('fangyu_workspace_private').doc(companyId);
    const latest = documentValue(await txRef.get())?.state;
    if (!latest || latest.companyId !== companyId || latest.revision !== original.revision ||
        latest.sharedLeadMigrationOffset !== original.items.length || JSON.stringify(latest.items) !== source) throw new Error('核验期间旧清单已变化');
    const state = structuredClone(latest);
    state.sharedLeadsMode = 'v2';
    state.sharedLeadSequence = state.items.length;
    delete state.items;
    delete state.sharedLeadMigrationOffset;
    delete state.sharedLeadMigrationRevision;
    await txRef.set({state});
    return {migrated: counted, revision: state.revision};
  });
}

module.exports = {COLLECTION, MAX_BATCH, PAGE_SIZE, docId, upsertBatch, listPage, migrateNextBatch, verifyAndFinalize};
