"""Independent focused review of the actual gateway/Core prospect scope.

Reuse root's current synthetic fixture; only the named new cases run.
No gateway/customer/core methods are replaced. Outbound transport stays in the
existing CloudStandin, with socket connections additionally forbidden here.
"""
import unittest
from unittest.mock import patch
from test_prospect_gateway import ProspectGateway
from workbench_backend import WorkbenchError


class ProspectScopeReview(ProspectGateway):
    def setUp(self):
        guard = patch('socket.create_connection', side_effect=AssertionError('Network forbidden'))
        guard.start()
        self.addCleanup(guard.stop)
        super().setUp()

    def test_default_full_customer_history_and_prospect_reply_scope_remain_distinct(self):
        self.seed_people()
        all_customers = self.backend.dispatch('customers', {}, self.token)['customers']
        prospects = self.backend.dispatch('customers', {'audience': 'prospects'}, self.token)['customers']
        self.assertEqual(all_customers['total'], 2)
        self.assertEqual(prospects['total'], 1)
        self.assertEqual(prospects['stats']['total'], 1)
        summary = self.backend.customer_workbench.acquisition_summary(self.user, self.store, self.task_id)
        self.assertEqual({item['id'] for item in summary['recent']}, {item['id'] for item in prospects['items']})
        self.assertEqual(summary['analyzed'], 2, 'Supplier analysis remains an analyzed result, not a reply prospect')

    def test_audience_does_not_allow_invalid_values_caller_authority_or_export_expansion(self):
        self.seed_people()
        for audience in ('everyone', '', None, True, [], {}):
            with self.subTest(audience=audience), self.assertRaises(ValueError):
                self.backend.dispatch('customers', {'audience': audience}, self.token)
        for extra in ({'owner': 'other-employee'}, {'tenant_id': 'other-tenant'}, {'storeId': 'other-store'}):
            with self.subTest(extra=extra), self.assertRaises(WorkbenchError):
                self.backend.dispatch('customers', {'audience': 'prospects', **extra}, self.token)
        with self.assertRaises(WorkbenchError):
            self.backend.dispatch('customer_export', {'audience': 'prospects'}, self.token)

    def test_prospect_filter_never_includes_another_owner_or_explicit_other_store(self):
        self.seed_people()
        foreign_owner = self.add('foreign-owner', '我想租古北一居，明天下午三点看房')
        other_store = self.add('foreign-store', '我想租古北一居，明天下午三点看房')
        grade = {'status': 'graded', 'level': 'high', 'reason': 'Synthetic evidence', 'evidence': ['明天下午三点看房']}
        self.backend.core.store.put('leads', {**foreign_owner, 'cloud_owner': 'not-this-employee', 'manual_intent': grade})
        self.backend.core.store.put('leads', {**other_store, 'store_id': 'explicit-other-store', 'manual_intent': grade})
        prospects = self.backend.dispatch('customers', {'audience': 'prospects'}, self.token)['customers']
        self.assertEqual(prospects['total'], 1)
        summary = self.backend.customer_workbench.acquisition_summary(self.user, self.store, self.task_id)
        self.assertEqual(len(summary['recent']), 1)
        self.assertEqual(summary['analyzed'], 2)


if __name__ == '__main__':
    names = [name for name in ProspectScopeReview.__dict__ if name.startswith('test_')]
    suite = unittest.TestSuite(ProspectScopeReview(name) for name in names)
    raise SystemExit(not unittest.TextTestRunner(verbosity=2).run(suite).wasSuccessful())
