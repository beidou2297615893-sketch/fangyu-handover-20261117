// This panel renders confirmed assistant data only. It never estimates a live comment count.
const PHASES = {
  idle: ['等待开始', '输入关键词，开始采集'],
  saving_config: ['准备中', '正在保存采集设置'],
  dispatching: ['准备中', '正在安排本次采集'],
  ready: ['尚未开始', '采集设置已保存，尚未开始采集'],
  queued: ['等待开始', '正在等待电脑开始采集'],
  preparing: ['准备采集', '正在检查本次采集条件'],
  searching: ['正在找帖子', '正在查找符合关键词的帖子'],
  reading_comments: ['正在读评论', '正在读取帖子的评论'],
  filtering: ['正在筛选', '正在筛选符合条件的评论'],
  saving: ['正在整理', '正在保存已读取的评论'],
  waiting: ['等待下一步', '正在等待下一步采集'],
  collecting: ['正在找评论', '采集已开始，正在等待评论返回'],
  reading: ['正在整理', '正在更新评论列表'],
  stopping: ['正在结束', '正在等待结束确认'],
  complete: ['采集完成', '采集完成，新评论已更新'],
  paused: ['已结束采集', '本次采集已结束'],
  failed: ['采集未完成', '采集未完成，请检查页面提示后再开始'],
  uncertain: ['结果待核对', '结果待核对，请稍后查看评论列表'],
};
const WAITING = new Set(['saving_config', 'dispatching', 'queued', 'preparing', 'searching', 'reading_comments', 'filtering', 'saving', 'waiting', 'collecting', 'reading', 'stopping']);
const STEPS = [['preparing', '准备'], ['searching', '搜索'], ['reading_comments', '读取'], ['saving', '保存']];
const STEP_FOR_PHASE = { saving_config: 'preparing', dispatching: 'preparing', queued: 'preparing', preparing: 'preparing', searching: 'searching', reading_comments: 'reading_comments', filtering: 'reading_comments', saving: 'saving' };
const REPLIES = {
  none: '未回复', draft: '草稿待审核', approved: '已审核·未发送',
  copied: '已复制，待人工发送', sending: '发送中', sent: '已回复',
  unknown: '回复结果待核实',
};
const text = value => String(value ?? '');
const count = value => (typeof value === 'number' || typeof value === 'string' && /^\d+$/u.test(value))
  && Number.isSafeInteger(Number(value)) && Number(value) >= 0 ? Number(value) : null;
const employeeCopy = value => typeof value === 'string' && value.trim() && value.length <= 140
  && !/[\r\n{}\[\]]/u.test(value) && !/Traceback|Error:|https?:\/\/|request_?id|token|cookie|\bJSON\b|\bHTTP\b/iu.test(value) ? value.trim() : null;

function el(doc, tag, className, value) {
  const node = doc.createElement(tag);
  if (className) node.className = className;
  if (value !== undefined) node.textContent = text(value);
  return node;
}
function short(value, limit = 96) {
  const clean = text(value).replace(/\s+/gu, ' ').trim();
  return clean.length > limit ? `${clean.slice(0, limit)}…` : clean;
}
function safeMotion(doc) {
  const view = doc.defaultView || globalThis;
  return !view.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches && view.gsap;
}
function duration(ms) {
  const seconds = Math.max(0, Math.floor(ms / 1000));
  const pad = value => String(value).padStart(2, '0');
  return seconds < 3600 ? `${pad(Math.floor(seconds / 60))}:${pad(seconds % 60)}`
    : `${Math.floor(seconds / 3600)}:${pad(Math.floor(seconds / 60) % 60)}:${pad(seconds % 60)}`;
}

/**
 * Contract:
 * prepare({deviceId}) -> opaque session before the task is saved; no count yet.
 * start({session?,deviceId,taskId,task,baselineIds?}) -> opaque session. An optional
 * prepared session must still be current and belong to the same device. Task must be
 * a workspace_state record captured before dispatch, to establish the count baseline.
 * update({session,phase?,task?,message?,progress?}) accepts only confirmed fields.
 * progress.run_id must already be checked by the caller against its current dispatch;
 * it binds result summary identity, never contributes an estimated comment count.
 * Phases: saving_config, dispatching, queued/claimed, collecting/running, reading,
 * stopping, ready; task_progress stages preparing/searching/reading_comments/filtering/saving/waiting.
 * Unknown phases do not move the view forward. No estimated percentages or counts.
 * complete({session,job,task?,leads?,summary?}) accepts a succeeded task_run job, current task,
 * and leads_list {items,total}. New cards require baselineIds captured before dispatch.
 * summary requires matching run_id and real read/filtered/duplicates/imported/deferred/
 * remaining counts. imported must equal the confirmed delta. onContinue(session) is
 * offered only for can_continue=true, batch_limit, ready task, not exhausted, quota>0;
 * it disables on click. The caller must run that same task once under normal guards.
 * summary.message is optional authored employee copy; unknown shapes are ignored.
 * fail({session,status?,message?,action?}) terminates the view. action='account'
 * offers account management. Message is optional employee
 * copy authored by the caller, never raw server errors/stacks. reset/dispose invalidate sessions.
 * All updates must carry the session returned by start, preventing late device/task writes.
 */
export function createCollectionProgress(container, { onStop = () => {}, onOpenResults = () => {}, onOpenAccount = () => {}, onContinue = () => {}, waitNoticeMs = 30000 } = {}) {
  if (!container?.ownerDocument?.createElement) throw new TypeError('需要真实的 DOM 容器');
  const doc = container.ownerDocument;
  const panel = el(doc, 'section', 'collection-progress');
  panel.setAttribute('aria-label', '采集进度');
  const idleIcon = el(doc, 'span', 'collection-progress__idle-icon');
  idleIcon.setAttribute('aria-hidden', 'true');
  const header = el(doc, 'div', 'collection-progress__head');
  const phaseNode = el(doc, 'h3', 'collection-progress__phase');
  phaseNode.setAttribute('role', 'status');
  const detail = el(doc, 'p', 'collection-progress__detail');
  detail.setAttribute('role', 'status');
  const stats = el(doc, 'div', 'collection-progress__stats');
  const countNode = el(doc, 'strong', 'collection-progress__count', '0');
  stats.append(countNode, el(doc, 'span', '', '条新评论'));
  const activity = el(doc, 'div', 'collection-progress__activity');
  activity.setAttribute('role', 'progressbar');
  activity.setAttribute('aria-label', '正在等待采集结果，进度未知');
  const flow = el(doc, 'span', 'collection-progress__flow');
  flow.setAttribute('aria-hidden', 'true');
  activity.append(flow);
  const activityCaption = el(doc, 'p', 'collection-progress__waiting', '结果返回后显示新评论');
  const elapsed = el(doc, 'p', 'collection-progress__elapsed');
  elapsed.setAttribute('aria-live', 'off');
  const entries = el(doc, 'ol', 'collection-progress__entries');
  entries.setAttribute('aria-label', '新找到的评论');
  const actions = el(doc, 'div', 'collection-progress__actions');
  const summaryNode = el(doc, 'dl', 'collection-progress__summary');
  summaryNode.setAttribute('aria-label', '本次采集结果');
  const track = el(doc, 'ol', 'collection-progress__steps');
  track.setAttribute('aria-label', '采集步骤');
  const stepNodes = new Map(STEPS.map(([name, label]) => {
    const node = el(doc, 'li', 'collection-progress__step');
    node.dataset.step = name;
    const dot = el(doc, 'span', 'collection-progress__dot');
    dot.setAttribute('aria-hidden', 'true');
    node.append(dot, el(doc, 'span', '', label));
    track.append(node);
    return [name, node];
  }));
  const stopButton = el(doc, 'button', 'collection-progress__stop', '结束本次采集');
  const openButton = el(doc, 'button', 'collection-progress__open', '查看本任务评论');
  const accountButton = el(doc, 'button', 'collection-progress__account', '打开账号管理');
  const continueButton = el(doc, 'button', 'collection-progress__continue', '继续采集');
  for (const button of [stopButton, openButton, accountButton, continueButton]) button.type = 'button';
  actions.append(continueButton, stopButton, openButton, accountButton);
  header.append(phaseNode, stats);
  panel.append(idleIcon, header, detail, track, activity, elapsed, activityCaption, summaryNode, entries, actions);
  container.append(panel);
  let current = null, follow = true, disposed = false, generation = 0, waitTimer = null, tickTimer = null, flowTimeline = null, onScreen = true;
  const view = doc.defaultView || globalThis;
  const motionQuery = view.matchMedia?.('(prefers-reduced-motion: reduce)');
  const clock = () => view.performance?.now?.() ?? Date.now();
  function clearWait() {
    if (waitTimer !== null) view.clearTimeout?.(waitTimer);
    waitTimer = null;
  }
  function clearCards() {
    view.gsap?.killTweensOf?.(Array.from(entries.children));
    entries.replaceChildren();
  }
  function stopCardMotion() {
    const cards = Array.from(entries.children);
    view.gsap?.killTweensOf?.(cards);
    view.gsap?.set?.(cards, { clearProps: 'opacity,visibility,transform' });
  }
  function stopActivity() {
    if (tickTimer !== null) view.clearTimeout?.(tickTimer);
    tickTimer = null;
    flowTimeline?.kill?.();
    flowTimeline = null;
    view.gsap?.set?.(flow, { clearProps: 'transform' });
    activity.dataset.motion = 'static';
  }
  function renderElapsed(waiting) {
    if (!current) return;
    current.elapsedMs = Math.max(0, clock() - current.startedAt);
    elapsed.textContent = `${waiting ? '已等待' : '本次用时'} ${duration(current.elapsedMs)}`;
  }
  function animateFlow() {
    if (doc.hidden || !onScreen || motionQuery?.matches) {
      flowTimeline?.kill?.();
      flowTimeline = null;
      view.gsap?.set?.(flow, { clearProps: 'transform' });
      activity.dataset.motion = 'static';
      return;
    }
    if (flowTimeline) return;
    if (view.gsap?.timeline) {
      activity.dataset.motion = 'gsap';
      flowTimeline = view.gsap.timeline({ repeat: -1 }).fromTo(flow, { xPercent: -130 }, { xPercent: 325, duration: 1.7, ease: 'none' });
    } else activity.dataset.motion = 'css';
  }
  function beginActivity() {
    panel.dataset.inactive = doc.hidden || !onScreen ? 'true' : 'false';
    animateFlow();
    renderElapsed(true);
    if (tickTimer !== null || !view.setTimeout || doc.hidden || !onScreen) return;
    const session = current?.session;
    const tick = () => {
      tickTimer = null;
      if (!active(session) || current.terminal || !WAITING.has(panel.dataset.phase) || doc.hidden || !onScreen) return;
      renderElapsed(true);
      animateFlow();
      tickTimer = view.setTimeout(tick, 1000);
    };
    tickTimer = view.setTimeout(tick, 1000);
  }

  const active = session => !disposed && !!current && session === current.session;
  function renderTrack(name) {
    track.hidden = !current;
    const step = STEP_FOR_PHASE[name];
    if (step) current?.reached.add(step);
    for (const [key, node] of stepNodes) {
      node.hidden = key === 'searching' && current?.scope === 'comments';
      const isCurrent = step === key && WAITING.has(name);
      node.dataset.state = isCurrent ? 'current' : current?.reached.has(key) ? 'done' : 'pending';
      node.setAttribute('aria-current', isCurrent ? 'step' : 'false');
    }
  }
  function phase(name) {
    if (!PHASES[name]) return;
    const changed = panel.dataset.phase !== name;
    const [, fallback] = PHASES[name];
    panel.dataset.phase = name;
    if (changed && current) { current.longWait = false; current.phaseStartedAt = clock(); }
    phaseNode.textContent = current?.longWait ? `${fallback}（${current.taskId ? '等待较久，可结束后核对结果' : '等待较久，结果待确认'}）` : fallback;
    detail.textContent = fallback;
    header.hidden = name === 'idle';
    idleIcon.hidden = name !== 'idle';
    detail.hidden = name !== 'idle';
    renderTrack(name);
    const waiting = WAITING.has(name);
    activity.hidden = !waiting;
    activity.setAttribute('aria-valuetext', fallback);
    elapsed.hidden = !current || name === 'ready';
    if (waiting) beginActivity();
    else { stopActivity(); renderElapsed(false); }
    activityCaption.hidden = true;
    stopButton.disabled = !waiting || !current?.taskId;
    stopButton.hidden = stopButton.disabled;
    openButton.hidden = !current?.taskId;
    accountButton.hidden = true;
    continueButton.hidden = true;
    continueButton.disabled = false;
    summaryNode.hidden = true;
    stats.hidden = current?.baselineCount === null || !current;
    entries.hidden = current?.shown.size === 0 || !current;
    actions.hidden = !current;
    if (changed || !waiting) {
      clearWait();
      activityCaption.textContent = name === 'reading' ? '评论列表更新后显示结果' : '结果返回后显示新评论';
    }
    if (waiting && !doc.hidden && onScreen && !current.longWait && waitTimer === null && view.setTimeout && Number.isFinite(waitNoticeMs) && waitNoticeMs > 0) {
      const session = current.session;
      const notice = () => {
        waitTimer = null;
        if (active(session) && !current.terminal && panel.dataset.phase === name) {
          current.longWait = true;
          phaseNode.textContent = `${fallback}（${current.taskId ? '等待较久，可结束后核对结果' : '等待较久，结果待确认'}）`;
        }
      };
      const remaining = Math.max(0, waitNoticeMs - (clock() - current.phaseStartedAt));
      if (remaining === 0) notice();
      else waitTimer = view.setTimeout(notice, remaining);
    }
  }
  function setConfirmed(value) {
    if (current.baselineCount === null || value === null || value < current.confirmed) return;
    current.confirmed = value;
    countNode.textContent = String(value - current.baselineCount);
  }
  function addCards(leads) {
    const added = current.confirmed - current.baselineCount;
    if (added <= 0 || !current.baselineIds || !Array.isArray(leads?.items)) return;
    const fresh = [];
    for (const lead of leads.items) {
      if (current.shown.size >= added) break;
      if (!lead || lead.task_id !== current.taskId || !lead.id || current.baselineIds.has(lead.id) || current.shown.has(lead.id)) continue;
      current.shown.add(lead.id);
      const card = el(doc, 'li', 'collection-progress__entry');
      const top = el(doc, 'div', 'collection-progress__entry-head');
      top.append(el(doc, 'strong', '', short(lead.author, 28) || '昵称未提供'));
      const grade = ['A', 'B', 'C'].includes(lead.grade) ? lead.grade : '待评分';
      const badge = el(doc, 'span', 'collection-progress__grade', `意向 ${grade}`);
      badge.dataset.grade = grade;
      top.append(badge);
      const body = el(doc, 'p', 'collection-progress__excerpt', short(lead.text) || '（评论正文为空）');
      const canonicalReply = typeof lead.reply_state === 'string' && Object.hasOwn(REPLIES, lead.reply_state) ? lead.reply_state : 'unknown';
      const replyState = Object.hasOwn(lead, 'reply_state') ? canonicalReply : lead.reply_status;
      const reply = el(doc, 'small', 'collection-progress__reply', `回复：${REPLIES[replyState] || '状态未提供'}`);
      reply.dataset.state = Object.hasOwn(REPLIES, replyState) ? replyState : 'unknown';
      card.append(top, body, reply);
      entries.append(card);
      fresh.push(card);
    }
    if (fresh.length) {
      entries.hidden = false;
      const gsap = !doc.hidden && onScreen && safeMotion(doc);
      if (gsap) gsap.fromTo(fresh, { autoAlpha: 0, y: 9 }, { autoAlpha: 1, y: 0, duration: .27, stagger: .07, ease: 'power2.out', clearProps: 'all', overwrite: 'auto' });
      if (follow) entries.scrollTop = entries.scrollHeight;
    }
  }
  function prepare({ deviceId, scope } = {}) {
    if (disposed || !text(deviceId).trim()) throw new TypeError('需要设备身份');
    clearWait();
    stopActivity();
    panel.dataset.phase = '';
    generation++;
    const session = Object.freeze({ deviceId: text(deviceId), taskId: '', generation });
    current = { session, taskId: '', scope, baselineCount: null, confirmed: null, baselineIds: null, shown: new Set(), reached: new Set(), terminal: false, startedAt: clock(), longWait: false, runId: null, canContinue: false };
    clearCards();
    countNode.textContent = '0';
    phase('saving_config');
    panel.hidden = false;
    return session;
  }
  function start({ session: prepared, deviceId, taskId, task, baselineIds } = {}) {
    if (prepared && (!active(prepared) || current.terminal || current.taskId || prepared.deviceId !== text(deviceId))) return null;
    if (disposed || !text(deviceId).trim() || !text(taskId).trim() || task?.id !== taskId || count(task.accumulated) === null) throw new TypeError('需要设备、任务身份及运行前任务快照');
    clearWait();
    stopActivity();
    panel.dataset.phase = '';
    generation++;
    const session = Object.freeze({ deviceId: text(deviceId), taskId: text(taskId), generation });
    current = { session, taskId: session.taskId, scope: task.scope, baselineCount: count(task.accumulated), confirmed: count(task.accumulated), baselineIds: Array.isArray(baselineIds) ? new Set(baselineIds) : null, shown: new Set(), reached: new Set(), terminal: false, startedAt: clock(), longWait: false, runId: null, canContinue: false };
    clearCards();
    countNode.textContent = '0';
    follow = true;
    phase('queued');
    panel.hidden = false;
    return session;
  }
  function update({ session, phase: nextPhase, task, message, progress } = {}) {
    if (!active(session) || current.terminal) return false;
    if (task && task.id !== current.taskId) return false;
    if (typeof progress?.run_id === 'string' && progress.run_id.trim()) {
      if (current.runId && current.runId !== progress.run_id) return false;
      current.runId = progress.run_id;
    }
    if (task) setConfirmed(count(task.accumulated));
    const stage = nextPhase === 'running' ? 'collecting' : nextPhase === 'claimed' ? 'queued' : nextPhase;
    if (WAITING.has(stage) || stage === 'ready') {
      phase(stage);
      const copy = employeeCopy(message);
      if (copy) phaseNode.textContent = detail.textContent = copy;
    }
    return true;
  }
  function renderSummary(summary, job, task, added) {
    const runId = typeof summary?.run_id === 'string' && summary.run_id.trim();
    if (!runId || runId !== (current.runId || job?.result?.summary?.run_id)) return false;
    const values = Object.fromEntries(['read', 'filtered', 'duplicates', 'imported', 'deferred', 'remaining'].map(key => [key, count(summary[key])]));
    if (Object.values(values).some(value => value === null) || values.imported !== added
      || values.read < values.duplicates + values.imported + values.filtered) return false;
    summaryNode.replaceChildren();
    for (const [label, value] of [['读取', values.read], ['已收录', values.duplicates], ['新增', values.imported]]) {
      const metric = el(doc, 'div', 'collection-progress__metric');
      metric.append(el(doc, 'dt', '', label), el(doc, 'dd', '', value));
      summaryNode.append(metric);
    }
    summaryNode.hidden = false;
    stats.hidden = true;
    current.canContinue = summary.can_continue === true && summary.stop_reason === 'batch_limit'
      && summary.exhausted === false && values.remaining > 0 && task.status === 'ready';
    continueButton.hidden = !current.canContinue;
    if (added === 0) {
      const message = employeeCopy(summary.message);
      if (message) phaseNode.textContent = message;
      else if (values.read > 0 && values.duplicates === values.read && values.filtered === 0 && values.deferred === 0)
        phaseNode.textContent = current.canContinue ? '本批评论已收录，还可继续采集' : '本批读取的评论已收录';
      else if (summary.stop_reason === 'range_exhausted' && summary.exhausted === true)
        phaseNode.textContent = '本轮采集范围已读完，没有新增评论';
    }
    return true;
  }
  function complete({ session, job, task, leads, summary } = {}) {
    if (!active(session) || current.terminal || !current.taskId || job?.status !== 'succeeded' || task?.id !== current.taskId || count(task.accumulated) === null) return false;
    setConfirmed(count(task.accumulated));
    addCards(leads);
    phase('complete');
    const added = current.confirmed - current.baselineCount;
    if (added === 0) detail.textContent = '本轮没有新增评论';
    else if (current.shown.size === 0) detail.textContent = `已新增${added}条，请到评论列表查看`;
    else detail.textContent = `已新增${added}条评论`;
    phaseNode.textContent = added === 0 ? '没有新增评论' : current.shown.size === 0 ? '采集完成，请到评论列表查看' : '采集完成';
    renderSummary(summary, job, task, added);
    current.terminal = true;
    return true;
  }
  function fail({ session, status, message, action } = {}) {
    if (!active(session) || current.terminal) return false;
    phase(status === 'uncertain' || status === 'expired' ? 'uncertain' : status === 'failed' ? 'failed' : 'paused');
    const copy = employeeCopy(message);
    if (copy) phaseNode.textContent = detail.textContent = copy;
    accountButton.hidden = action !== 'account';
    current.terminal = true;
    return true;
  }
  function reset() {
    generation++;
    clearWait();
    stopActivity();
    current = null;
    clearCards();
    countNode.textContent = '0';
    phase('idle');
    panel.hidden = false;
  }
  function dispose() {
    reset();
    disposed = true;
    doc.removeEventListener?.('visibilitychange', visibilityChanged);
    motionQuery?.removeEventListener?.('change', motionChanged);
    intersection?.disconnect();
    panel.remove();
  }
  stopButton.addEventListener('click', () => { if (current && !stopButton.disabled) onStop(current.session); });
  openButton.addEventListener('click', () => { if (current) onOpenResults(current.session); });
  accountButton.addEventListener('click', () => { if (current && !accountButton.hidden) onOpenAccount(current.session); });
  continueButton.addEventListener('click', () => {
    if (current?.terminal && current.canContinue && !continueButton.hidden && !continueButton.disabled) {
      continueButton.disabled = true;
      onContinue(current.session);
    }
  });
  entries.addEventListener('scroll', () => {
    follow = entries.scrollHeight - entries.clientHeight - entries.scrollTop <= 24;
  });
  function visibilityChanged() {
    if (doc.hidden || !onScreen) { panel.dataset.inactive = 'true'; stopActivity(); stopCardMotion(); clearWait(); }
    else if (current && !current.terminal && WAITING.has(panel.dataset.phase)) phase(panel.dataset.phase);
  }
  function motionChanged() {
    if (motionQuery?.matches) stopCardMotion();
    if (current && !current.terminal && WAITING.has(panel.dataset.phase)) animateFlow();
  }
  doc.addEventListener?.('visibilitychange', visibilityChanged);
  motionQuery?.addEventListener?.('change', motionChanged);
  const intersection = typeof view.IntersectionObserver === 'function' ? new view.IntersectionObserver(items => {
    onScreen = Boolean(items.at(-1)?.isIntersecting);
    visibilityChanged();
  }) : null;
  intersection?.observe(panel);
  reset();
  return { prepare, start, update, complete, fail, reset, dispose };
}
