export const intentLabels = {super_high:'超高意向',high:'高意向',medium:'中意向',low:'低意向',very_low:'极低意向',pending:'待分析',uncertain:'待核实',unrelated:'无关'};
export function intentGroupCount(groups,kind){
 const aliases={medium:['中意向','中等意向'],unrelated:['无关','不相关']};
 const names=aliases[kind]||[intentLabels[kind]];
 return (groups||[]).filter(group=>names.includes(group.label)||(kind==='pending'&&String(group.label||'').endsWith('· 待分析'))).reduce((sum,group)=>sum+Number(group.count||0),0);
}
export function intentReplyGuidance(kind){
 return ({
  super_high:'优先人工回复 · 逐条核对需求后确认',
  high:'优先人工回复 · 逐条核对后确认',
  medium:'可选批量回复 · 每条审核确认后发送',
  low:'筛选后可批量回复 · 每条审核确认后发送',
  very_low:'暂不主动联系；如需回复，请先人工复核。',
  pending:'等待分析或人工核对后再回复。',
  uncertain:'先人工核对原文与来源，再判断是否回复。',
  unrelated:'无关评论无需回复。'
 })[kind]||'先核对原评论。';
}
export function exactCustomer(items,platform,authorId){
 if(!Array.isArray(items)||typeof platform!=='string'||!platform||typeof authorId!=='string'||!authorId)return null;
 const matches=items.filter(row=>row?.platform===platform&&row.author_id===authorId&&/^[0-9a-f]{64}$/.test(row.author_key||''));
 return matches.length===1?matches[0]:null;
}
export function customerContactLine(person){
 if(!person)return '客户记录待核实';
 const state={sent:'系统记录已发送',external_reported:'仅人工记录已联系',legacy_sent_unverified:'历史发送待核实',unknown:'发送结果待核实',copied:'已复制，发送未核实',uncontacted:'未记录联系'}[person.contact_state]||'联系状态待核实';
 const count=Number.isSafeInteger(person.comment_count)&&person.comment_count>0?`${person.comment_count} 条评论 · `:'';
 return `${count}${person.viewed_at?'已看过':'未标记看过'} · ${state}${person.uncertain_contact&&person.contact_state!=='unknown'?' · 另有发送待核对':''}`;
}
export function customerPrincipalSignature(user){
 return JSON.stringify([user?.username,user?.id,user?.tenant_id,user?.company_id,user?.role]);
}
export function sameCustomerContext(request,current){
 return !!request&&!current.disposed&&current.page==='leads'&&
  request.generation===current.generation&&request.pageVersion===current.pageVersion&&
  request.leadId===current.leadId&&request.platform===current.platform&&
   request.authorId===current.authorId&&request.principal===current.principal;
}
export function workspaceHeaderDate(at=new Date()){
 const date=at instanceof Date?at:new Date(at);
 if(!Number.isFinite(date.getTime()))return '';
 const parts=Object.fromEntries(new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(date).map(part=>[part.type,part.value]));
 return `${parts.year}-${parts.month}-${parts.day}`;
}
export function displayCommentDate(value) {
 const match=String(value||'').match(/^(\d{4})-(\d{2})-(\d{2})(?:[T ](\d{2}):(\d{2})(?::\d{2}(?:\.\d+)?)?(?:Z|[+-]\d{2}:?\d{2})?)?$/);
 if(!match)return '待核实';
 const [,year,month,day,hour,minute]=match,date=new Date(Date.UTC(Number(year),Number(month)-1,Number(day)));
 if(date.getUTCFullYear()!==Number(year)||date.getUTCMonth()!==Number(month)-1||date.getUTCDate()!==Number(day)||hour!==undefined&&(Number(hour)>23||Number(minute)>59||!Number.isFinite(Date.parse(String(value)))))return '待核实';
 return `${year}-${month}-${day}${hour===undefined?'':` ${hour}:${minute}`}`;
}
export function effectiveIntent(lead) {
 const current=lead.manual_intent||lead.ai_intent;
 if(current?.status==='graded'&&Object.hasOwn(intentLabels,current.level)&&!['pending','uncertain','unrelated'].includes(current.level))return {...current,label:intentLabels[current.level],kind:current.level};
 if(['pending','uncertain','unrelated'].includes(current?.status))return {...current,label:intentLabels[current.status],kind:current.status};
 if(!current&&lead.analysis_status==='missing_text')return {status:'uncertain',level:null,label:intentLabels.uncertain,kind:'uncertain',source:'metadata',reason:'评论正文缺失，未进行 AI 分析；请核对原文与来源。'};
 return {status:'pending',level:null,label:'待分析',kind:'pending',reason:lead.grade?`历史规则 ${lead.grade}，尚未完成 AI 分析`:''};
}
export function replyAccountSelection(accounts,preferred=''){
 const eligible=accounts.filter(account=>account.platform==='xiaohongshu'&&account.status==='ready'&&account.requires_review!==true);
 const matched=eligible.some(account=>account.id===preferred);
 const value=matched?preferred:!preferred&&eligible.length===1?eligible[0].id:'';
 return {eligible,value,showChoice:eligible.length>1||eligible.length===1&&!!preferred&&!matched};
}
export function intentFacts(lead){
 const source=lead.manual_intent?.key_info??lead.ai_intent?.key_info;
 if(!Array.isArray(source))return null;
 return source.filter(item=>item&&typeof item.value==='string'&&typeof item.evidence==='string'&&item.evidence.includes(item.value)&&String(lead.text||'').includes(item.evidence)).slice(0,8);
}
export function continuousPayload(values,keywords) {
 const city=String(values.city||'').trim(),rawRange=String(values.comment_date_range||'3'),range={3:'3months',6:'6months',12:'12months'}[rawRange]||rawRange;
 if(!city)throw Error('请先填写城市');
 if(!['3months','6months','12months','custom'].includes(range))throw Error('请选择评论时间');
 if(!keywords.length)throw Error('请至少选择或填写一个关键词');
 const from=String(values.comment_date_from||''),to=String(values.comment_date_to||'');
 if(range==='custom'&&(!from||!to||from>to))throw Error('请设置有效的评论日期范围');
 return {name:String(values.name||'').trim()||`${city}租房获客`,account_id:String(values.account_id||''),platform:'xiaohongshu',
  scope:'search_comments',comment_depth:'all',comment_keyword_mode:'all',intent_mode:'all',keywords,
  continuous_enabled:true,city,area:String(values.area||'').trim(),comment_date_range:range,
  comment_date_from:range==='custom'?from:'',comment_date_to:range==='custom'?to:''};
}
// Compare collection behavior, not the editable display name or progress metadata.
function collectionConditions(task){
 const list=value=>Array.isArray(value)?[...new Set(value.map(item=>String(item).trim()).filter(Boolean))]:[];
 const scalar=(value,fallback='')=>String(value??fallback).trim();
 return JSON.stringify({
  account_id:scalar(task.account_id),platform:scalar(task.platform),scope:scalar(task.scope),
  keywords:list(task.keywords),city:scalar(task.city),area:scalar(task.area),
  comment_date_range:scalar(task.comment_date_range,'3months'),
  comment_date_from:scalar(task.comment_date_from),comment_date_to:scalar(task.comment_date_to),
  comment_depth:scalar(task.comment_depth,'all'),comment_keyword_mode:scalar(task.comment_keyword_mode,'all'),
  excludes:list(task.excludes),excluded_authors:list(task.excluded_authors),excluded_bloggers:list(task.excluded_bloggers),
  high_intent_words:list(task.high_intent_words),medium_intent_words:list(task.medium_intent_words),negative_intent_words:list(task.negative_intent_words),
  intent_mode:scalar(task.intent_mode,'all'),unknown_policy:scalar(task.unknown_policy,'keep'),
  region:scalar(task.region),date_from:scalar(task.date_from),date_to:scalar(task.date_to),
  source_blogger:scalar(task.source_blogger),blogger_unknown_policy:scalar(task.blogger_unknown_policy,'review'),
  note_url:scalar(task.note_url),search_pages:Number(task.search_pages||3),daily_limit:Number(task.daily_limit||20),
  target_count:Number(task.target_count||100),time_start:scalar(task.time_start,'00:00'),time_end:scalar(task.time_end,'23:59')
 });
}
export function matchingContinuousTask(tasks,data){
 const target=collectionConditions(data);
 const matches=(tasks||[]).filter(task=>task?.id&&task.continuous_enabled===true&&collectionConditions(task)===target);
 const count=value=>Number.isSafeInteger(value)&&value>=0?value:0;
 const time=task=>{const value=task.continuous?.updated_at||task.updated_at||task.last_run||task.created_at;
  return typeof value==='number'?value*1000:Date.parse(value)||0;};
 // More completed batches retain a later cursor; a fresh failed retry must not outrank it.
 matches.sort((a,b)=>count(b.continuous?.batches)-count(a.continuous?.batches)||
  count(b.continuous?.read)-count(a.continuous?.read)||
  Number(['queued','running','waiting'].includes(b.continuous?.status))-Number(['queued','running','waiting'].includes(a.continuous?.status))||
  time(b)-time(a));
 return matches[0]||null;
}
export function continuousStartAction(task){
 if(!task?.continuous_enabled)return 'continuous_start';
 const status=task.continuous?.status;
 return ['queued','running','waiting'].includes(status)?'display':
  ['paused','blocked','interrupted','failed'].includes(status)?'continuous_resume':'continuous_start';
}
export function confirmedNumber(value){const number=typeof value==='number'?value:null;return Number.isSafeInteger(number)&&number>=0?number:null;}
function safeDiagnostic(raw) {
 return String(raw||'').slice(0,1200)
  .replace(/(Bearer\s+)[^\s;，,]+/gi,'$1[已隐藏]')
  .replace(/((?:api[_-]?key|access[_-]?token|authorization|cookie|secret|password)\s*[:=]\s*)(?:"[^"]*"|'[^']*'|[^\s;，,]+)/gi,'$1[已隐藏]')
  .replace(/https?:\/\/[^\s;，,]+/gi,'[链接已隐藏]');
}
export function continuousPresentation(task,now=Date.now(),account=null) {
 const current=task?.continuous||{},progress=task?.progress||{},active=['queued','running','waiting'].includes(current.status);
 const next=typeof current.next_run_epoch==='number'?current.next_run_epoch*1000:Date.parse(current.next_run_at||'');
 const started=Date.parse(current.started_at||current.created_at||'');
 const phase=current.status==='waiting'?'waiting':current.status==='queued'?'preparing':progress.phase||progress.stage||current.stage;
 const labels={preparing:'正在准备采集',searching:'正在搜索帖子',reading_comments:'正在读取帖子评论',filtering:'正在筛选评论',saving:'正在保存评论',waiting:'等待下一次读取'};
 const rawError=current.last_error||current.message||'';
 const stopped=['paused','blocked'].includes(current.status),historicalVerification=stopped&&/verification_required|平台要求验证|小红书.*验证/.test(rawError);
 const reviewed=account?.requires_review===false,requiresReview=stopped&&account?.requires_review===true;
 const requiresVerification=requiresReview?account.review_reason==='verification_required':!reviewed&&account?.requires_review!==true&&historicalVerification;
 const requiresLogin=stopped&&account?.status==='login_required';
 const programFailure=stopped&&!requiresLogin&&!requiresVerification&&(!requiresReview||account.review_reason==='other_risk')&&/protocol_error|unsupported_operation|CLI 返回无效结果/i.test(rawError);
 const historyResolved=historicalVerification&&account?.status==='ready'&&account?.requires_review===false&&current.inflight!==true;
 const attention=requiresLogin||requiresReview||requiresVerification,errorState=['blocked','failed','interrupted'].includes(current.status)||attention;
 const statusLabel={idle:'等待开始',queued:'采集已安排',running:labels[phase]||'正在采集',waiting:current.wait_reason==='range_exhausted'?'等待新内容':'等待下一次读取',paused:historyResolved?'上次采集已停止':requiresVerification?'本次采集请求被拒绝':requiresReview?'账号需人工复核后继续':current.inflight?'正在暂停，请等待当前读取结束':'采集已暂停',blocked:historyResolved?'上次采集已停止':requiresVerification?'本次采集请求被拒绝':requiresReview?'账号需人工复核后继续':'采集已暂停，需要处理',failed:'采集失败',interrupted:'采集中断，请核对后恢复',exhausted:'本轮内容已读完',completed:'本轮采集完成',stopped:'采集已停止'};
 const ended=active?now:Date.parse(current.updated_at||'');
 const elapsed=Number.isFinite(started)&&Number.isFinite(ended)?Math.max(0,Math.floor((ended-started)/1000)):null;
 return {active,processing:current.status==='running',status:current.status||'idle',phase,heading:requiresLogin?'电脑登录已失效':programFailure?'采集程序需要检查':statusLabel[current.status]||'等待开始',requiresVerification,requiresReview,requiresLogin,historyResolved,
  elapsed,nextSeconds:Number.isFinite(next)&&current.status==='waiting'?Math.max(0,Math.ceil((next-now)/1000)):null,
  read:confirmedNumber(current.read),imported:confirmedNumber(current.imported),duplicates:confirmedNumber(current.duplicates),
  batches:confirmedNumber(current.batches),analysisPending:confirmedNumber(task?.analysis?.pending),
  message:historyResolved?'上次采集的断点已保留。确认采集条件后，点“恢复采集”继续。':programFailure?'登录记录仍保留，采集断点已保存，请查看失败详情。':errorState?(requiresLogin?'请到左侧「小红书账号」重新登录，采集进度已保留':requiresVerification?'进度已保留。请查看手机是否有提醒，并到左侧「小红书账号」核对':requiresReview?'采集已暂停，请到左侧「小红书账号」核对':'本次采集未完成，请查看详情后处理'):reviewed&&historicalVerification?'账号复核已记录，请核对后继续采集':(current.message||current.last_error||''),
  detail:errorState||historicalVerification?safeDiagnostic(rawError):''};
}
function postTitle(item){
 const title=String(item.content_title||'').trim();if(title)return title;
 const legacy=String(item.title||'').trim();
 if(item.source_type==='comment'||item.comment_id){
  const comment=String(item.text||'').trim();
  if(!comment||comment.startsWith(legacy))return '帖子标题未提供';
 }
 return legacy||'帖子标题未提供';
}
export function groupComments(items,groupBy='note') {
 const groups=new Map();
 for(const item of items){let canonicalUrl='';try{const u=new URL(item.note_url||item.url||'');const match=u.pathname.match(/\/(?:explore|search_result|discovery\/item)\/([A-Za-z0-9]+)/);canonicalUrl=match?match[1]:u.hostname+u.pathname;}catch{}
  const commentDate=displayCommentDate(item.published_at);
  const fallback=groupBy==='blogger'?(item.content_author_id||item.content_author||'博主未提供'):groupBy==='date'?(commentDate==='待核实'?'时间未提供':commentDate.slice(0,10)):
   groupBy==='intent'?effectiveIntent(item).kind:(item.note_id||item.content_id||canonicalUrl||item.content_title||'帖子信息未提供');
  const key=item.group_key||fallback,label=groupBy==='note'?postTitle(item):groupBy==='blogger'?item.content_author||'博主未提供':groupBy==='intent'?effectiveIntent(item).label:fallback;
  if(!groups.has(key))groups.set(key,{key,label,author:groupBy==='note'?item.content_author||'':'',url:groupBy==='note'?item.note_url||item.url||'':'',items:[]});
  else if(groupBy==='note'&&groups.get(key).label==='帖子标题未提供'&&label!=='帖子标题未提供')groups.get(key).label=label;
  groups.get(key).items.push(item);
 }
 const result=[...groups.values()];
 if(groupBy==='date')result.sort((a,b)=>(a.label==='时间未提供')-(b.label==='时间未提供')||b.label.localeCompare(a.label));
 return result;
}
export function updatePresentation(state={}) {
 const status=state.status||'unknown',configured=state.feed_configured===true,restart=state.requires_restart===true;
 const labels={ready:'可以检查更新',not_configured:'更新源尚未配置',available:'有可用更新',staged:'更新已下载并校验',busy:'等待工作台空闲',pending_restart:'更新已安排，等待重开',awaiting_close:'等待关闭工作台',awaiting_confirmation:'等待启动自检',up_to_date:'当前已是最新版本',installed:'更新完成',rolled_back:'已恢复上一版本',update_rejected:'此更新已被拒绝'};
 const blocked=restart||['pending_restart','awaiting_close','awaiting_confirmation'].includes(status);
 return {status,label:labels[status]||'更新状态待核对',configured,restart,
  canCheck:configured&&!blocked,canDownload:configured&&!blocked&&status==='available',
  canInstall:configured&&!blocked&&['staged','busy'].includes(status)&&Number.isSafeInteger(state.candidate_release),
  message:typeof state.message==='string'?state.message:'',
  installedVersion:state.installed_version&&state.installed_version!=='unknown'?String(state.installed_version):'版本未提供',
  installedRelease:Number.isSafeInteger(state.installed_release)?state.installed_release:null,
  candidateRelease:Number.isSafeInteger(state.candidate_release)?state.candidate_release:null};
}
