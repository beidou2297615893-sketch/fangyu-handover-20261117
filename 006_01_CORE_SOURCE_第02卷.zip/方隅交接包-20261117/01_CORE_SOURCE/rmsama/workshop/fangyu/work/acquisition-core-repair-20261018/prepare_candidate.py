from pathlib import Path
import ast,json,hashlib
W=Path(__file__).resolve().parent;P=W.parents[1];previous=P/'work/employee-simple-flow-20261018'
p=P/'work/ui-approved-implementation/ui-preview/pages/management-rules.mjs'
s=p.read_text('utf-8').replace('<h3>本地已保存的五级分级标准</h3>',"<h3>${overview.source==='unavailable'?'本地规则暂未读取':Number(overview.revision)>0?'本地已保存的五级分级标准':'本地初始分级标准（尚未保存）'}</h3>")
p.write_text(s,'utf-8')
changes={}
for source_name,target_name in [('assemble_candidate_v3.py','assemble_candidate.py'),('verify_candidate_v3.py','verify_candidate.py')]:
    source=previous/source_name;before=source.read_text('utf-8');after=before.replace("'candidate-v3'","'candidate-core-v4'")
    ast.parse(after);(W/target_name).write_text(after,'utf-8')
    changes[target_name]={'template':str(source),'template_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'adapted_sha256':hashlib.sha256(after.encode()).hexdigest()}
(W/'CANDIDATE-TOOLS.json').write_text(json.dumps(changes,indent=2)+'\n','utf-8')
print('Original public assembly and original validators adapted to this owned candidate only.')
