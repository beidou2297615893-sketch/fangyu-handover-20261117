"""Real UI/host/backend browser fixture, isolated memory cloud. No production IO."""
from __future__ import annotations
import argparse
from copy import deepcopy
import hashlib
import http.client
import importlib.util
import json
import linecache
import os
from pathlib import Path
import secrets
import shutil
import subprocess
import sys
import time
from types import SimpleNamespace
import uuid
from unittest.mock import patch

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
PROJECT=HERE.parents[2]
TASK_PROJECT=PROJECT
ROOT=PROJECT/'work/overnight-integration'
DEFAULT_BASE=Path('C:\\积木软件工坊\\项目\\方隅公寓客户版\\work\\employee-simple-flow-20261018\\candidate-v3\\project\\work\\ui-native-r57\\releases\\ui-r57-20261018T004632Z-6ebe453b')
DEFAULT_SNAPSHOT=ROOT/'client-bundle/runs/0de045b5b8aa4b5885019f77cb9c3e21'
F=HERE/'serve_fixture.py'

def digest(raw):return hashlib.sha256(raw).hexdigest()
def write(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2),'utf-8')
def plain(path,root):
    path=Path(path).resolve(strict=True)
    if not path.is_relative_to(root.resolve()):raise ValueError('Fixture source scope rejected')
    for item in (path,*path.parents):
        info=item.lstat()
        if item.is_symlink() or getattr(info,'st_file_attributes',0)&0x400:raise ValueError('Fixture source reparse rejected')
    return path

def copy_stable(items):
    before={str(src):digest(src.read_bytes()) for src,_ in items}
    for src,dst in items:dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
    after={str(src):digest(src.read_bytes()) for src,_ in items}
    if before!=after:raise ValueError('Input changed during snapshot; wait for the sole author to STOP')
    return [{'source':str(src),'relative':str(dst),'sha256':before[str(src)]} for src,dst in items]

def main(argv=None):
    global PROJECT
    parser=argparse.ArgumentParser(description=__doc__)
    mode=parser.add_mutually_exclusive_group()
    mode.add_argument('--source',action='store_true',help='Capture live sources only after the sole author STOPPED')
    mode.add_argument('--snapshot-run',default=str(DEFAULT_SNAPSHOT))
    parser.add_argument('--project-root',default=str(PROJECT),help='Prefer the frozen candidate project closure')
    parser.add_argument('--base-release',default=str(DEFAULT_BASE))
    parser.add_argument('--compiled',default=str(ROOT/'compiled-runtime-fixture.json'))
    parser.add_argument('--bundle',default=str(ROOT/'deployment-bundle.json'))
    parser.add_argument('--cloud-source',default=str(HERE/'reference-cloud-source'),help='Use an owned captured cloud snapshot; select live candidate only after its author STOPPED')
    parser.add_argument('--node',default=r'C:\Program Files\nodejs\node.exe')
    parser.add_argument('--native',action='store_true',help='Root-only isolated pywebview renderer, private owned profile')
    parser.add_argument('--smoke',action='store_true',help='Bootstrap/login/status only, then STOP both owned servers')
    parser.add_argument('--lost-receipt-once',action='store_true',help='Isolated platform stand-in accepts one task then loses its return receipt')
    parser.add_argument('--collection-interval',type=float,default=.6,help='Isolated platform batch delay for observable pause/resume; product code is unchanged')
    options=parser.parse_args(argv)
    PROJECT=plain(options.project_root,TASK_PROJECT)
    if not PROJECT.is_dir():raise ValueError('Project source directory required')
    if options.project_root!=str(TASK_PROJECT):
        if options.base_release==str(DEFAULT_BASE):
            staged=PROJECT.parent/'STAGED.json'
            options.base_release=json.loads(staged.read_text('utf-8'))['release']
        for field,name in (('compiled','compiled-runtime-fixture.json'),('bundle','deployment-bundle.json')):
            if getattr(options,field)==str(ROOT/name):setattr(options,field,str(PROJECT/'work/overnight-integration'/name))
        if options.cloud_source==str(HERE/'reference-cloud-source'):
            options.cloud_source=str(PROJECT/'work/overnight-integration/cloud-candidate')
    if not .6 <= options.collection_interval <= 30:
        parser.error('Fixture collection interval must be between .6 and 30 seconds')
    native_webview=None
    if options.native:
        # Root-authorized native QA dependency initialization only. pywebview's
        # Windows version probe may run the stdlib `cmd /c ver` via NUL. Finish
        # that and the fixed WebView2 backend import before installing the
        # existing strict audit hook; do not grant NUL/process/path exceptions.
        # This does not create a window, load a URL, or reuse any employee profile.
        import platform
        platform.win32_ver()
        platform.system()
        import webview as native_webview
        from webview.guilib import initialize as initialize_native_backend
        initialize_native_backend('edgechromium')
    base=plain(options.base_release,PROJECT)
    if not base.is_dir():raise ValueError('Release directory required')
    owned=HERE/'runs'/uuid.uuid4().hex;owned.mkdir(parents=True)
    code=owned/'code';web=owned/'web';items=[]
    if options.source:
        source=PROJECT/'work/ui-native-r57';vendor=PROJECT/'work/shared-backend-integration/vendor-src'
        ui=PROJECT/'work/ui-approved-implementation/ui-preview'
        names=['ui_native_host.py','workbench_backend.py','store_materials.py','store_materials_catalog.json','rental_assessment.py','customer_workbench.py','reply_workbench.py','reply_delivery.py']
        names += [n for n in ('workspace_binding.py','lifecycle_log.py') if (source/n).is_file()]
        items += [(plain(source/n,PROJECT),code/n) for n in names]
        items += [(plain(p,PROJECT),code/'vendor'/p.relative_to(vendor)) for p in vendor.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc']
        items += [(plain(p,PROJECT),web/p.relative_to(ui)) for p in ui.rglob('*') if p.is_file() and ('pages' in p.relative_to(ui).parts or p.parent==ui and p.suffix in ('.html','.css','.js','.mjs')) and '__pycache__' not in p.parts]
        r55=PROJECT/'work/ui-runtime-r55/src'
        items += [(plain(p,PROJECT),owned/'runtime-src'/p.relative_to(r55)) for p in r55.rglob('*.py') if '__pycache__' not in p.parts]
        source_kind='captured-live-source-after-author-stop-required'
    else:
        snapshot=plain(options.snapshot_run,ROOT)
        for folder,target in ((snapshot/'code',code),(snapshot/'web',web)):
            items += [(plain(p,snapshot),target/p.relative_to(folder)) for p in folder.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc']
        source_kind='previously-captured-client-bundle-fixture'
    cloud_source=plain(options.cloud_source,TASK_PROJECT)
    items += [(plain(p,cloud_source),owned/'cloud-source'/p.name) for p in cloud_source.iterdir() if p.is_file() and p.suffix=='.cjs' and not p.name.endswith('.test.cjs')]
    items += [(plain(options.compiled,PROJECT),owned/'central-fixture-input.json'),(plain(options.bundle,PROJECT),owned/'inputs/deployment-bundle.json'),(plain(F,TASK_PROJECT),owned/'harness/serve_fixture.py'),(plain(HERE/'base_fixture.py',TASK_PROJECT),owned/'harness/base_fixture.py'),(plain(HERE/'memory_cloud.cjs',TASK_PROJECT),owned/'harness/memory_cloud.cjs')]
    pins=copy_stable(items)
    bridge_key=secrets.token_hex(24);(owned/'cloud-bridge.key').write_text(bridge_key,'ascii')
    write(owned/'INPUT-SNAPSHOT.json',{'sourceKind':source_kind,'sourcePinClaim':'captured bytes only; not author approval or deployed release','files':pins})
    spec=importlib.util.spec_from_file_location('gui_final_existing_fixture',owned/'harness/serve_fixture.py')
    fixture=importlib.util.module_from_spec(spec);sys.modules[spec.name]=fixture;spec.loader.exec_module(fixture)
    fixture.HERE=HERE;fixture.PROJECT=PROJECT
    linecache.getlines(__file__)
    cloud_log=(owned/'cloud.log').open('wb')
    env={k:v for k,v in os.environ.items() if not any(x in k.upper() for x in ('TOKEN','SECRET','PASSWORD','TENCENT','CLOUDBASE','API_KEY'))}
    node=subprocess.Popen([str(Path(options.node).resolve()),str(owned/'harness/memory_cloud.cjs'),str(owned)],cwd=owned,env=env,
        stdin=subprocess.DEVNULL,stdout=cloud_log,stderr=subprocess.STDOUT,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    runtime=None;network=None;blocked=[];public=None;cloud=None;backend=None
    try:
        deadline=time.monotonic()+20
        while not (owned/'CLOUD-PUBLIC.json').exists():
            if node.poll() is not None:raise RuntimeError('Owned memory adapter exited; see cloud.log')
            if time.monotonic()>deadline:raise RuntimeError('Owned memory adapter readiness timed out')
            time.sleep(.05)
        cloud_public=json.loads((owned/'CLOUD-PUBLIC.json').read_text('utf-8'));cloud_port=cloud_public['port']
        compiled=json.loads((owned/'central-fixture-input.json').read_text('utf-8-sig'))
        original=fixture.CloudStandin
        class RulesCloud(original):
            def __call__(self,url,data,token=''):
                op=data['operation']
                if op!='store_config_read' and not op.startswith('rule_bundle_'):return super().__call__(url,data,token)
                if token not in self.sessions:return super().__call__(url,data,token)
                conn=http.client.HTTPConnection('127.0.0.1',cloud_port,timeout=60)
                conn.request('POST','/',json.dumps({'data':data,'token':token,'name':self.sessions[token]}),{'Content-Type':'application/json','X-Fixture-Bridge':bridge_key})
                response=conn.getresponse();raw=response.read();value=json.loads(raw);status=response.status;conn.close();self.calls.append(op)
                if status!=200:
                    from integrations import IntegrationError
                    error=IntegrationError(value.get('code','fixture_cloud_failed'));error.http_status=status;error.code=value.get('code');raise error
                return value
        sys.path[:0]=[str(code),str(code/'vendor'),str(owned/'runtime-src')]
        blocked=fixture.offline_guard(owned,base,[PROJECT/'work/ui-runtime-r55/src'])
        host=fixture.load('gui_final_real_host',code/'ui_native_host.py');fixture.install_verification_page(host)
        _,files=host.verify_release(base,fixture.digest((base/'RELEASE.json').read_bytes()))
        scope_contract=fixture.load('gui_final_pinned_scope_contract',base/'resources/platform-runtime/platform_runtime.py')
        backend_module=fixture.load('gui_final_real_backend',code/'workbench_backend.py')
        materials=fixture.load('store_materials',code/'store_materials.py')
        rental=fixture.load('rental_assessment',code/'rental_assessment.py')
        customers=fixture.load('gui_final_real_customers',code/'customer_workbench.py')
        cloud=RulesCloud(compiled);created=[]
        company={'id':fixture.COMPANY,'name':'方隅合成1000条界面验收','edition':'customer','personalMode':False,'authMode':'managed','releaseVersion':'fixture-only',
            'platforms':['xiaohongshu','douyin'],'managedWorkspace':{'environment_id':'overnight-fixture','endpoint':'https://example.invalid/fixture'}}
        class PlatformWithLostReceipt(fixture.PlatformStandin):
            lost=False
            def start_acquisition(self,user,data):
                result=super().start_acquisition(user,data)
                if options.lost_receipt_once and not self.lost:
                    self.lost=True
                    write(owned/'LOST-RECEIPT.json',{'injected':True,'taskId':result['taskId'],
                        'startCallsAtInjection':self.calls.count('acquisition_start'),'realPlatformCalls':0})
                    error=RuntimeError('Isolated accepted-task return receipt lost')
                    error.code='COLLECTION_RESULT_UNCONFIRMED';error.mutation_committed=None
                    error.status=503;error.task_id=result['taskId'];raise error
                return result
        def factory(**kwargs):
            value=backend_module.WorkbenchBackend(PROJECT,data_dir=owned/'data',company=company,
                platform_factory=lambda **kw:PlatformWithLostReceipt(**kw,scenario='ready'),customer_factory=fixture.customer_factory(customers.CustomerWorkbench,owned),
                materials_factory=lambda core:materials.StoreMaterials(core,code/'store_materials_catalog.json'),rental_factory=rental.RentalAssessmentService)
            value.platform_runtime.collection_interval=options.collection_interval
            value.platform_runtime.task_scope_factory=lambda data:scope_contract.PlatformRuntime._task_scope(
                {**scope_contract.PlatformRuntime._task_input(SimpleNamespace(server=SimpleNamespace(company=company)),data),
                 'store_id':data['storeId']},data['storeId'])
            created.append(value);return value
        network=patch('integrations.request_json',side_effect=cloud);network.start()
        runtime=host.SharedRuntime(base,files,owned/'state',project_root=PROJECT,profile='fixture',release_id='gui-final-isolated-snapshot',data_dir=owned/'data',company=company,
            backend_factory=factory,source_root=web,assets_root=base/'web/assets').start()
        backend=created[0];backend.platform_runtime.fixture_owned=owned;backend.platform_runtime.fixture_origin='http://127.0.0.1:'+str(runtime.development.server_port)
        seeds=fixture.seed(backend,cloud)
        origin='http://127.0.0.1:'+str(runtime.development.server_port)
        public={'status':'READY','profile':'gui-final-isolated','PID':os.getpid(),'cloudPID':node.pid,'URL':origin+'/',
            'instanceId':runtime.instance_id,'sourceKind':source_kind,'runDirectory':str(owned),'stopFile':str(owned/'STOP'),
            'publicFile':str(owned/'PUBLIC.json'),'cloudAdapter':'independent-loopback-memory-real-service','synthetic':True,'integrationReplayed':False,'evidenceURL':origin+'/fixture/evidence',
            'credentials':{'admin':'fixture-admin','operator':'fixture-operator','password':fixture.PASSWORD},
            'uploadFile':str(owned/'inputs/deployment-bundle.json'),'uploadFolder':str(owned/'inputs'),
            'stores':14,'seeded':seeds,'notProven':['GUI/file chooser/54 artifact viewing/export interaction until root CUA','native WinForms save dialog','real cloud/platform/device/CLI'],
            'productionDataAccess':False,'realPlatformCalls':0}
        public['lostReceiptInjectionEnabled']=options.lost_receipt_once
        public['isolatedCollectionIntervalSeconds']=options.collection_interval
        public['nativeRequested']=options.native
        public['nativeWindowTitle']='方隅工作台 · 本轮隔离验收' if options.native else None
        public['nativeProfile']=str(owned/'native-profile') if options.native else None
        write(owned/'PUBLIC.json',public);write(HERE/'LATEST.json',public)
        print(json.dumps(public,ensure_ascii=False),flush=True)
        if options.smoke:
            conn=http.client.HTTPConnection('127.0.0.1',runtime.development.server_port,timeout=10)
            conn.request('GET','/api/workbench/bootstrap');response=conn.getresponse();boot=json.loads(response.read());assert response.status==200
            headers={'Content-Type':'application/json','Origin':origin,'X-Fangyu-CSRF':boot['csrfToken']}
            conn.request('POST','/api/workbench',json.dumps({'action':'login','data':{'username':'fixture-admin','password':fixture.PASSWORD}}),headers)
            response=conn.getresponse();value=json.loads(response.read());assert response.status==200,value
            headers['Cookie']=response.getheader('Set-Cookie').split(';')[0]
            assert len(value['stores'])==14,value.keys()
            conn.request('POST','/api/workbench',json.dumps({'action':'rule_bundle_status','data':{}}),headers)
            response=conn.getresponse();state=json.loads(response.read());assert response.status==200,state;conn.close()
            write(owned/'SMOKE.json',{'status':'PASS','bootstrapLogin14StoreRuleStatus':True,'bundleState':state.get('ruleBundle',{}).get('state'),
                'bulkImportPerformed':False,'GUIReviewed':False,'realPlatformCalls':0})
            (owned/'STOP').touch()
        elif options.native:
            import threading
            webview=native_webview
            native_profile=owned/'native-profile';native_profile.mkdir()
            title='方隅工作台 · 本轮隔离验收'
            window=webview.create_window(title,origin+'/',width=1440,height=960,min_size=(1100,760))
            def native_status(phase):
                write(owned/'NATIVE-STATUS.json',{'phase':phase,'PID':os.getpid(),
                    'instanceId':runtime.instance_id,'title':title,'URL':origin+'/',
                    'profile':str(native_profile),'synthetic':True,'realPlatformCalls':0,
                    'GUIReviewed':False,'realEmployeeSessionReused':False})
            def shown():native_status('SHOWN')
            def closed():
                native_status('WINDOW_CLOSED');(owned/'STOP').touch()
            window.events.shown+=shown;window.events.closed+=closed
            def watch_stop():
                while not (owned/'STOP').exists():time.sleep(.2)
                try:window.destroy()
                except Exception:pass
            native_status('REQUESTED')
            webview.start(func=watch_stop,gui='edgechromium',private_mode=True,storage_path=str(native_profile))
            native_status('EVENT_LOOP_RETURNED');(owned/'STOP').touch()
        else:
            while not (owned/'STOP').exists():time.sleep(.2)
        return 0
    finally:
        (owned/'STOP').touch()
        if runtime is not None:runtime.close()
        if network is not None:network.stop()
        node.wait(timeout=10);cloud_log.close()
        write(owned/'CLOSED.json',{'closed':True,'cloudExited':node.returncode==0,'blockedAttempts':blocked,
            'cloudStandinOperations':cloud.calls if cloud else [],'platformStandinOperations':backend.platform_runtime.calls if backend else [],'realPlatformCalls':0,'realSend':False})
        if public:
            public['status']='SMOKE_CLOSED' if options.smoke else 'STOPPED';write(owned/'PUBLIC.json',public);write(HERE/'LATEST.json',public)

if __name__=='__main__':raise SystemExit(main())
