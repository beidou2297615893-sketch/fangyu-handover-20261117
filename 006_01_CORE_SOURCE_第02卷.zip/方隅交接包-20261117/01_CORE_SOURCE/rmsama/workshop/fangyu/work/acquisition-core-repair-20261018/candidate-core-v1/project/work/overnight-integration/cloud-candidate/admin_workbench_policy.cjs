'use strict';
// This reviewed installation only. An unbound candidate can never grant a lease.
const REVIEWED=Object.freeze({company:'fangyu-apartment-client',owner:'rmsama',
 device_id:"9vlNuUBb0D2FOw_vPAMSvegH",marker:'fangyu-admin-local-v1',version:'1.1.8-pilot.1'});
function createPolicy(reviewed){
 const valid=reviewed?.company==='fangyu-apartment-client'&&reviewed.owner==='rmsama'
  &&/^[A-Za-z0-9_-]{16,80}$/.test(reviewed.device_id||'')
  &&reviewed.marker==='fangyu-admin-local-v1'&&reviewed.version==='1.1.8-pilot.1';
 return (company,device,owner)=>!!(valid&&company===reviewed.company&&owner?.username===reviewed.owner
  &&owner.role==='admin'&&!owner.disabled&&device&&!device.revoked&&device.owner===reviewed.owner
  &&device.id===reviewed.device_id&&device.version===reviewed.version
  &&device.workbench_source_release===reviewed.marker);
}
const adminWorkbenchFor=createPolicy(REVIEWED);
const sourceFields=()=>({workbench_source_release:REVIEWED.marker,platforms:['xiaohongshu','douyin']});
module.exports={REVIEWED,createPolicy,adminWorkbenchFor,sourceFields};
