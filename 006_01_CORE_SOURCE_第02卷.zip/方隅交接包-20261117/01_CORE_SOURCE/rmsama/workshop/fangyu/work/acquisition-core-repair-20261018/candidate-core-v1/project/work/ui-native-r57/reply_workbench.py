"""Narrow draft/review bridge over the preserved customer and Core interfaces.

No send/copy/manual-contact actions are exposed. Mutation receipts are written
before calling the non-idempotent legacy Core; uncertain calls are read only.
"""
import hashlib
import json
import re
from core import CoreError
from core.review_queue import require_reply_permission, snapshot

ENTITY = 'ui_reply_requests_v1'
KEY = re.compile(r'[A-Za-z0-9_-]{1,160}\Z')


class ReplyWorkbenchError(ValueError):
    def __init__(self, code, message, status=400):
        super().__init__(message)
        self.code, self.status = code, status


def fail(code, message, status=400):
    raise ReplyWorkbenchError(code, message, status)


def digest(value):
    return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,
        separators=(',',':'),allow_nan=False).encode()).hexdigest()


class ReplyWorkbench:
    def __init__(self, core, customers):
        self.core, self.customers = core, customers

    def _context(self, user, store_id, customer_id):
        # Use exactly the existing employee/customer/task/store range.
        detail = self.customers.detail(user,store_id,customer_id)
        actor, public = self.customers._actor(user,store_id)
        person = self.customers._history(actor,store_id).customer_detail(customer_id,actor)
        return actor, public, detail['item'], person

    def _latest(self, actor, lead):
        rows = [row for row in self.core.store.list('replies',actor['tenant_id'])
                if row.get('lead_id')==lead['id']]
        if any(type(row.get('version')) is not int or row['version']<1 for row in rows):
            fail('REPLY_VERSION_INVALID','历史草稿版本需核对',409)
        return max(rows,key=lambda row:(row['version'],row['id']),default=None)

    @staticmethod
    def _public(reply):
        if reply is None: return None
        return {key:reply.get(key) for key in ('id','text','version','status','review_account_id')}

    def read(self, user, store_id, customer_id):
        with self.core.lock:
            actor, public, item, person = self._context(user,store_id,customer_id)
            receipts = [r for r in self.core.store.list(ENTITY,actor['tenant_id'])
                if r.get('owner')==actor['username'] and r.get('storeId')==store_id
                and r.get('customerId')==customer_id]
            pending = [r for r in receipts if r.get('state')=='submitted']
            comments = []
            for original in person.get('comments') or []:
                # History intentionally strips owner/store internals. Fetch the
                # exact visible original only after its scoped membership check.
                lead = self.core._get('leads',original['lead_id'],actor['tenant_id'])
                reply = self._latest(actor,lead)
                reason = ''
                try:
                    require_reply_permission(self.core,actor,lead,reply)
                    self.core._reply_recipient(lead,'comment',user=actor)
                    if lead.get('source_type')!='comment': raise ValueError('此来源不是原评论')
                    if reply and reply.get('status') not in ('draft','approved'):
                        raise ValueError('此评论已有联系记录或未知结果，不能另存或审核')
                except (ValueError,CoreError) as error: reason = str(error)
                accounts = []
                for account in self.core.store.list('accounts',actor['tenant_id']):
                    try: self.core._account_access(actor,account)
                    except CoreError: continue
                    if (account.get('platform')==lead.get('platform')
                            and account.get('store_id') in (None,'',store_id)):
                        accounts.append({'id':account['id'],'name':str(account.get('name') or '平台账号'),
                            'platform':account['platform']})
                review_current = False
                if reply and reply.get('status')=='approved' and not reason:
                    review_current = any(r.get('action')=='reply_review' and r.get('state') in ('accepted','observed')
                        and (r.get('reply') or {}).get('id')==reply['id']
                        and (r.get('intent') or {}).get('sourceDigest')==digest(lead) for r in receipts)
                    try:
                        account=self.core._get('accounts',reply.get('review_account_id'),actor['tenant_id'])
                        self.core._account_access(actor,account)
                        review_current=bool(review_current and account['id'] in {a['id'] for a in accounts}
                            and reply.get('approval_snapshot')==snapshot(self.core,reply,lead,account,user=actor))
                    except (CoreError,ValueError): review_current=False
                comments.append({'id':lead['id'],'text':str(original.get('text') or ''),
                    'publishedAt':str(original.get('published_at') or ''),
                    'postTitle':str(lead.get('content_title') or lead.get('title') or '帖子标题未提供'),
                    'postUrl':str(original.get('note_url') or ''),'platform':lead.get('platform'),
                    'coverUrl':self.customers._media_url(store_id,lead['id'],'cover'),
                    'avatarUrl':self.customers._media_url(store_id,lead['id'],'author'),
                    'postAuthorAvatarUrl':self.customers._media_url(store_id,lead['id'],'post_author'),
                    'sourceDigest':digest(lead),'draft':self._public(reply) if not reply or reply.get('author_id')==actor['id'] else None,
                    'pendingRequestId':next((r['requestId'] for r in pending if r.get('leadId')==lead['id']),''),
                    'canSave':not reason,'reason':reason,'accounts':accounts,
                    'reviewCurrent':review_current,
                    'canReview':not reason and bool(reply and reply.get('status')=='draft' and accounts)})
            return {'actor':public,'scope':'employee-local-history','customerId':customer_id,
                'item':item,'comments':comments,'sendAvailable':False}

    def _receipt_id(self, actor, store_id, request_id):
        return digest([actor['tenant_id'],actor['id'],store_id,request_id])

    def check(self, user, store_id, data):
        result = self.read(user,store_id,data['customerId'])
        if data['leadId'] not in {row['id'] for row in result['comments']}:
            fail('REPLY_SOURCE_UNAVAILABLE','原评论不在当前客户可见范围',404)
        receipt = self.core.store.get(ENTITY,self._receipt_id(user,store_id,data['requestId']))
        if receipt and (receipt.get('customerId')!=data['customerId'] or receipt.get('leadId')!=data['leadId']):
            fail('REPLY_REQUEST_CONFLICT','操作编号与原评论不一致',409)
        if receipt and receipt['state']=='submitted':
            row = next(row for row in result['comments'] if row['id']==data['leadId'])
            draft, intent = row['draft'],receipt['intent']
            observed = draft and row['sourceDigest']==intent['sourceDigest'] and (
                receipt['action']=='reply_save' and draft['version']==intent['expectedVersion']+1
                and draft['status']=='draft' and draft['text']==intent['text'].strip()
                or receipt['action']=='reply_review' and draft['id']==intent['expectedReplyId']
                and draft['version']==intent['expectedVersion'] and draft['status']=='approved'
                and draft['review_account_id']==intent['accountId'])
            if observed:
                receipt={**receipt,'state':'observed','reply':draft}
                self.core.store.put(ENTITY,receipt)
                result=self.read(user,store_id,data['customerId'])
            elif draft==receipt.get('expectedDraft'):
                # No draft/review change persisted. An explicit check closes
                # this attempt; the next change is a new user decision.
                receipt={**receipt,'state':'not_applied'}
                self.core.store.put(ENTITY,receipt)
                result=self.read(user,store_id,data['customerId'])
            else:
                # The source/current version has since changed. Close only the
                # receipt after this explicit read; retain the current draft and
                # original submitted text, without declaring the old action valid.
                receipt={**receipt,'state':'changed'}
                self.core.store.put(ENTITY,receipt)
                result=self.read(user,store_id,data['customerId'])
        result['receipt'] = {'requestId':data['requestId'],'state':receipt['state'] if receipt else 'not_found',
            'reply':receipt.get('reply') if receipt else None,
            'attemptText':((receipt.get('intent') or {}).get('text') or
                (receipt.get('expectedDraft') or {}).get('text','')) if receipt else ''}
        return result

    def execute(self, action, user, store_id, data):
        fields = {'reply_read':{'storeId','customerId'},
            'reply_check':{'storeId','customerId','leadId','requestId'},
            'reply_save':{'storeId','customerId','leadId','text','expectedVersion','expectedReplyId','sourceDigest','requestId'},
            'reply_review':{'storeId','customerId','leadId','expectedVersion','expectedReplyId','sourceDigest','requestId','accountId','confirmed'}}[action]
        if not isinstance(data,dict) or set(data)!=fields:
            fail('INPUT_INVALID','回复操作参数无效')
        for key in ('leadId','requestId','accountId'):
            if key in data and (not isinstance(data[key],str) or not KEY.fullmatch(data[key])):
                fail('INPUT_INVALID','原评论、账号或操作编号无效')
        if action=='reply_read': return self.read(user,store_id,data['customerId'])
        with self.core.lock:
            if action=='reply_check': return self.check(user,store_id,data)
            if (type(data['expectedVersion']) is not int or data['expectedVersion']<0
                    or not isinstance(data['expectedReplyId'],str)
                    or not isinstance(data['sourceDigest'],str)
                    or not re.fullmatch(r'[0-9a-f]{64}',data['sourceDigest'])):
                fail('INPUT_INVALID','请先读取当前原评论和草稿版本')
            if action=='reply_save' and (not isinstance(data['text'],str) or not data['text'].strip()
                    or len(data['text'])>1000 or re.search(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]',data['text'])):
                fail('INPUT_INVALID','请填写1至1000字的回复草稿')
            if action=='reply_review' and data['confirmed'] is not True:
                fail('CONFIRM_REQUIRED','请逐条确认原评论、草稿内容和回复账号')
            current = self.read(user,store_id,data['customerId'])
            row = next((row for row in current['comments'] if row['id']==data['leadId']),None)
            if not row: fail('REPLY_SOURCE_UNAVAILABLE','原评论不在当前客户可见范围',404)
            ident = self._receipt_id(user,store_id,data['requestId'])
            prior = self.core.store.get(ENTITY,ident)
            signature = digest([action,data])
            if prior:
                if prior.get('signature')!=signature: fail('REPLY_REQUEST_CONFLICT','同一操作编号的内容已经变化',409)
                if prior['state'] in ('accepted','observed'):
                    current['receipt']={'requestId':data['requestId'],'state':prior['state'],'reply':prior['reply']}
                    return current
                if prior['state'] in ('rejected','not_applied','changed'):
                    fail('REPLY_REQUEST_CLOSED','原操作已核对关闭，请阅读当前版本后明确发起下一次修改',409)
                fail('REPLY_RESULT_UNCONFIRMED','上次草稿操作结果待核对，请读取原评论；不会重复变更',409)
            if row['sourceDigest']!=data['sourceDigest']:
                fail('REPLY_SOURCE_CHANGED','原评论来源或内容已变化，请重新读取',409)
            draft = row['draft']
            if ((draft['id'] if draft else '')!=data['expectedReplyId']
                    or (draft['version'] if draft else 0)!=data['expectedVersion']):
                fail('REPLY_VERSION_CONFLICT','草稿已在其他窗口更新，请先读取并逐条核对',409)
            if not row['canSave']: fail('REPLY_FORBIDDEN',row['reason'],403)
            if row['pendingRequestId']:
                fail('REPLY_RESULT_UNCONFIRMED','原评论上次操作结果待核对，请先核对上次操作',409)
            if action=='reply_review' and (not draft or draft['status']!='draft'
                    or data['accountId'] not in {a['id'] for a in row['accounts']}):
                fail('REPLY_REVIEW_REQUIRED','请选择本人同平台账号，并先保存当前草稿',409)
            receipt = {'id':ident,'tenant_id':user['tenant_id'],'owner':user['username'],
                'customerId':data['customerId'],'leadId':data['leadId'],'signature':signature,'state':'submitted',
                'storeId':store_id,'requestId':data['requestId'],'action':action,
                'expectedDraft':draft,
                'intent':{**data,'expectedStatus':draft['status'] if draft else None}}
            self.core.store.put(ENTITY,receipt)
            before = self._latest(user,self.core._get('leads',data['leadId'],user['tenant_id']))
            try:
                args = ({'lead_id':data['leadId'],'text':data['text'],'channel':'comment'} if action=='reply_save'
                    else {'id':draft['id'],'account_id':data['accountId'],'confirmed':True})
                result = self.core.handle('draft_reply' if action=='reply_save' else 'review_reply',args,user)
                self.core.store.put(ENTITY,{**receipt,'state':'accepted','reply':self._public(result)})
            except Exception as error:
                # Core may already have committed before an audit/receipt error.
                after=self._latest(user,self.core._get('leads',data['leadId'],user['tenant_id']))
                if isinstance(error,(CoreError,ValueError)) and before==after:
                    self.core.store.put(ENTITY,{**receipt,'state':'rejected'})
                    fail('REPLY_REJECTED',str(error),409)
                fail('REPLY_RESULT_UNCONFIRMED','草稿操作结果待核对，请读取原评论；不会自动重试',409)
            current = self.read(user,store_id,data['customerId'])
            current['receipt']={'requestId':data['requestId'],'state':'accepted','reply':self._public(result)}
            return current
