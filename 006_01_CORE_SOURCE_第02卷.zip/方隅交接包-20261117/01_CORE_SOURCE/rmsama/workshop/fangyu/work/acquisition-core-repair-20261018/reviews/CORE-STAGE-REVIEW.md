# Runtime / Core 核心增量阶段独立只读复审

结论：**当前 Critical 0 / Important 0 / Minor 0。此前2项Important、追加旧任务/snapshot问题及诊断I/O Minor均已核销。** 本报告只覆盖固定字节的Runtime/Core阶段增量与下列7条隔离用例，不是最终候选闭包、安装、原生界面、真实平台、付费AI或全平台持续验收。

| 固定对象 | 本次SHA-256 |
|---|---|
| canonical work/shared-backend-integration/platform_runtime.py | b065531c8e9272f5ab12a0c61ca3179cc64f9de83111c16d310988de2e6e00cf |
| canonical work/ui-runtime-r55/src/core/engine.py | 8bfe23870a14ec535f4c1ac9e061d47cd230e1daa4341c6361442a20063af5cd |
| W/before/work/ui-runtime-r55/src/core/engine.py（仅RED前像） | d23bff0c3f1f361819b0dc282d6d76ddf5fa77886d049f7d7597651e94a2046d |

P=`C:/积木软件工坊/项目/方隅公寓客户版`；W=`C:/积木软件工坊/项目/方隅公寓客户版/work/acquisition-core-repair-20261018`。审查员仅写W/reviews的测试、短日志和本报告，未改产品、活动carrier或交付正文，未初始化产品/AppServer，未读取真实state/DB/客户/凭据/vault，未调用CLI、网络、平台或付费provider。测试主动禁止socket connect/create_connection与subprocess.Popen。

## 已核销问题

- **原Important 1：pending未阻止下一页。** 当前每页固定IDs先入持久journal，再_drain；AI_DISABLED/NOT_CONFIGURED/非法profile/不可用AI没有completed就停在analysis_pending，未读取下一平台页。disabled不是平台认证错误。
- **原Important 2：原页IDs中断后丢失。** 当前明确resume先drain原journal，再决定下一页；未知费用门槛早于空IDs返回。到target/exhausted可只完成分析，不重读平台。
- **追加旧任务问题：无journal的历史未分析行或旧unknown被exhausted提前跳过。** 623d2086…读版独立5例曾3 PASS/2 FAIL；作者修复后，当前_drain在无journal时只为明确选中的owned同task未完成行/旧paused ai_jobs恢复固定队列，再走原workflow。当前两例均PASS，覆盖Core提交后journal创建前的退出窗口。未知费用不被视为可自动重提；零平台读。
- **追加snapshot问题：analysis_pending被generic平台失败文案遮盖。** 935aa146…读版独立复现后，当前在没有真正readiness code时优先显示企业AI未配置等分析原因；status=paused/phase=analyzing、canStart=false/canResume=true。真实当前设备/平台准入失败仍优先保留。
- **Minor 1：历史诊断I/O影响can_continue。** 当前Core只删除旧_collection_summary内3行小红书历史摘要读取，精确diff无其他变化；require_platform、_platform_execution_guard、_account_access、account ready、当前actor/target/daily/exhausted条件全部保留。测试让历史summarize_activity抛OSError，当前合格页仍can_continue=true；当前execution guard改为拒绝时仍false。

## 独立7条当前用例

统一命令：`C:/积木软件工坊/项目/方隅公寓客户版/work/desktop-python/Scripts/python.exe -I -B C:/积木软件工坊/项目/方隅公寓客户版/work/acquisition-core-repair-20261018/reviews/test_core_stage_review.py`。

**当前7/7 PASS，exit0；Runtime和Core测试前后字节一致。** 使用真实Runtime resume/journal/snapshot方法及真实Core._collection_summary；Store、页IO、AI边界全为synthetic，不执行旧套件或真实请求。

1. 已有journal的AI pending阻止下一页，并保留原IDs/code。
2. 先drain原页IDs；exhausted时不再读平台。
3. 旧AI_BILLING_UNKNOWN即使IDs为空也阻止profile/模型提交。
4. analysis_pending snapshot显示AI未配置原因，不冒充平台验证失败。
5. 无journal旧task的已入库未分析行在明确resume时先被处理。
6. 无journal旧unknown不能被写成完成或自动收费重提。
7. 历史摘要OSError不阻断当前合格页，而实际execution guard仍能拒绝。

Core诊断用例的RED来源必须明确：主作者在审查员首次执行前已备份并删除3行，因此首次当前函数直接GREEN。随后审查员**只从W/before前像AST提取_collection_summary单函数**，在同一synthetic对象/固定OSError下执行，得到预期断言失败；没有回滚当前产品、没有导入执行旧整Core。该备份前像SHA为d23bff0c…，不能写成当前源码现场RED。再对当前真实函数与另外6条统一重跑，7/7 GREEN。首次旧journal/snapshot的RED在工具输出与上方版本说明中留有事实；当前命名复跑日志是GREEN，不冒称另存了那些旧原始RED。

## 直接依赖与保留边界

已静态复核当前Runtime逐页确认结果与真实pipeline进展，沿原Core daily/target/exhausted边界停止；每页重新核actor/task binding/executor/account/lease。未恢复10页/60秒/3个imported=0人为完成条件，未引入固定40秒或1800秒后台轮询。正常小红书既有request guard/pacing及超时/取消保留；辅助抖音仍single batch，不泛称全平台持续。

每页按post_identity同帖分组≤20，固定IDs再经原_analysis_visible_leads；replace_existing=false、explicit_retry=false。组间复核actor/store/executor/pause，分析异常不重采已确认页。局部_rental_after_import回调核对当前task context/contractDigest，写独立assessment，不冒充provider输出。未发现自动回调要求员工手动重应用旧selection.applied；LocalAIWorkflow现有cloud applied_policy合同核验仍保留。

LocalAIWorkflow与AIRequestAttempts的cache、durable原请求、unknown/overlap核对和最终CAS在此仅静态审阅，并未用本7例冒充完整provider/attempt/cache集成结果；主任务另有真实Core+workflow假provider集成时，应独立列其实际证据。

取消人工复核策略也已对L七文件的实际after字节核对：account_safety固定state=observe、legacy_review_pending仅诊断，account_review_view requires_review=false；Adapters历史review gate已删除。guard-manifest risk_stop='review_required'是固定兼容标记。CLI普通activity_checkpoint不拿历史pending当准入，但本次真实401/403/429/461/471/redirect/语义错误仍risk_seen停止，不自动重放。未清活动历史、放宽UID/lease/license/journal或other-owner权限。

## 固定证据

| 文件 | SHA-256 |
|---|---|
| test_core_stage_review.py | b229715b2fac136fde26d2d41cbd177b7b41f2fdfdb9c6cea59a5752534d24e1 |
| CORE-STAGE-FOCUSED.log（当前7/7） | 2c238b8a61414468ebf0ac7a78917961ceed340a03d7f1c66bf514d30e7f141e |
| CORE-STAGE-DIAGNOSTIC-PREIMAGE-RED.log（仅备份前像1例RED） | e3cddaf86510f98d47a9d51c551ef441768e47dada6f1ad555492e6cdbb7d1e8 |
| CORE-STAGE-LEGACY-RECHECK.log（旧任务恢复2/2） | 5b963a5e2cb5cdf20cda8d065d53f882faebb9c3cdc98bf8387d8dffa00d51d3 |
| CORE-STAGE-SNAPSHOT.log（状态投影1/1） | 8bc9057a3679fc1636037b2a566c00cb313d40f11f7b9ac186809d66f061222d |

复审时间：2026-10-18T01:49:10.569045+00:00。阶段复审通过，不宣称本轮已交付。
