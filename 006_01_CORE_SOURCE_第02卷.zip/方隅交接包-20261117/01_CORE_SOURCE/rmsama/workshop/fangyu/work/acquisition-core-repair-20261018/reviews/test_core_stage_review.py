"""Independent Runtime journal/resume checks, fake data and IO only.
No product initialization, DB, network, CLI, or paid provider is used.
"""
from pathlib import Path
import sys,unittest,types,copy,socket,subprocess
from unittest.mock import patch
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(W))
import test_continuous_contract as serial_fixture
import test_synchronous_ai_contract as ai_fixture
from platform_runtime import PlatformRuntimeError

class StageJournalReview(unittest.TestCase):
 def setUp(self):
  def forbidden(*args,**kwargs):raise AssertionError('External process/network prohibited')
  self.guards=[patch.object(socket.socket,'connect',forbidden),patch.object(socket,'create_connection',forbidden),patch.object(subprocess,'Popen',forbidden)]
  for guard in self.guards:guard.start();self.addCleanup(guard.stop)
 def controller(self,pages=(1,)):
  return serial_fixture.SerialCollectionContract().controller(list(pages),with_ai=True)
 def test_existing_journal_pending_stops_before_next_page(self):
  r,exc,user,control,calls,graded,store=self.controller((1,1))
  r._analyze_collection_page=lambda *args:{'status':'pending','code':'AI_NOT_CONFIGURED','pending':1,'analyzed':0}
  with self.assertRaises(PlatformRuntimeError):r._bounded_collection(exc,user,'fixture-task',control)
  self.assertEqual(calls,[1]);task=store.get('tasks','fixture-task');q=r._pending_collection_analysis(user,task)
  self.assertEqual(q['lead_ids'],['page-1-row-0']);self.assertEqual(q['code'],'AI_NOT_CONFIGURED')
 def test_existing_journal_drains_before_any_new_page(self):
  r,exc,user,control,calls,graded,store=self.controller()
  task=store.get('tasks','fixture-task');task.update(exhausted=True);store.put('tasks',task)
  # Callback is external to the journal seam; it must run before page IO.
  r._assess_collection_page=lambda *args:None
  r._queue_collection_analysis(user,'fixture-task',['saved-page-row'])
  analyzed=[]
  def analyze(*args):analyzed.extend(args[-1]);return {'status':'completed','pending':0,'analyzed':1}
  r._analyze_collection_page=analyze;r._bounded_collection(exc,user,'fixture-task',control)
  self.assertEqual(analyzed,['saved-page-row']);self.assertEqual(calls,[])
  self.assertIsNone(r._pending_collection_analysis(user,store.get('tasks','fixture-task')))
 def test_existing_unknown_record_blocks_even_with_empty_ids(self):
  case=ai_fixture.SynchronousAIContract();f=case.fixture();r,exc,user,task,store,ai,_=f
  store.put('ai_jobs',{'id':task['id'],'tenant_id':user['tenant_id'],'owner':user['username'],'status':'paused','code':'AI_BILLING_UNKNOWN'})
  with self.assertRaises(PlatformRuntimeError) as raised:r._analyze_collection_page(exc,user,task['id'],[])
  self.assertEqual(raised.exception.code,'AI_BILLING_UNKNOWN');self.assertEqual(ai.calls,[]);self.assertEqual(ai.profile_reads,[])
 def test_analysis_pending_snapshot_does_not_report_platform_failure(self):
  case=ai_fixture.SynchronousAIContract();f=case.fixture();r,exc,user,task,store,ai,_=f
  r._runs={};r.core.running=set();r.core.sequences={}
  r.core.handle=lambda action,data,actor:store.list(data['entity'],actor['tenant_id'])
  r.core.task_progress=lambda ident:{'state':'failed','run_id':'synthetic-prior-run'}
  r._readiness=lambda *args:('','');r._collection_readiness=lambda *args:('','')
  r._active_login_job_id=lambda *args:None;r._device=lambda *args:{'bound':True,'message':''}
  r.server.company['platforms']=['xiaohongshu']
  store.put('accounts',{'id':task['account_id'],'tenant_id':user['tenant_id'],'platform':'xiaohongshu','name':'synthetic-owned-account','status':'ready','cloud_owner':user['username'],'store_id':task['store_id']})
  r._queue_collection_analysis(user,task['id'],['synthetic-pending-row'])
  row=r._pending_collection_analysis(user,task);row['code']='AI_NOT_CONFIGURED'
  # The entity name is private implementation metadata, never production data.
  from platform_runtime import _COLLECTION_ANALYSIS_ENTITY
  store.put(_COLLECTION_ANALYSIS_ENTITY,row)
  store.put('ai_jobs',{'id':task['id'],'tenant_id':user['tenant_id'],'owner':user['username'],'status':'pending','code':'AI_NOT_CONFIGURED','pending':1})
  value=r.snapshot(user)['acquisition']
  self.assertEqual(value['status'],'paused');self.assertEqual(value['phase'],'analyzing')
  self.assertFalse(value['canStart']);self.assertTrue(value['canResume'])
  self.assertIn('企业AI尚未配置',value['message'],'Known analysis-pending must not be replaced by the prior generic platform-failure message')
 def test_history_diagnostic_oserror_does_not_deny_confirmed_page_continuation(self):
  from core import Core,CoreError
  import core.engine as engine_module
  # The actual Core summary method is exercised without constructing Core/DB.
  store=ai_fixture.Store();store.directory=W/'synthetic-not-created-diagnostic-path'
  user={'id':'synthetic-diagnostic-user','tenant_id':'synthetic-diagnostic-tenant','username':'synthetic-owner'}
  task={'id':'synthetic-confirmed-task','tenant_id':user['tenant_id'],'platform':'xiaohongshu','account_id':'synthetic-diagnostic-account','status':'ready','exhausted':False,'daily_limit':100,'target_count':100}
  account={'id':task['account_id'],'tenant_id':user['tenant_id'],'status':'ready'}
  store.put('users',user);store.put('accounts',account)
  core=object.__new__(Core);core.store=store;observed=[]
  core._get=lambda entity,ident,tenant:store.get(entity,ident)
  core.require_platform=lambda platform:observed.append('require_platform')
  core._platform_execution_guard=lambda platform:observed.append('execution_guard')
  core._account_access=lambda actor,row:observed.append('account_access')
  core.task_progress=lambda ident:{}
  counts={'read':20,'filtered':20,'imported':0,'duplicates':0}
  with patch.object(engine_module,'summarize_activity',side_effect=OSError('Synthetic diagnostic file unreadable')):
   summary_method=core._collection_summary
   if globals().get('USE_PREIMAGE',False):
    import ast,types
    original=W/'before/work/ui-runtime-r55/src/core/engine.py'
    node=next(item for item in ast.walk(ast.parse(original.read_text('utf-8'))) if isinstance(item,ast.FunctionDef) and item.name=='_collection_summary')
    scope=dict(engine_module.__dict__)
    exec(compile(ast.fix_missing_locations(ast.Module(body=[node],type_ignores=[])),str(original)+'::_collection_summary','exec'),scope)
    summary_method=types.MethodType(scope['_collection_summary'],core)
   value=summary_method(task,user,'stopped','batch_limit',counts)
   self.assertTrue(value['can_continue'],'Retired historical diagnostic IO must not deny current successful-page admission')
   self.assertEqual(observed,['require_platform','execution_guard','account_access'])
   def actual_denial(platform):raise CoreError('Synthetic current execution admission denied')
   core._platform_execution_guard=actual_denial
   self.assertFalse(core._collection_summary(task,user,'stopped','batch_limit',counts)['can_continue'],'Current execution guard must still deny continuation')
 def legacy_resume(self,*,unknown=False):
  r,exc,user,control,calls,graded,store=self.controller()
  r._runs={};r._run_cancels={};r.core.running=set();r.core.sequences={}
  task=store.get('tasks','fixture-task');task.update(status='paused',exhausted=True,accumulated=1,target_count=1);store.put('tasks',task)
  store.put('leads',{'id':'legacy-ungraded-row','tenant_id':user['tenant_id'],'cloud_owner':user['username'],'task_id':task['id'],'text':'synthetic ungraded rental demand'})
  if unknown:store.put('ai_jobs',{'id':task['id'],'tenant_id':user['tenant_id'],'owner':user['username'],'status':'paused','code':'AI_BILLING_UNKNOWN'})
  r._assess_collection_page=lambda *args:None
  analyzed=[]
  def analyze(*args):
   if unknown:raise PlatformRuntimeError('AI_BILLING_UNKNOWN','Synthetic unresolved paid outcome',409)
   analyzed.extend(args[-1]);return {'status':'completed','pending':0,'analyzed':len(args[-1])}
  r._analyze_collection_page=analyze
  original=r._execute
  def execute(executor,actor,action,payload):
   if action=='task_resume':
    fresh=store.get('tasks',task['id']);fresh['status']='ready';store.put('tasks',fresh);return fresh
   return original(executor,actor,action,payload)
  r._execute=execute
  def start(executor,actor,ident):r._bounded_collection(executor,actor,ident,control);return {'result':{'taskId':ident}}
  r._start_task=start
  return r,exc,user,task,store,calls,analyzed
 def test_legacy_no_journal_resume_analyzes_owned_ungraded_rows(self):
  r,exc,user,task,store,calls,analyzed=self.legacy_resume()
  r.resume_acquisition(user,{'taskId':task['id']})
  self.assertEqual(calls,[],'Exhausted range must not be re-read')
  self.assertEqual(analyzed,['legacy-ungraded-row'],'Explicit resume must not silently complete while old stored rows remain ungraded')
 def test_legacy_no_journal_unknown_cannot_be_marked_complete(self):
  r,exc,user,task,store,calls,analyzed=self.legacy_resume(unknown=True)
  with self.assertRaises(PlatformRuntimeError) as caught:r.resume_acquisition(user,{'taskId':task['id']})
  self.assertEqual(caught.exception.code,'AI_BILLING_UNKNOWN');self.assertEqual(calls,[]);self.assertEqual(analyzed,[])

if __name__=='__main__':
 import io,hashlib
 product=W.parents[1]/'work/shared-backend-integration/platform_runtime.py'
 before=hashlib.sha256(product.read_bytes()).hexdigest()
 engine=W.parents[1]/'work/ui-runtime-r55/src/core/engine.py'
 core_before=hashlib.sha256(engine.read_bytes()).hexdigest()
 USE_PREIMAGE='--preimage' in sys.argv
 if USE_PREIMAGE:sys.argv.remove('--preimage')
 stream=io.StringIO()
 suite=(unittest.defaultTestLoader.loadTestsFromNames(sys.argv[1:],module=sys.modules[__name__]) if len(sys.argv)>1 else unittest.defaultTestLoader.loadTestsFromTestCase(StageJournalReview))
 result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
 engine=W.parents[1]/'work/ui-runtime-r55/src/core/engine.py'
 output=stream.getvalue()+'\nREVIEWED_SOURCE_SHA256 '+before+'\nREVIEWED_CORE_ENGINE_SHA256 '+core_before+'\nPRODUCT_BYTES_UNCHANGED '+str(hashlib.sha256(product.read_bytes()).hexdigest()==before and hashlib.sha256(engine.read_bytes()).hexdigest()==core_before)+'\n'
 if USE_PREIMAGE:output+='PREIMAGE_ONLY_RED_FROM_BACKUP '+hashlib.sha256((W/'before/work/ui-runtime-r55/src/core/engine.py').read_bytes()).hexdigest()+'\n'
 log_name=('CORE-STAGE-DIAGNOSTIC-PREIMAGE-RED.log' if USE_PREIMAGE else 'CORE-STAGE-DIAGNOSTIC.log' if len(sys.argv)>1 and all('history_diagnostic_oserror' in value for value in sys.argv[1:]) else 'CORE-STAGE-LEGACY-RECHECK.log' if len(sys.argv)>1 and all('legacy_no_journal' in value for value in sys.argv[1:]) else 'CORE-STAGE-SNAPSHOT.log' if len(sys.argv)>1 else 'CORE-STAGE-FOCUSED.log')
 (Path(__file__).parent/log_name).write_text(output,encoding='utf-8')
 print(output)
 raise SystemExit(0 if result.wasSuccessful() else 1)
