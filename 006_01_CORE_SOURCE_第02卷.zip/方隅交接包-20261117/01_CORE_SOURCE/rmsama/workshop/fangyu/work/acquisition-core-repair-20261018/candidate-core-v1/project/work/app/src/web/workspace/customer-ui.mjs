const {intentLabels,bindIntentHint}=await import(new URL('?asset=enterprise-model.mjs',import.meta.url));
const {verifyReceipt}=await import(new URL('?asset=contact-verification.mjs',import.meta.url));
const {handoffPresentation,traceUpgradeRoute}=await import(new URL('?asset=upgrade-model.mjs',import.meta.url));
const RESPONSE_TERMINAL=new Set(['found','not_found','partial','needs_review','unavailable','failed','interrupted','cancelled']);
const RESPONSE_ACTIVE=new Set(['queued','running']);
const PLATFORM_REPLY_ID=/^[A-Za-z0-9_-]{1,256}$/;
export function checkableReplies(replies){return (Array.isArray(replies)?replies:[]).filter(r=>r?.status==='sent'&&typeof r.id==='string'&&r.id&&PLATFORM_REPLY_ID.test(r.platform_reply_id||'')).sort((a,b)=>String(b.sent_at||b.created_at||'').localeCompare(String(a.sent_at||a.created_at||'')));}
export function latestCheckableReply(replies){return checkableReplies(replies)[0]||null;}
const excerpt=value=>String(value||'').trim().replace(/\s+/g,' ').slice(0,54)||'内容未提供';
export function incomingReplyReference(item,replies){const match=(Array.isArray(replies)?replies:[]).find(r=>item?.reply_id&&r?.id===item.reply_id&&r.status==='sent');return match?`回应的是：${excerpt(match.text)}`:'回应的是：待核对（未匹配已发送记录）';}
export function applySeenResult(row,result,authorKey){if(!row||!result||result.author_key!==authorKey||typeof result.has_new_comment!=='boolean'||!Number.isSafeInteger(result.new_post_count)||result.new_post_count<0)return false;row.has_new_comment=result.has_new_comment;row.new_post_count=result.new_post_count;if(result.viewed_at)row.viewed_at=result.viewed_at;return true;}
export function responseCheckMessage(job,cancelling=false){
 if(cancelling&&RESPONSE_ACTIVE.has(job?.status))return '已请求取消，等待在途读取结束…';
 switch(job?.status){
  case 'queued':return '检查回信已排队…';
  case 'running':return `${job.message==='等待下一次读取'?'等待下一次读取':'正在检查回信'} · 已读 ${Number(job.pages_read)||0} 页、${Number(job.comments_read)||0} 条评论`;
  case 'found':return `发现可核实回信 · 本次保存 ${Number(job.observations_saved)||0} 条`;
  case 'not_found':return '本次有限范围未发现可核实回信；不代表对方没有回复。';
  case 'partial':return '仅完成部分页面检查；未查完不代表对方没有回复。';
  case 'needs_review':return '检查已停止，凭据或账号状态需要人工核验。';
  case 'unavailable':return '当前无法检查回信；请人工核对。';
  case 'failed':return '检查失败；结果待核实。';
  case 'interrupted':return '检查中断；结果待核实。';
  case 'cancelled':return '检查已取消；在途读取已结束。';
  default:return '检查状态待核实；不会自动重新发起。';
 }
}
export function createResponseCheckController({call,isCurrent,onState,onFinished,setTimer=setTimeout,clearTimer=clearTimeout,intervalMs=1500}){
 let disposed=false,attempted=false,cancelling=false,jobId='',timer=0,finished=false;
 const current=()=>!disposed&&isCurrent(),emit=value=>{if(current())onState(value);};
 const clear=()=>{if(timer){clearTimer(timer);timer=0;}};
 const schedule=()=>{clear();if(current()&&jobId)timer=setTimer(()=>{timer=0;void poll();},intervalMs);};
 function accept(job){
  if(!current()||!jobId)return;
  if(job?.id!==jobId||typeof job.status!=='string'){clear();jobId='';emit({status:'unknown',message:responseCheckMessage(null),active:false,cancellable:false});return;}
  const terminal=RESPONSE_TERMINAL.has(job.status),active=RESPONSE_ACTIVE.has(job.status);
  emit({status:job.status,message:responseCheckMessage(job,cancelling),active,cancellable:active&&!cancelling,job});
  if(terminal){clear();jobId='';if(!finished){finished=true;void onFinished(job);}return;}
  if(active){schedule();return;}
  clear();jobId='';emit({status:'unknown',message:responseCheckMessage(null),active:false,cancellable:false});
 }
 async function poll(){if(!current()||!jobId)return;const id=jobId;try{const job=await call('customer_response_check_status',{job_id:id});if(current()&&jobId===id)accept(job);}catch{if(current()&&jobId===id){clear();jobId='';emit({status:'unknown',message:'检查状态读取失败；不会自动重新发起。',active:false,cancellable:false});}}}
 async function start(authorKey,replyId){
  if(!current()||attempted)return;
  attempted=true;emit({status:'starting',message:'正在发起一次检查回信…',active:true,cancellable:false});
  try{const job=await call('customer_response_check_start',{author_key:authorKey,reply_id:replyId});if(!current())return;if(!job?.id||typeof job.id!=='string'){emit({status:'unknown',message:responseCheckMessage(null),active:false,cancellable:false});return;}jobId=job.id;accept(job);}
  catch{emit({status:'unknown',message:'检查请求结果未确认；不会自动重新发起。',active:false,cancellable:false});}
 }
 async function cancel(){
  if(!current()||!jobId||cancelling)return;
  cancelling=true;clear();emit({status:'cancelling',message:'已请求取消，等待在途读取结束…',active:true,cancellable:false});const id=jobId;
  try{const job=await call('customer_response_check_cancel',{job_id:id});if(current()&&jobId===id){if(job?.id!==id||typeof job.status!=='string')throw Error('取消状态未确认');accept(job);}}
  catch{if(current()&&jobId===id){emit({status:'cancelling',message:'取消结果待核实，等待在途读取结束…',active:true,cancellable:false});schedule();}}
 }
 return {start,cancel,dispose(){disposed=true;clear();jobId='';},get attempted(){return attempted;}};
}
const node=(tag,text,className)=>{const n=document.createElement(tag);if(text!==undefined)n.textContent=text;if(className)n.className=className;return n;};
const labels={all:'全部',uncontacted:'未联系',contacted:'已联系',new_comment:'新评论',viewed:'看过',uncertain:'待核对',copied:'已复制',customer_replied:'客户已回应',response_unverified:'回应待核实'};
const contactLabels={sent:'已发送',external_reported:'人工记录',legacy_sent_unverified:'历史记录待核对',unknown:'结果待核对',copied:'已复制',uncontacted:'未联系'};
const platformLabels={xiaohongshu:'小红书',douyin:'抖音',zhihu:'知乎',wechat_channels:'视频号',bilibili:'哔哩哔哩',kuaishou:'快手',weibo:'微博'};
function link(url,text,platform,{profile=false}={}){
 const fallback=()=>node('span',text||'原帖未提供');
 try{
  const u=new URL(url),contracts={
   xiaohongshu:[['www.xiaohongshu.com','xiaohongshu.com'],profile?/^\/user\/profile\/[A-Za-z0-9_-]{1,160}$/:/^\/explore\/[A-Za-z0-9_-]{1,160}$/],
   douyin:[['www.douyin.com','douyin.com'],/^\/video\/[0-9]{1,40}$/],
   kuaishou:[['www.kuaishou.com'],/^\/short-video\/[A-Za-z0-9_-]{1,160}$/],
   zhihu:[['www.zhihu.com'],/^\/(?:question\/[0-9]+\/)?answer\/[0-9]{1,40}$/],
   bilibili:[['www.bilibili.com'],/^\/video\/BV[A-Za-z0-9]{10}\/?$/],
   weibo:[['weibo.com'],/^\/[1-9][0-9]{0,31}\/[A-Za-z0-9]{1,32}$/]
  },contract=contracts[platform];
  if(typeof url!=='string'||url.length>2048||/[\p{Cc}\p{Cs}]/u.test(url)||u.protocol!=='https:'||u.username||u.password||u.port||profile&&platform!=='xiaohongshu'||!contract||!contract[0].includes(u.hostname)||!contract[1].test(u.pathname))return fallback();
  // Only the original XHS signing fields may survive a source projection.
  const query=new URLSearchParams();if(platform==='xiaohongshu'&&!profile){for(const name of ['xsec_token','xsec_source']){const values=u.searchParams.getAll(name);if(values.length>1||values.length&&(!values[0].trim()||values[0].length>512||/[\p{Cc}\p{Cs}]/u.test(values[0])))return fallback();if(values.length)query.set(name,values[0]);}}
  const a=node('a',text);u.search=query.toString();u.hash='';a.href=u.href;a.target='_blank';a.rel='noopener noreferrer';return a;
 }catch{return fallback();}
}
function date(value){if(!value)return '时间待核实';const d=new Date(typeof value==='number'?value*1000:value);return Number.isNaN(+d)?'时间待核实':d.toLocaleString('zh-CN',{month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hour12:false});}
function avatar(person,local){const img=node('img',undefined,'person-avatar');img.alt=`${person.nickname||'客户'}的头像`;img.referrerPolicy='no-referrer';img.loading='lazy';let url='';if(local&&/^[a-zA-Z0-9_-]{1,200}$/.test(person.avatar_lead_id||''))url=`/saved-avatar/${encodeURIComponent(person.avatar_lead_id)}?kind=author`;else try{const u=new URL(person.avatar_url);if(u.protocol==='https:')url=u.href;}catch{}const initial=node('span',Array.from(String(person.nickname||'').trim())[0]||'客','person-avatar upgrade-avatar-fallback');initial.setAttribute('aria-label',`${person.nickname||'客户'}的昵称首字`);if(!url)return initial;img.src=url;img.onerror=()=>{img.onerror=null;img.replaceWith(initial);};return img;}
function level(person){return Object.keys(intentLabels).find(k=>person.intent_distribution?.[k]>0)||'pending';}
export function representativeCustomerComment(person,{groupBy='post',selectedPost='',intentKind='pending'}={}){
 const comments=Array.isArray(person?.comments)?person.comments:[];
 if(groupBy==='post'&&selectedPost){
  const matched=comments.find(comment=>comment?.post_key===selectedPost);
  return {comment:matched||comments[0]||null,matched:Boolean(matched)};
 }
 if(groupBy==='intent'){
  const sameGrade=comment=>{
   const intent=comment?.intent;
   return intent&&((intent.status==='graded'?intent.level:intent.status)===intentKind);
  };
  const matches=comments.filter(sameGrade);
  const chosen=matches.find(comment=>person.representative_intent_lead_id&&comment.lead_id===person.representative_intent_lead_id)
   ||matches.find(comment=>comment.intent?.source==='manual'||comment.lead?.manual_intent)||matches[0];
  return {comment:chosen||comments[0]||null,matched:Boolean(chosen)};
 }
 return {comment:comments[0]||null,matched:Boolean(comments.length)};
}
function badge(text,kind){const b=node('span',text,'intent-tag');b.dataset.level=kind;return b;}
function intentButton(kind){const b=node('button',intentLabels[kind]||'待分析','customer-intent-button intent-tag');b.type='button';b.dataset.level=kind;bindIntentHint(b,kind);return b;}
export function createCustomerWorkspace({root,execute,cloud,getUser,getScope=null,localWorkspace=true,onComment,onHandoff=null,onClose=()=>{},onSummary=()=>{},onError=()=>{}}){
 let filter='all',groupBy='intent',groupKey='',offset=0,pageSize=10,total=0,selected='',rows=[],query='',generation=0,detailGeneration=0,principal='',responseCheck=null;
 const checked=new Set();let handoffScope='all',handoffRecords=null;
 let handoffGeneration=0;
 async function refreshHandoffs(){const request=++handoffGeneration,turn=generation,own=principalNow();let items=[],page=0,total=0;do{const result=await read('handoff_list',{offset:page,limit:100});if(request!==handoffGeneration||turn!==generation||own!==principalNow())return null;total=result.total;if(!Number.isSafeInteger(total)||total>5000)throw Error('交接记录范围较大，请到资源部交接核对完整记录');items.push(...(result.items||[]));page+=100;}while(page<total);handoffRecords=items;renderRows();return items;}
 const $=id=>root.querySelector('#'+id);
 root.innerHTML='<div class="customer-toolbar"><div class="customer-view"><button id="customer-by-post" class="active" type="button" aria-pressed="true">按帖子</button><button id="customer-by-intent" type="button" aria-pressed="false">按意向</button></div><select id="customer-group" aria-label="筛选帖子或意向"><option value="">全部帖子</option></select><details id="customer-search-box" class="customer-search-box"><summary aria-label="搜索客户" title="搜索客户"><img src="?asset=fy-icon-07-search.png" alt="" aria-hidden="true"></summary><form id="customer-search"><input id="customer-query" maxlength="100" aria-label="搜索客户、评论或帖子" placeholder="搜索客户、评论或帖子"><button type="submit" class="secondary">搜索</button></form></details><button id="customer-refresh" type="button" class="customer-refresh" aria-label="刷新客户清单" title="刷新客户清单"><img src="?asset=fy-icon-63-refresh.png" alt="" aria-hidden="true"></button></div><div id="customer-tabs" class="customer-tabs" role="tablist" aria-label="客户范围"></div><p id="customer-feedback" role="status" aria-live="polite"></p><div id="customer-layout" class="customer-layout"><div class="customer-main"><div id="customer-list" class="customer-list"></div><div class="customer-pagination"><span id="customer-total"></span><div class="upgrade-pagination-controls"><button id="customer-prev" class="secondary" type="button" aria-label="上一页" title="上一页">‹</button><span id="customer-page" aria-current="page">1</span><button id="customer-next" class="secondary" type="button" aria-label="下一页" title="下一页">›</button><select id="customer-page-size" aria-label="每页客户条数"><option value="10">10条 / 页</option><option value="20">20条 / 页</option><option value="50">50条 / 页</option></select></div></div></div><aside id="customer-detail" class="customer-detail" hidden tabindex="-1" aria-label="客户记录"></aside></div>';
 const detail=$('customer-detail'),feedback=$('customer-feedback');
 const principalNow=()=>getScope?String(getScope()||''):String(getUser()?.username||'');
 const read=async(action,data)=>{const r=await execute(action,data);if(r?.status!=='succeeded')throw Error(r?.error||'客户记录尚未读取');return r.result;};
 const toolbar=$('customer-group').parentNode,groupLabel=node('label','意向等级');toolbar.insertBefore(groupLabel,$('customer-group'));groupLabel.append($('customer-group'));
 const contactLabel=node('label','联系状态'),contactScope=node('select');contactScope.setAttribute('aria-label','筛选联系状态');for(const [key,label]of Object.entries(labels))contactScope.append(new Option(label,key));contactScope.onchange=()=>{filter=contactScope.value;groupKey='';close();void load(0);};contactLabel.append(contactScope);toolbar.insertBefore(contactLabel,$('customer-search-box'));
 const handoffLabel=node('label','交接状态'),handoffSelect=node('select');handoffSelect.setAttribute('aria-label','筛选本页客户的本机交接记录');for(const [key,label]of [['all','全部'],['pending','已登记待交接'],['accepted','本机已接收'],['none','未登记交接']])handoffSelect.append(new Option(label,key));handoffLabel.append(handoffSelect);toolbar.insertBefore(handoffLabel,$('customer-search-box'));
 handoffSelect.onchange=async()=>{handoffSelect.disabled=true;const turn=generation,own=principalNow();try{if(!handoffRecords)await refreshHandoffs();if(turn!==generation||own!==principalNow())return;handoffScope=handoffSelect.value;close();await load(0);if(turn+1!==generation||own!==principalNow())return;renderRows();feedback.textContent=handoffScope==='all'?'':'按本页客户的已登记本机交接筛选；跨电脑记录尚未核验。';}catch(error){handoffSelect.value=handoffScope;onError(error);}finally{handoffSelect.disabled=false;}};
 $('customer-search-box').open=true;
 function close(){onClose();responseCheck?.dispose();responseCheck=null;detailGeneration++;traceUpgradeRoute('customer.close','',detailGeneration,true);selected='';detail.hidden=true;$('customer-layout').classList.remove('has-detail');renderRows();}
 function renderTabs(counts={}){contactScope.value=filter;const host=$('customer-tabs'),more=node('details',undefined,'customer-more'),options=node('div',undefined,'customer-more-options');host.replaceChildren();more.append(node('summary',['new_comment','viewed','uncertain','copied','response_unverified'].includes(filter)?labels[filter]:'更多'),options);for(const [key,label] of Object.entries(labels)){const b=node('button',`${label} ${counts[key]??'—'}`);b.type='button';b.dataset.filter=key;b.role='tab';b.classList.toggle('active',filter===key);b.setAttribute('aria-selected',String(filter===key));b.addEventListener('click',()=>{filter=key;groupKey='';close();void load(0);});(['new_comment','viewed','uncertain','copied','response_unverified'].includes(key)?options:host).append(b);}host.append(more);}
 function renderGroups(groups=[]){const select=$('customer-group'),current=groupKey;select.replaceChildren(new Option('全部',''));for(const group of groups){const title=groupBy==='post'?group.label:intentLabels[group.key]||group.label;select.append(new Option(`${title} · ${group.count} 人`,group.key));}if(current&&!groups.some(group=>group.key===current)){groupKey='';select.value='';}else select.value=current;for(const [id,value] of [['customer-by-post','post'],['customer-by-intent','intent']]){const b=$(id);b.classList.toggle('active',groupBy===value);b.setAttribute('aria-pressed',String(groupBy===value));}}
 function renderRows(){
  const matching=person=>(handoffRecords||[]).filter(item=>person.author_id&&item.source?.author_id===person.author_id&&item.source?.platform===person.platform),visible=handoffScope==='all'?rows:rows.filter(person=>{const records=matching(person);return handoffScope==='none'?!!person.author_id&&!records.length:records.some(item=>handoffScope==='accepted'?item.status==='accepted'&&item.resource_receipt_verified===true:['draft','ready_to_deliver'].includes(item.status));});
  const host=$('customer-list');host.replaceChildren();let lastPost='';const head=node('div',undefined,'upgrade-grid-head');head.setAttribute('role','row');const all=node('input');all.type='checkbox';all.setAttribute('aria-label','选择本页客户');all.checked=visible.length>0&&visible.every(item=>checked.has(item.author_key));all.onchange=()=>{for(const item of visible)if(all.checked)checked.add(item.author_key);else checked.delete(item.author_key);renderRows();};head.append(all);for(const label of ['客户与需求','意向','最近联系','渠道归属','下一步'])head.append(node('span',label));host.append(head);
  for(const person of visible){
   const post=person.primary_post||{},kind=level(person);
   if(groupBy==='post'&&!groupKey&&post.post_key!==lastPost){
    lastPost=post.post_key;
    const header=node('div',undefined,'customer-post-heading');
    if(post.cover_url){const cover=node('img',undefined,'customer-post-thumb');cover.src=post.cover_url;cover.alt='';cover.loading='lazy';cover.referrerPolicy='no-referrer';cover.onerror=()=>cover.remove();header.append(cover);}
    header.append(link(post.note_url,post.title||'帖子标题未提供',person.platform));
    host.append(header);
   }
   const b=node('div',undefined,'customer-row');b.tabIndex=0;b.setAttribute('role','row');b.dataset.authorKey=person.author_key;
   b.classList.toggle('selected',selected===person.author_key);
   const copy=node('div',undefined,'customer-row-copy'),heading=node('div',undefined,'customer-person-heading');
   const chip=badge(intentLabels[kind]||'待分析',kind);
   heading.append(node('strong',person.nickname||'昵称未提供'));
   const intentRow=groupBy==='intent',representative=Boolean(person.representative_intent_lead_id);
   const rowText=intentRow?(representative?person.representative_comment||'评论原文待补齐':'评级与原文待核对'):person.latest_comment||'评论正文待补齐';
   const rowTime=intentRow?(representative?person.representative_comment_at:''):person.latest_published_at||person.last_comment_at;
   const meta=node('small',`${date(rowTime)} · ${person.comment_count} 条评论${person.has_new_comment?' · 有新评论':''}`);
   copy.append(heading,node('p',rowText));
   const choice=node('input');choice.type='checkbox';choice.checked=checked.has(person.author_key);choice.setAttribute('aria-label',`选择${person.nickname||'客户'}`);choice.onclick=event=>event.stopPropagation();choice.onchange=()=>{if(choice.checked){checked.add(person.author_key);void open(person.author_key);}else checked.delete(person.author_key);};b.append(choice);
   const identity=node('div',undefined,'upgrade-row-identity');identity.append(avatar(person,localWorkspace),copy);b.append(identity);const intentCell=node('div',undefined,'upgrade-row-intent');intentCell.append(chip);b.append(intentCell);bindIntentHint(chip,kind);
   const contact=node('div',undefined,'upgrade-row-contact'),contactState=person.uncertain_contact||person.contact_state==='unknown'?'unknown':person.incoming_reply_status==='observed'?'responded':person.contact_state;contact.dataset.state=contactState;contact.append(node('span',contactState==='unknown'?'发送待核对':contactState==='responded'?'客户已回应':contactState==='uncontacted'?(['high','super_high'].includes(kind)?'待联系':'未联系'):contactLabels[contactState]||'联系待核实'),node('small',date(person.last_contact_activity_at||rowTime)));b.append(contact);
   const channel=node('div',undefined,'upgrade-row-channel'),records=matching(person),latestHandoff=records.sort((a,b)=>(b.updated_at||0)-(a.updated_at||0))[0];const handoffState=latestHandoff?handoffPresentation(latestHandoff):null;channel.dataset.tone=handoffState?.tone||'neutral';channel.title=handoffState?.label||'';channel.append(node('span',handoffState?.label||(person.author_id?'来源身份已记录':'来源身份待核实')),node('small',`${platformLabels[person.platform]||'平台待核对'} · ${person.comment_count}条评论`));b.append(channel);
   const actions=node('div',undefined,'upgrade-row-actions');if(window.fangyuUpgrade?.canCreateHandoff?.()){const handoff=node('button','整理交接','secondary');handoff.type='button';handoff.dataset.customerAction='handoff';handoff.onclick=event=>{event.stopPropagation();traceUpgradeRoute('customer.row.handoff','handoff',detailGeneration,true);void open(person.author_key,{view:'handoff'});};handoff.disabled=!person.representative_intent_lead_id;actions.append(handoff);}const view=node('button','查看详情','secondary');view.type='button';view.dataset.customerAction='contact';view.onclick=event=>{event.stopPropagation();traceUpgradeRoute('customer.row.contact-button','contact',detailGeneration,true);void open(person.author_key);};actions.append(view);b.append(actions);
   b.addEventListener('click',()=>{traceUpgradeRoute('customer.row.contact','contact',detailGeneration,true);void open(person.author_key);});b.addEventListener('keydown',event=>{if(event.target===b&&['Enter',' '].includes(event.key)){event.preventDefault();void open(person.author_key);}});host.append(b);
  }
  if(!visible.length)host.append(node('p',query?'没有匹配的客户':handoffScope!=='all'?'本页没有匹配该本机交接状态的客户':'此范围暂无客户','empty'));
  $('customer-total').textContent=`共 ${Number.isSafeInteger(total)?total:'—'} 条${handoffScope!=='all'?` · 本页匹配 ${visible.length} 位`:''}`;
  $('customer-page').textContent=String(Math.floor(offset/pageSize)+1);$('customer-page').setAttribute('aria-label',`第 ${Math.floor(offset/pageSize)+1} 页`);$('customer-page-size').value=String(pageSize);
  $('customer-prev').disabled=offset===0;$('customer-next').disabled=offset+pageSize>=total;
 }
 async function load(next=offset,accept=()=>true){const own=principalNow();if(!own)return;if(principal!==own){close();rows=[];checked.clear();groupKey='';principal=own;next=0;}const turn=++generation,size=pageSize;feedback.textContent='正在读取客户…';root.setAttribute('aria-busy','true');try{const result=await read('customer_list',{filter,query,group_by:groupBy,group_key:groupKey,offset:next,limit:size});if(turn!==generation||own!==principalNow()||!accept())return;if(next>0&&next>=result.total)return load(Math.max(0,Math.floor((result.total-1)/size)*size),accept);offset=next;total=result.total;rows=result.items||[];for(const key of checked)if(!rows.some(item=>item.author_key===key))checked.delete(key);renderTabs(result.state_counts);renderGroups(result.groups);renderRows();if(!query)onSummary(result);feedback.textContent='';delete root.dataset.stale;}catch(e){if(turn===generation&&accept()){feedback.textContent=rows.length?'刷新失败，当前显示上次读取的记录':'客户记录读取失败，请重试';root.dataset.stale='true';onError(e);}}finally{if(turn===generation){root.removeAttribute('aria-busy');if(!accept()&&feedback.textContent==='正在读取客户…')feedback.textContent='';}}}
 async function seen(authorKey,postKey){const own=principalNow(),answer=await cloud.call('customer_seen',{author_key:authorKey,...(postKey?{post_key:postKey}:{})}),result=answer?.result;if(own!==principalNow())return null;if(!result||result.author_key!==authorKey||typeof result.has_new_comment!=='boolean'||!Number.isSafeInteger(result.new_post_count))throw Error('浏览状态待核对');const row=rows.find(r=>r.author_key===authorKey);if(row&&applySeenResult(row,result,authorKey))renderRows();return result;}
 async function open(key,{view='contact',leadId=null,accept=()=>true}={}){if(typeof accept!=='function'||!accept())return false;onClose();responseCheck?.dispose();responseCheck=null;const turn=++detailGeneration,own=principalNow(),selectedMode=groupBy,selectedPost=selectedMode==='post'?groupKey:'';const current=()=>turn===detailGeneration&&own===principalNow()&&accept();traceUpgradeRoute('customer.open.start',view,turn,true);selected=key;detail.hidden=false;$('customer-layout').classList.add('has-detail');detail.replaceChildren(node('p','正在读取客户记录…','help'));renderRows();try{const p=await read('customer_detail',{author_key:key});if(!current())return false;if(leadId!==null&&p.author_key!==key)throw Error('建议客户的来源范围已变化，请重新读取处理清单');const actual=leadId===null?representativeCustomerComment(p,{groupBy:selectedMode,selectedPost,intentKind:level(p)}):exactWorklistComment(p,leadId);renderDetail(p,turn,selectedMode,selectedPost,actual,current);if(actual.matched&&actual.comment?.lead&&onComment){traceUpgradeRoute('customer.comment.start',view,turn,true);const shown=await onComment(actual.comment.lead,{inline:true,accept:current});traceUpgradeRoute('customer.comment.return',view,turn,current());if(!current()||shown===false)return false;if(view==='handoff'&&onHandoff){try{traceUpgradeRoute('customer.handoff.start',view,turn,true);await onHandoff(actual.comment.lead);traceUpgradeRoute('customer.handoff.return',view,turn,current());}catch(error){if(current())onError(error);}if(!current())return false;}}if(!current())return false;void seen(key,selectedPost).catch(()=>{if(current()){const note=node('small','浏览状态未保存，请稍后重试','help');detail.append(note);}});detail.focus({preventScroll:true});if(typeof window!=='undefined'&&window.matchMedia?.('(max-width:1000px)').matches)detail.scrollIntoView?.({block:'start',behavior:'smooth'});return current();}catch(e){if(current()){detail.replaceChildren(node('p','客户记录读取失败，请重试','help'));const b=node('button','重试','secondary');b.type='button';b.onclick=()=>void open(key,{view,leadId,accept});detail.append(b);onError(e);}return false;}}
 function fillIncoming(host,p){
  host.replaceChildren();
  if(p.incoming_reply_status==='observed'&&(p.incoming_replies||[]).length){
   const items=p.incoming_replies,replies=(p.comments||[]).flatMap(c=>c.reply_history||[]);host.append(node('h3',`客户回应 · ${items.length}`));
   const renderItem=item=>{const article=node('article',undefined,'customer-incoming-comment');article.append(node('small',date(item.published_at)),node('p',item.text||'正文待补齐'),node('small',incomingReplyReference(item,replies)),link(item.note_url,'查看回应原帖 ↗',p.platform));return article;};
   host.append(renderItem(items[0]));
   if(items.length>1){const more=node('details');more.append(node('summary',`其他回应 ${items.length-1} 条`));for(const item of items.slice(1))more.append(renderItem(item));host.append(more);}
   const evidence=node('details');evidence.append(node('summary','匹配依据'),node('p','根据已保存的评论：同一客户、同一帖子，明确回应我们的已发送评论。'));host.append(evidence);
  }else host.append(node('p','客户回信：尚未核实'),node('small','尚未发现可确认的回应；不表示客户没有回复。'));
 }
 function exactWorklistComment(person,leadId){
  if(typeof leadId!=='string'||!/^[A-Za-z0-9_-]{1,160}$/.test(leadId))throw Error('建议原记录编号无效，请重新读取处理清单');
  const matches=(person.comments||[]).filter(comment=>comment.lead_id===leadId);
  if(matches.length!==1||!matches[0].lead||matches[0].lead.id!==leadId)throw Error('建议原记录已变化或当前不可读，请重新读取处理清单');
  return {matched:true,comment:matches[0]};
 }
 function renderDetail(p,turn,selectedMode='post',selectedPost='',selectedComment=null,accept=()=>true){
  detail.replaceChildren();
  const top=node('div',undefined,'customer-detail-top'),person=node('div',undefined,'detail-person'),name=node('div',undefined,'customer-detail-name');
  name.append(node('strong',p.nickname||'昵称未提供'));
  if(p.platform==='xiaohongshu'&&p.author_id)name.append(link(`https://www.xiaohongshu.com/user/profile/${encodeURIComponent(p.author_id)}`,'主页 ↗',p.platform,{profile:true}));
  else if(!p.author_id)name.append(node('small','身份待核实'));
  person.append(avatar(p,localWorkspace),name);
  const chip=intentButton(level(p));
  const x=node('button','×','customer-detail-close');x.type='button';x.title='关闭客户详情';x.setAttribute('aria-label','关闭客户详情');x.onclick=close;
  top.append(person,chip,x);detail.append(top);
  if(p.uncertain_contact)detail.append(node('small','发送结果待核对','customer-uncertain-send'));
  const representative=selectedComment||representativeCustomerComment(p,{groupBy:selectedMode,selectedPost,intentKind:level(p)});
  const latest=representative.comment,post=(p.posts||[]).find(item=>item.post_key===latest?.post_key)||p.primary_post||{};
  const original=node('section',undefined,'customer-original');
  original.append(node('p',latest?.text||p.latest_comment||'评论原文待补齐'));
  original.append(node('small',date(latest?.published_at||latest?.created_at||p.latest_published_at||p.last_comment_at)));
  detail.append(original);
  if(!representative.matched){
   const warning=node('small',selectedMode==='intent'?'此原文未能对应客户意向，请在详情核对':'此原文未能对应所选帖子，请在详情核对','customer-uncertain-send');
   detail.append(warning);
  }
  const source=node('div',undefined,'customer-source');
  if(post.cover_url){const cover=node('img',undefined,'customer-source-cover');cover.src=post.cover_url;cover.alt='';cover.referrerPolicy='no-referrer';cover.loading='lazy';cover.onerror=()=>cover.remove();source.append(cover);}
  source.append(link(post.note_url,post.title||'查看原帖 ↗',p.platform));
  detail.append(source);
  const primary=node('button','处理这条评论','customer-primary-action');primary.type='button';
  if(representative.matched&&latest?.lead&&onComment)primary.onclick=()=>{if(accept())return onComment(latest.lead,{accept});};
  else{primary.disabled=true;primary.title='评论或评级依据待核对，请在详情中选择原评论';}
  detail.append(primary);
  const extra=node('details',undefined,'customer-extra');extra.append(node('summary',`详情 · ${p.comment_count} 条评论`));
  detail.append(extra);
  const scored=(selectedMode==='intent'&&representative.matched?latest:null)||(p.comments||[]).find(comment=>{
   const intent=comment.intent||{};return (intent.status==='graded'?intent.level:intent.status)===level(p);
  });
  if(scored){
   const evidence=node('section',undefined,'customer-rating-evidence'),intent=scored.intent||{};
   evidence.append(node('h3','评级依据'));
   const source=intent.source==='manual'||scored.lead?.manual_intent?'人工评级':intent.source==='ai'?'AI 评级':'评级来源未标明';
   evidence.append(node('small',`${source} · ${intent.reason||'未提供评级说明'}`));
   extra.append(evidence);
  }
  const postHost=node('section',undefined,'customer-posts'),posts=p.posts||[],commentsByPost=new Map();postHost.append(node('h3',`评论与帖子 · ${p.post_count}`));
  for(const comment of p.comments||[]){if(!commentsByPost.has(comment.post_key))commentsByPost.set(comment.post_key,[]);commentsByPost.get(comment.post_key).push(comment);}
  function renderPost(post){
   const section=node('div',undefined,'customer-post'),a=link(post.note_url,post.title||'查看原帖 ↗',p.platform),seenLabel=node('small',post.has_new_comment?(post.viewed_at?'该帖有新评论':'该帖评论未查看'):'该帖评论已查看','help'),own=principalNow(),current=()=>turn===detailGeneration&&selected===p.author_key&&own===principalNow()&&accept();
   const mark=()=>{if(current())void seen(p.author_key,post.post_key).then(result=>{if(current()&&result?.post_key===post.post_key&&result.viewed_at){post.viewed_at=result.viewed_at;seenLabel.textContent='该帖评论已查看';}}).catch(()=>{if(current())seenLabel.textContent='查看状态未保存，请稍后核对';});};
   a.addEventListener('click',mark);section.append(a);
   const comments=commentsByPost.get(post.post_key)||[],makeComment=c=>{const button=node('button',undefined,'customer-comment');button.type='button';button.append(node('p',c.text||'正文待补齐'),node('small',date(c.published_at)));button.onclick=()=>{if(current()){mark();onComment?.(c.lead,{accept:current});}};return button;};
   for(const c of comments.slice(0,2))section.append(makeComment(c));
   if(comments.length>2){const more=node('details');more.append(node('summary',`另外 ${comments.length-2} 条评论`));for(const c of comments.slice(2))more.append(makeComment(c));section.append(more);}
   section.append(seenLabel);return section;
  }
  for(const post of posts.slice(0,5))postHost.append(renderPost(post));
  if(posts.length>5){const more=node('details',undefined,'customer-post-more');more.append(node('summary',`其他帖子 ${posts.length-5} 篇`));more.addEventListener('toggle',()=>{if(more.open&&!more.dataset.rendered){more.dataset.rendered='true';for(const post of posts.slice(5))more.append(renderPost(post));}});postHost.append(more);}extra.append(postHost);
  const history=node('section',undefined,'customer-contact-history');history.append(node('h3','联系记录'));const replies=(p.comments||[]).flatMap(c=>(c.reply_history||[]).map(r=>({...r,lead_id:c.lead_id,post_key:c.post_key}))).sort((a,b)=>String(b.sent_at||b.created_at).localeCompare(String(a.sent_at||a.created_at)));
  if(!replies.length)history.append(node('p','尚无联系记录','help'));
  function renderReply(r){const row=node('article',undefined,'customer-reply'),meta=node('div',undefined,'customer-reply-meta'),status=node('span',r.status==='sent'?'已发送 · 云端待核对':r.status==='external_reported'?'人工标记已联系':r.status==='copied'?'已复制，发送未核实':['unknown','sending'].includes(r.status)?'发送结果待核对':r.status==='draft'?'草稿 · 未发送':r.status==='approved'?'已审核 · 未发送':r.status==='failed'?'发送失败':'记录待核对');meta.append(node('small',date(r.sent_at||r.created_at)),status);row.append(meta,node('p',r.text));
   if(r.status==='sent'){const check=node('button','核对云端记录','text-button');check.type='button';async function verify(){if(!accept())return;check.disabled=true;status.textContent='正在核对云端记录…';try{const receipt=await verifyReceipt(d=>read('contact_receipt_status',d),d=>cloud.call('contact_receipts_verify',d),r.id);if(turn!==detailGeneration||!accept())return;status.textContent=receipt.text;status.dataset.verified=receipt.status;}catch{if(turn===detailGeneration&&accept()){status.textContent='已发送 · 云端核对失败';status.dataset.verified='failed';}}finally{if(turn===detailGeneration&&accept())check.disabled=false;}}check.onclick=()=>void verify();row.append(check);void verify();}
   return row;
  }
  for(const r of replies.slice(0,3))history.append(renderReply(r));
  if(replies.length>3){const more=node('details',undefined,'customer-reply-more');more.append(node('summary',`更早联系记录 ${replies.length-3} 条`));more.addEventListener('toggle',()=>{if(more.open&&!more.dataset.rendered){more.dataset.rendered='true';for(const r of replies.slice(3))more.append(renderReply(r));}});history.append(more);}extra.append(history);
   const incoming=node('section',undefined,'customer-incoming'),incomingBody=node('div',undefined,'customer-incoming-body');fillIncoming(incomingBody,p);incoming.dataset.state=p.incoming_reply_status||'';incoming.append(incomingBody);
   const candidates=checkableReplies(replies),hasSent=replies.some(r=>r.status==='sent'),postTitles=new Map(posts.map(post=>[post.post_key,post.title||'原帖标题未提供']));
   if(localWorkspace&&p.author_id&&candidates.length){
    const actions=node('div',undefined,'customer-response-actions'),source=node('select'),sourceLabel=node('label','检查哪条已发回复'),start=node('button','检查回信','secondary'),cancel=node('button','取消检查','text-button'),state=node('small','尚未检查平台回信','help');
    source.setAttribute('aria-label','选择检查的已发送回复');for(const r of candidates){const option=node('option',`${date(r.sent_at||r.created_at)} · 原帖：${excerpt(postTitles.get(r.post_key))} · 我方：${excerpt(r.text)}`);option.value=r.id;source.append(option);}source.value=candidates[0].id;sourceLabel.append(source);
    start.type='button';cancel.type='button';cancel.hidden=true;state.setAttribute('role','status');state.setAttribute('aria-live','polite');actions.append(sourceLabel,start,cancel,state);const missingIds=replies.filter(r=>r.status==='sent'&&!PLATFORM_REPLY_ID.test(r.platform_reply_id||'')).length;if(missingIds)actions.append(node('small',`另有 ${missingIds} 条旧发送记录无平台 ID，暂不能自动查`,'help'));incoming.append(actions);
    const own=principalNow(),current=()=>turn===detailGeneration&&selected===p.author_key&&own===principalNow()&&!detail.hidden&&!root.hidden&&accept();
    const call=async(name,data)=>{const answer=await cloud.call(name,data);if(!answer?.result||typeof answer.result!=='object')throw Error('检查状态未确认');return answer.result;};
    const controller=createResponseCheckController({call,isCurrent:current,onState:update=>{state.textContent=update.message;state.classList.toggle('is-checking',update.active);cancel.hidden=!update.cancellable;start.disabled=true;source.disabled=true;},
     onFinished:async()=>{try{const fresh=await read('customer_detail',{author_key:p.author_key});if(!current())return;fillIncoming(incomingBody,fresh);incoming.dataset.state=fresh.incoming_reply_status||'';if(fresh.incoming_reply_status==='observed'&&(fresh.incoming_replies||[]).length)extra.insertBefore(incoming,postHost);await load(offset,current);}catch{if(current())state.textContent+=' · 本机记录刷新失败，请重开客户记录';}}});
    responseCheck=controller;
    start.onclick=()=>void controller.start(p.author_key,source.value);
    cancel.onclick=()=>void controller.cancel();
   }else if(localWorkspace&&hasSent){const note=node('div',undefined,'customer-response-unavailable');note.append(node('small',p.author_id?'此记录暂不能自动查回信':'客户身份待核实，暂不能自动查回信','help'));const why=node('details');why.append(node('summary','?'),node('small','仅真实发送且保留平台回复 ID 的记录可检查；旧记录不补造 ID，刷新本机记录也不会查询平台。'));note.append(why);incoming.append(note);}
   if(p.incoming_reply_status==='observed'&&(p.incoming_replies||[]).length){
    const visibleReply=node('div',undefined,'customer-reply-preview');visibleReply.append(node('strong','客户已回应'),node('p',p.incoming_replies[0].text||'回应正文待补齐'));detail.insertBefore(visibleReply,source);
    extra.insertBefore(incoming,postHost);
   }else extra.append(incoming);

 }
 $('customer-search').addEventListener('submit',e=>{e.preventDefault();query=$('customer-query').value.trim();groupKey='';$('customer-search-box').open=Boolean(query);close();void load(0);});
 for(const [id,value] of [['customer-by-post','post'],['customer-by-intent','intent']])$(id).onclick=()=>{if(groupBy===value)return;groupBy=value;groupKey='';close();void load(0);};
 $('customer-group').onchange=e=>{groupKey=e.currentTarget.value;close();void load(0);};
 $('customer-refresh').onclick=()=>void load();$('customer-prev').onclick=()=>void load(Math.max(0,offset-pageSize));$('customer-next').onclick=()=>void load(offset+pageSize);$('customer-page-size').onchange=()=>{const size=Number($('customer-page-size').value);if(![10,20,50].includes(size))return;pageSize=size;checked.clear();close();void load(0);};renderTabs();
 function exportCurrent(){const selectedRows=rows.filter(item=>checked.has(item.author_key)),items=selectedRows.length?selectedRows:rows;const cell=value=>'"'+String(value??'').replace(/^[\s\uFEFF]*[=+\-@]|^[\t\r\n]/u,"'$&").replace(/"/g,'""')+'"';const csv='\uFEFF'+[['客户','平台','平台身份','意向','联系记录','原始评论'],...items.map(item=>[item.nickname,item.platform,item.author_id,intentLabels[level(item)]||'待核对',item.uncertain_contact?'发送待核对':item.incoming_reply_status==='observed'?'客户已回应':contactLabels[item.contact_state]||'待核实',item.representative_comment||item.latest_comment])].map(row=>row.map(cell).join(',')).join('\r\n');const url=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'})),download=node('a');download.href=url;download.download=`方隅客户清单-${selectedRows.length?'已选':'本页'}.csv`;download.click();setTimeout(()=>URL.revokeObjectURL(url),1000);feedback.textContent=`已导出${items.length}位${selectedRows.length?'已选':'本页'}客户，未对外发送。`;}
 return {load,open,refreshHandoffs,redraw:renderRows,exportCurrent,filters(){root.classList.toggle('show-extra-filters');},reset(){generation++;handoffGeneration++;detailGeneration++;principal='';rows=[];checked.clear();handoffRecords=null;handoffScope='all';handoffSelect.value='all';offset=0;total=0;groupKey='';query='';filter='all';groupBy='intent';$('customer-query').value='';root.removeAttribute('aria-busy');delete root.dataset.stale;close();detail.replaceChildren();feedback.textContent='';renderTabs();renderGroups();renderRows();}};
}
