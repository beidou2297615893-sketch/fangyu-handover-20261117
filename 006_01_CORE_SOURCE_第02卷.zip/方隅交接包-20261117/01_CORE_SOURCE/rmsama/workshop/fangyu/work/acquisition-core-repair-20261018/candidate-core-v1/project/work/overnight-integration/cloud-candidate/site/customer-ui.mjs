const {intentLabels}=await import(new URL('?asset=enterprise-model.mjs',import.meta.url));
const {verifyReceipt}=await import(new URL('?asset=contact-verification.mjs',import.meta.url));
const RESPONSE_TERMINAL=new Set(['found','not_found','partial','needs_review','unavailable','failed','interrupted','cancelled']);
const RESPONSE_ACTIVE=new Set(['queued','running']);
const PLATFORM_REPLY_ID=/^[A-Za-z0-9_-]{1,256}$/;
export function checkableReplies(replies){return (Array.isArray(replies)?replies:[]).filter(r=>r?.status==='sent'&&typeof r.id==='string'&&r.id&&PLATFORM_REPLY_ID.test(r.platform_reply_id||'')).sort((a,b)=>String(b.sent_at||b.created_at||'').localeCompare(String(a.sent_at||a.created_at||'')));}
export function latestCheckableReply(replies){return checkableReplies(replies)[0]||null;}
const excerpt=value=>String(value||'').trim().replace(/\s+/g,' ').slice(0,54)||'内容未提供';
export function incomingReplyReference(item,replies){const match=(Array.isArray(replies)?replies:[]).find(r=>item?.reply_id&&r?.id===item.reply_id&&r.status==='sent');return match?`回应的是：${excerpt(match.text)}`:'回应的是：待核对（未匹配已发送记录）';}
export function applySeenResult(row,result,authorKey){if(!row||!result||result.author_key!==authorKey||typeof result.has_new_comment!=='boolean'||!Number.isSafeInteger(result.new_post_count)||result.new_post_count<0)return false;row.has_new_comment=result.has_new_comment;row.new_post_count=result.new_post_count;if(result.viewed_at)row.viewed_at=result.viewed_at;return true;}
export function responseCheckMessage(job,cancelling=false){
 if(cancelling&&RESPONSE_ACTIVE.has(job?.status))return '已请求取消，等待在途读取结束…';
 switch(job?.status){
  case 'queued':return '检查回信已排队…';
  case 'running':return `${job.message==='等待下一次读取'?'等待下一次读取':'正在检查回信'} · 已读 ${Number(job.pages_read)||0} 页、${Number(job.comments_read)||0} 条评论`;
  case 'found':return `发现可核实回信 · 本次保存 ${Number(job.observations_saved)||0} 条`;
  case 'not_found':return '本次有限范围未发现可核实回信；不代表对方没有回复。';
  case 'partial':return '仅完成部分页面检查；未查完不代表对方没有回复。';
  case 'needs_review':return '检查已停止，凭据或账号状态需要人工核验。';
  case 'unavailable':return '当前无法检查回信；请人工核对。';
  case 'failed':return '检查失败；结果待核实。';
  case 'interrupted':return '检查中断；结果待核实。';
  case 'cancelled':return '检查已取消；在途读取已结束。';
  default:return '检查状态待核实；不会自动重新发起。';
 }
}
export function createResponseCheckController({call,isCurrent,onState,onFinished,setTimer=setTimeout,clearTimer=clearTimeout,intervalMs=1500}){
 let disposed=false,attempted=false,cancelling=false,jobId='',timer=0,finished=false;
 const current=()=>!disposed&&isCurrent(),emit=value=>{if(current())onState(value);};
 const clear=()=>{if(timer){clearTimer(timer);timer=0;}};
 const schedule=()=>{clear();if(current()&&jobId)timer=setTimer(()=>{timer=0;void poll();},intervalMs);};
 function accept(job){
  if(!current()||!jobId)return;
  if(job?.id!==jobId||typeof job.status!=='string'){clear();jobId='';emit({status:'unknown',message:responseCheckMessage(null),active:false,cancellable:false});return;}
  const terminal=RESPONSE_TERMINAL.has(job.status),active=RESPONSE_ACTIVE.has(job.status);
  emit({status:job.status,message:responseCheckMessage(job,cancelling),active,cancellable:active&&!cancelling,job});
  if(terminal){clear();jobId='';if(!finished){finished=true;void onFinished(job);}return;}
  if(active){schedule();return;}
  clear();jobId='';emit({status:'unknown',message:responseCheckMessage(null),active:false,cancellable:false});
 }
 async function poll(){if(!current()||!jobId)return;const id=jobId;try{const job=await call('customer_response_check_status',{job_id:id});if(current()&&jobId===id)accept(job);}catch{if(current()&&jobId===id){clear();jobId='';emit({status:'unknown',message:'检查状态读取失败；不会自动重新发起。',active:false,cancellable:false});}}}
 async function start(authorKey,replyId){
  if(!current()||attempted)return;
  attempted=true;emit({status:'starting',message:'正在发起一次检查回信…',active:true,cancellable:false});
  try{const job=await call('customer_response_check_start',{author_key:authorKey,reply_id:replyId});if(!current())return;if(!job?.id||typeof job.id!=='string'){emit({status:'unknown',message:responseCheckMessage(null),active:false,cancellable:false});return;}jobId=job.id;accept(job);}
  catch{emit({status:'unknown',message:'检查请求结果未确认；不会自动重新发起。',active:false,cancellable:false});}
 }
 async function cancel(){
  if(!current()||!jobId||cancelling)return;
  cancelling=true;clear();emit({status:'cancelling',message:'已请求取消，等待在途读取结束…',active:true,cancellable:false});const id=jobId;
  try{const job=await call('customer_response_check_cancel',{job_id:id});if(current()&&jobId===id){if(job?.id!==id||typeof job.status!=='string')throw Error('取消状态未确认');accept(job);}}
  catch{if(current()&&jobId===id){emit({status:'cancelling',message:'取消结果待核实，等待在途读取结束…',active:true,cancellable:false});schedule();}}
 }
 return {start,cancel,dispose(){disposed=true;clear();jobId='';},get attempted(){return attempted;}};
}
const node=(tag,text,className)=>{const n=document.createElement(tag);if(text!==undefined)n.textContent=text;if(className)n.className=className;return n;};
const labels={all:'全部',uncontacted:'未联系',contacted:'已联系',new_comment:'新评论',viewed:'看过',uncertain:'待核对',copied:'已复制',customer_replied:'客户已回应',response_unverified:'回应待核实'};
const contactLabels={sent:'已发送',external_reported:'人工记录',legacy_sent_unverified:'历史记录待核对',unknown:'结果待核对',copied:'已复制',uncontacted:'未联系'};
function link(url,text){const a=node('a',text);try{const u=new URL(url);if(u.protocol!=='https:'||!['www.xiaohongshu.com','xiaohongshu.com'].includes(u.hostname))return node('span',text||'原帖未提供');a.href=u.href;a.target='_blank';a.rel='noopener noreferrer';return a;}catch{return node('span',text||'原帖未提供');}}
function date(value){if(!value)return '时间待核实';const d=new Date(typeof value==='number'?value*1000:value);return Number.isNaN(+d)?'时间待核实':d.toLocaleString('zh-CN',{month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hour12:false});}
function avatar(person,local){const img=node('img',undefined,'person-avatar');img.alt=`${person.nickname||'客户'}的头像`;img.referrerPolicy='no-referrer';img.loading='lazy';let url='?asset=fy-icon-16-user.png';if(local&&/^[a-zA-Z0-9_-]{1,200}$/.test(person.avatar_lead_id||''))url=`/saved-avatar/${encodeURIComponent(person.avatar_lead_id)}?kind=author`;else try{const u=new URL(person.avatar_url);if(u.protocol==='https:')url=u.href;}catch{}img.src=url;img.onerror=()=>{img.onerror=null;img.src='?asset=fy-icon-16-user.png';};return img;}
function level(person){return Object.keys(intentLabels).find(k=>person.intent_distribution?.[k]>0)||'pending';}
function badge(text,kind){const b=node('span',text,'intent-tag');b.dataset.level=kind;return b;}
export function createCustomerWorkspace({root,execute,cloud,getUser,localWorkspace=true,onComment,onError=()=>{}}){
 let filter='all',offset=0,total=0,selected='',rows=[],query='',generation=0,detailGeneration=0,principal='',responseCheck=null;
 const $=id=>root.querySelector('#'+id);
 root.innerHTML='<div class="customer-toolbar"><form id="customer-search"><input id="customer-query" maxlength="100" aria-label="搜索客户、评论或帖子" placeholder="搜索客户、评论或帖子"><button type="submit" class="secondary">搜索</button></form><button id="customer-refresh" type="button" class="text-button">刷新本机记录</button></div><div id="customer-tabs" class="customer-tabs" role="tablist" aria-label="客户范围"></div><p id="customer-feedback" role="status" aria-live="polite"></p><div id="customer-layout" class="customer-layout"><div class="customer-main"><div id="customer-list" class="customer-list"></div><div class="customer-pagination"><button id="customer-prev" class="secondary" type="button">上一页</button><span id="customer-page"></span><button id="customer-next" class="secondary" type="button">下一页</button></div></div><aside id="customer-detail" class="customer-detail" hidden tabindex="-1" aria-label="客户记录"></aside></div>';
 const detail=$('customer-detail'),feedback=$('customer-feedback');
 const principalNow=()=>String(getUser()?.username||'');
 const read=async(action,data)=>{const r=await execute(action,data);if(r?.status!=='succeeded')throw Error(r?.error||'客户记录尚未读取');return r.result;};
 function close(){responseCheck?.dispose();responseCheck=null;detailGeneration++;selected='';detail.hidden=true;$('customer-layout').classList.remove('has-detail');renderRows();}
 function renderTabs(counts={}){const host=$('customer-tabs'),more=node('details',undefined,'customer-more'),options=node('div',undefined,'customer-more-options');host.replaceChildren();more.append(node('summary',['viewed','uncertain','copied','response_unverified'].includes(filter)?labels[filter]:'更多'),options);for(const [key,label] of Object.entries(labels)){const b=node('button',`${label} ${counts[key]??'—'}`);b.type='button';b.dataset.filter=key;b.role='tab';b.classList.toggle('active',filter===key);b.setAttribute('aria-selected',String(filter===key));b.addEventListener('click',()=>{filter=key;close();void load(0);});(['viewed','uncertain','copied','response_unverified'].includes(key)?options:host).append(b);}host.append(more);}
 function renderRows(){const host=$('customer-list');host.replaceChildren();for(const person of rows){const b=node('button',undefined,'customer-row');b.type='button';b.dataset.authorKey=person.author_key;b.classList.toggle('selected',selected===person.author_key);const copy=node('div',undefined,'customer-row-copy'),heading=node('div',undefined,'customer-person-heading'),kind=level(person);heading.append(node('strong',person.nickname||'昵称未提供'),badge(intentLabels[kind],kind));const status=node('span',contactLabels[person.contact_state]||'待核对','customer-contact-state');status.dataset.state=person.contact_state;if(person.incoming_reply_status==='observed')heading.append(node('span','客户已回应','customer-response-badge'));heading.append(status);if(person.contact_state==='sent'&&person.uncertain_contact)heading.append(node('small','另有发送待核对','customer-uncertain-send'));const newCount=Number.isSafeInteger(person.new_post_count)?person.new_post_count:0;const meta=node('small',`${person.post_count} 篇帖子 · ${person.comment_count} 条评论 · ${date(person.latest_published_at||person.last_comment_at)}${person.viewed_at?' · 看过':''}${newCount?` · ${newCount} 帖有新评论`:person.has_new_comment?' · 有新评论':''}`);copy.append(heading,node('p',person.latest_comment||'评论正文待补齐'),meta);b.append(avatar(person,localWorkspace),copy,node('span','›','customer-chevron'));b.addEventListener('click',()=>void open(person.author_key));host.append(b);}if(!rows.length)host.append(node('p',query?'没有匹配的客户':'此范围暂无客户','empty'));$('customer-page').textContent=total?`${offset+1}–${Math.min(offset+rows.length,total)} / ${total}`:'0 / 0';$('customer-prev').disabled=offset===0;$('customer-next').disabled=offset+20>=total;}
 async function load(next=offset,accept=()=>true){const own=principalNow();if(!own)return;if(principal!==own){close();rows=[];principal=own;}const turn=++generation;feedback.textContent='正在读取客户…';root.setAttribute('aria-busy','true');try{const result=await read('customer_list',{filter,query,offset:next,limit:20});if(turn!==generation||own!==principalNow()||!accept())return;offset=next;total=result.total;rows=result.items||[];renderTabs(result.state_counts);renderRows();feedback.textContent='';delete root.dataset.stale;}catch(e){if(turn===generation&&accept()){feedback.textContent=rows.length?'刷新失败，当前显示上次读取的记录':'客户记录读取失败，请重试';root.dataset.stale='true';onError(e);}}finally{if(turn===generation){root.removeAttribute('aria-busy');if(!accept()&&feedback.textContent==='正在读取客户…')feedback.textContent='';}}}
 async function seen(authorKey,postKey){const own=principalNow(),answer=await cloud.call('customer_seen',{author_key:authorKey,...(postKey?{post_key:postKey}:{})}),result=answer?.result;if(own!==principalNow())return null;if(!result||result.author_key!==authorKey||typeof result.has_new_comment!=='boolean'||!Number.isSafeInteger(result.new_post_count))throw Error('浏览状态待核对');const row=rows.find(r=>r.author_key===authorKey);if(row&&applySeenResult(row,result,authorKey))renderRows();return result;}
 async function open(key){responseCheck?.dispose();responseCheck=null;const turn=++detailGeneration,own=principalNow();selected=key;detail.hidden=false;$('customer-layout').classList.add('has-detail');detail.replaceChildren(node('p','正在读取客户记录…','help'));renderRows();try{const p=await read('customer_detail',{author_key:key});if(turn!==detailGeneration||own!==principalNow())return;renderDetail(p,turn);void seen(key).catch(()=>{if(turn===detailGeneration&&own===principalNow()){const note=node('small','浏览状态未保存，请稍后重试','help');detail.append(note);}});detail.focus({preventScroll:true});if(typeof window!=='undefined'&&window.matchMedia?.('(max-width:1000px)').matches)detail.scrollIntoView?.({block:'start',behavior:'smooth'});}catch(e){if(turn===detailGeneration&&own===principalNow()){detail.replaceChildren(node('p','客户记录读取失败，请重试','help'));const b=node('button','重试','secondary');b.type='button';b.onclick=()=>void open(key);detail.append(b);onError(e);}}}
 function fillIncoming(host,p){
  host.replaceChildren();
  if(p.incoming_reply_status==='observed'&&(p.incoming_replies||[]).length){
   const items=p.incoming_replies,replies=(p.comments||[]).flatMap(c=>c.reply_history||[]);host.append(node('h3',`客户回应 · ${items.length}`));
   const renderItem=item=>{const article=node('article',undefined,'customer-incoming-comment');article.append(node('small',date(item.published_at)),node('p',item.text||'正文待补齐'),node('small',incomingReplyReference(item,replies)),link(item.note_url,'查看回应原帖 ↗'));return article;};
   host.append(renderItem(items[0]));
   if(items.length>1){const more=node('details');more.append(node('summary',`其他回应 ${items.length-1} 条`));for(const item of items.slice(1))more.append(renderItem(item));host.append(more);}
   const evidence=node('details');evidence.append(node('summary','匹配依据'),node('p','根据已保存的评论：同一客户、同一帖子，明确回应我们的已发送评论。'));host.append(evidence);
  }else host.append(node('p','客户回信：尚未核实'),node('small','尚未发现可确认的回应；不表示客户没有回复。'));
 }
 function renderDetail(p,turn){detail.replaceChildren();const top=node('div',undefined,'customer-detail-top'),person=node('div',undefined,'detail-person'),name=node('div');name.append(node('strong',p.nickname||'昵称未提供'));if(p.author_id)name.append(link(`https://www.xiaohongshu.com/user/profile/${encodeURIComponent(p.author_id)}`,'小红书主页 ↗'));else name.append(node('small','身份待核实'));person.append(avatar(p,localWorkspace),name);const x=node('button','关闭','text-button');x.type='button';x.onclick=close;top.append(person,x);detail.append(top,badge(intentLabels[level(p)],level(p)));if(p.contact_state==='sent'&&p.uncertain_contact)detail.append(node('small','另有发送待核对','customer-uncertain-send'));
  const postHost=node('section',undefined,'customer-posts'),posts=p.posts||[],commentsByPost=new Map();postHost.append(node('h3',`评论与帖子 · ${p.post_count}`));
  for(const comment of p.comments||[]){if(!commentsByPost.has(comment.post_key))commentsByPost.set(comment.post_key,[]);commentsByPost.get(comment.post_key).push(comment);}
  function renderPost(post){
   const section=node('div',undefined,'customer-post'),a=link(post.note_url,post.title||'查看原帖 ↗'),seenLabel=node('small',post.viewed_at?'该帖评论已查看':'该帖评论未查看','help'),own=principalNow(),current=()=>turn===detailGeneration&&selected===p.author_key&&own===principalNow();
   const mark=()=>void seen(p.author_key,post.post_key).then(result=>{if(current()&&result?.post_key===post.post_key&&result.viewed_at){post.viewed_at=result.viewed_at;seenLabel.textContent='该帖评论已查看';}}).catch(()=>{if(current())seenLabel.textContent='查看状态未保存，请稍后核对';});
   a.addEventListener('click',mark);section.append(a);
   const comments=commentsByPost.get(post.post_key)||[],makeComment=c=>{const button=node('button',undefined,'customer-comment');button.type='button';button.append(node('p',c.text||'正文待补齐'),node('small',date(c.published_at)));button.onclick=()=>{mark();onComment?.(c.lead);};return button;};
   for(const c of comments.slice(0,2))section.append(makeComment(c));
   if(comments.length>2){const more=node('details');more.append(node('summary',`另外 ${comments.length-2} 条评论`));for(const c of comments.slice(2))more.append(makeComment(c));section.append(more);}
   section.append(seenLabel);return section;
  }
  for(const post of posts.slice(0,5))postHost.append(renderPost(post));
  if(posts.length>5){const more=node('details',undefined,'customer-post-more');more.append(node('summary',`其他帖子 ${posts.length-5} 篇`));more.addEventListener('toggle',()=>{if(more.open&&!more.dataset.rendered){more.dataset.rendered='true';for(const post of posts.slice(5))more.append(renderPost(post));}});postHost.append(more);}detail.append(postHost);
  const history=node('section',undefined,'customer-contact-history');history.append(node('h3','联系记录'));const replies=(p.comments||[]).flatMap(c=>(c.reply_history||[]).map(r=>({...r,lead_id:c.lead_id,post_key:c.post_key}))).sort((a,b)=>String(b.sent_at||b.created_at).localeCompare(String(a.sent_at||a.created_at)));
  if(!replies.length)history.append(node('p','尚无联系记录','help'));
  function renderReply(r){const row=node('article',undefined,'customer-reply'),meta=node('div',undefined,'customer-reply-meta'),status=node('span',r.status==='sent'?'已发送 · 云端待核对':r.status==='external_reported'?'人工标记已联系':r.status==='copied'?'已复制，发送未核实':['unknown','sending'].includes(r.status)?'发送结果待核对':r.status==='draft'?'草稿 · 未发送':r.status==='approved'?'已审核 · 未发送':r.status==='failed'?'发送失败':'记录待核对');meta.append(node('small',date(r.sent_at||r.created_at)),status);row.append(meta,node('p',r.text));
   if(r.status==='sent'){const check=node('button','核对云端记录','text-button');check.type='button';async function verify(){check.disabled=true;status.textContent='正在核对云端记录…';try{const receipt=await verifyReceipt(d=>read('contact_receipt_status',d),d=>cloud.call('contact_receipts_verify',d),r.id);if(turn!==detailGeneration)return;status.textContent=receipt.text;status.dataset.verified=receipt.status;}catch{if(turn===detailGeneration){status.textContent='已发送 · 云端核对失败';status.dataset.verified='failed';}}finally{if(turn===detailGeneration)check.disabled=false;}}check.onclick=()=>void verify();row.append(check);void verify();}
   return row;
  }
  for(const r of replies.slice(0,3))history.append(renderReply(r));
  if(replies.length>3){const more=node('details',undefined,'customer-reply-more');more.append(node('summary',`更早联系记录 ${replies.length-3} 条`));more.addEventListener('toggle',()=>{if(more.open&&!more.dataset.rendered){more.dataset.rendered='true';for(const r of replies.slice(3))more.append(renderReply(r));}});history.append(more);}detail.append(history);
   const incoming=node('section',undefined,'customer-incoming'),incomingBody=node('div',undefined,'customer-incoming-body');fillIncoming(incomingBody,p);incoming.dataset.state=p.incoming_reply_status||'';incoming.append(incomingBody);
   const candidates=checkableReplies(replies),hasSent=replies.some(r=>r.status==='sent'),postTitles=new Map(posts.map(post=>[post.post_key,post.title||'原帖标题未提供']));
   if(localWorkspace&&p.author_id&&candidates.length){
    const actions=node('div',undefined,'customer-response-actions'),source=node('select'),sourceLabel=node('label','检查哪条已发回复'),start=node('button','检查回信','secondary'),cancel=node('button','取消检查','text-button'),state=node('small','尚未检查平台回信','help');
    source.setAttribute('aria-label','选择检查的已发送回复');for(const r of candidates){const option=node('option',`${date(r.sent_at||r.created_at)} · 原帖：${excerpt(postTitles.get(r.post_key))} · 我方：${excerpt(r.text)}`);option.value=r.id;source.append(option);}source.value=candidates[0].id;sourceLabel.append(source);
    start.type='button';cancel.type='button';cancel.hidden=true;state.setAttribute('role','status');state.setAttribute('aria-live','polite');actions.append(sourceLabel,start,cancel,state);const missingIds=replies.filter(r=>r.status==='sent'&&!PLATFORM_REPLY_ID.test(r.platform_reply_id||'')).length;if(missingIds)actions.append(node('small',`另有 ${missingIds} 条旧发送记录无平台 ID，暂不能自动查`,'help'));incoming.append(actions);
    const own=principalNow(),current=()=>turn===detailGeneration&&selected===p.author_key&&own===principalNow()&&!detail.hidden&&!root.hidden;
    const call=async(name,data)=>{const answer=await cloud.call(name,data);if(!answer?.result||typeof answer.result!=='object')throw Error('检查状态未确认');return answer.result;};
    const controller=createResponseCheckController({call,isCurrent:current,onState:update=>{state.textContent=update.message;state.classList.toggle('is-checking',update.active);cancel.hidden=!update.cancellable;start.disabled=true;source.disabled=true;},
     onFinished:async()=>{try{const fresh=await read('customer_detail',{author_key:p.author_key});if(!current())return;fillIncoming(incomingBody,fresh);incoming.dataset.state=fresh.incoming_reply_status||'';if(fresh.incoming_reply_status==='observed'&&(fresh.incoming_replies||[]).length)detail.insertBefore(incoming,postHost);await load(offset,current);}catch{if(current())state.textContent+=' · 本机记录刷新失败，请重开客户记录';}}});
    responseCheck=controller;
    start.onclick=()=>void controller.start(p.author_key,source.value);
    cancel.onclick=()=>void controller.cancel();
   }else if(localWorkspace&&hasSent){const note=node('div',undefined,'customer-response-unavailable');note.append(node('small',p.author_id?'此记录暂不能自动查回信':'客户身份待核实，暂不能自动查回信','help'));const why=node('details');why.append(node('summary','?'),node('small','仅真实发送且保留平台回复 ID 的记录可检查；旧记录不补造 ID，刷新本机记录也不会查询平台。'));note.append(why);incoming.append(note);}
   if(p.incoming_reply_status==='observed'&&(p.incoming_replies||[]).length)detail.insertBefore(incoming,postHost);else detail.append(incoming);

 }
 $('customer-search').addEventListener('submit',e=>{e.preventDefault();query=$('customer-query').value.trim();close();void load(0);});$('customer-refresh').onclick=()=>void load();$('customer-prev').onclick=()=>void load(Math.max(0,offset-20));$('customer-next').onclick=()=>void load(offset+20);renderTabs();
 return {load,open,reset(){generation++;detailGeneration++;principal='';rows=[];offset=0;total=0;close();renderRows();}};
}
