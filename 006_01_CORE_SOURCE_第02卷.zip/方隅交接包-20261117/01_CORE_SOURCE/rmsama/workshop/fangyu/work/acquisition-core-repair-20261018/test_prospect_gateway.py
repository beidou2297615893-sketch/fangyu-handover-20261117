import unittest
from test_intent_projection import CurrentIntentProjection

class ProspectGateway(CurrentIntentProjection):
 def seed_people(self):
  self.add('real-renter','我想整租古北一居，预算3000元每月，明天下午三点可以看房吗')
  self.add('not-customer','我是中介，这里有一居房源出租，欢迎私信我')
  self.backend._assess_imported(self.user,self.task_id)
 def test_prospect_option_reaches_customer_service_through_actual_gateway(self):
  self.seed_people()
  result=self.backend.dispatch('customers',{'page':1,'pageSize':20,'audience':'prospects'},self.token)
  self.assertEqual(result['customers']['total'],1)
  self.assertEqual(result['customers']['items'][0]['eligibility'],'rental_seeker')
 def test_latest_intent_contains_prospects_only_but_counts_all_analyzed(self):
  self.seed_people()
  result=self.backend.customer_workbench.acquisition_summary(self.user,self.store,self.task_id)
  self.assertEqual(result['analyzed'],2)
  self.assertEqual(len(result['recent']),1)
  self.assertIn('高意向',result['recent'][0]['level'])

if __name__=='__main__':
 suite=unittest.TestSuite(ProspectGateway(n) for n in ProspectGateway.__dict__ if n.startswith('test_'))
 raise SystemExit(not unittest.TextTestRunner(verbosity=2).run(suite).wasSuccessful())
