const {verifyReceipt}=await import(new URL('?asset=contact-verification.mjs',import.meta.url));
const {explicitNeedCards,handoffPresentation,traceUpgradeRoute}=await import(new URL('?asset=upgrade-model.mjs',import.meta.url));
const {effectiveIntent,intentFacts,intentLabels,intentReplyGuidance,intentAdvice,bindIntentHint,exactCustomer,customerContactLine,customerPrincipalSignature,sameCustomerContext,intentGroupCount,continuousPayload,matchingContinuousTask,continuousStartAction,continuousPresentation,groupComments,updatePresentation,displayCommentDate,workspaceHeaderDate,replyAccountSelection}=await import(new URL('?asset=enterprise-model.mjs',import.meta.url));
const $=id=>document.getElementById(id);
const el=(tag,text,cls)=>{const n=document.createElement(tag);if(text!==undefined)n.textContent=String(text);if(cls)n.className=cls;return n;};
export function displayIntent(lead){
 if(lead?.analysis_status==='missing_text'&&!lead.manual_intent&&!lead.ai_intent&&!String(lead.text||'').trim())
  return {status:'uncertain',level:null,label:'正文待补',kind:'uncertain',reason:'评论正文缺失，补齐后自动分析'};
 return effectiveIntent(lead);
}
export function replyStateLabel(state){
 return ({none:'未回复',draft:'草稿',approved:'已审核，待发送',copied:'已复制，未发送',sending:'正在发送',unknown:'结果待核对',sent:'已回复'})[state]||'状态待核对';
}
export function employeeAiFinancialText(value,fallback='AI 暂不可用，仍待分析；请联系管理员'){
 const message=String(value||'');
 return /余额|充值|预算|额度|费用|花费|支出|账单|账务|¥|￥|CNY|RMB|billing|quota|credit|spend/i.test(message)?fallback:message;
}
export function aiConfigFieldsMatch(request,actual){
 if(!request||!actual)return false;
 for(const field of ['provider','model','reasoning_effort','enabled','daily_budget_cny','usd_cny_rate','rules_version']){
  if(!Object.hasOwn(request,field))continue;
  if(field==='daily_budget_cny'||field==='usd_cny_rate'){
   if(typeof actual[field]!=='number'||!Number.isFinite(actual[field])||Number(request[field])!==actual[field])return false;
  }else if(request[field]!==actual[field])return false;
 }
 return true;
}
export function aiModelStatus({profile={},analysis={},keywordBusy=false}={}){
 const labels={'gpt-6.1-sol':'GPT‑6.1 Sol','gpt-5.4-mini':'GPT‑5.4 mini','deepseek-flash':'DeepSeek Flash','deepseek-v4-pro':'DeepSeek V4 Pro'};
 const labelFor=model=>{
  if(Object.hasOwn(labels,model))return labels[model];
  if(typeof model==='string')for(const [id,label] of Object.entries(labels))if(model.startsWith(id+'-')&&/^\d{4}-\d{2}-\d{2}$/.test(model.slice(id.length+1)))return `${label}（${model.slice(id.length+1)}）`;
  return '';
 };
 if(!profile.configured)return 'AI 待配置';
 const label=labelFor(profile.model);if(!label)return 'AI 模型待核对';
 if(!profile.enabled)return `${label} · 未启用`;
 if(keywordBusy)return `${label} · 正在联想关键词`;
 if(analysis.status==='running')return `${labelFor(analysis.model)||label} · 正在分析`;
 return `${label} · ${analysis.status==='paused'?'分析已暂停':'已配置'}`;
}
export function analysisStatusView({analysis={},profileStatus='unknown',pending=null,imported=0,taskId='',city=''}){
 const code=analysis.code||'',balance=code==='AI_PROVIDER_BALANCE',providerAuth=code==='AI_PROVIDER_AUTH';
 const budget=code==='AI_DAILY_BUDGET',billing=code==='AI_BILLING_UNKNOWN',config=code==='AI_NOT_CONFIGURED',service=code==='AI_TRANSACTION_UNAVAILABLE';
 const review=['PRODUCT_REQUEST_UNKNOWN','PRODUCT_REQUEST_RESOLVED','PRODUCT_SETTLEMENT_UNCERTAIN','PRODUCT_BILLING_ROLLBACK_UNAVAILABLE'].includes(code),productHold=code.startsWith('PRODUCT_'),manualGate=analysis.status==='paused'&&['AI_NOT_CONFIGURED','AI_DAILY_BUDGET','PRODUCT_ANALYSIS_LIMIT'].includes(code);
 const context=code==='AI_CONTEXT_REQUIRED',missing=Number(analysis.excluded_missing_text||0);
 const enabled=profileStatus==='enabled',saved=Number(imported||0)>0||Number(pending||0)>0||missing>0;
 const safeMessage=typeof analysis.message==='string'&&analysis.message.length<=180&&!/token|cookie|Traceback|Error:|https?:\/\//i.test(analysis.message)?employeeAiFinancialText(analysis.message):'';
 const summary=review?'原分析待核对':productHold?'服务权益待核对':balance||budget||billing?'AI 暂不可用':providerAuth?'AI 密钥需检查':context?'AI 待补范围':
  profileStatus==='not_configured'||config?'AI 待配置':profileStatus==='disabled'?'AI 未启用':
  service||profileStatus==='unavailable'?'AI 暂不可用':missing&&!pending?'无正文待核实':pending>0?`待分析 ${pending} 条`:'分析状态';
 const state=review?'原分析结果待核对；请到管理中心核对原编号，暂勿重复分析':productHold?'服务权益或用量需核对；评论已保存，仍待分析':balance||budget||billing?'评论已保存，AI 暂不可用，仍待分析；请联系管理员':
  providerAuth?(safeMessage&&/密钥|API/.test(safeMessage)?safeMessage:'企业 AI 密钥需管理员检查；评论仍待分析'):
  context?(!String(city||'').trim()?'补充任务城市后自动分析；评论已保存':safeMessage||'核对帖子与评论资料后自动分析'):
  missing&&!pending?`${missing} 条评论正文缺失，待核实；补齐后自动分析`:
  profileStatus==='not_configured'?saved?'评论已保存；企业 AI 尚未配置，待管理员启用':'企业 AI 尚未配置，当前不会自动分析':
  profileStatus==='disabled'?saved?'评论已保存；企业 AI 未启用，待管理员启用':'企业 AI 未启用，当前不会自动分析':
  profileStatus==='unavailable'?'AI 状态暂不可用，请核对分析结果':!enabled?'AI 状态待读取':
  config?'企业 AI 尚未启用，请联系管理员配置':
  service?'企业 AI 暂不可用，评论待分析':employeeAiFinancialText(safeMessage)||(pending!==null?`待分析 ${pending} 条`:'采集后自动分析');
 const retryVisible=!!taskId&&enabled&&!review&&(!productHold||manualGate)&&(!budget||manualGate)&&!billing&&(!config||manualGate)&&!service&&
  (analysis.status==='pending'&&code&&(analysis.retry_count===undefined||analysis.retry_count>=3)||
   ['failed','retry_wait','paused'].includes(analysis.status));
 return {summary,state,retryVisible,retryLabel:manualGate?'核对配置后继续分析':balance?'继续分析':providerAuth?'检查密钥后继续分析':'重新分析',enabled};
}
const ANALYSIS_FAILURE_TEXT=Object.freeze({
 PRODUCT_REQUEST_UNKNOWN:'原分析结果未知，请到管理中心核对原编号；暂勿重复请求',
 PRODUCT_REQUEST_RESOLVED:'原请求已结束，请到管理中心核对原记录；暂勿重复请求',
 PRODUCT_SETTLEMENT_UNCERTAIN:'原分析结算状态未确认，请核对原编号；暂勿重复请求',
 PRODUCT_BILLING_ROLLBACK_UNAVAILABLE:'原预算预留状态未确认，请核对原编号；暂勿重复请求',
 PRODUCT_ANALYSIS_LIMIT:'当前服务的意向分析额度已达限制，请核对服务权益',
 PRODUCT_AI_DAILY_BUDGET:'企业每日预算已达限制，请核对企业 AI 设置',
 PRODUCT_AI_NOT_CONFIGURED:'企业 AI 尚未配置，请管理员配置后再明确发起操作',
 PRODUCT_PERIOD_REQUIRED:'服务计费周期尚未配置，请核对服务权益',
 PRODUCT_PERIOD_INACTIVE:'当前服务周期未生效，请核对服务权益',
 PRODUCT_SUBSCRIPTION_EXPIRED:'服务周期已结束，请核对服务权益',
 PRODUCT_FEATURE_DISABLED:'当前服务未启用此功能，请核对服务权益',
 PRODUCT_SUBSCRIPTION_INACTIVE:'当前服务权益未生效，请核对服务配置',

 AI_PROVIDER_UNAVAILABLE:'AI 服务连接失败，评论已保存，仍待分析；请联系管理员',
 AI_PROVIDER_TIMEOUT:'AI 服务连接超时，评论已保存，仍待分析；请联系管理员',
 AI_PROVIDER_BALANCE:'AI 暂不可用，评论仍待分析，请联系管理员',
 AI_PROVIDER_AUTH:'企业 AI 密钥需管理员检查；这不是员工登录问题',
 AI_DAILY_BUDGET:'AI 暂不可用，评论仍待分析，请联系管理员',
 AI_BILLING_UNKNOWN:'AI 暂不可用，评论仍待分析，请联系管理员',
 AI_NOT_CONFIGURED:'企业 AI 尚未配置，请管理员启用后继续分析',
 AI_CONFIG_CHANGED:'AI 设置已更新，请重试分析',
 AI_CONTEXT_REQUIRED:'补充任务城市或缺失资料后自动分析',
 AI_INVALID_OUTPUT:'AI 返回未通过校验，评论仍待分析，请管理员核对',
});
const KEYWORD_FAILURE_TEXT=Object.freeze({
 PRODUCT_REQUEST_UNKNOWN:'原分析结果未知，请到管理中心核对原编号；暂勿重复请求',
 PRODUCT_REQUEST_RESOLVED:'原请求已结束，请到管理中心核对原记录；暂勿重复请求',
 PRODUCT_SETTLEMENT_UNCERTAIN:'原分析结算状态未确认，请核对原编号；暂勿重复请求',
 PRODUCT_BILLING_ROLLBACK_UNAVAILABLE:'原预算预留状态未确认，请核对原编号；暂勿重复请求',
 PRODUCT_ANALYSIS_LIMIT:'当前服务的意向分析额度已达限制，请核对服务权益',
 PRODUCT_AI_DAILY_BUDGET:'企业每日预算已达限制，请核对企业 AI 设置',
 PRODUCT_AI_NOT_CONFIGURED:'企业 AI 尚未配置，请管理员配置后再明确发起操作',
 PRODUCT_PERIOD_REQUIRED:'服务计费周期尚未配置，请核对服务权益',
 PRODUCT_PERIOD_INACTIVE:'当前服务周期未生效，请核对服务权益',
 PRODUCT_SUBSCRIPTION_EXPIRED:'服务周期已结束，请核对服务权益',
 PRODUCT_FEATURE_DISABLED:'当前服务未启用此功能，请核对服务权益',
 PRODUCT_SUBSCRIPTION_INACTIVE:'当前服务权益未生效，请核对服务配置',

 AI_PROVIDER_UNAVAILABLE:'AI 服务连接失败，暂未生成关键词；请联系管理员',
 AI_PROVIDER_TIMEOUT:'AI 服务连接超时，暂未生成关键词；请联系管理员',
 AI_PROVIDER_BALANCE:'AI 暂不可用，请联系管理员后重新推荐',
 AI_PROVIDER_AUTH:'企业 AI 密钥需管理员检查，修复后重新推荐；这不是员工登录问题',
 AI_DAILY_BUDGET:'AI 暂不可用，请联系管理员后重新推荐',
 AI_BILLING_UNKNOWN:'AI 暂不可用，请联系管理员后重新推荐',
 AI_NOT_CONFIGURED:'企业 AI 尚未配置，请管理员启用后重新推荐',
 AI_CONFIG_CHANGED:'AI 设置已更新，请重新推荐',
 AI_CONTEXT_REQUIRED:'请补充任务城市或缺失资料后重新推荐',
 AI_INVALID_OUTPUT:'AI 关键词返回未通过校验，请管理员核对后重新推荐',
});
export function commandFailure(name,answer){
 const code=typeof answer?.result?.code==='string'?answer.result.code:'';
 const knownAI=name==='intent_analyze_pending'||name==='keyword_recommend';
 const messages=name==='keyword_recommend'?KEYWORD_FAILURE_TEXT:ANALYSIS_FAILURE_TEXT;
 const fixed=knownAI&&Object.hasOwn(messages,code)?messages[code]:'';
 const message=knownAI?fixed||'操作尚未完成，请核对状态':answer?.error||'操作尚未完成，请核对状态';
 const error=Error(message);
 if(fixed)error.code=code;
 if(['uncertain','expired','queued','running','claimed'].includes(answer?.status)||!answer){error.requestId=answer?.requestId;error.commandId=answer?.commandId;}
 return error;
}
export function mediaUrl(value){try{const u=new URL(String(value||''));return u.protocol==='https:'&&!u.username&&!u.password&&/(^|\.)(xhscdn\.com|xiaohongshu\.com)$/.test(u.hostname)?u.href:'';}catch{return '';}}
export function avatarSource(url,leadId='',kind='author',localWorkspace=false){
 if(localWorkspace&&typeof leadId==='string'&&leadId.trim()&&leadId.length<=160&&['author','post_author'].includes(kind))return `/saved-avatar/${encodeURIComponent(leadId)}?kind=${kind}`;
 return mediaUrl(url)||'?asset=fy-icon-16-user.png';
}
const avatarFallbacks=new WeakMap();
function setAvatar(n,url,name='',leadId='',kind='author',localWorkspace=false){avatarFallbacks.get(n)?.remove();avatarFallbacks.delete(n);n.hidden=false;n.alt=name?`${name}的头像`:'';n.referrerPolicy='no-referrer';n.loading='lazy';const fallback=()=>{if(n.onerror!==fallback||!n.parentNode)return;n.hidden=true;n.dataset.fallback='true';avatarFallbacks.get(n)?.remove();const initial=el('span',Array.from(String(name).trim())[0]||'客','person-avatar upgrade-avatar-fallback');initial.setAttribute('aria-label',name?`${name}的昵称首字`:'客户昵称未提供');n.after(initial);avatarFallbacks.set(n,initial);};n.onerror=fallback;n.onload=()=>{if(n.dataset.fallback==='true'&&n.src.endsWith('fy-icon-16-user.png'))return;avatarFallbacks.get(n)?.remove();avatarFallbacks.delete(n);n.hidden=false;n.dataset.fallback='false';};const source=avatarSource(url,leadId,kind,localWorkspace);n.src=source;n.dataset.fallback=String(source==='?asset=fy-icon-16-user.png');if(n.dataset.fallback==='true')queueMicrotask(fallback);return n;}
const avatar=(url,name,leadId='',kind='author',localWorkspace=false)=>setAvatar(el('img',undefined,'person-avatar'),url,name,leadId,kind,localWorkspace);
export function collectionProgramFailureText(error){
 const raw=String(error?.message||error||'');
 if(/verification_required|not_authenticated|ip_blocked|(?:HTTP[ :]*|状态码[ :]*)(?:401|403|429|461|471)\b/i.test(raw))return '';
 return /protocol_error|unsupported_operation|CLI 返回无效结果|CLI.*(?:不支持|启动失败|运行失败)|命令.*参数.*(?:无效|不支持)/i.test(raw)?'采集程序出现问题，登录记录仍保留，请查看失败详情。':'';
}
function sourceLink(url,title){const n=el(/^https:\/\//.test(url||'')?'a':'span',title);if(n.tagName==='A'){n.href=url;n.target='_blank';n.rel='noopener noreferrer';n.title='打开原网页；在外部网页回复不会自动成为已核验联系记录';}return n;}
export async function confirmFreshCollectionAccess(action,refresh,held){
 if(action==='continuous_pause')return;
 if(action!=='continuous_start'&&action!=='continuous_resume')throw Error('未知采集操作');
 await refresh();
 if(held())throw Error('持续只读验收未开放或已到期');
}
export function requireAccountReviewClear(accounts,accountId,localWorkspace=true){
 const account=(accounts||[]).find(item=>item.id===accountId&&item.platform==='xiaohongshu');
 if(!account||account.status!=='ready')throw Error('所选小红书账号状态已变化，请刷新账号状态');
 if(account.requires_review===true){
  const reason=account.review_reason;
  const destination=localWorkspace?'左侧「小红书账号」':'对应电脑的方隅工作台「小红书账号」';
  throw Error(reason==='verification_required'?`采集请求暂未被小红书接受，请查看手机是否有提醒，并到${destination}核对`:reason==='unknown'?`账号安全记录暂无法核对，请稍后在${destination}检查`:`账号需人工复核，请到${destination}核对`);
 }
 return account;
}
export function placeCollectionDemand({open,demand,home,dialogHost}){
 const host=open?dialogHost:home;
 if(demand.parentNode!==host)host.prepend(demand);
}
export function createKeywordPoolState(call,changed=()=>{}){
 let state=null,version=0,saved=0,timer=0,saving=null,generation=0,readGeneration=0,error=null;
 const scope=request=>JSON.stringify([String(request?.city||'').trim(),String(request?.area||'').trim()]);
 const notify=()=>changed({state,status:error?'error':saving||version>saved?'saving':state?'saved':'loading',generation});
 const clone=value=>JSON.parse(JSON.stringify(value));
 async function flush(){
  clearTimeout(timer);timer=0;
  if(!state||version===saved)return state;
  if(saving){await saving;if(version>saved)return flush();return state;}
  const current=state,token=generation;
  saving=(async()=>{
   while(version>saved){
    if(token!==generation)return;
    const target=version,draft=clone(current.draft),expectedRevision=current.revision;
    try{const answer=await call('keyword_state',{mode:'save',...draft.request,keywords:draft.keywords,selected:draft.selected,expected_revision:expectedRevision});
     if(!answer?.library||typeof answer.library.revision!=='number')throw Error('关键词保存结果未确认');
     if(token!==generation)return;
     current.revision=answer.library.revision;current.exists=true;saved=target;error=null;
    }catch(cause){if(token===generation)error=cause;throw cause;}
   }
  })().finally(()=>{saving=null;if(token===generation)notify();});
  notify();await saving;return state;
 }
 async function open(request={city:'',area:''}){
  const readToken=++readGeneration;
  if(state&&scope(request)===scope(state.draft.request)&&String(request.city||'').trim())return state;
  if(state&&version>saved)await flush();
  if(readToken!==readGeneration)return null;
  const token=++generation;state=null;version=saved=0;error=null;notify();
  const answer=await call('keyword_state',{mode:'read',city:String(request.city||'').trim(),area:String(request.area||'').trim()});
  if(token!==generation||readToken!==readGeneration)return null;
  const library=answer?.library||null,actual=library?.request||request;
  state={revision:Number(library?.revision||0),draft:{request:{city:String(actual.city||'').trim(),area:String(actual.area||'').trim(),seeds:Array.isArray(actual.seeds)?actual.seeds:[],count:Number(actual.count)||50},keywords:Array.isArray(library?.keywords)?clone(library.keywords):[],selected:Array.isArray(library?.selected)?[...library.selected]:[]},exists:!!library};
  notify();return state;
 }
 function edit(request,keywords,selected){
  if(!state||scope(request)!==scope(state.draft.request))throw Error('正在读取当前地区的常用关键词');
  const next={request:{city:String(request.city||'').trim(),area:String(request.area||'').trim(),seeds:[...(request.seeds||[])],count:Number(request.count)||50},keywords:clone(keywords),selected:[...selected]};
  if(JSON.stringify(next)===JSON.stringify(state.draft))return;
  state.draft=next;
  version++;error=null;clearTimeout(timer);timer=setTimeout(()=>{void flush().catch(()=>{});},250);notify();
 }
 async function retry(){
  if(!state)return null;
  if(error){const {city,area}=state.draft.request;const answer=await call('keyword_state',{mode:'read',city,area});state.revision=Number(answer?.library?.revision||0);error=null;}
  return flush();
 }
 async function refreshRevision(){if(!state)return null;const current=state,token=generation;try{if(saving)await saving;}catch{}if(token!==generation||state!==current)return null;const {city,area}=current.draft.request,answer=await call('keyword_state',{mode:'read',city,area});if(token!==generation||state!==current)return null;current.revision=Number(answer?.library?.revision||0);current.exists=!!answer?.library;error=null;notify();return answer?.library||null;}
 function clear(){clearTimeout(timer);timer=0;readGeneration++;generation++;state=null;version=saved=0;error=null;notify();}
 return {open,edit,flush,retry,refreshRevision,clear,get current(){return state;},get dirty(){return version>saved;},get status(){return error?'error':saving||version>saved?'saving':state?'saved':'loading';},get generation(){return generation;}};
}
export async function runPauseRequest({taskId,deviceId,submit,onChange}){
 const state=phase=>onChange(phase?{taskId,deviceId,phase}:null);
 state('request');
 try{
  const result=await submit(),continuous=result?.continuous;
  state(continuous?.status==='paused'?continuous.inflight?'inflight':null:'uncertain');
  return result;
 }catch(error){
  const uncertain=!!(error.requestId||error.commandId);state(uncertain?'uncertain':null);
  if(uncertain)error.message='暂停结果待核对，请刷新状态，暂勿重复操作';
  throw error;
 }
}
export function createEnterpriseWorkspace({execute,cloud,getState,getUser,held,collectionHeld,onError,onPage,onCustomerRecord=async()=>{},pageVersion=()=>0,onWorkspaceAccounts=()=>{},localWorkspace=false,beforeStart=async()=>{}}) {
 let keywordsExpanded=false,worklistTimer=0,worklistRefreshing=false,sessionGeneration=0;
 let keywords=[],selected=new Set(),libraryId='',keywordApproval=null,keywordAttemptSignature='',taskId='',hydratedTaskId='',savedForStart=null,savedForStartDevice='',pendingSave=null,collectionUncertain=null,task=null,pollTimer=0,clockTimer=0,queueTimer=0,detailFrame=0,confirmedReplies=new Set(),confirmedAccount='',worklistScope='pending',groupBy='note',groupKey='',offset=0,groupOffset=0,total=0,groupsTotal=0,groupRows=[],selectionId='',externalSelectionId='',selectedLead=null,reply=null,contactReceipt=null,replyNeedsCheck=false,replyReadStatus='ready',queue=null,rows=[],readGeneration=0,detailGeneration=0,leadOpenGeneration=0,profileGeneration=0,disposed=false,aiProfileStatus='unknown',aiProfile={},aiConfig=null,keywordBusy=false,analysisBusy=false,pauseFeedback=null,collectionBusy='',updateState=null,updateBusy=false,updateUnknown=false,updateError='';
 let worklistTaskId='',worklistTaskScopeToken=0,worklistTaskBinding='',worklistSummaryScope='';
 let worklistSummary={pending:null,priority:null,analysis:null,sent:null,all:null,analyzed:null,missing:null},worklistSummaryAt=0,worklistSummaryRead=null,worklistSummarySerial=0;
 let navigationPending={scope:'',count:null};
 const browserReply=el('button','在原帖回复','secondary');browserReply.id='reply-browser';browserReply.type='button';browserReply.hidden=true;$('reply-confirm').after(browserReply);let browserReplyBusy=false;
 const manualCopy=el('button','复制已审核回复','secondary'),manualConfirm=el('button','确认已在网页人工发送','secondary'),manualLocator=el('button','人工发送定位','secondary');let manualReplyBusy=false,manualReplyOperation=0;
 for(const button of [manualCopy,manualConfirm,manualLocator]){button.type='button';button.hidden=true;button.disabled=true;browserReply.after(button);}
 const manualQueueNotice=el('small','','upgrade-muted');manualQueueNotice.hidden=true;manualCopy.after(manualQueueNotice);
 $('reply-confirm').title='先核对草稿并加入本机待发送清单；最终确认发送才会发出，不会自动发送。';$('queue-prepare').textContent='准备待发送清单';
 const draftRetry=el('button','重试','text-button');draftRetry.id='reply-draft-retry';draftRetry.type='button';draftRetry.hidden=true;$('reply-feedback').after(draftRetry);
 const form=$('task'),field=name=>form.elements.namedItem(name),feedback=$('continuous-feedback');
 // Keep the employee surface to a title, one toolbar and the actual work.
 const compactToolbar=document.querySelector('.worklist-toolbar'),compactView=document.querySelector('.worklist-viewbar');
 compactToolbar.append(compactView);
 const taskCommentScope=el('div',undefined,'worklist-task-scope help actions'),taskCommentLabel=el('span'),taskCommentAll=el('button','查看全部评论','text-button');taskCommentScope.id='worklist-task-scope';taskCommentScope.hidden=true;taskCommentScope.setAttribute('aria-live','polite');taskCommentLabel.id='worklist-task-scope-label';taskCommentAll.id='worklist-task-clear';taskCommentAll.type='button';taskCommentScope.append(taskCommentLabel,taskCommentAll);compactToolbar.after(taskCommentScope);
 taskCommentAll.addEventListener('click',guard(openAllTaskComments));
 const advancedScopes=el('div',undefined,'worklist-advanced-scopes');advancedScopes.setAttribute('role','tablist');advancedScopes.setAttribute('aria-label','其他评论范围');
 advancedScopes.append($('analysis-tab'));document.querySelector('.worklist-search').append(advancedScopes);
 document.querySelector('.worklist-intro').hidden=true;$('worklist-page-top').hidden=true;
 const compactDetail=$('reply-detail'),detailPerson=compactDetail.querySelector('.detail-person');
 compactDetail.querySelector(':scope>.section-heading').hidden=false;
 $('reply-next-step').hidden=true;
 const postLine=compactDetail.querySelector('.detail-post-line');postLine.prepend($('reply-cover'));
 postLine.querySelector(':scope>span').hidden=true;
 const sourceCoverEmpty=el('span','暂无封面','upgrade-source-cover-empty');sourceCoverEmpty.id='upgrade-source-cover-empty';postLine.insertBefore(sourceCoverEmpty,$('reply-post'));
 const sourceCopy=el('div',undefined,'upgrade-source-copy'),sourceSummary=el('p'),sourceBottom=el('div',undefined,'upgrade-source-bottom'),sourceDate=el('time'),sourceOpen=el('span');sourceSummary.id='upgrade-source-summary';sourceDate.id='upgrade-source-comment-date';sourceOpen.id='upgrade-source-open';sourceBottom.append(sourceDate,sourceOpen);sourceCopy.append($('reply-post'),sourceSummary,sourceBottom);postLine.append(sourceCopy);
 compactDetail.querySelector('.detail-key-info h3').hidden=true;
 compactDetail.querySelector('.detail-review>summary').textContent='详情';
 compactDetail.querySelector('.detail-review-body').prepend($('reply-customer-context'));
 compactDetail.querySelector('.detail-reply>label').hidden=false;
 $('reply-text').placeholder='输入回复…';$('reply-text').setAttribute('aria-label','回复内容');
 const compactProgress=$('continuous-panel');compactProgress.querySelector('.continuous-main').append(document.querySelector('.continuous-actions'));
 const progressDetails=$('collection-details');progressDetails.querySelector('summary').textContent='详情';
 progressDetails.append($('continuous-steps'),compactProgress.querySelector('.continuous-micro'));
 $('continuous-heading').hidden=true;
 const keywordPool=localWorkspace?createKeywordPoolState((name,data)=>cloud.call(name,data),({state,status})=>{
  const label=$('keyword-save-state');label.textContent=status==='error'?'未保存，请重试':status==='saving'?'正在保存关键词…':status==='saved'?'常用关键词已保存':'正在读取常用关键词…';
  label.dataset.state=status;
  if(state&&poolReadPending===false)renderKeywords();
 }):null;
 let poolReadPending=false,poolRegionTimer=0,poolInputGeneration=0,poolRestoring=false;
 const settingsDialog=$('collection-dialog'),demand=$('collection-demand'),demandHome=demand.parentNode,dialogDemandHost=$('dialog-demand-host');let settingsReturnFocus=null,invalidQueued=false;
 const extraEvidence=el('div',undefined,'reply-extra-evidence');$('reply-analysis-details').append(extraEvidence);
 compactDetail.querySelector('.detail-review-body').append(compactDetail.querySelector('.detail-key-info'));
 const needCardsHost=$('upgrade-need-cards'),originalNeedEvidence=el('div',undefined,'upgrade-original-need-evidence');$('reply-analysis-details').append(originalNeedEvidence);
 function renderNeedCards(lead){const cards=explicitNeedCards(lead.text);needCardsHost.replaceChildren();originalNeedEvidence.replaceChildren();for(const item of cards){const card=el('div',undefined,'upgrade-need-card'),icon=el('img');icon.alt='';icon.src=item.key==='area'?'?asset=tabler-upgrade-pin.svg':'?asset=tabler-upgrade-budget.svg';card.append(icon,el('span',item.label),el('strong',item.value));card.title=item.evidence?`原文提到：${item.evidence}`:'原文未明确，不推断客户要求';needCardsHost.append(card);if(item.known)originalNeedEvidence.append(el('p',`原文${item.label}片段：${item.evidence}`,'help'));}const facts=intentFacts(lead)||[],count=facts.length||cards.filter(item=>item.known).length;compactDetail.querySelector('.detail-review>summary').textContent=`判断依据（${count}条）`;}
 const customerStatus=$('reply-customer-state'),customerLink=$('reply-customer-link');let customerKey='';
 const customerCurrent=request=>sameCustomerContext(request,{generation:detailGeneration,pageVersion:pageVersion(),leadId:selectionId,
  platform:selectedLead?.platform,authorId:String(selectedLead?.author_id||'').trim(),principal:customerPrincipalSignature(getUser()),
  page:$('workspace').dataset.page,disposed});
 async function refreshCustomerContext(lead,generation){
  customerKey='';customerLink.hidden=true;customerStatus.textContent='客户记录待核实';
  if(!localWorkspace){$('reply-customer-context').hidden=true;return;}
  $('reply-customer-context').hidden=false;
  const platform=String(lead.platform||''),authorId=String(lead.author_id||'').trim();
  if(!platform||!authorId||authorId.length>100){customerStatus.textContent='平台身份待核实';return;}
  const request={generation,pageVersion:pageVersion(),leadId:lead.id,platform,authorId,principal:customerPrincipalSignature(getUser())};
  customerStatus.textContent='正在核对同一客户记录…';
  try{
   const result=await action('customer_list',{filter:'all',query:authorId,offset:0,limit:100});
   if(!customerCurrent(request))return;
   const person=exactCustomer(result.items,platform,authorId);
   if(!person){customerStatus.textContent='同一客户记录未核实';return;}
   customerKey=person.author_key;customerStatus.textContent=customerContactLine(person);customerLink.hidden=false;
   // Viewing one comment marks its own post, never all of this person's posts.
   try{
    const detail=await action('customer_detail',{author_key:person.author_key});if(!customerCurrent(request))return;
    const comment=detail?.comments?.find(item=>item.lead_id===lead.id);
    if(detail?.author_key!==person.author_key||!/^[a-f0-9]{64}$/.test(comment?.post_key||''))return;
    const seen=await cloud.call('customer_seen',{author_key:person.author_key,post_key:comment.post_key});if(!customerCurrent(request))return;
    if(seen?.result?.author_key!==person.author_key||seen.result.post_key!==comment.post_key||!Number.isFinite(seen.result.viewed_at))throw Error('浏览标记未确认');
    customerStatus.textContent=customerContactLine({...person,viewed_at:seen.result.viewed_at});
   }catch{if(customerCurrent(request))customerStatus.textContent=customerContactLine(person)+' · 查看状态未保存';}
  }catch{if(customerCurrent(request))customerStatus.textContent='客户记录读取失败 · 联系情况待核实';}
 }
 customerLink.addEventListener('click',()=>{if(!localWorkspace||!customerKey)return;const key=customerKey;void Promise.resolve(onCustomerRecord(key)).catch(()=>{if(customerKey===key)customerStatus.textContent='客户记录打开失败 · 请重试';});});
 $('continuous-heading').after(feedback);
 const progressSteps=$('continuous-steps'),sourceStepLabel=el('span','搜索帖子'),sourceDoneIcon=el('img',undefined,'continuous-step-done-icon');
 sourceDoneIcon.src='?asset=fy-icon-50-check.png';sourceDoneIcon.alt='';sourceDoneIcon.setAttribute('aria-hidden','true');progressSteps.firstElementChild.replaceChildren(sourceDoneIcon,sourceStepLabel);
 let headerDateTimer=0;
 function showHeaderDate(){const node=$('workspace-date');if(node)node.textContent=workspaceHeaderDate();}
 function startHeaderDate(){if(!$('workspace-date'))return;showHeaderDate();if(!headerDateTimer){headerDateTimer=setInterval(showHeaderDate,60000);headerDateTimer.unref?.();}}
 startHeaderDate();
 const safetyLink=el('button','去小红书账号','text-button');safetyLink.type='button';safetyLink.addEventListener('click',()=>onPage('devices'));safetyLink.hidden=true;$('continuous-toggle').after(safetyLink);
 let feedbackTimer=0,snapshotUnconfirmed=false;
 function report(message,error=false){if(settingsDialog.open){$('collection-dialog-feedback').textContent=message;$('collection-dialog-feedback').classList.toggle('is-error',error);}clearTimeout(feedbackTimer);feedback.textContent=message;feedback.hidden=!message;feedback.classList.toggle('is-error',error);if(message&&!error&&!/正在|核对/.test(message))feedbackTimer=setTimeout(()=>{feedback.hidden=true;feedback.textContent='';},5000);}
 function markSnapshotUnconfirmed(loading=false){snapshotUnconfirmed=true;report(loading?'正在读取已有任务…':'状态读取未完成；下方是上次进度，请刷新状态核对',!loading);renderContinuous();}
 function renderCollectionSummary(){const city=field('city').value.trim()||'城市未设置',area=field('area').value.trim(),range=field('comment_date_range').value,rangeText={3:'近三个月',6:'近六个月',12:'近一年',custom:'自定义日期'}[range]||'时间未设置';$('collection-summary-text').textContent=`${city}${area?` · ${area}`:''} · ${rangeText} · 已选 ${chosen().length} 个关键词`;}
 function openCollectionDialog(trigger,focusTarget=null,message=''){if(!settingsDialog.open){settingsReturnFocus=trigger||document.activeElement;placeCollectionDemand({open:true,demand,home:demandHome,dialogHost:dialogDemandHost});settingsDialog.showModal();}keywordsExpanded=true;$('keyword-options').open=true;syncKeywordAdjustment();renderKeywords();if(focusTarget?.closest?.('.manual-keywords'))focusTarget.closest('.manual-keywords').open=true;$('collection-dialog-feedback').textContent=message;requestAnimationFrame(()=>{if(settingsDialog.open){const target=focusTarget?.isConnected===false?$('keyword-groups').querySelector('input')||$('keyword-seed'):focusTarget||$('keyword-seed');target.focus();}});}
 function closeCollectionDialog(){if(settingsDialog.open)settingsDialog.close();}
 async function action(name,data={}){const answer=await execute(name,data);if(answer?.status!=='succeeded')throw commandFailure(name,answer);return answer.result||{};}
 let handoffRecords=[];
 const canReply=()=>getUser()?.can_reply!==false;
 const locks=new WeakSet();
 function guard(fn){return async event=>{event?.preventDefault();const button=event?.currentTarget;if(button?.disabled||button&&locks.has(button))return;if(button)locks.add(button);if(button instanceof HTMLButtonElement||button instanceof HTMLSelectElement){button.disabled=true;button.setAttribute('aria-busy','true');}try{await fn(event);}catch(error){report(error.message||'操作未完成',true);if(['reply-save','reply-confirm','reply-browser','queue-send','queue-prepare','queue-refresh','queue-cancel'].includes(button?.id))$('reply-feedback').textContent=error.message||'操作结果待核对';if(button?.id==='ai-config-form'){$('ai-configured').textContent=error.message||'企业配置保存失败';$('ai-configured').classList.add('is-error');}onError(error);}finally{if(button)locks.delete(button);if(button instanceof HTMLButtonElement||button instanceof HTMLSelectElement){button.disabled=false;button.removeAttribute('aria-busy');}if(['reply-save','reply-confirm','reply-browser','queue-send','queue-prepare','queue-refresh','queue-cancel'].includes(button?.id)){updateReply(false);renderQueue();}if(button?.id==='save-keywords')updateKeywordCount();if(button?.id==='continuous-toggle')renderContinuous();if(button?.id?.startsWith('update-')||button?.id==='open-update')renderUpdate();}};}
 function chosen(){return [...new Set([...selected,...String(field('keywords')?.value||'').split(/\n/).map(x=>x.trim()).filter(Boolean)])];}
 function context(){return {city:field('city').value.trim(),area:field('area').value.trim(),seeds:$('keyword-seed').value.split(/[\n，,]/).map(x=>x.trim()).filter(Boolean),count:Number($('keyword-count').value)};}
 function mergedKeywords(items){const map=new Map();for(const item of items||[]){const word=String(typeof item==='string'?item:item?.keyword||'').trim();if(!word||map.has(word))continue;map.set(word,typeof item==='string'?{keyword:word,group:'手动关键词',recommended:false,source:'manual'}:{...item,keyword:word});}return [...map.values()];}
 function syncPoolDraft(){if(!keywordPool||poolRestoring||poolReadPending)return;const request=context();if(!request.city)return;const known=mergedKeywords([...keywords,...String(field('keywords')?.value||'').split(/\n/).map(keyword=>({keyword,group:'手动关键词',recommended:false,source:'manual'}))]);if(known.length>500){$('keyword-save-state').textContent='词库已达 500 个，请使用现有关键词';$('keyword-save-state').dataset.state='error';return;}keywords=known;try{keywordPool.edit(request,keywords,chosen());}catch{void loadKeywordPool(request).catch(onError);}}
 async function loadKeywordPool(request={city:'',area:''}){if(!keywordPool)return;const token=++poolInputGeneration;poolReadPending=true;try{const state=await keywordPool.open(request);if(token!==poolInputGeneration||!state)return;if(!request.city&&!state.exists)return;if(request.city&&(field('city').value.trim()!==request.city||field('area').value.trim()!==String(request.area||'')))return;poolRestoring=true;const savedRequest=state.draft.request;field('city').value=savedRequest.city;field('area').value=savedRequest.area;$('keyword-seed').value=(savedRequest.seeds||[]).join('，');$('keyword-count').value=String(savedRequest.count||50);keywords=mergedKeywords(state.draft.keywords);selected=new Set(state.draft.selected);field('keywords').value='';keywordApproval=null;if(state.exists&&selected.size)approveKeywords();renderKeywords();renderContinuous();}catch(error){if(token===poolInputGeneration){const prior=keywordPool.current?.draft.request;if(prior?.city){field('city').value=prior.city;field('area').value=prior.area;}$('keyword-save-state').textContent='未保存，请重试';$('keyword-save-state').dataset.state='error';throw error;}}finally{if(token===poolInputGeneration){poolRestoring=false;poolReadPending=false;}}}
 async function restorePool(){if(!keywordPool)return;await loadKeywordPool();if(keywordPool.current&&!keywordPool.current.exists&&context().city)await loadKeywordPool(context());}
 function schedulePoolRegion(){if(!keywordPool||poolRestoring)return;clearTimeout(poolRegionTimer);poolRegionTimer=setTimeout(()=>{void loadKeywordPool(context()).catch(onError);},350);}
 async function ensurePoolSaved(){if(!keywordPool)return;const request=context(),current=keywordPool.current;if(!request.city)throw Error('请填写城市');if(!current||current.draft.request.city!==request.city||current.draft.request.area!==request.area||poolReadPending)await loadKeywordPool(request);if(keywordPool.status==='error')await keywordPool.retry();syncPoolDraft();try{await keywordPool.flush();}catch{throw Error('未保存，请重试');}if(keywordPool.status!=='saved')throw Error('未保存，请重试');}
 function keywordSignature(){const data=context();return JSON.stringify([data.city,data.area,[...new Set(data.seeds)],data.count]);}
 function approvedKeywords(){return !!keywordApproval&&keywordApproval.signature===keywordSignature()&&keywordApproval.words===JSON.stringify(chosen());}
 function approveKeywords(){if(chosen().length)keywordApproval={signature:keywordSignature(),words:JSON.stringify(chosen())};}
 function renderKeywords(){
  field('keywords').required=false;
  const host=$('keyword-groups');host.replaceChildren();
  const visible=keywordsExpanded?keywords:keywords.slice(0,6);
  const section=el('section',undefined,'keyword-group'),grid=el('div',undefined,'keyword-grid');section.append(grid);if(visible.length)host.append(section);
  for(const item of visible){const group=String(item.group||'').trim();const label=el('label',undefined,'keyword-option'),box=el('input'),copy=el('span',undefined,'keyword-copy'),title=el('span',item.keyword,'keyword-phrase');box.type='checkbox';box.checked=selected.has(item.keyword);box.setAttribute('aria-label',group?`${item.keyword}，分类：${group}`:item.keyword);label.title=[group,item.reason].filter(Boolean).join(' · ');label.classList.toggle('checked',box.checked);
   box.addEventListener('change',()=>{box.checked?selected.add(item.keyword):selected.delete(item.keyword);label.classList.toggle('checked',box.checked);updateKeywordCount();syncPoolDraft();});
   if(item.recommended===true)title.append(el('small','推荐','keyword-recommended'));else if(item.source==='task_selected')title.append(el('small','任务已选','keyword-task-selected'));copy.append(title);if(item.reason)copy.append(el('small',item.reason,'keyword-reason'));label.append(box,copy);grid.append(label);
  }
  if(!keywords.length)host.append(el('p','在上方填写租房需求，点“AI 联想关键词”。','keyword-empty'));
  $('keywords-expand').hidden=settingsDialog.open||keywords.length<=6;$('keywords-expand').textContent=keywordsExpanded?'收起关键词':`查看全部 ${keywords.length} 个`;
  const fromTask=keywords.length>0&&keywords.every(k=>k.source==='task_selected');
  $('keyword-heading-title').textContent=fromTask?'本任务关键词':'候选关键词';$('keywords-recommended').disabled=!keywords.some(k=>k.recommended===true);
  updateKeywordCount();
 }
 function updateKeywordCount(){const selectedWords=chosen(),preview=$('keyword-selected-preview');$('keyword-options-summary').textContent=`调整关键词 · 已选 ${selectedWords.length} 个`;$('keyword-selection-count').textContent=`· 已选 ${selectedWords.length} 个`;preview.replaceChildren(...(selectedWords.length?[...selectedWords.slice(0,3).map(word=>el('span',word,'keyword-chip')),...(selectedWords.length>3?[el('span',`另有 ${selectedWords.length-3} 个`,'keyword-chip-more')]:[])]:[el('span','尚未选择，点“调整”添加','keyword-preview-empty')]));renderCollectionSummary();}
 function syncKeywordAdjustment(){const open=$('keyword-options').open,button=$('keyword-adjust');button.textContent=open?'收起':'调整';button.setAttribute('aria-expanded',String(open));}
 async function recommend(){if(keywordBusy)return;const data=context(),signature=keywordSignature();if(!data.city){openCollectionDialog($('suggest-keywords'),field('city'),'填写城市后即可联想关键词');return;}if(!data.seeds.length){openCollectionDialog($('suggest-keywords'),$('keyword-seed'),'请填写租房需求，例如：古北租房');return;}if(keywordPool)await ensurePoolSaved();if(keywords.length+data.count>500){openCollectionDialog($('suggest-keywords'),$('keyword-groups').querySelector('input'),'词池空间不足，请减少每次补充数量；已达 500 个时使用现有关键词');return;}data.exclude_keywords=keywords.map(item=>item.keyword);
  const button=$('suggest-keywords'),poolToken=keywordPool?.generation;keywordBusy=true;button.disabled=true;button.setAttribute('aria-busy','true');button.textContent='正在联想…';renderContinuous();report('AI 正在联想关键词…');if(settingsDialog.open)$('collection-dialog-feedback').textContent='AI 正在联想关键词…';
  try{const result=await action('keyword_recommend',data),sameRegion=()=>context().city===data.city&&context().area===data.area&&(!keywordPool||keywordPool.generation===poolToken);if(keywordPool&&sameRegion())await keywordPool.refreshRevision();if(!sameRegion()){openCollectionDialog(button,$('keyword-seed'),'地区已变化，请核对当前词库');return;}const before=keywords.length;keywords=mergedKeywords([...keywords,...(result.library?.keywords||[]),...(result.keywords||[])]);keywordApproval=null;syncPoolDraft();if(signature!==keywordSignature()){renderKeywords();openCollectionDialog(button,$('keyword-seed'),'需求已变化，请重新联想');return;}keywordsExpanded=false;libraryId=result.library_id||'';keywordAttemptSignature=signature;renderKeywords();openCollectionDialog(button,$('keyword-groups').querySelector('input')||field('keywords'),`新增 ${keywords.length-before} 个候选词，请勾选后确认`);if(['queued','running','waiting'].includes(task?.continuous?.status)){feedback.textContent='';feedback.hidden=true;}else report(result.cache_hit?'已复用关键词组合':'关键词已生成');void profile();}
  catch(error){keywordAttemptSignature=signature;openCollectionDialog(button,$('keyword-seed'),error.message||'关键词暂未生成，请稍后重试');throw error;}
  finally{keywordBusy=false;button.disabled=false;button.removeAttribute('aria-busy');button.textContent='AI 联想关键词';renderContinuous();}
 }
 async function restoreLibrary(id){if(disposed||!getUser())return;const generation=sessionGeneration,scope=navigationPendingScope(),answer=await action('keyword_library',id?{library_id:id}:{});if(disposed||generation!==sessionGeneration||scope!==navigationPendingScope())return;const libraries=answer.items||[];const choice=id?libraries.find(x=>x.id===id):libraries[0];
  const host=$('keyword-library-list');host.replaceChildren();for(const entry of libraries){const b=el('button',`${entry.request?.city||'城市未提供'} · ${entry.keywords?.length||0} 个词`,'secondary');b.type='button';b.addEventListener('click',guard(()=>restoreLibrary(entry.id)));host.append(b);}
  if(!libraries.length)host.append(el('p','还没有收藏的关键词组合','help'));
  if(choice){libraryId=choice.id;keywords=choice.keywords||[];selected=new Set(Array.isArray(choice.selected)?choice.selected:keywords.filter(k=>k.recommended).map(k=>k.keyword));field('city').value=choice.request?.city||field('city').value;field('area').value=choice.request?.area||'';$('keyword-seed').value=(choice.request?.seeds||[]).join('，');renderKeywords();report('已读取本机词库');}
 }
 async function saveLibrary(){await action('keyword_library',{library_id:libraryId,selected:chosen()});report('关键词组合已收藏');}
 function cancelPoll(){clearInterval(worklistTimer);worklistTimer=0;clearTimeout(pollTimer);clearInterval(clockTimer);clearTimeout(queueTimer);pollTimer=clockTimer=queueTimer=0;pauseFeedback=null;}
 function schedule(failed=false){clearTimeout(pollTimer);const active=!!collectionUncertain||['queued','running','waiting'].includes(task?.continuous?.status);if(!disposed&&taskId&&getUser())pollTimer=setTimeout(()=>refreshContinuous().catch(error=>{onError(error);schedule(true);}),failed?60000:active?8000:30000);}
 function reconcilePauseFeedback(nextTask){
  if(!pauseFeedback||pauseFeedback.phase==='request'||pauseFeedback.taskId!==nextTask?.id)return;
  const state=nextTask.continuous;
  if(['paused','blocked','stopped','completed','exhausted'].includes(state?.status))pauseFeedback=state?.inflight?{...pauseFeedback,phase:'inflight'}:null;
 }
 function renderContinuous(){
  const account=getState().accounts?.find(item=>item.id===task?.account_id),view=continuousPresentation(task,Date.now(),account),host=$('continuous-panel');host.dataset.state=view.status;host.dataset.historyResolved=String(view.historyResolved);host.classList.toggle('is-active',view.active);host.classList.toggle('is-processing',view.processing);$('continuous-heading').textContent='采集状态';if(view.active&&!feedback.classList.contains('is-error')&&/^(关键词已推荐|已复用关键词组合|关键词组合已收藏|已读取本机词库)/.test(feedback.textContent)){feedback.textContent='';feedback.hidden=true;}
  const pausing=pauseFeedback?.taskId===taskId&&pauseFeedback.deviceId===getState().selected?pauseFeedback:null;host.dataset.pausePhase=pausing?.phase||'';
  const employee=getUser()?.role!=='admin';
  const snapshotReadFailed=snapshotUnconfirmed&&feedback.classList.contains('is-error');
  $('continuous-phase').textContent=pausing?.phase==='request'?'正在暂停采集':pausing?.phase==='inflight'?'暂停请求已确认':pausing?.phase==='uncertain'?'暂停结果待核对':snapshotReadFailed?`${view.heading} · 状态待核对`:snapshotUnconfirmed?'正在核对采集状态':view.heading;
  $('continuous-message').textContent=pausing?.phase==='request'?'正在提交暂停请求，请稍候…':pausing?.phase==='inflight'?'已收到暂停确认，当前读取仍在途；读取结束后才完全暂停。':pausing?.phase==='uncertain'?'暂停结果尚未确认，请刷新状态核对，暂勿重复操作。':snapshotReadFailed?'状态读取未完成；请刷新状态核对。上次进度仅供参考。':snapshotUnconfirmed?'正在读取已有任务，确认后才能继续采集。':collectionUncertain?'上次采集请求结果待核对，请刷新状态；暂勿重复提交。':view.active?'':account?.requires_review===true&&!localWorkspace?'采集已暂停，请在对应电脑打开方隅工作台完成账号复核':employee?employeeAiFinancialText(view.message):view.message;
  const errorDetails=$('continuous-error-details'),errorText=$('continuous-error-text'),detail=employee?employeeAiFinancialText(view.detail):view.detail;if(errorText.textContent!==detail)errorDetails.open=false;errorText.textContent=detail;errorDetails.hidden=!detail;
  const savedTotal=Number.isSafeInteger(task?.analysis?.saved_total)&&task.analysis.saved_total>=0?task.analysis.saved_total:view.imported;
  const analyzedTotal=Number.isSafeInteger(task?.analysis?.analyzed_total)&&task.analysis.analyzed_total>=0?task.analysis.analyzed_total:null;
  const values=[['continuous-read',view.read,'已读取'],['continuous-imported',savedTotal,'已保存'],['continuous-duplicates',view.duplicates,'重复'],['continuous-analyzed',analyzedTotal??task?.analysis?.last_analyzed,analyzedTotal===null?'本批已分析':'已判定']];
  for(const [id,n,label] of values)$(id).textContent=typeof n==='number'?`${label==='累计新增'?'新增':label} ${n} 条`:`${label==='累计新增'?'新增':label} —`;
  const stats=$('continuous-imported').parentElement;
  for(const [id,label,count] of [['continuous-monitor-analyzed',analyzedTotal===null?'本批已分析':'已判定',analyzedTotal??task?.analysis?.last_analyzed],['continuous-monitor-pending','待分析',view.analysisPending]]){
   let item=$(id);if(!item){item=el('span',undefined,'continuous-monitor-count');item.id=id;stats.append(item);}item.textContent=typeof count==='number'?`${label} ${count}`:`${label} —`;
  }
  const elapsed=view.elapsed;$('continuous-elapsed').textContent=elapsed===null?'':`已运行 ${String(Math.floor(elapsed/60)).padStart(2,'0')}:${String(elapsed%60).padStart(2,'0')}`;
  $('continuous-next').textContent=view.nextSeconds===null?'':`等待下一次读取 ${view.nextSeconds} 秒`;
  renderCollectionSummary();
  let sameConditions=false;try{sameConditions=!!matchingContinuousTask(task?[task]:[],continuousPayload(Object.fromEntries(new FormData(form)),chosen()));}catch{}
  const currentWords=chosen(),oldWords=Array.isArray(task?.keywords)?task.keywords.filter(Boolean):[],keywordsDiffer=oldWords.length!==currentWords.length||oldWords.some(word=>!currentWords.includes(word));
  if(!pausing&&!snapshotUnconfirmed&&taskId&&view.status==='paused'&&!sameConditions&&!view.requiresLogin&&account?.requires_review!==true)$('continuous-message').textContent=`上次 ${oldWords.length} 词 · 当前 ${currentWords.length} 词。继续上次采集沿用原条件。`;
  $('continuous-toggle').hidden=!taskId||!view.active&&(sameConditions||view.requiresLogin||account?.requires_review===true);$('continuous-toggle').disabled=!!pausing||!!collectionBusy||!!collectionUncertain||snapshotUnconfirmed||view.status==='paused'&&task?.continuous?.inflight;$('continuous-toggle').textContent=collectionBusy==='resume'?'正在恢复…':pausing?.phase==='request'?'正在暂停…':pausing?.phase==='inflight'?'等待当前读取…':pausing?.phase==='uncertain'?'暂停待核对':snapshotUnconfirmed?'核对状态中':collectionUncertain?'结果待核对':view.active?'暂停采集':view.requiresLogin?'重新登录':account?.requires_review===true?'核对账号':view.status==='paused'?'继续上次采集':'恢复采集';$('continuous-toggle').dataset.action=view.active?'continuous_pause':'continuous_resume';safetyLink.hidden=!!taskId||!view.requiresLogin&&account?.requires_review!==true;
  host.dataset.accountAction=String(!!taskId&&(view.requiresLogin||account?.requires_review===true));
  if(snapshotUnconfirmed){$('create-task').dataset.snapshotBusy='true';$('create-task').setAttribute('aria-busy','true');}
  else if($('create-task').dataset.snapshotBusy==='true'){delete $('create-task').dataset.snapshotBusy;if(!collectionBusy)$('create-task').removeAttribute('aria-busy');}
  if(collectionUncertain){$('create-task').dataset.collectionPending='true';$('create-task').dataset.uncertain='true';}
  else if($('create-task').dataset.collectionPending==='true'){delete $('create-task').dataset.collectionPending;if(!pendingSave)delete $('create-task').dataset.uncertain;}
  $('create-task').hidden=view.active;$('create-task').disabled=!!pausing||!!collectionBusy||!!collectionUncertain||snapshotUnconfirmed||!$('task-prerequisite').hidden;$('create-task').textContent=collectionBusy==='resume'?'正在恢复…':collectionBusy?'正在开始…':snapshotReadFailed?'状态待核对':snapshotUnconfirmed?'核对状态中':collectionUncertain?'结果待核对':sameConditions&&!view.requiresLogin&&account?.requires_review!==true&&continuousStartAction(task)==='continuous_resume'?'继续上次采集':taskId&&!sameConditions?keywordsDiffer?'按新关键词采集':'按当前条件采集':'开始采集';$('continuous-spinner').hidden=!view.processing&&pausing?.phase!=='request'&&!collectionBusy;
  progressSteps.dataset.phase=view.processing?view.phase:view.status;
  const sourceReached=['reading_comments','filtering','saving','waiting'].includes(view.phase),scope=task?.scope;
  sourceStepLabel.textContent='搜索';
  progressSteps.dataset.sourceDone=String(sourceReached&&['search_comments','comments'].includes(scope));
  progressSteps.dataset.searchDone=String(sourceReached&&scope==='search_comments');
  const status=analysisStatusView({analysis:task?.analysis||{},profileStatus:aiProfileStatus,pending:view.analysisPending,imported:task?.continuous?.imported,taskId,city:task?.city});
  $('analysis-details-summary').textContent=status.summary;$('analysis-state').textContent=status.state;
  $('ai-model-state').textContent=aiModelStatus({profile:aiProfile,analysis:analysisBusy?{status:'running'}:task?.analysis||{},keywordBusy});$('ai-model-state').dataset.busy=String(keywordBusy||analysisBusy||task?.analysis?.status==='running');
  if(view.active&&!pausing&&['AI_PROVIDER_BALANCE','AI_DAILY_BUDGET','AI_BILLING_UNKNOWN'].includes(task?.analysis?.code))$('continuous-message').textContent=employee?'评论已保存，AI 暂不可用，仍待分析；请联系管理员':task.analysis.message||'企业 AI 暂不可用，请核对费用状态';
  const conditionNotice=taskId&&view.status==='paused'&&!sameConditions&&!view.requiresLogin&&account?.requires_review!==true;
  const needAction=!!pausing||snapshotUnconfirmed||!!collectionUncertain||conditionNotice||view.requiresLogin||account?.requires_review===true||['blocked','failed','interrupted'].includes(view.status)&&!view.historyResolved||view.active&&!!task?.analysis?.code;
  $('continuous-message').hidden=!needAction||!$('continuous-message').textContent;
  $('continuous-monitor-pending').hidden=!view.analysisPending;
  $('continuous-imported').textContent=typeof savedTotal==='number'?`${savedTotal} 条评论`:'— 条评论';
  progressSteps.lastElementChild.hidden=!status.enabled;
  $('analysis-retry').hidden=!status.retryVisible;$('analysis-retry').textContent=status.retryLabel;
  const source=task?.progress?.current_source||task?.progress||{},title=source.content_title||source.note_title||'';$('continuous-source').hidden=!title;$('continuous-source').replaceChildren(...(title?[sourceLink(source.note_url||'',`来自：${title}`)]:[]));
 }
 async function refreshContinuous(){
  if(!taskId||disposed)return;const current=taskId,deviceId=getState().selected;
  try{
  if(localWorkspace){
   let commandOutcome=null;
   if(collectionUncertain?.deviceId===deviceId&&collectionUncertain.commandId)try{const job=await cloud.inspect(collectionUncertain.commandId);if(['succeeded','failed','cancelled','expired'].includes(job?.status)){collectionUncertain=null;commandOutcome=job;}}catch{/* Keep the original request locked until a confirmed status is read. */}
   const snapshot=await action('workspace_state',{});
   if(current!==taskId||deviceId!==getState().selected||disposed)return;
   if(!Array.isArray(snapshot.tasks))throw Error('采集状态未完整读取，请刷新核对');
   if(Array.isArray(snapshot.accounts))onWorkspaceAccounts(snapshot.accounts);
   syncSnapshot({...snapshot,authoritative:true});
   if(commandOutcome)report(commandOutcome.status==='succeeded'?'采集请求已确认，请留意当前状态':commandOutcome.error||'采集请求未完成，请核对状态',commandOutcome.status!=='succeeded');
  }else{
   const result=await action('continuous_status',{task_id:taskId});
   if(current!==taskId||deviceId!==getState().selected||disposed)return;
   task={...task,...result.task,continuous:result.continuous||task?.continuous};reconcilePauseFeedback(task);renderContinuous();schedule();
  }
  }catch(error){if(current===taskId&&deviceId===getState().selected&&!disposed)markSnapshotUnconfirmed();throw error;}
  if($('workspace').dataset.page==='leads')void loadWorklist(offset).catch(onError);else if($('workspace').dataset.page==='tasks')void latest();
 }
 function syncSnapshot(snapshot){
  if(snapshot.authoritative&&pauseFeedback){const confirmed=(snapshot.tasks||[]).find(item=>item.id===pauseFeedback.taskId);if(confirmed)reconcilePauseFeedback(confirmed);else if(snapshot.truncated!==true)pauseFeedback=null;}
  // A confirmed empty store must clear deleted progress even while conditions are edited.
  if(snapshot.authoritative&&Array.isArray(snapshot.tasks)&&!snapshot.tasks.length&&snapshot.truncated!==true&&!pendingSave){
   clearTimeout(pollTimer);clearInterval(clockTimer);pollTimer=clockTimer=0;
   taskId='';hydratedTaskId='';savedForStart=null;savedForStartDevice='';task=null;
   if(snapshotUnconfirmed){snapshotUnconfirmed=false;report('');}
   renderContinuous();return;
  }
  if(settingsDialog.open){
   const current=(snapshot.tasks||[]).find(item=>item.id===taskId);
   if(current){task=current;renderContinuous();}
   if(snapshot.authoritative&&snapshotUnconfirmed){snapshotUnconfirmed=false;report('');}
   schedule();
   return;
  }
  const tasks=snapshot.tasks||[],live=t=>t.continuous_enabled&&['queued','running','waiting'].includes(t.continuous?.status);
  const current=tasks.find(t=>t.id===taskId),active=tasks.find(live);
  const first=tasks.find(t=>t.continuous_enabled&&['queued','running','waiting','paused','blocked','failed','interrupted'].includes(t.continuous?.status));
  let editing=false;
  if(task&&hydratedTaskId===taskId)try{editing=!matchingContinuousTask([task],continuousPayload(Object.fromEntries(new FormData(form)),chosen()));}catch{editing=true;}
  if((editing||pendingSave)&&taskId&&!current)return;
  const candidate=current&&(editing||pendingSave||live(current)||!active)?current:active||current||(first&&matchingContinuousTask(tasks,first));
  if(snapshot.authoritative&&collectionUncertain&&candidate?.id===collectionUncertain.taskId&&live(candidate))collectionUncertain=null;
  if(snapshot.authoritative&&snapshotUnconfirmed){snapshotUnconfirmed=false;report('');}
  if(candidate){task=candidate;taskId=candidate.id;if(hydratedTaskId!==taskId){if(!keywordPool?.current){field('city').value=task.city||'';field('area').value=task.area||'';$('keyword-seed').value=(task.keywords||[]).slice(0,3).join('，');keywords=(task.keywords||[]).map(keyword=>({keyword,group:'已选关键词',recommended:false,source:'task_selected'}));selected=new Set(task.keywords||[]);field('keywords').value='';approveKeywords();}field('comment_date_range').value={'3months':'3','6months':'6','12months':'12'}[task.comment_date_range]||task.comment_date_range||'3';field('comment_date_from').value=task.comment_date_from||'';field('comment_date_to').value=task.comment_date_to||'';$('custom-comment-dates').hidden=task.comment_date_range!=='custom';field('account_id').value=task.account_id||field('account_id').value;hydratedTaskId=taskId;renderKeywords();if(!settingsDialog.open)$('keyword-options').open=false;syncKeywordAdjustment();}renderContinuous();if(!clockTimer)clockTimer=setInterval(renderContinuous,1000);schedule();}
  else{taskId='';hydratedTaskId='';task=null;renderContinuous();}
 }
 async function start(event){
  if(settingsDialog.open)return;
  if(pendingSave)throw Error('保存结果待核对，请先刷新状态');
  if(collectionUncertain)throw Error('上次采集请求结果待核对，请先刷新状态');
  if(collectionBusy)return;
  let visibleResume=false;try{visibleResume=continuousStartAction(task)==='continuous_resume'&&!!matchingContinuousTask(task?[task]:[],continuousPayload(Object.fromEntries(new FormData(form)),chosen()));}catch{}
  collectionBusy=visibleResume?'resume':'start';$('create-task').setAttribute('aria-busy','true');report(visibleResume?'正在恢复上次采集，先核对条件…':'正在核对采集条件…');renderContinuous();
  try{
   if(!approvedKeywords()){
    if(!chosen().length&&!keywordPool?.current?.exists&&context().seeds.length&&keywordAttemptSignature!==keywordSignature()){await recommend();return;}
    openCollectionDialog(event.submitter||$('create-task'),$('keyword-groups').querySelector('input')||field('keywords'),
     chosen().length?'需求已变化，请核对后点“使用这些关键词”':'请先联想或手动加词，再点“使用这些关键词”');
    return;
   }
   await ensurePoolSaved();
   if(!approvedKeywords())throw Error('关键词已变化，请重新确认');
   const values=Object.fromEntries(new FormData(event.currentTarget));let data;
   try{data=continuousPayload(values,chosen());}catch(error){const target=!field('city').value.trim()?field('city'):field('comment_date_range').value==='custom'&&(!field('comment_date_from').value||!field('comment_date_to').value||field('comment_date_from').value>field('comment_date_to').value)?!field('comment_date_from').value?field('comment_date_from'):field('comment_date_to'):field('keywords');openCollectionDialog(event.submitter||$('create-task'),target,error.message);return;}
   const deviceId=getState().selected;
   const unchanged=()=>approvedKeywords()&&!!matchingContinuousTask([{...data,id:'requested'}],continuousPayload(Object.fromEntries(new FormData(form)),chosen()));
  const account=getState().accounts.find(a=>a.id===data.account_id&&a.platform==='xiaohongshu'&&a.status==='ready');if(!account)throw Error('请先登录小红书账号');
   await confirmFreshCollectionAccess('continuous_start',()=>beforeStart(data.account_id,'continuous_start'),collectionHeld);
   if(getState().selected!==deviceId||!unchanged())throw Error('当前电脑或采集条件已变化，请重新确认');
   const snapshot=await action('workspace_state',{});
   if(getState().selected!==deviceId)throw Error('当前电脑已变化，请重新读取任务');
    requireAccountReviewClear(snapshot.accounts,data.account_id,localWorkspace);
    if(!unchanged())throw Error('采集条件已变化，请重新确认');
   const matches=(snapshot.tasks||[]).filter(item=>matchingContinuousTask([item],data));
   const active=matches.find(item=>continuousStartAction(item)==='display');
   if(savedForStart&&!matchingContinuousTask([savedForStart],data))savedForStart=null;
   const savedOnDevice=savedForStartDevice===deviceId?matchingContinuousTask(savedForStart?[savedForStart]:[],data):null;
   const existing=active||matchingContinuousTask(matches,data)||savedOnDevice;
   if(!existing&&snapshot.truncated)throw Error('历史任务列表未完整读取，暂勿新建；请刷新或联系管理员核对原任务');
   if(existing){
    taskId=existing.id;hydratedTaskId=taskId;task=existing;
    const next=continuousStartAction(existing);
    if(next==='display'||existing.continuous?.inflight){savedForStart=null;renderContinuous();schedule();report('采集任务已在进行，请留意下次读取状态');return;}
    collectionBusy=next==='continuous_resume'?'resume':'start';report(collectionBusy==='resume'?'正在恢复上次采集…':'正在开始采集…');renderContinuous();
    const result=await action(next,{task_id:taskId});savedForStart=null;task={...task,...result.task,continuous:result.continuous};
    if(!settingsDialog.open)$('keyword-options').open=false;renderContinuous();if(!clockTimer)clockTimer=setInterval(renderContinuous,1000);schedule();report(next==='continuous_resume'?(result.continuous?.status==='waiting'?'已恢复上次采集，等待下一次读取':result.continuous?.status==='running'?'已恢复上次采集，正在读取':'恢复请求已确认，请留意采集状态'):(result.continuous?.status==='waiting'?'采集已开始，等待下一次读取':result.continuous?.status==='running'?'采集已开始，正在读取':'开始请求已确认，请留意采集状态'));void profile();return;
   }
   report('正在保存采集条件…');let saved;
   try{saved=await action('task_save',data);}catch(error){if(error.requestId){pendingSave={commandId:error.commandId,requestId:error.requestId,data,deviceId};$('create-task').dataset.uncertain='true';}report(error.requestId?'保存结果待核对，请刷新状态，暂勿重复开始':error.message,true);throw error;}
    taskId=saved.id;hydratedTaskId=taskId;task={...data,...saved};if(!taskId)throw Error('保存结果待核对，请刷新状态');
    savedForStart=task;savedForStartDevice=deviceId;if(!unchanged())throw Error('采集条件已变化；旧条件已保存，请重新点击开始');report('采集条件已保存，正在开始…');const result=await action('continuous_start',{task_id:taskId});savedForStart=null;task={...task,...result.task,continuous:result.continuous};if(!settingsDialog.open)$('keyword-options').open=false;renderContinuous();if(!clockTimer)clockTimer=setInterval(renderContinuous,1000);schedule();report(result.continuous?.status==='waiting'?'采集已开始，等待下一次读取':result.continuous?.status==='running'?'采集已开始，正在读取':'开始请求已确认，请留意采集状态');void profile();
  }catch(error){if(!pendingSave&&error.requestId){collectionUncertain={deviceId:getState().selected,taskId,commandId:error.commandId||'',requestId:error.requestId};error.message='采集请求结果待核对；请刷新状态，暂勿重复提交。';schedule();}if(!pendingSave)report(error.message||'采集操作未完成',true);throw error;}
  finally{collectionBusy='';$('create-task').removeAttribute('aria-busy');renderContinuous();}
 }
 async function toggle(){if(!taskId||pauseFeedback||collectionBusy||collectionUncertain)return;const account=getState().accounts?.find(item=>item.id===task?.account_id),view=continuousPresentation(task,Date.now(),account);if(!view.active&&(view.requiresLogin||account?.requires_review===true)){onPage('devices');return;}const name=$('continuous-toggle').dataset.action,currentTaskId=taskId,accountId=task?.account_id,deviceId=getState().selected;
  const submit=async()=>{await confirmFreshCollectionAccess(name,()=>beforeStart(accountId,name),collectionHeld);if(currentTaskId!==taskId||accountId!==task?.account_id||deviceId!==getState().selected)throw Error('采集任务或账号已变化，请刷新后重试');return action(name,{task_id:currentTaskId});};
  if(name==='continuous_resume'){collectionBusy='resume';$('continuous-toggle').setAttribute('aria-busy','true');report('正在恢复上次采集…');renderContinuous();}
  try{
   const result=name==='continuous_pause'?await runPauseRequest({taskId:currentTaskId,deviceId,submit,onChange:state=>{pauseFeedback=state;renderContinuous();}}):await submit();
   task={...task,...result.task,continuous:result.continuous};if(name==='continuous_resume'&&!settingsDialog.open)$('keyword-options').open=false;renderContinuous();report(pauseFeedback?.phase==='uncertain'?'暂停结果待核对，请刷新状态，暂勿重复操作':name==='continuous_resume'?(result.continuous?.status==='waiting'?'已恢复上次采集，等待下一次读取':result.continuous?.status==='running'?'已恢复上次采集，正在读取':'恢复请求已确认，请留意采集状态'):'');schedule();
  }catch(error){if(name==='continuous_resume'&&error.requestId){collectionUncertain={deviceId,taskId:currentTaskId,commandId:error.commandId||'',requestId:error.requestId};error.message='采集请求结果待核对；请刷新状态，暂勿重复提交。';report(error.message,true);schedule();}throw error;}
  finally{if(name==='continuous_resume'){collectionBusy='';$('continuous-toggle').removeAttribute('aria-busy');renderContinuous();}}
 }
 async function profile(){const user=getUser(),generation=++profileGeneration;if(!user)return;const budgetState=$('ai-budget-state');budgetState.hidden=user.role!=='admin';budgetState.textContent='';try{const result=await cloud.call('ai_profile'),p=result.config||result,b=result.budget;if(generation!==profileGeneration||user!==getUser())return;aiProfile={provider:p.provider,model:p.model,enabled:!!p.enabled,configured:!!p.configured,reasoning_effort:p.reasoning_effort,revision:p.revision};aiProfileStatus=!p.configured?'not_configured':p.enabled?'enabled':'disabled';if(user.role==='admin'){budgetState.hidden=false;budgetState.textContent=b?`AI 今日已用 ¥${Number(b.spent_cny||0).toFixed(3)} / ¥${b.limit_cny} · 剩余 ¥${Number(b.remaining_cny||0).toFixed(3)}`:p.configured?'企业 AI 已配置':'企业 AI 待管理员配置';if(!p.enabled)budgetState.textContent+=' · 未启用';}}catch{if(generation!==profileGeneration||user!==getUser())return;aiProfile={};aiProfileStatus='unavailable';if(user.role==='admin'){budgetState.hidden=false;budgetState.textContent='AI 支出状态暂不可用';}}renderContinuous();}
 let latestGeneration=0;
 async function latest(){if(disposed||!getUser()||!getState().selected)return;const generation=++latestGeneration,session=sessionGeneration,principal=customerPrincipalSignature(getUser()),device=getState().selected,deviceGeneration=getState().deviceGeneration,currentSession=()=>!disposed&&session===sessionGeneration&&principal===customerPrincipalSignature(getUser())&&device===getState().selected&&deviceGeneration===getState().deviceGeneration,current=()=>generation===latestGeneration&&currentSession();try{const result=await action('leads_list',{worklist:'all',sort:'newest',offset:0,limit:3});if(!current())return;const host=$('latest-discoveries');host.replaceChildren();for(const lead of result.items||[]){
  const row=el('div',undefined,'discovery-row'),person=el('button',undefined,'discovery-person'),copy=el('button',lead.text||'评论正文未提供','discovery-comment'),intent=effectiveIntent(lead),badge=el('span',intent.label,'intent-tag');person.type=copy.type='button';badge.dataset.level=intent.kind;
  const identity=el('span');identity.append(el('strong',lead.author||'用户未提供'),el('small',displayCommentDate(lead.published_at)));person.append(avatar(lead.author_avatar_url,lead.author,lead.id,'author',localWorkspace),identity);
   const open=()=>{if(!currentSession())return;clearTaskCommentsScope();worklistScope='all';groupKey='';groupOffset=0;$('worklist-intent').value='';$('worklist-intent').disabled=false;$('worklist-query').value='';onPage('leads');const version=pageVersion(),device=getState().selected,principal=customerPrincipalSignature(getUser());void loadWorklist(0).then(()=>{if(!currentSession()||version!==pageVersion()||device!==getState().selected||principal!==customerPrincipalSignature(getUser())||$('workspace').dataset.page!=='leads')return;return selectLead(lead);}).catch(onError);};person.addEventListener('click',open);copy.addEventListener('click',open);
  const source=el('div',undefined,'discovery-source');source.append(sourceLink(lead.note_url||lead.url,lead.content_title||'查看原帖'));
  row.append(person,copy,source,badge,el('span',replyStateLabel(lead.reply_state||'none'),`reply-tag${lead.reply_state==='sent'?' is-replied':''}`));host.append(row);
 }if(!result.items?.length)host.append(el('p','本次暂无新评论','help'));}catch{/* Keep prior results on a transient read failure. */}}
  function worklistReadScope(){return JSON.stringify([customerPrincipalSignature(getUser()),getState().selected||'',getState().deviceGeneration??0,worklistTaskId]);}
  function navigationPendingScope(){return JSON.stringify([customerPrincipalSignature(getUser()),getState().selected||'',getState().deviceGeneration??0]);}
  function renderNavigationPending(){const value=navigationPending.scope===navigationPendingScope()?navigationPending.count:null,known=Number.isSafeInteger(value)&&value>=0,badge=$('pending-nav-count');badge.textContent=known?String(value):'—';badge.title=known?`全部评论中待处理 ${value} 条`:'全部评论的待处理数量尚未核实';badge.setAttribute('aria-label',badge.title);$('pending-bell-dot').hidden=!known||value===0;}
  function invalidatePendingSummary(){navigationPending={scope:'',count:null};worklistSummaryAt=0;worklistSummarySerial++;worklistSummaryRead=null;renderNavigationPending();}
  function renderTaskCommentsScope(){taskCommentScope.hidden=!worklistTaskId||worklistTaskBinding!==worklistReadScope();const saved=(getState().tasks||[]).find(item=>item.id===worklistTaskId);taskCommentLabel.textContent=worklistTaskId?`当前只看原任务：${String(saved?.name||worklistTaskId).slice(0,200)}。统计仅包含该任务的评论。`:'';taskCommentLabel.title=worklistTaskId?`原任务编号：${worklistTaskId}`:'';}
  function setTaskCommentsScope(next='',{force=false}={}){if(next===worklistTaskId&&!force){renderTaskCommentsScope();return worklistTaskScopeToken;}worklistTaskId=next;worklistTaskScopeToken++;readGeneration++;invalidatePendingSummary();worklistSummaryScope='';worklistSummary={pending:null,priority:null,analysis:null,sent:null,all:null,analyzed:null,missing:null};rows=[];total=0;offset=0;groupRows=[];groupsTotal=0;groupKey='';groupOffset=0;worklistTaskBinding=next?worklistReadScope():'';renderTaskCommentsScope();renderWorklist();return worklistTaskScopeToken;}
  function clearTaskCommentsScope(){return setTaskCommentsScope('');}
  function resetTaskCommentFilters(){worklistScope='all';groupBy='note';groupKey='';groupOffset=0;offset=0;$('worklist-group-by').value='note';$('worklist-intent').value='';$('worklist-intent').disabled=false;$('worklist-query').value='';}
  async function openTaskComments(taskId,{accept=()=>true}={}){if(typeof taskId!=='string'||!/^[A-Za-z0-9_-]{1,200}$/.test(taskId))throw Error('原任务编号不完整，请刷新已保存任务。');if(!accept()||!getUser()||!getState().selected)return false;onPage('leads');const version=pageVersion(),device=getState().selected,deviceGeneration=getState().deviceGeneration,principal=customerPrincipalSignature(getUser());if(!accept())return false;resetTaskCommentFilters();const token=setTaskCommentsScope(taskId,{force:true});closeDetail();const current=()=>!disposed&&accept()&&token===worklistTaskScopeToken&&taskId===worklistTaskId&&version===pageVersion()&&device===getState().selected&&deviceGeneration===getState().deviceGeneration&&principal===customerPrincipalSignature(getUser())&&$('workspace').dataset.page==='leads';const abandon=()=>{if(token===worklistTaskScopeToken&&taskId===worklistTaskId)clearTaskCommentsScope();};try{const ready=await loadWorklist(0,{accept:current});if(!current()){abandon();return false;}if(ready!==true)return false;await refreshWorklistSummary(readGeneration,device,{accept:current});if(!current()){abandon();return false;}return true;}catch(error){if(!current()){abandon();return false;}throw error;}}
  async function openAllTaskComments(){clearTaskCommentsScope();resetTaskCommentFilters();closeDetail();onPage('leads');return loadWorklist(0);}
  function onWorklistPage(name){if(name==='leads'){clearTaskCommentsScope();if(replyReadStatus==='loading')closeDetail();return loadWorklist();}if(name==='tasks')void latest();}
  function worklistParams(page){const quick=worklistScope==='priority'?'priority':worklistScope==='analysis'?'pending':'';return {worklist:['all','sent'].includes(worklistScope)?'all':'pending',...(worklistTaskId?{task_id:worklistTaskId}:{}),...(worklistScope==='sent'?{reply_state:'sent'}:{}),sort:'intent',group_by:groupBy,group_offset:groupOffset,offset:page,limit:25,...(groupKey?{group_key:groupKey}:{}),...(quick||$('worklist-intent').value?{intent_level:quick||$('worklist-intent').value}:{}),...($('worklist-query').value.trim()?{query:$('worklist-query').value.trim()}: {})};}
  async function openPending(){clearTaskCommentsScope();worklistScope='pending';offset=0;groupKey='';groupOffset=0;$('worklist-query').value='';$('worklist-intent').value='';$('worklist-intent').disabled=false;closeDetail();await loadWorklist(0);}
  async function refreshWorklistSummary(_generation,device,{accept=()=>true}={}){
   const scope=worklistReadScope(),version=pageVersion();if(worklistSummaryRead?.scope===scope&&worklistSummaryRead?.generation===_generation)return worklistSummaryRead.promise;
   const serial=++worklistSummarySerial,promise=(async()=>{
   const globalCommon={sort:'intent',group_by:'intent',offset:0,limit:1},common={...globalCommon,...(worklistTaskId?{task_id:worklistTaskId}:{})},[pendingResult,allResult,sentResult,globalPendingResult]=await Promise.allSettled([action('leads_list',{...common,worklist:'pending'}),action('leads_list',{...common,worklist:'all'}),action('leads_list',{...common,worklist:'all',reply_state:'sent'}),...(worklistTaskId?[action('leads_list',{...globalCommon,worklist:'pending'})]:[])]);
   if(!accept()||serial!==worklistSummarySerial||scope!==worklistReadScope()||_generation!==readGeneration||version!==pageVersion()||device!==getState().selected||disposed)return;
   const pending=pendingResult.status==='fulfilled'?pendingResult.value:null,all=allResult.status==='fulfilled'?allResult.value:null;
   const count=label=>(pending?.groups||[]).filter(group=>group.label===label).reduce((sum,group)=>sum+group.count,0);
   const analysisCount=pending?.analysis_pending_total??(pending?.groups||[]).filter(group=>group.label==='待分析'||group.label.endsWith('· 待分析')).reduce((sum,group)=>sum+group.count,0);
   worklistSummary={pending:pending?.total??null,priority:pending?count('超高意向')+count('高意向'):null,analysis:pending?analysisCount:null,sent:sentResult.status==='fulfilled'?sentResult.value.total:null,all:all?.total??null,analyzed:all?.analysis_analyzed_total??null,missing:all?.analysis_missing_text_total??null};worklistSummaryAt=pending&&all?Date.now():0;
   const navigationResult=globalPendingResult||pendingResult,navigationCount=navigationResult.status==='fulfilled'?navigationResult.value?.total:null;
   navigationPending={scope:navigationPendingScope(),count:Number.isSafeInteger(navigationCount)&&navigationCount>=0?navigationCount:null};
   worklistSummaryScope=scope;renderWorklistSummary();
   })();
   worklistSummaryRead={scope,generation:_generation,promise};
   try{return await promise;}finally{if(serial===worklistSummarySerial)worklistSummaryRead=null;}
  }
  function renderWorklistSummary(){
   for(const [name,id] of [['pending','pending-count'],['priority','priority-count'],['analysis','analysis-count'],['sent','sent-count'],['all','all-count']])$(id).textContent=worklistSummary[name]===null?'—':String(worklistSummary[name]);
   renderNavigationPending();
   $('pending-tab').title='需要跟进的评论。已回复、已忽略、不相关和极低意向仍保留在「全部」。';
   $('analysis-tab').title='有正文、尚无 AI 或人工判断的评论；正文缺失的记录标为「正文待补」。';
   $('all-tab').title=worklistSummary.analyzed===null?'所有已保存评论，包括已回复和不相关的记录。':`所有已保存评论；已分析 ${worklistSummary.analyzed} 条，正文待补 ${worklistSummary.missing??'—'} 条。`;
   const help=document.querySelector('.worklist-summary-help');
   const hint='「全部」保留所有评论；「待处理」排除已回复、已忽略、不相关和极低意向。分类按当前范围统计，再分页。';
   if(help){help.title=hint;help.setAttribute('aria-label',hint);}
  }
 function scheduleDetailViewport(){if(detailFrame||disposed)return;detailFrame=requestAnimationFrame(()=>{detailFrame=0;const detail=$('reply-detail');if(detail.hidden||window.matchMedia('(max-width:980px)').matches){detail.style.removeProperty('--reply-visible-height');return;}const top=detail.getBoundingClientRect().top;detail.style.setProperty('--reply-visible-height',`${Math.max(0,Math.floor(window.innerHeight-top-16))}px`);});}
 async function loadWorklist(page=0,{accept=()=>true}={}){
  if(!worklistTimer)worklistTimer=setInterval(async()=>{if(disposed||taskId||worklistRefreshing||!getUser()||$('workspace').dataset.page!=='leads'||$('workspace').dataset.upgradeView==='customers')return;worklistRefreshing=true;try{await loadWorklist(offset);}catch(error){onError(error);}finally{worklistRefreshing=false;}},30000);
  if(!accept())return false;if(worklistTaskId&&worklistTaskBinding!==worklistReadScope()){clearTaskCommentsScope();return false;}
  const generation=++readGeneration,device=getState().selected,deviceGeneration=getState().deviceGeneration,principal=customerPrincipalSignature(getUser()),scope=worklistReadScope(),version=pageVersion(),params=worklistParams(page),current=()=>accept()&&generation===readGeneration&&device===getState().selected&&deviceGeneration===getState().deviceGeneration&&principal===customerPrincipalSignature(getUser())&&scope===worklistReadScope()&&version===pageVersion()&&!disposed;$('worklist-feedback').textContent='正在读取评论…';$('pending-bell-dot').hidden=true;
   try{const result=await action('leads_list',params);if(!current())return false;if(page>0&&page>=result.total)return loadWorklist(Math.max(0,Math.floor((result.total-1)/25)*25),{accept});
    rows=result.items||[];total=result.total||0;offset=page;groupRows=result.groups||[];groupsTotal=result.groups_total||0;renderWorklist();if(scope!==worklistSummaryScope||Date.now()-worklistSummaryAt>30000)void refreshWorklistSummary(generation,device,{accept:current}).catch(onError);$('worklist-feedback').textContent=rows.length?'':worklistScope==='sent'?'还没有确认发送成功的回复':worklistTaskId?'本任务没有符合条件的评论':'没有符合条件的评论';
   if(selectionId&&!rows.some(x=>x.id===selectionId)&&selectionId!==externalSelectionId)closeDetail();else if(selectionId){selectedLead=rows.find(x=>x.id===selectionId)||selectedLead;renderDetailInfo(selectedLead);}return true;
   }catch(error){if(current()){invalidatePendingSummary();$('worklist-feedback').textContent=worklistScope==='priority'&&/意向筛选|参数无效/.test(String(error?.message||''))?'优先联系分类尚不可用，请更新本机服务后重试':'评论读取失败，请重试';throw error;}return false;}
 }
  function renderWorklist(){
   renderTaskCommentsScope();
    if($('workspace').dataset.page==='leads')$('page-heading').textContent='客户工作台';
   const host=$('worklist-groups');host.replaceChildren();for(const [name,id] of [['pending','pending-tab'],['priority','priority-tab'],['analysis','analysis-tab'],['sent','sent-tab'],['all','all-tab']]){const active=worklistScope===name;$(id).classList.toggle('active',active);$(id).setAttribute('aria-selected',String(active));}
   renderWorklistSummary();
   if(groupBy==='intent'){
    const overview=el('div',undefined,'intent-overview');overview.setAttribute('aria-label','全部意向档位');
    for(const kind of ['super_high','high','medium','low','very_low','pending','uncertain','unrelated']){
     const label=intentLabels[kind],count=intentGroupCount(groupRows,kind);
     const item=el('span',`${label} ${count}`,'intent-overview-item');item.dataset.level=kind;bindIntentHint(item,kind);overview.append(item);
    }
    host.append(overview);
   }
   const tableHead=el('div',undefined,'upgrade-grid-head');tableHead.setAttribute('role','row');for(const label of ['', '客户与需求','意向','最近联系','渠道归属','下一步'])tableHead.append(el('span',label));host.append(tableHead);
   const groups=groupComments(rows,groupBy);for(const group of groups){const section=el('section',undefined,'post-group'),heading=el('div',undefined,'post-group-heading'),count=groupRows.find(g=>g.key===group.key)?.count,expansionKey=`${groupBy}:${group.key}`;
   section.dataset.groupKey=expansionKey;
   const fold=el('button',undefined,'group-fold');fold.setAttribute('aria-label','收起评论');fold.type='button';fold.setAttribute('aria-expanded','true');heading.append(groupBy==='note'?sourceLink(group.url,group.label):el('span',group.label),el('span',count===undefined?`本页 ${group.items.length} 条评论`:`${count} 条评论`,'group-count'));section.append(heading);
   if(groupBy==='note'){const first=group.items[0]||{},meta=el('div',undefined,'group-post-meta'),coverUrl=mediaUrl(first.content_cover_url);if(coverUrl){const cover=el('img',undefined,'group-post-cover');cover.src=coverUrl;cover.alt='帖子封面';cover.loading='lazy';cover.referrerPolicy='no-referrer';cover.onerror=()=>cover.remove();heading.prepend(cover);}if(first.content_author_avatar_url||localWorkspace&&first.id)meta.append(avatar(first.content_author_avatar_url,group.author,first.id,'post_author',localWorkspace));meta.append(el('span',group.author||'博主未提供'));if(first.content_published_at)meta.append(el('time',displayCommentDate(first.content_published_at)));heading.append(meta);}const body=el('div',undefined,'post-group-comments');fold.addEventListener('click',()=>{body.hidden=!body.hidden;fold.classList.toggle('collapsed',body.hidden);fold.setAttribute('aria-label',body.hidden?'展开评论':'收起评论');fold.setAttribute('aria-expanded',String(!body.hidden));});heading.prepend(fold);
    for(const lead of group.items){const card=el('div',undefined,'work-comment');card.tabIndex=0;card.setAttribute('role','row');card.dataset.leadId=lead.id;card.classList.toggle('selected',lead.id===selectionId);card.setAttribute('aria-selected',String(lead.id===selectionId));card.setAttribute('aria-controls','reply-detail');const identity=el('div',undefined,'upgrade-row-identity'),copy=el('div',undefined,'work-comment-copy'),intent=displayIntent(lead),badge=el('span',intent.label,'intent-tag');badge.dataset.level=intent.kind;
     const choice=el('input');choice.type='checkbox';choice.checked=lead.id===selectionId;choice.setAttribute('aria-label',`查看${lead.author||'客户'}的评论`);choice.onclick=event=>{event.stopPropagation();void selectLead(lead).catch(onError);};card.append(choice);bindIntentHint(badge,intent.kind);copy.append(el('strong',lead.author||'用户未提供'),el('p',lead.text||'评论正文未提供'));identity.append(avatar(lead.author_avatar_url,lead.author,lead.id,'author',localWorkspace),copy);card.append(identity);
     const intentCell=el('div',undefined,'upgrade-row-intent');intentCell.append(badge);card.append(intentCell);const contact=el('div',undefined,'upgrade-row-contact'),state=lead.reply_state||'none';contact.dataset.state=state;contact.append(el('span',replyStateLabel(state)),el('small',displayCommentDate(lead.published_at)));card.append(contact);
     const channel=el('div',undefined,'upgrade-row-channel'),latestHandoff=handoffRecords.filter(item=>item.lead_id===lead.id||lead.author_id&&item.source?.author_id===lead.author_id&&item.source?.platform===lead.platform).sort((a,b)=>(b.updated_at||0)-(a.updated_at||0))[0],handoffState=latestHandoff?handoffPresentation(latestHandoff):null;channel.dataset.tone=handoffState?.tone||'neutral';channel.title=handoffState?.label||'';channel.append(el('span',handoffState?.label||(String(lead.author_id||'').trim()?'来源身份已记录':'来源身份待核实')),el('small',`${lead.platform==='xiaohongshu'?'小红书':lead.platform||'平台待核对'} · 原始评论`));card.append(channel);
     const next=el('div',undefined,'upgrade-row-actions');if(window.fangyuUpgrade?.canCreateHandoff?.()){const handoff=el('button','整理交接','secondary');handoff.type='button';handoff.onclick=event=>{event.stopPropagation();const promise=selectLead(lead),generation=detailGeneration,principal=customerPrincipalSignature(getUser()),device=getState().selected,deviceGeneration=getState().deviceGeneration;void promise.then(()=>{if(generation===detailGeneration&&principal===customerPrincipalSignature(getUser())&&device===getState().selected&&deviceGeneration===getState().deviceGeneration&&selectionId===lead.id)return window.fangyuUpgrade?.showHandoff?.(lead.id);}).catch(onError);};next.append(handoff);}const view=el('button','查看详情','secondary');view.type='button';view.onclick=event=>{event.stopPropagation();void selectLead(lead).catch(onError);};next.append(view);card.append(next);card.addEventListener('click',guard(()=>selectLead(lead)));card.addEventListener('keydown',event=>{if(event.target===card&&['Enter',' '].includes(event.key)){event.preventDefault();void selectLead(lead).catch(onError);}});body.append(card);}
   section.append(body);host.append(section);}
   const pageText=`${total?offset+1:0}–${Math.min(offset+rows.length,total)} / ${total}`;$('worklist-page').textContent=pageText;$('worklist-page-top').textContent=pageText;$('worklist-prev').disabled=offset<=0;$('worklist-next').disabled=offset+25>=total;
   $('worklist-group-summary').textContent=`${groupsTotal} 个${{note:'帖子',blogger:'博主',date:'日期',intent:'意向分类'}[groupBy]}`;
   const select=$('worklist-group-key');select.setAttribute('aria-label','筛选分组');select.replaceChildren(new Option('全部分组',''));for(const group of groupRows)select.append(new Option(`${group.label} (${group.count})`,group.key));select.value=groupKey;
  $('worklist-group-prev').disabled=groupOffset<=0;$('worklist-group-next').disabled=groupOffset+30>=groupsTotal;$('worklist-group-page').textContent=groupsTotal>30?`${groupOffset+1}–${Math.min(groupOffset+30,groupsTotal)} / ${groupsTotal} 组`:'';
 }
 function exportCurrent(){const cell=value=>{const raw=String(value??'');return '"'+(/^[\s\uFEFF]*[=+\-@]|^[\t\r\n]/u.test(raw)?"'"+raw:raw).replaceAll('"','""')+'"';};const csv='\uFEFF'+[['客户','平台','平台身份','意向','评论时间','原始评论','原帖'],...rows.map(lead=>[lead.author,lead.platform,lead.author_id,displayIntent(lead).label,displayCommentDate(lead.published_at),lead.text,lead.note_url||lead.url])].map(row=>row.map(cell).join(',')).join('\r\n');const url=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'})),download=el('a');download.href=url;download.download='方隅原始评论-本页.csv';download.click();setTimeout(()=>URL.revokeObjectURL(url),1000);$('worklist-feedback').textContent=`已导出本页${rows.length}条原始评论，未对外发送。`;}
 function closeDetail(){manualReplyOperation++;manualReplyBusy=false;manualQueueNotice.hidden=true;manualQueueNotice.textContent="";for(const button of [manualCopy,manualConfirm,manualLocator]){button.hidden=true;button.disabled=true;}leadOpenGeneration++;traceUpgradeRoute('enterprise.closeDetail','',leadOpenGeneration,true);replyReadStatus='ready';draftRetry.hidden=true;$('reply-text').disabled=false;const previous=selectionId;detailGeneration++;selectionId='';externalSelectionId='';selectedLead=null;reply=null;contactReceipt=null;replyNeedsCheck=false;customerKey='';customerLink.hidden=true;$('reply-detail').hidden=true;$('reply-detail').style.removeProperty('--reply-visible-height');$('worklist-layout').classList.remove('has-detail');renderWorklist();const target=[...$('worklist-groups').querySelectorAll('[data-lead-id]')].find(n=>n.dataset.leadId===previous);target?.focus({preventScroll:true});}
 function renderDetailInfo(lead,{resetView=false}={}){if(!lead)return;const detail=$('reply-detail'),scope=JSON.stringify([customerPrincipalSignature(getUser()),getState().selected||'',getState().deviceGeneration??0]);if(!resetView&&detail.dataset.sourceScope&&detail.dataset.sourceScope!==scope)return;const sameSource=detail.dataset.sourceScope===scope&&detail.dataset.leadId===lead.id&&detail.dataset.authorId===String(lead.author_id||'')&&detail.dataset.platform===String(lead.platform||''),contextChanged=resetView||!sameSource,detailView=!contextChanged&&['contact','handoff','source'].includes(detail.dataset.detailView)?detail.dataset.detailView:'contact';traceUpgradeRoute('enterprise.renderDetail',detailView,detailGeneration,contextChanged);if(contextChanged){$('reply-review-details').open=false;for(const expanded of $('reply-detail').querySelectorAll('details'))if(!expanded.classList.contains('upgrade-tone-panel'))expanded.open=false;}const sourceStep=$('reply-detail').querySelector('[data-step="source"]'),sourceImage=sourceStep?.querySelector('img'),sourceRecorded=!!lead.id&&!!String(lead.author_id||'').trim()&&!!lead.platform;if(sourceStep){sourceStep.dataset.recorded=String(sourceRecorded);sourceStep.title=sourceRecorded?'已保存原始评论和来源身份':'来源身份未完整提供，需人工核对';if(sourceStep.lastChild?.nodeType===3)sourceStep.lastChild.textContent=sourceRecorded?'来源已记录':'来源待核对';}if(sourceImage)sourceImage.src=sourceRecorded?'?asset=tabler-upgrade-check.svg':'?asset=tabler-upgrade-warning.svg';const progress=$('reply-detail').querySelector('[data-step="handoff"]');if(contextChanged){if(progress){progress.dataset.tone='neutral';progress.title='正在核对当前客户的交接记录';if(progress.lastChild?.nodeType===3)progress.lastChild.textContent='交接待核对';}handoffChecked.checked=false;}syncInlineHandoff();detail.dataset.sourceScope=scope;$('reply-detail').dataset.leadId=lead.id;$('reply-detail').dataset.authorId=String(lead.author_id||'');$('reply-detail').dataset.platform=String(lead.platform||'');$('reply-detail').dataset.detailView=detailView;for(const tab of document.querySelectorAll('button[data-detail-view]')){const active=tab.dataset.detailView===detailView;tab.classList.toggle('active',active);tab.setAttribute('aria-selected',String(active));}$('upgrade-inline-handoff').hidden=detailView!=='handoff';document.dispatchEvent(new CustomEvent('upgrade:lead-detail',{detail:{leadId:lead.id,context_changed:contextChanged}}));renderNeedCards(lead);const intent=displayIntent(lead);setAvatar($('reply-avatar'),lead.author_avatar_url,lead.author,lead.id,'author',localWorkspace);$('reply-user').textContent=lead.author||'用户未提供';$('reply-date').textContent=({xiaohongshu:'小红书',douyin:'抖音',zhihu:'知乎',wechat_channels:'视频号'})[lead.platform]||'平台待核对';$('reply-date').textContent+=' · '+(String(lead.author_id||'').trim()?'已保存客户':'身份待核实');$('reply-date').title=displayCommentDate(lead.published_at);$('reply-post').replaceChildren(sourceLink(lead.note_url||lead.url,lead.content_title||'帖子标题未提供'));$('reply-post-author').textContent=lead.content_author||'博主未提供';setAvatar($('reply-post-avatar'),lead.content_author_avatar_url,lead.content_author,lead.id,'post_author',localWorkspace);$('reply-post-avatar').hidden=!localWorkspace&&!mediaUrl(lead.content_author_avatar_url);const cover=$('reply-cover'),coverUrl=mediaUrl(lead.content_cover_url),emptyCover=$('upgrade-source-cover-empty');cover.hidden=!coverUrl;if(emptyCover)emptyCover.hidden=!!coverUrl;cover.referrerPolicy='no-referrer';cover.onerror=()=>{if($('reply-detail').dataset.leadId!==lead.id||cover.getAttribute('src')!==coverUrl)return;cover.hidden=true;if(emptyCover)emptyCover.hidden=false;};if(coverUrl)cover.src=coverUrl;else cover.removeAttribute('src');$('upgrade-source-summary').textContent=lead.text||'评论正文未提供';$('upgrade-source-summary').title=lead.text||'评论正文未提供';$('upgrade-source-comment-date').textContent=lead.published_at?displayCommentDate(lead.published_at):'评论时间未提供';const sourceUrl=String(lead.note_url||lead.url||'');$('upgrade-source-open').replaceChildren(sourceLink(sourceUrl,/^https:\/\//.test(sourceUrl)?'查看原文':'原文链接未提供'));$('reply-post-date').textContent=lead.content_published_at?displayCommentDate(lead.content_published_at):'';$('reply-original').textContent=lead.text||'评论正文未提供';$('reply-intent').textContent=intent.label;$('reply-intent').dataset.level=intent.kind;
   $('reply-next-step').textContent=intentReplyGuidance(intent.kind);$('reply-next-step').dataset.level=intent.kind;bindIntentHint($('reply-intent'),intent.kind);
   const extractedFacts=intentFacts(lead),facts=extractedFacts||[],factChip=x=>{const chip=el('span',x.value,'evidence-chip');chip.title=x.evidence||'';return chip;};$('reply-evidence').replaceChildren(...facts.slice(0,3).map(factChip));extraEvidence.replaceChildren(...facts.slice(3).map(factChip));extraEvidence.hidden=facts.length<=3;$('reply-analysis-status').textContent=lead.analysis_status==='missing_text'&&!String(lead.text||'').trim()?'评论正文缺失，补齐后自动分析':intent.kind==='pending'?(aiProfileStatus==='not_configured'||aiProfileStatus==='disabled'?'企业 AI 尚未启用，配置后自动分析':aiProfileStatus==='enabled'?'等待自动分析':'正在核对 AI 状态'):facts.length?'':extractedFacts===null?'此条尚无结构化关键信息':'未提及明确的预算、入住或通勤要求';$('reply-manual-reason').textContent=lead.manual_intent?`人工修正：${lead.manual_intent.reason||'未填写修正理由'}`:'';$('reply-manual-reason').hidden=!lead.manual_intent;$('reply-reason').textContent=lead.ai_intent?`AI 判断：${lead.ai_intent.reason||'未提供判断理由'}`:lead.manual_intent?'':lead.grade&&intent.kind==='pending'?'尚未完成 AI 分析':intent.reason||'尚未完成 AI 分析';$('reply-reason').hidden=!$('reply-reason').textContent;if(contextChanged){$('manual-intent').value=intent.status==='graded'?intent.level:intent.status;$('manual-reason').value=lead.manual_intent?.reason||'';}
   compactDetail.querySelector('.detail-key-info').hidden=!facts.length&&intent.kind!=='pending'&&lead.analysis_status!=='missing_text';
   const legacy=[lead.grade?`历史评分 ${lead.grade}`:'',lead.ai_intent?.rules_version?`分析规则 ${lead.ai_intent.rules_version}`:''].filter(Boolean);$('legacy-intent-note').textContent=legacy.join(' · ');$('legacy-intent-details').hidden=!legacy.length;
  const platformIp=lead.ip_location||lead.region||'未提供',contentRegion=lead.content_region||lead.ai_intent?.content_region||'待核实';$('reply-metadata').textContent=`平台 IP 属地：${platformIp}；内容提及地区：${contentRegion}；日期与地区：${lead.verification_status==='pending'?'待核实':'以原文为准'}`;
 }
 function clearSessionDetail(){
  manualReplyOperation++;manualReplyBusy=false;manualQueueNotice.hidden=true;manualQueueNotice.textContent="";for(const button of [manualCopy,manualConfirm,manualLocator]){button.hidden=true;button.disabled=true;}
  sessionGeneration++;latestGeneration++;form.reset();$('keyword-seed').value='';$('latest-discoveries').replaceChildren();$('keyword-library-list').replaceChildren();$('keyword-library').hidden=true;
  for(const id of ['reply-user','reply-date','reply-original','reply-post','reply-post-date','reply-post-author','reply-intent','reply-next-step','reply-manual-reason','reply-reason','reply-metadata','reply-feedback','reply-customer-state','reply-analysis-status','legacy-intent-note','reply-evidence','upgrade-source-summary','upgrade-source-comment-date','upgrade-source-open','upgrade-inline-handoff']){const node=$(id);node.replaceChildren();node.removeAttribute('title');node.removeAttribute('href');}
  for(const node of [extraEvidence,originalNeedEvidence,needCardsHost])node.replaceChildren();
  for(const id of ['manual-intent','manual-reason','reply-text']){const node=$(id);node.value='';node.removeAttribute('value');if(id!=='manual-intent')node.textContent='';}
  $('reply-account').replaceChildren(new Option('选择回复账号',''));$('reply-account').value='';$('reply-count').textContent='0 / 1000';delete $('reply-feedback').dataset.replyState;
  for(const key of ['leadId','authorId','platform','sourceScope','detailView'])delete compactDetail.dataset[key];
  for(const id of ['reply-avatar','reply-post-avatar','reply-cover']){const node=$(id);node.onerror=node.onload=null;avatarFallbacks.get(node)?.remove();avatarFallbacks.delete(node);node.removeAttribute('src');node.removeAttribute('alt');delete node.dataset.fallback;node.hidden=true;}
  for(const expanded of compactDetail.querySelectorAll('details'))expanded.open=false;
  handoffChecked.checked=false;syncInlineHandoff();$('upgrade-inline-handoff').hidden=true;browserReply.hidden=true;browserReply.disabled=true;$('reply-save').disabled=true;$('reply-confirm').disabled=true;renderQueue();
 }
 async function selectLead(lead,{external=false,openRequest=null,accept=()=>true}={}){
  const current=()=>!disposed&&accept()&&(openRequest===null||openRequest===leadOpenGeneration);
  if(!current()||$('workspace').dataset.page!=='leads')return false;
  if(openRequest===null)leadOpenGeneration++;
  const generation=++detailGeneration;traceUpgradeRoute('enterprise.selectLead','contact',generation,external);selectionId=lead.id;externalSelectionId=external?lead.id:'';selectedLead=lead;reply=null;contactReceipt=null;replyNeedsCheck=false;replyReadStatus='loading';draftRetry.hidden=true;
  const request={generation,pageVersion:pageVersion(),leadId:lead.id,platform:String(lead.platform||''),authorId:String(lead.author_id||'').trim(),principal:customerPrincipalSignature(getUser())};
  $('reply-detail').hidden=false;$('worklist-layout').classList.add('has-detail');renderDetailInfo(lead,{resetView:true});void refreshCustomerContext(lead,generation);renderWorklist();scheduleDetailViewport();$('reply-text').value='';$('reply-feedback').textContent='正在读取草稿…';delete $('reply-feedback').dataset.replyState;updateReply(false);
  try{
   const result=await action('reply_status',{lead_id:lead.id});if(!current()||!customerCurrent(request))return;
   reply=result.status?result:{status:'none'};replyReadStatus='ready';$('reply-text').value=reply.text||'';updateReply();scheduleDetailViewport();$('reply-detail').focus({preventScroll:true});if(matchMedia('(max-width:980px)').matches)$('reply-detail').scrollIntoView({block:'start',behavior:'auto'});await refreshContactReceipt();
  }catch(error){
   if(!current()||!customerCurrent(request))return;reply=null;replyReadStatus='failed';updateReply(false);$('reply-feedback').textContent='草稿读取失败，请重试';draftRetry.hidden=false;
  }
 }
 draftRetry.onclick=()=>{if(replyReadStatus==='loading'||!selectedLead)return;void selectLead(selectedLead,{external:externalSelectionId===selectedLead.id});};
  async function openLead(lead,{preservePage=false,accept=()=>true}={}){if(!lead||typeof lead.id!=='string'||!lead.id)throw Error('评论资料不完整，请刷新客户清单');if(!accept())return false;clearTaskCommentsScope();closeDetail();worklistScope='all';groupBy='note';groupKey='';groupOffset=0;$('worklist-group-by').value='note';$('worklist-intent').value='';$('worklist-intent').disabled=false;$('worklist-query').value='';if(!preservePage)onPage('leads');const nonce=++leadOpenGeneration,version=pageVersion(),device=getState().selected,deviceGeneration=getState().deviceGeneration,principal=customerPrincipalSignature(getUser()),current=()=>!disposed&&nonce===leadOpenGeneration&&accept()&&version===pageVersion()&&device===getState().selected&&deviceGeneration===getState().deviceGeneration&&principal===customerPrincipalSignature(getUser())&&$('workspace').dataset.page==='leads';traceUpgradeRoute('enterprise.openLead.start','',nonce,true);const ready=await loadWorklist(0);traceUpgradeRoute('enterprise.openLead.read','',nonce,current()&&ready===true);if(!current())return false;if(ready!==true)throw Error('评论范围正在刷新，请重新打开客户详情。');const original=await action('lead_detail',{lead_id:lead.id});if(!current())return false;if(!original||original.id!==lead.id||typeof original.text!=='string'||typeof original.platform!=='string')throw Error('原评论详情尚未核实，请重新打开。');await selectLead(original,{external:true,openRequest:nonce,accept:current});return current();}
 async function trackedReplyCall(name,data){const response=await fetch('/api',{method:'POST',headers:{'Content-Type':'application/json','X-Local-App':'1'},body:JSON.stringify({action:name,data})});const result=await response.json();if(!response.ok||result.error)throw Error(result.error||'网页回复状态未确认');return result;}
 async function openTrackedReply(){
  if(!localWorkspace||held()||!canReply()||reply?.status!=='approved'||browserReplyBusy)throw Error('当前不能打开网页回复');
  if($('reply-text').value.trim()!==reply.text?.trim())throw Error('请先保存并确认当前回复内容');
  const accountId=$('reply-account').value;if(!accountId||reply.review_account_id!==accountId)throw Error('请核对回复账号');
  const id=reply.id,generation=detailGeneration;browserReplyBusy=true;updateReply(false);
  try{let job=await trackedReplyCall('tracked_reply_start',{reply_id:id,account_id:accountId,authorized:true});
   while(!disposed&&generation===detailGeneration&&reply?.id===id){
    if(!/^[a-f0-9]{32}$/.test(job.id||'')||job.reply_id!==id||job.account_id!==accountId)throw Error('网页回复任务状态未确认');
    $('reply-feedback').textContent=job.message||'请在原帖按已审核内容回复，结果会自动核对';
    if(['completed','stopped'].includes(job.status)){await refreshSelectedReply();worklistSummaryAt=0;await loadWorklist(offset);break;}
    await new Promise(resolve=>setTimeout(resolve,1500));job=await trackedReplyCall('tracked_reply_status',{job_id:job.id});
   }
  }catch(error){if(generation===detailGeneration&&reply?.id===id)$('reply-feedback').textContent=error.message;throw error;}
  finally{browserReplyBusy=false;updateReply(false);}
 }
 function updateReply(writeFeedback=true){
  syncManualReplyButtons();
  if(replyReadStatus!=='ready'){$('reply-count').textContent=`${$('reply-text').value.length} / 1000`;$('reply-save').disabled=true;$('reply-confirm').disabled=true;$('reply-text').disabled=true;browserReply.hidden=true;browserReply.disabled=true;return;}
  $('reply-text').disabled=false;$('reply-text').readOnly=!canReply();const text=$('reply-text').value;$('reply-count').textContent=`${text.length} / 1000`;const current=reply?.status||'none';browserReply.hidden=!localWorkspace||held()||current!=='approved';browserReply.disabled=browserReplyBusy||replyNeedsCheck||!canReply()||text.trim()!==String(reply?.text||'').trim();const states={none:'',draft:'草稿已保存，待确认',approved:['running','awaiting_collection'].includes(queue?.status)?'已审核，发送进展请在待发送清单核对':'已审核，尚未发送；可加入待发送清单',copied:'已复制，未发送',sent:'已回复',unknown:'发送结果待核对',sending:'正在发送'};$('reply-feedback').dataset.replyState=current;if(writeFeedback)$('reply-feedback').textContent=canReply()||['sent','unknown','sending'].includes(current)?(current==='sent'&&contactReceipt?.text?contactReceipt.text:(Object.hasOwn(states,current)?states[current]:'状态待核对')):'当前账号没有草稿与回复权限，请联系获授权成员处理';$('reply-save').disabled=!canReply()||replyNeedsCheck||!selectionId||['sent','unknown','sending'].includes(current);$('reply-confirm').disabled=replyNeedsCheck||!canReply()||!reply?.id||['sent','unknown','sending'].includes(current)||text.trim()!==String(reply?.text||'').trim();
  const select=$('reply-account'),prior=select.value,choice=replyAccountSelection(getState().accounts,prior||reply?.review_account_id||field('account_id').value);select.replaceChildren(new Option('选择回复账号',''));for(const account of choice.eligible)select.append(new Option(account.name||account.id,account.id));select.value=choice.value;select.closest('label').hidden=!choice.showChoice;select.disabled=['running','awaiting_collection'].includes(queue?.status);const approved=current==='approved';$('reply-confirm').textContent=approved?'加入待发送清单':'审核后回复';if(!select.value)$('reply-confirm').disabled=true;if(approved&&(!reply.review_account_id||reply.review_account_id!==select.value)){$('reply-confirm').disabled=true;if(canReply()&&writeFeedback)$('reply-feedback').textContent='请重新保存草稿并核对当前回复账号';}if(canReply()&&!choice.eligible.length&&writeFeedback&&!['sent','unknown','sending'].includes(current))$('reply-feedback').textContent=(current==='draft'?'草稿已保存；':current==='approved'?'草稿审核记录已保存；':'')+'小红书账号需要登录或核实，暂不能审核回复';if(replyNeedsCheck&&writeFeedback)$('reply-feedback').textContent='正在核对回复状态…';
 }
  async function saveReply(){if(!canReply())throw Error('当前账号没有草稿与回复权限');const id=selectionId,text=$('reply-text').value.trim();if(!id||!text)throw Error('请填写回复内容');const result=await action('reply_prepare',{lead_id:id,text});if(id!==selectionId)return;reply=result;updateReply();worklistSummaryAt=0;await loadWorklist(offset);}
 function manualDetailScope(){return JSON.stringify([getUser(),getState().selected,getState().deviceGeneration,cloud.epoch,cloud.companyId,cloud.environmentId,selectionId,reply?.id,detailGeneration]);}
 function manualQueueConflict(){return ['ready','awaiting_collection','running'].includes(queue?.status)&&Array.isArray(queue?.reply_ids)&&queue.reply_ids.includes(reply?.id);}
 function syncManualReplyButtons(){
  const current=reply?.status;manualCopy.hidden=!localWorkspace||current!=='approved';manualConfirm.hidden=!localWorkspace||current!=='copied';manualLocator.hidden=!localWorkspace||current!=='sent'||contactReceipt?.status!=='external';
  const conflict=manualQueueConflict();manualQueueNotice.hidden=!localWorkspace||!conflict;manualQueueNotice.textContent=conflict?'此回复仍在原待发送清单中，请先取消原队列，再选择人工联系。':'';
  for(const button of [manualCopy,manualConfirm,manualLocator]){button.disabled=manualReplyBusy||replyNeedsCheck||replyReadStatus!=='ready'||!canReply()||conflict;button.title=conflict?'请先取消原待发送队列':'';}
 }
 async function manualReplyAction(kind){
  if(!localWorkspace||!canReply()||replyNeedsCheck||manualReplyBusy||!reply?.id)return;
  if(manualQueueConflict())throw Error('此回复仍在原待发送清单中，请先取消原队列。');
  const expected=kind==='reply_copy'?'approved':'copied';if(reply.status!==expected)throw Error('原回复状态已变化，请重新读取。');
  const original=manualDetailScope(),ticket=++manualReplyOperation,id=reply.id,leadId=selectionId,current=()=>!disposed&&ticket===manualReplyOperation&&original===manualDetailScope()&&!$('reply-detail').hidden;
  manualReplyBusy=true;syncManualReplyButtons();let actionStarted=false;
  try{
   if(kind==='reply_manual_confirm'){
    const open=window.fangyuUpgrade?.operations?.openManualReplyConfirmation;
    if(typeof open!=='function')throw Error('人工确认窗口暂不可用，本次未提交。');
    if(await open({replyId:id,leadId},{accept:current})!==true||!current())return;
    if(!canReply()||replyNeedsCheck||reply?.status!==expected)throw Error('原回复状态或权限已变化，本次未提交，请重新读取。');
    if(manualQueueConflict())throw Error('此回复仍在原待发送清单中，本次未提交，请先取消原队列。');
   }
   actionStarted=true;
   const value=await action(kind,{reply_id:id,...(kind==='reply_manual_confirm'?{confirmed:true}:{})});if(!current())return;
   if(value?.manual_only!==true||value.platform_verified!==false||value.response_check_started!==false||value.reply?.id!==id||value.reply.status!==(kind==='reply_copy'?'copied':'sent'))throw Error('人工操作回显待核对，请读取原回复。');
   reply=value.reply;contactReceipt=kind==='reply_manual_confirm'?{status:'external',text:'人工登记 · 平台未核验'}:null;worklistSummaryAt=0;
   if(kind==='reply_copy'){confirmedReplies.delete(id);if(!confirmedReplies.size)confirmedAccount='';renderQueue();}
   updateReply();
   if(kind==='reply_copy'){
    try{await navigator.clipboard.writeText(value.text);}catch{if(current())$('reply-feedback').textContent='复制操作已记录，剪贴板未完成；请手动复制已审核文字。仍未确认发送。';return;}
    if(current())$('reply-feedback').textContent='已复制，未确认发送。请到原帖人工发送，再明确登记。';
   }else if(current()){
    $('reply-feedback').textContent='人工登记 · 平台未核验';
     await window.fangyuUpgrade?.operations?.openManualReplyLocator({replyId:id,leadId},{accept:current});
   }
  }catch(error){if(current()){if(actionStarted){replyNeedsCheck=true;$('reply-feedback').textContent='人工操作结果待核对，请重新打开原评论读取；暂勿重复确认。';}else $('reply-feedback').textContent=error.message||'确认未完成，本次未提交。';updateReply(false);}throw error;}
  finally{if(ticket===manualReplyOperation){manualReplyBusy=false;syncManualReplyButtons();}}
 }
 manualCopy.onclick=()=>void manualReplyAction('reply_copy').catch(onError);
 manualConfirm.onclick=()=>void manualReplyAction('reply_manual_confirm').catch(onError);
 manualLocator.onclick=()=>{if(manualLocator.disabled||!reply?.id)return;const original=manualDetailScope(),id=reply.id,leadId=selectionId;void window.fangyuUpgrade?.operations?.openManualReplyLocator({replyId:id,leadId},{accept:()=>!disposed&&original===manualDetailScope()&&!$('reply-detail').hidden}).catch(onError);};

 async function confirmReply(){if(!canReply())throw Error('尚未获得回复确认权限');if(!reply?.id||!selectionId)throw Error('请先保存草稿');const id=reply.id,leadId=selectionId,generation=detailGeneration,principal=customerPrincipalSignature(getUser()),device=getState().selected,deviceGeneration=getState().deviceGeneration,reviewText=$('reply-text').value,accountId=$('reply-account').value,current=()=>!disposed&&generation===detailGeneration&&leadId===selectionId&&id===reply?.id&&principal===customerPrincipalSignature(getUser())&&device===getState().selected&&deviceGeneration===getState().deviceGeneration&&accountId===$('reply-account').value;if(!accountId)throw Error('请选择回复账号');if(confirmedAccount&&confirmedAccount!==accountId)throw Error('账号已变化，请重新确认所选回复');if(confirmedReplies.size>=20&&!confirmedReplies.has(reply.id))throw Error('一次最多确认 20 条回复');if($('reply-text').value.trim()!==reply.text?.trim())throw Error('内容已改变，请重新保存草稿');if(reply.status==='approved'){if(reply.review_account_id!==accountId)throw Error('请重新保存草稿并核对当前回复账号');}else{if(reply.status!=='draft')throw Error('当前回复不能确认，请核对状态');const reviewed=await action('reply_review',{reply_id:id,account_id:accountId,confirmed:true});if(!current())return;if(reviewed?.id!==id||reviewed?.status!=='approved'||reviewed?.review_account_id!==accountId){replyNeedsCheck=true;updateReply(false);throw Error('审核结果待核对，请重新打开客户读取草稿状态。');}reply=reviewed;}if(!current())return;if($('reply-text').value!==reviewText){confirmedReplies.delete(id);if(!confirmedReplies.size)confirmedAccount='';updateReply(false);renderQueue();$('reply-feedback').textContent='原草稿已审核，当前内容已修改且未加入待发送清单；请重新保存并审核。';return;}confirmedReplies.add(reply.id);confirmedAccount=accountId;updateReply();renderQueue();$('reply-feedback').textContent=['running','awaiting_collection'].includes(queue?.status)?'已加入本机待发送清单；已有发送进展需核对':'已审核，尚未发送，请在待发送清单准备并确认';if(!$('reply-detail').hidden&&$('reply-detail').dataset.detailView==='contact')$('reply-queue').scrollIntoView?.({block:'nearest',behavior:'smooth'});}
 function renderQueue(){const labels={ready:'队列已准备',awaiting_collection:'等待采集暂停',running:'顺序发送中',completed:'发送完成',stopped:'发送已停止',interrupted:'发送中断，需要核对',cancelled:'队列已取消',unknown:'结果未知，需要核对'};const terminal=['completed','stopped','interrupted','cancelled','unknown'].includes(queue?.status),canContinue=queue?.status==='awaiting_collection'&&queue.wait_expired===true;$('reply-queue').hidden=!queue&&!confirmedReplies.size;$('queue-feedback').textContent=queue?`${labels[queue.status]||'状态待核对'} · 已处理 ${queue.processed??0} / ${queue.reply_ids?.length??confirmedReplies.size} · 已发送 ${queue.sent??0}${queue.message?` · ${queue.message}`:''}`:`已审核 ${confirmedReplies.size} 条，尚未发送；请先准备待发送清单，再由获授权成员最终确认发送。`;$('queue-prepare').disabled=!canReply()||!confirmedReplies.size||['running','awaiting_collection','interrupted','unknown'].includes(queue?.status);$('queue-send').textContent=canContinue?'继续发送':'开始发送';$('queue-send').disabled=!canReply()||held()||!queue||terminal||!(queue.status==='ready'||canContinue);$('queue-refresh').disabled=!queue;$('queue-cancel').disabled=!queue||terminal;$('queue-gate').textContent=held()?'公开回复尚未开放；草稿与确认状态已保留。':'';}
 async function prepareQueue(){if(!canReply()||!confirmedReplies.size)throw Error('请先确认回复');queue=await action('reply_queue_prepare',{reply_ids:[...confirmedReplies],account_id:confirmedAccount,confirmed:true});renderQueue();}
 function scheduleQueue(){clearTimeout(queueTimer);if(['running','awaiting_collection'].includes(queue?.status))queueTimer=setTimeout(()=>queueAction('reply_queue_status').catch(error=>{onError(error);scheduleQueue();}),3000);}
 async function refreshContactReceipt(){
  if(reply?.status!=='sent'||!reply?.id)return;
  const id=reply.id,generation=detailGeneration;
  contactReceipt={status:'checking',text:'已回复 · 正在核对云端记录'};updateReply();
  try{const result=localWorkspace?await verifyReceipt(data=>action('contact_receipt_status',data),data=>cloud.call('contact_receipts_verify',data),id):{status:'pending',text:'已回复 · 请在原电脑核对联系凭据'};if(generation===detailGeneration&&reply?.id===id){contactReceipt=result;updateReply();}}
  catch{if(generation===detailGeneration&&reply?.id===id){contactReceipt={status:'failed',text:'已回复 · 云端核对未完成，请重新打开此评论'};updateReply();}}
 }
 async function refreshSelectedReply(){const id=selectionId,generation=detailGeneration;if(!id)return;replyNeedsCheck=true;updateReply();try{const result=await action('reply_status',{lead_id:id});if(id!==selectionId||generation!==detailGeneration)return;reply=result.status?result:{status:'none'};replyNeedsCheck=false;contactReceipt=null;updateReply();await refreshContactReceipt();}catch(error){if(id===selectionId){$('reply-feedback').textContent='回复状态读取失败，请重新打开此评论核对';updateReply(false);}onError(error);}}
  async function queueAction(name){if(!queue?.id&&!queue?.queue_id)throw Error('请先准备队列');if(name==='reply_queue_send'&&(!canReply()||held()||!(queue.status==='ready'||queue.status==='awaiting_collection'&&queue.wait_expired===true)))throw Error('当前队列不能发送，请核对状态');queue=await action(name,{queue_id:queue.id||queue.queue_id,...(name==='reply_queue_send'?{authorized:true}:{})});if(['completed','stopped','interrupted','cancelled','unknown'].includes(queue.status)){if(['completed','stopped','cancelled'].includes(queue.status)){confirmedReplies.clear();confirmedAccount='';}worklistSummaryAt=0;await loadWorklist(offset);await refreshSelectedReply();}renderQueue();scheduleQueue();}
  async function correct(){if(!selectionId)return;const id=selectionId,generation=detailGeneration,principal=customerPrincipalSignature(getUser()),device=getState().selected,deviceGeneration=getState().deviceGeneration;const value=$('manual-intent').value;if(!value)throw Error('请选择人工判断的意向');const status=['uncertain','unrelated'].includes(value)?value:'graded';const lead=await action('intent_correct',{lead_id:id,status,level:status==='graded'?value:null,reason:$('manual-reason').value.trim()});if(generation!==detailGeneration||id!==selectionId||principal!==customerPrincipalSignature(getUser())||device!==getState().selected||deviceGeneration!==getState().deviceGeneration||disposed)return;selectedLead=lead;renderDetailInfo(lead);worklistSummaryAt=0;await loadWorklist(offset);}
 function renderAiProvider(clearKey=false){
  if(clearKey){$('ai-key').value='';$('ai-clear-key').checked=false;}
  const provider=$('ai-provider').value,entry=aiConfig?.providers?.[provider]||
   (provider===aiConfig?.provider?aiConfig:{}),catalog=(aiConfig?.model_catalog||[]).filter(item=>item.provider===provider);
  $('ai-model').replaceChildren(...catalog.map(item=>{const option=el('option',item.label);option.value=item.id;return option;}));
  if(catalog.some(item=>item.id===entry.model))$('ai-model').value=entry.model;
  $('ai-configured').classList.remove('is-error');$('ai-configured').textContent=entry.configured?'该供应商密钥已配置':'请填写该供应商的 API 密钥';
  $('ai-key-help').href=provider==='openai'?'https://platform.openai.com/api-keys':'https://platform.deepseek.com/api_keys';
  $('ai-key-help').textContent=provider==='openai'?'获取 OpenAI API 密钥':'获取 DeepSeek API 密钥';
  $('ai-usd-rate-label').hidden=provider!=='openai';renderAiEffort(entry.reasoning_effort);
 }
 function renderAiEffort(preferred){
  const item=(aiConfig?.model_catalog||[]).find(item=>item.provider===$('ai-provider').value&&item.id===$('ai-model').value);
  const efforts=item?.reasoning_efforts||[],labels={none:'关闭推理',low:'低 · 更快',medium:'中',high:'高',xhigh:'超高',max:'最高'};
  $('ai-effort').replaceChildren(...efforts.map(value=>{const option=el('option',labels[value]||value);option.value=value;return option;}));
  $('ai-effort-label').hidden=!efforts.length;
  $('ai-effort').value=efforts.includes(preferred)?preferred:item?.id==='gpt-5.4-mini'&&efforts.includes('none')?'none':efforts.includes('low')?'low':efforts[0]||'';
 }
 async function openAi(){if(getUser()?.role!=='admin')return;const result=await cloud.call('ai_config_read'),c=result.config;aiConfig=c;
  // An old server exposes only DeepSeek. Never submit an unsupported provider to it.
  if(!Array.isArray(c.model_catalog))aiConfig={...c,provider:'deepseek',model_catalog:[{id:'deepseek-flash',provider:'deepseek',label:'DeepSeek Flash',reasoning_efforts:[]},{id:'deepseek-v4-pro',provider:'deepseek',label:'DeepSeek V4 Pro',reasoning_efforts:[]}]};
  $('ai-provider').value=aiConfig.provider||'deepseek';$('ai-provider').querySelector('option[value="openai"]').disabled=!aiConfig.model_catalog.some(item=>item.provider==='openai');
  $('ai-enabled').checked=!!c.enabled;$('ai-daily-budget').value=c.daily_budget_cny;$('ai-usd-rate').value=c.usd_cny_rate||7.5;$('ai-rules-version').value=c.rules_version;$('ai-rules-version').readOnly=true;renderAiProvider(true);$('ai-dialog').showModal();
 }
 async function saveAi(){const key=$('ai-key').value,provider=$('ai-provider').value;$('ai-key').value='';
  const config={provider,enabled:$('ai-enabled').checked,model:$('ai-model').value,daily_budget_cny:Number($('ai-daily-budget').value)};
  if(aiConfig?.model_catalog?.some(item=>item.provider==='openai')){config.usd_cny_rate=Number($('ai-usd-rate').value);if(provider==='openai')config.reasoning_effort=$('ai-effort').value;}
  else delete config.provider;
  const clearKey=$('ai-clear-key').checked,data={config,...(key?{api_key:key}:{}),...(clearKey?{clear_api_key:true}:{})};
  const controls=[...$('ai-config-form').elements];for(const control of controls)control.disabled=true;$('ai-configured').textContent='正在保存…';
  try{
   if(key&&clearKey)throw Error('请在填写新密钥和清除密钥之间选择一项');
   let saveError=null;try{await cloud.call('ai_config_save',data);}catch(error){if(error.status)throw error;saveError=error;}
   let current;try{current=(await cloud.call('ai_config_read')).config;}catch{throw Error('保存结果待核对；配置读取失败，请稍后重新打开设置核对');}
   if(!aiConfigFieldsMatch(config,current))throw Error(saveError?'保存结果待核对；当前配置与填写内容不一致，请核对后重试':'保存请求已返回，但回读配置与填写内容不一致，请核对后重试');
   if(saveError&&(key||clearKey))throw Error('配置字段已回读核对；密钥写入结果无法回读确认，请在管理后台核对');
   aiConfig=current;renderAiProvider(true);$('ai-configured').classList.remove('is-error');$('ai-configured').textContent=key||clearKey?'配置字段已回读核对；密钥不回显':'企业配置已回读核对';await profile();
  }
  finally{$('ai-key').value='';for(const control of controls)control.disabled=false;}
 }
 function renderUpdate(){const view=updatePresentation(updateState||{});$('update-version').textContent=updateState?`当前版本 ${view.installedVersion}${view.installedRelease===null?'':` · 发布 ${view.installedRelease}`}${view.candidateRelease===null?'':` · 可用发布 ${view.candidateRelease}`}`:'';$('update-state').textContent=updateState?view.label:'';$('update-feedback').textContent=updateError||(updateBusy?'正在核对更新状态…':view.message||'正在读取更新状态…');$('update-feedback').classList.toggle('is-error',!!updateError);$('update-restart').hidden=!(view.restart||['pending_restart','awaiting_close'].includes(view.status));for(const [id,visible,allowed] of [['update-check',view.configured,view.canCheck],['update-download',view.canDownload,view.canDownload],['update-install',view.canInstall,view.canInstall]]){const button=$(id);button.hidden=!visible;button.disabled=updateBusy||updateUnknown||!allowed;}$('update-refresh').disabled=updateBusy;}
 async function updateAction(name){if(getUser()?.role!=='admin')throw Error('更新由管理员管理');const view=updatePresentation(updateState||{});if(name==='update_download'&&!view.canDownload||name==='update_install'&&!view.canInstall||name==='update_check'&&!view.canCheck)throw Error('请先刷新并核对更新状态');updateBusy=true;updateError='';renderUpdate();try{updateState=await action(name,{});updateUnknown=false;}catch(error){updateUnknown=!!error.requestId;updateError=updateUnknown?'操作结果待核对，请刷新状态后继续':error.message||'更新操作未完成';throw error;}finally{updateBusy=false;renderUpdate();}}
 async function openUpdate(){if(getUser()?.role!=='admin')return;$('update-dialog').showModal();await updateAction('update_status');}
  $('keywords-expand').addEventListener('click',()=>{keywordsExpanded=!keywordsExpanded;renderKeywords();});$('keywords-recommended').addEventListener('click',()=>{if(!keywords.some(k=>k.recommended===true))return;selected=new Set(keywords.filter(k=>k.recommended===true).map(k=>k.keyword));renderKeywords();renderContinuous();syncPoolDraft();});$('keywords-all').addEventListener('click',()=>{selected=new Set(keywords.map(k=>k.keyword));renderKeywords();renderContinuous();syncPoolDraft();});
 $('suggest-keywords').addEventListener('click',guard(recommend));$('open-keyword-library').hidden=localWorkspace;$('open-keyword-library').addEventListener('click',guard(async()=>{$('keyword-library').hidden=!$('keyword-library').hidden;if(!$('keyword-library').hidden)await restoreLibrary();}));
 field('keywords').addEventListener('input',()=>{updateKeywordCount();syncPoolDraft();});field('city').addEventListener('input',schedulePoolRegion);field('area').addEventListener('input',schedulePoolRegion);$('keyword-seed').addEventListener('input',syncPoolDraft);$('keyword-count').addEventListener('change',syncPoolDraft);form.addEventListener('input',renderContinuous);form.addEventListener('change',renderContinuous);field('comment_date_range').addEventListener('change',()=>{$('custom-comment-dates').hidden=field('comment_date_range').value!=='custom';});
 form.addEventListener('invalid',event=>{if(!settingsDialog.contains(event.target))return;event.preventDefault();if(invalidQueued)return;invalidQueued=true;openCollectionDialog($('create-task'),event.target,'请补全采集条件');queueMicrotask(()=>{invalidQueued=false;});},true);
 $('collection-adjust').addEventListener('click',event=>openCollectionDialog(event.currentTarget));$('collection-dialog-close').addEventListener('click',closeCollectionDialog);$('collection-dialog-done').addEventListener('click',guard(async()=>{if(keywordBusy){$('collection-dialog-feedback').textContent='请等关键词生成后再确认';return;}if(!chosen().length){$('collection-dialog-feedback').textContent='请勾选关键词，或展开“手动加词”';return;}const signature=keywordSignature(),words=JSON.stringify(chosen());await ensurePoolSaved();if(signature!==keywordSignature()||words!==JSON.stringify(chosen()))throw Error('关键词已变化，请重新确认');approveKeywords();closeCollectionDialog();}));settingsDialog.addEventListener('close',()=>{placeCollectionDemand({open:false,demand,home:demandHome,dialogHost:dialogDemandHost});const target=settingsReturnFocus;settingsReturnFocus=null;renderCollectionSummary();if(target?.isConnected!==false)target?.focus?.();if(target&&taskId&&!disposed)void refreshContinuous().catch(onError);});
 $('keyword-adjust').addEventListener('click',()=>{$('keyword-options').open=!$('keyword-options').open;syncKeywordAdjustment();});$('keyword-options').addEventListener('toggle',syncKeywordAdjustment);
 $('continuous-toggle').addEventListener('click',guard(toggle));$('continuous-add-keywords').addEventListener('click',()=>{$('keyword-options').open=true;syncKeywordAdjustment();field('keywords').closest('details').open=true;field('keywords').focus();});
 $('analysis-retry').addEventListener('click',guard(async()=>{analysisBusy=true;renderContinuous();try{await action('intent_analyze_pending',{task_id:taskId});report('已完成本批分析');await refreshContinuous();}finally{analysisBusy=false;renderContinuous();}}));
  $('latest-open-all').addEventListener('click',()=>{clearTaskCommentsScope();worklistScope='all';groupKey='';groupOffset=0;$('worklist-intent').value='';$('worklist-intent').disabled=false;$('worklist-query').value='';onPage('leads');void loadWorklist(0).catch(onError);});
  for(const [id,value] of [['pending-tab','pending'],['priority-tab','priority'],['analysis-tab','analysis'],['sent-tab','sent'],['all-tab','all']])$(id).addEventListener('click',guard(async()=>{clearTaskCommentsScope();worklistScope=value;offset=0;groupKey='';groupOffset=0;$('worklist-intent').value='';$('worklist-intent').disabled=value==='priority'||value==='analysis';closeDetail();await loadWorklist();}));
  $('worklist-group-by').addEventListener('change',guard(async event=>{clearTaskCommentsScope();groupBy=event.currentTarget.value;groupKey='';groupOffset=0;if(groupBy==='intent'){worklistScope='all';$('worklist-intent').value='';$('worklist-intent').disabled=false;$('worklist-query').value='';}closeDetail();await loadWorklist(0);}));
  $('worklist-group-key').addEventListener('change',guard(async event=>{clearTaskCommentsScope();groupKey=event.currentTarget.value;closeDetail();await loadWorklist(0);}));
  $('worklist-intent').addEventListener('change',guard(()=>{clearTaskCommentsScope();groupKey='';groupOffset=0;closeDetail();return loadWorklist(0);}));$('worklist-filter').addEventListener('submit',guard(()=>{clearTaskCommentsScope();groupKey='';groupOffset=0;closeDetail();return loadWorklist(0);}));
 $('worklist-prev').addEventListener('click',guard(()=>loadWorklist(Math.max(0,offset-25))));$('worklist-next').addEventListener('click',guard(()=>loadWorklist(offset+25)));
 $('worklist-group-prev').addEventListener('click',guard(async()=>{groupOffset=Math.max(0,groupOffset-30);await loadWorklist();}));$('worklist-group-next').addEventListener('click',guard(async()=>{groupOffset+=30;await loadWorklist();}));
 browserReply.addEventListener('click',guard(openTrackedReply));$('reply-close').addEventListener('click',closeDetail);$('reply-text').addEventListener('input',updateReply);$('reply-save').addEventListener('click',guard(saveReply));$('reply-confirm').addEventListener('click',guard(confirmReply));$('manual-intent-save').addEventListener('click',guard(correct));
 $('reply-account').addEventListener('change',()=>{if(confirmedReplies.size&&$('reply-account').value!==confirmedAccount){confirmedReplies.clear();confirmedAccount='';queue=null;clearTimeout(queueTimer);$('reply-feedback').textContent='回复账号已变化，请重新确认每条草稿';renderQueue();updateReply(false);}else updateReply();});$('queue-prepare').addEventListener('click',guard(prepareQueue));
 for(const [id,name] of [['queue-send','reply_queue_send'],['queue-refresh','reply_queue_status'],['queue-cancel','reply_queue_cancel']])$(id).addEventListener('click',guard(()=>queueAction(name)));
 $('ai-provider').addEventListener('change',()=>renderAiProvider(true));$('ai-model').addEventListener('change',()=>renderAiEffort());
 $('open-ai-config').addEventListener('click',guard(openAi));$('ai-config-form').addEventListener('submit',guard(saveAi));$('ai-close').addEventListener('click',()=>{$('ai-key').value='';$('ai-dialog').close();});$('ai-dialog').addEventListener('close',()=>{$('ai-key').value='';});$('open-update').addEventListener('click',guard(openUpdate));$('update-close').addEventListener('click',()=>$('update-dialog').close());for(const [id,name] of [['update-check','update_check'],['update-download','update_download'],['update-install','update_install'],['update-refresh','update_status']])$(id).addEventListener('click',guard(()=>updateAction(name)));
 // The footer belongs to the detail scrollport so its actions remain visible.
 $('reply-detail').append($('reply-detail').querySelector('.detail-reply-actions'));
 $('reply-detail').querySelector('.detail-reply-actions').prepend($('reply-detail').querySelector('.reply-edit-meta'));
 const sourceFooter=el('section',undefined,'upgrade-source-footer');sourceFooter.append(el('h3','来源证据'),postLine,compactDetail.querySelector('.detail-post-meta'));compactDetail.append(sourceFooter);
 const inlineHandoffEntry=el('div',undefined,'upgrade-detail-handoff-entry'),handoffChecked=el('input'),handoffLabel=el('label'),handoffEntryButton=el('button','整理交接','text-button');handoffChecked.type='checkbox';handoffChecked.id='upgrade-detail-handoff-check';handoffLabel.append(handoffChecked,el('span','我已核对本次交接用途与接收方'));handoffEntryButton.type='button';handoffEntryButton.disabled=true;inlineHandoffEntry.append(handoffLabel,handoffEntryButton);compactDetail.insertBefore(inlineHandoffEntry,sourceFooter);
 const syncInlineHandoff=()=>{inlineHandoffEntry.hidden=!window.fangyuUpgrade?.canCreateHandoff?.();handoffEntryButton.disabled=!handoffChecked.checked||!selectionId||!window.fangyuUpgrade?.canCreateHandoff?.();};handoffChecked.onchange=syncInlineHandoff;handoffEntryButton.onclick=()=>{if(!handoffEntryButton.disabled&&selectionId)void window.fangyuUpgrade?.showHandoff?.(selectionId).catch(onError);};document.addEventListener('upgrade:permissions',syncInlineHandoff);syncInlineHandoff();
 window.addEventListener('resize',scheduleDetailViewport);
 window.addEventListener('scroll',scheduleDetailViewport,{passive:true});
 window.addEventListener('focus',()=>{if(!disposed&&getUser()&&$('workspace').dataset.page==='tasks')void profile();});
 document.addEventListener('keydown',event=>{if(event.key==='Escape'&&selectedLead){closeDetail();$('pending-tab').focus();}});
 renderKeywords();renderContinuous();renderNavigationPending();
 return {start,syncSnapshot,markSnapshotUnconfirmed,invalidatePendingSummary,onNavigate(){clearTaskCommentsScope();leadOpenGeneration++;readGeneration++;if(replyReadStatus==='loading')closeDetail();},loadWorklist,openTaskComments,openPending,openLead,closeDetail,exportCurrent,redraw:renderWorklist,setHandoffs(items){handoffRecords=Array.isArray(items)?items:[];renderWorklist();},profile,latest,restorePool,reset(){setTaskCommentsScope('',{force:true});leadOpenGeneration++;settingsReturnFocus=null;closeCollectionDialog();disposed=false;startHeaderDate();cancelPoll();clearTimeout(poolRegionTimer);poolInputGeneration++;keywordPool?.clear();poolReadPending=false;taskId='';hydratedTaskId='';savedForStart=null;savedForStartDevice='';pendingSave=null;collectionUncertain=null;snapshotUnconfirmed=false;collectionBusy='';aiProfileStatus='unknown';aiProfile={};aiConfig=null;keywordBusy=false;analysisBusy=false;updateState=null;updateBusy=false;updateUnknown=false;updateError='';$('pending-bell-dot').hidden=true;$('keyword-options').open=false;syncKeywordAdjustment();delete $('create-task').dataset.uncertain;task=null;readGeneration++;detailGeneration++;rows=[];handoffRecords=[];selectionId='';externalSelectionId='';selectedLead=null;reply=null;replyNeedsCheck=false;queue=null;confirmedReplies.clear();confirmedAccount='';keywords=[];selected.clear();libraryId='';keywordApproval=null;keywordAttemptSignature='';profileGeneration++;$('ai-key').value='';$('ai-budget-state').textContent='';$('ai-budget-state').hidden=true;$('ai-dialog').close();$('update-dialog').close();closeDetail();clearSessionDetail();resetTaskCommentFilters();$('worklist-feedback').textContent='';renderContinuous();renderKeywords();},async refresh(){if(pendingSave){if(pendingSave.deviceId!==getState().selected){report('当前电脑已变化，请回到原电脑核对保存结果，暂勿重复开始',true);return;}if(!pendingSave.commandId){report('保存结果仍待核对，请联系管理员查看原操作；暂勿重复开始',true);return;}const result=await cloud.inspect(pendingSave.commandId);if(result?.status==='succeeded'&&result.result?.id){savedForStart={...pendingSave.data,...result.result};savedForStartDevice=pendingSave.deviceId;taskId=savedForStart.id;task=savedForStart;pendingSave=null;delete $('create-task').dataset.uncertain;$('create-task').disabled=false;report('设置已保存，点击开始采集继续此任务');}else if(['failed','cancelled'].includes(result?.status)){pendingSave=null;delete $('create-task').dataset.uncertain;$('create-task').disabled=false;report('设置未保存，可以重新开始',true);}else{report('保存结果仍待核对，暂勿重复开始',true);return;}}await refreshContinuous();await profile();},onPage:onWorklistPage,dispose(){setTaskCommentsScope('',{force:true});leadOpenGeneration++;settingsReturnFocus=null;closeCollectionDialog();disposed=true;clearInterval(headerDateTimer);headerDateTimer=0;cancelPoll();if(detailFrame)cancelAnimationFrame(detailFrame);}};
}
