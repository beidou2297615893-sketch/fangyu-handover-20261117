"""Opt-in owned natural-page worker. No platform HTTP or synthesized API calls.

The existing parent retains account locking, pacing, cancellation and storage.
This helper owns only its WebView2 and authenticated loopback IPC connection.
"""
from threading import Event, Thread
from collections import OrderedDict
import json
import time
from urllib.parse import parse_qs, urlsplit

from natural_page_controller import (NaturalPageController, NaturalPageError,
                                     _json_pairs, _reject_constant)
from owned_natural_reader import OwnedNaturalReader, ReaderError
from xhs_page_window import _post, PageBridgeError
from xhs_search_range import (initial_checkpoint, resume_checkpoint, validate_checkpoint,
                             advance_checkpoint, mark_delivered)
from xhs_page_transport import _platform_code


_FAILURES = {'pagination_unknown', 'pagination_unavailable', 'document_changed',
             'timeout', 'invalid_response', 'not_authenticated', 'identity_mismatch',
             'verification_required', 'body_unavailable', 'body_stale',
             'response_scope_invalid', 'request_scope_invalid',
             'comment_scroll_unavailable', 'search_scroll_unavailable', 'cancelled'}


class NaturalWindowWorker:
    """One logical call at a time; injectable native reader for local QA."""
    def __init__(self, spec, window, *, post=_post, reader_factory=OwnedNaturalReader,
                 clock=time.monotonic):
        self.spec, self.window, self.post, self.clock = spec, window, post, clock
        self.closed = Event()
        self.controller = None
        self.reader = reader_factory(window, navigation_callback=self._navigation)
        self.active = None
        self.deadline = 0
        self.next_action = 0
        self.checkpoint = None
        self.network_attempted = False
        self.stopped = False
        self.comment_responses = []
        self.sub_responses = []
        self.root_evidence = OrderedDict()
        self.expanded_cursors = set()
        self.search_waiting = False

    def _navigation(self, uri, *, redirected=False):
        if self.controller is None:
            return False
        approved = self.controller.physical_navigation(uri, redirected=redirected)
        self.network_attempted |= approved
        return approved

    def connect(self):
        self.reader.attach()
        facts = self.reader.runtime_sources(self.spec.profile_dir)
        packet = {
            'secret': self.spec.bootstrap_secret,
            'tenant_id': self.spec.tenant_id, 'account_id': self.spec.account_id,
            'bound_uid': self.spec.bound_uid, 'doc_epoch': 1, 'runtime_facts': facts}
        if self.spec.purpose=='identity_observation':packet['purpose']='identity_observation'
        response = self.post(self.spec, '/connect', packet)
        token = response.get('session_token')
        if response.get('ok') is not True or not isinstance(token, str) or len(token) < 32:
            raise PageBridgeError('ipc_failed')
        self.controller = NaturalPageController(
            post=lambda path, packet: self.post(self.spec, path, packet),
            navigate=lambda url:self.reader.navigate_target(url), session_token=token,
            bound_uid=self.spec.bound_uid,
            identity_observation=self.spec.purpose=='identity_observation')

    def _scope(self):
        return {'doc_epoch': self.controller.doc_epoch,
                'task_epoch': self.active['task_epoch'], 'identity_verified': True}

    def _begin(self, packet):
        if packet.get('ok') is not True:
            raise PageBridgeError('ipc_failed')
        command = {key: packet[key] for key in ('action', 'call_id', 'task_epoch', 'params')}
        target = self.controller._target(command['action'], command['params'])
        self.reader.arm(command['action'], command['params'],
                        doc_epoch=self.reader.doc_epoch,
                        task_epoch=command['task_epoch'], target_url=target,
                        bound_uid=self.spec.bound_uid,
                        identity_observation=self.spec.purpose=='identity_observation',
                        replay_main=(command['action'] == 'comments' and bool(command['params']['cursor'])),
                        replay_sub=command['action'] == 'sub_comments',
                        observe_main_roots=command['action'] == 'sub_comments')
        self.active = command
        self.deadline = self.clock() + 50
        self.next_action = self.clock()
        self.network_attempted = False
        self.checkpoint = None
        self.comment_responses = []
        self.sub_responses = []
        self.expanded_cursors = set()
        self.search_waiting = False
        if command['action'] == 'search':
            saved = command['params'].get('rangeCheckpoint')
            self.checkpoint = (resume_checkpoint(validate_checkpoint(saved)) if saved is not None
                else initial_checkpoint(command['params']['keyword']))
        # Native NavigationStarting invokes the reader on the UI thread.
        # Never hold the reader lock while load_url waits for that thread.
        self.controller.accept_command(command)

    def _comments(self):
        if not self.controller.identity_verified:
            return
        while self.comment_responses and self.controller.phase != 'idle':
            expected = self.controller.replay_expected_cursor
            desired = self.active['params']['cursor']
            wanted = desired if expected is None else expected
            found = next((index for index, response in enumerate(self.comment_responses)
                if parse_qs(urlsplit(response.url).query, keep_blank_values=True).get('cursor',[''])[0] == wanted), None)
            if found is None:
                return
            response = self.comment_responses.pop(found)
            if wanted == desired:
                self.controller.passive_response(response)
            else:
                self.controller.consume_comment_replay(response)
            self._remember_root_evidence(response)

    def _remember_root_evidence(self, response):
        if response.http_status != 200:
            return
        envelope = json.loads(response.body.decode('utf-8'))
        data = envelope
        for _ in range(4):
            if not isinstance(data, dict) or 'comments' in data:
                break
            data = data.get('data')
        if not isinstance(data, dict):
            return
        note = self.active['params']['noteId']
        for item in data.get('comments', []):
            if not isinstance(item, dict):
                continue
            user = item.get('user_info')
            alternate = item.get('user')
            if isinstance(user,dict) and isinstance(alternate,dict):
                if user.get('user_id') != alternate.get('user_id'):
                    continue
            elif not isinstance(user,dict):
                user = alternate
            ident, content = item.get('id'), item.get('content')
            if (not isinstance(user, dict) or not isinstance(ident,str) or len(ident)>128 or
                    not isinstance(content,str) or len(content)>5000):
                continue
            uid = user.get('user_id')
            if not isinstance(uid,str) or not 0<len(uid)<=100 or not content:
                continue
            fallback = {'author_uid':uid, 'content':content}
            nickname = user.get('nickname')
            if isinstance(nickname,str) and 0<len(nickname)<=120:
                fallback['author'] = nickname
            created = item.get('create_time')
            if type(created) is int and len(str(created)) in (10,13):
                fallback['create_time'] = str(created)
            key = (note,ident)
            self.root_evidence[key] = fallback
            self.root_evidence.move_to_end(key)
            while len(self.root_evidence)>2048:
                self.root_evidence.popitem(last=False)

    def _consume_sub_responses(self):
        params = self.active['params']
        note, root = params['noteId'], params['rootCommentId']
        if not self.controller.can_expand_root(note,root):
            return
        while self.sub_responses and self.controller.phase == 'identity_verified':
            expected = self.controller.sub_replay_expected_cursor
            wanted = params['cursor'] if expected is None else expected
            found = next((index for index,response in enumerate(self.sub_responses)
                if parse_qs(urlsplit(response.url).query,keep_blank_values=True)
                .get('cursor',[''])[0] == wanted),None)
            if found is None:
                return
            response = self.sub_responses.pop(found)
            if wanted == params['cursor']:
                self.controller.passive_response(response)
            else:
                self.controller.consume_sub_replay(response)
                if self.controller.phase == 'identity_verified':
                    self.reader.authorize_root_page(response, **self._scope())

    def _sub_comments(self):
        params = self.active['params']
        note, root = params['noteId'], params['rootCommentId']
        if not self.controller.can_expand_root(note, root):
            # Current physical-document main-comment evidence must authorize
            # the exact root/cursor before even a read-only expansion click.
            if self.controller.root_main_expected_cursor == '':
                self.next_action = self.clock()+1.5
                return
            if self.controller.root_main_expected_cursor is None:
                raise ReaderError('pagination_unavailable')
            self.reader.scroll_note_comments(note, **self._scope())
            self.next_action = self.clock()+1.5
            return
        expected = self.controller.sub_replay_expected_cursor
        cursor = params['cursor'] if expected is None else expected
        facts = self.reader.read_or_expand_root(note,root, **self._scope(), page_cursor=cursor,
                                              fallback=self.root_evidence.get((note,root)))
        if facts['code'] == 'security':
            raise ReaderError('verification_required')
        if facts['code'] == 'login_wall':
            raise ReaderError('not_authenticated')
        if facts['code'] == 'observed' and cursor not in self.expanded_cursors:
            expanded = self.reader.read_or_expand_root(note,root,action='expand',
                **self._scope(),page_cursor=cursor,fallback=self.root_evidence.get((note,root)))
            if expanded['code'] != 'expanded_once':
                raise ReaderError('pagination_unavailable')
            self.expanded_cursors.add(cursor)
        elif facts['code'] == 'root_not_found':
            self.reader.scroll_note_comments(note, **self._scope())
        elif facts['code'] != 'observed':
            raise ReaderError('pagination_unavailable')
        self.next_action = self.clock()+1.5

    def _document(self):
        state = self.reader.document_state()
        if self.controller.phase in ('navigating', 'invalidated'):
            # CDP can observe the new Document request before Core.Source
            # switches from the old document. Wait for both facts, rather
            # than reject that normal renderer transition as account failure.
            if (self.controller.phase == 'invalidated' and state['loader_id'] and
                    state['frame_id'] and self.controller._route_matches(state['current_url'],history=True)):
                self.controller.document_ready(doc_epoch=state['doc_epoch'],
                    loader_id=state['loader_id'], frame_id=state['frame_id'],
                    uri=state['current_url'])
            else:
                return False
        elif (self.controller.phase in ('observing', 'identity_verified') and
              state['current_url'] != self.controller.current_url):
            self.controller.history_changed(state['current_url'])
        if self.controller.phase == 'failed':
            raise ReaderError('document_changed')
        return True

    def _search(self):
        keyword = self.active['params']['keyword']
        snapshot = self.reader.read_search_range(keyword, **self._scope())
        self._record_search_snapshot(snapshot)
        if (snapshot['code'] == 'feed_loading' or
                snapshot['code'] == 'observed' and not snapshot['card_count'] and
                (snapshot['content_loading'] or snapshot['feed_client_height'] == 0) and
                not snapshot['explicit_end_marker']):
            self.search_waiting = True
            self.next_action = self.clock() + .5
            return
        self.search_waiting = False
        self.checkpoint, event = advance_checkpoint(self.checkpoint, snapshot, keyword=keyword)
        if event['next_action'] == 'inspect':
            raise ReaderError('search_scroll_unavailable')
        delivered = set(self.checkpoint['delivered_ids'])
        wanted = [ident for ident in snapshot['ready_ids'] if ident not in delivered][:40]
        if wanted:
            found = self.reader.read_wanted_rows(keyword, wanted, **self._scope())
            rows = [row for row in found['rows'] if row['xsec_token']]
            if rows:
                self.checkpoint = mark_delivered(self.checkpoint,
                                               [row['note_id'] for row in rows])
                info = {'state': self.checkpoint['range_state'], 'checkpoint': self.checkpoint,
                        'delivered_ids': list(self.checkpoint['delivered_ids'])}
                self.controller.submit_dom_search(rows, info,
                    doc_epoch=self.controller.doc_epoch, task_epoch=self.active['task_epoch'],
                    route_revision=self.controller.route_revision)
                return
        if event['range_state'] in ('plateau', 'explicit_end'):
            pending = set(self.checkpoint['ready_ids']) - set(self.checkpoint['delivered_ids'])
            if pending:
                # Observed but unavailable virtual rows are not silently lost.
                raise ReaderError('pagination_unknown')
            info = {'state': event['range_state'], 'checkpoint': self.checkpoint,
                    'delivered_ids': list(self.checkpoint['delivered_ids'])}
            self.controller.submit_dom_search([], info,
                doc_epoch=self.controller.doc_epoch, task_epoch=self.active['task_epoch'],
                route_revision=self.controller.route_revision)
            return
        scrolling = self.reader.read_search_range(keyword, action='scroll', **self._scope())
        self.checkpoint, _ = advance_checkpoint(self.checkpoint, scrolling, keyword=keyword)
        self.next_action = self.clock() + 1.5

    def _record_search_snapshot(self, snapshot):
        # Diagnostics contain geometry and counts only, never keyword, IDs or links.
        self.last_search_snapshot = {k:v for k,v in snapshot.items()
            if k not in ('observed_ids','ready_ids')}
        self._write_diagnostic('xhs-natural-search-state', self.last_search_snapshot)

    def _write_diagnostic(self, name, value):
        if name not in ('xhs-natural-search-state','xhs-natural-failure-state','xhs-natural-comment-state'):
            return
        if not hasattr(self.spec, 'profile_dir') or not hasattr(self.spec, 'spec_path'):
            return
        try:
            from xhs_page_window import _job_scope, _reparse
            _job_scope(self.spec.spec_path)
            folder = self.spec.profile_dir.parent / 'work'
            target = folder / (name + '.json')
            tmp = folder / (name + '.tmp')
            if any(_reparse(p) for p in (folder,target,tmp)):
                return
            tmp.write_text(json.dumps(value), encoding='utf-8')
            tmp.replace(target)
        except (OSError,ValueError,PageBridgeError):
            pass

    def tick(self):
        if self.closed.is_set() or self.spec.cancel_file.exists():
            self.stopped = True
            return 'cancelled'
        if self.active is None:
            packet = self.post(self.spec, '/poll', {
                'session_token': self.controller.session_token,
                'doc_epoch': self.controller.doc_epoch})
            action = packet.get('action')
            if action == 'stop':
                self.stopped = True
                return 'stopped'
            if action in ('idle', 'hold'):
                return action
            self._begin(packet)
        if not self._document():
            if self.clock() >= self.deadline:
                raise ReaderError('timeout')
            return 'navigating'
        for response in self.reader.pump():
            if self.controller.phase == 'idle':
                break
            self.network_attempted = True
            # Search is observed from rendered cards. A successful response of
            # one endpoint cannot invent API paging for DOM-discovered rows.
            if (response.kind == 'search' and
                    (response.http_status is None or response.http_status < 400)):
                try:
                    envelope = json.loads(response.body.decode('utf-8'),
                        object_pairs_hook=_json_pairs, parse_constant=_reject_constant)
                except (UnicodeError,ValueError,TypeError,RecursionError):
                    raise ReaderError('invalid_response') from None
                if not _platform_code(envelope):
                    continue
            if response.kind == 'comments':
                if len(self.comment_responses) >= 64:
                    raise ReaderError('invalid_response')
                self.comment_responses.append(response)
            elif response.kind == 'sub_comments':
                if len(self.sub_responses) >= 64:
                    raise ReaderError('invalid_response')
                self.sub_responses.append(response)
            else:
                self.controller.passive_response(response)
        if self.active['action'] == 'comments' and self.controller.phase != 'idle':
            self._comments()
        elif self.active['action'] == 'sub_comments' and self.controller.phase == 'identity_verified':
            while self.comment_responses and self.controller.phase == 'identity_verified':
                expected=self.controller.root_main_expected_cursor
                found=next((index for index,response in enumerate(self.comment_responses)
                    if parse_qs(urlsplit(response.url).query,keep_blank_values=True).get('cursor',[''])[0]==expected),None)
                if found is None:
                    break
                response=self.comment_responses.pop(found)
                self.controller.remember_main_roots(response)
                self._remember_root_evidence(response)
            self._consume_sub_responses()
        if self.controller.phase == 'idle':
            self.reader.finish_task(self.active['task_epoch'])
            self.active = None
            self.checkpoint = None
            self.comment_responses = []
            self.sub_responses = []
            return 'completed'
        if self.clock() >= self.deadline:
            if (self.active['action'] == 'search' and self.search_waiting and
                    self.controller.phase == 'identity_verified'):
                raise ReaderError('search_scroll_unavailable')
            raise ReaderError('timeout')
        if self.controller.phase == 'identity_verified' and self.clock() >= self.next_action:
            action = self.active['action']
            if action == 'search':
                self._search()
            elif action in ('comments', 'sub_comments'):
                if action == 'sub_comments':
                    self._sub_comments()
                else:
                    if (not self.active['params']['cursor'] or
                            self.controller.replay_expected_cursor == ''):
                        # The first page is loaded naturally by navigation.
                        # Scrolling before it settles can prefetch a later
                        # cursor outside this call and leave the next call at
                        # the bottom with nothing new to trigger.
                        return 'observing'
                    try:
                        self.reader.scroll_note_comments(self.active['params']['noteId'], **self._scope())
                    except ReaderError as error:
                        if error.code != 'comment_control_unavailable':
                            raise
                        # The natural note document can still be rendering.
                    finally:
                        facts = getattr(self.reader, 'last_comment_control', None)
                        if isinstance(facts, dict):
                            self._write_diagnostic('xhs-natural-comment-state', facts)
                    self.next_action = self.clock() + 1.5
        return 'observing'

    def failure(self, error):
        code = getattr(error, 'code', 'invalid_response')
        # Fixed source locations only: no exception message, source locals,
        # request/response body, URL, account identity or credentials.
        from pathlib import Path
        source_files = {'xhs_natural_window.py','owned_natural_reader.py',
                        'natural_page_controller.py','xhs_search_range.py'}
        frames = []
        trace = error.__traceback__
        while trace is not None:
            name = Path(trace.tb_frame.f_code.co_filename).name
            if name in source_files:
                frames.append({'source': name,'line': trace.tb_lineno,
                               'function': trace.tb_frame.f_code.co_name})
            trace = trace.tb_next
        self._write_diagnostic('xhs-natural-failure-state', {
            'phase': self.controller.phase if self.controller else 'unconnected',
            'raw_code': code if code in _FAILURES | set(('dom_unavailable','dom_invalid',
                'wanted_rows_invalid','search_snapshot_invalid')) else 'other',
            'frames': frames[-8:]})
        aliases = {'navigation_changed': 'document_changed', 'navigation_failed': 'document_changed',
                   'document_scope_invalid': 'document_changed',
                   'scroll_denied': 'comment_scroll_unavailable',
                   'comment_control_unavailable': 'comment_scroll_unavailable',
                   'dom_unavailable': 'invalid_response', 'dom_invalid': 'invalid_response',
                   'wanted_rows_invalid': 'invalid_response', 'search_snapshot_invalid': 'invalid_response'}
        code = aliases.get(code, code)
        if code not in _FAILURES:
            code = 'invalid_response'
        if self.active is not None and self.controller is not None:
            try:
                self.post(self.spec, '/failure', {
                    'session_token': self.controller.session_token,
                    'doc_epoch': self.controller.doc_epoch,
                    'call_id': self.active['call_id'], 'task_epoch': self.active['task_epoch'],
                    'code': code, 'network_attempted': self.network_attempted})
            except Exception:
                pass
        return code

    def run(self):
        try:
            self.connect()
            while not self.stopped:
                result = self.tick()
                if result in ('stopped', 'cancelled'):
                    return result
                self.closed.wait(0.2)
            return 'stopped'
        except (NaturalPageError, ReaderError, PageBridgeError, KeyError, ValueError) as error:
            code = self.failure(error)
            if code == 'verification_required':
                self.window.show()
                # Keep this owned verification page; the failed task has
                # already stopped. User review never automatically retries it.
                while not self.closed.is_set() and not self.spec.cancel_file.exists():
                    packet = self.post(self.spec, '/poll', {
                        'session_token': self.controller.session_token,
                        'doc_epoch': self.controller.doc_epoch})
                    if packet.get('action') == 'stop':
                        break
                    self.closed.wait(.4)
            return code
        finally:
            if self.controller is not None:
                self.controller.cancel()
            try:
                self.reader.close()
            finally:
                if self.window.events.shown.is_set():
                    self.window.destroy()


def run_natural_window(spec):
    if spec.purpose=='session_recovery':
        from assistant.xhs_session_window import run_session_recovery_window
        return run_session_recovery_window(spec)
    import webview
    window = webview.create_window('小红书连接', 'about:blank', width=820,
                                   height=730, js_api=None, focus=False)
    runner = NaturalWindowWorker(spec, window)
    outcome = {'code': 'closed'}
    def worker():
        if not window.events.shown.wait(15):
            outcome['code'] = 'window_failed'
            return
        try:
            window.hide()
            outcome['code'] = runner.run()
        except Exception as error:
            outcome['code'] = runner.failure(error)
            if window.events.shown.is_set():
                window.destroy()
    thread = Thread(target=worker, name='xhs-owned-natural-page', daemon=True)
    thread.start()
    try:
        webview.start(gui='edgechromium', private_mode=False,
                      storage_path=str(spec.profile_dir), debug=False)
    finally:
        runner.closed.set()
    thread.join(timeout=8)
    return outcome['code'] if not thread.is_alive() else 'helper_shutdown_timeout'
