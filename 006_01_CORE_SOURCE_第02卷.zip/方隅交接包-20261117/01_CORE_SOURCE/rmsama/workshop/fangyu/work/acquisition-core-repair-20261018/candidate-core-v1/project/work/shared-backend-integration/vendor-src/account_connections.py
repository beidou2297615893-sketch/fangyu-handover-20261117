"""Connection state machine; service running is never treated as authenticated."""
import json, secrets, subprocess, sys, threading, time, urllib.request, urllib.error
from pathlib import Path

def managed_window_argv(spec_path):
    executable=Path(sys.executable)
    if getattr(sys,'frozen',False):
        return [str(executable),'--managed-platform-window',str(spec_path)]
    if executable.name.lower()=='python.exe' and executable.with_name('pythonw.exe').exists():
        executable=executable.with_name('pythonw.exe')
    return [str(executable),str(Path(__FANGYU_SOURCE_ROOT__)/'managed_platform_window.py'),str(spec_path)]

IDENTITY_JS="""(async()=>{
  const fail=reason=>({authenticated:false,reason,uid:'',nickname:'',capable:false});
  if(location.hostname!=='www.douyin.com'||!window.__bridge||typeof window.__bridge._q!=='function')return fail('page_not_ready');
  const p=new URLSearchParams(window.__bridge._q());
  const r=await fetch('/aweme/v1/web/query/user/?'+p,{credentials:'include'});
  if(!r.ok)return fail('network');
  const d=await r.json();
  if(!d||typeof d!=='object'||d.status_code!==0)return fail('identity_status_unconfirmed');
  const numeric=value=>{
    if(typeof value==='number'){if(!Number.isSafeInteger(value))return '';value=String(value);}
    return typeof value==='string'&&/^[1-9][0-9]{4,159}$/.test(value)?value:'';
  };
  const u=d.user&&typeof d.user==='object'?d.user:{};
  const hasTop=Object.prototype.hasOwnProperty.call(d,'user_uid');
  const hasNested=Object.prototype.hasOwnProperty.call(u,'uid');
  const top=numeric(d.user_uid),nested=numeric(u.uid);
  if((hasTop&&!top)||(hasNested&&!nested))return fail('identity_uid_invalid');
  if(top&&nested&&top!==nested)return fail('identity_uid_conflict');
  const uid=top||nested;if(!uid)return fail('identity_uid_missing');
  const capable=typeof window.__bridge.getComments==='function';
  if(!capable)return fail('identity_capability_unconfirmed');
  return {authenticated:true,uid,nickname:typeof u.nickname==='string'?u.nickname:'',capable:true};
})()"""

def verify_douyin(manager, tenant, connection):
    config=json.loads((manager.root(tenant)/'config.json').read_text('utf-8'))['bridge']
    payload={'site':'douyin.com','expression':IDENTITY_JS,'awaitPromise':True,'connId':connection,'timeout':4500}
    req=urllib.request.Request('http://127.0.0.1:'+str(config['port'])+'/api/call',data=json.dumps(payload).encode(),headers={'Content-Type':'application/json','Authorization':'Bearer '+config['token']})
    try:
        with urllib.request.urlopen(req,timeout=6) as r:result=json.load(r)
    except urllib.error.HTTPError as exc:
        # Keep the bridge's actual reason; a live window is not proof of login.
        try:reason=str(json.loads(exc.read(4096).decode('utf-8')).get('error',''))[:240]
        except (ValueError,UnicodeError):reason='连接服务未返回可读取的原因'
        if exc.code==503:
            return {'authenticated':False,'uid':'','nickname':'','check_pending':True,'check_error':reason,'http_status':503}
        raise ValueError('登录状态检查失败（HTTP '+str(exc.code)+'）：'+reason) from exc
    if result.get('connection')!=connection:raise ValueError('窗口已变化，请重新选择登录窗口')
    if result.get('ok') is not True:raise ValueError('窗口暂未响应，请等待页面加载后重试')
    value=result.get('value') or {}
    return {'authenticated':value.get('authenticated') is True and value.get('capable') is True,'uid':value.get('uid',''),'nickname':value.get('nickname','')}

def _owned_check(manager,user,ident,call,*,io=False):
    if call is None:return
    from assistant.douyin_connection_service import _DouyinConnectionCall
    from assistant.owner_douyin_read import _OwnerDouyinConnectionCall
    if (type(call) not in (_DouyinConnectionCall,_OwnerDouyinConnectionCall) or call.manager is not manager
            or call.account_id!=ident or call.user_id!=user.get('id')):
        raise ValueError('current_scope_unavailable')
    call.before_io() if io else call.check()


class AccountConnections:
    def __init__(self, server):
        self.server=server;self.owned={};self.states={};self.locks={};self.cache={};self.identity_failures={}
    def persist(self, ident, **values):
        with self.server.core.lock:
            latest=self.server.core.store.get('accounts',ident)
            if latest is None:raise ValueError('账号已移除，请刷新账号列表')
            latest.update(values);self.server.core.store.put('accounts',latest)
            return latest
    def context(self, user, ident):return self.server.core.handle('account_browser_context',{'id':ident},user)
    def result(self,status,message,**extra):
        return {'status':status,'step':status,'message':message,'next_action':{'ready':'开始关键词采集','choose_window':'选择你已登录的窗口','waiting_login':'在打开的平台窗口完成登录','failed':'重试连接','disconnected':'重新连接','connected_unverified':'打开视频页面后检查连接'}.get(status,'请稍候'),**extra}
    def connect(self,user,ident,mode='auto',*,_owned_call=None):
        _owned_check(self,user,ident,_owned_call,io=True)
        context=self.context(user,ident);a=context['account'];tenant=context['tenant'];platform=a['platform']
        if platform not in ('douyin','kuaishou'):return self.result('unsupported','此平台请使用扫码登录入口。')
        manager=self.server.bridge_for(platform)
        if mode not in ('auto','new'):raise ValueError('未知连接方式')
        if mode=='auto':
            source=self.server.company.get('localCliPaths',{}).get('douyin') if platform=='douyin' else None
            proc=manager.processes.get(tenant)
            if source and Path(source).is_file() and not manager.external(tenant) and not (proc and proc.poll() is None):
                with self.server.core.lock:
                    if self.server.core.running or self.server.core.sequences:raise ValueError('请先停止采集，再切换账号连接')
                    try:manager.attach_existing(tenant,source,start_if_needed=True)
                    except ValueError as exc:
                        # Preserve the error; do not silently claim the original CLI attached.
                        self.states[ident]=self.result('failed',str(exc));self.persist(ident,status='unverified',connection_message=str(exc));raise
            try:
                state=self.status(user,ident,force=True)
                if state['status'] in ('ready','choose_window','waiting_login','connected_unverified'):return state
            except Exception:pass
        return self.open_owned(user,context,manager,_owned_call=_owned_call)
    def open_owned(self,user,context,manager,*,_owned_call=None):
        a=context['account'];tenant=context['tenant'];ident=a['id']
        existing=self.owned.get(ident)
        if existing and existing['process'].poll() is None:
            return self.status(user,ident,force=True,_owned_call=_owned_call)
        _owned_check(self,user,ident,_owned_call,io=True)
        if _owned_call is not None and manager.external(tenant):
            raise ValueError('owned_bridge_required')
        manager.start(tenant)
        _,script=manager.prepare(tenant)
        directory=self.server.core.store.directory/'accounts'/tenant/ident/'managed-window';directory.mkdir(parents=True,exist_ok=True)
        marker=secrets.token_hex(20)
        spec={'platform':a['platform'],'name':a['name'],'marker':marker,'config':str(manager.root(tenant)/'config.json'),'script':str(script),'profile':str(directory/'profile'),'state_path':str(directory/('state-'+marker+'.json'))}
        path=directory/'window.json';path.write_text(json.dumps(spec,ensure_ascii=False),'utf-8')
        _owned_check(self,user,ident,_owned_call,io=True)
        with (directory/'window.log').open('ab') as log:
            process=subprocess.Popen(managed_window_argv(path),stdout=log,stderr=log,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        self.owned[ident]={'process':process,'marker':marker,'opened_at':time.time(),'state_path':spec['state_path']}
        if _owned_call is not None:_owned_call.register_owned(self.owned[ident])
        with self.server.core.lock:
            _owned_check(self,user,ident,_owned_call)
            self.persist(ident,status='logging_in',conn_id='')
        state=self.result('waiting_login','已打开'+('抖音' if a['platform']=='douyin' else '快手')+'登录窗口。直接登录即可，软件会自动检查，无需安装脚本。',candidates=[])
        self.states[ident]=state
        with self.server.core.lock:
            _owned_check(self,user,ident,_owned_call)
            self.persist(ident,connection_message=state['message'])
        return state
    def status(self,user,ident,force=False,*,_owned_call=None):
        _owned_check(self,user,ident,_owned_call,io=True)
        context=self.context(user,ident);a=context['account'];tenant=context['tenant'];core=self.server.core
        if a['platform'] not in ('douyin','kuaishou'):return self.result('unsupported','请使用扫码登录。')
        lock=self.locks.setdefault(ident,threading.Lock())
        if not lock.acquire(False):
            if _owned_call is not None:return self.result('checking','正在检查登录状态，请稍候。')
            return self.states.get(ident,self.result('checking','正在检查登录状态，请稍候。'))
        try:
            if not force and ident in self.cache and time.monotonic()-self.cache[ident]<4:return self.states[ident]
            manager=self.server.bridge_for(a['platform']);owned=self.owned.get(ident)
            if owned and owned['process'].poll() is not None:
                code=owned['process'].poll()
                if code!=0:
                    state=self.result('failed',f'登录窗口启动或运行失败（退出码 {code}）。不是账号未登录；请更新软件或查看登录窗口日志。',candidates=[],error_code='LOGIN_WINDOW_PROCESS_FAILED')
                else:
                    state=self.result('disconnected','登录窗口已关闭。点击重新连接可以再次打开，已保存的登录资料仍保留。',candidates=[])
            else:
                items=manager.connections(tenant)
                assigned={x.get('conn_id') for x in core.handle('list',{'entity':'accounts'},user) if x['id']!=ident and x['platform']==a['platform']}
                items=[x for x in items if x.get('alive') and x.get('id') not in assigned]
                if owned:
                    items=[x for x in items if '#workbench-account='+owned['marker'] in x.get('url','')]
                    state_path=Path(owned['state_path']) if owned.get('state_path') else None
                    if state_path and state_path.is_file():
                        current_id=json.loads(state_path.read_text('utf-8')).get('conn_id')
                        items=[x for x in items if x['id']==current_id]
                bound=next((x for x in items if x['id']==a.get('conn_id')),None)
                if not bound and owned and len(items)==1:
                    bound=items[0]
                    if _owned_call is None:
                        a=core.handle('save',{'entity':'accounts','record':{**a,'conn_id':bound['id'],'status':'unverified'}},user)
                    else:
                        # Keep the candidate conn_id local until the guarded
                        # original final write; revocation during GET saves none.
                        a={**a,'conn_id':bound['id'],'status':'unverified'}
                if bound:
                    if a['platform']=='douyin':
                        if _owned_call is not None:
                            _owned_call.owned_connection(items,a)
                        _owned_check(self,user,ident,_owned_call,io=True)
                        identity=verify_douyin(manager,tenant,bound['id'])
                        _owned_check(self,user,ident,_owned_call,io=True)
                        old_uid=a.get('platform_uid')
                        self.identity_failures[ident]=(self.identity_failures.get(ident,0)+1) if identity.get('check_pending') else 0
                        if identity.get('check_pending'):
                            state=self.result('failed' if self.identity_failures[ident]>=3 else 'checking','窗口仍打开，但多次检查未成功。请等待页面加载、检查网络后重试。' if self.identity_failures[ident]>=3 else '登录窗口仍打开，登录状态检查暂未完成。请等待页面加载后再次检查。',candidates=items,check_error=identity['check_error'],http_status=identity['http_status'],check_attempts=self.identity_failures[ident])
                        elif identity['authenticated'] and old_uid and old_uid!=identity['uid']:
                            state=self.result('failed','此窗口登录的账号已改变。请为新身份添加账号，避免把消息发到错误账号。',identity=identity,candidates=items)
                        elif identity['authenticated']:
                            if _owned_call is not None:_owned_call.admit_identity(identity)
                            a['platform_uid']=identity['uid'];a['platform_nickname']=identity['nickname']
                            state=self.result('ready','已登录'+(identity['nickname'] or '抖音账号')+'，可以开始关键词采集。',identity=identity,candidates=items)
                        else:state=self.result('waiting_login','连接正常，但尚未确认登录。请在抖音窗口完成扫码或手机验证。',candidates=items)
                    else:state=self.result('connected_unverified','快手窗口已连接；当前组件尚不能自动核实登录身份。打开目标视频后可尝试读取评论。',candidates=items)
                elif items:state=self.result('choose_window','发现可用窗口，请选择你要使用的账号窗口。',candidates=items)
                elif owned and time.time()-owned['opened_at']>45:state=self.result('failed','登录窗口已打开，但页面尚未连通。请检查网络并等待平台首页加载，再点击检查连接；无需安装脚本。',candidates=[])
                elif owned:state=self.result('waiting_login','请在打开的平台窗口登录。页面加载后将自动识别；无需安装或下载脚本。',candidates=[])
                else:state=self.result('disconnected','尚未发现已连接窗口。点击连接账号，软件会打开独立登录窗口。',candidates=[])
            a['status']='ready' if state['status']=='ready' else ('logging_in' if state['status']=='waiting_login' else 'unverified')
            with core.lock:
                _owned_check(self,user,ident,_owned_call)
                fields=('platform_uid','platform_nickname','conn_id') if _owned_call is not None else ('platform_uid','platform_nickname')
                self.persist(ident,status=a['status'],connection_message=state['message'],**{k:a[k] for k in fields if k in a})
                self.states[ident]=state;self.cache[ident]=time.monotonic();return state
        except Exception as exc:
            if _owned_call is not None:
                # No fallback write may turn a rejected/revoked call into a
                # new connection binding, nor hide an uncertain committed write.
                raise
            state=self.result('failed','检查未成功：'+str(exc),candidates=[]);self.states[ident]=state;self.persist(ident,status='unverified',connection_message=state['message']);return state
        finally:lock.release()
    def release_account(self, ident):
        item=self.owned.pop(ident,None)
        if item:
            process=item['process']
            if process.poll() is None:
                process.terminate()
                try:process.wait(timeout=3)
                except subprocess.TimeoutExpired:process.kill();process.wait(timeout=3)
        for mapping in (self.states,self.cache,self.identity_failures):mapping.pop(ident,None)
        # Keep the lock object so in-flight readers cannot create a parallel lock.

    def close(self):
        for item in self.owned.values():
            p=item['process']
            if p.poll() is None:
                p.terminate()
                try:p.wait(timeout=3)
                except subprocess.TimeoutExpired:p.kill()
