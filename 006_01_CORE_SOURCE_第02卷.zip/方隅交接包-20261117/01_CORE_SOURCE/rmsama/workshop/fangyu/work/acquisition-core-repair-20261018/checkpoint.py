from pathlib import Path
import datetime,json,hashlib
W=Path(__file__).resolve().parent;P=W.parents[1];H=P/'work/overnight-integration/continuation-20261018'
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n','utf-8')
before=W/'before-checkpoint';before.mkdir(exist_ok=True)
for name in ('NEXT.md','BATCH-RESULT.json'):
 p=before/name
 if not p.exists():p.write_bytes((H/name).read_bytes())
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
progress={'status':'ACTIVE_CORE_ACQUISITION_REPAIR','at_utc':now,
 'scope':'Latest human: continuous collection first; synchronous AI/keyword filtering, real images, then navigation and visible rules',
 'work':'work/acquisition-core-repair-20261018','root_single_product_writer':True,
 'parallel_readonly_audits':'audits/PAUSE-AUDIT.md; INTENT-FILTER-AUDIT.md; MEDIA-NAV-AUDIT.md',
 'continuous_controller':'7 focused cases GREEN including 1200 synthetic reads, >60s, advancing duplicate-only pages; not real platform acceptance',
 'intent_projection':'5 focused cases GREEN: no saved apply gate, current excludes, prospect audience, rule provenance',
 'media_navigation':'12 Python+8 Node focused RED, product implementation pending',
 'synchronous_ai':'7 focused RED, helper implementation pending; no paid call',
 'not_done':['real Core/adapter continuous integration and error reason surfacing','AI sync helper + per-page fixed IDs wiring','media same-origin proxy/DTO','stable five-item navigation + rules/permission views','changed-scope UI acceptance and independent review','new complete closure / entry installation; active old closure must stay unchanged'],
 'original_task_observation':'OWNED-TASK-SUMMARY.json: latest paused with verification-related message; limit100/added0; older last_batch20 all date-filtered, not20 new and not proven same attempt',
 'deadline_asia_shanghai':'2026-10-18 21:36:54','quota_remaining_percent':89,
 'automation_12':'app API not_found previously; no replacement created',
 'real_platform_requests':0,'paid_provider_requests':0,'original_client_closed':False}
write(W/'PROGRESS.json',progress)
next_text='''# 当前第一优先级：修好连续获客与同步意向分析（本人最新要求覆盖旧“无必要改动”）

W=C:/积木软件工坊/项目/方隅公寓客户版/work/acquisition-core-repair-20261018。先读W/PROGRESS.json、PLAN.md和命名短证据，不读29.7MB聊天/图片编码。此前员工简单流程已交付，但本人现报告核心采集/意向/头像/导航问题，继续本轮，不能把前轮成功当本轮已修。

root单一产品作者；本人已允许并行，三个只读代理已完成audits并仅写W内focused tests，无产品并发编辑。已备份12源码到W/before。Runtime正在canonical源码增量修：取消10页/60秒/3个无新增的人为终止，每页确认后本地assessment再读下一页；7新控制测试GREEN（1200合成评论），不是真平台连续验收。gateway当前词库excludes传递、去掉读分级/计数的saved-applied门槛、prospect audience和规则来源字段5新用例GREEN。

待继续：同步AI helper _analyze_collection_page（7 RED，使用现有executor.ai.cloud/analyze、AI attempts、按本页固定IDs/帖子每组≤20，不开启旧后台pilot），真实Core分页集成；同源固定kind媒体路由（12 Python RED）及头像/cover精确来源；导航五入口稳定（8 Node 3PASS/5RED）；管理显示真实词/排除/意向标准/来源/保存内容与原角色权限。已有UI与旧服务/安全媒体模块优先复用，不重做整套页面，不扩云权限。付费AI只恢复产品正常显式开始的已有配置链路，agent验收不实际付费；不导出密钥，不虚构cloud no-dispatch证明。

原真实任务短摘要W/OWNED-TASK-SUMMARY.json：最新limit100/target100/新增0，当前验证相关错误暂停；last_batch20全date筛除是保留批次，不能说20新增或已证HTTP461/本人手动暂停。保留真正平台验证/UID/lease/license/未确认journal，不自动重放被拒请求；软件人为批次截止与真实平台拒绝分开。小红书原跨CLI每次请求已有正常约1秒节奏，不能复活前轮已取消固定40秒；抖音读节奏不同，不能泛称相同或紧密无限循环。

活动原入口仍为employee-simple-flow/candidate-v3/project / release ui-r57-20261018T004632Z-6ebe453b；保留原state/resolver/设备/数据/company、90a/旧CLI/旧v3及所有完整活动依赖。不要直接修改活动冻结载体、伪造pins、清临时目录。新本轮还未固化/安装；不要声称原客户端已用本轮新代码。原窗口未关闭，不操作真实登录/采集/外发；缺认证记录SKIPPED继续独立工作，不问不找密码不代扫码/验证码。只验本轮变化及受影响链路，不重复旧无关GUI/导出/CLI上游查询。

截止仍2026-10-18 21:36:54 Asia/Shanghai，先查顶层暂停/全部适用Codex额度/准确时间；最近周窗剩89%，secondary未知不重测。已知窗<=1%保存断点并暂停本任务，等本人重置且明确继续；不兑换reset。automation-12应用API曾返回不存在，无有效续行保证，不新建替代/换路径工具绕过。总控合并也曾自动审批拒绝无理由，不重试，只保存本轮独立证据。不归档、不关闭真实客户端；禁付费验收/真实发送/其他客户聊天/扩大设备角色cloud权限。
'''
(H/'NEXT.md').write_text(next_text,'utf-8')
b=json.loads((H/'BATCH-RESULT.json').read_text('utf-8-sig'))
b.update(status=progress['status'],checkpoint_at_utc=now,current_requirement=progress['scope'],new_requirement_work=progress['work'],core_repair=progress)
write(H/'BATCH-RESULT.json',b)
(H/'IN-FLIGHT.md').write_text('ACTIVE核心获客修复；W/PROGRESS.json为本轮阶段。不要按前轮已交付停止工作。见NEXT。\n','utf-8')
hp=json.loads((H/'UNIFIED-CHECKPOINT-PINS.json').read_text('utf-8-sig'))
for name in ('NEXT.md','BATCH-RESULT.json','IN-FLIGHT.md'):hp[name]=hashlib.sha256((H/name).read_bytes()).hexdigest()
write(H/'UNIFIED-CHECKPOINT-PINS.json',hp)
print('Saved current authorized core repair priority and exact partial progress.')
