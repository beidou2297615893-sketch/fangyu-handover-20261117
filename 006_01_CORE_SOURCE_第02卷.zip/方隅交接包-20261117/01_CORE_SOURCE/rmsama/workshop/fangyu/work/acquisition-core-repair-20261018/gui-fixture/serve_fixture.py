"""Synthetic 1000-row GUI fixture over real captured host/backend/UI.

This file is QA infrastructure, not product code. 1000 rows are pre-seeded
visualization data, not another platform/AI integration execution. Only root
starts the launcher/ports and reviews the browser. No real platform/CLI/AI IO.
"""
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import sys
from urllib.parse import urlsplit

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[2]
_path = HERE / 'base_fixture.py'
_spec = importlib.util.spec_from_file_location('core_repair_previous_fixture', _path)
_base = importlib.util.module_from_spec(_spec)
sys.modules[_spec.name] = _base
_spec.loader.exec_module(_base)
PASSWORD, COMPANY, digest, load = _base.PASSWORD, _base.COMPANY, _base.digest, _base.load
MEDIA = {}
MEDIA_FETCHES = []
SEED_EVIDENCE = {}


def offline_guard(owned, release, public_roots):
    _base.HERE, _base.PROJECT = HERE, PROJECT
    return _base.offline_guard(owned, release, public_roots)


class CloudStandin(_base.CloudStandin):
    def __call__(self, url, data, token=''):
        operation = data['operation']
        if operation not in ('ai_profile', 'intent_analyze'):
            return super().__call__(url, data, token)
        if token not in self.sessions:
            from integrations import IntegrationError
            error = IntegrationError('隔离会话已失效')
            error.http_status = 401
            raise error
        self.calls.append(operation)
        result = {'contract': 'fangyu-workspace-v1', 'company_id': COMPANY,
                  'environment_id': 'overnight-fixture'}
        if operation == 'ai_profile':
            return {**result, 'config': {'enabled': True, 'configured': True,
                    'provider': 'deepseek', 'model': 'synthetic-deepseek-contract',
                    'revision': 1, 'rules_version': 'synthetic-gui-v1'}}
        # This optional callback is synthetic, not a live provider or billing adapter.
        if not 1 <= len(data.get('comments', [])) <= 20:
            raise ValueError('Synthetic GUI callback group is out of range')
        return {**result, 'rules_version': 'synthetic-gui-v1', 'results': [
            {'id': row['id'], 'status': 'graded', 'level': 'high',
             'reason': '隔离合成输出，未调用模型', 'evidence': ['预算人民币4000元/月'],
             'region_status': 'unknown', 'content_region': '', 'key_info': []}
            for row in data['comments']]}


class PlatformStandin(_base.PlatformStandin):
    def __init__(self, *args, **kwargs):
        _base.PROJECT = PROJECT
        super().__init__(*args, **kwargs)

    def snapshot(self, user):
        value = super().snapshot(user)
        task = value.get('acquisition', {}).get('taskId')
        if task and task.startswith('synthetic-gui1000-'):
            value['acquisition'].update(canStart=False, canPause=False, canResume=False,
                message='隔离预置1000条已完成结果；仅界面验收，未重新运行采集或模型')
        return value

    def start_acquisition(self, user, data):
        error = ValueError('本夹具仅展示预置合成结果，不重跑1000条采集')
        error.code, error.status = 'FIXTURE_READ_ONLY', 409
        raise error


def customer_factory(parent, owned):
    """Keep the real media route/ownership checks; replace only exact image IO."""
    from PIL import Image, ImageDraw
    palette = [(57, 128, 143), (174, 96, 89), (114, 109, 164),
               (190, 135, 59), (74, 135, 91), (109, 122, 147)]
    folder = owned / 'synthetic-media'
    folder.mkdir()
    for index, color in enumerate(palette):
        picture = Image.new('RGB', (256, 256), (232, 238, 235))
        draw = ImageDraw.Draw(picture)
        draw.ellipse((37, 143, 219, 338), fill=color)
        draw.ellipse((70, 29, 187, 164), fill=(235, 187, 150))
        draw.pieslice((66, 18, 191, 134), 175, 355, fill=(49 + index*9, 42, 39))
        draw.ellipse((97, 91, 105, 99), fill=(38, 37, 35))
        draw.ellipse((151, 91, 159, 99), fill=(38, 37, 35))
        draw.arc((109, 110, 148, 139), 0, 180, fill=(130, 67, 58), width=3)
        stream = io.BytesIO()
        picture.save(stream, 'PNG')
        MEDIA[f'/avatar-{index}.png'] = stream.getvalue()
    for index in range(3):
        picture = Image.new('RGB', (720, 440), (239, 231-index*5, 215))
        draw = ImageDraw.Draw(picture)
        draw.rectangle((0, 307, 720, 440), fill=(161, 125, 91))
        draw.rectangle((70, 50, 340, 260), fill=(111, 151, 167))
        draw.rectangle((194, 50, 205, 260), fill=(244, 241, 226))
        draw.rectangle((70, 148, 340, 160), fill=(244, 241, 226))
        draw.rounded_rectangle((361, 215, 684, 355), radius=18, fill=palette[index])
        draw.rounded_rectangle((350, 265, 698, 372), radius=15, fill=palette[index+2])
        draw.ellipse((80, 329, 319, 407), fill=(211, 193, 157))
        draw.rectangle((110, 285, 280, 310), fill=(101, 80, 61))
        draw.rectangle((130, 310, 141, 361), fill=(101, 80, 61))
        draw.rectangle((251, 310, 262, 361), fill=(101, 80, 61))
        stream = io.BytesIO()
        picture.save(stream, 'PNG')
        MEDIA[f'/cover-{index}.png'] = stream.getvalue()
    for name, body in MEDIA.items():
        (folder / name.lstrip('/')).write_bytes(body)
    (owned / 'MEDIA-REGISTRY.json').write_text(json.dumps({
        'synthetic': True, 'photos_of_real_people': False, 'fetch_scope': 'exact local registry only',
        'images': {name: hashlib.sha256(body).hexdigest() for name, body in MEDIA.items()}},
        ensure_ascii=False, indent=2), 'utf-8')

    def safe_fetch(parsed, hostname):
        if (parsed.scheme != 'https' or parsed.netloc != 'fixture.xhscdn.com'
                or hostname != 'fixture.xhscdn.com' or parsed.query or parsed.fragment
                or parsed.path not in MEDIA):
            raise ValueError('Synthetic media registry rejects arbitrary URL')
        MEDIA_FETCHES.append(parsed.path)
        return MEDIA[parsed.path], 'image/png'

    class SyntheticMediaBoundary(parent):
        def media(self, user, store_id, lead_id, kind, fetcher=None):
            if fetcher is not None:
                raise ValueError('External media injection is not permitted')
            return super().media(user, store_id, lead_id, kind, fetcher=safe_fetch)
    return SyntheticMediaBoundary


def seed(backend, cloud):
    """Precomputed fake AI for GUI only; actual Core import + rules/projections."""
    name = 'fixture-operator'
    boot = backend.dispatch('login', {'username': name, 'password': PASSWORD})
    token, store = boot['token'], cloud.first_store
    if boot['selection']['storeId'] != store:
        boot = backend.dispatch('select_store', {'storeId': store,
                    'expectedRevision': boot['selection']['revision']}, token)
    user, _ = backend._identity(token)
    user = {**user, '_workbench_store_id': store}
    platform = backend.platform_runtime
    platform.prepared.add(name)
    account = platform.account(user)
    account.update(status='ready', store_id=store,
                   message='隔离模拟已登录；未访问真实账号')
    backend.core.store.put('accounts', account)
    ident = 'synthetic-gui1000-' + name
    now = datetime.now(timezone.utc).isoformat()
    task = {'id': ident, 'tenant_id': user['tenant_id'], 'cloud_owner': name, 'store_id': store,
            'account_id': account['id'], 'platform': 'xiaohongshu', 'scope': 'search_comments',
            'city': '上海', 'area': '古北', 'keywords': ['古北租房'], 'comment_keyword_mode': 'all',
            'continuous_enabled': False, 'unknown_policy': 'exclude', 'region': '',
            'daily_limit': 1000, 'target_count': 1000, 'accumulated': 1000,
            'status': 'completed', 'created_at': now, 'exhausted': True, 'fixtureOffset': 1000,
            'fixtureCounts': {'read': 1000, 'added': 1000, 'analyzed': 1000, 'duplicates': 0},
            'fixtureScope': {'storeId': store, 'platform': 'xiaohongshu', 'accountId': account['id'],
                             'scope': 'search_comments', 'keywords': ['古北租房'],
                             'dailyLimit': 1000, 'targetCount': 1000}}
    backend.core.store.put('tasks', task)
    rows = []
    for index in range(1000):
        supply = index >= 900
        text = ('我是中介，古北有房源出租，提供带看与租赁服务，欢迎咨询。' if supply else
                '我自己想租古北一居室，预算人民币4000元/月，明天下午3点能看房吗？')
        text += ('这是一条用于界面验收的合成完整评论，不是真实客户。希望核对原帖、评论与头像是否属于同一条来源。'
                 '完整内容应该保留并可在右侧阅读，不能只显示列表截断摘要。') * 3
        text += f'【完整评论尾标 SYNTHETIC-{index:04d}】'
        rows.append({'platform': 'xiaohongshu', 'source_type': 'comment',
            'source_id': f'{ident}-{index:04d}', 'comment_id': f'synthetic-comment-{index:04d}',
            'author_id': f'synthetic-person-{index:04d}',
            'author': ('隔离供给方' if supply else '隔离租客') + f' {index:04d}',
            'task_id': ident, 'text': text, 'published_at': now,
            'content_title': '隔离原帖 · 古北一居室与通勤讨论 ' + str(index % 3),
            'content_author': '隔离房源讨论作者', 'content_author_id': 'synthetic-post-owner',
            'note_url': 'https://www.xiaohongshu.com/explore/' + ('a' * 23) + str(index % 3),
            'author_avatar_url': f'https://fixture.xhscdn.com/avatar-{index%6}.png',
            'content_author_avatar_url': 'https://fixture.xhscdn.com/avatar-5.png',
            'content_cover_url': f'https://fixture.xhscdn.com/cover-{index%3}.png'})
    imported = backend.core._import(rows, user['tenant_id'], user)
    if imported['imported'] != 1000:
        raise ValueError('Synthetic GUI seed count mismatch')
    # Bulk persist explicit synthetic outputs, without rerunning the 1000-item AI test.
    with backend.core.lock, backend.core.store.connect() as db:
        for row in backend.core.store.list('leads', user['tenant_id']):
            if row.get('task_id') != ident:
                continue
            supply = row['author'].startswith('隔离供给方')
            row['ai_intent'] = {'status': 'unrelated' if supply else 'graded',
                'level': None if supply else 'high', 'reason': '合成预置结果；未调用模型',
                'evidence': [], 'key_info': [], 'region_status': 'unknown',
                'provider': 'synthetic_fixture', 'model': 'precomputed_gui_seed',
                'rules_version': 'synthetic-gui-v1', 'analyzed_at': now}
            row['analysis_status'] = row['ai_intent']['status']
            db.execute('UPDATE records SET body=? WHERE entity=? AND id=? AND tenant_id=?',
                (json.dumps(row, ensure_ascii=False), 'leads', row['id'], user['tenant_id']))
    # Exact persisted source/assessment logic stays real; this is not provider execution.
    policy = backend._assessment_policy(store)
    assessment = backend._assessment_for(user, store).assess_task(user, ident)
    summary = backend.customer_workbench.acquisition_summary(user, store, ident)
    all_customers = backend.customer_workbench.list(user, store, {'pageSize': 20})
    prospects = backend.customer_workbench.list(user, store, {'pageSize': 20, 'audience': 'prospects'})
    if summary['analyzed'] != 1000 or all_customers['total'] != 1000:
        raise ValueError('Actual current customer projection disagrees with synthetic seed')
    if any(row['name'].startswith('隔离供给方') for row in prospects['items']):
        raise ValueError('Actual prospect projection retained a synthetic supplier')
    SEED_EVIDENCE.update(synthetic=True, seed_mode='precomputed fake outputs; AI integration not rerun',
        taskId=ident, storeId=store, imported=imported['imported'], analyzed=summary['analyzed'],
        customers=all_customers['total'], prospects=prospects['total'], suppliers=100,
        rules={'engine': policy.get('engineVersion'), 'sourceDigest': policy.get('sourceDigest'),
               'calibrated': False, 'exclusionTerms': cloud.configs[store].get('runtimeSearch', {}).get('excludeTerms', [])},
        actual_local_assessment=assessment, real_platform_calls=0, real_provider_calls=0,
        paid_ai_requested=False, media_fetches=len(MEDIA_FETCHES))
    owned = platform.fixture_owned
    (owned / 'SYNTHETIC-SEED-EVIDENCE.json').write_text(
        json.dumps(SEED_EVIDENCE, ensure_ascii=False, indent=2), 'utf-8')
    backend.dispatch('logout', {}, token)
    return deepcopy(SEED_EVIDENCE)


def install_verification_page(host):
    """Authenticated QA evidence only; product API/media handlers stay inherited."""
    original = host.StaticHandler

    class EvidenceHandler(original):
        def do_GET(self):
            parsed = urlsplit(self.path)
            if parsed.path != '/fixture/evidence':
                return super().do_GET()
            try:
                origin = 'http://127.0.0.1:' + str(self.server.server_port)
                if (parsed.scheme or parsed.netloc or parsed.query
                        or self.headers.get('Host') != origin[7:] or self.headers.get('Upgrade')):
                    return self.reject()
                user, profile = self.server.backend._identity(self.session_token())
                self.server.backend._selected_store(user, profile)
                if user['username'] not in ('fixture-admin', 'fixture-operator'):
                    return self.reject()
                return self.api_response(200, {'ok': True, **deepcopy(SEED_EVIDENCE),
                    'media_fetch_count': len(MEDIA_FETCHES),
                    'media_paths': sorted(set(MEDIA_FETCHES)),
                    'gui_reviewed_by_fixture': False, 'instanceId': self.server.runtime.instance_id})
            except Exception as error:
                return self.api_response(getattr(error, 'status', 403), {
                    'ok': False, 'error': {'code': 'FIXTURE_EVIDENCE_FORBIDDEN',
                                          'message': '隔离证据需要当前本地合成账号'}})
    host.StaticHandler = EvidenceHandler
