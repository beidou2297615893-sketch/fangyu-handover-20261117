"""Reconcile only final handoff observations; never mutates product or real data."""
import hashlib
import json
from pathlib import Path

project = Path(__file__).resolve().parents[2]
work = Path(__file__).resolve().parent
handoff = project / 'work/overnight-integration/continuation-20261018'
batch_path = handoff / 'BATCH-RESULT.json'
batch = json.loads(batch_path.read_text(encoding='utf-8-sig'))
native = json.loads((work / 'NATIVE-RESULT.json').read_text(encoding='utf-8-sig'))
for name in ('last_native_observation', 'current_native_observation'):
    old = batch.get(name)
    if old and old != native:
        batch['historical_' + name + '_before_core_repair'] = old
    batch[name] = native
batch['current_native_liveness'] = 'PID62880/window5772776 restored once from installed original entry after prior processes absent; last observed employee login only; client left open'
batch['quota_last_known_remaining_percent'] = 84
batch['new_requirement'] = 'Latest human priorities: continuous acquisition, synchronous intent grading, relevant prospects, saved media, peer navigation and visible rules; remote update deployment deferred.'
batch['remaining'] = batch['core_repair']['remaining']
batch_path.write_text(json.dumps(batch, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
next_path = handoff / 'NEXT.md'
text = next_path.read_text(encoding='utf-8-sig')
text = text.replace('原state/resolver/设备/数据/company不变，无业务迁移。', '保留原state/resolver/设备与既有数据，未做业务迁移；不声称真实DB字节相等，company哈希未变。')
next_path.write_text(text, encoding='utf-8')
pins_path = handoff / 'UNIFIED-CHECKPOINT-PINS.json'
pins = json.loads(pins_path.read_text(encoding='utf-8-sig'))
for name in ('BATCH-RESULT.json', 'NEXT.md'):
    pins[name] = hashlib.sha256((handoff / name).read_bytes()).hexdigest()
pins_path.write_text(json.dumps(pins, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'status': 'PASS_HANDOFF_ONLY', 'native_observations_match': batch['current_native_observation'] == native == batch['last_native_observation'], 'pins_updated': ['BATCH-RESULT.json', 'NEXT.md']}, ensure_ascii=False))
