/* Fixed official origins, no redirects, no raw provider errors in responses/logs. */
const {MODELS, OPENAI_MODELS} = require('./ai_contract.cjs');
class ProviderError extends Error {
  constructor(code, {knownUnbilled = false, retryable = false, httpStatus = 0} = {}) {
    super(code); this.code = code; this.knownUnbilled = knownUnbilled; this.retryable = retryable; this.httpStatus = httpStatus;
  }
}
async function readJsonBounded(response, maxBytes) {
  if (!response.body?.getReader) return response.json(); // Minimal test transports.
  const reader = response.body.getReader(); let bytes = 0, pieces = [];
  while (true) {
    const part = await reader.read();
    if (part.done) break;
    bytes += part.value.byteLength;
    if (bytes > maxBytes) { await reader.cancel(); throw new ProviderError('AI_PROVIDER_BODY_TOO_LARGE'); }
    pieces.push(Buffer.from(part.value));
  }
  try { return JSON.parse(Buffer.concat(pieces).toString('utf8')); }
  catch { throw new ProviderError('AI_PROVIDER_INVALID_RESPONSE'); }
}
const CONNECTIVITY_CAUSES = new Set(['ENOTFOUND', 'EAI_AGAIN', 'ETIMEDOUT', 'ECONNREFUSED',
  'ECONNRESET', 'ENETUNREACH', 'EHOSTUNREACH', 'UND_ERR_CONNECT_TIMEOUT',
  'CERT_HAS_EXPIRED', 'UNABLE_TO_VERIFY_LEAF_SIGNATURE']);
async function discardProbeBody(response) {
  if (!response?.body?.getReader) return false;
  const reader = response.body.getReader(); let bytes = 0;
  try {
    while (true) {
      const part = await reader.read();
      if (part.done) return false;
      bytes += part.value?.byteLength || 0;
      if (bytes > 1024) {
        try { await reader.cancel(); } catch {}
        return true;
      }
    }
  } finally { try { reader.releaseLock(); } catch {} }
}
function createProvider({fetchImpl = globalThis.fetch, timeoutMs = 45000, connectivityTimeoutMs = 5000} = {}) {
  const complete = async function complete({provider = 'deepseek', apiKey, model, reasoningEffort, messages, maxTokens, tenantId, timeoutMs: remainingTimeoutMs}) {
    if (!['openai', 'deepseek'].includes(provider)) throw new ProviderError('AI_PROVIDER_REJECTED', {knownUnbilled: true});
    if (!model || !(provider === 'openai' ? Object.hasOwn(OPENAI_MODELS, model) : Object.hasOwn(MODELS, model)))
      throw new ProviderError('AI_PROVIDER_REJECTED', {knownUnbilled: true});
    if (provider === 'openai' && model && !OPENAI_MODELS[model].efforts.includes(reasoningEffort))
      throw new ProviderError('AI_PROVIDER_REJECTED', {knownUnbilled: true});
    const requestTimeout = Math.floor(Math.min(timeoutMs, remainingTimeoutMs === undefined ? timeoutMs : remainingTimeoutMs));
    if (!Number.isFinite(requestTimeout) || requestTimeout <= 0) {
      throw new ProviderError('AI_PROVIDER_TIMEOUT', {knownUnbilled: true});
    }
    const abort = new AbortController(), timer = setTimeout(() => abort.abort(), requestTimeout);
    try {
      const body = provider === 'openai'
        ? {model, messages, max_completion_tokens: maxTokens, reasoning_effort: reasoningEffort, service_tier: 'default',
            ...(model === 'gpt-6.1-sol' ? {prompt_cache_options: {mode: 'explicit'}} : {}), stream: false,
            response_format: {type: 'json_object'}, user: tenantId}
        : {model, messages, max_tokens: maxTokens, temperature: 0.1, stream: false,
            thinking: {type: 'disabled'}, response_format: {type: 'json_object'}, user_id: tenantId};
      const response = await fetchImpl(provider === 'openai' ? 'https://api.openai.com/v1/chat/completions' : 'https://api.deepseek.com/chat/completions', {
        method: 'POST', redirect: 'error', signal: abort.signal,
        headers: {'Content-Type': 'application/json', Authorization: `Bearer ${apiKey}`},
        body: JSON.stringify(body)
      });
      if (!response.ok) {
        const status = response.status;
        if (status === 402) throw new ProviderError('AI_PROVIDER_BALANCE', {httpStatus: status, knownUnbilled: true, retryable: false});
        if (status === 401) throw new ProviderError('AI_PROVIDER_AUTH', {httpStatus: status, knownUnbilled: true, retryable: false});
        if (provider === 'openai' && status === 429) {
          // A 429 may be rate-limiting or insufficient_quota. Never replay a paid request automatically.
          let quota = false;
          try { quota = (await readJsonBounded(response, 8192))?.error?.code === 'insufficient_quota'; } catch {}
          if (quota) throw new ProviderError('AI_PROVIDER_BALANCE', {httpStatus: status, knownUnbilled: true, retryable: false});
          throw new ProviderError('AI_PROVIDER_REJECTED', {httpStatus: status, knownUnbilled: true, retryable: false});
        }
        throw new ProviderError('AI_PROVIDER_REJECTED', {httpStatus: status,
          knownUnbilled: [400, 401, 402, 403, 404, 422, 429].includes(status), retryable: status === 429});
      }
      // Stream the HTTP body with a hard bound; corrupted/overlarge replies have unknown usage.
      return await readJsonBounded(response, 1000000);
    } catch (error) {
      if (error instanceof ProviderError) throw error;
      throw new ProviderError(abort.signal.aborted ? 'AI_PROVIDER_TIMEOUT' : 'AI_PROVIDER_UNAVAILABLE');
    } finally { clearTimeout(timer); }
  };
  complete.checkConnectivity = async function checkConnectivity() {
    const abort = new AbortController();
    const budget = Number.isFinite(connectivityTimeoutMs) && connectivityTimeoutMs > 0
      ? Math.min(5000, Math.floor(connectivityTimeoutMs)) : 5000;
    let timer;
    const timeoutResult = {reachability:'timeout', http_status:0, error:{cause:{code:'TIMEOUT'}}};
    const deadline = new Promise(resolve => {
      timer = setTimeout(() => { abort.abort(); resolve(timeoutResult); }, budget);
    });
    const request = (async () => {
      try {
        const response = await fetchImpl('https://api.openai.com/v1/models', {
          method:'GET', redirect:'error', signal:abort.signal,
          headers:{Accept:'application/json'}
        });
        const status = Number.isInteger(response?.status) && response.status >= 100 && response.status <= 599
          ? response.status : 0;
        const bodyLimited = await discardProbeBody(response);
        return {reachability:'reachable', http_status:status,
          error:bodyLimited ? {cause:{code:'BODY_LIMIT'}} : null};
      } catch (error) {
        if (abort.signal.aborted) return timeoutResult;
        const rawCode = error?.cause?.code;
        const code = CONNECTIVITY_CAUSES.has(rawCode) ? rawCode : 'NETWORK_OTHER';
        return {reachability:'unreachable', http_status:0, error:{cause:{code}}};
      }
    })();
    try { return await Promise.race([request, deadline]); }
    finally { clearTimeout(timer); }
  };
  return complete;
}
module.exports = {createProvider, ProviderError};
