"""Fixed wanted-ID DOM row extraction for an owned, already verified search page.

Adapted selectors from jackwener/OpenCLI search.js, pinned at
24136945847afbfad266c6c46a8cd335377f9112 (Apache-2.0).
"""

from __future__ import annotations

import json
from pathlib import Path
import re
from urllib.parse import parse_qs, urlsplit


_SCRIPT = (Path(__file__).resolve().parent / 'resources' /
           'xhs-natural-wanted-dom-rows.js').read_text(encoding='utf-8')
_ID = re.compile(r'[0-9a-f]{24}')
_ROW_KEYS = {'note_id', 'xsec_token', 'xsec_source', 'title', 'author',
             'url', 'author_avatar_url', 'cover_url'}
_RESULT_KEYS = {'code', 'rows', 'wanted_count', 'found_count', 'missing_ids',
                'missing_count', 'scanned_card_count', 'ambiguous_card_count',
                'signed_row_count', 'source_pair_present_count'}
_CODES = {'untrusted_page', 'dom_scan_limit', 'rows_observed', 'wanted_missing'}


def _wanted_ids(value):
    return (type(value) is list and 1 <= len(value) <= 40 and
            all(type(item) is str and _ID.fullmatch(item) for item in value) and
            len(set(value)) == len(value))


def _keyword(value):
    return (type(value) is str and 0 < len(value) <= 200 and
            not any(ord(char) < 32 or ord(char) == 127 for char in value))


def build_wanted_dom_rows_js(keyword: str, wanted_note_ids: list[str]) -> str:
    """Embed only fixed keyword and exact scoped note IDs, never JS expressions."""
    if (not _keyword(keyword) or not _wanted_ids(wanted_note_ids) or
            _SCRIPT.count('__KEYWORD_JSON__') != 1 or
            _SCRIPT.count('__WANTED_IDS_JSON__') != 1):
        raise ValueError('wanted_rows_scope_invalid')
    return (_SCRIPT.replace('__KEYWORD_JSON__', json.dumps(keyword, ensure_ascii=True), 1)
            .replace('__WANTED_IDS_JSON__', json.dumps(wanted_note_ids), 1))


def _platform_image(value):
    if value == '':
        return True
    if type(value) is not str or len(value) > 2048 or re.search(r'[\s\\]', value):
        return False
    try:
        url = urlsplit(value)
        host = (url.hostname or '').lower()
        return (url.scheme == 'https' and url.port in (None, 443) and
                not url.username and not url.password and not url.fragment and
                url.path not in ('', '/') and
                any(host == domain or host.endswith('.' + domain)
                    for domain in ('xhscdn.com', 'xiaohongshu.com')))
    except ValueError:
        return False


def _valid_row(row):
    if type(row) is not dict or set(row) != _ROW_KEYS:
        return False
    if (type(row['note_id']) is not str or not _ID.fullmatch(row['note_id']) or
            any(type(row[key]) is not str for key in _ROW_KEYS - {'note_id'}) or
            not 0 < len(row['title']) <= 300 or len(row['author']) > 120 or
            len(row['xsec_token']) > 2048 or len(row['xsec_source']) > 128 or
            any(re.search(r'[\s\x00-\x1f\x7f]', row[key])
                for key in ('xsec_token', 'xsec_source')) or
            not _platform_image(row['author_avatar_url']) or
            not _platform_image(row['cover_url'])):
        return False
    try:
        url = urlsplit(row['url'])
        match = re.fullmatch(r'/(?:search_result|explore)/([0-9a-f]{24})/?', url.path)
        query = parse_qs(url.query, keep_blank_values=True)
        return bool(url.scheme == 'https' and url.hostname == 'www.xiaohongshu.com'
                    and url.port in (None, 443) and not url.username and
                    not url.password and not url.fragment and len(row['url']) <= 4096
                    and match and match.group(1) == row['note_id'] and
                    query.get('xsec_token', ['']) == [row['xsec_token']] and
                    query.get('xsec_source', ['']) == [row['xsec_source']] and
                    len(query.get('xsec_token', [])) <= 1 and
                    len(query.get('xsec_source', [])) <= 1)
    except ValueError:
        return False


def validate_wanted_rows(value: object, wanted_ids: list[str]) -> dict:
    """Return validated DTO; missing rows remain pending, never fabricated."""
    if not _wanted_ids(wanted_ids) or type(value) is not dict or set(value) != _RESULT_KEYS:
        raise ValueError('wanted_rows_invalid')
    if type(value['code']) is not str or value['code'] not in _CODES:
        raise ValueError('wanted_rows_invalid')
    rows = value['rows']
    missing = value['missing_ids']
    if (type(rows) is not list or len(rows) > len(wanted_ids) or
            type(missing) is not list or
            any(type(item) is not str or not _ID.fullmatch(item) for item in missing) or
            any(not _valid_row(row) for row in rows)):
        raise ValueError('wanted_rows_invalid')
    found_ids = [row['note_id'] for row in rows]
    if (found_ids != [item for item in wanted_ids if item in set(found_ids)] or
            missing != [item for item in wanted_ids if item not in set(found_ids)]):
        raise ValueError('wanted_rows_invalid')
    for key in ('wanted_count', 'found_count', 'missing_count', 'scanned_card_count',
                'ambiguous_card_count', 'signed_row_count', 'source_pair_present_count'):
        if type(value[key]) is not int or not 0 <= value[key] <= 100000:
            raise ValueError('wanted_rows_invalid')
    if (value['wanted_count'] != len(wanted_ids) or value['found_count'] != len(rows) or
            value['missing_count'] != len(missing) or
            value['scanned_card_count'] < len(rows) or
            value['ambiguous_card_count'] > value['scanned_card_count'] or
            value['signed_row_count'] != sum(bool(row['xsec_token']) for row in rows) or
            value['source_pair_present_count'] != sum(bool(row['xsec_token'] and
                                                        row['xsec_source']) for row in rows) or
            (value['code'] == 'rows_observed' and missing) or
            (value['code'] == 'wanted_missing' and not missing) or
            (value['code'] in {'untrusted_page', 'dom_scan_limit'} and
             (rows or missing != wanted_ids))):
        raise ValueError('wanted_rows_invalid')
    return {**value, 'rows': [dict(row) for row in rows], 'missing_ids': list(missing)}
