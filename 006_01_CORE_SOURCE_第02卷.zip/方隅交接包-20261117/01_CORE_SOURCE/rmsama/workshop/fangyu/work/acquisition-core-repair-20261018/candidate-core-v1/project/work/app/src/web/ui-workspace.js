/* Personal workspace draft adapter; not part of generic core. */
(()=>{
 const drafts=new Map();
 function captureDraft(){const box=document.querySelector('#reply-text');if(box&&box.dataset.lead)drafts.set(box.dataset.lead,{text:box.value,channel:document.querySelector('#reply-channel')?.value,grade:document.querySelector('#f-manual_grade')?.value});}
 function attachDraft(id){const box=document.querySelector('#reply-text');box.dataset.lead=id;const saved=drafts.get(id);if(saved){box.value=saved.text;document.querySelector('#reply-channel').value=saved.channel;document.querySelector('#f-manual_grade').value=saved.grade;}box.addEventListener('input',captureDraft);document.querySelector('#reply-channel').addEventListener('change',captureDraft);document.querySelector('#f-manual_grade').addEventListener('change',captureDraft);}
 function snapshot(){captureDraft();const a=document.activeElement;return {page:typeof state!=='undefined'?state.page:null,lead:document.querySelector('#lead-inspector:not([hidden]) #reply-text')?.dataset.lead,focus:a?.id,selection:a&&typeof a.selectionStart==='number'?[a.selectionStart,a.selectionEnd]:null,scroll:[...document.querySelectorAll('.content,.table-wrap,#lead-inspector')].map(e=>[e.id?'#'+e.id:'.'+e.classList[0],e.scrollTop,e.scrollLeft]),windowY:scrollY};}
 function restore(s){if(s.page!==state.page)return;if(s.lead&&rows('leads').some(l=>l.id===s.lead))leadDetail(s.lead);if(s.focus){const a=document.getElementById(s.focus);a?.focus({preventScroll:true});if(s.selection&&a?.setSelectionRange)a.setSelectionRange(...s.selection);}for(const [sel,y,x]of s.scroll){const e=document.querySelector(sel);if(e){e.scrollTop=y;e.scrollLeft=x;}}scrollTo(0,s.windowY);}
 document.addEventListener('ui:drawerclosing',captureDraft);
 Object.assign(WorkbenchUI,{captureDraft,attachDraft,snapshot,restore});
})();
