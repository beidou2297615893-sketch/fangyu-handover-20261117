/* Local recorded activity and current evidence are separate views, never a funnel. */
const keys=['reviewed_clients','sent_reported_clients','external_reported_clients','copied_clients','handoff_saved_clients','handoff_submitted_clients','nonself_receipt_recorded_clients'];
const labels={reviewed_clients:'回复审核记录',sent_reported_clients:'发送上报记录',external_reported_clients:'人工外部联系记录',copied_clients:'回复复制记录',handoff_saved_clients:'新建本机交接',handoff_submitted_clients:'登记本机待交付',nonself_receipt_recorded_clients:'非本人接收登记'};
const explanations={reviewed_clients:'表示回复经过审核，不表示客户意向评级或已经联系。',sent_reported_clients:'表示本机保存发送上报，不表示平台独立验真或客户已读。',external_reported_clients:'表示人工登记外部联系，不表示平台已核验。',copied_clients:'仅表示复制回复，不表示已经发送。',handoff_saved_clients:'仅计新建的本机交接，不表示公司已收到。',handoff_submitted_clients:'表示本机登记待交付，不表示资源部已经收到。',nonself_receipt_recorded_clients:'表示另一授权账号的本机接收记录；当前接收权限已核对，不表示跨电脑送达或付款。'};
const reasons={journal_unreadable:'联系历史不完整，需要核对原记录',source_unavailable:'部分原来源当前不可读',source_changed:'原来源身份或内容已变化',identity_unverified:'部分客户账号身份尚未核实',date_unavailable:'部分记录缺少可信日期',future_record:'部分记录时间超前，需要核对',reply_owner_unverified:'原回复归属尚未核实',reply_evidence_unavailable:'原回复缺少完整对应事件',handoff_audit_unavailable:'交接审计记录尚未完整核对',receipt_receiver_unavailable:'接收账号或其当前权限尚未核实',response_evidence_unavailable:'客户回应对应证据尚未完整核对'};
const unsupported=[['first_found_clients','当天首次找到客户','first_saved_date_not_recorded','缺少不可变的首次保存日期'],['first_qualified_clients','当天首次确认高意向','historical_assessment_not_reconstructable','不能用当前意向评级还原过去'],['actual_customer_consent_clients','当天实际客户同意','actual_consent_date_not_verified','实际同意发生日期尚未核实'],['first_response_confirmed_clients','当天首次确认客户回应','first_match_date_not_immutable','首次对应确认日期没有不可变记录'],['verified_cash_cents','实际回款','financial_authority_not_connected','尚无财务核验证据'],['verified_paid_commission_cents','已付提成','financial_authority_not_connected','尚无财务核验证据']];
const falseFlags=['mutation_committed','cross_machine_verified','platform_requests_started','provider_requests_started','ratings_modified','contacts_modified','handoffs_modified','auto_retry','is_conversion_funnel','platform_provenance_verified','financial_receipt_verified'];
const exact=(v,fields)=>v&&typeof v==='object'&&!Array.isArray(v)&&Object.keys(v).length===fields.length&&fields.every(k=>Object.hasOwn(v,k));
const integer=v=>Number.isSafeInteger(v)&&v>=0;
const list=(v,allowed)=>Array.isArray(v)&&v.length<=allowed.length&&new Set(v).size===v.length&&v.every(k=>typeof k==='string'&&allowed.includes(k));
const dayStart=day=>{if(typeof day!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(day)||day<'2020-01-01')return null;const [y,m,d]=day.split('-').map(Number),ms=Date.UTC(y,m-1,d);return Number.isFinite(ms)&&new Date(ms).toISOString().slice(0,10)===day?ms/1000-28800:null;};
const shanghaiDay=ms=>new Date(ms+28800000).toISOString().slice(0,10);
const invalidMessage='本人每日记录的范围或证据完整度未通过核对，请重新查询。';

export function checkedSelfDailyEvidence(value,request){
  const fail=()=>{throw Error(invalidMessage);};
  const top=[...falseFlags,'contract','read_only','local_only','storage_scope','period','observed_at','scope','historical_activities_do_not_prove_current_authorization','activities','unsupported','current','coverage'];
  if(!exact(request,['day'])||!exact(value,top)||value.contract!=='self_daily_evidence_v1'||value.read_only!==true||value.local_only!==true||value.storage_scope!=='this_device'||falseFlags.some(k=>value[k]!==false)||value.historical_activities_do_not_prove_current_authorization!==true)fail();
  const period=value.period,start=dayStart(request.day);
  if(start===null||!exact(period,['day','timezone','utc_offset','start_epoch','end_epoch_exclusive','basis'])||period.day!==request.day||period.timezone!=='Asia/Shanghai'||period.utc_offset!=='+08:00'||period.basis!=='recorded_activity'||period.start_epoch!==start||period.end_epoch_exclusive!==start+86400||!integer(value.observed_at)||value.observed_at<start||value.observed_at>253402271999)fail();
  if(!exact(value.scope,['subject','deduplication'])||value.scope.subject!=='current_actor'||value.scope.deduplication!=='platform_uid_per_stage_per_day'||!Array.isArray(value.activities)||value.activities.length!==keys.length)fail();
  const fields=['key','value','unit','event_count','coverage_status','checked_record_count','reason_codes','clock_basis','evidence_level','authority'];
  for(let i=0;i<keys.length;i++){
    const item=value.activities[i];if(!exact(item,fields)||item.key!==keys[i]||item.unit!=='unique_clients'||item.clock_basis!=='local_recorded_epoch'||item.evidence_level!=='local_chain_checked_record'||item.authority!==(i===6?'authorized_local_actor_current_receiver_checked':'local_device_report')||!integer(item.checked_record_count)||!list(item.reason_codes,Object.keys(reasons))||!['complete','incomplete'].includes(item.coverage_status))fail();
    if(item.coverage_status==='complete'){if(!integer(item.value)||!integer(item.event_count)||item.value>item.event_count||(item.value===0)!==(item.event_count===0)||item.event_count>item.checked_record_count||item.reason_codes.length)fail();}
    else if(item.value!==null||item.event_count!==null||item.reason_codes.length===0)fail();
  }
  if(!Array.isArray(value.unsupported)||value.unsupported.length!==unsupported.length)fail();
  for(let i=0;i<unsupported.length;i++){const item=value.unsupported[i],[key,,reason]=unsupported[i];if(!exact(item,['key','value','reason_code'])||item.key!==key||item.value!==null||item.reason_code!==reason)fail();}
  const current=value.current;
  if(!exact(current,['basis','stable_uid_clients','provisional_identity_clients','needs_check_clients','provisional_needs_check_clients','explicit_response_observed_clients','response_coverage_status','response_reason_codes','ready_to_deliver_clients','handoff_coverage_status'])||current.basis!=='current_authorized_snapshot'||['stable_uid_clients','provisional_identity_clients','needs_check_clients','provisional_needs_check_clients'].some(k=>!integer(current[k]))||current.needs_check_clients>current.stable_uid_clients||current.provisional_needs_check_clients>current.provisional_identity_clients||!['complete','incomplete'].includes(current.response_coverage_status)||!['complete','incomplete'].includes(current.handoff_coverage_status)||!list(current.response_reason_codes,['response_evidence_unavailable']))fail();
  if(current.response_coverage_status==='complete'){if(!integer(current.explicit_response_observed_clients)||current.explicit_response_observed_clients>current.stable_uid_clients||current.response_reason_codes.length)fail();}
  else if(current.explicit_response_observed_clients!==null||current.response_reason_codes.length!==1)fail();
  if(current.handoff_coverage_status==='complete'){if(!integer(current.ready_to_deliver_clients)||current.ready_to_deliver_clients>current.stable_uid_clients)fail();}else if(current.ready_to_deliver_clients!==null)fail();
  const handoffMissing=value.activities.slice(4).some(item=>item.reason_codes.some(code=>['source_changed','handoff_audit_unavailable'].includes(code)));
  if((current.handoff_coverage_status==='incomplete')!==handoffMissing)fail();
  const coverage=value.coverage;
  if(!exact(coverage,['scope','complete','stage_missing_dates_are_not_zero','historical_receiver_permission_snapshot_available'])||coverage.scope!=='currently_authorized_local_sources'||coverage.complete!==(value.activities.every(r=>r.coverage_status==='complete')&&current.response_coverage_status==='complete')||coverage.stage_missing_dates_are_not_zero!==true||coverage.historical_receiver_permission_snapshot_available!==false)fail();
  return value;
}

const node=(tag,text='',className='')=>{const element=document.createElement(tag);element.textContent=String(text);if(className)element.className=className;return element;};
const number=v=>v===null?'未核实':`${v} 位`;
export function createSelfDailyEvidenceUI({createDialog,read,scope,clock=Date.now}){
  let generation=0,active=null,disposed=false;
  function clear(){generation++;if(active){active.root.replaceChildren();active.root.close?.();active.root.remove();active=null;}}
  async function open({accept=()=>true}={}){
    if(disposed)return;try{if(accept()!==true)return;}catch{return;}
    clear();const own=++generation,principal=scope(),view=createDialog('本人每日记录进展');active=view;let epoch=0;
    const current=()=>{try{return !disposed&&generation===own&&active===view&&scope()===principal&&view.current()&&accept()===true;}catch{return false;}};
    const report=(text,error=false)=>{if(current()){view.status.textContent=text;view.status.dataset.state=error?'error':'ready';}};
    view.root.append(node('p','只读取本人当前有权的本机记录。当天活动与当前情况分别展示；不会自动联系、交接、查询公司或调用模型。','upgrade-muted'));
    const form=node('form','','upgrade-operation-form'),label=node('label','上海日期'),date=node('input'),query=node('button','查询这一天','secondary');date.type='date';date.min='2020-01-01';date.setAttribute('aria-label','上海日期');
    try{date.max=shanghaiDay(clock());date.value=date.max;}catch{report('本机日期暂不可核对，请核对电脑时间。',true);return;}
    query.type='submit';label.append(date);form.append(label,query);view.root.append(form);const results=node('section');view.root.append(results);
    date.addEventListener('input',()=>{if(!current())return;epoch++;results.replaceChildren();query.disabled=false;report('日期已变化，请查询这一天；旧日期结果已收起。');});
    form.addEventListener('submit',event=>{event.preventDefault();void load();});
    async function load(){
      if(!current())return;const ticket=++epoch,request={day:date.value},valid=()=>current()&&ticket===epoch&&date.value===request.day;results.replaceChildren();
      if(dayStart(request.day)===null||request.day>date.max){query.disabled=false;report('请选择2020年至今天的上海日期，未发起查询。',true);return;}
      query.disabled=true;report('正在核对这一天的本机记录与当前范围…');
      try{const value=await read('self_daily_evidence_summary',request);if(!valid())return;render(checkedSelfDailyEvidence(value,request));report(value.coverage.complete?'已读取当天记录与当前快照；各项人数不能当作转化率。':'部分证据未完整核实，缺口显示未核实；没有记为0。');}
      catch{if(valid()){results.replaceChildren();report('每日记录暂不可读或未通过核对；请核对本人范围后重新查询，缺失未记为0。',true);}}
      finally{if(current()&&ticket===epoch)query.disabled=false;}
    }
    function render(value){
      results.replaceChildren();const activities=node('section','','upgrade-operation-form');activities.append(node('h3',`${value.period.day} 当天已保存的活动`),node('p','上海时间当天零点起，次日零点前。每项按平台账号对应的客户去重，同一客户可出现在多项；各项不能相除或合并为转化漏斗。','upgrade-muted'));
      for(const item of value.activities){const row=node('section','','upgrade-operation-form'),header=node('div','','upgrade-record-line');header.append(node('span',labels[item.key]),node('strong',number(item.value)));row.append(header,node('p',explanations[item.key],'upgrade-muted'));
        if(item.coverage_status==='complete')row.append(node('p',`已保存 ${item.event_count} 条相关事件；人数限当前本人有权范围。`,'upgrade-muted'));
        else row.append(node('p','人数与事件数均未核实，暂不能按已有部分推算。','upgrade-authorization-warning'));
        const detail=node('details');detail.append(node('summary','查看完整度说明'),node('p',`证据核对覆盖 ${item.checked_record_count} 条记录；这是检查范围，不是业绩人数。`,'upgrade-muted'));
        for(const code of item.reason_codes)detail.append(node('p',reasons[code],'upgrade-muted'));row.append(detail);activities.append(row);}
      results.append(activities);const snapshot=node('section','','upgrade-operation-form'),current=value.current;snapshot.append(node('h3','当前本人有权快照'),node('p','以下是读取时的当前情况，与所选日期无关；历史活动不能证明现在仍有客户授权。','upgrade-muted'));
      for(const [title,v]of [['有稳定账号身份的客户',current.stable_uid_clients],['身份尚未完整核实的客户',current.provisional_identity_clients],['当前需要核对的客户',current.needs_check_clients],['身份未完整且需要核对的客户',current.provisional_needs_check_clients],['已保存对应回应的客户',current.explicit_response_observed_clients],['当前具备本机待交付条件的客户',current.ready_to_deliver_clients]]){const row=node('div','','upgrade-record-line');row.append(node('span',title),node('strong',number(v)));snapshot.append(row);}
      for(const code of current.response_reason_codes)snapshot.append(node('p',reasons[code],'upgrade-muted'));if(current.handoff_coverage_status==='incomplete')snapshot.append(node('p','当前交接来源或审计记录尚未完整核对。','upgrade-muted'));results.append(snapshot);
      const missing=node('section','','upgrade-operation-form');missing.append(node('h3','尚不能按天确认的事项'));for(const [,title,,reason]of unsupported){const row=node('div','','upgrade-record-line');row.append(node('span',title),node('strong','未核实'));missing.append(row,node('p',reason,'upgrade-muted'));}missing.append(node('p','记录发生不等于平台送达、客户实际同意、资源部独立接收或财务到账。没有把未知回款与提成显示为0。','upgrade-muted'));results.append(missing);
    }
    await load();
  }
  return {open,reset:clear,dispose(){disposed=true;clear();}};
}
