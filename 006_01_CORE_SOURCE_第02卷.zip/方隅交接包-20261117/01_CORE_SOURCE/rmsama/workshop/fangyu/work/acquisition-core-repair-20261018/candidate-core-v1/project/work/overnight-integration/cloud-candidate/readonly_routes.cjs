'use strict';
const {createStoreConfigRead,hash}=require('./store_config.cjs');
const {devicePermissionSnapshot}=require('./device_permission_snapshot.cjs');
function createReadonlyRoutes(options){
 const config=createStoreConfigRead(options),{store,companyId,clock=Date.now}=options;
 return async function read(payload,bearer){
  if(payload.operation==='store_config_read')return config(payload,bearer);
  const flags={purpose:'device_permission_snapshot',schema:'device-permission-snapshot-v1',read_only:true,mutation_committed:false,command_claimed:false,auto_retry:false};
  try{
   if(typeof store.readStoreConfigState!=='function')return {status:503,data:{...flags,code:'DEVICE_SNAPSHOT_STORAGE_UNAVAILABLE'}};
   const before=await store.readStoreConfigState();
   if(!before)return {status:503,data:{...flags,code:'DEVICE_SNAPSHOT_STORAGE_UNAVAILABLE'}};
   if(before.companyId!==companyId)return {status:403,data:{...flags,code:'DEVICE_SNAPSHOT_COMPANY_MISMATCH'}};
   const first=devicePermissionSnapshot({...options,state:before,payload,bearer,now:Math.floor(clock()/1000)});
   if(first.status!==200)return first;
   const deviceIdentity=state=>{
    const device=state?.devices?.find(d=>d&&!d.revoked&&d.digest===hash(bearer));
    const owner=state?.users?.find(u=>u&&u.username===device?.owner&&!u.disabled);
    return hash({companyId:state?.companyId,device,owner});
   };
   const after=await store.readStoreConfigState();
   const last=devicePermissionSnapshot({...options,state:after,payload,bearer,now:Math.floor(clock()/1000)});
   if(last.status!==200)return last;
   if(deviceIdentity(before)!==deviceIdentity(after))return {status:409,data:{...flags,code:'DEVICE_SNAPSHOT_AUTHORITY_CHANGED'}};
   return last;
  }catch{return {status:503,data:{...flags,code:'DEVICE_SNAPSHOT_STORAGE_UNAVAILABLE'}};}
 };
}
module.exports={createReadonlyRoutes};
