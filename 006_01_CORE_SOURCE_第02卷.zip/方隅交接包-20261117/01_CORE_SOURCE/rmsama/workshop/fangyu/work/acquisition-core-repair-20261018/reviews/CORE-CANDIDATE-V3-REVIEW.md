# Core candidate v3 独立只读审查

结论：本次事务修复、v3 固定闭包及本地入口适配未发现未解决问题。Critical 0 / Important 0 / Minor 0。此结论是技术审查，不是平台、许可、用途或商业分发批准。

审查时 GUI-RESULT、PREPARED 与 INSTALL 均尚不存在；本报告不声称隔离 GUI 已通过、原入口已安装或新原生业务已实测。root 可在本轮 GUI gate 成立、生成新 PREPARED 并完成既有入口 --check 后，继续已授权的本地两文件安装。既有 expected-old CAS 仍会拒绝期间变化的原入口。

## 事务锁修复与账号门禁

- Core `work/ui-runtime-r55/src/core/engine.py:351` 的 `_task_access(..., *, db=None)` 只把同一连接传给账号读取；`_account_access` 345–350 行原文未变，cloud-bound 管理员也没有新增跨 owner 通道。
- Core 365–373 行 `_get` 的新分支复用与原 Store.get 相同的 entity/id 查询，再执行原 body tenant 检查。不存在账号、跨 tenant、其他 owner 仍拒绝；没有增加角色、许可或 lease 例外。原未传 db 的调用仍走原 Store.get。
- `work/ui-native-r57/rental_assessment.py:934` 与 1020 行是仅有的两个 Core task-access 调用，均传 `db=db`。assess_task、assess_visible 与 read_assessment 的账号读取都沿 `_scope` 使用已打开连接；批量判断的 BEGIN IMMEDIATE 事务内，actor、task、lead、context、既有 assessment、fresh_actor/fresh_scope 与写入均复用同一 db。静态检查整个 RentalAssessmentService 未见剩余 store.get 或额外连接。
- source55 Core SHA `95841d88d5ff936477eb749cacdc8d781a45c444534c852f78463b4bae3977a0`；rental SHA `888081fa1e9ffb2aff59b5dd7ef8e646fbbb3d15d0de0295c90795bcb8e8f223`，与 v3 实际父依赖/冻结文件相同。
- 独立测试证据已核对，没有重跑：RENTAL-ACCOUNT-1000-RED 来自冻结 v2 前像的 database locked；GREEN 使用当前真实 Core/Store/账号门禁，1000 assessed/written/stored，并验证同事务账号改 owner、改 tenant、删除均拒绝且回滚。测试只有合成 SQLite，真实请求/CLI/付费 AI 为零。不能把 v2 RED 写成当前源码失败。

## v3 固定闭包

- Release `ui-r57-20261018T015518Z-f7fec96e`；UNIFIED-PINS SHA `d705bb65967f6c5e7d6a1f849fb3bbbbd50cd5e7188bf03acca7c29cf86c6910`。本审查逐项只读核对 2216 pins、117 frozen files、245 source55 父依赖、2096 当前公共源输入，大小/哈希全部一致。
- CLI 297 文件与原 component/artifacts 同字节；未编译、未执行。固定 helper SHA `845540b979438b4d44c0f92adfbdb8440bb7f95f8f66d47df42917fe26d5a2c3` 同时进入 carrier 与 frozen vendor，Runtime 固定 pin 未变。
- 三处装配变换逐字节复核：company 仅 cli_source_sha256、employee_distribution 三个 artifact pins、Runtime 仅 guarded-cli 路径。Core/rental 修复确已进入闭包；相对 v2，共同路径下只有这两个公共源码文件变化，其余差异为新 release/launcher 生成。
- private_evaluation、self_operating_read、runtime_license_policy 与上一已审 employee candidate 同字节。22 原校验器 PASS 的既有记录指向本 v3 pin/release，未重跑旧套。当前 assemble/verify 的实际文件哈希与 CANDIDATE-TOOLS.current_file_sha256 相符。
- 本轮结论不扩成全平台持续运行声明；辅助 DY 原 single-batch 限制仍按已知范围保留。当前 XHS request guard/pacing、实际平台验证停止和 lease 准入没有因此获绕过。

## 入口适配及操作边界

- adapt_entry_tools 复用 continuation entry-batch 已审模板。install 脚本除 P 层级和 OUT 路径两处字面量外完全一致；仅 run_workbench.py / FROZEN.json 两个目标，替换前各自 CAS、exclusive backup、fsync + os.replace、仅回滚仍符合本次 old/new 的文件等代码保持原样。两文件是受限事务，不宣称断电下的操作系统整体原子替换。
- prepare 改用本轮 GUI-RESULT：要求本 release、browser/native 均验、真实平台和付费 AI 次数为零；旧原 native/6 条规则 GUI 证据不再充当本轮 gate。report 明确 original-native-business skipped。新计划会实时捕获当前原入口/FROZEN 旧哈希，未复制旧 PREPARED。
- 原 state 保留；只复制公开 production-workspace 声明作为双 binding，原/候选声明哈希在 launcher 的 host/business import 前检查。未复制真实 DB/vault/session，未改桌面快捷方式、company、生产授权或 other-owner 策略。
- 审查者未写产品、未开 GUI/真实进程、未读真实 state DB/vault 内容、未发网络/平台/CLI 请求。短验证数据见同目录 CORE-CANDIDATE-V3-REVIEW.json。
