/* Fangyu first release keeps the team shared-lead API and data dormant. */
const SHARED_FEATURE_ENABLED = false;
module.exports = {SHARED_FEATURE_ENABLED};
