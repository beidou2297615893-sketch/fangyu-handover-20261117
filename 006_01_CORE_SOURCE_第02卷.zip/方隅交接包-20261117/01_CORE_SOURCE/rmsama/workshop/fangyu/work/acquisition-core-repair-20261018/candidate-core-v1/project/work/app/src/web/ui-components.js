/* Reusable interaction primitives; no platform calls or customer data. */
window.WorkbenchUI=(()=>{
 let origin=null,previousNav=null;
 const reduced=matchMedia('(prefers-reduced-motion: reduce)');
 const running=new Set();
 function animate(node,frames,options={}){if(!node||reduced.matches||document.body.classList.contains('ui-refresh'))return null;const a=node.animate(frames,{duration:520,easing:'cubic-bezier(.16,1,.3,1)',...options});running.add(a);a.finished.catch(()=>{}).finally(()=>running.delete(a));return a;}
 reduced.addEventListener('change',()=>{if(reduced.matches)for(const a of running)a.cancel()});
 function openDrawer(node){if(node.hidden){origin=document.activeElement;node.hidden=false;node.tabIndex=-1;node.focus({preventScroll:true});animate(node,[{opacity:0,transform:'translateX(100%)'},{opacity:1,transform:'translateX(0)'}],{duration:620});}node.setAttribute('aria-label','客户详情');}
 function closeDrawer(node){node.dispatchEvent(new CustomEvent('ui:drawerclosing',{bubbles:true}));if(!node.hidden&&!reduced.matches){const ghost=node.cloneNode(true);ghost.removeAttribute('id');ghost.querySelectorAll('[id]').forEach(e=>e.removeAttribute('id'));ghost.classList.add('ui-exit-ghost');ghost.setAttribute('aria-hidden','true');ghost.inert=true;document.body.append(ghost);ghost.scrollTop=node.scrollTop;const a=animate(ghost,[{opacity:1,transform:'translateX(0)'},{opacity:0,transform:'translateX(100%)'}],{duration:320,easing:'cubic-bezier(.4,0,1,1)'});if(a)a.finished.catch(()=>{}).finally(()=>ghost.remove());else ghost.remove();}node.hidden=true;if(origin?.isConnected)origin.focus({preventScroll:true});else document.querySelector('[data-drawer-return]')?.focus({preventScroll:true});}
 function busy(button,value){if(!button)return;button.disabled=value;button.setAttribute('aria-busy',String(value));}
 function help(anchor,text){const panel=document.createElement('span');panel.className='ui-popover';panel.id='help-'+Math.random().toString(36).slice(2);panel.hidden=true;panel.textContent=text;anchor.after(panel);anchor.setAttribute('aria-controls',panel.id);anchor.setAttribute('aria-expanded','false');anchor.onclick=()=>{panel.hidden=!panel.hidden;anchor.setAttribute('aria-expanded',String(!panel.hidden));};anchor.addEventListener('keydown',e=>{if(e.key==='Escape'){panel.hidden=true;anchor.setAttribute('aria-expanded','false');}});}
 document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!document.querySelector('dialog[open]')){const drawer=document.querySelector('.ui-drawer:not([hidden])');if(drawer){closeDrawer(drawer);e.preventDefault();}}});
 function beforeRender(){previousNav=document.querySelector('.nav .active')?.getBoundingClientRect();}
 function afterRender(){
  const active=document.querySelector('.nav .active');
  if(active){const mark=document.createElement('span');mark.className='ui-nav-track';mark.setAttribute('aria-hidden','true');active.prepend(mark);if(previousNav){const now=active.getBoundingClientRect();animate(mark,[{transform:`translateY(${previousNav.top-now.top}px)`},{transform:'translateY(0)'}],{duration:500});}}
  if(document.body.classList.contains('ui-refresh'))return;
  const parts=[...document.querySelectorAll('#page>.page-head,#page>.panel,#page>.reference-account-strip,#page>.reference-layout>section')];
  parts.forEach((node,i)=>animate(node,[{opacity:0,transform:'translateY(26px)'},{opacity:1,transform:'translateY(0)'}],{duration:580,delay:i*75}));
  [...document.querySelectorAll('#page tbody tr,#page .reference-platform-tabs>button')].slice(0,10).forEach((node,i)=>animate(node,[{opacity:0,transform:'translateX(22px)'},{opacity:1,transform:'translateX(0)'}],{duration:440,delay:120+i*45}));
 }
 document.addEventListener('click',e=>{
  const button=e.target.closest('button');
  if(button&&!button.disabled&&!reduced.matches){const r=button.getBoundingClientRect();const halo=document.createElement('span');halo.className='ui-click-wave';halo.setAttribute('aria-hidden','true');const size=Math.max(r.width,r.height)*1.5;Object.assign(halo.style,{width:size+'px',height:size+'px',left:(e.detail?e.clientX:r.left+r.width/2)-size/2+'px',top:(e.detail?e.clientY:r.top+r.height/2)-size/2+'px'});document.body.append(halo);const a=animate(halo,[{opacity:.45,transform:'scale(.05)'},{opacity:0,transform:'scale(1)'}],{duration:520,easing:'ease-out'});if(a)a.finished.catch(()=>{}).finally(()=>halo.remove());else halo.remove();}
  const summary=e.target.closest('summary');if(!summary)return;const details=summary.parentElement;if(!details.matches('details')||reduced.matches)return;
  e.preventDefault();if(details.dataset.animating)return;details.dataset.animating='true';const closing=details.open;const start=details.getBoundingClientRect().height;details.open=true;if(!closing)animate(details.querySelector('.form-grid'),[{opacity:0,transform:'translateY(-14px)'},{opacity:1,transform:'translateY(0)'}],{duration:440});const end=closing?summary.getBoundingClientRect().height:details.getBoundingClientRect().height;details.style.overflow='hidden';const a=animate(details,[{height:start+'px'},{height:end+'px'}],{duration:460});const done=()=>{if(details.isConnected){details.open=!closing;details.style.overflow='';delete details.dataset.animating;}};if(a)a.finished.then(done,done);else done();
 });
 document.addEventListener('change',e=>{if(e.target.matches('select'))animate(e.target,[{boxShadow:'0 0 0 0 #639ee680'},{boxShadow:'0 0 0 9px #639ee600'},{boxShadow:'0 0 0 0 #639ee600'}],{duration:620,easing:'ease-out'})});
 return {openDrawer,closeDrawer,busy,help,beforeRender,afterRender,animate};
})();
