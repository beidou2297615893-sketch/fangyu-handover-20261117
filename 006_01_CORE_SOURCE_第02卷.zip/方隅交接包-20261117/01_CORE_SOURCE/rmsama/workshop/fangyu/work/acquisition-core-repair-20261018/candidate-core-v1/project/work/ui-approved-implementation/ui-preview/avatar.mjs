// Existing recorded customer avatars only; never query a profile or guess a portrait.
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function savedMediaUrl(value,kinds){
  if(typeof value!=='string'||value.length>2048||/[\s\u0000-\u001f\u007f]/.test(value))return '';
  try{
    const url=new URL(value,location.origin),keys=[...url.searchParams.keys()];
    if(url.origin!==location.origin||url.pathname!=='/api/workbench/media'||url.hash||url.username||url.password
      ||keys.length!==3||new Set(keys).size!==3||keys.some(key=>!['storeId','leadId','kind'].includes(key))
      ||!kinds.includes(url.searchParams.get('kind'))||!(/^[A-Za-z0-9_-]{1,80}$/).test(url.searchParams.get('storeId')||'')
      ||!(/^(?:[a-f0-9]{32}|[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12})$/i).test(url.searchParams.get('leadId')||''))return '';
    return url.pathname+url.search;
  }catch{return '';}
}
export function customerAvatarUrl(value){return savedMediaUrl(value,['author','post_author']);}
export function postCover(person,cls='',style=''){
  const url=savedMediaUrl(person?.coverUrl,['cover']);
  return `<img class="${cls}"${style?` style="${style}"`:''} src="${esc(url||'/assets/tabler-external-link.svg')}" alt="原帖图片" referrerpolicy="no-referrer" data-post-cover${url?' data-cover-remote':''}>`;
}
export function customerAvatar(person,cls='',style=''){
  const url=customerAvatarUrl(person?.avatarUrl),fallback='/assets/approved-icon-user-round.svg';
  return `<img class="${cls}"${style?` style="${style}"`:''} src="${esc(url||fallback)}" alt="${url?esc((person?.name||'客户')+'的头像'):''}" referrerpolicy="no-referrer" data-customer-avatar${url?' data-avatar-remote':''}>`;
}
export function bindCustomerAvatars(root){
  for(const image of root.querySelectorAll('[data-avatar-remote]')){
    const fallback=()=>{image.removeEventListener('error',fallback);delete image.dataset.avatarRemote;image.src='/assets/approved-icon-user-round.svg';image.alt='';};
    image.addEventListener('error',fallback,{once:true});
    if(image.complete&&image.naturalWidth===0)fallback();
  }
  for(const image of root.querySelectorAll('[data-cover-remote]')){
    const fallback=()=>{image.removeEventListener('error',fallback);delete image.dataset.coverRemote;image.src='/assets/tabler-external-link.svg';image.alt='原帖未保存图片';image.style.objectFit='contain';image.style.padding='20px';};
    image.addEventListener('error',fallback,{once:true});
    if(image.complete&&image.naturalWidth===0)fallback();
  }
}
