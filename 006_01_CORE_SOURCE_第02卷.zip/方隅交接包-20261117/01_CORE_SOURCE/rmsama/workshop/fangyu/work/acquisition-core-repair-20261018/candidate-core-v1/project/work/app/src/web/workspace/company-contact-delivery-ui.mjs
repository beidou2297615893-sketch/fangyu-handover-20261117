/* Explicit contact actions. Backend owns all durable keys; plaintext never enters storage. */
const exact=(v,keys)=>v&&typeof v==='object'&&!Array.isArray(v)&&Object.keys(v).length===keys.length&&keys.every(k=>Object.hasOwn(v,k));
const hex=v=>typeof v==='string'&&/^[a-f0-9]{64}$/.test(v),channel=v=>typeof v==='string'&&/^hc_[a-f0-9]{64}$/.test(v);
const integer=v=>Number.isSafeInteger(v)&&v>=0,stamp=v=>integer(v)&&v>=1577836800,bool=v=>typeof v==='boolean';
const version=v=>typeof v==='string'&&/^[A-Za-z0-9_-]{8,96}$/.test(v),identifier=v=>typeof v==='string'&&/^[A-Za-z0-9_-]{1,160}$/.test(v);
const label=v=>typeof v==='string'&&!!v.trim()&&v.length<=160&&v===v.normalize('NFKC')&&!/[\p{Cc}\p{Cf}\p{Cs}]/u.test(v)&&!/(?:\d[\p{P}\p{Z}]*){7,}|(?:微信|wechat|weixin|wxid|手机号|电话|cookie|password|secret|api[_-]?key)\s*[:：=号]?\s*[A-Za-z0-9]{3,}|(?:contact|platform|consent|evidence|notice|document)\s*:|Bearer\s+|sk-[\w-]{12}/iu.test(v);
const PUBLISH='company_contact_publish',REVEAL='company_contact_reveal',WITHDRAW='company_contact_withdraw',GET='company_contact_operation_get';
const cloudActions={[PUBLISH]:'acquisition_contact_publish',[REVEAL]:'acquisition_contact_reveal',[WITHDRAW]:'acquisition_handoff_withdraw'};
const states=['draft','submitted','accepted','rejected','needs_information','duplicate_pending_review','existing_customer_pending_review','withdrawn','disputed'];
const top=['contract','action','read_only','mutation_committed','storage_scope','observed_at','channel_id','state','attempt','delivery','current','withdrawal_receipt','cloud_requested','auto_retry','plaintext_cached','cross_machine_delivery_verified','platform_requests_started','ai_provider_called','financial_receipt_verified','verified_cash_cents','verified_paid_commission_cents'];
const itemKeys=['channel_id','customer_scope_hash','source_actor_scope_hash','platform','recipient_id','recipient_name','purpose','revision','status','current_consent_valid','can_receipt','historical_resource_receipt_recorded','receipt_evidence_independently_verified','contact_delivery','created_at','updated_at'];
const attemptKeys=['state','operation_action','cloud_idempotency_key','contact_version','expected_revision','expected_contact_revision','created_at','updated_at'];
const deliveryKeys=['contract','storage_scope','authenticated_actor','state','operation_id','original_action','original_key','original_execution_confirmed','read_only','mutation_committed','auto_retry','replayed','provider_configured','live_kms_verified','contact_available','contact','server_release_recorded','plaintext_replayed','contact_values','cloud_kms_requested','current_consent_valid','current_channel_status','platform_provenance_verified','consent_independently_verified','customer_contacted_verified','financial_receipt_verified','verified_cash_cents','verified_paid_cents','retention_configured','channel_binding_state','permissions'];
const contactKeys=['contact_version','revision','has_phone','has_wechat','created_at','expires_at','revoked_at'];
const receiptKeys=['contract','read_only','mutation_committed','storage_scope','authenticated_actor','observed_at','operation_action','idempotency_key','state','original_execution_confirmed','original_operation','current_handoff','auto_retry','platform_delivery_verified','settlement_active','financial_receipt_verified','cooperation_policy_verified','verified_cash_cents','verified_paid_commission_cents'];
const originalKeys=['channel_id','revision','historical_status','occurred_at','historical_event_self_hash_verified','full_historical_chain_verified'];
const receiptCurrentKeys=['channel_id','revision','status','current_consent_valid','historical_resource_receipt_recorded','receipt_evidence_independently_verified'];
const falseFlags=['auto_retry','plaintext_cached','cross_machine_delivery_verified','platform_requests_started','ai_provider_called','financial_receipt_verified'];
const validValues=v=>exact(v,['phone','wechat'])&&typeof v.phone==='string'&&typeof v.wechat==='string'&&!!(v.phone||v.wechat)&&(!v.phone||/^\+?[0-9]{7,15}$/.test(v.phone))&&(!v.wechat||/^[A-Za-z][A-Za-z0-9_-]{5,29}$/.test(v.wechat));
export function companyContactScope(context={}){
  // Epoch distinguishes logout/relogin by the same actor. No token or contact values.
  return JSON.stringify([context.user,context.deviceId,context.deviceGeneration,context.cloudEpoch,context.localWorkspace,context.companyId,context.environmentId,context.cloudCompanyId,context.cloudEnvironmentId,context.endpoint]);
}
export function checkedCompanyContact(value,{action,operationAction,channelId,actor,recipientId=null,purpose=null,previous=null,request=null}={}){
  const fail=()=>{throw Error('联系方式回执范围或证据格式未通过核对；保留原操作，暂勿重发。');};
  const operation=action===GET?operationAction:action;
  if(!Object.hasOwn(cloudActions,operation)||!exact(value,top)||value.contract!=='local_company_contact_delivery_v1'||value.storage_scope!=='local_bridge_company_server_contact_vault'||value.channel_id!==channelId||!channel(channelId)||!stamp(value.observed_at)||!['not_attempted','unknown','recorded'].includes(value.state)||!bool(value.read_only)||!bool(value.mutation_committed)||!bool(value.cloud_requested)||falseFlags.some(k=>value[k]!==false)||value.verified_cash_cents!==null||value.verified_paid_commission_cents!==null)fail();
  if(value.read_only?(value.action!==GET||value.mutation_committed!==false):(action===GET||value.action!==action||value.mutation_committed!==true||value.state!=='recorded'))fail();
  const item=value.current;
  if(!exact(item,itemKeys)||item.channel_id!==channelId||!hex(item.customer_scope_hash)||!hex(item.source_actor_scope_hash)||!['xiaohongshu','douyin','zhihu','wechat_channels','weixin','bilibili','bili','kuaishou'].includes(item.platform)||!identifier(item.recipient_id)||!label(item.recipient_name)||!label(item.purpose)||!integer(item.revision)||item.revision<1||!states.includes(item.status)||!bool(item.current_consent_valid)||!bool(item.can_receipt)||!bool(item.historical_resource_receipt_recorded)||item.receipt_evidence_independently_verified!==false||item.contact_delivery!=='platform_reference_only'||!stamp(item.created_at)||!stamp(item.updated_at)||item.updated_at<item.created_at||item.status==='withdrawn'&&item.current_consent_valid||recipientId&&item.recipient_id!==recipientId||purpose&&item.purpose!==purpose||request&&item.revision<request.expected_revision)fail();
  const a=value.attempt;
  if(a!==null&&(!exact(a,attemptKeys)||!['unknown','recorded'].includes(a.state)||a.operation_action!==operation||!hex(a.cloud_idempotency_key)||!integer(a.expected_revision)||a.expected_revision<1||a.expected_revision>item.revision||!stamp(a.created_at)||!stamp(a.updated_at)||a.updated_at<a.created_at||(operation===WITHDRAW?(a.contact_version!==null||a.expected_contact_revision!==null):(!version(a.contact_version)||!integer(a.expected_contact_revision)||a.expected_contact_revision<1))))fail();
  if(previous&&(a===null||['operation_action','cloud_idempotency_key','contact_version','expected_revision','expected_contact_revision'].some(k=>a[k]!==previous[k])))fail();
  if(request&&a&&(['expected_revision','expected_contact_revision','contact_version'].some(k=>Object.hasOwn(request,k)&&request[k]!==a[k])||operation===PUBLISH&&a.contact_version!==request.contact_reference.slice(8)+'_'+request.expected_contact_revision))fail();
  const d=value.delivery,r=value.withdrawal_receipt;
  if(operation!==WITHDRAW){
    if(r!==null||!exact(d,deliveryKeys)||d.contract!=='company_contact_delivery_v1'||d.storage_scope!=='company_server_contact_vault'||d.authenticated_actor!==actor||!['not_recorded','unknown','recorded'].includes(d.state)||!['unbound','unknown','recorded'].includes(d.channel_binding_state)||!states.includes(d.current_channel_status)||d.current_channel_status!==item.status||d.current_consent_valid!==item.current_consent_valid||!exact(d.permissions,['can_publish','can_reveal','can_withdraw'])||Object.values(d.permissions).some(v=>!bool(v))||['read_only','replayed','provider_configured','retention_configured','contact_available','server_release_recorded','cloud_kms_requested'].some(k=>!bool(d[k]))||['auto_retry','live_kms_verified','plaintext_replayed','platform_provenance_verified','consent_independently_verified','customer_contacted_verified','financial_receipt_verified'].some(k=>d[k]!==false)||d.verified_cash_cents!==null||d.verified_paid_cents!==null)fail();
    if(d.state==='not_recorded'){if(['operation_id','original_action','original_key','original_execution_confirmed'].some(k=>d[k]!==null))fail();}
    else if(!hex(d.operation_id)||d.original_action!==cloudActions[operation]||!hex(d.original_key)||a&&a.cloud_idempotency_key!==d.original_key||d.original_execution_confirmed!==(d.state==='recorded'?true:null))fail();
    if(d.server_release_recorded!==(d.state==='recorded'&&operation===REVEAL)||d.read_only&&(d.mutation_committed!==false||d.contact_values!==null||d.cloud_kms_requested!==false))fail();
    if(value.read_only&&(d.read_only!==true||d.contact_values!==null)||!value.read_only&&(d.read_only!==false||d.mutation_committed!==true||d.state!=='recorded'||d.replayed!==false||d.cloud_kms_requested!==true))fail();
    const c=d.contact;
    if(c!==null&&(!exact(c,contactKeys)||!version(c.contact_version)||!integer(c.revision)||c.revision<1||!bool(c.has_phone)||!bool(c.has_wechat)||!stamp(c.created_at)||!stamp(c.expires_at)||c.expires_at<c.created_at||c.revoked_at!==null&&(!stamp(c.revoked_at)||c.revoked_at<c.created_at)))fail();
    if((c!==null)!==(d.channel_binding_state==='recorded')||d.contact_available&&(!c||c.revoked_at!==null||!d.current_consent_valid||!['submitted','accepted'].includes(d.current_channel_status))||d.permissions.can_publish&&(!d.provider_configured||!d.retention_configured||d.channel_binding_state!=='unbound'||!d.current_consent_valid)||d.permissions.can_reveal&&(!d.provider_configured||!d.contact_available||d.state!=='not_recorded'))fail();
    if(!value.read_only&&operation===REVEAL){if(d.replayed!==false||!validValues(d.contact_values)||!d.server_release_recorded||!d.contact_available||!c||c.contact_version!==a?.contact_version||c.revision!==a?.expected_contact_revision)fail();}
    else if(d.contact_values!==null)fail();
    if(value.state!==(d.state==='recorded'?'recorded':a||d.state==='unknown'?'unknown':'not_attempted'))fail();
  }else{
    if(d!==null||!exact(r,receiptKeys)||r.contract!=='handoff_operation_receipt_v1'||r.storage_scope!=='company_server_ledger'||r.authenticated_actor!==actor||r.operation_action!=='acquisition_handoff_withdraw'||!hex(r.idempotency_key)||a&&a.cloud_idempotency_key!==r.idempotency_key||!stamp(r.observed_at)||r.read_only!==true||r.mutation_committed!==false||['auto_retry','platform_delivery_verified','settlement_active','financial_receipt_verified','cooperation_policy_verified'].some(k=>r[k]!==false)||r.verified_cash_cents!==null||r.verified_paid_commission_cents!==null||!['recorded','unknown'].includes(r.state))fail();
    if(r.state==='unknown'){if(r.original_operation!==null||r.current_handoff!==null||r.original_execution_confirmed!==null||value.state!=='unknown')fail();}
    else{
      const o=r.original_operation,c=r.current_handoff;
      if(!exact(o,originalKeys)||o.channel_id!==channelId||!integer(o.revision)||o.revision<1||a&&o.revision!==a.expected_revision+1||o.historical_status!=='withdrawn'||!stamp(o.occurred_at)||o.historical_event_self_hash_verified!==true||o.full_historical_chain_verified!==false||!exact(c,receiptCurrentKeys)||c.channel_id!==channelId||!integer(c.revision)||c.revision<o.revision||c.revision!==item.revision||c.status!==item.status||c.current_consent_valid!==item.current_consent_valid||c.historical_resource_receipt_recorded!==item.historical_resource_receipt_recorded||c.receipt_evidence_independently_verified!==false||r.original_execution_confirmed!==true||value.state!=='recorded')fail();
    }
  }
  if(!value.read_only&&(!a||a.state!=='recorded'||!value.cloud_requested))fail();
  return value;
}
const node=(tag,text='',className='')=>{const result=document.createElement(tag);result.textContent=String(text);if(className)result.className=className;return result;};
const scrub=value=>{if(value?.delivery?.contact_values){value.delivery.contact_values.phone='';value.delivery.contact_values.wechat='';value.delivery.contact_values=null;}};
export function createCompanyContactDeliveryUI({createDialog,execute,getContext}){
  let active=null,generation=0,disposed=false;
  const held=new Set(); // Opaque scope/channel/action only; no values or payloads.
  const clearSensitive=()=>{generation++;const old=active;active=null;if(old){old.release();old.root.replaceChildren();old.root.close?.();old.root.remove();}};
  async function open(options,{accept=()=>true}={}){
    clearSensitive();if(disposed||!options||!channel(options.channelId)||!['source','receiver'].includes(options.mode)||typeof accept!=='function')return false;
    const context=getContext()||{},owner=companyContactScope(context),actor=context.user?.username;
    if(context.localWorkspace!==true||!actor||!context.deviceId||!context.companyId||!context.environmentId||!Number.isSafeInteger(context.cloudEpoch)){return false;}
    if(!accept())return false;
    const fixed={...options},view=createDialog(fixed.mode==='source'?'公司联系方式交付与授权撤回':'本人一次查看联系方式',{onClose:()=>{if(active?.root===view.root)clearSensitive();}}),ticket=++generation;
    let metadata=null,contactMetadata=null,operation=fixed.mode==='source'?PUBLISH:REVEAL,readGeneration=0,writing=false,ram=null;
    const pane=node('section','','upgrade-operation-form'),valuesHost=node('section','','upgrade-operation-form');valuesHost.hidden=true;view.root.append(node('p','此处核对公司联系方式授权。平台来源、独立接收、客户回应、成交与回款仍分别核验。配置就绪不等于真实 KMS 已核验。','upgrade-muted'),pane,valuesHost);
    let watch=null;
    active={root:view.root,release(){if(watch!==null)clearInterval(watch);watch=null;readGeneration++;ram=null;metadata=null;contactMetadata=null;valuesHost.textContent='';valuesHost.hidden=true;}};
    const current=()=>{let valid=false;try{valid=!disposed&&active?.root===view.root&&generation===ticket&&view.current()&&companyContactScope(getContext()||{})===owner&&accept()===true;}catch{}if(!valid&&active?.root===view.root)clearSensitive();return valid;};
    const report=(text,error=false)=>{if(current()){view.status.textContent=text;view.status.dataset.state=error?'error':'ready';}};
    const button=(text,fn)=>{const b=node('button',text,'secondary');b.type='button';b.onclick=()=>void fn(b);pane.append(b);return b;};
    const lock=()=>JSON.stringify([owner,fixed.channelId,operation]);
    const clearRam=()=>{ram=null;valuesHost.textContent='';valuesHost.hidden=true;};
    async function call(action,data,fresh){
      let response;
      try{
        response=await execute(action,data);if(!fresh())return null;
        if(response?.status!=='succeeded'||!response.result)throw Error('本次回执暂不可读。');
        const value=checkedCompanyContact(response.result,{action,operationAction:operation,channelId:fixed.channelId,actor,recipientId:fixed.recipientId,purpose:fixed.purpose,previous:metadata?.attempt,request:action===GET?null:data});
        if(!fresh())return null;
        const released=value.delivery?.contact_values;
        if(released)ram={phone:released.phone,[REDACTED:wechat_id].wechat};
        // Ordinary state retains only the whitelisted metadata; never the response values.
        const safe={...value,delivery:value.delivery?{...value.delivery,contact_values:null}:null};scrub(response.result);
        return safe;
      }finally{scrub(response?.result);}
    }
    async function readOriginal(next=operation){
      if(!current()||writing)return;clearRam();operation=next;metadata=null;contactMetadata=null;const read=++readGeneration,fresh=()=>current()&&read===readGeneration;pane.replaceChildren();report('正在按本人原操作读取授权与元数据…');
      try{
        const value=await call(GET,{channel_id:fixed.channelId,operation_action:operation},fresh);if(!value)return;metadata=value;
        if(operation===PUBLISH&&value.state==='not_attempted'&&value.delivery?.permissions.can_publish&&/^contact:[a-f0-9]{32}$/.test(fixed.contactReference||'')){
          const answer=await execute('contact_read',{contact_reference:fixed.contactReference,reveal:false});if(!fresh())return;
          const c=answer?.status==='succeeded'?answer.result:null;
          if(!c||c.contact_reference!==fixed.contactReference||fixed.leadId&&c.lead_id!==fixed.leadId||c.recipient_id!==value.current.recipient_id||c.purpose!==value.current.purpose||!integer(c.revision)||c.revision<1||c.revoked_at!==null||c.storage_scope!=='local_current_windows_user'||c.consent?.status!=='granted'||c.consent.evidence_source!=='operator_recorded'||c.consent.independently_verified!==false)throw Error('本机受保护联系人范围需重新核对。');
          contactMetadata={revision:c.revision};
        }
        if(fresh())render();
      }catch{if(fresh()){pane.replaceChildren();report('原联系方式摘要暂不可读；未自动重发。',true);button('核对原联系方式操作',()=>readOriginal());}}
    }
    function render(){
      if(!current()||!metadata)return;pane.replaceChildren();const item=metadata.current,d=metadata.delivery;
      pane.append(node('p',`${item.recipient_name} · ${item.purpose}`),node('p',item.current_consent_valid?'公司当前客户授权记录有效。':'公司当前客户授权已停止，历史操作继续保留。','upgrade-muted'));
      if(d)pane.append(node('p',`服务端配置：${d.provider_configured?'提供者已配置':'提供者未就绪'}；${d.retention_configured?'保留期限已配置':'保留期限未就绪'}。真实 KMS 与跨实体电脑交付尚未验收。`,'upgrade-muted'));
      if(metadata.attempt)pane.append(node('p',`本人原操作编号：${metadata.attempt.cloud_idempotency_key}`,'upgrade-muted'));
      const blocked=held.has(lock())||metadata.attempt!==null||metadata.state==='recorded';
      if(metadata.state==='recorded')report(operation===REVEAL?'公司曾登记本人查看；原号核对不会再次返回明文。':operation===WITHDRAW?'公司已登记撤回客户交接授权，历史记录保留。':'公司已登记联系方式发布；客户联系与成交仍待核验。');
      else if(blocked)report('原操作结果仍待核对，请保留原号；不会重复提交。',true);
      else report(operation===WITHDRAW?'核对当前授权后，可明确发起安全撤回。过去缺回执仍不能证明未执行。':'当前只读取了原操作元数据，尚未执行本次动作。');
      button('核对原联系方式操作',()=>readOriginal());
      if(fixed.mode==='source')button(operation===WITHDRAW?'返回联系方式发布':'撤回公司交接客户授权',()=>readOriginal(operation===WITHDRAW?PUBLISH:WITHDRAW));
      let eligible=!blocked&&item.current_consent_valid;
      if(operation===PUBLISH)eligible=eligible&&metadata.state==='not_attempted'&&d?.permissions.can_publish===true&&d.provider_configured&&d.retention_configured&&!!contactMetadata;
      if(operation===REVEAL)eligible=eligible&&metadata.state==='not_attempted'&&d?.permissions.can_reveal===true&&!!d.contact;
      if(!eligible){if(operation===PUBLISH&&!fixed.contactReference)pane.append(node('p','此交接未提供本机受保护联系方式引用；请先在原客户交接中保存已同意的联系方式。','upgrade-muted'));return;}
      const confirm=node('label'),check=node('input');check.type='checkbox';check.checked=false;
      const copy=operation===PUBLISH?'我确认此原受保护联系方式用于上述接收方和用途，明确发布到公司。':operation===REVEAL?'我确认本人获权使用此联系方式；明确查看一次，关闭后只可核对元数据。':'我确认客户撤回公司交接授权；这会阻断后续交付和查看，历史记录保留。';confirm.append(check,node('span',copy));pane.append(confirm);
      const submit=button(operation===PUBLISH?'确认发布联系方式':operation===REVEAL?'确认一次查看':'确认撤回公司交接授权',()=>write(check));submit.disabled=true;check.addEventListener('change',()=>{if(current())submit.disabled=writing||!check.checked;});
    }
    async function write(check){
      if(!current()||writing||!check.checked||!metadata||held.has(lock()))return;
      const action=operation,item=metadata.current,data={channel_id:fixed.channelId,expected_revision:item.revision};
      if(action===PUBLISH){if(!contactMetadata)return;data.contact_reference=fixed.contactReference;data.expected_contact_revision=contactMetadata.revision;}
      if(action===REVEAL){if(!metadata.delivery?.contact)return;data.contact_version=metadata.delivery.contact.contact_version;data.expected_contact_revision=metadata.delivery.contact.revision;}
      held.add(lock());writing=true;clearRam();for(const b of pane.querySelectorAll('button,input'))b.disabled=true;report('正在执行本次明确操作；结果不明时仅核对原号…');
      const read=++readGeneration,fresh=()=>current()&&read===readGeneration;
      try{
        const value=await call(action,data,fresh);if(!value)return;metadata=value;writing=false;render();
        if(action===REVEAL&&ram&&fresh()){
          valuesHost.hidden=false;valuesHost.append(node('h3','本次本人查看（仅当前窗口）'));for(const [name,key]of [['电话','phone'],['微信','wechat']])if(ram[key])valuesHost.append(node('p',`${name}：${ram[key]}`));
          report('本次明确查看已返回。关闭、离开或范围变化即清理；不自动联系客户。');
          const hide=node('button','清理本次明文','secondary');hide.type='button';hide.onclick=()=>{clearRam();report('本次明文已从当前界面与引用清理，原号不会再次返回明文。');};valuesHost.append(hide);
        }
      }catch{if(fresh()){writing=false;clearRam();pane.replaceChildren();report('原操作结果未确认，继续保留原号；请只核对元数据，暂勿重发。',true);button('核对原联系方式操作',()=>readOriginal());}}
    }
    watch=setInterval(()=>{current();},250);
    await readOriginal();return current();
  }
  return {open,clearSensitive,reset:clearSensitive,dispose(){disposed=true;clearSensitive();}};
}
