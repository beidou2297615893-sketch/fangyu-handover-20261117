from pathlib import Path
import hashlib,json,shutil
W=Path(__file__).resolve().parent;P=W.parents[1]
names=['work/shared-backend-integration/platform_runtime.py',
 'work/ui-native-r57/workbench_backend.py','work/ui-native-r57/customer_workbench.py',
 'work/ui-native-r57/reply_workbench.py','work/ui-native-r57/ui_native_host.py',
 'work/ui-native-r57/freeze_ui.py','work/ui-runtime-r55/src/assistant/saved_media.py',
 'work/ui-approved-implementation/ui-preview/app.mjs',
 'work/ui-approved-implementation/ui-preview/avatar.mjs',
 'work/ui-approved-implementation/ui-preview/pages/reply-connected.mjs',
 'work/ui-approved-implementation/ui-preview/pages/customers.mjs',
 'work/ui-approved-implementation/ui-preview/pages/management-rules.mjs']
records={}
for name in names:
 source=P/name;before=W/'before'/name
 if not source.is_file():continue
 before.parent.mkdir(parents=True,exist_ok=True)
 if not before.exists():shutil.copy2(source,before)
 records[name]={'before_sha256':hashlib.sha256(before.read_bytes()).hexdigest()}
(W/'SOURCE-BASELINE.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps({'backed_up_files':len(records)},ensure_ascii=False))
