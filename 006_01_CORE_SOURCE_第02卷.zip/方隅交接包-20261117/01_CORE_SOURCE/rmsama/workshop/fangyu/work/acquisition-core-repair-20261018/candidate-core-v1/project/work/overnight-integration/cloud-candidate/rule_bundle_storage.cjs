'use strict';
// Lossless storage only. The public import/export bytes and digests stay JSON.
const zlib=require('node:zlib'),crypto=require('node:crypto'),{isUtf8}=require('node:buffer');
const MAX_BYTES=8388608,MAX_COMPRESSED=MAX_BYTES+65536,SCHEMA='fangyu-rule-bundle-storage/1';
// One validated representation only: at most8MiB decoded plus bounded base64.
// Every call still checks the full envelope; hits require exact immutable wire
// text/metadata and rehash bytes so a mutable Buffer caller cannot poison it.
let decodedCache=null;
const sha=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const invalid=()=>{throw new Error('RULE_BUNDLE_STORED_CONTENT_INVALID');};
function pack(bytes){
 if(!Buffer.isBuffer(bytes)||bytes.length<2||bytes.length>MAX_BYTES)invalid();
 const compressed=zlib.gzipSync(bytes,{level:6});if(compressed.length>MAX_COMPRESSED)invalid();
 return {schema:SCHEMA,encoding:'gzip+base64',bytes:bytes.length,sha256:sha(bytes),dataBase64:compressed.toString('base64')};
}
function unpackBytes(value){
 if(!value||Object.getPrototypeOf(value)!==Object.prototype||Object.keys(value).sort().join(',')!=='bytes,dataBase64,encoding,schema,sha256'
  ||value.schema!==SCHEMA||value.encoding!=='gzip+base64'||!Number.isInteger(value.bytes)||value.bytes<2||value.bytes>MAX_BYTES
  ||typeof value.sha256!=='string'||!/^[a-f0-9]{64}$/.test(value.sha256)||typeof value.dataBase64!=='string'
  ||value.dataBase64.length>Math.ceil(MAX_COMPRESSED/3)*4)invalid();
 if(decodedCache&&decodedCache.bytes===value.bytes&&decodedCache.sha256===value.sha256
  &&decodedCache.dataBase64===value.dataBase64){
  if(decodedCache.decoded.length===value.bytes&&sha(decodedCache.decoded)===value.sha256)return decodedCache.decoded;
  decodedCache=null;
 }
 const compressed=Buffer.from(value.dataBase64,'base64');
 if(compressed.toString('base64')!==value.dataBase64||compressed.length>MAX_COMPRESSED)invalid();
 let bytes;try{bytes=zlib.gunzipSync(compressed,{maxOutputLength:MAX_BYTES});}catch{invalid();}
 if(bytes.length!==value.bytes||sha(bytes)!==value.sha256)invalid();
 // Representation validation only. JSON authority belongs to the route's
 // immutable validated-canonical capsule; callers without it must use unpack.
 if(typeof isUtf8==='function'){if(!isUtf8(bytes))invalid();}
 else {try{new TextDecoder('utf-8',{fatal:true}).decode(bytes);}catch{invalid();}}
 decodedCache={bytes:value.bytes,sha256:value.sha256,dataBase64:value.dataBase64,decoded:bytes};
 return bytes;
}
function unpack(value){
 const bytes=unpackBytes(value);
 try{return JSON.parse(bytes.toString('utf8'));}catch{invalid();}
}
function readBundle(row){
 if(!row||(!row.bundle&&!row.bundle_storage)||row.bundle&&row.bundle_storage)invalid();
 // Existing uncompressed versions remain readable; all new writes are packed.
 return row.bundle_storage?unpack(row.bundle_storage):structuredClone(row.bundle);
}
module.exports={pack,unpack,unpackBytes,readBundle,MAX_BYTES,MAX_COMPRESSED,SCHEMA};
