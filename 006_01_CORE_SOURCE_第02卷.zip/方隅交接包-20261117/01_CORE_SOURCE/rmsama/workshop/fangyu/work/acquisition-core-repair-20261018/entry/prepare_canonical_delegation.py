"""Prepare (not install) a reversible canonical entry for the validated closure.

Reuse the original freeze tool's pin/read/log/error handling. The only launcher
adaptation selects the fixed complete customer project while keeping original
installation state. Original and candidate workspace declarations must match.
No business construction, login, cloud mutation or compiled CLI execution.
"""
from pathlib import Path
import datetime
import hashlib
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
P = HERE.parents[2]
NATIVE = P / 'work/ui-native-r57'
OUT = P / 'work/acquisition-core-repair-20261018/candidate-core-v4'
PROJECT = OUT / 'project'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


def main():
    staged = json.loads((OUT / 'STAGED.json').read_text('utf-8'))
    pins = json.loads((OUT / 'UNIFIED-PINS.json').read_text('utf-8'))
    assert len(pins['files']) == 2216
    for item in pins['files']:
        path = PROJECT / item['path']
        assert path.stat().st_size == item['bytes'] and sha(path).lower() == item['sha256'].lower(), item['path']
    gui = json.loads((HERE.parent / 'GUI-RESULT.json').read_text('utf-8'))
    assert gui['status']=='PASS_CHANGED_SCOPE_GUI' and gui['release']==staged['release_id']
    assert gui['browser_verified'] and gui['isolated_native_verified']
    assert gui['real_platform_calls']==0 and gui['paid_ai_calls']==0
    release = Path(staged['release'])
    assert sha(release / 'RELEASE.json') == staged['manifest_sha256'].upper()
    manifest = json.loads((release / 'RELEASE.json').read_text('utf-8'))
    files = {item['path']: item for item in manifest['files']}
    binding = NATIVE / 'state/production-workspace.json'
    candidate_binding = PROJECT / 'work/ui-native-r57/state/production-workspace.json'
    assert binding.read_bytes() == candidate_binding.read_bytes()
    spec = importlib.util.spec_from_file_location('original_freeze_source_for_delegation', NATIVE / 'freeze_ui.py')
    freeze = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(freeze)
    original = freeze.launcher_source(staged['release_id'], staged['manifest_sha256'],
        files['ui_native_host.py']['sha256'], files['lifecycle_log.py']['sha256'])
    original_release = "RELEASE = ROOT / 'releases/" + staged['release_id'] + "'"
    replacement = ("PROJECT_ROOT = ROOT.parent.parent / 'work/acquisition-core-repair-20261018/candidate-core-v4/project'\n"
        "RELEASE = PROJECT_ROOT / 'work/ui-native-r57/releases/" + staged['release_id'] + "'\n"
        "BINDING_SHA256 = '" + sha(binding) + "'")
    assert original.count(original_release) == 1
    body = original.replace(original_release, replacement)
    assert body.count('project_root=ROOT.parent.parent') == 1
    body = body.replace('project_root=ROOT.parent.parent', 'project_root=PROJECT_ROOT')
    marker = "        pinned(RELEASE / 'RELEASE.json', MANIFEST_SHA256)"
    assert body.count(marker) == 1
    body = body.replace(marker,
        "        pinned(ROOT / 'state/production-workspace.json', BINDING_SHA256)\n"
        "        pinned(PROJECT_ROOT / 'work/ui-native-r57/state/production-workspace.json', BINDING_SHA256)\n" + marker)
    compile(body, 'run_workbench.py', 'exec')
    candidate = NATIVE / ('run_delegated_candidate.' + staged['release_id'] + '.py')
    with candidate.open('xb') as stream:
        stream.write(body.encode('utf-8'))
    report = {
        'status': 'PREPARED_NOT_INSTALLED',
        'at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'release_id': staged['release_id'], 'release': str(release),
        'manifest_sha256': staged['manifest_sha256'],
        'launcher': str(candidate), 'launcher_sha256': sha(candidate),
        'canonical_launcher': str(NATIVE / 'run_workbench.py'),
        'expected_previous_launcher_sha256': sha(NATIVE / 'run_workbench.py'),
        'expected_previous_frozen_sha256': sha(NATIVE / 'FROZEN.json'),
        'original_freeze_tool_sha256': sha(NATIVE / 'freeze_ui.py'),
        'full_closure_files_verified': len(pins['files']),
        'full_closure_manifest_sha256': sha(OUT / 'UNIFIED-PINS.json'),
        'runtime_project_root': str(PROJECT), 'installation_state_root': str(NATIVE / 'state'),
        'workspace_binding_sha256': sha(binding),
        'workspace_resolution': 'unchanged resolver, matching original and candidate declaration, no explicit data_dir override',
        'workspace_binding_matches_original': True,
        'original_native_business_this_batch': 'SKIPPED_no_real_auth_or_platform_replay',
        'changed_scope_gui_evidence': str(HERE.parent / 'GUI-RESULT.json'),
        'installed': False, 'original_company_changed': False,
        'old_90a_and_old_CLI_changed': False,
        'production_cloud_activation': False, 'production_pin_acceptance': False,
        'component_use_policy': 'pending',
        'compiled_CLI_executed': False,
        'external_platform_risk_pauses_changed': False,
        'purpose': 'local original desktop entry only; no installer, release approval, platform permission or commercial distribution claim',
    }
    (HERE / 'CANONICAL-DELEGATION-PREPARED.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', 'utf-8')
    print(json.dumps({'status': report['status'], 'launcher': str(candidate), 'launcher_sha256': report['launcher_sha256'],
                      'files_verified': len(pins['files'])}, ensure_ascii=False))


if __name__ == '__main__':
    main()
