'use strict';
// Only loopback fixture IO. Real copied cloud service, independent memory store.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const http=require('node:http'),net=require('node:net'),dns=require('node:dns'),cp=require('node:child_process');
const run=path.resolve(process.argv[2]||'');
if(!run||!fs.statSync(run).isDirectory()||path.basename(path.dirname(run))!=='runs')throw Error('owned_run_required');
const key=fs.readFileSync(path.join(run,'cloud-bridge.key'),'utf8');
const blocked=[];
function deny(name){blocked.push(name);throw Error('fixture_denied_'+name);}
function own(p){if(typeof p==='number')return;const q=path.resolve(String(p));if(q!==run&&!q.startsWith(run+path.sep))deny('outside_write');}
for(const name of ['writeFileSync','writeFile','appendFileSync','appendFile','mkdirSync','mkdir','unlinkSync','unlink','rmSync','rm','rmdirSync','rmdir','truncateSync','truncate','chmodSync','chmod']){
 const old=fs[name];if(old)fs[name]=function(p,...args){own(p);return old.call(this,p,...args);};
}
for(const name of ['renameSync','rename','copyFileSync','copyFile']){
 const old=fs[name];fs[name]=function(a,b,...args){own(a);own(b);return old.call(this,a,b,...args);};
}
for(const name of ['spawn','spawnSync','exec','execSync','execFile','execFileSync','fork'])cp[name]=()=>deny('child_process');
const connect=net.Socket.prototype.connect;
net.Socket.prototype.connect=function(...args){const a=args[0],host=typeof a==='object'?a.host:args[1];if(host!=='127.0.0.1'&&host!=='::1')deny('external_socket');return connect.apply(this,args);};
for(const name of ['lookup','resolve','resolve4','resolve6','reverse']){const old=dns[name];dns[name]=function(host,...args){if(host!=='127.0.0.1'&&host!=='::1')deny('external_dns');return old.call(this,host,...args);};}
global.fetch=()=>Promise.reject(Error('fixture_denied_fetch'));
const source=path.join(run,'cloud-source');
const {createService}=require(path.join(source,'service.cjs'));
const {hash,COMPANY}=require(path.join(source,'store_config.cjs'));
const compiled=JSON.parse(fs.readFileSync(path.join(run,'central-fixture-input.json'),'utf8').replace(/^\uFEFF/,''));
if(compiled.manifest.stores.length!==14)throw Error('fourteen_stores_required');
const state={companyId:COMPANY,revision:1,users:[{username:'fixture-admin',role:'admin'},{username:'fixture-operator',role:'operator',store_id:compiled.manifest.stores[0].id}],sessions:[],devices:[],audit:[],attempts:{},items:[],rememberedDevices:[]};
const docs=new Map([compiled.manifest,...compiled.documents].map(v=>[v._id,structuredClone(v)]));
let mutations=0,operations=[],serial=Promise.resolve();
const store={readStoreConfigState:async()=>structuredClone(state),readStoreConfigDocument:async id=>structuredClone(docs.get(id)||null),readRuleBundleDocument:async id=>structuredClone(docs.get(id)||null),
 transaction:async fn=>(await fn(structuredClone(state),{})).result,
 ruleBundleTransaction:fn=>{const operation=serial.then(async()=>{const staged=new Map();const result=await fn({state:async()=>structuredClone(state),get:async id=>structuredClone(docs.get(id)||null),set:async(id,value)=>staged.set(id,structuredClone(value))});for(const[id,value]of staged)docs.set(id,value);mutations++;return result;});serial=operation.catch(()=>{});return operation;}};
const service=createService({store,companyId:COMPANY,environmentId:'overnight-fixture'});
let closing=false;
const server=http.createServer(async(req,res)=>{
 try{
  if(req.method==='GET'&&req.url==='/health'){res.writeHead(200,{'Content-Type':'application/json'});res.end(JSON.stringify({state:'ready',stores:14,mutations,operations:operations.length,profile:'isolated-memory'}));return;}
  if(req.method!=='POST'||req.url!=='/'||req.headers['x-fixture-bridge']!==key){res.writeHead(403);res.end('{"code":"fixture_bridge_forbidden"}');return;}
  const chunks=[];let size=0;for await(const c of req){size+=c.length;if(size>10000000)throw Error('oversize');chunks.push(c);}
  const input=JSON.parse(Buffer.concat(chunks));const op=input.data?.operation;
  if(op!=='store_config_read'&&!(typeof op==='string'&&op.startsWith('rule_bundle_')))throw Error('fixture_operation_rejected');
  if(!['fixture-admin','fixture-operator'].includes(input.name)||typeof input.token!=='string'||input.token.length>256)throw Error('fixture_actor_rejected');
  if(!state.sessions.some(s=>s.digest===hash(input.token)))state.sessions.push({username:input.name,digest:hash(input.token),expires:Math.floor(Date.now()/1000)+36000});
  operations.push(op);const out=await service(input.data,input.token);res.writeHead(out.status,{'Content-Type':'application/json'});res.end(JSON.stringify(out.data));
 }catch(e){res.writeHead(500,{'Content-Type':'application/json'});res.end(JSON.stringify({code:'fixture_memory_adapter_failed',error:String(e).slice(0,180)}));}
});
server.listen(0,'127.0.0.1',function(){fs.writeFileSync(path.join(run,'CLOUD-PUBLIC.json'),JSON.stringify({port:this.address().port,pid:process.pid,profile:'isolated-memory',stores:14,realPlatformCalls:0}));});
const timer=setInterval(()=>{if(!closing&&fs.existsSync(path.join(run,'STOP'))){closing=true;clearInterval(timer);server.close(()=>{fs.writeFileSync(path.join(run,'CLOUD-CLOSED.json'),JSON.stringify({closed:true,operations,mutations,blocked,realPlatformCalls:0},null,2));});}},200);
