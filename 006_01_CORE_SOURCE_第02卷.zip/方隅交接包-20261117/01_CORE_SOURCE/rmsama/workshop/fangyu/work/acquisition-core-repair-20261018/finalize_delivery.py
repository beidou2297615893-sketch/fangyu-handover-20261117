from pathlib import Path
import json,hashlib,datetime,shutil
W=Path(__file__).resolve().parent;P=W.parents[1];H=P/'work/overnight-integration/continuation-20261018'
OUT=P/'outputs/核心获客修复';OUT.mkdir(exist_ok=True)
def read(p):return json.loads(p.read_text('utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n','utf-8')
staged=read(W/'candidate-core-v4/STAGED.json');gui=read(W/'GUI-RESULT.json');install=read(W/'entry/CANONICAL-DELEGATION-INSTALL.json')
assert gui['status']=='PASS_CHANGED_SCOPE_GUI' and gui['release']==staged['release_id']
check=read(W/'ORIGINAL-ENTRY-CHECK.log');assert check['status']=='PASS' and check['release_id']==staged['release_id']
active=read(P/'work/ui-native-r57/state/active.json');assert active['release']==staged['release_id'] and active['pid']==62880
assert sha(P/'work/ui-native-r57/run_workbench.py').upper()==install['targets'][0]['new_sha256']
assert sha(P/'work/ui-native-r57/FROZEN.json').upper()==install['targets'][1]['new_sha256']
assert sha(P/'work/app/company.json').upper()==install['company_sha256']
native={'status':'PASS_ORIGINAL_ENTRY_OPEN_LOGIN_ONLY','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'release':active['release'],'instance':active['instanceId'],'pid':active['pid'],'ports':[active['stablePort'],active['developmentPort']],
 'window':{'id':5772776,'title':'方隅工作台'},'visible_page':'employee_login','password_entered_by_agent':False,
 'employee_authentication_by_agent':False,'real_platform_task_resumed_by_agent':False,
 'recovery':'Externally supplied app recovery event; prior real and QA processes absent before one original-entry restore; no agent close/kill/restart of an existing real process.',
 'original_workspace_resolution':'same pinned state/binding/resolver; no explicit data_dir override',
 'full_real_database_byte_equality':'not_asserted','production_post_login_business':'SKIPPED_no_available_employee_session'}
write(W/'NATIVE-RESULT.json',native)
for name in ('GUI-NATIVE-REPLY.jpg','GUI-NATIVE-CUSTOMERS.jpg'):shutil.copy2(W/name,OUT/name)
changed=[]
for before in sorted((W/'before').rglob('*')):
 if not before.is_file():continue
 relative=before.relative_to(W/'before');source=P/relative
 if source.is_file() and sha(before)!=sha(source):changed.append({'path':relative.as_posix(),'before_sha256':sha(before),'after_sha256':sha(source)})
write(W/'PRODUCT-CHANGES.json',{'source_files':changed,'cli_rebuilt':False,'old_frozen_closures_modified':False,'original_company_changed':False})
result={'status':'LOCAL_CORE_FIX_DELIVERED_ORIGINAL_ENTRY_RESTORED_LOGIN_SKIPPED',
 'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'release':staged['release_id'],
 'active_complete_project':str(W/'candidate-core-v4/project'),'pins_sha256':sha(W/'candidate-core-v4/UNIFIED-PINS.json'),
 'files':2216,'parents':245,'frozen_files':117,'modified_product_source_files':len(changed),
 'installed_canonical_entry':True,'canonical_entry_check':'PASS','current_real_native':native,
 'complete_1000_integration':{'evidence':'CORE-AI-RENTAL-1000-RESULT.json','status':'PASS','pages':50,
   'rows':1000,'next_page_after_local_and_ai_saved':True,'real_platform_and_model':'fake callbacks; actual Core/SQLite/Rental/AIWorkflow/Attempts',
   'real_platform_or_customer_admission':'not_proven'},
 'gui':'GUI-RESULT.json; actual native/browser using synthetic data, images and cloud stand-in',
 'scope':'XHS continuous page controller, synchronous configured AI, prospects, saved real media routes, existing navigation/rules',
 'real_provider_calls_by_agent':0,'real_platform_acquisition_calls_by_agent':0,'real_external_sends':0,'reset_used':False,
 'original_strict_acceptance_all_proven':False,'component_use_policy':'pending_not_granted',
 'production_new_cloud_activation':False,'remote_companywide_rules_prompts_or_software_update_deployed':False,
 'remaining':['Production actual platform1000/paid DeepSeek not run; current employee login absent and skipped',
   'Production cloud rule activation and component-use remain pre-existing pending conditions',
   'Full remote companywide keyword/prompt/software updates not deployed; existing version/CAS paths retained',
   'Auxiliary Douyin single-batch behavior and upstream missing media fields not expanded by this XHS-focused controller fix',
   'Upstream standalone LICENSE/NOTICE originals gap retained'],
 'qa_cleanup':{'last_instance':'5e3870614b02489394be6351b6c48ea7','STOP_requested':True,
   'python51096_node63072_absent_observed':True,'python_exit_code':'unavailable_after_app_recovery',
   'final_closed_receipt':'absent_after_recovery; no exit0 claim','own_browser_tab_closed_before_recovery':True},
 'deadline_asia_shanghai':'2026-10-18 21:36:54','automation_12':'previous app NOT_FOUND; no replacement created',
 'master_progress_merge':'not_retried_prior_automatic_refusal','delivery_folder':str(OUT)}
write(W/'RESULT.json',result);write(OUT/'验收结果.json',result)
text=f'''# 方隅核心获客修复

原桌面入口已更新为 `{staged['release_id']}`，入口校验通过。本轮软件恢复事件后确认旧客户端已退出，现从原入口恢复一个新版窗口，停在员工登录页；没有代找密码、代登录或重放暂停采集。

## 已修复

- 小红书连续获客不再受原来10页、60秒、连续3批无新增的人为终止影响。默认新任务目标及日限额采用现有允许的1000条；达成目标、自然读完、本人暂停或实际平台拒绝仍会结束当前运行。
- 每批保存后先完成本地判断及已有企业AI工作流的结构化分析，再读取下一批。重用初版AI缓存、原请求/费用回执和结果校验，不另建一套模型接口。旧当前任务有已保存未分析评论时，明确继续先补分析；未确认费用不会重复提交。
- 修复千条本地分级写库时，账号权限检查另开连接造成的数据库锁冲突；权限检查与写入共用事务，账号改属、跨企业、删除仍被拒绝。
- 当前服务器提供的搜索词与排除词真正进入执行；回复和最新意向只显示有有效求租意向的候选，供给方/不相关/未知不会混入。客户清单保留历史记录与其明确状态。
- 接回保存的真实用户头像和原帖封面，经当前员工、门店、来源绑定的同源图片入口显示；回复右侧增加原帖标题、图片、来源入口、完整评论和判断依据。上游未返回图片的历史记录不能凭空补造。
- 获客、回复、客户、账号、管理保持五个同级入口。账号页可直接切回获客；管理分为获客规则与口吻。
- 管理页可查看完整精准/通勤词库、来源、当前排除词、权限内的五级本地标准及当前本机证据规则。“保存本门店方案”说明仅保存本机门店选择，开始时自动读取服务器最新有效词库。管理员中央规则文件入口和原有员工选方案权限保持；没有给员工新增中央写权限。

## 本轮验证

完整1000条、50批的真实Core/SQLite/租房判断/AI工作流/请求回执集成已通过，每个下一批读取前同时核对上一批判断和AI结果已保存；平台和模型回调均为合成返回，未付费、未实采。另有实际1000条本地写库与同事务账号改属/跨企业/删除拒绝验证。

实际原生与浏览器验收使用1000条合成记录：回复900名候选、100名供给方被排除；头像、原帖封面、完整评论尾标、客户详情、五个导航、规则来源和本机保存均已观察。截图中的人物与房间是夹具示意图，不是真人或真实房源；实际图片路由已产生5项受限媒体读取。没有重做旧无关导出、规则整库、CLI构建和全套GUI验收。

真实原任务先前错误为 `verification_required`，并非20条成功后必须停；旧last_batch20条全被日期筛除，不能当作本次20条新增。实际平台验证没有自动重放。本轮当前原生登录后的真实业务与真实付费DeepSeek调用均记为跳过。

## 尚未上线或尚未证明

生产新云规则未激活；组件实例用途条件仍pending，技术pin/编译/开源说明不等同用途批准。完整远程统一关键词、提示词和软件更新尚未部署，继续沿用已有服务器版本与CAS机制。此轮连续控制重点为小红书；抖音辅助仍保留原单批策略，不能说两平台均已完成实采千条验收。实际完整远端AI提示词未由当前公共接口返回，界面明确区分远端AI与本地标准。独立上游LICENSE/NOTICE原件缺口保留。

## 入口与证据

继续使用原桌面快捷方式。完整活动依赖目录不能作为临时文件清理：
`{W/'candidate-core-v4/project'}`

原入口：`{P/'work/ui-native-r57/run_workbench.py'}`。
本轮独立证据目录：`{W}`。同目录含RESULT、GUI-RESULT、NATIVE-RESULT、完整1000集成、RED/GREEN、独立审查与原入口两文件可恢复备份。原state/resolver/设备/数据/company、90a与旧CLI/旧完整载体均保留。

交付文件：`{OUT/'交付说明.md'}`。
所在文件夹：`{OUT}`。
'''
(OUT/'交付说明.md').write_text(text,'utf-8')
write(W/'PROGRESS.json',{**result,'next':'Local requested repair delivered; do not rebuild/retest unchanged work. Keep original login window; skip credentials. Only new human info/authorized condition change justifies further action.'})
(H/'NEXT.md').write_text(f'''# 本轮核心修复已本地交付，原入口已恢复新版；严格原总验收仍false
先只读W=work/acquisition-core-repair-20261018/RESULT.json、PROGRESS.json；它们优先于本轮旧checkpoint脚本，不重跑旧脚本、不读29.7MB聊天。

最终v4 release {staged['release_id']}，2216pins SHA {result['pins_sha256']} /245父依赖/117冻结；原入口fresh CAS已安装，候选与原入口--check均PASS。完整1000/50页实际Core+Rental+AI attempts（平台/模型fake）全过，原生/浏览器合成GUI与独立只读审查通过。头像/封面/回复900排100供给方/完整评论/客户/同级导航/实际词来源与权限管理已验。不重复已过测试、构建、GUI、截图、CLI查询；CLI未改不重编。

软件恢复事件后已确认旧原PID61924、QA51096/cloud63072均不在，QA最后无CLOSED/Python退出码，不能声称exit0；仅已写其精确STOP。原窗口不是agent主动关闭。为恢复用户软件，从已安装原入口启动唯一新窗口5772776，实际PID62880/instance{active['instanceId']}，production release v4，当前员工登录页，密码未输；未代登录/找凭据/扫码/验证码/重放真实采集。保留此窗口，缺会话业务SKIPPED，不询问。

严格原总验收false：生产新云规则未激活、真实平台千条/付费AI未运行、component-use pending、远端全prompt未返回、完整远程统一升级未部署、抖音辅助仍单批、上游独立LICENSE/NOTICE原件缺口。不要把mock1000/技术pin/原生启动当这些条件批准；不放宽UID/lease/license/未确认journal或其他owner/private用途。原verification_required未重放，原HTTP风险不清。

完整活动目录W/candidate-core-v4/project及旧90a/CLI/旧完整依赖都保留，不当临时目录清理；原state/resolver/设备/数据/company不变，无业务迁移。原入口备份W/entry/canonical-entry-before。独立交付P/outputs/核心获客修复/交付说明.md、验收结果.json。总控合并曾自动拒绝无理由，未换路径工具重试，仅独立证据。

若无本人新信息/已授权条件变化，无必要重复计算。准确截止仍2026-10-18 21:36:54 Asia/Shanghai，不重计；最近周窗剩84%、secondary未知不重测，不用reset；<=1%保存停并尝试PAUSED本心跳。automation-12曾NOT_FOUND，不另建替代、不声称有效/已暂停。完成收口不归档、不关闭当前真实客户端。仅实质新成果/失败/本人必要处理才通知。
''','utf-8')
b=read(H/'BATCH-RESULT.json');b.update(status=result['status'],checkpoint_at_utc=result['at_utc'],core_repair=result,current_result='work/acquisition-core-repair-20261018/RESULT.json',strict_original_acceptance_all_proven=False);write(H/'BATCH-RESULT.json',b)
hp=read(H/'UNIFIED-CHECKPOINT-PINS.json')
for n in ('NEXT.md','BATCH-RESULT.json'):hp[n]=sha(H/n)
write(H/'UNIFIED-CHECKPOINT-PINS.json',hp)
print(json.dumps({'status':result['status'],'modified_files':len(changed),'release':result['release'],'delivery':str(OUT),'original_window':5772776},ensure_ascii=False))
