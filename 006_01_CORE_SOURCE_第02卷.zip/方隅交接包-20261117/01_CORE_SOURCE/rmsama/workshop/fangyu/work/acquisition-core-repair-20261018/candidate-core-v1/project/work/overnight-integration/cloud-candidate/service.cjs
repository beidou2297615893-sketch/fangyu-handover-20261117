/* Dedicated-company CloudBase HTTP service. No platform credentials enter this API. */
const crypto = require('node:crypto');
const {createReadonlyRoutes}=require('./readonly_routes.cjs');
const {createRuleBundleRoutes,OPS:RULE_BUNDLE_OPS}=require('./rule_bundle.cjs');
const {handleDevices}=require('./devices.cjs');
const {MAX_BATCH, upsertBatch}=require('./shared_leads_v2.cjs');
const {SHARED_FEATURE_ENABLED}=require('./shared_feature.cjs');
const {createEnterpriseAi, OPERATIONS: AI_OPERATIONS}=require('./ai_enterprise.cjs');
const {createContactLedger, OPERATIONS: CONTACT_OPERATIONS}=require('./contact_ledger.cjs');
const CONTRACT = 'fangyu-workspace-v1';
const publicUser = u => ({username: u.username, role: u.role, disabled: !!u.disabled, can_reply: u.can_reply !== false});
const hash = value => crypto.createHash('sha256').update(value).digest('hex');
const ACCESS_SECONDS = 8 * 3600;
const REMEMBER_IDLE_SECONDS = 30 * 86400;
const REMEMBER_ABSOLUTE_SECONDS = 90 * 86400;
const validDeviceId = value => typeof value === 'string' && /^[A-Za-z0-9_-]{16,100}$/.test(value);
const validRefresh = value => typeof value === 'string' && /^rd_[A-Za-z0-9_-]{40,100}$/.test(value);
const passwordHash = (password, salt) => crypto.scryptSync(password, salt, 64).toString('hex');
function validatePassword(password) {
  if (typeof password !== 'string' || password.length < 12 || password.length > 256) throw new Error('密码需要 12 至 256 个字符');
}
function validateUsername(name) {
  if (typeof name !== 'string' || !/^[a-zA-Z0-9_.@-]{3,80}$/.test(name)) throw new Error('用户名需要 3 至 80 位字母、数字或 _.@-');
}
function createUser(username, password, role) {
  validateUsername(username); validatePassword(password);
  const salt = crypto.randomBytes(24).toString('hex');
  return {username, role, salt, digest: passwordHash(password, salt), disabled: false};
}
function cleanLead(item) {
  if (!item || typeof item !== 'object') throw new Error('客户格式错误');
  const allowed = {platform: 40, source_id: 300, author: 120, author_id: 160, text: 3000, url: 1000, grade: 10, reason: 300, content_title: 300, content_author: 120, published_at: 40, region: 120, comment_id: 160, parent_id: 160, reply_status: 40};
  const out = {};
  for (const [key, limit] of Object.entries(allowed)) out[key] = typeof item[key] === 'string' ? item[key].slice(0, limit) : '';
  if (!['xiaohongshu', 'douyin', 'kuaishou', 'weibo', 'wechat_channels'].includes(out.platform) || !out.source_id) throw new Error('客户来源标识不完整');
  if (out.url && !/^https?:\/\//.test(out.url)) throw new Error('来源链接格式错误');
  out.comment_level = item.comment_level === 2 ? 2 : 1;
  out.id = hash(out.platform + '\n' + out.source_id);
  return out;
}
function createService({store, environmentId, companyId, initialAdmin, initialPassword, initialUser, clock = Date.now,
 releaseApproved = false, releaseVersion = '', pairingApproved = false, pairingVersion = '', employeeReleaseEnabled = false, employeeReleaseVersion = '', platformQaDeviceId = '', qaContinuousUntil = 0, continuousReadonlyDeviceId = '', sharedFeatureEnabled = SHARED_FEATURE_ENABLED, aiProvider, aiRetryDelay}) {
  if (!environmentId || !companyId) throw new Error('缺少环境 ID 或公司隔离 ID');
  const reply = (status, data) => ({status, data: {contract: CONTRACT, environment_id: environmentId, company_id: companyId, ...data}});
  const enterpriseAi = createEnterpriseAi({store, companyId, clock, provider: aiProvider, retryDelay: aiRetryDelay});
  const contactLedger = createContactLedger({store, companyId, clock});
  const ruleBundleRoutes=createRuleBundleRoutes({store,environmentId,companyId,clock});
  const readonlyRoutes=createReadonlyRoutes({store,environmentId,companyId,clock,releaseApproved,releaseVersion,
    pairingApproved,pairingVersion,employeeReleaseEnabled,employeeReleaseVersion,
    platformQaDeviceId,qaContinuousUntil,continuousReadonlyDeviceId});
  return async function handle(payload, bearer = '') {
    if (!payload || payload.environment_id !== environmentId) return reply(400, {error: '环境 ID 不匹配'});
    if (RULE_BUNDLE_OPS.has(payload.operation)) {
      const result=await ruleBundleRoutes(payload,bearer);
      return reply(result.status,result.data);
    }
    if (payload.operation === 'store_config_read' || payload.operation === 'device_permission_snapshot') {
      const result=await readonlyRoutes(payload,bearer);
      return reply(result.status,result.data);
    }
    if (payload.operation === 'health') return reply(200, {ok: true});
    let initial = null;
    const result = await store.transaction(async (stored, dbTransaction) => {
      const now = Math.floor(clock() / 1000);
      if (!stored) {
        if (!initial) initial = initialUser ? structuredClone(initialUser) : createUser(initialAdmin, initialPassword, 'admin');
        stored = {companyId, revision: 0, users: [initial], sessions: [], rememberedDevices: [], attempts: {}, items: [], audit: []};
      }
      if (stored.companyId !== companyId) return {state: stored, result: reply(403, {error: '公司隔离检查失败'})};
      const state = structuredClone(stored);
      state.sessions = state.sessions.filter(s => s.expires > now);
      state.rememberedDevices = (state.rememberedDevices || []).filter(d => d.idleExpires > now && d.absoluteExpires > now);
      state.attempts = Object.fromEntries(Object.entries(state.attempts).filter(([, v]) => v.until > now));
      const finish = (status, data) => ({state, result: reply(status, data)});
      const audit = (user, operation) => { state.audit.push({user, operation, time: now}); state.audit = state.audit.slice(-300); };
      try {
        if (payload.operation === 'login') {
          const username = String(payload.username || '').slice(0, 80), password = String(payload.password || '');
          // A shared workspace limit also bounds attempts against invented usernames.
          const bucket = hash(username), failures = state.attempts[bucket] || {count: 0, until: now + 300};
          const total = state.attempts.all || {count: 0, until: now + 60};
          if (failures.count >= 8 || total.count >= 40) return finish(429, {error: '登录尝试过多，请稍后再试'});
          const u = state.users.find(x => x.username === username);
          const digest = password.length <= 256 ? passwordHash(password, u?.salt || 'invalid-account-fixed-timing-salt') : '';
          if (!u || u.disabled || digest.length !== u.digest.length || !crypto.timingSafeEqual(Buffer.from(digest), Buffer.from(u.digest))) {
            state.attempts[bucket] = {...failures, count: failures.count + 1}; state.attempts.all = {...total, count: total.count + 1};
            return finish(401, {error: '用户名或密码错误'});
          }
          delete state.attempts[bucket];
          const remember = payload.remember_device === true;
          if (remember && !validDeviceId(payload.device_id)) return finish(400, {error: '设备标识无效'});
          const token = crypto.randomBytes(32).toString('base64url'), expires = now + ACCESS_SECONDS;
          const deviceId = remember ? payload.device_id : '';
          if (remember) {
            state.rememberedDevices = state.rememberedDevices.filter(d => d.username !== username || d.deviceId !== deviceId);
            state.sessions = state.sessions.filter(s => s.username !== username || s.deviceId !== deviceId);
            const refreshToken = 'rd_' + crypto.randomBytes(32).toString('base64url');
            const absoluteExpires = now + REMEMBER_ABSOLUTE_SECONDS;
            state.rememberedDevices.push({username, deviceId, digest: hash(refreshToken),
              idleExpires: Math.min(now + REMEMBER_IDLE_SECONDS, absoluteExpires), absoluteExpires});
            state.rememberedDevices = state.rememberedDevices.slice(-200);
            state.sessions.push({digest: hash(token), username, deviceId, expires});
            state.sessions = state.sessions.slice(-200);
            audit(username, 'login');
            return finish(200, {token, expires, device_id: deviceId, refresh_token: refreshToken,
              refresh_idle_expires: Math.min(now + REMEMBER_IDLE_SECONDS, absoluteExpires),
              refresh_absolute_expires: absoluteExpires, user: publicUser(u)});
          }
          state.sessions.push({digest: hash(token), username, expires}); state.sessions = state.sessions.slice(-200);
          audit(username, 'login'); return finish(200, {token, expires, user: publicUser(u)});
        }
        if (payload.operation === 'refresh' || payload.operation === 'refresh_status') {
          if (!validDeviceId(payload.device_id) || !validRefresh(bearer)) return finish(401, {error: '设备登录已过期'});
          const remembered = state.rememberedDevices.find(d => d.deviceId === payload.device_id && d.digest === hash(bearer));
          const rememberedUser = remembered && state.users.find(u => u.username === remembered.username && !u.disabled);
          if (!rememberedUser) return finish(401, {error: '设备登录已过期'});
          if (payload.operation === 'refresh') {
            if (!validRefresh(payload.next_refresh_token) || payload.next_refresh_token === bearer)
              return finish(400, {error: '续期参数无效'});
            remembered.digest = hash(payload.next_refresh_token);
            remembered.idleExpires = Math.min(now + REMEMBER_IDLE_SECONDS, remembered.absoluteExpires);
          }
          const token = crypto.randomBytes(32).toString('base64url'), expires = now + ACCESS_SECONDS;
          state.sessions.push({digest: hash(token), username: remembered.username, deviceId: remembered.deviceId, expires});
          state.sessions = state.sessions.slice(-200);
          audit(remembered.username, payload.operation);
          return finish(200, {token, expires, device_id: remembered.deviceId,
            refresh_idle_expires: remembered.idleExpires,
            refresh_absolute_expires: remembered.absoluteExpires, user: publicUser(rememberedUser)});
        }
        const session = state.sessions.find(x => x.digest === hash(bearer));
        const user = session && state.users.find(x => x.username === session.username && !x.disabled);
        const deviceResponse=handleDevices({state,payload,bearer,user,now,reply,companyId,releaseApproved,releaseVersion,
          pairingApproved,pairingVersion,employeeReleaseEnabled,employeeReleaseVersion,
          platformQaDeviceId,qaContinuousUntil,continuousReadonlyDeviceId});
        if(deviceResponse)return deviceResponse;
        if (payload.operation === 'contact_events_sync' || payload.operation === 'contact_responses_sync') {
          const device = state.devices?.find(d => !d.revoked && d.digest === hash(bearer));
          const owner = device && state.users.find(u => u.username === device.owner && !u.disabled);
          if (!device || !owner) return finish(401, {error: '设备已撤销或员工已停用', code: 'CONTACT_AUTH_REQUIRED'});
          return {state, result: {_contactRequest: true,
            identity: {username: owner.username, deviceId: device.id, deviceDigest: device.digest}}};
        }
        if (!user) return finish(401, {error: '请重新登录'});
        if (!sharedFeatureEnabled && (payload.operation === 'list' || payload.operation === 'publish')) {
          return finish(423, {error: 'feature_disabled'});
        }
        // Provider calls happen after this transaction commits; CloudBase may replay
        // transaction callbacks and must never replay a billable network request.
        if (AI_OPERATIONS.has(payload.operation)) return {state, result: {_aiRequest: true,
          identity: {username: user.username, sessionDigest: session.digest}}};
        if (CONTACT_OPERATIONS.has(payload.operation)) return {state, result: {_contactRequest: true,
          identity: {username: user.username, sessionDigest: session.digest}}};
        if (payload.operation === 'logout') {
          state.sessions = state.sessions.filter(x => x.digest !== hash(bearer)
            && !(session.deviceId && x.username === user.username && x.deviceId === session.deviceId));
          if (session.deviceId) state.rememberedDevices = state.rememberedDevices.filter(d => d.username !== user.username || d.deviceId !== session.deviceId);
          return finish(200, {ok: true});
        }
        if (payload.operation === 'me') return finish(200, {user: publicUser(user)});
        if (payload.operation === 'list') {
          if (state.sharedLeadsMode === 'v2') {
            const cursor = payload.cursor === undefined ? '' : payload.cursor;
            if (typeof cursor !== 'string' || cursor && (!/^[1-9][0-9]*$/.test(cursor) || !Number.isSafeInteger(Number(cursor)))) return finish(400, {error: '清单游标无效'});
            if (payload.revision !== undefined && payload.revision !== state.revision) return finish(409, {error: '清单已更新，请重新读取'});
            return {state, result: {_sharedListPage: true, cursor, revision: state.revision, username: user.username, sessionDigest: session.digest}};
          }
          return finish(200, {items: state.items, revision: state.revision, max_batch: 100});
        }
        if (payload.operation === 'members') {
          if (user.role !== 'admin') return finish(403, {error: '需要管理员权限'});
          return finish(200, {users: state.users.map(publicUser)});
        }
        if (payload.operation === 'member_save') {
          if (user.role !== 'admin') return finish(403, {error: '需要管理员权限'});
          const {username, password, role} = payload; validateUsername(username);
          if (!['admin', 'operator'].includes(role)) throw new Error('角色无效');
          if (username === user.username && (payload.disabled || role !== 'admin')) throw new Error('不能停用自己或取消自己的管理员权限');
          const previous = state.users.find(x => x.username === username);
          let next = previous ? {...previous, role, disabled: payload.disabled === true} : createUser(username, password, role);
          if (previous && password) next = {...createUser(username, password, role), disabled: payload.disabled === true};
          if (payload.can_reply !== undefined && typeof payload.can_reply !== 'boolean') throw new Error('回复权限格式无效');
          next.can_reply=payload.can_reply===undefined?previous?.can_reply!==false:payload.can_reply;
          if (!previous && state.users.length >= 100) throw new Error('当前部署支持最多 100 位成员');
          state.users = state.users.filter(x => x.username !== username).concat(next);
          state.sessions = state.sessions.filter(x => x.username !== username);
          state.rememberedDevices = state.rememberedDevices.filter(x => x.username !== username);
          audit(user.username, 'member_save'); return finish(200, {user: publicUser(next)});
        }
        if (payload.operation === 'publish') {
          if (Number.isSafeInteger(state.sharedLeadMigrationOffset) && state.sharedLeadsMode !== 'v2') return finish(423, {error: '企业共享清单迁移中，请稍后重新读取再提交'});
          if (!Number.isSafeInteger(payload.revision) || payload.revision !== state.revision) return finish(409, {error: '清单已更新，请重新读取'});
          const maxBatch = state.sharedLeadsMode === 'v2' ? MAX_BATCH : 100;
          if (!Array.isArray(payload.items) || !payload.items.length || payload.items.length > maxBatch) return finish(400, {error: `每次允许 1 至 ${maxBatch} 位客户`});
          const incoming = payload.items.map(cleanLead);
          if (companyId === 'fangyu-apartment-client' && incoming.some(row => row.platform !== 'xiaohongshu')) {
            return finish(422, {error: '方隅首版只允许共享小红书线索'});
          }
          if (state.sharedLeadsMode === 'v2') {
            if (!dbTransaction) throw new Error('共享清单事务不可用');
            const unique = [...new Map(incoming.map(row => [row.id, {...row, updatedBy: user.username, updatedAt: now}])).values()];
            const sequence = state.sharedLeadSequence === undefined ? 0 : state.sharedLeadSequence;
            await upsertBatch(dbTransaction, companyId, unique, sequence);
            state.sharedLeadSequence = sequence + unique.length;
            state.revision++; audit(user.username, 'publish');
            return finish(200, {revision: state.revision, shared: unique.length});
          }
          const map = new Map(state.items.map(x => [x.id, x]));
          for (const row of incoming) map.set(row.id, {...row, updatedBy: user.username, updatedAt: now});
          const items = [...map.values()];
          if (items.length > 1000 || Buffer.byteLength(JSON.stringify(items)) > 1500000) {
            return {state: stored, result: reply(507, {error: '企业共享清单已达当前部署容量（1000 条或 1.5 MB）；本次未上传，请联系管理员扩容'})};
          }
          state.items = items; state.revision++; audit(user.username, 'publish');
          return finish(200, {revision: state.revision, shared: incoming.length});
        }
        return finish(400, {error: '不支持的操作'});
      } catch (e) {
        // A v2 batch may already have written documents inside the transaction.
        // Throw so CloudBase rolls back the entire batch and revision together.
        if (payload.operation === 'publish' && state.sharedLeadsMode === 'v2') throw e;
        // Do not commit partially changed state after a validation failure.
        return {state: stored, result: reply(400, {error: '请求参数不正确，请核对输入'})};
      }
    });
    if (result?._aiRequest) {
      const response = await enterpriseAi.handle(payload, result.identity);
      return reply(response.status, response.data);
    }
    if (result?._contactRequest) {
      const response = await contactLedger.handle(payload, result.identity);
      return reply(response.status, response.data);
    }
    if (result?._sharedListPage) {
      if (!store.listSharedPage) return reply(503, {error: '共享清单分页服务尚未配置'});
      const page = await store.listSharedPage(result.cursor, result.revision, result.username, result.sessionDigest);
      if (!page) return reply(409, {error: '清单已更新，请重新读取'});
      return reply(200, {...page, revision: result.revision, max_batch: MAX_BATCH});
    }
    return result;
  };
}
module.exports = {createService, cleanLead, createUser};
