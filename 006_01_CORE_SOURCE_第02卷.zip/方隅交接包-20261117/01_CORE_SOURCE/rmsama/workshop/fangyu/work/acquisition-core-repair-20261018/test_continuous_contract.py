"""Actual Runtime serial controller; only the executor/page IO boundary is fake."""
from pathlib import Path
import copy,sys,threading,types,unittest
W=Path(__file__).resolve().parent;P=W.parents[1]
sys.path.insert(0,str(P/'work/shared-backend-integration'))
from platform_runtime import PlatformRuntime,PlatformRuntimeError

class Store:
 def __init__(self,task):self.rows={('tasks',task['id']):copy.deepcopy(task)}
 def get(self,entity,ident):return copy.deepcopy(self.rows.get((entity,ident)))
 def put(self,entity,row):self.rows[entity,row['id']]=copy.deepcopy(row)
 def list(self,entity,tenant=None):return [copy.deepcopy(row) for (kind,_),row in self.rows.items() if kind==entity and (tenant is None or row.get('tenant_id')==tenant)]

class SerialCollectionContract(unittest.TestCase):
 def controller(self,pages,*,clock_step=0,fail_on=0,pause_on=0,no_progress_on=0,check_order=False,with_ai=False):
  r=object.__new__(PlatformRuntime);r._run_lock=threading.RLock();r.closed=False
  user={'id':'fixture-actor','username':'fixture-employee','tenant_id':'fixture-tenant'}
  task={'id':'fixture-task','tenant_id':user['tenant_id'],'cloud_owner':user['username'],
   'platform':'xiaohongshu','account_id':'fixture-account','status':'ready',
   'scope':'search_comments','continuous_enabled':False,'comment_keyword_mode':'all',
   'unknown_policy':'exclude','region':'','pipeline':{'page':0}}
  store=Store(task);r.core=types.SimpleNamespace(lock=threading.RLock(),store=store,task_progress=lambda ident:{'run_id':str(len(calls))})
  r._principal=lambda actor:actor;r._task=lambda actor,ident:store.get('tasks',ident)
  r._collection_binding=lambda row:'owned-fixture-binding'
  executor=types.SimpleNamespace(ai=types.SimpleNamespace(analyze=lambda *args,**kwargs:None)) if with_ai else object();r._executor=lambda actor:executor
  r._account=lambda actor,ident:{'id':ident,'status':'ready'}
  r._collection_readiness=lambda actor,account:('','')
  clock=[0];calls=[];graded=[];control={'event':threading.Event(),'attempt':'fixture-attempt','binding':'owned-fixture-binding'}
  def now():clock[0]+=clock_step;return clock[0]
  r._collection_now=now
  def execute(exc,actor,action,payload):
   self.assertIs(exc,executor);self.assertEqual(payload,{'task_id':task['id'],'max_batches':1})
   index=len(calls)+1
   if fail_on==index:raise PlatformRuntimeError('FIXTURE_PLATFORM_DENIED','fixture denied')
   if index>len(pages):raise AssertionError('Controller read beyond exhausted range')
   if index>1 and check_order:self.assertIn(index-1,graded,'Previous imported page must be analyzed before reading another')
   calls.append(index);current=store.get('tasks',task['id'])
   if index!=no_progress_on:current['pipeline']={'page':index}
   if index==pause_on:current['status']='paused';control['event'].set()
   last=index==len(pages);added=pages[index-1]
   result={'status':'completed' if last else 'stopped','summary':{'read':20,'filtered':0,'imported':added,
    'duplicates':20-added,'can_continue':not last,'exhausted':last,
    'stop_reason':'range_exhausted' if last else 'batch_limit'}}
   current.update(exhausted=last,last_result=copy.deepcopy(result))
   store.put('tasks',current)
   if with_ai:
    for n in range(added):store.put('leads',{'id':f'page-{index}-row-{n}','tenant_id':user['tenant_id'],
     'cloud_owner':user['username'],'task_id':task['id'],'text':'合成求租评论'})
   return result
  r._execute=execute
  def assess(actor,ident):graded.append(len(calls));return {'assessed':max(0,pages[len(calls)-1])}
  r._rental_after_import=assess
  r._analyze_collection_page=lambda *args:{'status':'completed','pending':0,'analyzed':len(args[-1])}
  store.put('rental_task_context_v1',{'id':task['id'],'enabled':True,'tenant_id':user['tenant_id'],'owner':user['username']})
  return r,executor,user,control,calls,graded,store

 def run_controller(self,values,**options):
  values=self.controller(values,**options)
  r,executor,user,control,calls,graded,store=values
  r._bounded_collection(executor,user,'fixture-task',control)
  return values

 def receipt(self,store):
  return next(value for (entity,ident),value in store.rows.items() if entity!='tasks' and 'stop_reason' in value)

 def test_reads_1200_comments_without_ten_page_termination(self):
  *_,calls,graded,store=self.run_controller([20]*60)
  self.assertEqual(len(calls),60);self.assertEqual(self.receipt(store)['counts']['read'],1200)
  self.assertEqual(self.receipt(store)['status'],'completed')

 def test_slow_valid_pages_continue_after_sixty_seconds(self):
  *_,calls,graded,store=self.run_controller([20]*3,clock_step=70)
  self.assertEqual(len(calls),3);self.assertEqual(self.receipt(store)['status'],'completed')

 def test_duplicate_only_pages_with_advancing_cursor_do_not_end_range(self):
  *_,calls,graded,store=self.run_controller([0,0,0,20])
  self.assertEqual(len(calls),4);self.assertEqual(self.receipt(store)['counts']['imported'],20)

 def test_each_page_is_analyzed_before_next_page_and_final_result(self):
  *_,calls,graded,store=self.run_controller([20,20,20],check_order=True)
  self.assertEqual(graded,[1,2,3])

 def test_no_progress_stops_without_replaying_cursor(self):
  *_,calls,graded,store=self.run_controller([20,20],no_progress_on=1)
  self.assertEqual(calls,[1]);self.assertEqual(self.receipt(store)['stop_reason'],'no_progress')

 def test_user_pause_remains_final_without_automatic_resume(self):
  *_,calls,graded,store=self.run_controller([20]*3,pause_on=1)
  self.assertEqual(calls,[1]);self.assertEqual(self.receipt(store)['status'],'paused')

 def test_real_executor_failure_is_not_retried(self):
  r,exc,user,control,calls,graded,store=self.controller([20]*3,fail_on=2)
  with self.assertRaises(PlatformRuntimeError):r._bounded_collection(exc,user,'fixture-task',control)
  self.assertEqual(calls,[1]);self.assertEqual(self.receipt(store)['status'],'failed')

 def test_ai_pending_stops_before_any_new_platform_page(self):
  r,exc,user,control,calls,graded,store=self.controller([20]*3,with_ai=True)
  r._analyze_collection_page=lambda *args:{'status':'pending','code':'AI_DISABLED','pending':20,'analyzed':0}
  with self.assertRaises(PlatformRuntimeError):r._bounded_collection(exc,user,'fixture-task',control)
  self.assertEqual(calls,[1])
  queued=[v for (entity,_),v in store.rows.items() if 'lead_ids' in v]
  self.assertEqual(len(queued),1);self.assertEqual(len(queued[0]['lead_ids']),20)

 def test_resume_analyzes_the_saved_page_ids_before_new_reads(self):
  r,exc,user,control,calls,graded,store=self.controller([20]*3,with_ai=True)
  r._analyze_collection_page=lambda *args:{'status':'pending','code':'AI_DISABLED','pending':20,'analyzed':0}
  try:r._bounded_collection(exc,user,'fixture-task',control)
  except PlatformRuntimeError:pass
  self.assertEqual(calls,[1])
  events=[];execute=r._execute
  def read(*args):events.append(('read',len(calls)+1));return execute(*args)
  def analyze(executor,actor,ident,ids):events.append(('analyze',list(ids)));return {'status':'completed','analyzed':len(ids),'pending':0}
  r._execute=read;r._analyze_collection_page=analyze
  r._bounded_collection(exc,user,'fixture-task',control)
  self.assertEqual(events[0][0],'analyze')
  self.assertEqual(set(events[0][1]),{f'page-1-row-{n}' for n in range(20)})
  self.assertEqual(calls,[1,2,3])

 def test_finished_range_can_finish_original_analysis_without_another_read(self):
  r,exc,user,control,calls,graded,store=self.controller([20],with_ai=True)
  r._analyze_collection_page=lambda *args:{'status':'pending','code':'AI_NOT_CONFIGURED','pending':20,'analyzed':0}
  try:r._bounded_collection(exc,user,'fixture-task',control)
  except PlatformRuntimeError:pass
  r._analyze_collection_page=lambda *args:{'status':'completed','pending':0,'analyzed':20}
  r._bounded_collection(exc,user,'fixture-task',control)
  self.assertEqual(calls,[1]);self.assertEqual(self.receipt(store)['status'],'completed')

if __name__=='__main__':unittest.main(verbosity=2)
