from pathlib import Path
import json,datetime,hashlib
W=Path(__file__).resolve().parent;P=W.parents[1];OUT=W/'candidate-core-v4'
latest=json.loads((W/'gui-fixture/LATEST.json').read_text('utf-8'))
assert latest['instanceId']=='5e3870614b02489394be6351b6c48ea7' and latest['status']=='READY'
staged=json.loads((OUT/'STAGED.json').read_text('utf-8'))
screens={}
for name in ('GUI-NATIVE-REPLY.jpg','GUI-NATIVE-REPLY.txt','GUI-NATIVE-CUSTOMERS.jpg','GUI-NATIVE-CUSTOMERS.txt'):
 p=W/name;assert p.is_file();screens[name]=hashlib.sha256(p.read_bytes()).hexdigest()
result={'status':'PASS_CHANGED_SCOPE_GUI','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'release':staged['release_id'],'closure':'candidate-core-v4','instanceId':latest['instanceId'],
 'browser_verified':True,'isolated_native_verified':True,'native_window_id':989256,
 'native_title':'方隅工作台 · 本轮隔离验收','original_real_window_id':49485052,
 'original_window_closed_or_restarted':False,'real_platform_calls':0,'paid_ai_calls':0,
 'profiles':'separate synthetic fixture-operator native and fixture-admin browser; no original employee session copied',
 'native_observed':{'acquisition':{'read':1000,'added':1000,'analyzed':1000,'recent_contains_suppliers':False},
   'reply':{'candidates':900,'seed_suppliers_excluded':100,'avatars_visible':True,'post_cover_visible':True,
     'right_original_post_card_visible':True,'complete_selected_comment_tail':'SYNTHETIC-0470','paid_reply_or_send_clicked':False},
   'customers':{'total':1000,'high_intent':900,'list_and_detail_avatars_visible':True}},
 'browser_observed':{'primary_navigation':['获客','回复','客户','账号','管理'],
   'accounts_direct_and_return_to_acquisition':True,'management_categories':['获客规则','口吻'],
   'actual_precise_words':142,'precise_and_commute_full_lists_and_source_refs_read':True,
   'source_revision':'r_00668c8261143ee051214c7d72fd426f','exclusion_terms':'empty_in_this_central_fixture_not_fabricated',
   'manager_five_level_local_criteria_read':True,'local_revision_zero_label':'initial_not_saved',
   'server_actual_prompt_returned':False,'server_prompt_absence_explicit':True,
   'save_local_store_plan':'clicked; toast confirms selected words/display preferences local only; navigation returns acquisition'},
 'browser_live_evidence':{'ok':True,'synthetic':True,'media_fetch_count':5,
   'media_paths':['/avatar-0.png','/avatar-1.png','/avatar-2.png','/avatar-5.png','/cover-2.png'],
   'gui_reviewed_by_fixture':False,'real_platform_calls':0,'real_provider_calls':0},
 'screenshots':screens,'synthetic':True,'seed_data':'precomputed fake AI for renderer; distinct CORE-AI-RENTAL-1000 real workflow test with fake provider',
 'not_proven':['real customer/platform authentication or real continuous platform run','actual paid DeepSeek invocation',
   'production CDN fetch or historical records lacking image URLs','production central activation or component-use approval',
   'all unmodified GUI/export/native save functions (historical acceptance retained)'],
 'previous_attempts':{'v2_seed':'actual write-lock defect, fixed and independently tested1000',
   'v3_native_loader':'QA audit initialization issue fixed without loosening audit',
   'v3_reply':'actual gateway audience omission fixed, targeted RED/GREEN; old own QA stopped exit0'}}
(W/'GUI-RESULT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n','utf-8')
print('Recorded observed v4 native/browser changed-scope acceptance, synthetic scope explicit.')
