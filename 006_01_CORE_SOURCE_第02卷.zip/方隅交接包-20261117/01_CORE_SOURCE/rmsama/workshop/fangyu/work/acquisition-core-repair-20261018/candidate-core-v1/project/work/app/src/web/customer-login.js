/* One surface from preparation through verified identity. No credentials in browser storage. */
loginAccount = async function (id) {
  const modal = $('#modal'), account = rows('accounts').find(x => x.id === id);
  if (!account) throw Error('账号不存在，请刷新页面。');
  modal.classList.remove('task-dialog');
  const generation = ++loginViewGeneration;
  const alive = () => generation === loginViewGeneration && modal.open && !!$('#customer-qr-status');
  let finished = false, job = null, loaded = false;
  $('#modal-body').innerHTML = `<div class="connect-title">${platformLogo(account.platform)}<div><h2>连接${esc(platformName(account.platform))}</h2><p>${esc(account.name)}</p></div></div><div class="qr-steps"><span class="active" id="qr-step-1">1 准备二维码</span><span id="qr-step-2">2 手机扫码确认</span><span id="qr-step-3">3 检查账号</span></div><div class="qr-frame loading" id="customer-qr-frame"><img id="customer-qr-image" hidden alt="平台登录二维码"></div><div id="customer-qr-status" class="qr-status" role="status" aria-live="polite">正在准备二维码。生成后，请用${esc(platformName(account.platform))}手机 App 扫码。</div><div class="qr-actions"><button id="customer-qr-cancel">取消连接</button><button id="customer-qr-retry" hidden>重新生成二维码</button><button id="customer-qr-done" class="primary" hidden>开始找客户</button></div><p class="connect-footer">扫码必须由你本人完成。无需保存二维码图片，直接扫描上方二维码即可。</p>`;
  if (!modal.open) modal.showModal();
  const show = (message, failed = false) => { if (!alive()) return; const status = $('#customer-qr-status'); status.textContent = message; status.classList.toggle('failed', failed); if (failed) { $('#customer-qr-frame').classList.remove('loading'); $('#customer-qr-retry').hidden = false; } };
  const cancel = async () => {
    if (finished) { ++loginViewGeneration; modal.close(); return; }
    const b = $('#customer-qr-cancel'); WorkbenchUI.busy(b, true);
    try { await api('account_login_cancel', {id}); finished = true; ++loginViewGeneration; modal.close(); await loadPage(); }
    catch (e) { show('取消没有完成：' + e.message, true); } finally { WorkbenchUI.busy(b, false); }
  };
  $('#customer-qr-cancel').onclick = cancel;
  modal.addEventListener('cancel', function onCancel(e) { if (alive()) { e.preventDefault(); void cancel(); } }, {once: true});
  $('#customer-qr-retry').onclick = async () => { try { await api('account_login_cancel', {id}); finished = true; await loginAccount(id); } catch (e) { show(e.message, true); } };
  $('#customer-qr-done').onclick = () => { ++loginViewGeneration; modal.close(); state.quickAccount = id; state.page = 'tasks'; render(); $('#quick-keywords')?.focus(); };
  try {
    const result = await api('account_login', {id}); job = result.login_job;
    if (!alive()) return;
    for (let i = 0; i < 130 && alive(); i++) {
      const j = await api('job_status', {id: job}); if (!alive()) return;
      if (j.qr_ready && !loaded) {
        const image = $('#customer-qr-image');
        image.onload = () => { if (!alive()) return; loaded = true; image.hidden = false; $('#customer-qr-frame').classList.remove('loading'); $('#qr-step-1').classList.remove('active'); $('#qr-step-2').classList.add('active'); show('二维码已准备好。请用手机扫码，并在手机上确认登录。'); };
        image.onerror = () => show('二维码已生成，但图片读取失败。请重新生成二维码。', true);
        image.src = '/qr/' + encodeURIComponent(job);
      }
      if (j.status !== 'running') {
        finished = true;
        $('#customer-qr-frame').classList.remove('loading');
        if (j.status === 'completed' && j.result?.verified) {
          $('#qr-step-2').classList.remove('active'); $('#qr-step-3').classList.add('active');
          show('账号已连接，身份检查通过。现在可以开始找客户。');
          $('#customer-qr-done').hidden = false; $('#customer-qr-cancel').textContent = '完成';
        } else show(j.error || j.result?.message || '本次登录未完成，请重新生成二维码。', true);
        await loadPage(); return;
      }
      if (!j.qr_ready && i === 10) show('二维码准备时间较长，正在等待平台返回。可以继续等待，或取消后重试。');
      await new Promise(resolve => setTimeout(resolve, 1800));
    }
    if (alive()) show('等待扫码超时，请重新生成二维码。', true);
  } catch (e) { show(e.message, true); }
};
