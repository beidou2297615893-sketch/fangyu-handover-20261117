"""Explicit owner-local selected SourcePool CSV. No cloud/platform/AI privilege."""
from copy import deepcopy
import csv,io,re,secrets,threading,time
from core import CoreError
from .platform_receipt_archive import SOURCES,_hash

ACTIONS=frozenset({'owner_source_export_begin','owner_source_export_page','owner_source_export_confirm'})
_ACTOR=('id','tenant_id','username','role','personal_owner','cloud_bound','disabled','permission_revision')
_FIELDS=('id','account_id','group_id','platform','title','text','author','grade','analysis_status','analysis_verified','intent_level','analysis_reason','readonly_archive','can_reply')
_COLUMNS=(('id','本机来源编号'),('platform','平台'),('title','原作品标题'),('author','原评论作者'),('text','原评论'),('analysis_status','分析状态'),('intent_level','原保存意向'),('analysis_reason','原保存依据'))
TTL=300

def _class(row):
    if row['analysis_status']=='pending_analysis':return 'pending'
    if row['analysis_verified'] is True and row['analysis_status']=='graded' and row['intent_level'] in ('high','super_high'):return 'priority'
    if row['analysis_verified'] is True and row['analysis_status'] in ('graded','uncertain','unrelated'):return 'other'
    return 'review'

def _csv(rows):
    stream=io.StringIO(newline='');writer=csv.writer(stream,lineterminator='\r\n');writer.writerow([label for _,label in _COLUMNS])
    for row in rows:
        values=[]
        for key,_ in _COLUMNS:
            value='' if row.get(key) is None else str(row[key])
            if re.match(r'^[\s\ufeff]*[=+\-@]|^[\t\r\n]',value):value="'"+value
            values.append(value)
        writer.writerow(values)
    return '\ufeff'+stream.getvalue()

class OwnerSourceExport:
    ACTIONS=ACTIONS
    def __init__(self,workspace):
        from .self_operating_read import OwnerReadWorkspace
        if type(workspace) is not OwnerReadWorkspace or workspace.server._self_operating_reads is not workspace:
            raise CoreError('导出只能由本人工作台的固定用途创建')
        self.workspace,self.core=workspace,workspace.server.core
        self._lock=threading.RLock();self._entries={};self._requests={}

    def _principal(self,user):
        return _hash([self.workspace.instance.check()['selfOperatingRead'],{k:user.get(k) for k in _ACTOR}])

    def _capture(self,token,user,ids,cutoff,filter_name):
        rows=[];scope=[]
        for ident in ids:
            lead=self.core._get('leads',ident,user['tenant_id'])
            uid=lead.get('source_uid')
            if type(uid) is not str or not uid:raise CoreError('原来源范围需核对')
            source_id=_hash([user['tenant_id'],uid]);source=self.core._get(SOURCES,source_id,user['tenant_id'])
            # Build the seek on the server from the canonical SOURCE, never
            # accept a client validation_ids/account/proof/view dictionary.
            previous=int(source_id,16)-1
            cursor={'schema':'owner_source_cursor_v1','after':format(previous,'064x'),'cutoff':cutoff} if previous>=0 else None
            page=self.workspace._source_page(token,user,1,cursor)
            values=page.get('leads')
            if type(values) is not list or len(values)!=1 or values[0].get('id')!=ident:
                raise CoreError('某个原选中来源已缺失或失权，整份导出失效')
            row=values[0]
            if set(row)!=set(_FIELDS) or row['platform'] not in ('xiaohongshu','douyin') or row['readonly_archive'] is not True or row['can_reply'] is not False:
                raise CoreError('原来源安全显示契约需核对')
            if filter_name!='all' and _class(row)!=filter_name:raise CoreError('原来源已不符合冻结筛选，整份导出失效')
            account=self.workspace._intent._source_account(token,user,row['account_id'])
            if account['platform']=='xiaohongshu':self.workspace._require_activity_safe(user,account)
            else:self.workspace._douyin._safe(user,account)
            rows.append(deepcopy(row));scope.append({'source_id':source_id,'source':_hash(source),'lead':_hash(lead),'account':_hash(account)})
        return rows,tuple(scope)

    def _invalidate(self,request_id):
        snapshot=self._requests.get(request_id)
        if snapshot is not None:self._entries.pop(snapshot,None)
        self._requests[request_id]=None

    def __call__(self,token,action,data):
        if action not in ACTIONS or type(data) is not dict:raise CoreError('不支持此本人导出用途')
        request_id=data.get('request_id')
        if type(request_id) is not str or re.fullmatch(r'[A-Za-z0-9_-]{8,128}',request_id) is None:
            raise CoreError('导出原编号无效')
        with self.workspace._lock,self._lock,self.core.lock:
            user=None
            try:
                user=self.workspace._actor(token)
                principal=self._principal(user)
                identity=(user['id'],user['tenant_id'],user['username'])
                if self.workspace._identity is not None and self.workspace._identity!=identity:
                    raise CoreError('自营实例本人身份已变化；不能借用另一人的导出服务')
                if action=='owner_source_export_begin':
                    if set(data)!={'request_id','source_ids','filter'}:raise CoreError('导出只接受明确所选来源及本页筛选')
                    if request_id in self._requests:raise CoreError('原导出编号已保留，只核对原号，不重新开始')
                    ids=data['source_ids'];filter_name=data['filter']
                    if (type(ids) is not list or not 1<=len(ids)<=50
                        or any(type(x) is not str or re.fullmatch(r'[0-9a-f]{64}',x) is None for x in ids) or len(set(ids))!=len(ids)
                        or filter_name not in ('all','pending','priority','review','other')):
                        raise CoreError('请选择本页至多50条明确来源')
                    for old in list(self._entries.values()):
                        if time.monotonic()-old['created']>TTL:self._invalidate(old['request_id'])
                    if len(self._requests)>=512 or len(self._entries)>=8:raise CoreError('导出原号容量已满，请保留现状')
                    self._requests[request_id]=None  # reserve this original request; unknown cannot restart it
                    if self.workspace._identity!=(user['id'],user['tenant_id'],user['username']) or self.workspace._intent is None:
                        raise CoreError('本人来源池尚未明确加载；请先刷新来源，原导出编号保持失效')
                    cutoff=time.time();rows,scope=self._capture(token,user,ids,cutoff,filter_name)
                    if self._principal(self.workspace._actor(token))!=principal:raise CoreError('本人范围在建立导出时变化')
                    snapshot=secrets.token_hex(32)
                    entry={'request_id':request_id,'snapshot':snapshot,'principal':principal,'created':time.monotonic(),
                        'session':_hash(token),'actor':identity,'ids':tuple(ids),'rows':rows,'scope':scope,'cutoff':cutoff,'filter':filter_name}
                    self._requests[request_id]=snapshot;self._entries[snapshot]=entry
                    offset=0;limit=25
                else:
                    fields={'request_id','snapshot','offset','limit'} if action=='owner_source_export_page' else {'request_id','snapshot'}
                    if set(data)!=fields:raise CoreError('导出核对参数无效')
                    snapshot=self._requests.get(request_id);entry=self._entries.get(snapshot)
                    supplied=data['snapshot']
                    if (entry is None or supplied!=snapshot and not (supplied is None and action=='owner_source_export_page')
                        or principal!=entry['principal'] or _hash(token)!=entry['session'] or self.workspace._identity!=entry['actor'] or self.workspace._intent is None or time.monotonic()-entry['created']>TTL):
                        raise CoreError('原导出token失效；不能恢复或换号重放')
                    offset=data.get('offset',0);limit=data.get('limit',25)
                    if type(offset) is not int or not 0<=offset<=len(entry['rows']) or type(limit) is not int or not 1<=limit<=25:
                        raise CoreError('导出原页位置无效')
                    rows,scope=self._capture(token,user,entry['ids'],entry['cutoff'],entry['filter'])
                    if rows!=entry['rows'] or scope!=entry['scope'] or self._principal(self.workspace._actor(token))!=entry['principal']:
                        raise CoreError('原导出完整来源或本人范围已变化，整份失效')
                result={'purpose':action,'request_id':request_id,'snapshot':snapshot,'count':len(entry['rows']),
                    'filter':entry['filter'],'source_ids':list(entry['ids']),'coverage':'selected_sources_only',
                    'scope':'this_instance_owner','local_only':True,'AI_started':False,'platform_requests_started':False,
                    'can_reply':False,'auto_retry':False}
                if action=='owner_source_export_confirm':result.update(state='confirmed',csv=_csv(entry['rows']),filename='方隅已选来源.csv')
                else:result.update(state='open',offset=offset,rows=deepcopy(entry['rows'][offset:offset+limit]))
                return result
            except Exception as error:
                cached=self._entries.get(self._requests.get(request_id))
                caller_identity=(user['id'],user['tenant_id'],user['username']) if user is not None else None
                if request_id in self._requests and (cached is None or cached['session']==_hash(token) or cached['actor']==caller_identity):
                    self._invalidate(request_id)
                if not isinstance(error,CoreError):
                    raise CoreError('原导出核对结果未知，token已失效；保留原编号') from None
                raise
