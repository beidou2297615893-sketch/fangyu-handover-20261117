from pathlib import Path
W=Path(__file__).resolve().parent;P=W.parents[1]
UI=P/'work/ui-approved-implementation/ui-preview'
def replace(path,old,new):
 s=path.read_text('utf-8');assert s.count(old)==1,(path.name,old[:70],s.count(old))
 path.write_text(s.replace(old,new),'utf-8')
app=UI/'app.mjs'
s=app.read_text('utf-8')
start=s.index('const nav=management?')
end=s.index(';\nreturn `<div class="shell"',start)
nav='''const nav=`${navButton('acquire','获客','approved-icon-search.svg')}${navButton('reply','回复','icon-message-square-more.svg')}${navButton('customers','客户','approved-icon-user-round.svg')}<hr class="nav-divider">${navButton('accounts','账号','approved-icon-user-round.svg')}${navButton('rules','管理','approved-icon-settings.svg')}`;
if(['rules','tone','presets'].includes(state.page))content=`<div role="navigation" aria-label="管理分类" style="display:flex;gap:12px;margin-bottom:20px"><button type="button" class="rp-tab ${state.page==='rules'?'is-active':''}" data-nav="rules" aria-pressed="${state.page==='rules'}">获客规则</button><button type="button" class="rp-tab ${state.page==='tone'?'is-active':''}" data-nav="tone" aria-pressed="${state.page==='tone'}">口吻</button></div>`+content'''
s=s[:start]+nav+s[end:]
old='function navButton(page,label,img){return '
new="function navButton(page,label,img){const current=state.page===page||(page==='rules'&&['tone','presets'].includes(state.page));return "
assert s.count(old)==1;s=s.replace(old,new)
s=s.replace("${state.page===page?'active':''}","${current?'active':''}").replace("${state.page===page?'aria-current=\"page\"':''}","${current?'aria-current=\"page\"':''}")
app.write_text(s,'utf-8')
reply=UI/'pages/reply-connected.mjs'
replace(reply,'import {customerAvatar,bindCustomerAvatars}', 'import {customerAvatar,postCover,bindCustomerAvatars}')
replace(reply,'<img class="rp-post-thumbnail" style="object-fit:contain;padding:25px;flex-shrink:0" src="/assets/tabler-external-link.svg" alt="来源帖子">',
 '${postCover(p,\'rp-post-thumbnail\',\'object-fit:cover;flex-shrink:0\')}')
replace(reply,"ctx.replyCustomers({query:v.query,filter:v.tab,sort:v.groupBy,page:v.page,pageSize:20})",
 "ctx.replyCustomers({query:v.query,filter:v.tab,sort:v.groupBy,page:v.page,pageSize:20,audience:'prospects'})")
replace(reply,'<p style="display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden">${esc(row.text.length>100?row.text.slice(0,100)+\'…\':row.text)}</p>',
 '<p style="white-space:pre-wrap;overflow-wrap:anywhere;max-height:180px;overflow:auto">${esc(row.text)}</p>')
replace(reply,'<button type="button" class="rp-evidence-toggle" data-live-evidence',
 '''<div class="rp-selected-source" style="display:flex;gap:12px;margin:14px 0;align-items:center;flex-shrink:0">${postCover(row,'rp-post-thumbnail','width:92px;height:92px;object-fit:cover;flex-shrink:0;border-radius:12px')}<div style="min-width:0;flex:1"><strong style="display:block;font-size:16px;overflow-wrap:anywhere">${esc(row.postTitle)}</strong><span style="font-size:13px;color:#7186a6">${esc(row.publishedAt||'原评论时间未提供')}</span><button type="button" class="rp-text-link" data-live-source style="display:block">打开原帖</button></div></div><div style="font-size:15px;line-height:1.6;color:#526986;margin:0 0 12px;flex-shrink:0">${esc((person.evidence||[]).slice(0,2).join('；')||'意向依据暂未完整提供')}</div>
      <button type="button" class="rp-evidence-toggle" data-live-evidence''')
print('Applied incremental media/detail and stable primary navigation changes.')
