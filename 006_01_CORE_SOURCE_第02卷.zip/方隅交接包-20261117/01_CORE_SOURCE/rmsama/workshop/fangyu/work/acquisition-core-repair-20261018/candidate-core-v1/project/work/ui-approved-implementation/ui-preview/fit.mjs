// Fill the window with a fluid design viewport; text keeps a uniform scale.
const sizes={login:[1487,1058],acquire:[1585,992],reply:[1585,992],customers:[1586,992],presets:[1586,992],accounts:[1585,992],rules:[1586,992],tone:[1586,992]};
const frame=document.getElementById('workspace-frame');
const route=value=>Object.hasOwn(sizes,value)?value:'login';
let page=route(location.hash.slice(1)),layoutWidth=0,layoutHeight=0;
function fit(){
  if(!innerWidth||!innerHeight)return;
  const [baseWidth,baseHeight]=sizes[page];
  const baseScale=Math.min(innerWidth/baseWidth,innerHeight/baseHeight);
  // Data rows and expanded details must scroll in their own panels. They do
  // not change the type scale of the whole workbench or its navigation rail.
  const scale=baseScale;
  layoutWidth=innerWidth/scale;layoutHeight=innerHeight/scale;
  frame.style.width=layoutWidth+'px';frame.style.height=layoutHeight+'px';
  frame.style.transform=`scale(${scale})`;
  document.body.dataset.page=page;document.body.dataset.scale=String(scale);
  frame.contentWindow?.postMessage({type:'fangyu-canvas-viewport',layoutY:(innerHeight/baseScale)/baseHeight},location.origin);
}
function reset(){fit();}
window.addEventListener('resize',reset);
window.visualViewport?.addEventListener('resize',reset);
frame.addEventListener('load',fit);
window.addEventListener('message',event=>{
  if(event.source!==frame.contentWindow||event.origin!==location.origin)return;
  const m=event.data;
  if(!Object.hasOwn(sizes,m?.page))return;
  if(m.type==='fangyu-canvas-change'){
    page=m.page;reset();
    if(location.hash!=='#'+page)history.replaceState(null,'','#'+page);
    return;
  }
  if(m.type!=='fangyu-canvas-size'||m.page!==page)return;
  if(Math.abs(m.viewportWidth-layoutWidth)>1||Math.abs(m.viewportHeight-layoutHeight)>1)return;
  frame.dataset.contentOverflow=String(Number.isFinite(m.contentHeight)&&m.contentHeight>layoutHeight+1);
  frame.dataset.ready='true';
});
window.addEventListener('hashchange',()=>{
  const next=route(location.hash.slice(1));if(next===page)return;
  page=next;reset();frame.contentWindow.location.hash=page;
});
fit();frame.src='/canvas.html#'+page;
