/* Current members capability grants only the declared personnel scope. */
const roles=new Set(['admin','operator','origin_partner']),storePattern=/^[A-Za-z0-9_-]{1,80}$/;
const text=(tag,value='',className='')=>{const node=document.createElement(tag);node.textContent=String(value);if(className)node.className=className;return node;};
const roleLabel=role=>({admin:'管理员',operator:'员工',origin_partner:'合作来源（仅资料包）'})[role]||'权限待核对';
function verifiedManagement(value,actor,localWorkspace){
 const m=value?.member_management,s=m?.scope;
 if(!m||m.version!=='store-members-v1'||m.actor?.username!==actor?.username||m.actor?.role!==actor?.role
  ||!s||!['company','store'].includes(s.type)||typeof s.stamp!=='string'||!/^[a-f0-9]{64}$/.test(s.stamp)
  ||!Array.isArray(m.operations)||m.operations.length!==2||!m.operations.includes('create')||!m.operations.includes('update'))return null;
 if(s.type==='company'&&(actor.role!=='admin'||localWorkspace===true||s.store_id!==''))return null;
 if(s.type==='store'&&(actor.role!=='operator'||!storePattern.test(s.store_id)))return null;
 return {version:m.version,actor:{...m.actor},scope:{...s},operations:[...m.operations]};
}
export function memberChangePayload(values,member,actor,management=null){
 const manager=management?.scope?.type==='store';
 if(!actor||(manager?actor.role!=='operator':actor.role!=='admin'))throw Error('没有当前人员管理权限');
 const username=String(values.username||'').trim(),role=String(values.role||'');
 if(!/^[a-zA-Z0-9_.@-]{3,80}$/.test(username)||!roles.has(role))throw Error('用户名或权限无效');
 const password=String(values.password||''),disabled=values.disabled===true,partner=role==='origin_partner';
 const store=String(values.store_id||'').trim();
 if((!member||password)&&password.length<12)throw Error('密码至少需要 12 位');
 if(store&&!storePattern.test(store))throw Error('门店分组仅使用字母、数字、下划线和短横线，最多 80 位');
 if(member&&(username!==member.username||(member.role==='origin_partner')!==partner))throw Error('原成员身份已变化，请重新选择编辑');
 if(member&&username===actor.username&&(disabled||role!=='admin'))throw Error('不能停用自己或取消自己的管理员权限');
 if(manager&&(role!=='operator'||store!==management.scope.store_id||username===actor.username
  ||member&&(member.can_edit!==true||member.can_manage_store_members===true)||values.can_reply!==(member?member.can_reply:false)))throw Error('仅能管理本店普通员工，不能提升权限');
 return {username,role,can_reply:partner?false:values.can_reply===true,store_id:partner?'':store,
  ...(member?{disabled}:{}),...(password?{password}:{}),member_mode:member?'update':'create',
  ...(management?{member_scope_stamp:management.scope.stamp}:{}),
  ...(!manager&&management?{can_manage_store_members:values.can_manage_store_members===true}:{})};
}
export function createMemberAdminUI({form,list,count,feedback,title,cancel,passwordLabel,disabledRow,call,getContext,onScope=()=>{}}){
 const field=name=>form.elements.namedItem(name),save=form.querySelector('button[type=submit]');
 let member=null,editorOwner='',editorActor=null,editorScope='',busy=false,revision=0,readRevision=0,needsRead=false,modesVerified=false,management=null,capabilityOwner='',capabilityActor=null;
 const context=()=>getContext()||{},stamp=()=>JSON.stringify([context().user?.username,context().user?.role,context().epoch,context().companyId,context().environmentId,context().localWorkspace]);
 const authorized=()=>!!context().user&&!context().user.development_local_only&&(context().user.role==='operator'||context().user.role==='admin'&&context().localWorkspace!==true);
 const writable=()=>authorized()&&modesVerified&&management&&capabilityOwner===stamp()&&capabilityActor===context().user;
 const say=(message,error=false)=>{feedback.textContent=message;feedback.hidden=!message;feedback.classList.toggle('is-error',error);};
 function sync(){
  const manager=management?.scope.type==='store',partner=field('role').value==='origin_partner',self=member?.username===context().user?.username,grant=field('can_manage_store_members');
  if(manager){field('role').value='operator';field('store_id').value=management.scope.store_id;field('can_reply').checked=member?member.can_reply:false;}
  if(partner){field('can_reply').checked=false;field('store_id').value='';}
  field('can_reply').disabled=busy||manager||partner;field('store_id').disabled=busy||manager||partner;
  field('role').disabled=busy||manager||!!member&&(self||member.role==='origin_partner');
  if(grant){if(manager||partner||field('role').value!=='operator')grant.checked=false;grant.disabled=busy||manager||partner||field('role').value!=='operator';grant.closest?.('label')?.toggleAttribute('hidden',!!manager);}
  field('disabled').disabled=busy||self;field('username').readOnly=!!member;
  field('password').required=!member;field('password').disabled=busy;
  field('username').disabled=busy;save.disabled=busy||needsRead||!writable();cancel.disabled=busy;
  save.textContent=member?'保存变更':'创建账号';cancel.hidden=!member;disabledRow.hidden=!member;
  title.textContent=member?`编辑成员：${member.username}`:manager?'新增本店员工':'新增成员';
  passwordLabel.textContent=member?'新密码（留空保留原密码）':'初始密码（至少 12 位）';
  onScope(writable()?{...management.scope}:null);
 }
 function reset(){revision++;readRevision++;member=null;editorOwner='';editorActor=null;editorScope='';form.reset();field('password').value='';say(needsRead?'保存结果未确认；请先刷新当前范围成员核对，暂勿再次提交密码。':'');sync();}
 function edit(row){if(busy||needsRead||!writable()||row.can_edit!==true)return;revision++;member={...row};editorOwner=stamp();editorActor=context().user;editorScope=management.scope.stamp;form.reset();
  field('username').value=row.username;field('role').value=row.role;field('can_reply').checked=row.can_reply!==false;
  field('store_id').value=row.store_id||'';field('disabled').checked=row.disabled===true;field('password').value='';
  if(field('can_manage_store_members'))field('can_manage_store_members').checked=row.can_manage_store_members===true;
  say('');sync();field('username').focus();}
 async function load(highlight='',accept=()=>true,internal=false,releaseUnknown=true){
  if(busy&&!internal||!authorized()||!accept())return false;
  const owner=stamp(),actor=context().user,generation=++readRevision;
  modesVerified=false;management=null;capabilityOwner='';capabilityActor=null;
  member=null;editorOwner='';editorActor=null;editorScope='';form.reset();field('password').value='';list.replaceChildren();count.textContent='人员范围待读取';sync();
  const value=await call('members');
  if(owner!==stamp()||actor!==context().user||generation!==readRevision||!accept()||!authorized())return false;
  const candidate=verifiedManagement(value,actor,context().localWorkspace);
  if(!Array.isArray(value.users)||value.users.length>100||new Set(value.users.map(row=>row?.username)).size!==value.users.length||value.users.some(row=>!row||!/^[a-zA-Z0-9_.@-]{3,80}$/.test(row.username)||!roles.has(row.role)||typeof row.disabled!=='boolean'||typeof row.can_reply!=='boolean'||row.store_id!==undefined&&(typeof row.store_id!=='string'||row.store_id&&!storePattern.test(row.store_id))
   ||candidate&&(typeof row.can_edit!=='boolean'||typeof row.can_manage_store_members!=='boolean'||candidate.scope.type==='store'&&(row.role!=='operator'||row.store_id!==candidate.scope.store_id))))throw Error('成员名单未通过当前范围核对，请重新读取');
  modesVerified=!!candidate&&Array.isArray(value.member_save_modes)&&value.member_save_modes.length===2&&value.member_save_modes.includes('create')&&value.member_save_modes.includes('update');
  management=candidate;capabilityOwner=owner;capabilityActor=actor;
  member=null;editorOwner='';editorActor=null;editorScope='';revision++;form.reset();field('password').value='';
  if(!modesVerified)say('管理服务需更新，当前可只读；成员账号尚未修改。',true);
  list.replaceChildren();count.textContent=`${value.users.filter(row=>!row.disabled).length} 个启用账号${candidate?.scope.type==='store'?` · 本店 ${candidate.scope.store_id}`:''}`;
  for(const row of value.users.slice().sort((a,b)=>Number(a.role!=='admin')-Number(b.role!=='admin')||a.username.localeCompare(b.username))){
   const item=text('div','','row member-row'),label=text('div'),role=text('span',row.can_manage_store_members?'本店人员管理':roleLabel(row.role),'member-role');role.dataset.role=row.role;
   if(row.username===highlight)item.classList.add('is-new');
   label.append(text('strong',row.username),text('small',row.disabled?'已停用':row.role==='origin_partner'?'尚需单独准入，不能登录员工工作台':'可登录'));
   label.append(text('small',row.store_id?`门店分组：${row.store_id}`:'未绑定门店分组'));
   const button=text('button','编辑','secondary');button.type='button';button.disabled=busy||!writable()||row.can_edit!==true;button.onclick=()=>{if(owner===stamp()&&actor===context().user)edit(row);};item.append(label,role,button);list.append(item);
  }
  if(!value.users.length)list.append(text('p','还没有成员。','help'));
  const held=needsRead;if(modesVerified&&releaseUnknown)needsRead=false;if(held&&modesVerified&&releaseUnknown)say('当前范围成员名单已重新读取；若上次涉及密码，其是否已更改仍未独立核实。');sync();return !!modesVerified;
 }
 async function submit(event){
  event.preventDefault();if(busy||needsRead||!authorized())return;
  if(member&&(editorOwner!==stamp()||editorActor!==context().user||editorScope!==management?.scope.stamp)){reset();say('管理账号、企业或范围已变化，请重新读取成员并选择编辑。',true);return;}
  if(!writable()){say('管理服务或当前范围尚未核实，请先刷新成员；当前可只读。',true);return;}
  const owner=stamp(),actor=context().user,generation=revision,scopeStamp=management.scope.stamp,original=member&&{...member};
  const fresh=()=>owner===stamp()&&actor===context().user&&generation===revision&&authorized()&&scopeStamp===management?.scope.stamp;
  let payload;
  try{payload=memberChangePayload({username:field('username').value,role:field('role').value,password:field('password').value,
   can_reply:field('can_reply').checked,store_id:field('store_id').value,disabled:field('disabled').checked,can_manage_store_members:field('can_manage_store_members')?.checked===true},original,context().user,management);}
  catch(error){say(error.message,true);return;}
  if(!fresh())return;
  field('password').value='';busy=true;say('正在保存成员…');sync();
  try{
   const result=await call('member_save',payload);
   if(!fresh())return;
   const row=result?.user,reply=verifiedManagement(result,actor,context().localWorkspace);
   if(!row||row.username!==payload.username||row.role!==payload.role||row.disabled!==(payload.disabled===true)||row.can_reply!==payload.can_reply||(row.store_id||'')!==payload.store_id
    ||!reply||reply.scope.stamp!==scopeStamp||typeof row.can_manage_store_members!=='boolean'||Object.hasOwn(payload,'can_manage_store_members')&&row.can_manage_store_members!==payload.can_manage_store_members)throw Error('保存回执尚未确认');
   const username=payload.username;member=null;editorScope='';form.reset();field('password').value='';
   say(`已${original?'更新':'创建'} ${username}。${original?'该成员需重新登录。':'请单独交付初始密码。'}`);
   try{await load(username,()=>owner===stamp()&&actor===context().user&&authorized(),true);}catch{if(owner===stamp()&&actor===context().user)say(`已保存 ${username}，名单刷新失败；请点“刷新成员”核对。`,true);}
  }catch(error){if(fresh()){needsRead=![400,401,403,409,422,429].includes(error.status);say(needsRead?'保存结果未确认；请先刷新当前范围成员核对，暂勿再次提交密码。':error.message||'成员保存未完成，请核对后重试。',true);}}
  finally{if(payload)delete payload.password;busy=false;sync();}
 }
 form.addEventListener('submit',submit);field('role').addEventListener('change',sync);cancel.addEventListener('click',reset);sync();
 return {load,probe:(highlight='',accept=()=>true)=>load(highlight,accept,false,false),reset,scope:()=>writable()?{...management.scope}:null};
}
