"""Natural DOM search result contract; never an API has_more claim."""
import re
from urllib.parse import parse_qs, urlsplit
from xhs_search_range import validate_checkpoint

ROW_FIELDS = {'note_id','xsec_token','xsec_source','title','author','url',
              'author_avatar_url','cover_url'}
STATES = {'more','plateau','explicit_end','unknown'}


def validate_range(value, *, keyword=None):
    if not isinstance(value,dict) or set(value) != {'state','checkpoint','delivered_ids'} or value['state'] not in STATES:
        raise ValueError('natural_search_range_invalid')
    checkpoint=value['checkpoint']
    validate_checkpoint(checkpoint)
    if value['state'] != checkpoint['range_state'] or (keyword is not None and checkpoint['keyword'] != keyword):
        raise ValueError('natural_search_range_invalid')
    delivered=value['delivered_ids']
    if (not isinstance(delivered,list) or len(delivered)>100000 or
            any(type(item) is not str or not re.fullmatch('[0-9a-f]{24}',item) for item in delivered)
            or len(set(delivered))!=len(delivered) or delivered != checkpoint['delivered_ids']):
        raise ValueError('natural_search_range_invalid')
    return value


def validate_rows(rows):
    if not isinstance(rows,list) or len(rows)>40:
        raise ValueError('natural_search_rows_invalid')
    seen=set()
    for row in rows:
        if not isinstance(row,dict) or set(row)!=ROW_FIELDS or any(type(value) is not str for value in row.values()):
            raise ValueError('natural_search_rows_invalid')
        ident=row['note_id']
        if (not re.fullmatch('[0-9a-f]{24}',ident) or ident in seen or not row['title'] or
                len(row['title'])>300 or len(row['author'])>120 or not 0<len(row['xsec_token'])<=2048 or
                row['xsec_source'] not in {'','pc_search','pc_note','pc_user','pc_feed'}):
            raise ValueError('natural_search_rows_invalid')
        seen.add(ident)
        try:
            parsed=urlsplit(row['url'])
            query=parse_qs(parsed.query,keep_blank_values=True,max_num_fields=16)
            if (len(row['url'])>8192 or parsed.scheme!='https' or parsed.hostname!='www.xiaohongshu.com' or
                    parsed.port not in (None,443) or parsed.username or parsed.password or parsed.fragment or
                    not re.fullmatch(r'/(?:explore|search_result)/'+ident+r'/?',parsed.path) or
                    query.get('xsec_token')!=[row['xsec_token']] or
                    query.get('xsec_source',[''])!=[row['xsec_source']] or
                    any(len(k)>64 or len(v)!=1 or len(v[0])>2048 for k,v in query.items())):
                raise ValueError
            for name in ('author_avatar_url','cover_url'):
                if not row[name]:continue
                media=urlsplit(row[name]);host=media.hostname or ''
                if (len(row[name])>2048 or media.scheme!='https' or media.port not in (None,443) or
                        media.username or media.password or media.fragment or
                        not (host in ('xhscdn.com','xiaohongshu.com') or
                             host.endswith('.xhscdn.com') or host.endswith('.xiaohongshu.com'))):
                    raise ValueError
        except (TypeError,ValueError):
            raise ValueError('natural_search_rows_invalid') from None
        if any(any(ord(char)<32 or ord(char)==127 for char in value) for value in row.values()):
            raise ValueError('natural_search_rows_invalid')
    return rows


def validate_result(envelope):
    if (not isinstance(envelope,dict) or set(envelope)!={'code','_transport','data'} or
            type(envelope['code']) is not int or envelope['code']!=0 or envelope['_transport']!='natural_dom' or
            not isinstance(envelope['data'],dict) or set(envelope['data'])!={'items','range'}):
        raise ValueError('natural_search_result_invalid')
    rows=validate_rows(envelope['data']['items'])
    info=validate_range(envelope['data']['range'])
    if not {row['note_id'] for row in rows}.issubset(info['delivered_ids']):
        raise ValueError('natural_search_result_invalid')
    return envelope['data']


def map_notes(envelope):
    data=validate_result(envelope)
    return [{'platform':'xiaohongshu','source_id':row['note_id'],'title':row['title'],
             'author':row['author'],'author_id':'','author_avatar_url':row['author_avatar_url'],
             'cover_url':row['cover_url'],'text':'','url':row['url'],'published_at':'','region':'',
             'source_type':'note','stage':'待核实（笔记）'} for row in data['items']]
