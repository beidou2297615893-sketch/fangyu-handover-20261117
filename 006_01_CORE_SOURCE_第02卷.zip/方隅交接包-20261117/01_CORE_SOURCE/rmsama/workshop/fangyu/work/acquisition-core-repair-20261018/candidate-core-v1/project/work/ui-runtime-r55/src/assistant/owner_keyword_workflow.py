"""Explicit local-owner keyword assistance. No platform/search/startup AI calls.

The caller retains a local personal_owner identity. Remote member credentials
remain in the existing owner_ai_cloud_v1 binding; no cloud_bound promotion.
"""
from copy import deepcopy
import re
import threading

from core import CoreError
from core.service_plans import require_feature
from integrations import Integrations, IntegrationError
from .ai_workflow import LocalAIWorkflow, digest
from .ai_attempts import AIRequestReview
from .self_operating_read import OwnerReadWorkspace, _OwnerReadInstance
from .self_operating_source_intent import OwnerSourceIntent, _stable_actor

_SEAL=object()
_OPS=frozenset({'ai_profile','keyword_suggest','ai_attempt_status'})

class OwnerKeywordError(CoreError):
    code='OWNER_KEYWORD_REVIEW'
    auto_retry=False
    def __init__(self,message,*,mutation_committed=False):
        super().__init__(message);self.mutation_committed=mutation_committed

class _OwnerKeywordHost:
    def __init__(self,seal,service,token,user):
        if seal is not _SEAL or type(service) is not OwnerKeywordWorkflow:
            raise OwnerKeywordError('关键词建议需要可信本人范围')
        self._seal,self.service,self.token=seal,service,token
        self.user=deepcopy(user);self.actor=digest(_stable_actor(user));self.provider=None
        self.profile=None;self.attempt_snapshot=None;self.last_attempt=None
        self.check(user,feature=False)

    def check(self,user,*,feature=True):
        if self._seal is not _SEAL or type(self.service) is not OwnerKeywordWorkflow:
            raise OwnerKeywordError('原关键词建议范围已变化，请保留原编号')
        current=self.service._current(self.token)
        if digest(_stable_actor(current))!=self.actor or digest(_stable_actor(user))!=self.actor:
            raise OwnerKeywordError('原本人身份已变化，请保留原关键词请求编号',mutation_committed=None)
        if feature:require_feature(self.service.server.company,'strategy')
        return current

class _OwnerKeywordAICloudScope:
    """Separate exact scope; never expands the source-intent scope's 3 methods."""
    def __init__(self,seal,host,binding):
        if seal is not _SEAL or type(host) is not _OwnerKeywordHost:
            raise IntegrationError('关键词 AI 服务范围无法核对')
        self._seal,self.host=seal,host
        self.integrations=host.service.integrations;self.binding=deepcopy(binding)
        self.config={'cloud':{k:binding['remote'][k] for k in ('endpoint','environment_id')},
            'sessions':{host.user['id']:deepcopy(binding['session'])}}

    def check(self,user,config,operation):
        if (self._seal is not _SEAL or type(self.host) is not _OwnerKeywordHost
            or self.host.service.integrations is not self.integrations or operation not in _OPS or config!=self.config):
            raise IntegrationError('本用途仅允许 AI 资料、明确关键词建议与原关键词请求核对')
        self.host.check(user,feature=operation!='ai_attempt_status')
        if self.host.service.connection._configured(self.host)!=self.binding:
            raise IntegrationError('原 AI 成员绑定已变化；保留原关键词编号，未自动重发')
        self.host.service._check_attempt_snapshot(self.host)
        return self.binding['remote']['company_id']

    def session(self):return deepcopy(self.binding['session'])

class _OwnerKeywordAIWorkflow(LocalAIWorkflow):
    def _key(self,user,kind,payload,profile):
        return digest(['owner_keyword_workflow_v1',self.host_context(),super()._key(user,kind,payload,profile)])

class OwnerKeywordWorkflow:
    ACTIONS=frozenset({'keyword_recommend','keyword_library','keyword_state','owner_keyword_attempt_status'})
    def __init__(self,workspace):
        if (type(workspace) is not OwnerReadWorkspace or type(workspace.instance) is not _OwnerReadInstance
            or type(workspace._intent) is not OwnerSourceIntent or workspace._intent.workspace is not workspace
            or type(workspace.server.integrations) is not Integrations
            or workspace.server.integrations.core is not workspace.server.core):
            raise OwnerKeywordError('关键词建议必须沿可信本人实例与原 AI 连接创建')
        self.workspace,self.connection=workspace,workspace._intent
        self.server,self.core,self.instance=workspace.server,workspace.server.core,workspace.instance
        self.integrations=self.server.integrations
        self._tls=threading.local();self._lock=threading.RLock();self._identity=None
        self.ai=_OwnerKeywordAIWorkflow(self.core,self._cloud,company=lambda:self.server.company,host_context=self._context)
        self.ai.host_context=self._context

    def _current(self,token):
        if (self.workspace._intent is not self.connection or self.connection.workspace is not self.workspace
            or self.workspace.instance is not self.instance or self.server.integrations is not self.integrations
            or self.server.core is not self.core):
            raise OwnerKeywordError('关键词建议的原本人实例已变化，请保留原编号',mutation_committed=None)
        user=self.connection._current(token)
        if user.get('personal_owner') is not True or user.get('role')!='admin' or user.get('cloud_bound') not in (None,False):
            raise OwnerKeywordError('只能在本人的自用工作台管理关键词')
        identity=digest(_stable_actor(user))
        if self._identity is None:self._identity=identity
        if self._identity!=identity:raise OwnerKeywordError('关键词库本人身份已变化，请保留原编号',mutation_committed=None)
        return user

    def _host(self):
        host=getattr(self._tls,'host',None)
        if type(host) is not _OwnerKeywordHost or host.service is not self:
            raise IntegrationError('关键词 AI 调用不在当前明确本人操作内')
        return host

    def _context(self):
        host=self._host();host.check(host.user,feature=False)
        if host.provider is None:raise IntegrationError('原关键词 AI 服务绑定无法核对')
        host.provider.check(host.user,host.provider.config,'ai_attempt_status')
        remote=host.provider.binding['remote']
        return {'usage_scope':'owner_keyword_workflow_v1','local_instance_id':self.connection.instance_id,
            'local_actor_digest':host.actor,'environment_id':remote['environment_id'],'company_id':remote['company_id'],
            'remote_binding_digest':self.connection._provider_digest(host.provider.binding)}

    def _cloud(self,user,operation,data):
        host=self._host()
        if host.provider is None:raise IntegrationError('AI 成员服务尚未明确连接')
        if operation not in _OPS or type(data) is not dict:raise IntegrationError('关键词用途不允许此操作')
        if operation=='ai_profile' and data:raise IntegrationError('关键词资料不能借作连接测试或配置操作')
        if operation=='ai_attempt_status' and (set(data)!={'operation_kind','request_id'} or data['operation_kind']!='keyword_suggest'):
            raise IntegrationError('只能核对原关键词请求；不能借此核对其他模型用途')
        if operation=='keyword_suggest':
            if set(data)-{'city','area','seeds','count','exclude_keywords','expected_revision','expected_rules_version','request_id','submission_id'}:
                raise IntegrationError('关键词建议包含未授权字段')
            if any(type(data.get(k)) is not str or re.fullmatch(r'[0-9a-fA-F-]{36}',data[k]) is None for k in ('request_id','submission_id')):
                raise IntegrationError('新模型请求只能使用当前本机生成的原编号')
        if operation in ('keyword_suggest','ai_attempt_status'):
            self._bind_attempt_snapshot(host,data,dispatch=operation=='keyword_suggest')
            host.last_attempt=deepcopy(host.attempt_snapshot)
        try:
            result=self.integrations._cloud(host.provider.config,user,operation,_owner_scope=host.provider,**data)
        finally:
            # The transport frame ends before legacy Attempts transitions its
            # own row to response_received/validated/unknown under its CAS.
            host.attempt_snapshot=None
        if operation=='ai_profile':host.profile=deepcopy(result.get('config',result))
        return result

    def _bind_attempt_snapshot(self,host,data,*,dispatch):
        user=host.user
        row=next((r for r in self.core.store.list('ai_attempts',user['tenant_id'])
            if r.get('owner')==user['username'] and r.get('request_id')==data['request_id']),None)
        principal,context=self.ai.attempts._principal(user)
        if (row is None or row.get('operation')!='keyword_suggest' or row.get('principal_digest')!=principal
            or row.get('host_digest')!=context or type(row.get('context_digest')) is not str
            or re.fullmatch(r'[0-9a-f]{64}',row['context_digest']) is None
            or type(row.get('submission_id')) is not str or re.fullmatch(r'[0-9a-fA-F-]{36}',row['submission_id']) is None):
            raise AIRequestReview('原关键词请求的本人、提交编号或规则摘要需核对；未重发')
        if dispatch:
            profile=host.profile or {}
            original_context={k:profile.get(k) for k in ('revision','rules_version','provider','model','reasoning_effort')}
            if (row['submission_id']!=data['submission_id'] or row.get('state')!='submitted'
                or row['context_digest']!=digest(original_context)
                or data.get('expected_rules_version')!=profile.get('rules_version')
                or (type(profile.get('revision')) is int and data.get('expected_revision')!=profile['revision'])):
                raise AIRequestReview('当前关键词提交的原编号或规则版本已变化；未开始模型请求')
        # Status transport has no revision/rules fields: retain the ORIGINAL
        # stored context_digest and submission, never invent old raw versions.
        host.attempt_snapshot=deepcopy(row)

    def _check_attempt_snapshot(self,host):
        saved=host.attempt_snapshot
        if saved is not None:
            row=self.core.store.get('ai_attempts',saved['id'])
            if row!=saved:raise AIRequestReview('原关键词请求记录已变化；保留原号，未重发')

    def execute(self,token,action,data):
        if action not in self.ACTIONS or type(data) is not dict:raise OwnerKeywordError('关键词请求参数无效')
        with self._lock:
            user=self._current(token)
            if getattr(self._tls,'host',None) is not None:raise OwnerKeywordError('明确关键词操作不能嵌套')
            # Local history and durable selection never need a cloud/model grant.
            if action=='keyword_library':
                if set(data)-{'library_id'} or ('library_id' in data and (type(data['library_id']) is not str or not data['library_id'])):
                    raise OwnerKeywordError('关键词历史仅接受本地组合编号')
                result=self.ai.library(user,data);self._current(token);return result
            if action=='keyword_state':
                result=self.ai.keyword_state(user,data)
                try:self._current(token)
                except CoreError:
                    if data.get('mode')=='save':
                        raise OwnerKeywordError('关键词保存已提交；请由本人重新核对，不可自动重复保存。',mutation_committed=True) from None
                    raise
                return result
            if action=='keyword_recommend':
                if set(data)-{'city','area','seeds','count','exclude_keywords'}:
                    raise OwnerKeywordError('关键词建议仅接受城市、区域、需求词、数量和已有词')
                if type(data.get('city')) is not str or not data['city'].strip() or len(data['city'].strip())>60:
                    raise OwnerKeywordError('请填写获客城市')
                if 'area' in data and (type(data['area']) is not str or len(data['area'].strip())>80):raise OwnerKeywordError('目标区域格式无效')
                if type(data.get('count',50)) is not int or data.get('count',50) not in (10,20,50,100):raise OwnerKeywordError('单次推荐数量为10、20、50或100')
                if type(data.get('seeds')) is not list or not 1<=len(data['seeds'])<=20 or any(type(s) is not str or not s.strip() or len(s)>80 for s in data['seeds']):raise OwnerKeywordError('请填写1至20条需求词')
                require_feature(self.server.company,'strategy')
            else:
                if set(data)!={'request_id'} or type(data['request_id']) is not str or re.fullmatch(r'[0-9a-fA-F-]{36}',data['request_id']) is None:
                    raise OwnerKeywordError('请核对本机原关键词请求编号')
                row=next((r for r in self.core.store.list('ai_attempts',user['tenant_id']) if r.get('owner')==user['username'] and r.get('request_id')==data['request_id']),None)
                if row is None or row.get('operation')!='keyword_suggest':raise OwnerKeywordError('此编号不是本人的原关键词请求')
            host=_OwnerKeywordHost(_SEAL,self,token,user);self._tls.host=host
            try:
                binding=self.connection._configured(host)
                host.provider=_OwnerKeywordAICloudScope(_SEAL,host,binding)
                if action=='owner_keyword_attempt_status':return self.ai.attempts.status(user,data)
                result=self.ai.keywords(user,data);host.check(user);return result
            except Exception as error:
                # Only this invocation's verified binding may reveal its original
                # identifiers. Never guess a recent row or expose remote content.
                failure=OwnerKeywordError('原关键词操作需要核对；保留原编号，不自动建议或保存。',
                    mutation_committed=getattr(error,'mutation_committed',None))
                saved=host.last_attempt
                if saved is not None:
                    try:current=self.core.store.get('ai_attempts',saved['id'])
                    except Exception:current=None
                    fields=('tenant_id','owner','operation','request_id','submission_id','principal_digest','host_digest','context_digest')
                    matched=type(current) is dict and all(current.get(k)==saved.get(k) for k in fields)
                    state=current.get('state') if matched else None
                    failure.request_id=saved['request_id'];failure.submission_id=saved['submission_id']
                    failure.operation_kind='keyword_suggest'
                    failure.state=state if state in ('prepared','submitted','unknown','not_dispatched','response_received','validated') else 'unknown'
                raise failure from None
            finally:
                if getattr(self._tls,'host',None) is host:del self._tls.host
