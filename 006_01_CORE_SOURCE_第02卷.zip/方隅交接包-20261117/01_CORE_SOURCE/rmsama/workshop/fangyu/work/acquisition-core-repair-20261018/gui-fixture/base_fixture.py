"""Owned loopback UI fixture. Real local business code; synthetic cloud/platform IO."""
from __future__ import annotations
import argparse
import base64
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import html
import hmac
import http.client
import importlib.util
import json
import os
from pathlib import Path
import secrets
import shutil
import socket
import sqlite3
import sys
import threading
import time
import uuid
from urllib.parse import parse_qs, urlsplit
from unittest.mock import patch

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[2]
COMPANY = 'fangyu-apartment-client'
PASSWORD = '[REDACTED:assigned_secret]'


def digest(value):
    raw = value if isinstance(value, bytes) else json.dumps(value, ensure_ascii=False,
        sort_keys=True, separators=(',', ':'), allow_nan=False).encode()
    return hashlib.sha256(raw).hexdigest()


def load(name, path):
    module = importlib.util.module_from_spec(importlib.util.spec_from_loader(name, loader=None))
    module.__file__ = str(path)
    sys.modules[name] = module
    exec(compile(path.read_bytes(), str(path), 'exec'), module.__dict__)
    return module


def offline_guard(owned, release, public_roots):
    readable = [owned, release, Path(sys.prefix), Path(sys.base_prefix), *public_roots]
    blocked = []
    def audit(event, args):
        if event in ('socket.connect', 'socket.bind'):
            address = args[1]
            if not isinstance(address, tuple) or address[0] not in ('127.0.0.1', '::1'):
                blocked.append(event)
                raise RuntimeError('Fixture denies external sockets')
        if event == 'socket.getaddrinfo' and args[0] not in ('127.0.0.1', '::1', 'localhost', None):
            blocked.append(event)
            raise RuntimeError('Fixture denies external DNS')
        if event in ('subprocess.Popen', 'os.system', 'os.startfile', 'os.posix_spawn'):
            blocked.append(event)
            raise RuntimeError('Fixture denies external processes/CLI')
        if event == 'sqlite3.connect':
            target = Path(args[0]).resolve()
            if not target.is_relative_to(owned):
                blocked.append(event)
                raise RuntimeError('Fixture denies non-owned database')
        if event == 'open' and isinstance(args[0], (str, bytes, os.PathLike)):
            target = Path(os.fsdecode(args[0])).absolute()
            mode, flags = args[1] or '', args[2] or 0
            writes = any(c in str(mode) for c in 'wax+') or isinstance(flags, int) and bool(
                flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC))
            allowed = (target.is_relative_to(owned) or target == HERE/'LATEST.json') if writes else any(target.is_relative_to(p) for p in readable)
            if not allowed:
                blocked.append('write' if writes else 'read')
                raise RuntimeError('Fixture denies path outside owned/public source: ' + target.name)
    sys.addaudithook(audit)
    return blocked


class CloudStandin:
    """Same directory envelope as central client Cloud, credentials/session per actor."""
    def __init__(self, compiled):
        self.manifest = deepcopy(compiled['manifest'])
        self.configs = {r['store_id']: deepcopy(r['config']) for r in compiled['documents']
            if r.get('doc_type') == 'store_config_version'}
        if len(self.manifest['stores']) != 14 or {r['id'] for r in self.manifest['stores']} != set(self.configs):
            raise ValueError('Central fixture must contain the complete 14-store projection')
        self.calls, self.sessions = [], {}
        self.first_store = self.manifest['stores'][0]['id']

    def __call__(self, url, data, token=''):
        from integrations import IntegrationError
        op = data['operation']; self.calls.append(op)
        if op == 'login':
            name = data.get('username')
            if name not in ('fixture-admin', 'fixture-operator') or data.get('password') != PASSWORD:
                error = IntegrationError('隔离账号或密码错误'); error.http_status = 401; raise error
            token = 'fixture-' + secrets.token_urlsafe(24)
            self.sessions[token] = name
        else:
            name = self.sessions.get(token)
            if not name:
                error = IntegrationError('隔离会话已失效'); error.http_status = 401; raise error
        role = 'admin' if name == 'fixture-admin' else 'operator'
        user = {'username': name, 'role': role, 'disabled': False, 'can_reply': True,
            'can_export': True, **({'store_id': self.first_store} if role == 'operator' else {})}
        result = {'contract': 'fangyu-workspace-v1', 'company_id': COMPANY,
            'environment_id': 'overnight-fixture', 'user': user}
        if op == 'login':
            result.update(token=token, expires=time.time() + 36000)
        elif op == 'logout':
            self.sessions.pop(token, None)
        elif op == 'store_config_read':
            rows = [r for r in self.manifest['stores'] if role == 'admin' or r['id'] == self.first_store]
            result.update(schema='store-config-v1', read_only=True, mutation_committed=False,
                catalog_revision=self.manifest['active_revision'], catalog_digest=self.manifest['catalog_digest'],
                source_versions=deepcopy(self.manifest['source_versions']),
                actor={'username': name, 'role': role},
                scope={'type': 'company' if role == 'admin' else 'store', 'store_ids': [r['id'] for r in rows]},
                stores=deepcopy(rows))
            if data.get('store_id'):
                store = data['store_id']
                if store not in {r['id'] for r in rows}:
                    error = IntegrationError('隔离门店无授权'); error.http_status = 403; raise error
                config = deepcopy(self.configs[store])
                result.update(store_id=store, config=config, config_digest=digest(config))
        elif op != 'me':
            raise RuntimeError('Unsupported external standin operation: ' + op)
        return result


SAMPLES = [
    ('隔离客户甲', '我自己想租古北一居，明天下午3点能看房吗？整套房租硬上限人民币5000元/月。'),
    ('隔离客户乙', '我自己想租古北一居，预算人民币4000元/月；本人税后月收入人民币12000元。'),
    ('隔离客户丙', '我自己想租古北一居，明年才搬家，现在只是提前了解公寓。'),
    ('隔离客户丁', '这家咖啡店很好喝，喜欢这里的氛围。'),
    ('隔离客户戊', '朋友说“求租虹桥一居，预算5000元/月”，我自己已经租好了。'),
    ('隔离客户己', '我自己想租古北一居，明天下午三点能看房吗？整套租金硬上限人民币2000元/月。'),
]


class PlatformStandin:
    """External platform seam only; Core import/classification/database remain real."""
    def __init__(self, project_root, data_dir, company, *, scenario='ready'):
        from core.engine import Core
        self.core = Core(data_dir, PROJECT / 'work/ui-runtime-r55/src/resources', defer_startup_recovery=True)
        self.calls, self.receipts, self.workers, self.generations = [], [], [], {}
        self.scenario=scenario;self.prepared=set();self.jobs={};self.safety={};self.primary={}
        self.stop = threading.Event(); self._rental_after_import = None

    def account(self, user, platform='xiaohongshu'):
        account_id = self.primary.get((user['username'],platform)) or (
            ('fixture-xhs-' if platform=='xiaohongshu' else 'fixture-dy-') + user['username'])
        row = self.core.store.get('accounts', account_id)
        if not row:
            row = {'id': account_id, 'tenant_id': user['tenant_id'], 'cloud_owner': user['username'],
                'platform': platform, 'platform_uid': 'fixture-uid-' + platform + '-' + user['username'],
                'name': '隔离'+('小红书' if platform=='xiaohongshu' else '抖音')+'主账号',
                'status': 'login_required', 'conn_id': 'fixture-no-cookie',
                'message':'隔离退出账号；点击一键登录，无人工复核步骤'}
            self.core.store.put('accounts', row)
        self.primary[(user['username'],platform)]=account_id
        return row

    def create_account(self,user,data):
        platform=data['platform']
        if platform not in ('xiaohongshu','douyin'):raise ValueError('Fixture platform rejected')
        ident='fixture-account-'+uuid.uuid4().hex
        row={'id':ident,'tenant_id':user['tenant_id'],'cloud_owner':user['username'],'platform':platform,
            'platform_uid':'fixture-uid-'+ident,'name':data['name'] or '隔离新账号','status':'disconnected',
            'conn_id':'fixture-no-cookie','message':'隔离模拟账号；未连接真实平台'}
        self.core.store.put('accounts',row);self.primary[(user['username'],platform)]=ident
        self.calls.append('account_create:'+platform)
        return {'accountId':ident,'status':'completed','message':'隔离模拟账号已创建'}

    def _owned(self, user, entity, ident):
        row = self.core._get(entity, ident, user['tenant_id'])
        if row.get('cloud_owner') != user['username']:
            raise ValueError('Fixture scope rejected')
        if row.get('store_id') not in (None, '', user.get('_workbench_store_id')):
            raise ValueError('Fixture store scope rejected')
        return row

    def snapshot(self, user):
        account = self.account(user)
        dy=self.account(user,'douyin');prepared=user['username'] in self.prepared
        tasks = [r for r in self.core.store.list('tasks', user['tenant_id'])
            if r.get('cloud_owner') == user['username'] and r.get('store_id') == user.get('_workbench_store_id')]
        task = max(tasks, key=lambda r:r.get('created_at', ''), default=None)
        ready=prepared and account['status']=='ready' and not account.get('requiresReview')
        live = {'taskId': '', 'status': 'idle', 'canStart': ready, 'canPause': False, 'canResume': False,
            'read': 0, 'added': 0, 'analyzed': 0, 'duplicates': 0, 'message': '隔离平台回执；不访问真实平台'}
        if task:
            live.update(taskId=task['id'], status=task['status'], canStart=ready and task['status'] != 'running',
                canPause=task['status'] == 'running', canResume=task['status'] == 'paused',
                **task.get('fixtureCounts', {}), taskScope=task.get('fixtureScope', {}))
            live['counts']=deepcopy(task.get('fixtureCounts',{}))
        accounts=[{**r,'canConnect':prepared,'requiresReview':bool(r.get('requiresReview'))}
            for r in self.core.store.list('accounts',user['tenant_id']) if r.get('cloud_owner')==user['username']]
        return {'available': True, 'device': {'state': 'online' if prepared else 'unbound',
            'bound': prepared, 'canPrepare': True, 'prepared':prepared,
            'message': '隔离模拟电脑已准备；无真实设备许可' if prepared else '隔离模拟电脑待准备'},
            'accounts':accounts,'platforms':[{'id':r['platform'],'name':'小红书' if r['platform']=='xiaohongshu' else '抖音',
                'enabled':True,'accountId':r['id'],'accountName':r['name'],'status':r['status'],
                'canConnect':prepared,'requiresReview':bool(r.get('requiresReview')),'message':r.get('message','')}
                for r in (account,dy)],'acquisition':live}

    def prepare(self, user):
        self.prepared.add(user['username']);self.calls.append('prepare')
        return {'status':'completed','state':'online','phase':'prepared','accepted':True,
            'message':'隔离模拟电脑已准备；双平台可测试连接，无真实设备绑定'}

    def connect_account(self, user, data):
        account=self._owned(user,'accounts',data['accountId'])
        if user['username'] not in self.prepared:self.prepare(user)
        safety=self.safety.get(account['id'],{})
        if safety.get('reviewRequired'):
            return {'accountId':account['id'],'status':'failed','phase':'verification_required',
                'message':'隔离模拟验证码待人工复核；检查不会清除风险或自动继续'}
        for job in self.jobs.values():
            if job['accountId']==account['id'] and job['status']=='running':return self._public_job(job)
        ident='fixture-job-'+uuid.uuid4().hex
        job={'id':ident,'jobId':ident,'accountId':account['id'],'owner':user['username'],
            'tenant':user['tenant_id'],'store':user.get('_workbench_store_id'),'status':'running',
            'phase':'waiting_login','step':0,'message':'隔离模拟等待登录阶段；没有真实浏览器或扫码',
            'windowOpen':False,'persistentBrowser':False}
        self.jobs[ident]=job;account.update(status='logging_in',message=job['message'])
        self.core.store.put('accounts',account);self.calls.append('account_connect:'+account['platform'])
        return self._public_job(job)

    @staticmethod
    def _public_job(job):
        return {k:deepcopy(v) for k,v in job.items() if k not in ('owner','tenant','store','step')}

    def account_job(self,user,data):
        job=self.jobs.get(data['jobId'])
        if not job or (job['owner'],job['tenant'],job['store'])!=(user['username'],user['tenant_id'],user.get('_workbench_store_id')):
            raise ValueError('Fixture job scope rejected')
        account=self._owned(user,'accounts',job['accountId'])
        if job['status']=='running':
            job['step']+=1
            if job['step']==1:
                job.update(phase='checking',message='隔离模拟正在核对账号身份；不请求平台')
                account.update(status='checking',message=job['message'])
            elif self.scenario=='failure':
                job.update(status='failed',phase='connection_failed',message='隔离模拟连接失败；可重试测试，不是真实平台故障')
                account.update(status='failed',message=job['message'])
            elif (self.scenario=='verification' and account['platform']=='xiaohongshu'
                    and not self.safety.get(account['id'],{}).get('manualReviewed')):
                safety=self.safety.setdefault(account['id'],{'revision':1})
                safety.update(reviewRequired=True,windowOpen=False,viewerClosed=False,manualReviewed=False)
                job.update(status='failed',phase='verification_required',message='隔离模拟验证码已触发；请查看详情并人工复核')
                account.update(status='held',requiresReview=True,message=job['message'])
            else:
                job.update(status='completed',phase='connected',message='隔离模拟身份核对完成；没有真实平台请求')
                account.update(status='ready',requiresReview=False,message=job['message'])
            self.core.store.put('accounts',account)
        return self._public_job(job)

    def check_account(self,user,data):
        self.calls.append('account_check')
        return self.connect_account(user,data)

    def cancel_account(self,user,data):
        job=self.jobs.get(data['jobId'])
        if not job or job['owner']!=user['username'] or job['tenant']!=user['tenant_id'] or job['store']!=user.get('_workbench_store_id'):
            raise ValueError('Fixture job scope rejected')
        self._owned(user,'accounts',job['accountId'])
        job.update(status='cancelled',phase='cancelled',message='隔离模拟连接已取消')
        account=self._owned(user,'accounts',job['accountId']);account.update(status='disconnected',message=job['message'])
        self.core.store.put('accounts',account);return self._public_job(job)

    def read_account_safety(self, user, data):
        self._owned(user, 'accounts', data['accountId'])
        safety=self.safety.get(data['accountId'],{})
        required=bool(safety.get('reviewRequired'));window=bool(safety.get('windowOpen'))
        return {'accountId':data['accountId'],'revision':safety.get('revision',0),'reviewRequired':required,
            'verificationWindowOpen':window,'canConfirmReview':required and not window and safety.get('viewerClosed') is True,
            'reviewReason':'fixture_verification_required' if required else '',
            'message':'隔离模拟验证码待复核：先打开下方模拟页，完成后回工作台本人确认' if required else '隔离账号；无生产风险状态'}

    def open_account_verification(self,user,data):
        account=self._owned(user,'accounts',data['accountId']);safety=self.safety.get(account['id'],{})
        if not safety.get('reviewRequired'):raise ValueError('没有待复核的隔离验证码')
        safety.update(windowOpen=True,viewerClosed=False)
        self.calls.append('verification_open')
        return {'accountId':account['id'],'status':'verification_open','windowOpen':True,
            'message':'隔离模拟验证页已准备：'+getattr(self,'fixture_origin','')+'/fixture-verification?accountId='+account['id']+' 。仅测试本地状态，无真实验证码。'}

    def close_verification(self,user,account_id):
        self._owned(user,'accounts',account_id);safety=self.safety.get(account_id,{})
        if not safety.get('reviewRequired') or not safety.get('windowOpen'):raise ValueError('隔离验证页未打开')
        safety.update(windowOpen=False,viewerClosed=True);self.calls.append('verification_page_completed')

    def confirm_account_review(self,user,data):
        account=self._owned(user,'accounts',data['accountId']);safety=self.safety.get(account['id'],{})
        if data.get('confirmed') is not True or type(data.get('revision')) is not int:raise ValueError('隔离场景也须明确确认')
        if not safety.get('reviewRequired') or user['username'] not in self.prepared:raise ValueError('隔离账号没有当前可复核提醒')
        if data['revision']!=safety.get('revision'):raise ValueError('隔离复核版本冲突')
        if not safety.get('viewerClosed') or safety.get('windowOpen'):raise ValueError('请先完成并关闭隔离模拟验证页')
        if any(r.get('status')=='running' and r.get('account_id')==account['id'] for r in self.core.store.list('tasks',user['tenant_id'])):
            raise ValueError('隔离账号任务仍运行')
        safety.update(reviewRequired=False,manualReviewed=True,revision=safety['revision']+1)
        account.update(status='unverified',requiresReview=False,message='隔离人工复核已记录；仍需主动检查连接，不自动采集')
        self.core.store.put('accounts',account);self.calls.append('manual_review_confirmed')
        return self.read_account_safety(user,{'accountId':account['id']})

    def start_acquisition(self, user, data):
        account=self._owned(user, 'accounts', data['accountId'])
        if user['username'] not in self.prepared or account['status']!='ready' or account.get('requiresReview'):
            raise ValueError('隔离账号尚未准备并连接或仍待复核')
        if data['storeId'] != user.get('_workbench_store_id'): raise ValueError('Fixture store rejected')
        ident = 'fixture-task-' + uuid.uuid4().hex
        scope = {'storeId': data['storeId'], 'platform': data['platform'], 'accountId': data['accountId'],
            'keywords': data['keywords'], 'scope': 'search_comments', 'intentMode': 'all', 'excludes': [],
            'region': '', 'unknownPolicy': 'exclude', 'dailyLimit': 100, 'target': 100}
        if callable(getattr(self, 'task_scope_factory', None)):
            scope = self.task_scope_factory(data)
        task = {'id': ident, 'tenant_id': user['tenant_id'], 'cloud_owner': user['username'],
            'store_id': data['storeId'], 'platform': data['platform'], 'account_id': data['accountId'],
            'keywords':list(data['keywords']),
            'status': 'running', 'created_at': datetime.now(timezone.utc).isoformat(),
            'fixtureScope': scope, 'fixtureOffset': 0,
            'fixtureCounts': {'read':0,'added':0,'analyzed':0,'duplicates':0}}
        self.core.store.put('tasks', task)
        if data.get('requestBinding'):
            from core.acquisition_receipts import ENTITY,prepared_receipt
            receipt=prepared_receipt(user,task,data['requestBinding'])
            self.core.store.put(ENTITY,{**receipt,'state':'started','started_at':datetime.now(timezone.utc).isoformat()})
        if data.get('rentalAssessment', {}).get('enabled'):
            self.core.store.put('rental_task_context_v1', {'id': ident, 'tenant_id': user['tenant_id'],
                'owner': user['username'], 'enabled': True, 'store_id': data['storeId'],
                'rule_version': data['rentalAssessment']['ruleVersion']})
        self.calls.append('acquisition_start'); self._launch(user, ident)
        return {'taskId': ident, 'status': 'running', 'accepted': True, 'message': '隔离评论正在经过真实本地导入'}

    def _launch(self, user, ident):
        generation=self.generations.get(ident,0)+1;self.generations[ident]=generation
        def worker():
            for _ in range(3):
                if self.stop.wait(getattr(self, 'collection_interval', .6)): return
                with self.core.lock:
                    task = self._owned(user, 'tasks', ident)
                    if task['status'] != 'running' or self.generations.get(ident)!=generation: return
                    offset = task['fixtureOffset']
                    rows = self.sample_rows(ident, offset, min(offset+2, len(SAMPLES)))
                    result = self.core._import(rows, user['tenant_id'], user)
                    counts = task['fixtureCounts']; counts['read'] += len(rows)
                    counts['added'] += result['imported']; counts['duplicates'] += result['duplicates']
                    task.update(fixtureOffset=offset+len(rows)); self.core.store.put('tasks', task)
                    if task['fixtureOffset'] == len(SAMPLES):
                        task['status'] = 'completed'; self.core.store.put('tasks', task)
                        if callable(self._rental_after_import): self._rental_after_import(user, ident)
                        return
        thread = threading.Thread(target=worker, daemon=True); self.workers.append(thread); thread.start()

    @staticmethod
    def sample_rows(task, start=0, end=len(SAMPLES)):
        now = datetime.now(timezone.utc).isoformat()
        return [{'platform':'xiaohongshu', 'source_type':'comment', 'source_id':task+'-'+str(i),
            'comment_id':'fixture-comment-'+str(i), 'author_id':'fixture-person-'+str(i), 'author':name,
            'task_id':task, 'published_at':now, 'text':text, 'content_title':'隔离公寓求租来源',
            'note_url':'https://www.xiaohongshu.com/explore/123456789012345678901234'}
            for i,(name,text) in enumerate(SAMPLES) if start<=i<end]

    def pause_acquisition(self, user, data):
        with self.core.lock:
            task=self._owned(user,'tasks',data['taskId']);task['status']='paused';self.core.store.put('tasks',task)
            self.generations[task['id']]=self.generations.get(task['id'],0)+1
        return {'taskId':task['id'],'status':'paused'}

    def resume_acquisition(self, user, data):
        with self.core.lock:
            task=self._owned(user,'tasks',data['taskId'])
            if task['status']!='paused': raise ValueError('Fixture task not paused')
            task['status']='running';self.core.store.put('tasks',task)
        self._launch(user,task['id']);return {'taskId':task['id'],'status':'running'}

    def reply_guard(self, user, account_id):
        self._owned(user, 'accounts', account_id)

    def start_reply_queue(self, user, queue_id):
        queue = self.core._get('reply_queues', queue_id, user['tenant_id'])
        if queue.get('authorized_by') != user['id']: raise ValueError('Fixture queue owner rejected')
        self.receipts.append({'queueId':queue_id,'username':user['username'],
            'state':'receipt_standin_no_external_send','realSend':False})
        queue.update(status='cancelled',message='隔离发送回执；没有对外发送，草稿保留已审核')
        self.core.store.put('reply_queues',queue)

    def close(self):
        self.stop.set()
        for worker in self.workers: worker.join(3)
        self.core.adapters.close()


def install_verification_page(host):
    """Fixture-only form route, authenticated by the real host cookie/Backend."""
    original=host.StaticHandler
    class FixtureHandler(original):
        def _actor(self):
            origin='http://127.0.0.1:'+str(self.server.server_port)
            if self.headers.get('Host')!=origin[7:] or self.headers.get('Upgrade'):
                raise ValueError('Fixture host rejected')
            user,profile=self.server.backend._identity(self.session_token())
            self.server.backend._selected_store(user,profile)
            return user,origin
        def _page(self,text,form=''):
            body=('<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>隔离模拟验证</title>'
                '<h1>仅隔离模拟验证</h1><p>'+html.escape(text)+'</p>'+form+'</html>').encode()
            self.send_response(200);self.send_header('Content-Type','text/html; charset=utf-8')
            self.send_header('Content-Length',str(len(body)));self.send_header('Cache-Control','no-store')
            self.send_header('Content-Security-Policy',"default-src 'none'; form-action 'self'; base-uri 'none'; frame-ancestors 'none'")
            self.send_header('X-Content-Type-Options','nosniff');self.send_header('Referrer-Policy','no-referrer')
            self.end_headers();self.wfile.write(body);self.close_connection=True
        def do_GET(self):
            parsed=urlsplit(self.path)
            if parsed.path!='/fixture-verification':return super().do_GET()
            try:
                if parsed.scheme or parsed.netloc:raise ValueError('Invalid fixture URL')
                user,_=self._actor();query=parse_qs(parsed.query,strict_parsing=True)
                if set(query)!={'accountId'} or len(query['accountId'])!=1:raise ValueError('Invalid fixture account')
                ident=query['accountId'][0];runtime=self.server.backend.platform_runtime
                runtime._owned(user,'accounts',ident)
                if not runtime.safety.get(ident,{}).get('windowOpen'):raise ValueError('请先在工作台详情点打开验证网页')
                form=('<form method="post" action="/fixture-verification/complete">'
                    '<input type="hidden" name="accountId" value="'+html.escape(ident,quote=True)+'">'
                    '<input type="hidden" name="csrf" value="'+html.escape(self.server.csrf_token,quote=True)+'">'
                    '<button type="submit">完成隔离模拟验证并关闭</button></form>')
                return self._page('此页不连接小红书或抖音，没有真实验证码。按钮仅关闭隔离模拟窗口状态；随后须回工作台本人确认复核，再主动检查连接。',form)
            except Exception as error:
                return self.api_response(getattr(error,'status',403),{'ok':False,'error':{'code':'FIXTURE_VERIFICATION_REJECTED','message':str(error)}})
        def do_POST(self):
            if self.path!='/fixture-verification/complete':return super().do_POST()
            try:
                user,origin=self._actor()
                if (self.headers.get('Origin')!=origin or self.headers.get('Transfer-Encoding')
                        or self.headers.get('Content-Type','').split(';')[0]!='application/x-www-form-urlencoded'):
                    return self.reject()
                size=int(self.headers.get('Content-Length','0'))
                if not 1<=size<=4096:return self.reject(413)
                values=parse_qs(self.rfile.read(size).decode('utf-8'),strict_parsing=True)
                if set(values)!={'accountId','csrf'} or any(len(v)!=1 for v in values.values()):return self.reject(400)
                if not hmac.compare_digest(values['csrf'][0],self.server.csrf_token):return self.reject()
                self.server.backend.platform_runtime.close_verification(user,values['accountId'][0])
                return self._page('隔离模拟窗口状态已关闭；请关闭此标签页，回工作台刷新详情，点“本人已完成验证，确认复核”。此处未自动复核或重连。')
            except Exception as error:
                return self.api_response(getattr(error,'status',403),{'ok':False,'error':{'code':'FIXTURE_VERIFICATION_REJECTED','message':str(error)}})
    host.StaticHandler=FixtureHandler


def prepare(options):
    base = Path(options.base_release or options.candidate).resolve()
    if options.candidate and base.is_file():
        entry=json.loads(base.read_text('utf-8-sig'));base=Path(entry['release']).resolve()
        expected=entry.get('manifest_sha256')
    else: expected=None
    if not base.is_relative_to(PROJECT/'work/ui-native-r57/releases'): raise ValueError('Only customer release base permitted')
    manifest_raw=(base/'RELEASE.json').read_bytes()
    if expected and digest(manifest_raw).upper()!=expected.upper(): raise ValueError('Candidate pin mismatch')
    owned=HERE/'runs'/uuid.uuid4().hex;owned.mkdir(parents=True)
    code=owned/'code';code.mkdir()
    source=PROJECT/'work/ui-native-r57' if options.source else base
    names=['ui_native_host.py','workbench_backend.py','store_materials.py','store_materials_catalog.json',
        'rental_assessment.py','customer_workbench.py','reply_workbench.py','reply_delivery.py']
    # New source/release support modules are copied into the same isolated
    # code directory. Older immutable releases have neither and remain usable.
    names += [name for name in ('workspace_binding.py','lifecycle_log.py') if (source/name).is_file()]
    for name in names: shutil.copy2(source/name,code/name)
    vendor=PROJECT/'work/shared-backend-integration/vendor-src' if options.source else base/'resources/platform-runtime/vendor-src'
    shutil.copytree(vendor,code/'vendor',ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
    web=owned/'web'
    if options.source:
        ui=PROJECT/'work/ui-approved-implementation/ui-preview';web.mkdir()
        for path in ui.iterdir():
            if path.is_file() and path.suffix in ('.html','.css','.js','.mjs'):shutil.copy2(path,web/path.name)
        shutil.copytree(ui/'pages',web/'pages',ignore=shutil.ignore_patterns('__pycache__'))
    else:web=base/'web'
    compiled_path=Path(options.compiled or PROJECT/'work/central-store-config/compiled-fixture.json').resolve()
    compiled=json.loads(compiled_path.read_text('utf-8-sig'))
    (owned/'central-fixture.json').write_text(json.dumps(compiled,ensure_ascii=False),'utf-8')
    sys.path[:0]=[str(code),str(code/'vendor'),str(PROJECT/'work/ui-runtime-r55/src')]
    blocked=offline_guard(owned,base,[PROJECT/'work/ui-runtime-r55/src'])
    host=load('overnight_fixture_host',code/'ui_native_host.py')
    install_verification_page(host)
    _,files=host.verify_release(base,digest(manifest_raw))
    backend_module=load('overnight_fixture_backend',code/'workbench_backend.py')
    materials=load('store_materials',code/'store_materials.py')
    rental=load('rental_assessment',code/'rental_assessment.py')
    customers=load('overnight_fixture_customers',code/'customer_workbench.py')
    cloud=CloudStandin(compiled);created=[]
    company={'id':COMPANY,'name':'方隅隔离验收','edition':'customer','personalMode':False,'authMode':'managed',
        'releaseVersion':'fixture-only','platforms':['xiaohongshu','douyin'],
        'managedWorkspace':{'environment_id':'overnight-fixture','endpoint':'https://example.invalid/fixture'}}
    def factory(**kwargs):
        backend=backend_module.WorkbenchBackend(PROJECT,data_dir=owned/'data',company=company,
            platform_factory=lambda **kw:PlatformStandin(**kw,scenario=options.scenario),customer_factory=customers.CustomerWorkbench,
            materials_factory=lambda core:materials.StoreMaterials(core,code/'store_materials_catalog.json'),
            rental_factory=rental.RentalAssessmentService)
        created.append(backend);return backend
    network=patch('integrations.request_json',side_effect=cloud);network.start()
    runtime=host.SharedRuntime(base,files,owned/'state',project_root=PROJECT,profile='fixture',
        release_id='source-fixture' if options.source else base.name,data_dir=owned/'data',company=company,
        backend_factory=factory,source_root=web,assets_root=base/'web/assets').start()
    created[0].platform_runtime.fixture_origin='http://127.0.0.1:'+str(runtime.development.server_port)
    pins={p.name:digest(p.read_bytes()).upper() for p in code.iterdir() if p.is_file()}
    (owned/'PINS.json').write_text(json.dumps(pins,indent=2),'utf-8')
    return owned,runtime,created[0],cloud,blocked,network


def seed(backend, cloud):
    records={}
    for name in ('fixture-admin','fixture-operator'):
        boot=backend.dispatch('login',{'username':name,'password':PASSWORD})
        token=boot['token'];store=cloud.first_store
        if boot['selection']['storeId']!=store:
            boot=backend.dispatch('select_store',{'storeId':store,'expectedRevision':boot['selection']['revision']},token)
        current=boot['materials']['currentSelection'];material=boot['materials']['materials'][0]
        eligible=next(w['id'] for w in material['keywords'] if w['eligible'] and
            any('precise' in binding['presetIds'] for binding in w['bindings']))
        boot=backend.dispatch('apply_preset',{'storeId':store,'searchPresetId':'precise','intentPresetId':'standard',
            'expectedRevision':boot['selection']['revision'],'materialKey':current['materialKey'],
            'keywordIds':[eligible],'expectedMaterialRevision':current['revision'],
            'expectedCatalogDigest':boot['materials']['digest'],'confirmMaterialBinding':False},token)
        user,_=backend._identity(token);backend.platform_runtime.account(user)
        task='fixture-seed-'+name
        backend.core.store.put('tasks',{'id':task,'tenant_id':user['tenant_id'],'cloud_owner':name,
            'store_id':store,'platform':'xiaohongshu','status':'completed','created_at':'2000-01-01T00:00:00Z'})
        backend.core._import(PlatformStandin.sample_rows(task),user['tenant_id'],user)
        customers=backend.dispatch('customers',{},token)['customers']
        first=customers['items'][0]['id']
        reply=backend.dispatch('reply_read',{'storeId':store,'customerId':first},token)['replyWorkspace']
        comment=reply['comments'][0]
        saved=backend.dispatch('reply_save',{'storeId':store,'customerId':first,'leadId':comment['id'],
            'text':'隔离草稿：方便说一下预计入住时间和预算吗？','sourceDigest':comment['sourceDigest'],
            'expectedReplyId':'','expectedVersion':0,'requestId':'fixture-seed-draft-'+name},token)
        records[name]={'role':boot['session']['user']['role'],'storeId':store,'customers':customers['total'],
            'draftSaved':any(c.get('draft') for c in saved['replyWorkspace']['comments'])}
        backend.dispatch('logout',{},token)
    return records


def verify_http(runtime):
    conn=http.client.HTTPConnection('127.0.0.1',runtime.development.server_port,timeout=5)
    conn.request('GET','/api/workbench/bootstrap');response=conn.getresponse();boot=json.loads(response.read())
    assert response.status==200
    csrf=boot['csrfToken'];origin='http://127.0.0.1:'+str(runtime.development.server_port)
    headers={'Content-Type':'application/json','Origin':origin,'X-Fangyu-CSRF':csrf}
    conn.request('POST','/api/workbench',json.dumps({'action':'login','data':{'username':'fixture-admin','password':PASSWORD}}),headers)
    response=conn.getresponse();value=json.loads(response.read());assert response.status==200,value
    cookie=response.getheader('Set-Cookie').split(';',1)[0];headers['Cookie']=cookie
    assert '_fixture_' in cookie
    conn.request('GET','/api/workbench/customers',headers={'Cookie':cookie})
    response=conn.getresponse();value=json.loads(response.read());assert response.status==200 and value['customers']['total']==6,value
    conn.request('GET','/');response=conn.getresponse();html=response.read();assert response.status==200 and b'<!' in html
    conn.close()
    return {'loopbackHTTP':True,'realHostLogin':True,'fixtureCookie':True,'realHTTPList':True,'html':True}


def verify_flows(backend,cloud):
    boot=backend.dispatch('login',{'username':'fixture-admin','password':PASSWORD});token=boot['token']
    store=cloud.first_store;user,_=backend._identity(token)
    backend.dispatch('platform_prepare',{},token)
    connected=backend.dispatch('account_check',{'accountId':backend.platform_runtime.account(user)['id']},token)['job']
    if connected.get('jobId'):
        for _ in range(2):connected=backend.dispatch('account_job',{'jobId':connected['jobId']},token)['job']
    assert connected['status']=='completed',connected
    assert len(boot['stores'])==14 and boot['session']['user']['role']=='admin'
    params={'query':'隔离客户甲','filter':'all','sort':'intent','sortDirection':'desc'}
    listing=backend.dispatch('customers',params,token)['customers'];assert listing['total']==1
    ident=listing['items'][0]['id']
    detail=backend.dispatch('customer_detail',{'id':ident},token)['customer'];assert detail['item']['id']==ident
    exported=backend.dispatch('customer_export',params,token)['file']
    assert base64.b64decode(exported['dataBase64']).startswith(b'PK\x03\x04')
    workspace=backend.dispatch('reply_read',{'storeId':store,'customerId':ident},token)['replyWorkspace']
    row=workspace['comments'][0];draft=row.get('draft')
    common={'storeId':store,'customerId':ident,'leadId':row['id'],'sourceDigest':row['sourceDigest']}
    saved=backend.dispatch('reply_save',{**common,'text':'隔离核验草稿：请确认入住时间。',
        'expectedVersion':draft['version'] if draft else 0,'expectedReplyId':draft['id'] if draft else '',
        'requestId':'fixture-verify-save'},token)['replyWorkspace']
    saved_row=next(c for c in saved['comments'] if c['id']==row['id']);draft=saved_row['draft']
    account=backend.platform_runtime.account(user)['id']
    reviewed=backend.dispatch('reply_review',{**common,'expectedVersion':draft['version'],
        'expectedReplyId':draft['id'],'requestId':'fixture-verify-review','accountId':account,'confirmed':True},token)['replyWorkspace']
    assert next(c for c in reviewed['comments'] if c['id']==row['id'])['reviewCurrent']
    prepared=backend.dispatch('reply_delivery_prepare',{'storeId':store,'requestId':'fixture-verify-prepare',
        'items':[{'customerId':ident,'leadId':row['id'],'sourceDigest':row['sourceDigest'],
            'replyId':draft['id'],'version':draft['version'],'accountId':account}]},token)['delivery']
    result=backend.dispatch('reply_delivery_start',{'storeId':store,'id':prepared['id'],
        'snapshotDigest':prepared['snapshotDigest'],'confirmed':True,'requestId':'fixture-verify-delivery'},token)
    assert backend.platform_runtime.receipts[-1]['realSend'] is False
    assert backend.core.store.get('replies',draft['id'])['status']=='approved'
    started=backend.dispatch('acquisition_start',{'storeId':store,'expectedRevision':boot['selection']['revision'],
        'platform':'xiaohongshu','accountId':account,'region':'','time':'最近7天','requestId':'fixture-verify-acquisition'},token)
    task=started['job']['taskId']
    backend.dispatch('acquisition_pause',{'taskId':task},token)
    backend.dispatch('acquisition_resume',{'taskId':task},token)
    for worker in backend.platform_runtime.workers:worker.join(5)
    row=backend.core.store.get('tasks',task);assert row['status']=='completed' and row['fixtureCounts']['read']==6
    backend.dispatch('logout',{},token)
    operator=backend.dispatch('login',{'username':'fixture-operator','password':PASSWORD});token=operator['token']
    assert len(operator['stores'])==1 and operator['session']['user']['role']=='operator'
    denied=False
    try:backend.dispatch('select_store',{'storeId':cloud.manifest['stores'][1]['id'],
        'expectedRevision':operator['selection']['revision']},token)
    except ValueError:denied=True
    assert denied
    backend.dispatch('logout',{},token)
    return {'admin14Operator1':True,'crossStoreRejected':True,'presetCAS':True,
        'listFilterDetailExcel':True,'draftSaveReviewReal':True,'deliveryValidationRealReceiptStandin':True,
        'noReplyMarkedSent':True,'collectionStandinRealImportPauseResume':True}


def verify_scenario(backend,cloud,runtime):
    boot=backend.dispatch('login',{'username':'fixture-admin','password':PASSWORD});token=boot['token']
    user,_=backend._identity(token);platform=backend.platform_runtime;scenario=platform.scenario
    snapshot=backend.dispatch('platform_snapshot',{},token)['platform'];assert snapshot['device']['state']=='unbound'
    prepared=backend.dispatch('platform_prepare',{},token);assert prepared['platform']['device']['state']=='online'
    stages={}
    for system in ('xiaohongshu','douyin'):
        created=backend.dispatch('account_create',{'platform':system,'name':'隔离场景'+system},token)['job']
        account=created['accountId'];connected=backend.dispatch('account_connect',{'accountId':account},token)['job']
        cancelled=backend.dispatch('account_cancel',{'jobId':connected['jobId']},token)['job']
        assert cancelled['status']=='cancelled'
        connected=backend.dispatch('account_connect',{'accountId':account},token)['job']
        assert connected['phase']=='waiting_login';job=connected['jobId']
        checking=backend.dispatch('account_job',{'jobId':job},token)['job'];assert checking['phase']=='checking'
        terminal=backend.dispatch('account_job',{'jobId':job},token)['job'];stages[system]=terminal['phase']
        if scenario=='failure':assert terminal['status']=='failed'
        elif scenario=='verification' and system=='xiaohongshu':
            assert terminal['phase']=='verification_required'
            pending=backend.dispatch('account_safety',{'accountId':account},token)['job'];assert pending['reviewRequired']
            blocked=backend.dispatch('account_check',{'accountId':account},token)['job'];assert blocked['status']=='failed'
            opened=backend.dispatch('account_verification_open',{'accountId':account},token)['job'];assert opened['windowOpen']
            wrong=False
            try:backend.dispatch('account_review_confirm',{'accountId':account,'revision':pending['revision'],'confirmed':True},token)
            except ValueError:wrong=True
            assert wrong
            # Actual fixture form route, real host cookie/session + Origin/CSRF. No platform browser.
            conn=http.client.HTTPConnection('127.0.0.1',runtime.development.server_port,timeout=5)
            headers={'Cookie':runtime.development.session_cookie+'='+token,'Origin':platform.fixture_origin,
                'Content-Type':'application/x-www-form-urlencoded'}
            conn.request('GET','/fixture-verification?accountId='+account,headers={'Cookie':headers['Cookie']})
            response=conn.getresponse();body=response.read();assert response.status==200 and b'<form' in body
            from urllib.parse import urlencode
            form=urlencode({'accountId':account,'csrf':runtime.development.csrf_token})
            conn.request('POST','/fixture-verification/complete',form,{**headers,'Origin':'https://example.invalid'})
            response=conn.getresponse();response.read();assert response.status==403
            conn.request('POST','/fixture-verification/complete',form,headers)
            response=conn.getresponse();response.read();assert response.status==200;conn.close()
            latest=backend.dispatch('account_safety',{'accountId':account},token)['job'];assert latest['canConfirmReview']
            conflict=False
            try:backend.dispatch('account_review_confirm',{'accountId':account,'revision':latest['revision']+1,'confirmed':True},token)
            except ValueError:conflict=True
            assert conflict
            reviewed=backend.dispatch('account_review_confirm',{'accountId':account,'revision':latest['revision'],'confirmed':True},token)['job']
            assert not reviewed['reviewRequired'] and platform.account(user)['status']=='unverified'
            resumed=backend.dispatch('account_check',{'accountId':account},token)['job']
            for _ in range(2):resumed=backend.dispatch('account_job',{'jobId':resumed['jobId']},token)['job']
            assert resumed['status']=='completed'
        else:assert terminal['status']=='completed'
    backend.dispatch('logout',{},token)
    return {'scenario':scenario,'platformStages':stages,'statefulPrepare':True,'bothPlatformsEnabled':True,
        'manualVerificationFormAndRevision':scenario=='verification','syntheticOnly':True}


def verify_guard():
    checks={}
    def denied(name,callback):
        try:callback()
        except RuntimeError:checks[name]=True
        else:raise AssertionError('Guard failed: '+name)
    # Hooks reject before OS IO. No packet/process/outside file is created.
    with socket.socket() as sock:
        denied('externalSocketRejected',lambda:sock.connect(('192.0.2.1',80)))
    denied('subprocessRejected',lambda:sys.audit('subprocess.Popen','fixture-never-executed',[],None,None))
    denied('outsideWriteRejected',lambda:open(HERE/'MUST-NOT-CREATE.txt','w'))
    denied('outsideDatabaseRejected',lambda:sqlite3.connect(str(HERE/'MUST-NOT-CREATE.sqlite3')))
    return checks


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    mode=parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--source',action='store_true');mode.add_argument('--candidate')
    parser.add_argument('--base-release');parser.add_argument('--compiled');parser.add_argument('--verify',action='store_true')
    parser.add_argument('--scenario',choices=('ready','failure','verification'),default='ready')
    options=parser.parse_args(argv)
    if options.source and not options.base_release:parser.error('--source requires --base-release')
    owned,runtime,backend,cloud,blocked,network=prepare(options)
    try:
        seeds=seed(backend,cloud)
        verification={'status':'PASS','profile':'fixture','seeded':seeds,'realLocalCode':['host','authentication integration',
            'store scope/CAS','Core import/local classification','rental assessment service','customer list/detail/filter/Excel',
            'reply save/review/handoff/delivery validation'],
            'standins':['enterprise cloud sessions/directory','platform account/device/read/collection scheduling','outbound send receipt only'],
            'notProven':['real platform login/CLI throughput/risk recovery','paid AI prompt execution','new admin bundle actions until supported by selected backend'],
            'productionDataAccess':False,'externalSocketsAllowed':False,'subprocessesAllowed':False}
        if options.verify:
            verification.update(verify_http(runtime));verification.update(verify_scenario(backend,cloud,runtime))
            if options.scenario!='failure':verification.update(verify_flows(backend,cloud))
            verification.update(verify_guard())
        (owned/'VERIFY.json').write_text(json.dumps(verification,ensure_ascii=False,indent=2),'utf-8')
        public={'status':'READY','PID':os.getpid(),'profile':'fixture','instanceId':runtime.instance_id,
            'scenario':options.scenario,
            'URL':'http://127.0.0.1:'+str(runtime.development.server_port)+'/',
            'verificationURLPattern':'http://127.0.0.1:'+str(runtime.development.server_port)+'/fixture-verification?accountId=ACCOUNT_ID',
            'runDirectory':str(owned),'stopFile':str(owned/'STOP'),
            'credentials':{'admin':'fixture-admin','operator':'fixture-operator','password':PASSWORD}}
        (owned/'PUBLIC.json').write_text(json.dumps(public,ensure_ascii=False,indent=2),'utf-8')
        (HERE/'LATEST.json').write_text(json.dumps(public,ensure_ascii=False,indent=2),'utf-8')
        print(json.dumps(public,ensure_ascii=False),flush=True)
        if not options.verify:
            while not (owned/'STOP').exists():time.sleep(.2)
    finally:
        runtime.close();network.stop()
        (owned/'CLOSED.json').write_text(json.dumps({'closed':True,'blockedAttempts':blocked,
            'cloudStandinOperations':cloud.calls,'platformStandinOperations':backend.platform_runtime.calls,
            'outboundReceiptStandins':backend.platform_runtime.receipts,'realSend':False},ensure_ascii=False,indent=2),'utf-8')
        if options.verify:
            public.update(status='VERIFIED_CLOSED')
            (owned/'PUBLIC.json').write_text(json.dumps(public,ensure_ascii=False,indent=2),'utf-8')
            (HERE/'LATEST.json').write_text(json.dumps(public,ensure_ascii=False,indent=2),'utf-8')
    return 0


if __name__=='__main__':raise SystemExit(main())

