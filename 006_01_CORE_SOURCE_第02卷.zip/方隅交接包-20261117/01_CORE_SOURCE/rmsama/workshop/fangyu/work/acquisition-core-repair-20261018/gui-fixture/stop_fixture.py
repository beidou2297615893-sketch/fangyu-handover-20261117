"""Stop only the named currently published owned synthetic GUI instance."""
import argparse
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--instance', required=True)
args = parser.parse_args()
latest = HERE / 'LATEST.json'
raw = latest.read_bytes()
public = json.loads(raw)
if public.get('instanceId') != args.instance or public.get('status') != 'READY':
    raise SystemExit('Current READY instance does not match; nothing stopped')
run = Path(public['runDirectory']).resolve(strict=True)
if (run.parent != (HERE / 'runs').resolve() or run.is_symlink()
        or (run / 'PUBLIC.json').read_bytes() != raw):
    raise SystemExit('Owned run/public CAS check failed; nothing stopped')
stop = Path(public['stopFile'])
if stop != run / 'STOP' or stop.exists() or latest.read_bytes() != raw:
    raise SystemExit('Current instance changed/already stopping; nothing stopped')
stop.write_text(json.dumps({'instanceId': args.instance, 'reason': 'root requested QA cleanup'}), 'utf-8')
print(json.dumps({'stop_requested': True, 'instanceId': args.instance,
                  'receipt_to_check': str(run / 'CLOSED.json'),
                  'exit_code_claimed': False}, ensure_ascii=False))
