/* Local, reusable interface icons. No external font or image service. */
function uiIcon(name='arrow'){
 const icons={add:'op-plus',arrow:'op-arrow-right',back:'op-arrow-right',close:'op-logout',search:'nav-search',account:'op-user',link:'op-lock',check:'op-info',refresh:'op-clock',chat:'nav-reply',save:'op-file',edit:'op-edit',filter:'op-filter',clock:'op-clock',folder:'nav-materials',download:'op-download',upload:'op-upload',play:'op-arrow-right',stop:'op-more',help:'op-help',browser:'nav-materials',shield:'op-lock',star:'nav-leads',pin:'op-location',block:'op-delete',settings:'nav-settings'};
 return `<img class="ui-icon reference-icon" src="/assets/approved-${icons[name]||'op-arrow-right'}.png" alt="" aria-hidden="true">`;
}

function platformLogo(platform){return `<img class="platform-logo" src="/assets/platform-${platform==='wechat_channels'?'wechat':['douyin','xiaohongshu','kuaishou','weibo'].includes(platform)?platform:'douyin'}.svg" alt="" aria-hidden="true">`}
function iconForText(text){
 for(const [re,name]of [[/删除/,'block'],[/关闭|取消|退出/,'close'],[/停止|暂停/,'stop'],[/开始|继续/,'play'],[/新增|新建|添加/,'add'],[/保存|备份/,'save'],[/扫码|连接|登录/,'link'],[/窗口|浏览器/,'browser'],[/刷新|重试|重新/,'refresh'],[/排除/,'block'],[/地区|属地/,'pin'],[/时间|日期|每日|今天/,'clock'],[/意向|判断|评分/,'star'],[/筛选|条件/,'filter'],[/账号|客户/,'account'],[/搜索|关键词|查找/,'search'],[/编辑|修改|调整/,'edit'],[/发送|消息|回复|评论/,'chat'],[/导出|下载/,'download'],[/导入|恢复/,'upload'],[/文件夹/,'folder'],[/检查|确认|选用/,'check'],[/帮助|说明/,'help']])if(re.test(text))return name;
 return 'arrow';
}
function decorateInterface(){
 document.querySelectorAll('button,a,summary').forEach(el=>{
  if(el.querySelector('svg,img')||el.classList.contains('icon-skip')||!el.textContent.trim())return;
  el.insertAdjacentHTML('afterbegin',uiIcon(iconForText(el.textContent)));
 });
}
let iconPaintPending=false;
new MutationObserver(()=>{if(iconPaintPending)return;iconPaintPending=true;requestAnimationFrame(()=>{decorateInterface();iconPaintPending=false})}).observe(document.documentElement,{childList:true,subtree:true});

// Keep the visible account list current after the connection panel is closed.
let accountStatusRefreshing=false;
setInterval(async()=>{
 if(accountStatusRefreshing||typeof state==='undefined'||!state.user||state.page!=='accounts'||document.querySelector('#modal')?.open)return;
 accountStatusRefreshing=true;
 try{
  const accounts=rows('accounts').filter(a=>['douyin','kuaishou','wechat_channels'].includes(a.platform));
  if(!accounts.length)return;
  let changed=false;
  for(const a of accounts){
   const r=await api('account_connection_status',{id:a.id});
   const mapped=a.platform==='wechat_channels'?(r.status==='connected_unverified'?'connected_unverified':'unverified'):r.status==='ready'?'ready':r.status==='waiting_login'?'logging_in':'unverified';
   if(mapped!==a.status||r.message!==a.connection_message)changed=true;
  }
  if(changed&&state.page==='accounts'&&!document.querySelector('#modal')?.open)await loadPage();
 }catch(e){/* Explicit actions show errors; a passive refresh must not steal focus. */}
 finally{accountStatusRefreshing=false}
},6000);
