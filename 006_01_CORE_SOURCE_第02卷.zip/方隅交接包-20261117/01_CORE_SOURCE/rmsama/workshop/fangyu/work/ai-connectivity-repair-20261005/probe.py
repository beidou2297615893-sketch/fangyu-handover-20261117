"""One credential-free supplier probe, through the existing admin session."""
from pathlib import Path
import importlib.util,json

here=Path(__file__).resolve().parent
root=here.parents[1]
marker=here/'probe-attempt.json'
if marker.exists():
    print(json.dumps({'stopped':True,'reason':'already_attempted'}));raise SystemExit(1)
spec=importlib.util.spec_from_file_location('owner_connectivity',root/'work/owner-admin-20261004/owner_admin.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
owner=module.Owner();user=owner.user()
with owner.integrations.lock:config=owner.integrations._read(user['tenant_id'])
marker.write_text(json.dumps({'supplier_credentials_sent':False,'model_requested':False,'automatic_replay':False})+'\n','utf-8')
try:
    value=owner.integrations._cloud(config,user,'ai_profile',connectivity_check=True)
    result={'connectivity':value.get('connectivity'),'provider':value.get('config',{}).get('provider'),'model':value.get('config',{}).get('model'),'supplier_credentials_sent':False,'model_requested':False,'automatic_replay':False}
except Exception as error:
    result={'stopped':True,'safe_code':getattr(error,'code','PROBE_UNCONFIRMED'),'error_type':type(error).__name__,'automatic_replay':False}
(here/'probe-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps(result,ensure_ascii=False))
