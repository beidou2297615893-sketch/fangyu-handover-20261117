"""User-requested switch, preserving both provider keys and budget controls."""
from pathlib import Path
import importlib.util,json,uuid
here=Path(__file__).resolve().parent
root=here.parents[1]
spec=importlib.util.spec_from_file_location('owner_switch',root/'work/owner-admin-20261004/owner_admin.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
owner=module.Owner()
prior=owner.call('ai_profile',{})['config']
deepseek=prior.get('providers',{}).get('deepseek',{})
if not deepseek.get('configured'):
    print(json.dumps({'stopped':True,'reason':'deepseek_key_missing'}));raise SystemExit(1)
model=deepseek.get('model')
if model not in ('deepseek-flash','deepseek-v4-pro'):
    print(json.dumps({'stopped':True,'reason':'deepseek_model_invalid'}));raise SystemExit(1)
record=here/'deepseek-switch.json'
if record.exists():
    print(json.dumps({'stopped':True,'reason':'already_attempted'}));raise SystemExit(1)
request_id=str(uuid.uuid4())
record.write_text(json.dumps({'request_id':request_id,'expected_revision':prior['revision'],'prior_provider':prior['provider'],'desired_provider':'deepseek','desired_model':model})+'\n','utf-8')
save_confirmed=False
try:
    owner.call('ai_config_save',{'request_id':request_id,'expected_revision':prior['revision'],'config':{'provider':'deepseek','model':model,'enabled':True}})
    save_confirmed=True
except Exception:
    pass
actual=owner.call('ai_profile',{})['config']
result={'save_response_confirmed':save_confirmed,'readback_confirmed':actual.get('last_save_id')==request_id and actual.get('provider')=='deepseek' and actual.get('model')==model and actual.get('enabled') is True,'provider':actual.get('provider'),'model':actual.get('model'),'configured':actual.get('configured'),'revision':actual.get('revision'),'openai_key_preserved':actual.get('providers',{}).get('openai',{}).get('configured') is True,'paid_ai_requested':False,'no_automatic_replay':True}
(here/'deepseek-switch-result.json').write_text(json.dumps(result,indent=2)+'\n','utf-8')
print(json.dumps(result))
