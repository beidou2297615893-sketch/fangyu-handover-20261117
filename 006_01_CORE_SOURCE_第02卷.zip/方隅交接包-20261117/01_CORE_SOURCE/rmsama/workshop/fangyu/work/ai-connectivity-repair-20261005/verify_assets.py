"""Public asset check, without opening a UI or triggering business requests."""
from pathlib import Path
from urllib.request import urlopen
import json,hashlib
here=Path(__file__).resolve().parent
root=here.parents[1]
runtime=json.loads((root/'work/assistant/qa-cloud-pairing-pc1-20260926/running.json').read_text('utf-8'))
endpoints={'local':runtime['url'],'cloud':'https://fh6-d5ga45c0ddae7008c-1439321968.ap-shanghai.app.tcloudbase.com/fangyu-workspace'}
result=[]
for kind,base in endpoints.items():
    for name in ('app.mjs','enterprise-ui.mjs'):
        try:
            with urlopen(base+'/workspace?asset='+name if kind=='local' else base+'?asset='+name,timeout=12) as response:
                body=response.read(500000)
                expected=(root/'work/app/src/web/workspace'/name).read_bytes()
                result.append({'endpoint':kind,'asset':name,'status':response.status,'matches_source':body==expected,'no_store':'no-store' in response.headers.get('Cache-Control',''),'sha256':hashlib.sha256(body).hexdigest()})
        except Exception as error:
            result.append({'endpoint':kind,'asset':name,'confirmed':False,'error_type':type(error).__name__})
(here/'assets.json').write_text(json.dumps(result,indent=2)+'\n','utf-8')
print(json.dumps(result))
