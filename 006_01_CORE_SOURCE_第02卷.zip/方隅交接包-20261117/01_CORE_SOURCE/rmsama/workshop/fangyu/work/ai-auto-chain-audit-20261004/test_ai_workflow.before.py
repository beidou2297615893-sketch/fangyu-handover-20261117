import sys, tempfile, unittest, threading
from io import BytesIO
from pathlib import Path
from types import SimpleNamespace
from urllib.error import HTTPError
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from core.store import Store
from core.engine import Core
from assistant.ai_workflow import LocalAIWorkflow,effective_intent
from assistant.business import BusinessExecutor
from assistant.lead_groups import group_rows
from assistant.ai_worker import AIWorker,safe_error_code,needs_analysis
from assistant.ai_workflow import AIContextRequired
from integrations import IntegrationError,request_json
from unittest.mock import patch

class AITests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.store=Store(self.tmp.name)
        def task_access(actor, task, tenant):
            if task.get('tenant_id') != tenant or task.get('cloud_owner') != actor.get('username'):
                raise ValueError('task owner mismatch')
        self.core=SimpleNamespace(store=self.store,lock=threading.RLock(),_get=lambda entity,id,tenant:self.store.get(entity,id),_audit=lambda *a:None,_task_access=task_access)
        self.user={'tenant_id':'tenant','id':'u','username':'employee','role':'operator','cloud_bound':True};self.calls=[];self.revision=1
        self.store.put('users',self.user)
        self.store.put('tasks',{'id':'task','tenant_id':'tenant','cloud_owner':'employee','platform':'xiaohongshu','scope':'search','city':'上海','area':'古北','keywords':['公寓']})
        self.workflow=LocalAIWorkflow(self.core,self.cloud)
    def cloud(self,user,action,data):
        self.calls.append(action)
        if action=='ai_profile':return {'config':{'model':'deepseek-flash','rules_version':'1','revision':self.revision,'enabled':True,'configured':True}}
        if action=='keyword_suggest':
            self.last_keyword_payload=data
            return {'keywords':[{'keyword':f'上海古北租房需求{i+1}','group':'地域','recommended':i<10,'reason':'同城'} for i in range(data['count'])],'model':'deepseek-flash','api_key':'[REDACTED:assigned_secret]'}
        return {'results':[{'id':c['id'],'status':'graded','level':'high','reason':'明确需求','evidence':['预算3500'],
                            'region_status':'unknown','content_region':'','key_info':[{'type':'budget','value':'3500','evidence':'预算3500'}]} for c in data['comments']]}
    def lead(self,id='l'):
        value={'id':id,'tenant_id':'tenant','task_id':'task','cloud_owner':'employee','text':'预算3500，周末能看吗？','note_url':'https://www.xiaohongshu.com/explore/abc','content_title':'古北一居室','grade':'C'}
        self.store.put('leads',value);return value
    def test_keyword_reuse_selection_and_revision(self):
        args={'city':'上海','area':'古北','seeds':['古北租房']}
        result=self.workflow.keywords(self.user,args)
        self.assertEqual(self.last_keyword_payload['seeds'],['古北租房'])
        self.assertEqual(len(result['keywords']),50)
        self.assertNotIn('MUST_NOT_PERSIST',str(self.store.list('ai_cache')))
        second=self.workflow.keywords(self.user,args)
        self.assertTrue(second['cache_hit']);self.assertEqual(self.calls.count('keyword_suggest'),1)
        before=len(self.calls)
        self.workflow.library(self.user,{'library_id':result['library_id'],'selected':['上海古北求租','上海长宁一居室']})
        self.assertEqual(len(self.calls),before)
        self.assertEqual(len(self.workflow.library(self.user,{})['items'][0]['selected']),2)
        self.revision=2;self.workflow.keywords(self.user,args)
        self.assertEqual(self.calls.count('keyword_suggest'),2)
    def test_owner_isolation(self):
        result=self.workflow.keywords(self.user,{'city':'上海','seeds':['公寓']})
        other={**self.user,'username':'other','id':'other'}
        self.assertEqual(self.workflow.library(other,{})['items'],[])
        with self.assertRaises(ValueError):self.workflow.library(other,{'library_id':result['library_id'],'selected':['上海']})
    def test_semantic_no_literal_seed_legacy_kept_and_cache(self):
        lead=self.lead();task=self.store.get('tasks','task')
        self.workflow.analyze(self.user,task,[lead]);saved=self.store.get('leads','l')
        self.assertEqual(saved['grade'],'C');self.assertEqual(saved['ai_intent']['level'],'high')
        self.assertEqual(saved['ai_intent']['key_info'],[{'type':'budget','value':'3500','evidence':'预算3500'}])
        self.workflow.analyze(self.user,task,[saved]);self.assertEqual(self.calls.count('intent_analyze'),1)
        self.workflow.correct(self.user,saved,{'level':'low','reason':'员工核实无近期需求'})
        self.workflow.analyze(self.user,task,[self.store.get('leads','l')])
        self.assertEqual(effective_intent(self.store.get('leads','l'))['level'],'low')
    def test_invalid_batch_never_partialgrades(self):
        lead=self.lead()
        original=self.cloud
        self.workflow.cloud=lambda user,action,data: original(user,action,data) if action=='ai_profile' else {'results':[{'id':'wrong','status':'graded','level':'high'}]}
        with self.assertRaises(ValueError):self.workflow.analyze(self.user,self.store.get('tasks','task'),[lead])
        self.assertNotIn('ai_intent',self.store.get('leads','l'))
    def test_legacy_missing_city_does_not_use_ip_post_or_new_task_city(self):
        lead=self.lead()
        task=self.store.get('tasks','task')
        task.update(city=None,region=None,area=None)
        self.store.put('tasks',task)
        lead.update(ip_location='上海',content_title='上海租房')
        self.store.put('leads',lead)
        with self.assertRaises(AIContextRequired) as caught:
            self.workflow.analyze(self.user,task,[lead])
        self.assertEqual(caught.exception.code,'AI_CONTEXT_REQUIRED')
        self.assertEqual(self.calls.count('intent_analyze'),0)
        self.assertNotIn('ai_intent',self.store.get('leads','l'))
    def test_none_optional_comment_context_accepts_title_evidence(self):
        lead=self.lead()
        lead.update(text='周末能看吗？',parent_text=None,published_at=None,
                    ip_location=None,region=None,content_author=None)
        self.store.put('leads',lead)
        original=self.cloud
        def title_evidence(user,action,data):
            if action!='intent_analyze':return original(user,action,data)
            comment=data['comments'][0]
            self.assertEqual((comment['parent_text'],comment['published_at'],comment['ip_location']),('','',''))
            self.assertEqual(data['post']['author'],'')
            return {'results':[{'id':comment['id'],'status':'graded','level':'medium',
                    'reason':'结合帖子核对','evidence':['古北一居室'],
                    'region_status':'unknown','content_region':'','key_info':[]}]}
        self.workflow.cloud=title_evidence
        result=self.workflow.analyze(self.user,self.store.get('tasks','task'),[lead])
        self.assertEqual(result['analyzed'],1)
        self.assertEqual(self.store.get('leads','l')['ai_intent']['level'],'medium')
        bad={**lead,'id':'bad','parent_text':{'unexpected':'object'}}
        self.store.put('leads',bad)
        with self.assertRaises(AIContextRequired):
            self.workflow.analyze(self.user,self.store.get('tasks','task'),[bad])
    def test_empty_legacy_comment_is_marked_and_other_post_comment_analyzed(self):
        self.lead('valid')
        empty=self.lead('empty');empty['text']='';self.store.put('leads',empty)
        executor=SimpleNamespace(core=self.core,tenant='tenant',ai=self.workflow,
                                 _lead_access=lambda user,lead:None)
        result=BusinessExecutor.analyze_pending(executor,self.user,{'task_id':'task'})
        self.assertEqual((result['analyzed'],result['pending'],result['excluded_missing_text']),(1,0,1))
        saved=self.store.get('leads','empty')
        self.assertEqual((saved['analysis_status'],saved['verification_status']),('missing_text','pending'))
        self.assertNotIn('ai_intent',saved)
        self.assertFalse(needs_analysis(saved))
        saved['text']='预算3500，周末能看吗？';self.store.put('leads',saved)
        self.assertTrue(needs_analysis(saved),'verified text can re-enter the queue')
    def test_legacy_context_wait_does_not_block_new_valid_task(self):
        old={'id':'a-old','tenant_id':'tenant','cloud_owner':'employee','city':None,'region':None,'area':None}
        new={'id':'z-new','tenant_id':'tenant','cloud_owner':'employee','city':'上海','area':''}
        self.store.put('tasks',old);self.store.put('tasks',new)
        self.store.put('leads',{**self.lead('old'),'task_id':'a-old'})
        self.store.put('leads',{**self.lead('new'),'task_id':'z-new'})
        executor=SimpleNamespace(core=self.core,tenant='tenant',user_id='u',ai=self.workflow,
                                 _lead_access=lambda user,lead:None)
        executor.analyze_pending=lambda user,data:BusinessExecutor.analyze_pending(executor,user,data)
        worker=AIWorker(executor)
        with patch('assistant.ai_worker.time.time',return_value=2000000000):worker.step()
        self.assertEqual(self.store.get('ai_jobs','a-old')['code'],'AI_CONTEXT_REQUIRED')
        self.assertNotIn('ai_intent',self.store.get('leads','old'))
        self.assertEqual(self.store.get('leads','new')['ai_intent']['level'],'high')
        old['city']='上海';self.store.put('tasks',old)
        with patch('assistant.ai_worker.time.time',return_value=2000000059):worker.step()
        self.assertNotIn('ai_intent',self.store.get('leads','old'))
        with patch('assistant.ai_worker.time.time',return_value=2000000060):worker.step()
        self.assertEqual(self.store.get('leads','old')['ai_intent']['level'],'high')
    def test_old_paused_invalid_input_rechecks_once_then_city_fix_backfills(self):
        lead=self.lead()
        task=self.store.get('tasks','task');task.update(city=None,region=None,area=None)
        self.store.put('tasks',task)
        self.store.put('ai_jobs',{'id':'task','tenant_id':'tenant','task_id':'task',
                                  'profile_revision':1,'status':'paused','code':'AI_INVALID_INPUT'})
        executor=SimpleNamespace(core=self.core,tenant='tenant',user_id='u',ai=self.workflow,
                                 _lead_access=lambda user,lead:None)
        executor.analyze_pending=lambda user,data:BusinessExecutor.analyze_pending(executor,user,data)
        worker=AIWorker(executor)
        with patch('assistant.ai_worker.time.time',return_value=2000000000):worker.step()
        self.assertEqual(self.store.get('ai_jobs','task')['code'],'AI_CONTEXT_REQUIRED')
        self.assertEqual(self.calls.count('intent_analyze'),0)
        task['city']='上海';self.store.put('tasks',task)
        with patch('assistant.ai_worker.time.time',return_value=2000000060):worker.step()
        self.assertEqual(self.store.get('leads','l')['ai_intent']['level'],'high')
    def test_rechecked_invalid_input_does_not_repeat_until_revision_changes(self):
        worker,calls=self.worker('AI_INVALID_INPUT')
        self.store.put('ai_jobs',{'id':'task','tenant_id':'tenant','task_id':'task',
                                  'profile_revision':1,'status':'paused','code':'AI_INVALID_INPUT'})
        with patch('assistant.ai_worker.time.time',return_value=2000000000):worker.step()
        job=self.store.get('ai_jobs','task')
        self.assertEqual((len(calls),job['status'],job['context_preflight_checked']),(1,'paused',True))
        with patch('assistant.ai_worker.time.time',return_value=2000010000):worker.step()
        self.assertEqual(len(calls),1)
    def test_groups_before_paging_signed_url_normalized(self):
        rows=[{**self.lead(str(i)),'note_url':'https://www.xiaohongshu.com/explore/abc?xsec_token='+str(i)} for i in range(32)]
        items,view=group_rows(rows,{'group_by':'note'})
        self.assertEqual(view['groups_total'],1);self.assertEqual(view['groups'][0]['count'],32)
        self.assertNotIn('xsec_token',str(view))
        selected,view=group_rows(rows,{'group_by':'note','group_key':'g_'+'0'*32})
        self.assertEqual(selected,[])
    def test_unknown_fields_and_manual_priority(self):
        rows=[{'id':'a','published_at':'','grade':'A'}, {'id':'b','published_at':'2026-09-29','manual_intent':{'status':'graded','level':'super_high'},'ai_intent':{'status':'graded','level':'low'}}]
        self.assertEqual(group_rows(rows,{'group_by':'date'})[1]['groups_total'],2)
        labels={x['label'] for x in group_rows(rows,{'group_by':'intent'})[1]['groups']}
        self.assertEqual(labels,{'超高意向','旧评分 A · 待分析'})
    def worker(self,error_code='AI_UNAVAILABLE'):
        self.store.put('users',self.user)
        self.store.put('tasks',{'id':'task','tenant_id':'tenant','continuous_enabled':True})
        lead=self.lead();lead['task_id']='task';self.store.put('leads',lead)
        self.core._task_access=lambda *a:None
        calls=[]
        def fail(*args):
            calls.append(1);error=ValueError('fixture failure');error.code=error_code;raise error
        executor=SimpleNamespace(core=self.core,user_id='u',tenant='tenant',analyze_pending=fail,
                                 ai=SimpleNamespace(cloud=lambda user,action,data:self.cloud(user,action,data)))
        return AIWorker(executor),calls
    def test_worker_failure_is_bounded_across_restart(self):
        worker,calls=self.worker()
        for step in range(4):
            with patch('assistant.ai_worker.time.time',return_value=2000000000+step*301):worker.step()
        self.assertEqual(len(calls),3)
        fresh=AIWorker(worker.executor)
        retry_at=self.store.get('ai_jobs','task')['retry_after']
        with patch('assistant.ai_worker.time.time',return_value=retry_at-1):fresh.step()
        self.assertEqual(len(calls),3)
        with patch('assistant.ai_worker.time.time',return_value=retry_at):fresh.step()
        self.assertEqual(len(calls),4,'failure remains retryable after restart and backoff')
        self.assertLessEqual(self.store.get('ai_jobs','task')['retry_after']-retry_at,3600)
        self.assertNotIn('ai_intent',self.store.get('leads','l'))
    def test_worker_recovers_same_revision_and_clears_pending(self):
        worker,calls=self.worker()
        for moment in (2000000000,2000000300,2000000900):
            with patch('assistant.ai_worker.time.time',return_value=moment):worker.step()
        self.assertEqual(len(calls),3)
        def recovered(user,data):
            lead=self.store.get('leads','l')
            lead['ai_intent']={'status':'graded','level':'high'}
            self.store.put('leads',lead)
            return {'analyzed':1,'pending':0}
        worker.executor.analyze_pending=recovered
        retry_at=self.store.get('ai_jobs','task')['retry_after']
        with patch('assistant.ai_worker.time.time',return_value=retry_at):worker.step()
        self.assertEqual(self.store.get('ai_jobs','task')['status'],'ready')
        self.assertEqual(self.store.get('ai_jobs','task')['retry_count'],0)
        self.assertEqual(self.store.get('leads','l')['ai_intent']['level'],'high')
    def test_budget_does_not_turn_pending_comments_into_low_intent(self):
        worker,calls=self.worker('AI_DAILY_BUDGET');worker.step();worker.step()
        self.assertEqual(len(calls),1)
        job=self.store.get('ai_jobs','task')
        self.assertEqual(job['retry_count'],0);self.assertGreater(job['retry_after'],0)
        self.assertEqual(effective_intent(self.store.get('leads','l'))['status'],'pending')
    def test_worker_backfills_old_task_after_configured_revision_and_respects_access(self):
        worker,calls=self.worker();task=self.store.get('tasks','task');task['continuous_enabled']=False;self.store.put('tasks',task)
        foreign={'id':'foreign','tenant_id':'tenant','continuous_enabled':False};self.store.put('tasks',foreign)
        self.store.put('leads',{**self.lead('foreign-lead'),'task_id':'foreign'})
        self.core._task_access=lambda user,task,tenant: (_ for _ in ()).throw(ValueError('other owner')) if task['id']=='foreign' else None
        self.store.put('ai_jobs',{'id':'task','tenant_id':'tenant','task_id':'task','profile_revision':1,'retry_count':3,'retry_after':2000010000})
        with patch('assistant.ai_worker.time.time',return_value=2000000000):worker.step()
        self.assertEqual(calls,[],'same revision keeps the three-failure stop')
        self.revision=2
        with patch('assistant.ai_worker.time.time',return_value=2000000000):worker.step()
        self.assertEqual(len(calls),1,'new configured revision permits bounded backfill')
        self.assertEqual(self.store.get('ai_jobs','task')['profile_revision'],2)
        self.assertIsNone(self.store.get('ai_jobs','foreign'))
    def test_worker_waits_for_config_and_skips_manual_or_completed_results(self):
        worker,calls=self.worker();task=self.store.get('tasks','task');task['continuous_enabled']=False;self.store.put('tasks',task)
        worker.executor.ai.cloud=lambda *_:{'config':{'enabled':False,'configured':False,'revision':1}}
        worker.step();self.assertEqual(calls,[])
        job=self.store.get('ai_jobs','task')
        self.assertEqual((job['status'],job['code'],job['pending']),('pending','AI_DISABLED',1))
        worker.executor.ai.cloud=lambda *_:{'config':{'enabled':True,'configured':True,'revision':2}}
        lead=self.store.get('leads','l');lead['manual_intent']={'status':'graded','level':'high'};self.store.put('leads',lead)
        worker.step();self.assertEqual(calls,[])
        lead.pop('manual_intent');lead['ai_intent']={'status':'graded','level':'high'};self.store.put('leads',lead)
        worker.step();self.assertEqual(calls,[])
    def test_invalid_output_pauses_paid_retry_until_explicit_retry_or_new_revision(self):
        worker,calls=self.worker('AI_INVALID_OUTPUT')
        with patch('assistant.ai_worker.time.time',return_value=2000000000):worker.step()
        job=self.store.get('ai_jobs','task')
        self.assertEqual((job['status'],job['code']),('paused','AI_INVALID_OUTPUT'))
        with patch('assistant.ai_worker.time.time',return_value=2000010000):worker.step()
        self.assertEqual(len(calls),1)
        self.revision=2
        with patch('assistant.ai_worker.time.time',return_value=2000010000):worker.step()
        self.assertEqual(len(calls),2)
    def test_unknown_provider_billing_never_auto_retries_same_revision(self):
        worker,calls=self.worker('AI_PROVIDER_TIMEOUT')
        with patch('assistant.ai_worker.time.time',return_value=2000000000):worker.step()
        with patch('assistant.ai_worker.time.time',return_value=2000010000):worker.step()
        self.assertEqual(len(calls),1)
        self.assertEqual(self.store.get('ai_jobs','task')['status'],'paused')
        self.assertEqual(effective_intent(self.store.get('leads','l'))['status'],'pending')
    def test_paused_provider_balance_recounts_new_comments_without_paid_retry(self):
        worker,calls=self.worker('AI_PROVIDER_BALANCE')
        with patch('assistant.ai_worker.time.time',return_value=2000000000):worker.step()
        original=self.store.get('ai_jobs','task')
        self.lead('new')
        missing=self.lead('empty')
        missing.update(text='',analysis_status='missing_text',verification_status='pending')
        self.store.put('leads',missing)
        with patch('assistant.ai_worker.time.time',return_value=2000000015):worker.step()
        updated=self.store.get('ai_jobs','task')
        self.assertEqual(len(calls),1,'paused balance must not make another paid request')
        self.assertEqual((updated['pending'],updated['excluded_missing_text']),(2,1))
        self.assertEqual(updated,{**original,'pending':2,'excluded_missing_text':1})
        self.assertEqual(effective_intent(self.store.get('leads','new'))['status'],'pending')
        self.assertEqual(self.store.get('leads','empty')['analysis_status'],'missing_text')
    def test_paused_final_manual_correction_recounts_without_cloud_profile(self):
        worker,calls=self.worker('AI_BILLING_UNKNOWN')
        with patch('assistant.ai_worker.time.time',return_value=2000000000):worker.step()
        original=self.store.get('ai_jobs','task')
        missing=self.lead('empty')
        missing.update(text='',analysis_status='missing_text',verification_status='pending')
        self.store.put('leads',missing)
        lead=self.store.get('leads','l')
        lead['manual_intent']={'status':'graded','level':'medium'}
        self.store.put('leads',lead)
        profile_calls=self.calls.count('ai_profile')
        worker.retry_after=2000000100
        with patch('assistant.ai_worker.time.time',return_value=2000000015):worker.step()
        updated=self.store.get('ai_jobs','task')
        self.assertEqual(updated,{**original,'pending':0,'excluded_missing_text':1})
        self.assertEqual(self.calls.count('ai_profile'),profile_calls)
        self.assertEqual(len(calls),1,'recount must not submit another AI request')
    def test_paused_unknown_billing_recounts_and_does_not_block_other_task(self):
        worker,calls=self.worker('AI_BILLING_UNKNOWN')
        with patch('assistant.ai_worker.time.time',return_value=2000000000):worker.step()
        original=self.store.get('ai_jobs','task')
        self.lead('new')
        self.store.put('tasks',{'id':'task-2','tenant_id':'tenant','cloud_owner':'employee'})
        lead=self.lead('second');lead['task_id']='task-2';self.store.put('leads',lead)
        self.store.put('ai_jobs',{'id':'task-2','tenant_id':'tenant','task_id':'task-2',
                                  'profile_revision':1,'updated_at':'9999-01-01'})
        second_calls=[]
        def analyze(_user,data):
            second_calls.append(data['task_id'])
            current=self.store.get('leads','second')
            current['ai_intent']={'status':'graded','level':'high'}
            self.store.put('leads',current)
            return {'analyzed':1,'pending':0}
        worker.executor.analyze_pending=analyze
        with patch('assistant.ai_worker.time.time',return_value=2000000015):worker.step()
        updated=self.store.get('ai_jobs','task')
        self.assertEqual(len(calls),1,'unknown billing must stay paused')
        self.assertEqual((updated['pending'],updated['excluded_missing_text']),(2,0))
        self.assertEqual(updated,{**original,'pending':2,'excluded_missing_text':0})
        self.assertEqual(second_calls,['task-2'])
        self.assertEqual(self.store.get('ai_jobs','task-2')['status'],'ready')
    def test_profile_auth_failure_preserves_paused_unknown_billing(self):
        worker,calls=self.worker('AI_BILLING_UNKNOWN')
        with patch('assistant.ai_worker.time.time',return_value=2000000000):worker.step()
        paused=self.store.get('ai_jobs','task')
        self.lead('new')
        self.store.put('tasks',{'id':'task-2','tenant_id':'tenant','cloud_owner':'employee'})
        second=self.lead('second');second['task_id']='task-2';self.store.put('leads',second)
        available=[False]
        def profile(user,action,data):
            if not available[0]:
                error=IntegrationError('expired');error.http_status=401;raise error
            return self.cloud(user,action,data)
        worker.executor.ai.cloud=profile
        with patch('assistant.ai_worker.time.time',return_value=2000000015):worker.step()
        self.assertEqual(self.store.get('ai_jobs','task'),{**paused,'pending':2,'excluded_missing_text':0})
        auth_job=self.store.get('ai_jobs','task-2')
        self.assertEqual((auth_job['status'],auth_job['code']),('pending','AI_AUTH_REQUIRED'))
        self.assertEqual(len(calls),1)
        available[0]=True
        paid=[]
        def analyze(_user,data):
            paid.append(data['task_id'])
            lead=self.store.get('leads','second')
            lead['ai_intent']={'status':'graded','level':'high'}
            self.store.put('leads',lead)
            return {'analyzed':1,'pending':0}
        worker.executor.analyze_pending=analyze
        with patch('assistant.ai_worker.time.time',return_value=2000000075):worker.step()
        self.assertEqual(paid,['task-2'])
        self.assertEqual(self.store.get('ai_jobs','task')['code'],'AI_BILLING_UNKNOWN')
        self.assertEqual(self.store.get('ai_jobs','task')['status'],'paused')
    def test_provider_balance_and_key_failures_pause_with_actionable_messages(self):
        for code, expected in (('AI_PROVIDER_BALANCE','企业 DeepSeek API 余额不足，充值后点继续分析'),
                               ('AI_PROVIDER_AUTH','企业 DeepSeek API 密钥无效，请管理员检查后点继续分析')):
            with self.subTest(code=code):
                self.store.delete('ai_jobs','task') if self.store.get('ai_jobs','task') else None
                worker,calls=self.worker(code)
                with patch('assistant.ai_worker.time.time',return_value=2000000000):worker.step()
                job=self.store.get('ai_jobs','task')
                self.assertEqual((job['status'],job['code'],job['message']),('paused',code,expected))
                with patch('assistant.ai_worker.time.time',return_value=2000010000):worker.step()
                self.assertEqual(len(calls),1)
                self.assertEqual(effective_intent(self.store.get('leads','l'))['status'],'pending')
                if code=='AI_PROVIDER_BALANCE':
                    explicit=object.__new__(BusinessExecutor)
                    explicit.core=self.core;explicit.tenant='tenant'
                    explicit.server=SimpleNamespace(assistant_service=SimpleNamespace(ai_worker=worker))
                    explicit._guard_platform_qa_command=lambda *_:None
                    explicit.principal=lambda *_:self.user
                    explicit._xiaohongshu_held=lambda:False
                    def failed_analysis(*_):
                        error=IntegrationError('余额仍不足');error.code=code;raise error
                    explicit.ai=SimpleNamespace(analyze=failed_analysis)
                    with self.assertRaises(IntegrationError):
                        explicit({'action':'intent_analyze_pending','data':{'task_id':'task'}})
                    retained=self.store.get('ai_jobs','task')
                    self.assertEqual((retained['status'],retained['code']),('paused',code))
                    def recovered_analysis(_user,_task,_batch):
                        lead=self.store.get('leads','l')
                        lead['ai_intent']={'status':'graded','level':'high'}
                        self.store.put('leads',lead)
                        return {'analyzed':1}
                    explicit.ai=SimpleNamespace(analyze=recovered_analysis)
                    result=explicit({'action':'intent_analyze_pending','data':{'task_id':'task'}})
                    self.assertEqual(result['analyzed'],1)
                    completed=self.store.get('ai_jobs','task')
                    self.assertEqual((completed['status'],completed['last_analyzed'],completed['pending'],completed['excluded_missing_text']),('ready',1,0,0))
                    self.assertNotIn('code',completed)
                    self.assertEqual(completed['retry_count'],0)
                    self.assertEqual(completed['retry_after'],0)
                    missing=self.lead('missing')
                    missing.update(task_id='task',text='',analysis_status='missing_text',verification_status='pending')
                    self.store.put('leads',missing)
                    manual=self.lead('manual')
                    manual.update(task_id='task',manual_intent={'status':'graded','level':'medium'})
                    self.store.put('leads',manual)
                    empty=explicit({'action':'intent_analyze_pending','data':{'task_id':'task'}})
                    self.assertEqual(empty,{'analyzed':0,'pending':0,'excluded_missing_text':1})
                    followup=self.store.get('ai_jobs','task')
                    self.assertEqual((followup['status'],followup['last_analyzed'],followup['excluded_missing_text']),('pending',0,1))
                    self.assertNotIn('code',followup)
                    self.assertEqual(self.store.get('leads','missing')['analysis_status'],'missing_text')
                    self.assertEqual(self.store.get('leads','manual')['manual_intent']['level'],'medium')
    def test_provider_codes_survive_integration_without_cloud_login_conflation(self):
        for code,expected in (('AI_PROVIDER_BALANCE','充值'),('AI_PROVIDER_AUTH','DeepSeek API 密钥')):
            with self.subTest(code=code):
                error=HTTPError('https://example.invalid',502,'ai failed',{},BytesIO(
                    ('{"code":"'+code+'","error":"provider raw secret"}').encode()))
                opener=SimpleNamespace(open=lambda *_args,**_kwargs: (_ for _ in ()).throw(error))
                with patch('integrations.build_opener',return_value=opener):
                    with self.assertRaises(IntegrationError) as caught:
                        request_json('https://example.invalid',{'operation':'intent_analyze'})
                self.assertEqual(safe_error_code(caught.exception),code)
                self.assertIn(expected,str(caught.exception))
                self.assertNotIn('provider raw secret',str(caught.exception))
                self.assertNotEqual(getattr(caught.exception,'http_status',None),401)
    def test_auth_expiry_recovers_same_revision_without_manual_analysis(self):
        worker,calls=self.worker('AI_AUTH_REQUIRED')
        with patch('assistant.ai_worker.time.time',return_value=2000000000):worker.step()
        job=self.store.get('ai_jobs','task')
        self.assertEqual((job['status'],job['code']),('pending','AI_AUTH_REQUIRED'))
        self.assertEqual(len(calls),1)
        def recovered(user,data):
            lead=self.store.get('leads','l')
            lead['ai_intent']={'status':'graded','level':'high'}
            self.store.put('leads',lead)
            return {'analyzed':1,'pending':0}
        worker.executor.analyze_pending=recovered
        with patch('assistant.ai_worker.time.time',return_value=2000000059):worker.step()
        self.assertNotIn('ai_intent',self.store.get('leads','l'))
        with patch('assistant.ai_worker.time.time',return_value=2000000060):worker.step()
        self.assertEqual(self.store.get('ai_jobs','task')['status'],'ready')
        self.assertEqual(self.store.get('leads','l')['ai_intent']['level'],'high')
    def test_profile_auth_expiry_records_pending_then_backfills_after_restore(self):
        worker,calls=self.worker()
        available=[False]
        def profile(user,action,data):
            if not available[0]:
                error=IntegrationError('expired');error.http_status=401;raise error
            return self.cloud(user,action,data)
        worker.executor.ai.cloud=profile
        with patch('assistant.ai_worker.time.time',return_value=2000000000):worker.step()
        self.assertEqual(self.store.get('ai_jobs','task')['code'],'AI_AUTH_REQUIRED')
        self.assertEqual(calls,[])
        available[0]=True
        worker.executor.analyze_pending=lambda *_:{'analyzed':1,'pending':0}
        with patch('assistant.ai_worker.time.time',return_value=2000000059):worker.step()
        self.assertEqual(self.store.get('ai_jobs','task')['status'],'pending')
        with patch('assistant.ai_worker.time.time',return_value=2000000060):worker.step()
        self.assertEqual(self.store.get('ai_jobs','task')['status'],'ready')
    def test_real_cloud_http_error_code_survives_business_ai_path(self):
        def remote_error(body):
            return HTTPError('https://example.invalid',401,'expired',{},BytesIO(body))
        for body,attribute in ((b'{"code":"AI_AUTH_REQUIRED"}','code'),(b'{"error":"expired"}','http_status')):
            opener=SimpleNamespace(open=lambda *_args,**_kwargs: (_ for _ in ()).throw(remote_error(body)))
            with patch('integrations.build_opener',return_value=opener):
                with self.assertRaises(IntegrationError) as caught:
                    request_json('https://example.invalid',{'operation':'intent_analyze'})
            self.assertEqual(getattr(caught.exception,attribute),
                             'AI_AUTH_REQUIRED' if attribute=='code' else 401)
            integrations=SimpleNamespace(lock=threading.RLock(),_read=lambda *_:{},
                                         _cloud=lambda *_args,**_kwargs: (_ for _ in ()).throw(caught.exception))
            executor=SimpleNamespace(server=SimpleNamespace(integrations=integrations))
            with self.assertRaises(IntegrationError) as forwarded:
                BusinessExecutor._ai_cloud(executor,self.user,'intent_analyze',{})
            self.assertEqual(safe_error_code(forwarded.exception),'AI_AUTH_REQUIRED')
    def test_invented_structured_fact_rejects_entire_analysis(self):
        lead=self.lead()
        original=self.cloud
        def invalid(user,action,data):
            value=original(user,action,data)
            if action=='intent_analyze':value['results'][0]['key_info'][0]['evidence']='并不存在的预算'
            return value
        self.workflow.cloud=invalid
        with self.assertRaises(ValueError):self.workflow.analyze(self.user,self.store.get('tasks','task'),[lead])
        self.assertNotIn('ai_intent',self.store.get('leads','l'))
    def test_real_task_save_changes_city_during_provider_and_blocks_old_context(self):
        with tempfile.TemporaryDirectory() as directory:
            core=Core(directory)
            user={'id':'u','tenant_id':'tenant','username':'employee','role':'operator','cloud_bound':True}
            core.store.put('tenants',{'id':'tenant','tenant_id':'tenant','name':'Fixture','business_rules':{},'industry':'apartment'})
            core.store.put('users',user)
            core.store.put('accounts',{'id':'account','tenant_id':'tenant','platform':'xiaohongshu',
                'cloud_owner':'employee','name':'fixture','status':'ready'})
            task={'id':'task','tenant_id':'tenant','cloud_owner':'employee','account_id':'account',
                'platform':'xiaohongshu','scope':'search','city':'Shanghai','region':'Shanghai',
                'area':'Gubei','keywords':['apartment'],'status':'ready'}
            core.store.put('tasks',task)
            lead={**self.lead(),'task_id':'task','cloud_owner':'employee'}
            core.store.put('leads',lead)
            def provider(actor,action,data):
                if action=='intent_analyze':
                    core.handle('save',{'entity':'tasks','record':{'id':'task','city':'Beijing',
                        'region':'Beijing','area':'Chaoyang'}},actor)
                return self.cloud(actor,action,data)
            result=LocalAIWorkflow(core,provider).analyze(user,task,[lead])
            self.assertEqual(core.store.get('tasks','task')['city'],'Beijing')
            self.assertEqual(result['analyzed'],0)
            self.assertNotIn('ai_intent',core.store.get('leads','l'))
            self.assertEqual(len(core.store.list('ai_cache')),1)
            self.assertEqual(self.calls.count('intent_analyze'),1)

    def test_permission_revoked_during_provider_keeps_comment_pending(self):
        with tempfile.TemporaryDirectory() as directory:
            core=Core(directory)
            user={'id':'u','tenant_id':'tenant','username':'employee','role':'operator','cloud_bound':True}
            core.store.put('users',user)
            task={'id':'task','tenant_id':'tenant','cloud_owner':'employee','platform':'xiaohongshu',
                  'scope':'search','city':'Shanghai','area':'Gubei'}
            core.store.put('tasks',task)
            lead={**self.lead(),'task_id':'task','cloud_owner':'employee'}
            core.store.put('leads',lead)
            def provider(actor,action,data):
                if action=='intent_analyze':core.store.put('users',{**user,'disabled':True})
                return self.cloud(actor,action,data)
            result=LocalAIWorkflow(core,provider).analyze(user,task,[lead])
            self.assertEqual(result['analyzed'],0)
            self.assertNotIn('ai_intent',core.store.get('leads','l'))
            self.assertEqual(len(core.store.list('ai_cache')),1)
            self.assertEqual(self.calls.count('intent_analyze'),1)

    def test_pending_recounts_current_manual_review_and_reuses_paid_cache(self):
        with tempfile.TemporaryDirectory() as directory:
            core=Core(directory)
            user={'id':'u','tenant_id':'tenant','username':'employee','role':'operator','cloud_bound':True}
            core.store.put('users',user)
            core.store.put('tasks',{'id':'task','tenant_id':'tenant','cloud_owner':'employee',
                'platform':'xiaohongshu','scope':'search','city':'Shanghai','area':'Gubei'})
            core.store.put('leads',{**self.lead(),'task_id':'task','cloud_owner':'employee'})
            def provider(actor,action,data):
                if action=='intent_analyze':
                    current=core.store.get('leads','l')
                    current['manual_intent']={'status':'graded','level':'low'}
                    core.store.put('leads',current)
                return self.cloud(actor,action,data)
            executor=SimpleNamespace(core=core,tenant='tenant',ai=LocalAIWorkflow(core,provider))
            executor._lead_access=lambda actor,lead:BusinessExecutor._lead_access(executor,actor,lead)
            first=BusinessExecutor.analyze_pending(executor,user,{'task_id':'task'})
            self.assertEqual(first['analyzed'],0)
            self.assertEqual(first['pending'],0)
            current=core.store.get('leads','l');current.pop('manual_intent');core.store.put('leads',current)
            second=BusinessExecutor.analyze_pending(executor,user,{'task_id':'task'})
            self.assertEqual(second['analyzed'],1)
            self.assertEqual(second['pending'],0)
            self.assertEqual(second['cache_hits'],1)
            self.assertEqual(self.calls.count('intent_analyze'),1)


    def test_missing_identity_or_task_never_calls_paid_provider(self):
        lead=self.lead()
        with self.assertRaises(ValueError):
            self.workflow.analyze(self.user,{'city':'上海'},[lead])
        self.store.delete('users','u')
        with self.assertRaises(ValueError):
            self.workflow.analyze(self.user,self.store.get('tasks','task'),[lead])
        self.assertEqual(self.calls.count('intent_analyze'),0)

    def test_deleted_user_during_provider_keeps_comment_pending(self):
        lead=self.lead();task=self.store.get('tasks','task');original=self.cloud
        def delete_during_call(user,action,data):
            if action=='intent_analyze':self.store.delete('users','u')
            return original(user,action,data)
        self.workflow.cloud=delete_during_call
        result=self.workflow.analyze(self.user,task,[lead])
        self.assertEqual(result['analyzed'],0)
        self.assertNotIn('ai_intent',self.store.get('leads','l'))
        self.assertEqual(len(self.store.list('ai_cache')),1)

    def test_lead_moved_to_other_task_during_provider_does_not_write_old_result(self):
        lead=self.lead();task=self.store.get('tasks','task');original=self.cloud
        def move_during_call(user,action,data):
            if action=='intent_analyze':
                current=self.store.get('leads','l');current['task_id']='other';self.store.put('leads',current)
            return original(user,action,data)
        self.workflow.cloud=move_during_call
        result=self.workflow.analyze(self.user,task,[lead])
        self.assertEqual(result['analyzed'],0)
        self.assertNotIn('ai_intent',self.store.get('leads','l'))

    def test_manual_review_during_provider_call_keeps_manual_result_first(self):
        lead=self.lead();original=self.cloud
        def reviewed_during_call(user,action,data):
            if action=='intent_analyze':
                current=self.store.get('leads','l');current['manual_intent']={'status':'graded','level':'low'};self.store.put('leads',current)
            return original(user,action,data)
        self.workflow.cloud=reviewed_during_call
        result=self.workflow.analyze(self.user,self.store.get('tasks','task'),[lead])
        saved=self.store.get('leads','l')
        self.assertEqual(result['analyzed'],0)
        self.assertEqual(effective_intent(saved)['level'],'low')
        self.assertNotIn('ai_intent',saved)

if __name__=='__main__':unittest.main()
