# Enterprise AI auto-analysis chain audit (read-only customer state)

- Scope: source inspection and local read-only SQLite aggregate query. No provider/platform/cloud request, no customer database write.
- Source flow: Core import stores leads; AIWorker scans accessible tasks every 15 seconds; it counts leads without manual/AI intent and batches one post at a time through BusinessExecutor.analyze_pending.
- Observed local QA database: 65 leads, 0 AI intents, 0 AI cache rows; one AI_PROVIDER_BALANCE paused job with 48 valid pending; three AI_CONTEXT_REQUIRED pending jobs totaling 16 valid pending and one missing text.
- Same-revision AI_PROVIDER_BALANCE is intentionally paused to avoid repeated provider calls. Existing UI retry command intent_analyze_pending calls BusinessExecutor.analyze_pending; only on success does it clear code, retry_after and paused status. A failed retry leaves the pause intact. If more comments remain, worker continues on later ticks.
- Defect reproduced: a temporarily disabled/unconfigured read-only profile replaced an existing paid pause with AI_DISABLED/AI_NOT_CONFIGURED pending. Restoring same revision would then permit an unattended paid retry. Fixed worker to preserve paused record and all ledger fields; its local counts still refresh.
- Targeted red-green test: test_disabled_profile_does_not_erase_paid_pause_or_trigger_retry_on_restore failed before fix, passed after fix. Full AI workflow test file: 37 passed.
- Not verified: actual DeepSeek recovery after recharge, current cloud command execution, customer UI live state. These require the root's authorized live check.
