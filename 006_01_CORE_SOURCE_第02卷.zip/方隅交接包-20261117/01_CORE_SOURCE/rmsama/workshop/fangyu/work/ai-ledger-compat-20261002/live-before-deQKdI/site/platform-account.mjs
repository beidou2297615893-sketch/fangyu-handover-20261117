const ACTIONS = new Set(['assistant_status','assistant_workspace_state','assistant_account_safety',
  'assistant_account_signal','assistant_account_login','assistant_new_account_login','assistant_job_status']);
const QR_JOB = /^[a-f0-9]{24}$/;

export async function localAssistantCall(action,data={},fetcher=fetch){
  if(!ACTIONS.has(action)||!data||typeof data!=='object'||Array.isArray(data))throw Error('账号请求无效');
  const response=await fetcher('/api',{method:'POST',credentials:'same-origin',redirect:'error',cache:'no-store',
    headers:{'Content-Type':'application/json','X-Local-App':'1'},body:JSON.stringify({action,data})});
  let value;
  try{value=await response.json();}catch{throw Error('本机助手响应无法读取，请核对状态');}
  if(!response.ok)throw Error(value?.error||'本机助手暂时无法连接');
  return value;
}

export function safeXhsImageUrl(value){
  if(typeof value!=='string'||value.length>2048)return '';
  try{
    const url=new URL(value);
    const host=url.hostname.toLowerCase();
    if(url.protocol!=='https:'||url.username||url.password||!url.pathname||
      !(host==='xhscdn.com'||host.endsWith('.xhscdn.com')||host==='xiaohongshu.com'||host.endsWith('.xiaohongshu.com')))return '';
    return value;
  }catch{return '';}
}

export function reviewSignal(accountId,safety){
  if(typeof accountId!=='string'||!accountId||safety?.state!=='review_required'||
    !Number.isSafeInteger(safety.activity_revision_bytes)||safety.activity_revision_bytes<0)throw Error('请先刷新账号复核记录');
  return {account_id:accountId,kind:'review_completed',revision:safety.activity_revision_bytes};
}

export async function recoverConnection(accountId,safety,record,check){
  if(typeof record!=='function'||typeof check!=='function')throw Error('连接检查暂不可用');
  const data=reviewSignal(accountId,safety);
  await record(data);
  return check(accountId);
}

const make=(tag,text,className)=>{const element=document.createElement(tag);if(text!==undefined)element.textContent=String(text);if(className)element.className=className;return element;};
const reasonText=reason=>({verification_required:'平台要求验证，请先在手机完成验证并核对上次操作结果。',
  ip_blocked:'平台访问受限，请先人工核实账号。',not_authenticated:'登录状态失效，请先核对手机与账号。',
  manual_signal:'此前有人记录了安全提醒，请核对账号与上次操作。',other_risk:'账号出现异常，请先人工核实。',
  unknown:'操作结果或记录尚不确定，请核对后再决定。'})[reason]||'请核对账号状态与上次操作结果。';
export function accountRecovery(account){
  const blocked=account?.requires_review===true;
  const verification=blocked&&account.review_reason==='verification_required';
  const reauth=blocked&&account.review_reason==='not_authenticated'&&account.status==='login_required';
  return {blocked,verification,reauth,canLogin:!blocked&&account?.status!=='logging_in',label:reauth?'电脑登录已失效':verification?'等待手机验证确认':blocked?'等待账号确认':'',
    message:reauth?'手机可以正常使用，但这台电脑的登录已失效。请在此扫码更新登录。':verification?'登录已保存在本机。请先完成手机小红书的验证，再回来确认账号状态。':blocked?'请先核实账号和上次操作结果，再确认复核。':'',
    reviewLabel:reauth?'手机正常，重新扫码登录':verification?'手机已恢复，检查连接':'账号已核实，检查连接'};
}
const statusText=account=>account.requires_review?accountRecovery(account).label:({ready:'已保存登录',logging_in:'登录中',
  login_required:'待登录',identity_mismatch:'扫码身份不一致',identity_unverified:'账号身份待核实',
  duplicate_identity:'账号记录重复',duplicate_identity_remote:'企业身份登记冲突',
  identity_cloud_unavailable:'企业身份校验不可用'})[account.status]||'状态待核对';
const accountName=account=>String(account.platform_nickname||account.name||'小红书账号');

export function createPlatformAccount({root,onAccountsChanged=()=>{},checkAccount,fetcher=fetch,confirmReview=message=>window.confirm(message)}){
  if(!root)throw Error('缺少小红书账号页面');
  const legacy=root.querySelector('.account-layout');
  if(legacy)legacy.hidden=true;
  const shell=make('section',undefined,'platform-account-shell');
  shell.innerHTML='<div class="platform-account-head"><strong>已保存账号</strong><div class="platform-account-head-actions"><button type="button" class="secondary platform-account-refresh">刷新状态</button><button type="button" class="platform-account-new">登录新账号</button></div></div><p class="platform-account-alert" role="status" aria-live="polite"></p><div class="platform-account-list"></div><div class="platform-account-detail" hidden></div><div class="platform-account-qr" hidden><div class="platform-account-qr-head"><strong>扫码登录</strong><button type="button" class="text-button platform-account-qr-close">关闭</button></div><p class="platform-account-qr-message" role="status"></p><img class="platform-account-qr-image" alt="小红书登录二维码" hidden></div>';
  root.prepend(shell);
  const alert=shell.querySelector('.platform-account-alert'),list=shell.querySelector('.platform-account-list'),
    detail=shell.querySelector('.platform-account-detail'),qr=shell.querySelector('.platform-account-qr'),
    qrImage=shell.querySelector('.platform-account-qr-image'),qrMessage=shell.querySelector('.platform-account-qr-message');
  let accounts=[],status=null,selectedId='',safety=null,safetyId='',revision=0,loginJob='',pollTimer=0,refreshSerial=0,busy=false;
  const call=(action,data)=>localAssistantCall(action,data,fetcher);
  let messageKind='';
  const message=(text,error=false,kind='action')=>{messageKind=kind;alert.textContent=text||'';alert.classList.toggle('is-error',error);};
  const loginAllowed=()=>status?.state==='online'&&status?.safety_hold!==true&&status?.account_safety_available===true;
  const reviewAllowed=()=>['online','held'].includes(status?.state)&&status?.account_safety_available===true;
  function stopPolling(){clearTimeout(pollTimer);pollTimer=0;}
  function reset(){refreshSerial++;revision++;stopPolling();loginJob='';accounts=[];status=null;selectedId='';safety=null;safetyId='';busy=false;list.replaceChildren();detail.replaceChildren();detail.hidden=true;qr.hidden=true;qrImage.hidden=true;qrImage.removeAttribute('src');message('');}
  function renderAccounts(){
    shell.setAttribute('aria-busy',String(busy));list.replaceChildren();
    const newButton=shell.querySelector('.platform-account-new');newButton.disabled=!loginAllowed()||busy;
    newButton.title=loginAllowed()?'':'当前企业或本机平台登录尚未开放';
    if(!accounts.length){const empty=make('div',undefined,'platform-account-empty');empty.append(make('strong','还没有小红书账号'),make('p','登录开放后，可用小红书 App 扫码。'));list.append(empty);}
    for(const account of accounts){
      const row=make('article',undefined,'platform-account-row');row.classList.toggle('is-selected',account.id===selectedId);
      const avatar=make('img',undefined,'platform-account-avatar');avatar.alt='';avatar.referrerPolicy='no-referrer';avatar.loading='lazy';avatar.onerror=()=>{avatar.onerror=null;avatar.src='?asset=fy-icon-16-user.png';};avatar.src=safeXhsImageUrl(account.platform_avatar_url)||'?asset=fy-icon-16-user.png';
      const info=make('div',undefined,'platform-account-identity');info.append(make('strong',accountName(account)),make('span',statusText(account),'platform-account-state'));
      if(account.platform_nickname&&account.name&&account.platform_nickname!==account.name)info.append(make('small',account.name));
      const action=make('button',account.requires_review?'查看复核':'查看账号','secondary');action.type='button';
      action.addEventListener('click',()=>void selectAccount(account.id));row.append(avatar,info,action);list.append(row);
    }
    if(status?.safety_hold||status?.state==='held')message('当前平台操作尚未开放；已保存的账号与安全记录仍可查看。',false,'state');
    else if(!status?.account_safety_available)message('正在连接工作台，请稍候…',false,'state');
    else if(messageKind==='state')message('');
  }
  function renderDetail(){
    detail.replaceChildren();const account=accounts.find(item=>item.id===selectedId);
    detail.hidden=!account;if(!account)return;
    const heading=make('div',undefined,'platform-account-detail-head');heading.append(make('h3',accountName(account)),make('span',statusText(account),'platform-account-state'));detail.append(heading);
    const recovery=accountRecovery(account);
    const summary=make('p',recovery.blocked?recovery.message:account.requires_review?reasonText(account.review_reason):account.status==='ready'?'登录信息已保存在本机。':'需要登录或核对身份。','platform-account-detail-copy');detail.append(summary);
    const actions=make('div',undefined,'platform-account-detail-actions');
    if(loginAllowed()&&recovery.canLogin){
      const check=make('button','检查连接','secondary');check.type='button';check.disabled=busy;check.addEventListener('click',()=>void checkConnection(account.id));actions.append(check);
    }
    if(loginAllowed()&&recovery.canLogin&&account.status!=='ready'){
      const login=make('button',account.status==='ready'?'重新扫码登录':'扫码登录此账号','secondary');login.type='button';login.disabled=busy;
      login.addEventListener('click',()=>void beginLogin(account.id));actions.append(login);
    }
    const reload=make('button','刷新状态','secondary');reload.type='button';reload.disabled=busy;
    reload.addEventListener('click',()=>void loadSafety(account.id));actions.append(reload);detail.append(actions);
    const safetyBox=make('div',undefined,'platform-account-safety');
    if(safetyId===account.id&&safety){
      if(safety.state==='review_required'){
        const review=make('button',recovery.reviewLabel);review.type='button';review.disabled=!reviewAllowed()||busy;
        review.addEventListener('click',()=>void completeReview(account.id));safetyBox.append(review);
        if(!reviewAllowed())safetyBox.append(make('small','工作台连上企业服务后可以检查连接。'));
      }
      const history=make('details',undefined,'platform-account-record');history.append(make('summary','查看记录'));
      history.append(make('p',safety.message||'账号记录已读取。'));
      history.append(make('small',`近 30 天：${Number(safety.requests)||0} 次平台请求，${Number(safety.risk_signals)||0} 次提醒，${Number(safety.process_anomalies)||0} 次进程异常。`));
      safetyBox.append(history);
    }else safetyBox.append(make('p','正在读取账号安全记录…'));
    detail.append(safetyBox);
    const signal=make('details',undefined,'platform-account-signals');signal.append(make('summary','遇到手机验证或账号意外退出？'));
    const signalCopy=make('p','只有实际遇到这些情况时才记录。记录后该账号的相关平台操作会暂停，等待人工核实。');signal.append(signalCopy);
    for(const [kind,label] of [['phone_verification','遇到手机验证'],['unexpected_logout','账号意外退出']]){
      const button=make('button',label,'secondary');button.type='button';button.disabled=busy;
      button.addEventListener('click',()=>void reportSignal(account.id,kind,label));signal.append(button);
    }
    detail.append(signal);
  }
  async function refresh(){
    const current=++refreshSerial;try{
      const nextStatus=await call('assistant_status');
      const snapshot=await call('assistant_workspace_state');
      if(current!==refreshSerial)return;
      status=nextStatus;accounts=(Array.isArray(snapshot.accounts)?snapshot.accounts:[]).filter(item=>item?.platform==='xiaohongshu'&&typeof item.id==='string');
      if(!accounts.some(item=>item.id===selectedId)){selectedId=accounts.find(item=>item.requires_review)?.id||accounts[0]?.id||'';safety=null;safetyId='';}
      onAccountsChanged(accounts);renderAccounts();renderDetail();
      if(selectedId)await loadSafety(selectedId);
    }catch(error){if(current!==refreshSerial)return;message(error.message||'账号状态读取失败',true);throw error;}
  }
  async function selectAccount(accountId){if(!accounts.some(item=>item.id===accountId))return;selectedId=accountId;safety=null;safetyId='';renderAccounts();renderDetail();await loadSafety(accountId);}
  async function loadSafety(accountId){
    if(!accountId)return;const current=++revision;
    try{const value=await call('assistant_account_safety',{account_id:accountId});
      if(current!==revision||selectedId!==accountId)return;safety=value;safetyId=accountId;renderDetail();
    }catch(error){if(current!==revision)return;safety=null;safetyId='';renderDetail();message(error.message||'复核记录读取失败',true);}
  }
  async function completeReview(accountId){
    let data;try{if(safetyId!==accountId)throw Error('请先刷新账号复核记录');data=reviewSignal(accountId,safety);}catch(error){message(error.message,true);return;}
    if(busy)return;
    const reauth=accountRecovery(accounts.find(item=>item.id===accountId)).reauth;
    busy=true;renderAccounts();renderDetail();
    try{message(reauth?'正在准备二维码…':'正在检查连接…');await recoverConnection(accountId,safety,payload=>call('assistant_account_signal',payload),reauth?async id=>{safety=null;safetyId='';await refresh();await beginLogin(id,true);}:verifyConnection);safety=null;safetyId='';await refresh();}
    catch(error){safety=null;safetyId='';message(error.message||'连接未确认，采集保持暂停。请先核对手机提示。',true);await refresh().catch(()=>{});}
    finally{busy=false;renderAccounts();renderDetail();}
  }
  async function verifyConnection(accountId){
    if(typeof checkAccount!=='function')throw Error('连接检查暂不可用，请稍后再试');
    const checked=await checkAccount(accountId);
    if(checked?.status==='ready'&&checked.requires_review!==true){message('连接正常，不需要重新扫码。');return checked;}
    throw Error(checked?.requires_review?'平台仍要求验证，请核对手机提示；采集保持暂停。':'登录需要更新，请使用此页的扫码登录。');
  }
  async function checkConnection(accountId){
    if(busy)return;busy=true;renderAccounts();renderDetail();message('正在检查连接…');
    try{await verifyConnection(accountId);await refresh();}
    catch(error){message(error.message||'连接检查未完成，请稍后再试',true);await refresh().catch(()=>{});}
    finally{busy=false;renderAccounts();renderDetail();}
  }
  async function reportSignal(accountId,kind,label){
    if(!confirmReview(`确认${label}？记录后该账号相关平台操作会暂停，需人工核实。`))return;
    busy=true;renderAccounts();renderDetail();
    try{await call('assistant_account_signal',{account_id:accountId,kind});message('安全提醒已记录，相关操作将暂停。');await refresh();}
    catch(error){message(error.message||'提醒未记录，请核对状态',true);await loadSafety(accountId);}
    finally{busy=false;renderAccounts();renderDetail();}
  }
  async function beginLogin(accountId='',afterReview=false){
    if(!loginAllowed()||busy&&!afterReview)return;
    const account=accounts.find(item=>item.id===accountId);
    if(account&&!accountRecovery(account).canLogin){message('请先完成手机验证并核实账号，暂勿重复扫码。',true);return;}
    busy=true;renderAccounts();renderDetail();qr.hidden=false;qrImage.hidden=true;qrMessage.textContent='正在准备二维码…';
    try{const result=await call(accountId?'assistant_account_login':'assistant_new_account_login',accountId?{account_id:accountId}:{});
      if(!QR_JOB.test(result?.login_job||''))throw Error('登录任务编号无效，请核对助手状态');
      loginJob=result.login_job;pollLogin(loginJob);await refresh();
    }catch(error){qrMessage.textContent=`${error.message||'二维码未准备好'}。请核对账号与助手状态，暂勿连续重试。`;}
    finally{busy=false;renderAccounts();renderDetail();}
  }
  async function pollLogin(job){
    stopPolling();if(job!==loginJob||qr.hidden)return;
    try{
      const value=await call('assistant_job_status',{job_id:job});
      if(job!==loginJob||qr.hidden)return;
      if(value.status==='running'){
        if(value.phase==='verifying_identity'){message('');qrImage.hidden=true;qrMessage.textContent='扫码已完成，本机正在核验账号身份。';}
        else if(value.qr_ready){message('');if(qrImage.hidden){qrImage.src=`/assistant-qr/${job}?t=${Date.now()}`;qrImage.hidden=false;}qrMessage.textContent='请用小红书 App 扫码，完成后等待身份核验。';}
        else qrMessage.textContent='正在等待二维码…';
        pollTimer=setTimeout(()=>void pollLogin(job),1500);return;
      }
      loginJob='';qrImage.hidden=true;qrMessage.textContent=value.status==='completed'?'登录已完成，请核对账号状态。':`${value.error||'登录结果未确认'}。请核对手机和账号状态，暂勿重复扫码。`;
      if(value.status==='completed'){qr.hidden=true;message('登录已完成，正在更新账号信息…');}
      await refresh();
    }catch(error){qrImage.hidden=true;qrMessage.textContent=`${error.message||'连接中断'}。扫码结果尚未确认，请核对助手与手机状态。`;}
  }
  shell.querySelector('.platform-account-refresh').addEventListener('click',()=>void refresh().catch(()=>{}));
  shell.querySelector('.platform-account-new').addEventListener('click',()=>void beginLogin());
  shell.querySelector('.platform-account-qr-close').addEventListener('click',()=>{stopPolling();loginJob='';qr.hidden=true;qrImage.hidden=true;qrImage.removeAttribute('src');void refresh().catch(()=>{});});
  return {refresh,reset,openReview(accountId=''){
    if(accountId){selectedId=accountId;safety=null;safetyId='';}
    if(accountId&&!accounts.some(item=>item.id===accountId))return;
    const target=accounts.find(item=>item.id===selectedId)||accounts.find(item=>item.requires_review)||accounts[0];
    if(target)void selectAccount(target.id);
  },setAccounts(items){if(!Array.isArray(items))return;accounts=items.filter(item=>item?.platform==='xiaohongshu'&&typeof item.id==='string');renderAccounts();renderDetail();}};
}
