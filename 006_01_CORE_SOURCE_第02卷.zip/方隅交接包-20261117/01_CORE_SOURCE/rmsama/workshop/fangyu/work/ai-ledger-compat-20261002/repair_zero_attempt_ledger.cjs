// One known Fangyu reservation, before any provider attempt. --status is read-only.
// Never print document bodies, request IDs, credentials, prompts, or provider output.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const {spawnSync} = require('node:child_process');
const project = path.resolve(__dirname, '../..');
// Pin the contract copied from the actual deployed tree; canonical workspace may differ.
const {hash} = require(path.join(__dirname, 'stage/ai_contract.cjs'));

const ENVIRONMENT = 'fh6-d5ga45c0ddae7008c';
const COMPANY = 'fangyu-apartment-client';
const DAY = '2026-10-02';
const RESERVED = 48118;
const OPERATION = 'intent_analyze';
const MODEL = 'deepseek-flash';
const ERROR = 'AI_PRE_PROVIDER_WRITE_FAILED';
const COLLECTION = Object.freeze({ledger:'fangyu_ai_ledger',budget:'fangyu_ai_budget',cache:'fangyu_ai_cache'});
const digest = value => crypto.createHash('sha256').update(value).digest('hex');

function canonical(value) {
  if (Array.isArray(value)) return '['+value.map(canonical).join(',')+']';
  if (value && typeof value === 'object') return '{'+Object.keys(value).sort().filter(key => value[key] !== undefined)
    .map(key => JSON.stringify(key)+':'+canonical(value[key])).join(',')+'}';
  return JSON.stringify(value);
}
function invariant(condition) {if (!condition) throw Error('AI_LEDGER_REPAIR_GUARD');}
function unwrap(result) {
  invariant(result && !result.code && Object.hasOwn(result, 'data'));
  const value=result.data;
  if (Array.isArray(value)) {invariant(value.length <= 2);return value;}
  invariant(value === null || value === undefined || typeof value === 'object');
  return value;
}
function documentId(key) {return hash(`${COMPANY}\n${key}`);}
function ref(owner, kind, key) {return owner.collection(COLLECTION[kind]).doc(documentId(key));}
function checkDocumentId(doc, kind, key) {
  invariant(doc && typeof doc === 'object' && !Array.isArray(doc));
  invariant(doc.companyId === COMPANY && (doc._id === undefined || doc._id === documentId(key)));
}
function validate(ledger,budget,cache) {
  invariant(ledger && budget && cache);
  invariant(typeof ledger.request_id === 'string' && /^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/.test(ledger.request_id));
  invariant(typeof ledger.context_hash === 'string' && /^[0-9a-f]{64}$/.test(ledger.context_hash));
  checkDocumentId(ledger,'ledger',ledger.request_id);
  checkDocumentId(budget,'budget',DAY);
  checkDocumentId(cache,'cache',ledger.context_hash);
  invariant(ledger.day === DAY && ledger.operation === OPERATION && ledger.model === MODEL);
  invariant(ledger.status === 'reserved' && Array.isArray(ledger.attempts) && ledger.attempts.length === 0);
  invariant(ledger.reserved_micro === RESERVED && (ledger.actual_cost_micro == null || ledger.actual_cost_micro === 0));
  invariant(ledger.usage == null && (ledger.reservation_retained == null || ledger.reservation_retained === false));
  invariant(ledger.completed_at == null && !ledger.error_code && (ledger.http_status == null || ledger.http_status === 0));
  invariant(budget.day === DAY && Number.isSafeInteger(budget.reserved_micro) && budget.reserved_micro >= RESERVED);
  invariant(Number.isSafeInteger(budget.spent_micro) && budget.spent_micro >= 0);
  invariant(Number.isSafeInteger(budget.request_count) && budget.request_count >= 1);
  invariant(cache.status === 'in_flight' && cache.request_id === ledger.request_id && cache.model === MODEL);
  return {ledger,budget,cache};
}
function metadata(docs, readOnly=true) {
  return {read_only:readOnly, company:COMPANY, day:DAY, operation:OPERATION, model:MODEL,
    ledger_status:docs.ledger.status, attempts:docs.ledger.attempts.length,
    reservation_micro:RESERVED, budget_reserved_micro:docs.budget.reserved_micro,
    budget_spent_micro:docs.budget.spent_micro, budget_request_count:docs.budget.request_count,
    cache_status:docs.cache.status};
}
function takeOne(value) {
  if (Array.isArray(value)) {invariant(value.length <= 1);return value[0] || null;}
  return value || null;
}
async function inspect(db) {
  // Limit to two so an ambiguous second candidate fails closed.
  const result=unwrap(await db.collection(COLLECTION.ledger)
    .where({companyId:COMPANY,day:DAY,status:'reserved'}).limit(2).get());
  invariant(Array.isArray(result) && result.length === 1);
  const ledger=result[0];
  invariant(ledger.operation === OPERATION && ledger.model === MODEL && ledger.reserved_micro === RESERVED);
  // A query result must prove it is stored at the production repoFor ledger key.
  invariant(ledger._id === documentId(ledger.request_id));
  const budget=takeOne(unwrap(await ref(db,'budget',DAY).get()));
  const cache=takeOne(unwrap(await ref(db,'cache',ledger.context_hash).get()));
  return validate(ledger,budget,cache);
}
function dpapi(mode,bytes) {
  const python=path.join(project,'work/desktop-python/Scripts/python.exe');
  const helper=path.join(project,'work/cloud/dpapi_stream.py');
  const result=spawnSync(python,[helper,mode],{input:bytes,maxBuffer:24*1024*1024,
    windowsHide:true,stdio:['pipe','pipe','pipe']});
  invariant(!result.error && result.status === 0 && result.stdout?.length);
  return result.stdout;
}
function saveBackups(docs,{crypt=dpapi,directory=path.join(__dirname,'private-backups')}={}) {
  validate(docs.ledger,docs.budget,docs.cache);
  fs.mkdirSync(directory,{recursive:true});
  const saved={};
  for (const kind of ['ledger','budget','cache']) {
    const document=docs[kind];
    const plain=Buffer.from(JSON.stringify({format:'fangyu-ai-zero-attempt-v1',environment:ENVIRONMENT,
      company:COMPANY,kind,document}),'utf8');
    let reopened;
    try {
      const cipher=crypt('encrypt',plain);
      reopened=crypt('decrypt',cipher);
      invariant(reopened.length === plain.length && crypto.timingSafeEqual(reopened,plain));
      reopened.fill(0);reopened=null;
      const file=path.join(directory,`ai-ledger-${kind}-${Date.now()}-${crypto.randomBytes(5).toString('hex')}.dpapi`);
      fs.writeFileSync(file,cipher,{flag:'wx',mode:0o600});
      const persisted=fs.readFileSync(file);
      reopened=crypt('decrypt',persisted);
      invariant(digest(cipher) === digest(persisted) && reopened.length === plain.length
        && crypto.timingSafeEqual(reopened,plain));
      saved[kind]={file,sha:digest(canonical(document)),verified:true};
    } finally {plain.fill(0);if(reopened)reopened.fill(0);}
  }
  return saved;
}
function nextDocuments(docs,now) {
  validate(docs.ledger,docs.budget,docs.cache);
  return {
    ledger:{...docs.ledger,status:'unbilled',completed_at:now,usage:null,actual_cost_micro:0,
      error_code:ERROR,http_status:0,reservation_retained:false},
    budget:{...docs.budget,reserved_micro:docs.budget.reserved_micro-RESERVED},
    cache:{...docs.cache,status:'failed',error_code:ERROR,expires_at:now}
  };
}
function withoutId(value) {const {_id,...body}=value;return body;}
async function repair(db,{backup=saveBackups,clock=Date.now}={}) {
  const prior=await inspect(db);
  const saved=await backup(prior);
  invariant(['ledger','budget','cache'].every(kind=>saved?.[kind]?.verified === true
    && saved[kind].sha === digest(canonical(prior[kind]))));
  const result=await db.runTransaction(async transaction=>{
    // Read all three first, then compare exact document versions before any write.
    const ledger=takeOne(unwrap(await ref(transaction,'ledger',prior.ledger.request_id).get()));
    const budget=takeOne(unwrap(await ref(transaction,'budget',DAY).get()));
    const cache=takeOne(unwrap(await ref(transaction,'cache',prior.ledger.context_hash).get()));
    const current=validate(ledger,budget,cache);
    invariant(['ledger','budget','cache'].every(kind=>digest(canonical(current[kind])) === saved[kind].sha));
    const next=nextDocuments(current,clock());
    for (const kind of ['ledger','budget','cache']) {
      const key=kind==='ledger'?prior.ledger.request_id:kind==='budget'?DAY:prior.ledger.context_hash;
      const response=await ref(transaction,kind,key).set(withoutId(next[kind]));
      invariant(!response?.code);
    }
    return {updated:3,retained_spent_micro:current.budget.spent_micro,
      retained_request_count:current.budget.request_count,new_reserved_micro:next.budget.reserved_micro};
  });
  return {...metadata(prior,false),...result,backup_verified:true,backup_count:3};
}
async function connect() {
  const {getCredentialWithoutCheck}=require(path.join(project,'work/cloud-tools/node_modules/@cloudbase/toolbox'));
  const cloudbase=require(path.join(__dirname,'stage/node_modules/@cloudbase/node-sdk'));
  const identity=await getCredentialWithoutCheck();
  invariant(identity?.secretId && identity?.secretKey);
  const config={env:ENVIRONMENT,secretId:identity.secretId,secretKey:identity.secretKey};
  if (identity.token) config.sessionToken=identity.token;
  return cloudbase.init(config).database();
}
async function main() {
  const args=process.argv.slice(2);
  invariant(args.length === 1 && ['--status','--repair'].includes(args[0]));
  const db=await connect();
  const answer=args[0]==='--repair'?await repair(db):metadata(await inspect(db));
  console.log(JSON.stringify(answer));
}
module.exports={inspect,validate,metadata,saveBackups,nextDocuments,repair,canonical,
  ENVIRONMENT,COMPANY,DAY,RESERVED,ERROR,COLLECTION};
if (require.main === module) main().catch(()=>{
  console.error('AI ledger maintenance stopped: guard, backup, or transaction did not pass. No private fields printed.');
  process.exitCode=1;
});
