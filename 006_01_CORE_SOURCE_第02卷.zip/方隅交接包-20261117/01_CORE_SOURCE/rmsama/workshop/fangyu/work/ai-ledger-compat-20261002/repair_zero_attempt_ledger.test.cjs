const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const {hash} = require('./stage/ai_contract.cjs');
const {inspect,metadata,saveBackups,repair,canonical,COMPANY,DAY,RESERVED,ERROR,COLLECTION} = require('./repair_zero_attempt_ledger.cjs');

const REQUEST_ID = '426998cc-7e37-4d25-b74b-f0263765b728';
const CONTEXT = 'a'.repeat(64);
const id = key => hash(`${COMPANY}\n${key}`);
const clone = value => structuredClone(value);
function seed() {
  return {
    [COLLECTION.ledger]: {[id(REQUEST_ID)]: {_id:id(REQUEST_ID),companyId:COMPANY,request_id:REQUEST_ID,
      context_hash:CONTEXT,day:DAY,operation:'intent_analyze',model:'deepseek-flash',status:'reserved',
      reserved_micro:RESERVED,attempts:[],created_at:123,username:'synthetic'}},
    [COLLECTION.budget]: {[id(DAY)]: {_id:id(DAY),companyId:COMPANY,day:DAY,
      reserved_micro:RESERVED+200,spent_micro:75,request_count:2,extra:'preserve'}},
    [COLLECTION.cache]: {[id(CONTEXT)]: {_id:id(CONTEXT),companyId:COMPANY,status:'in_flight',
      request_id:REQUEST_ID,model:'deepseek-flash',expires_at:123456,rules_version:'synthetic'}}
  };
}
function fakeDb(initial = seed()) {
  let rows = clone(initial), writes = 0;
  function owner(current) {
    return {collection(name) {return {
      where(criteria) {return {limit(n) {return {async get() {return {data:Object.values(current[name] || {})
        .filter(doc=>Object.entries(criteria).every(([key,value])=>doc[key]===value)).slice(0,n).map(clone)};}};}};},
      doc(key) {return {async get() {return {data:current[name]?.[key] ? [clone(current[name][key])] : []};},
        async set(body) {writes++;current[name][key]={_id:key,...clone(body)};return {updated:1};}};}
    };}};
  }
  return {...owner(rows),async runTransaction(callback) {
    const current=clone(rows);
    const result=await callback(owner(current));
    rows=current;
    return result;
  },get rows() {return rows;},get writes() {return writes;}};
}
function verifiedBackup(docs) {return Object.fromEntries(['ledger','budget','cache']
  .map(kind=>[kind,{verified:true,sha:require('node:crypto').createHash('sha256')
    .update(canonical(docs[kind])).digest('hex')}]));}

test('status inspects only the exact pre-provider reservation without writes or request ID output',async()=>{
  const db=fakeDb();
  const result=metadata(await inspect(db));
  assert.equal(result.read_only,true);
  assert.equal(result.attempts,0);
  assert.equal(result.reservation_micro,RESERVED);
  assert.equal(db.writes,0);
  assert.doesNotMatch(JSON.stringify(result),new RegExp(REQUEST_ID));
});

test('repair changes only three expected documents, preserving unrelated budget state',async()=>{
  const db=fakeDb(), before=clone(db.rows), now=987654;
  const answer=await repair(db,{backup:verifiedBackup,clock:()=>now});
  const ledger=db.rows[COLLECTION.ledger][id(REQUEST_ID)];
  const budget=db.rows[COLLECTION.budget][id(DAY)];
  const cache=db.rows[COLLECTION.cache][id(CONTEXT)];
  assert.equal(answer.updated,3);
  assert.equal(answer.backup_verified,true);
  assert.equal(db.writes,3);
  assert.deepEqual(ledger,{...before[COLLECTION.ledger][id(REQUEST_ID)],status:'unbilled',
    completed_at:now,usage:null,actual_cost_micro:0,error_code:ERROR,http_status:0,reservation_retained:false});
  assert.deepEqual(budget,{...before[COLLECTION.budget][id(DAY)],reserved_micro:200});
  assert.deepEqual(cache,{...before[COLLECTION.cache][id(CONTEXT)],status:'failed',error_code:ERROR,expires_at:now});
  assert.doesNotMatch(JSON.stringify(answer),new RegExp(REQUEST_ID));
});

test('rejects ambiguous, attempted, settled, charged, tenant-mismatched, and unrelated cache records',async()=>{
  const cases={
    attempted:s=>s[COLLECTION.ledger][id(REQUEST_ID)].attempts.push({attempt:1}),
    settled:s=>s[COLLECTION.ledger][id(REQUEST_ID)].status='settled',
    charged:s=>s[COLLECTION.ledger][id(REQUEST_ID)].actual_cost_micro=1,
    completed:s=>s[COLLECTION.ledger][id(REQUEST_ID)].completed_at=42,
    wrongKey:s=>s[COLLECTION.ledger][id(REQUEST_ID)]._id='wrong',
    wrongCompany:s=>s[COLLECTION.budget][id(DAY)].companyId='another-company',
    insufficient:s=>s[COLLECTION.budget][id(DAY)].reserved_micro=RESERVED-1,
    wrongCache:s=>s[COLLECTION.cache][id(CONTEXT)].request_id='other-request',
    ambiguous:s=>s[COLLECTION.ledger].other={...s[COLLECTION.ledger][id(REQUEST_ID)],_id:'other'}
  };
  for (const [name,mutate] of Object.entries(cases)) {
    const state=seed();mutate(state);
    const db=fakeDb(state);
    await assert.rejects(inspect(db),/AI_LEDGER_REPAIR_GUARD/,name);
    assert.equal(db.writes,0,name);
  }
});

test('rejects any change between backup and transactional reread',async()=>{
  const db=fakeDb();
  await assert.rejects(repair(db,{backup:docs=>{
    const saved=verifiedBackup(docs);
    db.rows[COLLECTION.budget][id(DAY)].request_count++;
    return saved;
  }}),/AI_LEDGER_REPAIR_GUARD/);
  assert.equal(db.writes,0);
});

test('requires every verified backup before the first write',async()=>{
  const db=fakeDb();
  await assert.rejects(repair(db,{backup:()=>({})}),/AI_LEDGER_REPAIR_GUARD/);
  assert.equal(db.writes,0);
});

test('encrypted backup is written and decrypted again before verification',async()=>{
  const directory=fs.mkdtempSync(path.join(os.tmpdir(),'fangyu-ai-backup-test-'));
  try {
    const docs=await inspect(fakeDb());
    let encrypts=0,decrypts=0;
    const crypt=(mode,buffer)=>{if(mode==='encrypt') {encrypts++;return Buffer.from(buffer).reverse();}
      decrypts++;return Buffer.from(buffer).reverse();};
    const saved=saveBackups(docs,{crypt,directory});
    assert.equal(encrypts,3);
    assert.equal(decrypts,6);
    for(const kind of ['ledger','budget','cache']) {
      assert.equal(saved[kind].verified,true);
      assert.ok(fs.statSync(saved[kind].file).size>0);
    }
  } finally {fs.rmSync(directory,{recursive:true,force:true});}
});

test('current-user DPAPI round-trip succeeds on synthetic documents only',async()=>{
  const directory=fs.mkdtempSync(path.join(os.tmpdir(),'fangyu-ai-dpapi-test-'));
  try {
    const docs=await inspect(fakeDb());
    const saved=saveBackups(docs,{directory});
    assert.deepEqual(Object.keys(saved),['ledger','budget','cache']);
    for(const item of Object.values(saved)) assert.equal(item.verified,true);
  } finally {fs.rmSync(directory,{recursive:true,force:true});}
});
