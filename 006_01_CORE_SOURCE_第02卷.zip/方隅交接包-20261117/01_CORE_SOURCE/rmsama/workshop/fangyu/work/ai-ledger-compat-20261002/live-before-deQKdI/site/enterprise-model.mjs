export const intentLabels = {super_high:'超高意向',high:'高意向',medium:'中意向',low:'低意向',very_low:'极低意向',pending:'待分析',uncertain:'待核实',unrelated:'无关'};
export function displayCommentDate(value) {
 const match=String(value||'').match(/^(\d{4})-(\d{2})-(\d{2})(?:[T ](\d{2}):(\d{2})(?::\d{2}(?:\.\d+)?)?(?:Z|[+-]\d{2}:?\d{2})?)?$/);
 if(!match)return '待核实';
 const [,year,month,day,hour,minute]=match,date=new Date(Date.UTC(Number(year),Number(month)-1,Number(day)));
 if(date.getUTCFullYear()!==Number(year)||date.getUTCMonth()!==Number(month)-1||date.getUTCDate()!==Number(day)||hour!==undefined&&(Number(hour)>23||Number(minute)>59||!Number.isFinite(Date.parse(String(value)))))return '待核实';
 return `${year}-${month}-${day}${hour===undefined?'':` ${hour}:${minute}`}`;
}
export function effectiveIntent(lead) {
 const current=lead.manual_intent||lead.ai_intent;
 if(current?.status==='graded'&&Object.hasOwn(intentLabels,current.level)&&!['pending','uncertain','unrelated'].includes(current.level))return {...current,label:intentLabels[current.level],kind:current.level};
 if(['pending','uncertain','unrelated'].includes(current?.status))return {...current,label:intentLabels[current.status],kind:current.status};
 return {status:'pending',level:null,label:'待分析',kind:'pending',reason:lead.grade?`历史规则 ${lead.grade}，尚未完成 AI 分析`:''};
}
export function intentFacts(lead){
 const source=lead.manual_intent?.key_info??lead.ai_intent?.key_info;
 if(!Array.isArray(source))return null;
 return source.filter(item=>item&&typeof item.value==='string'&&typeof item.evidence==='string'&&item.evidence.includes(item.value)&&String(lead.text||'').includes(item.evidence)).slice(0,8);
}
export function continuousPayload(values,keywords) {
 const city=String(values.city||'').trim(),rawRange=String(values.comment_date_range||'3'),range={3:'3months',6:'6months',12:'12months'}[rawRange]||rawRange;
 if(!city)throw Error('请先填写城市');
 if(!['3months','6months','12months','custom'].includes(range))throw Error('请选择评论时间');
 if(!keywords.length)throw Error('请至少选择或填写一个关键词');
 const from=String(values.comment_date_from||''),to=String(values.comment_date_to||'');
 if(range==='custom'&&(!from||!to||from>to))throw Error('请设置有效的评论日期范围');
 return {name:String(values.name||'').trim()||`${city}租房获客`,account_id:String(values.account_id||''),platform:'xiaohongshu',
  scope:'search_comments',comment_depth:'all',comment_keyword_mode:'all',intent_mode:'all',keywords,
  continuous_enabled:true,city,area:String(values.area||'').trim(),comment_date_range:range,
  comment_date_from:range==='custom'?from:'',comment_date_to:range==='custom'?to:''};
}
export function confirmedNumber(value){const number=typeof value==='number'?value:null;return Number.isSafeInteger(number)&&number>=0?number:null;}
function safeDiagnostic(raw) {
 return String(raw||'').slice(0,1200)
  .replace(/(Bearer\s+)[^\s;，,]+/gi,'$1[已隐藏]')
  .replace(/((?:api[_-]?key|access[_-]?token|authorization|cookie|secret|password)\s*[:=]\s*)(?:"[^"]*"|'[^']*'|[^\s;，,]+)/gi,'$1[已隐藏]')
  .replace(/https?:\/\/[^\s;，,]+/gi,'[链接已隐藏]');
}
export function continuousPresentation(task,now=Date.now(),account=null) {
 const current=task?.continuous||{},progress=task?.progress||{},active=['queued','running','waiting'].includes(current.status);
 const next=typeof current.next_run_epoch==='number'?current.next_run_epoch*1000:Date.parse(current.next_run_at||'');
 const started=Date.parse(current.started_at||current.created_at||'');
 const phase=progress.phase||progress.stage||current.stage;
 const labels={preparing:'正在准备采集',searching:'正在搜索帖子',reading_comments:'正在读取帖子评论',filtering:'正在筛选评论',saving:'正在保存评论',waiting:'等待下一次读取'};
 const rawError=current.last_error||current.message||'';
 const stopped=['paused','blocked'].includes(current.status),historicalVerification=stopped&&/verification_required|平台要求验证|小红书.*验证/.test(rawError);
 const reviewed=account?.requires_review===false,requiresReview=stopped&&account?.requires_review===true;
 const requiresVerification=requiresReview?account.review_reason==='verification_required':!reviewed&&account?.requires_review!==true&&historicalVerification;
 const attention=requiresReview||requiresVerification,errorState=['blocked','failed','interrupted'].includes(current.status)||attention;
 const statusLabel={idle:'等待开始',queued:'采集已安排',running:labels[phase]||'正在采集',waiting:current.wait_reason==='range_exhausted'?'等待新内容':'等待下一次读取',paused:requiresVerification?'请在小红书完成验证后再继续':requiresReview?'账号需人工复核后继续':current.inflight?'正在暂停，请等待当前读取结束':'采集已暂停',blocked:requiresVerification?'请在小红书完成验证后再继续':requiresReview?'账号需人工复核后继续':'采集已暂停，需要处理',failed:'采集失败',interrupted:'采集中断，请核对后恢复',exhausted:'本轮内容已读完',completed:'本轮采集完成',stopped:'采集已停止'};
 const ended=active?now:Date.parse(current.updated_at||'');
 const elapsed=Number.isFinite(started)&&Number.isFinite(ended)?Math.max(0,Math.floor((ended-started)/1000)):null;
 return {active,status:current.status||'idle',phase,heading:statusLabel[current.status]||'等待开始',requiresVerification,requiresReview,
  elapsed,nextSeconds:Number.isFinite(next)&&active?Math.max(0,Math.ceil((next-now)/1000)):null,
  read:confirmedNumber(current.read),imported:confirmedNumber(current.imported),duplicates:confirmedNumber(current.duplicates),
  batches:confirmedNumber(current.batches),analysisPending:confirmedNumber(task?.analysis?.pending),
  message:errorState?(requiresVerification?'采集已暂停，当前进度已保留':requiresReview?'采集已暂停，请到左侧「小红书账号」核对':'本次采集未完成，请查看详情后处理'):reviewed&&historicalVerification?'账号复核已记录，请核对后继续采集':(current.message||current.last_error||''),
  detail:errorState||historicalVerification?safeDiagnostic(rawError):''};
}
export function groupComments(items,groupBy='note') {
 const groups=new Map();
 for(const item of items){let canonicalUrl='';try{const u=new URL(item.note_url||item.url||'');const match=u.pathname.match(/\/(?:explore|discovery\/item)\/([A-Za-z0-9]+)/);canonicalUrl=match?match[1]:u.hostname+u.pathname;}catch{}
  const fallback=groupBy==='blogger'?(item.content_author_id||item.content_author||'博主未提供'):groupBy==='date'?(String(item.published_at||'').slice(0,10)||'日期未提供'):
   groupBy==='intent'?effectiveIntent(item).kind:(item.note_id||item.content_id||canonicalUrl||item.content_title||'帖子信息未提供');
  const key=item.group_key||fallback,label=groupBy==='note'?item.content_title||'帖子标题未提供':groupBy==='blogger'?item.content_author||'博主未提供':groupBy==='intent'?effectiveIntent(item).label:fallback;
  if(!groups.has(key))groups.set(key,{key,label,author:groupBy==='note'?item.content_author||'':'',url:groupBy==='note'?item.note_url||item.url||'':'',items:[]});
  groups.get(key).items.push(item);
 }
 return [...groups.values()];
}
export function updatePresentation(state={}) {
 const status=state.status||'unknown',configured=state.feed_configured===true,restart=state.requires_restart===true;
 const labels={ready:'可以检查更新',not_configured:'更新源尚未配置',available:'有可用更新',staged:'更新已下载并校验',busy:'等待工作台空闲',pending_restart:'更新已安排，等待重开',awaiting_close:'等待关闭工作台',awaiting_confirmation:'等待启动自检',up_to_date:'当前已是最新版本',installed:'更新完成',rolled_back:'已恢复上一版本',update_rejected:'此更新已被拒绝'};
 const blocked=restart||['pending_restart','awaiting_close','awaiting_confirmation'].includes(status);
 return {status,label:labels[status]||'更新状态待核对',configured,restart,
  canCheck:configured&&!blocked,canDownload:configured&&!blocked&&status==='available',
  canInstall:configured&&!blocked&&['staged','busy'].includes(status)&&Number.isSafeInteger(state.candidate_release),
  message:typeof state.message==='string'?state.message:'',
  installedVersion:state.installed_version&&state.installed_version!=='unknown'?String(state.installed_version):'版本未提供',
  installedRelease:Number.isSafeInteger(state.installed_release)?state.installed_release:null,
  candidateRelease:Number.isSafeInteger(state.candidate_release)?state.candidate_release:null};
}
