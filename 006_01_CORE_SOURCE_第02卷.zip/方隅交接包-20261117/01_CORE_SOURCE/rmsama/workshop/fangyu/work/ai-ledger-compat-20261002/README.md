# 方隅 AI 零尝试预留账本一次性维护候选

目标只限于 2026-10-02 方隅企业 `intent_analyze` / `deepseek-flash` 的 48118 micro 预留，其 ledger 仍为 `reserved`、`attempts=[]`，cache 为对应 `in_flight`。根据 `ai_enterprise.cjs` 的调用顺序，`markAttempt` 写入成功后才会触发 provider；该已知故障发生在写入前，未发 provider。其他状态应停止，不做推断性冲销。

## 执行界面

脚本：`repair_zero_attempt_ledger.cjs`

- `node repair_zero_attempt_ledger.cjs --status`：云端只读，验证唯一目标及三文档一致性，只输出状态、次数与金额等元数据。
- `node repair_zero_attempt_ledger.cjs --repair`：先备份三文档并用当前 Windows 用户 DPAPI 加密，文件回读解密校验；再在云事务内重读三文档，SHA 相同才写入。此命令由 root 执行。
- 不带参数或其他参数直接拒绝。

云环境固定为 `fh6-d5ga45c0ddae7008c`，企业固定为 `fangyu-apartment-client`。哈希函数与 SDK 固定读取 `stage` 中经核对的已部署版本。凭据沿用本机 CloudBase 维护身份，脚本不读取或打印企业 AI API key。

## 守卫与变更

先查询该企业、日期唯一的 `reserved` ledger，要求实际 `_id` 等于已部署 `hash(companyId + '\n' + request_id)`；然后以已部署相同规则定向读取预算和 cache。要求空 attempts、无已结算费用/usage/completed_at、相同企业、预算预留不少于 48118、cache 的 request_id/model 与 ledger 完全一致。任一条件不满足则无写入退出。

写入只影响三份原文档：ledger 设为 `unbilled`、实际费用 0、`reservation_retained=false`、固定错误码 `AI_PRE_PROVIDER_WRITE_FAILED`；预算仅从 reserved 减 48118，保留 spent 与 request_count；cache 设为 `failed`，过期时间设为执行时刻。`set` 前移除 SDK 保留的 `_id`，其余字段保留。事务若发现备份后文档有任何变化则拒绝。

备份默认落在同目录 `private-backups`，仅当前 Windows 用户可解密。该目录含完整加密原文，勿上传、提交或分享；终端输出不含请求 ID、密钥、原文及备份路径。

## 隔离验证

`node --test repair_zero_attempt_ledger.test.cjs`：7/7 通过，覆盖状态只读、三文档精确更新、身份/状态/费用错配拒绝、备份后变化拒绝、缺备份拒绝、合成加密回读以及本机真实 DPAPI 合成文档回读。未调用云、provider 或平台请求；实际云端恢复结果需 root 的 `--status` / `--repair` 执行并验收。
