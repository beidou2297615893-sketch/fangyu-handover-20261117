const {test} = require('node:test');
const assert = require('node:assert/strict');
const {AsyncLocalStorage} = require('node:async_hooks');
const {createService} = require('./service.cjs');
const {createStore} = require('./index.js');
const {createProvider, ProviderError} = require('./ai_provider.cjs');
const {normalizeInput, validateOutput, tariff, reservationMicro, prompt, defaults, PRICE_VERSION, OPENAI_PRICE_VERSION,
  usageOf, configuredModel, hash} = require('./ai_contract.cjs');
const {COLLECTIONS, createEnterpriseAi} = require('./ai_enterprise.cjs');
const SECRET = '[REDACTED:api_key_sk]';
const OPENAI_SECRET = '[REDACTED:api_key_sk]';
const NOW = Date.UTC(2026, 8, 29, 2); // Tuesday 10:00 Asia/Shanghai, published peak tariff.
function memoryDb() {
  let documents = new Map(), queue = Promise.resolve(), rejectWrite = null; const transactionContext = new AsyncLocalStorage();
  const txFor = map => ({collection: name => ({doc: id => ({
    get: async () => ({data: map.has(`${name}/${id}`) ? {...structuredClone(map.get(`${name}/${id}`)), _id: id} : []}),
    set: async value => {
      assert.equal(Object.hasOwn(value, '_id'), false, 'CloudBase document.set rejects own _id');
      if (rejectWrite?.(name, value)) throw new Error(`unsafe SDK write failure ${SECRET}`);
      map.set(`${name}/${id}`, structuredClone(value));
    }
  })})});
  const db = {runTransaction(callback) {
    const task = queue.then(async () => {
      const staged = new Map([...documents].map(([k,v]) => [k, structuredClone(v)]));
      const result = await transactionContext.run(true, () => callback(txFor(staged))); documents = staged; return result;
    });
    queue = task.catch(() => {}); return task;
  }, collection: name => txFor(documents).collection(name)};
  return {db, rows: collection => [...documents.entries()].filter(([k]) => k.startsWith(`${collection}/`)).map(([,v]) => structuredClone(v)),
    state: company => documents.get(`fangyu_workspace_private/${company}`).state,
    rejectWriteWhen: predicate => {rejectWrite = predicate;},
    inTransaction: () => transactionContext.getStore() === true};
}
function resultFor(request) {
  const input = JSON.parse(request.messages[1].content);
  const output = input.count ? {keywords: Array.from({length: input.count}, (_, i) => ({keyword: `${input.city}求租需求${i+1}`,
    group: '租房需求', recommended: i < 10, reason: '明确寻找本地租房需求'}))} : {results: input.comments.map(c => ({id: c.id,
      status: 'graded', level: 'high', evidence: [c.text.slice(0, 10)], reason: '本人表达求租条件', region_status: 'unknown', content_region: '',
      key_info: c.text.includes('下个月') ? [{type: 'move_in', value: '下个月', evidence: '下个月想租'}] : []}))};
  return {model: request.model, ...(request.provider === 'openai' ? {service_tier: 'default'} : {}),
    usage: request.provider === 'openai'
    ? {prompt_tokens: 100, completion_tokens: 50, total_tokens: 150,
        prompt_tokens_details: request.model === 'gpt-6.1-sol' ? {cached_tokens: 0}
          : {cached_tokens: 20, cache_write_tokens: 30}, completion_tokens_details: {reasoning_tokens: 10}}
    : {prompt_tokens: 100, prompt_cache_hit_tokens: 20, prompt_cache_miss_tokens: 80, completion_tokens: 50},
    choices: [{finish_reason: 'stop', message: {content: JSON.stringify(output)}}]};
}
async function fixture({provider, connectivityProbe, shared, company = 'fangyu-apartment-client', budget = 5, now = () => NOW} = {}) {
  const memory = shared || memoryDb(); let calls = 0;
  const store = createStore(memory.db, company);
  const paidProvider = async request => {
    calls++; assert.equal(memory.inTransaction(), false, 'billable provider call must be outside DB callback');
    assert.equal(request.apiKey, request.provider === 'openai' ? OPENAI_SECRET : SECRET);
    assert.equal(JSON.stringify(request.messages).includes(SECRET), false);
    assert.equal(JSON.stringify(request.messages).includes(OPENAI_SECRET), false);
    return provider ? provider(request) : resultFor(request);
  };
  if (connectivityProbe) paidProvider.checkConnectivity = connectivityProbe;
  const service = createService({store, environmentId: 'ai-test-env', companyId: company, initialAdmin: 'admin', initialPassword: 'test-admin-password-123',
    clock: now, aiRetryDelay: async () => {}, aiProvider: paidProvider});
  const call = (operation, data = {}, token = '') => service({environment_id: 'ai-test-env', operation, ...data}, token);
  const admin = (await call('login', {username: 'admin', password: '[REDACTED:assigned_secret]'})).data.token;
  const saved = await call('ai_config_save', {api_key: SECRET, config: {enabled: true, daily_budget_cny: budget}}, admin);
  assert.equal(saved.status, 200);
  return {memory, call, admin, calls: () => calls};
}
const intentInput = (id = 'c1') => ({city: '杭州', area: '滨江', post: {id: 'post1', title: '杭州租房讨论', text: '租房避坑经验'},
  comments: [{id, text: '下个月想租一室一厅', published_at: '2026-09-29', ip_location: '浙江'}]});
test('admin-only ai_profile connectivity flag probes once after auth; default and staff never probe', async () => {
  let probes = 0;
  const f = await fixture({connectivityProbe: async () => {
    probes++; assert.equal(f.memory.inTransaction(), false);
    return {reachability: 'reachable', http_status: 401, error: null};
  }});
  const normal = await f.call('ai_profile', {}, f.admin);
  assert.equal(normal.status, 200); assert.equal(normal.data.connectivity, undefined);
  assert.equal(probes, 0);
  await f.call('member_save', {username:'staff',password:'[REDACTED:assigned_secret]',role:'operator'}, f.admin);
  const staff = (await f.call('login',{username:'staff',password:'[REDACTED:assigned_secret]'})).data.token;
  assert.equal((await f.call('ai_profile',{connectivity_check:true},staff)).status, 403);
  assert.equal((await f.call('ai_profile',{connectivity_check:true})).status, 401);
  assert.equal(probes, 0);
  const checked = await f.call('ai_profile',{connectivity_check:true},f.admin);
  assert.equal(checked.status, 200);
  assert.deepEqual(checked.data.connectivity,{reachability:'reachable',http_status:401,error:null});
  assert.equal(probes, 1); assert.equal(f.calls(), 0);
  assert.equal(f.memory.rows(COLLECTIONS.ledger).length, 0);
});
test('fixed OpenAI connectivity GET omits credentials, body and redirects', async () => {
  const requests=[];
  const transport=createProvider({fetchImpl:async (url,options) => {
    requests.push({url,options}); return {status:401,body:null};
  }});
  const result=await transport.checkConnectivity();
  assert.deepEqual(result,{reachability:'reachable',http_status:401,error:null});
  assert.equal(requests.length,1);
  assert.equal(requests[0].url,'https://api.openai.com/v1/models');
  assert.equal(requests[0].options.method,'GET');
  assert.equal(requests[0].options.redirect,'error');
  assert.equal(requests[0].options.body,undefined);
  assert.equal(requests[0].options.headers?.Authorization,undefined);
  assert.equal(JSON.stringify(requests).includes(SECRET),false);
});
test('connectivity network cause and timeout return only safe enums', async () => {
  const network=createProvider({fetchImpl:async () => {
    throw Object.assign(new Error(`unsafe ${SECRET}`),{cause:{code:'ENOTFOUND'}});
  }});
  assert.deepEqual(await network.checkConnectivity(),
    {reachability:'unreachable',http_status:0,error:{cause:{code:'ENOTFOUND'}}});
  const unknown=createProvider({fetchImpl:async () => {throw new Error(`unsafe ${SECRET}`);}});
  assert.deepEqual(await unknown.checkConnectivity(),
    {reachability:'unreachable',http_status:0,error:{cause:{code:'NETWORK_OTHER'}}});
  const timeout=createProvider({connectivityTimeoutMs:10,fetchImpl:(_url,{signal}) =>
    new Promise((_resolve,reject) => signal.addEventListener('abort',() => reject(new Error(`unsafe ${SECRET}`)),{once:true}))});
  assert.deepEqual(await timeout.checkConnectivity(),
    {reachability:'timeout',http_status:0,error:{cause:{code:'TIMEOUT'}}});
});
test('connectivity probe never returns a body and caps what it reads', async () => {
  let cancelled = false;
  const body = new ReadableStream({
    pull(controller) {controller.enqueue(new Uint8Array(2048));},
    cancel() {cancelled = true;}
  });
  const transport=createProvider({fetchImpl:async () => ({status:401,body})});
  assert.deepEqual(await transport.checkConnectivity(),
    {reachability:'reachable',http_status:401,error:{cause:{code:'BODY_LIMIT'}}});
  assert.equal(cancelled,true);
});
test('revoked admin session during connectivity probe suppresses result', async () => {
  let entered;
  const started=new Promise(resolve => {entered=resolve;});
  let release;
  const waiting=new Promise(resolve => {release=resolve;});
  const f=await fixture({connectivityProbe:async () => {
    entered(); await waiting;
    return {reachability:'reachable',http_status:401,error:null};
  }});
  const pending=f.call('ai_profile',{connectivity_check:true},f.admin);
  await started;
  assert.equal((await f.call('logout',{},f.admin)).status,200);
  release();
  const result=await pending;
  assert.equal(result.status,401);
  assert.equal(result.data.connectivity,undefined);
  assert.equal(f.calls(),0);
});
test('configuration is admin-only; operators receive safe profile; secret never leaves private company state', async () => {
  const f = await fixture();
  const read = await f.call('ai_config_read', {}, f.admin);
  assert.equal(read.data.config.model, 'deepseek-flash'); assert.equal(read.data.config.daily_budget_cny, 5);
  assert.equal(read.data.config.configured, true); assert.equal(JSON.stringify(read).includes(SECRET), false);
  assert.equal((await f.call('ai_config_read')).status, 401);
  await f.call('member_save', {username: 'staff', password: '[REDACTED:assigned_secret]', role: 'operator'}, f.admin);
  const staff = (await f.call('login', {username: 'staff', password: '[REDACTED:assigned_secret]'})).data.token;
  assert.equal((await f.call('ai_config_read', {}, staff)).status, 403);
  assert.equal((await f.call('ai_config_save', {api_key: SECRET}, staff)).status, 403);
  assert.equal((await f.call('ai_profile', {}, staff)).status, 200);
  assert.equal((await f.call('intent_analyze', intentInput(), staff)).status, 200);
  for (const operation of ['me', 'members', 'list', 'ai_profile', 'ai_config_read']) {
    assert.equal(JSON.stringify(await f.call(operation, {}, f.admin)).includes(SECRET), false);
  }
  const state = f.memory.state('fangyu-apartment-client');
  assert.equal(state.enterpriseAi.api_key, SECRET);
  for (const key of ['audit','devices','jobs','sessions','items']) assert.equal(JSON.stringify(state[key] || null).includes(SECRET), false);
  for (const collection of Object.values(COLLECTIONS)) assert.equal(JSON.stringify(f.memory.rows(collection)).includes(SECRET), false);
});
test('provider switching preserves legacy DeepSeek key and keeps OpenAI key private and separate', async () => {
  const f = await fixture();
  const initial = (await f.call('ai_config_read', {}, f.admin)).data.config;
  assert.equal(initial.provider, 'deepseek'); assert.equal(initial.providers.deepseek.configured, true);
  assert.equal(initial.providers.openai.configured, false);
  assert.equal(initial.model_catalog.some(m => m.id === 'gpt-6.1-extra'), false);
  assert.equal((await f.call('ai_config_save', {config: {provider: 'openai'}}, f.admin)).status, 400);
  assert.equal((await f.call('ai_config_save', {config: {provider: 'openai'}, api_key: SECRET}, f.admin)).status, 400);
  const changed = await f.call('ai_config_save', {config: {provider: 'openai', model: 'gpt-6.1-sol', reasoning_effort: 'low'},
    api_key: OPENAI_SECRET}, f.admin);
  assert.equal(changed.status, 200);
  assert.equal(changed.data.config.providers.openai.configured, true);
  assert.equal(changed.data.config.providers.deepseek.configured, true);
  assert.equal(JSON.stringify(changed).includes(OPENAI_SECRET), false);
  const response = await f.call('intent_analyze', intentInput(), f.admin);
  assert.equal(response.status, 200); assert.equal(response.data.provider, 'openai');
  assert.equal(response.data.configured_model, 'gpt-6.1-sol'); assert.equal(response.data.reasoning_effort, 'low');
  assert.equal(f.memory.state('fangyu-apartment-client').enterpriseAi.api_key, SECRET);
  assert.equal(f.memory.state('fangyu-apartment-client').enterpriseAi.api_keys.openai, OPENAI_SECRET);
  assert.equal((await f.call('ai_config_save', {config: {provider: 'deepseek'}}, f.admin)).status, 200);
  assert.equal((await f.call('intent_analyze', intentInput(), f.admin)).data.provider, 'deepseek');
  await f.call('ai_config_save', {config: {provider: 'openai', enabled: false}, clear_api_key: true}, f.admin);
  const after = (await f.call('ai_config_read', {}, f.admin)).data.config;
  assert.equal(after.providers.openai.configured, false); assert.equal(after.providers.deepseek.configured, true);
  assert.equal((await f.call('ai_config_save', {config: {enabled: true}}, f.admin)).status, 400);
  assert.equal((await f.call('ai_config_save', {config: {provider: 'deepseek', enabled: true}}, f.admin)).status, 200);
  for (const type of Object.values(COLLECTIONS)) assert.equal(JSON.stringify(f.memory.rows(type)).includes(OPENAI_SECRET), false);
});
test('Sol explicit no-cache usage bills input and hidden reasoning in the CNY budget', async () => {
  const f = await fixture();
  const saved = await f.call('ai_config_save', {config: {provider: 'openai', model: 'gpt-6.1-sol',
    reasoning_effort: 'low', usd_cny_rate: 7.5}, api_key: OPENAI_SECRET}, f.admin);
  assert.equal(saved.status, 200);
  assert.equal(saved.data.config.usd_cny_rate, 7.5);
  const first = await f.call('intent_analyze', intentInput(), f.admin);
  assert.equal(first.status, 200); assert.equal(first.data.billing.actual_cost_cny, 0.00525);
  const ledger = f.memory.rows(COLLECTIONS.ledger)[0];
  assert.equal(ledger.provider, 'openai'); assert.equal(ledger.price_version, OPENAI_PRICE_VERSION);
  assert.equal(ledger.usd_cny_rate, 7.5); assert.equal(ledger.usage.prompt_cache_write_tokens, 0);
  assert.equal(ledger.usage.prompt_cache_hit_tokens, 0); assert.equal(ledger.usage.cache_write_reported, false);
  assert.equal(ledger.usage.reasoning_tokens, 10); assert.equal(ledger.usage.completion_tokens, 50);
  const cached = await f.call('intent_analyze', intentInput(), f.admin);
  assert.equal(cached.data.cache_hit, true); assert.equal(cached.data.provider, 'openai');
  assert.equal(cached.data.model, first.data.model); assert.equal(f.calls(), 1);
  assert.equal((await f.call('ai_config_save', {config: {reasoning_effort: 'medium'}}, f.admin)).status, 200);
  assert.equal((await f.call('intent_analyze', intentInput(), f.admin)).data.cache_hit, false);
  assert.equal(f.calls(), 2);
});
test('Sol official-style usage settles both keyword suggestions and one-comment analysis without an unknown bill', async () => {
  const f = await fixture();
  await f.call('ai_config_save', {config: {provider: 'openai', model: 'gpt-6.1-sol', reasoning_effort: 'medium'},
    api_key: OPENAI_SECRET}, f.admin);
  const keywords = await f.call('keyword_suggest', {city: '杭州', seeds: ['滨江租房'], count: 1}, f.admin);
  const intent = await f.call('intent_analyze', intentInput(), f.admin);
  assert.equal(keywords.status, 200); assert.equal(keywords.data.keywords.length, 1);
  assert.equal(intent.status, 200); assert.equal(intent.data.results[0].status, 'graded');
  assert.equal(f.memory.rows(COLLECTIONS.ledger).every(row => row.status === 'settled'), true);
  const profile = await f.call('ai_profile', {}, f.admin);
  assert.equal(profile.data.usage.today.known_requests, 2);
  assert.equal(profile.data.usage.today.unknown_requests, 0);
  assert.equal(profile.data.usage.today.total_tokens, 300);
});
test('expected config revision rejects stale provider selection before budget or provider work', async () => {
  const f = await fixture();
  const original = (await f.call('ai_profile', {}, f.admin)).data.config.revision;
  await f.call('ai_config_save', {config: {provider: 'openai', model: 'gpt-6.1-sol', reasoning_effort: 'low'},
    api_key: OPENAI_SECRET}, f.admin);
  const stale = await f.call('intent_analyze', {...intentInput(), expected_revision: original}, f.admin);
  assert.equal(stale.status, 409); assert.equal(stale.data.code, 'AI_CONFIG_CHANGED'); assert.equal(f.calls(), 0);
  assert.equal(f.memory.rows(COLLECTIONS.ledger).length, 0);
  const current = (await f.call('ai_profile', {}, f.admin)).data.config.revision;
  assert.equal((await f.call('intent_analyze', {...intentInput(), expected_revision: current}, f.admin)).data.provider, 'openai');
});
test('OpenAI reservation blocks requests that exceed the fixed CNY daily budget', async () => {
  const f = await fixture();
  await f.call('ai_config_save', {config: {provider: 'openai', model: 'gpt-6.1-sol', reasoning_effort: 'low',
    daily_budget_cny: 0.01}, api_key: OPENAI_SECRET}, f.admin);
  const response = await f.call('intent_analyze', intentInput(), f.admin);
  assert.equal(response.status, 429); assert.equal(response.data.code, 'AI_DAILY_BUDGET');
  assert.equal(f.calls(), 0); assert.equal(f.memory.rows(COLLECTIONS.ledger).length, 0);
});
test('OpenAI usage requires cache-write data and accepts only documented model snapshots', () => {
  const response = {model: 'gpt-5.4-mini-2026-03-17', usage: {prompt_tokens: 100, completion_tokens: 20,
    prompt_tokens_details: {cached_tokens: 10, cache_write_tokens: 0}}};
  assert.equal(usageOf(response, 'gpt-5.4-mini').response_model, 'gpt-5.4-mini-2026-03-17');
  response.model = 'gpt-5.4-mini-fabricated'; assert.equal(usageOf(response, 'gpt-5.4-mini'), null);
  response.model = 'gpt-5.4-mini-2026-03-17'; delete response.usage.prompt_tokens_details.cache_write_tokens;
  assert.equal(usageOf(response, 'gpt-5.4-mini').cache_write_reported, false);
  assert.equal(usageOf(response, 'gpt-5.4-mini').prompt_cache_write_tokens, 0);
  response.model = 'gpt-6.1-sol'; assert.equal(usageOf(response, 'gpt-5.4-mini'), null);
  assert.equal(usageOf(response, 'gpt-6.1-sol'), null); // Missing confirmed standard tier.
  response.usage.prompt_tokens_details.cache_write_tokens = -1;
  assert.equal(usageOf(response, 'gpt-6.1-sol'), null);
  response.usage.prompt_tokens_details.cache_write_tokens = 101;
  assert.equal(usageOf(response, 'gpt-6.1-sol'), null);
});
test('Sol accepts official optional zero cache counters only under confirmed standard tier', () => {
  const response = {model: 'gpt-6.1-sol', service_tier: 'default', usage: {
    prompt_tokens: 19, completion_tokens: 10, total_tokens: 29,
    prompt_tokens_details: {cached_tokens: 0, audio_tokens: 0},
    completion_tokens_details: {reasoning_tokens: 0}}};
  const usage = usageOf(response, 'gpt-6.1-sol');
  assert.equal(usage.prompt_cache_write_tokens, 0);
  assert.equal(usage.prompt_cache_hit_tokens, 0);
  assert.equal(usage.prompt_cache_miss_tokens, 19);
  assert.equal(usage.cache_write_reported, false);
  delete response.usage.prompt_tokens_details;
  assert.equal(usageOf(response, 'gpt-6.1-sol').prompt_cache_miss_tokens, 19);
  response.usage.prompt_tokens_details = {cached_tokens: 1};
  assert.equal(usageOf(response, 'gpt-6.1-sol'), null);
  response.usage.prompt_tokens_details = {cache_write_tokens: 1};
  assert.equal(usageOf(response, 'gpt-6.1-sol'), null);
  response.usage.prompt_tokens_details = {cached_tokens: 0, cache_write_tokens: 0};
  response.service_tier = 'priority'; assert.equal(usageOf(response, 'gpt-6.1-sol'), null);
  response.service_tier = 'default'; response.model = 'gpt-5.4-mini';
  assert.equal(usageOf(response, 'gpt-6.1-sol'), null);
  response.model = 'gpt-6.1-sol'; response.usage.total_tokens = 30;
  assert.equal(usageOf(response, 'gpt-6.1-sol'), null);
});
test('Mini optional cache-write field can be absent and still settle a complete analysis', async () => {
  const f = await fixture({provider: async request => {
    const response = resultFor(request);
    response.model = 'gpt-5.4-mini-2026-03-17';
    response.usage.prompt_tokens_details = {cached_tokens: 0};
    response.usage.completion_tokens_details = {reasoning_tokens: 0};
    return response;
  }});
  assert.equal((await f.call('ai_config_save', {config: {provider: 'openai', model: 'gpt-5.4-mini',
    reasoning_effort: 'none'}, api_key: OPENAI_SECRET}, f.admin)).status, 200);
  const response = await f.call('intent_analyze', intentInput(), f.admin);
  assert.equal(response.status, 200); assert.equal(response.data.results[0].status, 'graded');
  assert.equal(response.data.provider, 'openai'); assert.equal(response.data.model, 'gpt-5.4-mini-2026-03-17');
  assert.equal(response.data.billing.actual_cost_cny, 0.00225);
  const ledger = f.memory.rows(COLLECTIONS.ledger)[0];
  assert.equal(ledger.status, 'settled'); assert.equal(ledger.usage.cache_write_reported, false);
  assert.equal(ledger.usage.prompt_cache_write_tokens, 0);
  assert.equal(f.memory.rows(COLLECTIONS.budget)[0].spent_micro, 2250);
});
test('an allowed but different returned OpenAI model cannot be graded under the configured price', async () => {
  const f = await fixture({provider: async request => ({...resultFor(request), model: 'gpt-6.1-sol'})});
  await f.call('ai_config_save', {config: {provider: 'openai', model: 'gpt-5.4-mini',
    reasoning_effort: 'none'}, api_key: OPENAI_SECRET}, f.admin);
  const response = await f.call('intent_analyze', intentInput(), f.admin);
  assert.equal(response.status, 502); assert.equal(response.data.code, 'AI_BILLING_UNKNOWN');
  assert.equal(response.data.results, undefined); assert.equal(response.data.configured_model, 'gpt-5.4-mini');
  assert.equal(f.memory.rows(COLLECTIONS.ledger)[0].status, 'billing_unknown');
});
test('prototype property names cannot select a model or reach either provider origin', async () => {
  const f = await fixture();
  for (const model of ['__proto__', 'constructor', 'toString']) {
    assert.equal((await f.call('ai_config_save', {config: {model}}, f.admin)).status, 400);
    assert.equal((await f.call('ai_config_save', {config: {provider: 'openai', model}, api_key: OPENAI_SECRET}, f.admin)).status, 400);
  }
  assert.equal(configuredModel({provider: 'openai', model: '__proto__', provider_models: {openai: 'constructor'}}, 'openai'), 'gpt-6.1-sol');
  assert.equal(configuredModel({provider: 'deepseek', model: 'constructor', provider_models: {deepseek: '__proto__'}}, 'deepseek'), 'deepseek-flash');
  let calls = 0;
  const transport = createProvider({fetchImpl: async () => {calls++; throw new Error('unexpected network');}});
  for (const provider of ['openai', 'deepseek']) {
    await assert.rejects(transport({provider, model: '__proto__', reasoningEffort: 'low', apiKey: SECRET}),
      e => e instanceof ProviderError && e.knownUnbilled);
  }
  assert.equal(calls, 0);
});
test('Mini none effort reports the actual documented snapshot on new and cached results', async () => {
  const f = await fixture({provider: async request => ({...resultFor(request), model: 'gpt-5.4-mini-2026-03-17'})});
  assert.equal((await f.call('ai_config_save', {config: {provider: 'openai', model: 'gpt-5.4-mini',
    reasoning_effort: 'none'}, api_key: OPENAI_SECRET}, f.admin)).status, 200);
  const first = await f.call('intent_analyze', intentInput(), f.admin);
  assert.equal(first.status, 200); assert.equal(first.data.model, 'gpt-5.4-mini-2026-03-17');
  assert.equal(first.data.configured_model, 'gpt-5.4-mini'); assert.equal(first.data.reasoning_effort, 'none');
  const cached = await f.call('intent_analyze', intentInput(), f.admin);
  assert.equal(cached.data.cache_hit, true); assert.equal(cached.data.model, first.data.model);
  assert.equal(cached.data.configured_model, 'gpt-5.4-mini');
});
test('OpenAI transport uses only the fixed official origin and normalizes insufficient quota without retry', async () => {
  let seen, calls = 0;
  const transport = createProvider({fetchImpl: async (url, options) => {seen = {url, options}; calls++;
    return {ok: false, status: 429, json: async () => ({error: {code: 'insufficient_quota', message: OPENAI_SECRET}})};}});
  await assert.rejects(transport({provider: 'openai', apiKey: OPENAI_SECRET, model: 'gpt-6.1-sol', reasoningEffort: 'low',
    messages: [{role: 'system', content: 'JSON only'}], maxTokens: 2048, tenantId: hash('company')}),
  error => error instanceof ProviderError && error.code === 'AI_PROVIDER_BALANCE' && error.knownUnbilled && !error.retryable);
  assert.equal(seen.url, 'https://api.openai.com/v1/chat/completions'); assert.equal(seen.options.redirect, 'error');
  const body = JSON.parse(seen.options.body);
  assert.equal(body.model, 'gpt-6.1-sol'); assert.equal(body.service_tier, 'default');
  assert.deepEqual(body.prompt_cache_options, {mode: 'explicit'});
  assert.equal(body.reasoning_effort, 'low'); assert.equal(body.max_completion_tokens, 2048);
  assert.equal(body.temperature, undefined); assert.equal(body.tools, undefined);
  assert.equal(seen.options.body.includes(OPENAI_SECRET), false); assert.equal(calls, 1);
});
test('staff profile and analysis omit financial and token details while admin sees daily and cumulative usage', async () => {
  const f = await fixture();
  await f.call('member_save', {username: 'staff', password: '[REDACTED:assigned_secret]', role: 'operator'}, f.admin);
  const staff = (await f.call('login', {username: 'staff', password: '[REDACTED:assigned_secret]'})).data.token;
  const profile = await f.call('ai_profile', {}, staff);
  assert.equal(profile.status, 200);
  for (const key of ['budget', 'usage']) assert.equal(Object.hasOwn(profile.data, key), false);
  for (const key of ['daily_budget_cny', 'usd_cny_rate', 'price_source', 'price_version'])
    assert.equal(Object.hasOwn(profile.data.config, key), false);
  assert.equal(Object.hasOwn(profile.data.config, 'last_save_id'), false);
  const first = await f.call('intent_analyze', intentInput('c1'), staff);
  assert.equal(first.status, 200); assert.equal(first.data.results[0].status, 'graded');
  assert.equal(Object.hasOwn(first.data, 'billing'), false);
  const cached = await f.call('intent_analyze', intentInput('c1'), staff);
  assert.equal(cached.data.cache_hit, true); assert.equal(Object.hasOwn(cached.data, 'budget'), false);
  assert.equal(Object.hasOwn(cached.data, 'billing'), false);
  const second = await f.call('intent_analyze', intentInput('c2'), staff);
  assert.equal(second.status, 200);
  const admin = await f.call('ai_profile', {}, f.admin);
  assert.equal(admin.data.usage.today.known_requests, 2);
  assert.equal(admin.data.usage.today.prompt_tokens, 200);
  assert.equal(admin.data.usage.today.completion_tokens, 100);
  assert.equal(admin.data.usage.cumulative.total_tokens, 300);
  assert.equal(admin.data.usage.today.confirmed_cost_cny > 0, true);
  assert.equal(admin.data.usage.cumulative.confirmed_cost_cny, admin.data.usage.today.confirmed_cost_cny);
  assert.equal(admin.data.usage.today.has_unknown_billing, false);
  assert.equal(admin.data.usage.coverage, 'since_tracking_start');
  assert.equal(f.memory.rows(COLLECTIONS.ledger).length, 2);
});
test('save receipt and revision show a lost success without replaying a write', async () => {
  const f = await fixture();
  const original = (await f.call('ai_config_read', {}, f.admin)).data.config;
  const requestId = '18bc6734-126c-4811-9f34-917b5c9ad0e1';
  const saved = await f.call('ai_config_save', {request_id: requestId, expected_revision: original.revision,
    config: {model: 'deepseek-v4-pro', daily_budget_cny: 4}}, f.admin);
  assert.equal(saved.status, 200);
  const read = await f.call('ai_config_read', {}, f.admin);
  assert.equal(read.data.config.last_save_id, requestId);
  assert.equal(read.data.config.revision, original.revision + 1);
  assert.equal(read.data.config.model, 'deepseek-v4-pro');
  assert.equal(read.data.config.daily_budget_cny, 4);
  assert.equal((await f.call('ai_config_save', {request_id: requestId, expected_revision: original.revision,
    config: {model: 'deepseek-v4-pro', daily_budget_cny: 4}}, f.admin)).status, 409);
  assert.equal((await f.call('ai_config_read', {}, f.admin)).data.config.revision, original.revision + 1);
});
test('concurrent saves from the same revision commit once; invalid receipt writes nothing', async () => {
  const f = await fixture();
  const revision = (await f.call('ai_config_read', {}, f.admin)).data.config.revision;
  const bad = await f.call('ai_config_save', {request_id: 'not-a-uuid', expected_revision: revision,
    config: {daily_budget_cny: 3}}, f.admin);
  assert.equal(bad.status, 400);
  const [a, b] = await Promise.all([
    f.call('ai_config_save', {request_id: 'c568419f-cdb2-41aa-8b30-24d82671a391', expected_revision: revision,
      config: {daily_budget_cny: 3}}, f.admin),
    f.call('ai_config_save', {request_id: '2af51932-1c76-4f3a-a89a-0bc43e8506f7', expected_revision: revision,
      config: {daily_budget_cny: 4}}, f.admin)
  ]);
  assert.deepEqual([a.status, b.status].sort(), [200, 409]);
  const current = (await f.call('ai_config_read', {}, f.admin)).data.config;
  assert.equal(current.revision, revision + 1);
  assert.equal(current.daily_budget_cny, a.status === 200 ? 3 : 4);
  assert.equal(current.last_save_id, a.status === 200 ? 'c568419f-cdb2-41aa-8b30-24d82671a391' : '2af51932-1c76-4f3a-a89a-0bc43e8506f7');
});
test('returned priority tier is held as unknown billing and cannot become a successful analysis', async () => {
  const f = await fixture({provider: async request => ({...resultFor(request), service_tier: 'priority'})});
  await f.call('ai_config_save', {config: {provider: 'openai', model: 'gpt-6.1-sol', reasoning_effort: 'low'},
    api_key: OPENAI_SECRET}, f.admin);
  const response = await f.call('intent_analyze', intentInput(), f.admin);
  assert.equal(response.status, 502); assert.equal(response.data.code, 'AI_BILLING_UNKNOWN');
  assert.equal(response.data.results, undefined);
  assert.equal(f.memory.rows(COLLECTIONS.ledger)[0].status, 'billing_unknown');
  assert.equal(f.memory.rows(COLLECTIONS.budget)[0].reserved_micro > 0, true);
  const profile = await f.call('ai_profile', {}, f.admin);
  assert.equal(profile.data.usage.today.unknown_requests, 1);
  assert.equal(profile.data.usage.today.total_tokens, 0);
  assert.equal(profile.data.usage.today.has_unknown_billing, true);
});
test('a damaged saved model is rejected before provider work instead of silently selecting another model', async () => {
  const f = await fixture();
  await f.call('ai_config_save', {config: {provider: 'openai', model: 'gpt-5.4-mini', reasoning_effort: 'none'},
    api_key: OPENAI_SECRET}, f.admin);
  f.memory.state('fangyu-apartment-client').enterpriseAi.model = 'gpt-6.1-sol-unknown';
  const response = await f.call('intent_analyze', intentInput(), f.admin);
  assert.equal(response.status, 503); assert.equal(response.data.code, 'AI_UNPRICED_MODEL');
  assert.equal(f.calls(), 0); assert.equal(f.memory.rows(COLLECTIONS.ledger).length, 0);
});
test('keyword default 50, explicit 100, grounded city and grouped recommendation contract; >100 never calls provider', async () => {
  const f = await fixture();
  const first = await f.call('keyword_suggest', {city: '杭州', seeds: ['公寓','租房']}, f.admin);
  assert.equal(first.status, 200); assert.equal(first.data.keywords.length, 50);
  assert.equal(first.data.keywords.every(k => k.keyword.includes('杭州') && k.group && k.reason && typeof k.recommended === 'boolean'), true);
  assert.equal((await f.call('keyword_suggest', {city: '杭州', count: 100}, f.admin)).data.keywords.length, 100);
  assert.equal((await f.call('keyword_suggest', {city: '杭州', count: 101}, f.admin)).status, 400);
  assert.equal(f.calls(), 2);
});
test('one complete demand sentence yields reviewable search phrases without filter fragments', async () => {
  const f = await fixture();
  const result = await f.call('keyword_suggest', {city:'上海', seeds:['古北租房'], count:50}, f.admin);
  assert.equal(result.status,200);assert.equal(result.data.keywords.length,50);
  assert.equal(result.data.keywords.every(row=>row.keyword.includes('上海') && /(租|公寓|找房|居室)/.test(row.keyword)),true);
  const input=normalizeInput('keyword_suggest',{city:'上海',seeds:['古北租房'],count:2});
  const out={keywords:[{keyword:'整租',group:'需求',recommended:true,reason:'筛选碎片'},
    {keyword:'上海有电梯',group:'需求',recommended:false,reason:'筛选碎片'}]};
  assert.throws(()=>validateOutput('keyword_suggest',out,input));
  assert.match(prompt('keyword_suggest',input,defaults())[0].content,/完整可搜索短语/);
});
test('actual cache hit/miss/completion usage and versioned peak/off-peak tariffs settle reserve exactly', async () => {
  const f = await fixture();
  const response = await f.call('intent_analyze', intentInput(), f.admin);
  assert.equal(response.status, 200); assert.equal(response.data.billing.actual_cost_cny, 0.000561);
  const [ledger] = f.memory.rows(COLLECTIONS.ledger);
  assert.deepEqual(ledger.usage, {prompt_tokens:100,prompt_cache_hit_tokens:20,prompt_cache_miss_tokens:80,completion_tokens:50});
  assert.equal(ledger.price_version, PRICE_VERSION); assert.equal(ledger.model, 'deepseek-flash');
  assert.equal(ledger.status, 'settled'); assert.equal(ledger.price_window, 'peak');
  const [budget] = f.memory.rows(COLLECTIONS.budget);
  assert.equal(budget.reserved_micro, 0); assert.equal(budget.spent_micro, 561);
  assert.equal(tariff('deepseek-flash', NOW + 3 * 3600000).output, 4); // 13:00 off-peak.
  assert.equal(tariff('deepseek-flash', Date.UTC(2026,8,26,2)).output, 4); // Saturday.
});
test('unknown markAttempt DB failure pauses before provider call and hides SDK error', async () => {
  const f = await fixture();
  f.memory.rejectWriteWhen((name, value) => name === COLLECTIONS.ledger && value.status === 'reserved' && value.attempts.length === 1);
  const response = await f.call('intent_analyze', intentInput(), f.admin);
  assert.equal(response.status, 503);
  assert.equal(response.data.code, 'AI_LEDGER_CONFLICT');
  assert.equal(f.calls(), 0);
  assert.equal(JSON.stringify(response).includes(SECRET), false);
  assert.equal(JSON.stringify(response).includes('unsafe SDK write failure'), false);
  assert.equal(f.memory.rows(COLLECTIONS.ledger)[0].attempts.length, 0);
});
test('unknown settlement DB failure pauses after one provider call and hides SDK error', async () => {
  const f = await fixture();
  f.memory.rejectWriteWhen((name, value) => name === COLLECTIONS.ledger && value.status === 'settled');
  const response = await f.call('intent_analyze', intentInput(), f.admin);
  assert.equal(response.status, 503);
  assert.equal(response.data.code, 'AI_LEDGER_CONFLICT');
  assert.equal(f.calls(), 1);
  assert.equal(JSON.stringify(response).includes(SECRET), false);
  assert.equal(JSON.stringify(response).includes('unsafe SDK write failure'), false);
  assert.equal(f.memory.rows(COLLECTIONS.ledger)[0].status, 'reserved');
});
test('cross-machine simultaneous requests cannot overspend daily enterprise budget', async () => {
  let release; const pending = new Promise(resolve => {release = resolve;});
  const memory = memoryDb();
  const f = await fixture({shared: memory, budget: 0.02, provider: async req => {await pending; return resultFor(req);}});
  // Distinct service instance, same company and DB, represents another machine/request worker.
  const second = createService({store: createStore(memory.db, 'fangyu-apartment-client'), environmentId: 'ai-test-env', companyId:'fangyu-apartment-client',
    clock: () => NOW, aiProvider: async req => {await pending; return resultFor(req);}});
  const calls = Array.from({length: 12}, (_, i) => (i % 2 ? second({environment_id:'ai-test-env',operation:'intent_analyze',...intentInput(`parallel-${i}`)}, f.admin)
    : f.call('intent_analyze', intentInput(`parallel-${i}`), f.admin)));
  // Flush transaction queue without waiting for intentionally held provider calls.
  await new Promise(resolve => setTimeout(resolve, 100));
  const during = (await f.call('ai_config_read', {}, f.admin)).data.budget;
  assert.ok(during.reserved_cny <= 0.02); assert.ok(during.reserved_cny > 0);
  release(); const results = await Promise.all(calls);
  assert.equal(results.filter(r => r.status === 200).length, 1);
  assert.equal(results.filter(r => r.data.code === 'AI_DAILY_BUDGET').length, 11);
  assert.equal(memory.rows(COLLECTIONS.ledger).length, 1);
});
test('same input is coalesced while in flight, then cached; tenant and model/rule configuration isolation', async () => {
  let release; const pending = new Promise(resolve => {release = resolve;});
  const shared = memoryDb();
  const f = await fixture({shared, provider: async req => {await pending; return resultFor(req);}});
  const first = f.call('intent_analyze', intentInput(), f.admin);
  await new Promise(resolve => setTimeout(resolve, 30));
  const duplicate = await f.call('intent_analyze', intentInput(), f.admin);
  assert.equal(duplicate.status, 409); assert.equal(duplicate.data.ai_status, 'pending');
  release(); assert.equal((await first).status, 200);
  const cached = await f.call('intent_analyze', intentInput(), f.admin);
  assert.equal(cached.data.cache_hit, true); assert.equal(cached.data.billing.actual_cost_cny, 0); assert.equal(f.calls(), 1);
  const tenant2 = await fixture({shared, company: 'another-company'});
  assert.equal((await tenant2.call('intent_analyze', intentInput(), tenant2.admin)).data.cache_hit, false);
  assert.equal(tenant2.calls(), 1);
  await f.call('ai_config_save', {config: {rules_version: 'custom-rules-v2'}}, f.admin);
  assert.equal((await f.call('intent_analyze', intentInput(), f.admin)).data.cache_hit, false); assert.equal(f.calls(), 2);
  await f.call('ai_config_save', {config: {model:'deepseek-v4-pro'}}, f.admin);
  assert.equal((await f.call('intent_analyze', intentInput(), f.admin)).data.model, 'deepseek-v4-pro'); assert.equal(f.calls(), 3);
});
test('known unbilled 429 retries at most twice and releases; unknown failures never retry or grade and retain reserve', async () => {
  for (const [error, attempts, status] of [
    [new ProviderError('AI_PROVIDER_REJECTED', {knownUnbilled:true,retryable:true,httpStatus:429}),2,'unbilled'],
    [new ProviderError('AI_PROVIDER_REJECTED', {knownUnbilled:true,httpStatus:401}),1,'unbilled'],
    [new ProviderError('AI_PROVIDER_TIMEOUT'),1,'billing_unknown'],
    [new Error(`unsafe provider error ${SECRET}`),1,'billing_unknown']
  ]) {
    const f = await fixture({provider: async () => {throw error;}});
    const response = await f.call('intent_analyze', intentInput(), f.admin);
    assert.equal(response.status, 502); assert.equal(response.data.ai_status, 'pending'); assert.equal(response.data.results, undefined);
    assert.equal(f.calls(), attempts); assert.equal(JSON.stringify(response).includes(SECRET), false);
    const [ledger] = f.memory.rows(COLLECTIONS.ledger), [budget] = f.memory.rows(COLLECTIONS.budget);
    assert.equal(ledger.status, status); assert.equal(ledger.attempts.length, attempts);
    assert.equal(budget.reserved_micro > 0, status === 'billing_unknown');
  }
});
test('DeepSeek 402 balance and 401 key failures are fixed, unbilled, and never retried', async () => {
  for (const [httpStatus, code, message] of [
    [402, 'AI_PROVIDER_BALANCE', '余额不足'],
    [401, 'AI_PROVIDER_AUTH', '密钥无效']
  ]) {
    const transport = createProvider({fetchImpl: async () => ({ok:false, status:httpStatus,
      text: async () => {throw new Error(`provider body ${SECRET}`);}})});
    const f = await fixture({provider: transport});
    const response = await f.call('intent_analyze', intentInput(), f.admin);
    assert.equal(response.status, 502); assert.equal(response.data.code, code);
    assert.match(response.data.error, new RegExp(message));
    assert.equal(JSON.stringify(response).includes(SECRET), false);
    assert.equal(JSON.stringify(response).includes('provider body'), false);
    assert.equal(f.calls(), 1);
    const [ledger] = f.memory.rows(COLLECTIONS.ledger), [budget] = f.memory.rows(COLLECTIONS.budget);
    assert.equal(ledger.status, 'unbilled'); assert.equal(ledger.error_code, code);
    assert.equal(ledger.attempts.length, 1); assert.equal(ledger.reservation_retained, false);
    assert.equal(budget.reserved_micro, 0); assert.equal(budget.spent_micro, 0);
  }
});
test('invalid, truncated, invented evidence, wrong IDs/levels and missing usage never become grades; known usage still billed', async () => {
  const mutations = [
    r => {r.choices[0].message.content = '';},
    r => {r.choices[0].finish_reason = 'length';},
    r => {const out=JSON.parse(r.choices[0].message.content);out.results[0].evidence=['并不存在的逐字证据'];r.choices[0].message.content=JSON.stringify(out);},
    r => {const out=JSON.parse(r.choices[0].message.content);out.results[0].id='invented';r.choices[0].message.content=JSON.stringify(out);},
    r => {const out=JSON.parse(r.choices[0].message.content);out.results[0].level='A';r.choices[0].message.content=JSON.stringify(out);},
    r => {const out=JSON.parse(r.choices[0].message.content);out.results[0].reason=SECRET;r.choices[0].message.content=JSON.stringify(out);},
    r => {delete r.usage;},
    r => {r.usage.prompt_cache_hit_tokens=999;},
    r => {r.model='unknown-price-model';}
  ];
  for (let i=0;i<mutations.length;i++) {
    const f = await fixture({provider: async req => {const r=resultFor(req);mutations[i](r);return r;}});
    const response = await f.call('intent_analyze', intentInput(), f.admin);
    assert.equal(response.status, 502); assert.equal(response.data.ai_status,'pending'); assert.equal(response.data.results,undefined);
    assert.equal(f.calls(),1); assert.equal(JSON.stringify(response).includes(SECRET),false);
    const [ledger]=f.memory.rows(COLLECTIONS.ledger);
    assert.equal(ledger.status, i<6 ? 'invalid_output' : 'billing_unknown');
    if(i<6) assert.equal(ledger.actual_cost_micro,561);
  }
});
test('all five grades are distinct; uncertain/unrelated are outside grades; strict IDs and source evidence', () => {
  const input = normalizeInput('intent_analyze', {...intentInput(),comments: Array.from({length:7}, (_,i)=>({id:`c${i}`,text:'本人想租杭州公寓'}))});
  const levels=['super_high','high','medium','low','very_low'];
  const result={results: input.comments.map((c,i)=>({id:c.id,status:i<5?'graded':i===5?'uncertain':'unrelated',level:i<5?levels[i]:null,
    evidence:i<5?['想租杭州公寓']:[],reason:'源文本说明',region_status:'matched',content_region:'杭州',
    key_info:i<5?[{type:'room_type',value:'公寓',evidence:'杭州公寓'}]:[]}))};
  assert.equal(validateOutput('intent_analyze',result,input),result);
  result.results[5].level='very_low'; assert.throws(()=>validateOutput('intent_analyze',result,input));
});
test('structured rental facts require exact evidence in the same comment', () => {
  const input=normalizeInput('intent_analyze',intentInput());
  const base={results:[{id:'c1',status:'graded',level:'high',evidence:['下个月想租'],reason:'本人求租',
    region_status:'unknown',content_region:'',key_info:[{type:'move_in',value:'下个月',evidence:'下个月想租'}]}]};
  assert.equal(validateOutput('intent_analyze',base,input),base);
  for(const fact of [
    {type:'budget',value:'5000元',evidence:'预算5000元'},
    {type:'move_in',value:'明天',evidence:'下个月想租'},
    {type:'other',value:'下个月',evidence:'下个月想租'},
    {type:'move_in',value:'下个月',evidence:'租房避坑经验'}]) {
    const bad=structuredClone(base);bad.results[0].key_info=[fact];assert.throws(()=>validateOutput('intent_analyze',bad,input));
  }
  const unrelated=structuredClone(base);unrelated.results[0].status='unrelated';unrelated.results[0].level=null;
  assert.throws(()=>validateOutput('intent_analyze',unrelated,input));
});
test('fabricated key info is billed as invalid output and never becomes a grade or cache hit', async () => {
  const f=await fixture({provider:async req=>{const response=resultFor(req),out=JSON.parse(response.choices[0].message.content);
    out.results[0].key_info=[{type:'budget',value:'5000元',evidence:'预算5000元'}];
    response.choices[0].message.content=JSON.stringify(out);return response;}});
  const first=await f.call('intent_analyze',intentInput(),f.admin);
  assert.equal(first.status,502);assert.equal(first.data.ai_status,'pending');assert.equal(first.data.results,undefined);
  assert.equal(f.memory.rows(COLLECTIONS.ledger)[0].status,'invalid_output');
  assert.equal(f.memory.rows(COLLECTIONS.cache)[0].status,'failed');
});
test('invalid foreign-city keyword or duplicate response is rejected and never cached', async () => {
  for(const invalid of ['foreign','duplicate']) {
    const f=await fixture({provider:async req=>{const response=resultFor(req),out=JSON.parse(response.choices[0].message.content);
      out.keywords[0].keyword=invalid==='foreign'?'北京租房求助':out.keywords[1].keyword;
      response.choices[0].message.content=JSON.stringify(out);return response;}});
    assert.equal((await f.call('keyword_suggest',{city:'杭州',count:2},f.admin)).status,502);
    assert.equal(f.memory.rows(COLLECTIONS.cache)[0].status,'failed');
  }
});
test('daily timezone reset does not free previous unknown reservation; current day has fresh budget', async () => {
  let now=Date.UTC(2026,8,29,15,59);
  const f=await fixture({now:()=>now,provider:async()=>{throw new ProviderError('AI_PROVIDER_TIMEOUT');}});
  await f.call('intent_analyze',intentInput(),f.admin);
  now+=120000;
  const profile=await f.call('ai_profile',{},f.admin);
  assert.equal(profile.data.budget.day,'2026-09-30');assert.equal(profile.data.budget.reserved_cny,0);
  const prior=f.memory.rows(COLLECTIONS.budget)[0];assert.equal(prior.day,'2026-09-29');assert.ok(prior.reserved_micro>0);
});
test('revocation during request suppresses response but still settles measured usage', async () => {
  let release;const wait=new Promise(resolve=>{release=resolve;});
  const f=await fixture({provider:async req=>{await wait;return resultFor(req);}});
  const call=f.call('intent_analyze',intentInput(),f.admin);
  await new Promise(resolve=>setTimeout(resolve,30));await f.call('logout',{},f.admin);release();
  const response=await call;assert.equal(response.status,401);assert.equal(response.data.results,undefined);
  assert.equal(f.memory.rows(COLLECTIONS.ledger)[0].status,'settled');
});
test('DeepSeek fixed-origin transport disables thinking, requests JSON and tenant cache isolation, sanitizes errors', async () => {
  let captured;
  const provider=createProvider({fetchImpl:async(url,options)=>{captured={url,options};return {ok:true,json:async()=>({ok:true})};}});
  await provider({apiKey:SECRET,model:'deepseek-flash',messages:[{role:'system',content:'JSON schema'}],maxTokens:2048,tenantId:hash('company')});
  assert.equal(captured.url,'https://api.deepseek.com/chat/completions');assert.equal(captured.options.redirect,'error');
  const body=JSON.parse(captured.options.body);assert.deepEqual(body.thinking,{type:'disabled'});assert.deepEqual(body.response_format,{type:'json_object'});
  assert.equal(body.user_id,hash('company'));assert.equal(captured.options.body.includes(SECRET),false);
  const rejected=createProvider({fetchImpl:async()=>({ok:false,status:500,text:async()=>SECRET})});
  await assert.rejects(rejected({apiKey:SECRET,model:'deepseek-flash'}),e=>e instanceof ProviderError&&!e.knownUnbilled&&!e.message.includes(SECRET));
});
test('pricing reservation is pessimistic about cache and time window; unknown model cannot be saved', async () => {
  const input=normalizeInput('keyword_suggest',{city:'杭州'}),config=defaults();
  const reserve=reservationMicro(prompt('keyword_suggest',input,config),6400,'deepseek-flash');
  assert.ok(reserve.micro>=6400*8); assert.ok(reserve.prompt_bound>Buffer.byteLength(JSON.stringify(input)));
  const f=await fixture();assert.equal((await f.call('ai_config_save',{config:{model:'custom-unpriced'}},f.admin)).status,400);
});
test('429 retry consumes the same 45-second deadline including reservation and retry wait', async () => {
  const f = await fixture(); let elapsed = 0, calls = 0; const timeouts = [];
  const baseStore = createStore(f.memory.db, 'fangyu-apartment-client');
  const store = {transaction: async callback => {elapsed += 100; return baseStore.transaction(callback);}};
  const ai = createEnterpriseAi({store, companyId: 'fangyu-apartment-client', clock: () => NOW,
    deadlineClock: () => elapsed, retryDelay: async ms => {elapsed += ms;}, provider: async request => {
      calls++; timeouts.push(request.timeoutMs); assert.equal(f.memory.inTransaction(), false);
      if (calls === 1) {elapsed += 30000; throw new ProviderError('AI_PROVIDER_REJECTED', {knownUnbilled:true,retryable:true,httpStatus:429});}
      return resultFor(request);
    }});
  const identity = {username: 'admin', sessionDigest: f.memory.state('fangyu-apartment-client').sessions[0].digest};
  const response = await ai.handle({operation: 'intent_analyze', ...intentInput()}, identity);
  assert.equal(response.status, 200); assert.deepEqual(timeouts, [44800, 14450]);
  assert.equal(f.memory.rows(COLLECTIONS.ledger)[0].attempts.length, 2);
});
test('deadline exhaustion after known unbilled 429 suppresses retry and releases budget', async () => {
  const f = await fixture(); let elapsed = 0, calls = 0, waits = 0;
  const ai = createEnterpriseAi({store: createStore(f.memory.db, 'fangyu-apartment-client'), companyId: 'fangyu-apartment-client', clock: () => NOW,
    deadlineClock: () => elapsed, retryDelay: async () => {waits++;}, provider: async request => {
      calls++; assert.equal(request.timeoutMs, 45000); elapsed = 44900;
      throw new ProviderError('AI_PROVIDER_REJECTED', {knownUnbilled:true,retryable:true,httpStatus:429});
    }});
  const response = await ai.handle({operation: 'intent_analyze', ...intentInput()},
    {username: 'admin', sessionDigest: f.memory.state('fangyu-apartment-client').sessions[0].digest});
  assert.equal(response.status, 502); assert.equal(response.data.code, 'AI_PROVIDER_TIMEOUT');
  assert.equal(calls, 1); assert.equal(waits, 0); assert.equal(response.data.billing.status, 'unbilled');
  assert.equal(f.memory.rows(COLLECTIONS.budget)[0].reserved_micro, 0);
});
test('reservation or retry delay exhausting deadline prevents another HTTP attempt', async () => {
  for (const phase of ['reserve', 'backoff']) {
    const f = await fixture(); let elapsed = 0, calls = 0;
    const baseStore = createStore(f.memory.db, 'fangyu-apartment-client');
    const store = {transaction: async callback => {const result = await baseStore.transaction(callback); if (phase === 'reserve') elapsed = 45000; return result;}};
    const ai = createEnterpriseAi({store, companyId: 'fangyu-apartment-client', clock: () => NOW,
      deadlineClock: () => elapsed, retryDelay: async () => {elapsed = 45000;}, provider: async () => {
        calls++; throw new ProviderError('AI_PROVIDER_REJECTED', {knownUnbilled:true,retryable:true,httpStatus:429});
      }});
    const response = await ai.handle({operation: 'intent_analyze', ...intentInput()},
      {username: 'admin', sessionDigest: f.memory.state('fangyu-apartment-client').sessions[0].digest});
    assert.equal(response.status, 502); assert.equal(response.data.billing.status, 'unbilled');
    assert.equal(calls, phase === 'reserve' ? 0 : 1);
    assert.equal(f.memory.rows(COLLECTIONS.budget)[0].reserved_micro, 0);
  }
});
test('provider enforces supplied remaining timeout and never fetches after zero deadline', async () => {
  let calls = 0;
  const provider = createProvider({fetchImpl: async (_url, {signal}) => {
    calls++; return new Promise((_resolve, reject) => signal.addEventListener('abort', () => reject(new Error('fixture abort')), {once:true}));
  }});
  await assert.rejects(provider({apiKey:SECRET, model:'deepseek-flash', timeoutMs:10}), e => e.code === 'AI_PROVIDER_TIMEOUT' && !e.knownUnbilled);
  await assert.rejects(provider({apiKey:SECRET, model:'deepseek-flash', timeoutMs:0}), e => e.code === 'AI_PROVIDER_TIMEOUT' && e.knownUnbilled);
  assert.equal(calls, 1);
});
test('disabled enterprise AI returns explicit not-configured status without provider or ledger attempt', async () => {
  const f = await fixture();
  assert.equal((await f.call('ai_config_save', {config:{enabled:false}}, f.admin)).status, 200);
  const profile = await f.call('ai_profile', {}, f.admin);
  assert.equal(profile.data.config.enabled, false); assert.equal(profile.data.config.daily_budget_cny, 5);
  const response = await f.call('intent_analyze', intentInput(), f.admin);
  assert.equal(response.status, 503); assert.equal(response.data.code, 'AI_NOT_CONFIGURED');
  assert.equal(f.calls(), 0); assert.equal(f.memory.rows(COLLECTIONS.ledger).length, 0);
});
