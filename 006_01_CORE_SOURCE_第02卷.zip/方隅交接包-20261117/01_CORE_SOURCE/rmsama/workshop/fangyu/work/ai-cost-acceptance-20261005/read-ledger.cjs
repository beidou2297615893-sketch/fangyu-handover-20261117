// Read-only accounting diagnostics. Never return configuration, keys or prompts.
const fs=require('node:fs'),path=require('node:path');
const project=path.resolve(__dirname,'../..');
async function main(){
 const {getCredentialWithoutCheck}=require(path.join(project,'work/cloud-tools/node_modules/@cloudbase/toolbox'));
 const sdk=require(path.join(project,'work/cloud/workspace/node_modules/@cloudbase/node-sdk'));
 const c=await getCredentialWithoutCheck();
 const db=sdk.init({env:'fh6-d5ga45c0ddae7008c',secretId:c.secretId,secretKey:c.secretKey,sessionToken:c.token}).database();
 const r=await db.collection('fangyu_ai_ledger').where({companyId:'fangyu-apartment-client',day:'2026-10-05'}).limit(100).get();
 if(r.code||!Array.isArray(r.data))throw Error('ledger_unavailable');
 const keys=['request_id','operation','created_at','completed_at','model','max_tokens','status','usage','actual_cost_micro','price_window','price_version','price_per_million','error_code','reservation_retained'];
 const safe=r.data.map(row=>Object.fromEntries(keys.map(k=>[k,row[k]])));
 fs.writeFileSync(path.join(__dirname,'ledger-read-only.json'),JSON.stringify(safe,null,2));
 console.log(JSON.stringify(safe));
}
main().catch(()=>{console.error('read_only_diagnostic_failed');process.exitCode=1;});
