"""Two bounded paid samples through the existing authenticated cloud AI service.
No XHS request, lead insertion, supplier secret read or automatic retry.
"""
from pathlib import Path
import importlib.util,json,uuid,sys

here=Path(__file__).resolve().parent
root=here.parents[1]
def record(name,data):
    (here/(name+'.json')).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n','utf-8')
def emit(data):print(json.dumps(data,ensure_ascii=False),flush=True)
spec=importlib.util.spec_from_file_location('existing_owner',root/'work/owner-admin-20261004/owner_admin.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
owner=m.Owner()

def profile():
    user=owner.user()
    with owner.integrations.lock:connection=owner.integrations._read(user['tenant_id'])
    result=owner.integrations._cloud(connection,user,'ai_profile')
    config=result.get('config') or {}
    if config.get('provider')!='deepseek' or config.get('model')!='deepseek-flash' or not config.get('enabled') or not config.get('configured'):
        raise ValueError('configured_flash_required')
    return user,connection,config,result

def sample(name,operation,payload,user,connection,config):
    marker=here/(name+'-attempt.json')
    if marker.exists():raise ValueError('already_attempted_no_automatic_replay')
    data={**payload,'expected_revision':config['revision'],'request_id':str(uuid.uuid4())}
    with marker.open('x',encoding='utf-8') as f:
        json.dump({'operation':operation,'payload':data,'model':'deepseek-flash','max_calls':1,'automatic_replay':False,'platform_requests':0,'synthetic_leads_inserted':0},f,ensure_ascii=False)
    emit({'stage':name,'status':'submitted','max_provider_attempts':1})
    try:
        result=owner.integrations._cloud(connection,user,operation,**data)
    except Exception as error:
        report={'succeeded':False,'safe_code':getattr(error,'code','AI_CALL_UNCONFIRMED'),'http_status':getattr(error,'http_status',None),'automatic_replay':False}
        record(name+'-result',report);emit({'stage':name,**report});raise
    report={k:result.get(k) for k in ('provider','model','configured_model','cache_hit','source','billing','keywords','results','rules_version')}
    report['succeeded']=True
    record(name+'-result',report)
    emit({'stage':name,'succeeded':True,'count':len(result.get('keywords') or result.get('results') or []),'cache_hit':result.get('cache_hit'),'billing':result.get('billing')})
    return result

try:
    user,connection,config,before=profile()
    record('profile-before',{'config':{k:config.get(k) for k in ('provider','model','enabled','configured','revision')},'usage':before.get('usage'),'budget':before.get('budget')})
    emit({'stage':'preflight','configured':True,'model':config['model'],'paid_calls_planned':2,'platform_requests':0})
    if (here/'keyword-attempt.json').exists():raise ValueError('run_already_attempted_no_automatic_replay')
    keyword=sample('keyword','keyword_suggest',{'city':'上海','area':'古北','seeds':['古北租房'],'count':50},user,connection,config)
    if len(keyword.get('keywords') or [])!=50:raise ValueError('keyword_count_not_verified')
    intent=sample('intent','intent_analyze',{'city':'上海','area':'古北','post':{'id':'synthetic-cost-acceptance-20261005','title':'上海古北租房交流（合成验收样本，不是真实帖子）','author':'合成验收'},'comments':[
        {'id':'urgent-demand','text':'下周搬到上海古北，想租一居室，预算3500，周末可以看房，有合适的房源吗？','ip_location':'上海'},
        {'id':'semantic-demand','text':'下个月来上海工作，月预算4000，想住九号线附近，周末可以看，有推荐吗？','ip_location':'上海'},
        {'id':'unrelated-complaint','text':'这家店服务不好，我投诉了，希望商家改进。','ip_location':'上海'},
        {'id':'other-city','text':'我在北京望京找两居室，预算6000，下个月入住。','ip_location':'上海'}
    ]},user,connection,config)
    rows={r['id']:r for r in intent.get('results') or []}
    quality={
       'all_four_returned':len(rows)==4,
       'urgent_prioritized':rows.get('urgent-demand',{}).get('level') in ('high','super_high'),
       'semantic_preserved':rows.get('semantic-demand',{}).get('status')=='graded',
       'complaint_not_high':rows.get('unrelated-complaint',{}).get('level') not in ('high','super_high'),
       'other_city_distinguished':rows.get('other-city',{}).get('region_status')=='other',
    }
    record('quality',quality)
    after=owner.integrations._cloud(connection,user,'ai_profile')
    record('profile-after',{'usage':after.get('usage'),'budget':after.get('budget')})
    billings=[x.get('billing') or {} for x in (keyword,intent)]
    report={'succeeded':True,'model':config['model'],'paid_samples':2,'actual_cost_cny':sum(b.get('actual_cost_cny') or 0 for b in billings),'cost_confirmed':all(isinstance(b.get('actual_cost_cny'),(int,float)) for b in billings),'quality':quality,'platform_requests':0,'production_comment_writes':0,'automatic_replay':False}
    record('summary',report);emit(report)
except Exception as error:
    emit({'stopped':True,'safe_code':getattr(error,'code','AI_ACCEPTANCE_UNCONFIRMED'),'error_type':type(error).__name__,'automatic_replay':False})
    sys.exit(1)
