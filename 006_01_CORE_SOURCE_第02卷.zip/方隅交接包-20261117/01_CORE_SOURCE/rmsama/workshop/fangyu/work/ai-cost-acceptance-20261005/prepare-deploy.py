from pathlib import Path
here=Path(__file__).resolve().parent
source=(here.parent/'ai-connectivity-repair-20261005/deploy.cjs').read_text('utf-8')
source=source.replace("../ai-workflow-repair-20261005/deployment.json","../ai-connectivity-repair-20261005/deployment.json")
source=source.replace("path.join(__dirname,'../ai-workflow-repair-20261005/stage')","path.join(__dirname,'stage')")
source=source.replace("const allowed=['ai_enterprise.cjs','ai_provider.cjs','site/enterprise-ui.mjs'];","const allowed=['ai_enterprise.cjs','ai_contract.cjs'];")
with (here/'deploy.cjs').open('x',encoding='utf-8') as f:f.write(source)
