"""One bounded synthetic diagnostic; capture safe cloud validation reason, not provider secrets."""
from pathlib import Path
import sys
import importlib.util,json,uuid
from urllib.request import Request,build_opener
from urllib.error import HTTPError
here=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('owner',here.parent/'owner-admin-20261004/owner_admin.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
o=m.Owner();u=o.user();c=o.integrations._read(u['tenant_id'])
profile=o.integrations._cloud(c,u,'ai_profile');config=profile['config']
assert config['model']=='deepseek-flash' and config['provider']=='deepseek' and config['revision']==4
data=json.loads((here/'intent-attempt.json').read_text('utf-8'))['payload']
name=sys.argv[1] if len(sys.argv)>1 else 'diagnostic'
assert name in ('diagnostic','field-diagnostic','final-intent','cache-proof')
if name=='cache-proof':
    prior=json.loads((here/'final-intent-result.json').read_text('utf-8'))
    assert prior['http_status']==200 and len(prior['results'])==4
    data=json.loads((here/'final-intent-attempt.json').read_text('utf-8'))['payload']
else:
    data['post']['id']='synthetic-cost-'+name+'-20261005'
data['request_id']=str(uuid.uuid4())
marker=here/(name+'-attempt.json')
with marker.open('x',encoding='utf-8') as f:json.dump({'payload':data,'max_calls':1,'automatic_replay':False},f,ensure_ascii=False)
session=o.integrations._refresh_session(c,u)
request=Request(c['cloud']['endpoint'],data=json.dumps({'operation':'intent_analyze','environment_id':c['cloud']['environment_id'],**data},ensure_ascii=False).encode(),headers={'Content-Type':'application/json','Authorization':'Bearer '+session['token']},method='POST')
try:
    with build_opener(m.NoRedirect()).open(request,timeout=70) as response:status=response.status;result=json.loads(response.read(1000000))
except HTTPError as error:
    status=error.code;result=json.loads(error.read(32768))
assert result.get('contract')=='fangyu-workspace-v1' and result.get('company_id')==m.COMPANY and result.get('environment_id')==m.ENV
safe={k:result.get(k) for k in ('code','error','validation_issue','model','configured_model','results','billing','cache_hit')}
safe['http_status']=status
(here/(name+'-result.json')).write_text(json.dumps(safe,ensure_ascii=False,indent=2),'utf-8')
print(json.dumps(safe,ensure_ascii=False))
