from pathlib import Path
import importlib.util,json
here=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('owner',here.parent/'owner-admin-20261004/owner_admin.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
profile=m.Owner().profile()
safe={k:profile[k] for k in ('config','usage','budget')}
(here/'profile-after.json').write_text(json.dumps(safe,ensure_ascii=False,indent=2),'utf-8')
print(json.dumps(safe,ensure_ascii=False))
