const fs=require('node:fs'),path=require('node:path');
const {walk,digest}=require('../cloud/verify_live_function_tree.cjs');
const prior=JSON.parse(fs.readFileSync(path.join(__dirname,'../persistent-keywords-20261005/deployment.json')));
const stage=path.join(__dirname,'stage'),base=prior.verified_code_copy;
if(digest(stage)!=='90755b2c519a35428b4bb69dd60baa8f555cff3ae2683c3784fd77cb08b0d3f6'||digest(base)!==prior.candidate_sha)throw Error('reviewed_trees_changed');
if(JSON.stringify(walk(stage))!==JSON.stringify(walk(base)))throw Error('file_inventory_changed');
const own=['ai_contract.cjs','ai_enterprise.cjs'],copied=[];
for(const rel of walk(base)){
 if(own.includes(rel))continue;
 const target=path.join(stage,rel),source=path.join(base,rel);
 if(!fs.readFileSync(source).equals(fs.readFileSync(target))){fs.copyFileSync(source,target);copied.push(rel);}
}
console.log(JSON.stringify({baseline:prior.candidate_sha,preserved_latest_files:copied}));
