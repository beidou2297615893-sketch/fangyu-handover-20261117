from pathlib import Path
import shutil
here=Path(__file__).resolve().parent
root=here.parents[1]
backup=here/'before'
backup.mkdir(exist_ok=False)
for name in ('ai_contract.cjs','ai_enterprise.cjs','ai_enterprise.test.cjs'):
    shutil.copy2(root/'work/cloud/workspace'/name,backup/name)
