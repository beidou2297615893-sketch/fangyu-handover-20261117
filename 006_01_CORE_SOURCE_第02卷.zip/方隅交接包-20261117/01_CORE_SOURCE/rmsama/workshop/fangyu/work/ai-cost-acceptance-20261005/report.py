from pathlib import Path
import json,math
here=Path(__file__).resolve().parent
def read(name):return json.loads((here/(name+'.json')).read_text('utf-8'))
before=read('profile-before');after=read('profile-after')
final=read('final-intent-result');cache=read('cache-proof-result');keyword=read('keyword-result')
assert final['http_status']==200 and final['model']==final['configured_model']=='deepseek-flash'
rows={r['id']:r for r in final['results']}
quality={'four_ids':set(rows)=={'urgent-demand','semantic-demand','unrelated-complaint','other-city'},
 'urgent_prioritized':rows['urgent-demand']['level'] in ('high','super_high'),
 'semantic_need_without_seed_word':rows['semantic-demand']['status']=='graded',
 'complaint_excluded':rows['unrelated-complaint']['status']=='unrelated',
 'other_city_from_content_not_ip':rows['other-city']['region_status']=='other' and rows['other-city']['status']=='unrelated',
 'keyword_50':len(keyword['keywords'])==50,
 'identical_request_cached':cache['cache_hit'] is True and cache['billing']['actual_cost_cny']==0 and cache['results']==final['results']}
assert all(quality.values())
ledger=read('ledger-read-only')
paid=[r for r in ledger if r['model']=='deepseek-flash' and r.get('usage') and r['created_at']>=1791183253429]
assert len(paid)==5
def recalc(r,factor=1):
 u=r['usage'];return math.ceil((u['prompt_cache_hit_tokens']*.02+u['prompt_cache_miss_tokens']+u['completion_tokens']*4)*factor)/1e6
reconciled=sum(recalc(r) for r in paid)
ledger_cost=sum(r['actual_cost_micro'] for r in paid)/1e6
last=next(r for r in paid if r['request_id']==final['billing']['request_id'])
word=next(r for r in paid if r['operation']=='keyword_suggest')
assert after['usage']['today']['known_requests']-before['usage']['today']['known_requests']==5
assert sum(r['usage']['prompt_tokens']+r['usage']['completion_tokens'] for r in paid)==7403
summary={'model':'deepseek-flash','quality':quality,'paid_provider_calls':5,'invalid_outputs':2,'successful_intent_samples':2,
 'cache_checks':1,'new_tokens':7403,'software_recorded_cost_cny':ledger_cost,
 'official_tariff_recalculated_cny':reconciled,'historical_tariff_difference_cny':round(ledger_cost-reconciled,6),
 'billing_basis':'actual provider token counts multiplied by published tariff; supplier invoice not accessed',
 'keyword_50_off_peak_cny':recalc(word),'keyword_50_peak_cny':recalc(word,2),
 'intent_four_off_peak_cny':recalc(last),'intent_four_peak_cny':recalc(last,2),
 'per_1000_short_comments_off_peak_estimate_cny':recalc(last)*250,
 'per_1000_short_comments_peak_estimate_cny':recalc(last,2)*250,
 'production_comment_writes':0,'platform_requests':0,'key_reads':0,
 'earlier_openai_unknown_billing_excluded':True,'formal_installer_created':False,
 'limits':['Synthetic four-comment quality sample; production scale not established.',
           'First two invalid raw responses were not retained; exact failed field is not known.',
           'Known 2026 holiday calendar only; unverified years conservatively retain weekday pricing.',
           'Historical ledger amounts preserved; report separately recalculates the verified holiday tariff.',
           'Supplier cache hits vary; comment length, context and output length change future costs.']}
(here/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),'utf-8')
out=here.parents[1]/'outputs/AI实测与成本';out.mkdir(exist_ok=True)
report=f'''# DeepSeek 实测与成本（2026-10-05）

## 已验证

- 固定使用企业配置的 deepseek-flash，没有切换模型或服务商。
- 真实 API 返回 50 个上海古北租房候选关键词。
- 两次四条合成评论分析通过：近期本人求租优先，正文无“古北租房”原词的需求保留，投诉与外地求租区分。
- 同一四条评论再次请求命中企业结果缓存，增加费用 0 元；共计 5 次有用量供应商调用，含 2 次格式校验失败，合计 7403 tokens。
- 加强输出字段、null 等级、外地无关内容关键信息为空的提示约束；字段错误仅记录固定诊断标识。严格原文证据校验保留。
- 修复费用核算漏排除节假日问题；49 项离线 AI 回归通过。两次云代码更新均已下载验 SHA，企业配置版本仍为 4。

## 费用估算

| 操作 | 空闲时段 | 高峰时段 |
|---|---:|---:|
| 联想 50 个关键词 | {summary['keyword_50_off_peak_cny']:.6f} 元 | {summary['keyword_50_peak_cny']:.6f} 元 |
| 分析本组 4 条短评论 | {summary['intent_four_off_peak_cny']:.6f} 元 | {summary['intent_four_peak_cny']:.6f} 元 |
| 按本组外推 1000 条短评论 | 约 {summary['per_1000_short_comments_off_peak_estimate_cny']:.2f} 元 | 约 {summary['per_1000_short_comments_peak_estimate_cny']:.2f} 元 |

这些是 API 实际返回 token 乘官方单价的核算，供应商账单未读取；不包括腾讯云服务器费用。1000 条为小样本外推，不是千条实测。样本有两条无关评论；长评论、更多上下文或关键信息、缓存变化均会改变价格。

本轮含失败诊断的 5 次调用，按今天节假日单价重算约 {reconciled:.6f} 元。修复前的三笔历史账本按普通工作日价格记录；软件目前合计 {ledger_cost:.6f} 元，差额 {ledger_cost-reconciled:.6f} 元已在本报告单列对账，未改写旧账。之前 OpenAI 的未知用量和预算预留不纳入本轮 DeepSeek 成本，也不当作已知零扣费。

官方依据：[DeepSeek 模型与价格](https://api-docs.deepseek.com/zh-cn/quick_start/pricing/)、[国务院 2026 年节假日安排](https://www.beijing.gov.cn/cs/gncs/zcwj/202603/t20260327_4568275.html)。

## 验收范围与未验证

本轮是企业 AI 服务真实调用和合成评论质量验收，没有请求小红书、插入测试客户、重启用户程序或读取供应商密钥。小红书真实持续采集、员工界面的最新视觉认可、完整安装与异机更新不因此视为完成。最初两次失败只有固定“意向等级未通过校验”记录，无法回溯具体字段；增强约束后的代表性复测通过，不能承诺所有模型输出永不失败。未知费用预留保持待核对。

证据目录：{here}
'''
(out/'DeepSeek实测与成本-20261005.md').write_text(report,'utf-8')
print(json.dumps(summary,ensure_ascii=False))
