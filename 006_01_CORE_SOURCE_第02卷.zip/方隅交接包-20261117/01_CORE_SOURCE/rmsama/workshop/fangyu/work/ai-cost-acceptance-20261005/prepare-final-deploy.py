from pathlib import Path
here=Path(__file__).resolve().parent
final=here.parent/'ai-intent-contract-20261005'
final.mkdir(exist_ok=False)
source=(here/'deploy.cjs').read_text('utf-8')
source=source.replace("../persistent-keywords-20261005/deployment.json","../ai-cost-acceptance-20261005/deployment.json")
source=source.replace("stage=path.join(__dirname,'stage')","stage=path.join(__dirname,'../ai-cost-acceptance-20261005/stage')")
source=source.replace("const allowed=['ai_enterprise.cjs','ai_contract.cjs'];","const allowed=['ai_contract.cjs'];")
source=source.replace("if(fs.existsSync(stage))throw Error('stage_exists');\n fs.cpSync(baseline,stage,{recursive:true,errorOnExist:true,force:false});","if(digest(stage)!==BASE)throw Error('reviewed_stage_differs');")
with (final/'deploy.cjs').open('x',encoding='utf-8') as f:f.write(source)
