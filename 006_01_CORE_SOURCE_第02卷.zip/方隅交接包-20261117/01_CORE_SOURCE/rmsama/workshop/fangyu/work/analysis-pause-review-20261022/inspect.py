"""Read-only current task analysis metadata; no text, credentials or raw model output."""
from pathlib import Path
from collections import Counter
from datetime import datetime, timezone
import hashlib,json,sqlite3

T=Path(__file__).resolve().parent
N=T.parents[1]/'work/ui-native-r57'
b=json.loads((N/'state/production-workspace.json').read_text('utf-8-sig'))
tenant='cloud-'+hashlib.sha256((b['environment_id']+'\n'+b['company_id']).encode()).hexdigest()[:24]
db=sqlite3.connect((Path(b['data_dir'])/'workspace.sqlite3').as_uri()+'?mode=ro',uri=True)
db.execute('PRAGMA query_only=ON')
def rows(entity):return [json.loads(r[0]) for r in db.execute('SELECT body FROM records WHERE entity=? AND tenant_id=?',(entity,tenant))]
task=max((r for r in rows('tasks') if r.get('cloud_owner')==b['owner']),key=lambda r:r.get('created_at',''))
leads=[r for r in rows('leads') if r.get('task_id')==task['id'] and r.get('cloud_owner') in (None,'',b['owner'])]
queue=next((r for r in rows('workbench_collection_page_analysis_v1') if r['id']==task['id']),{})
lookup={r['id']:r for r in leads}
queued=[lookup[k] for k in queue.get('lead_ids',[]) if k in lookup]
digest=lambda v:hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True,allow_nan=False,separators=(',',':')).encode()).hexdigest()
hashes={digest([tenant,b['owner'],r['id']]) for r in queued}
attempts=[r for r in rows('ai_attempts') if r.get('owner')==b['owner'] and hashes.intersection(r.get('lead_digests') or [])]
fields=('id','state','operation','created_at','updated_at','error_code','code','validated_at')
facts={'at':datetime.now(timezone.utc).isoformat(),'access':'read_only','taskId':task['id'],
 'totalComments':len(leads),'taskAIStatuses':dict(Counter(str((r.get('manual_intent') or r.get('ai_intent') or {}).get('status')) for r in leads)),
 'queuedCount':len(queue.get('lead_ids',[])),'queuedFound':len(queued),
 'queuedAIStatuses':dict(Counter(str((r.get('manual_intent') or r.get('ai_intent') or {}).get('status')) for r in queued)),
 'queuedManualCount':sum(bool(r.get('manual_intent')) for r in queued),'job':[{k:r[k] for k in ('status','code','pending','analyzed','updated_at') if k in r} for r in rows('ai_jobs') if r['id']==task['id']],
 'attempts':[ {**{k:r[k] for k in fields if k in r},'overlap':len(hashes.intersection(r.get('lead_digests') or []))} for r in attempts],
 'attemptStateCounts':dict(Counter(r.get('state') for r in attempts))}
db.close()
(T/'ACTUAL.json').write_text(json.dumps(facts,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps(facts,ensure_ascii=True))
