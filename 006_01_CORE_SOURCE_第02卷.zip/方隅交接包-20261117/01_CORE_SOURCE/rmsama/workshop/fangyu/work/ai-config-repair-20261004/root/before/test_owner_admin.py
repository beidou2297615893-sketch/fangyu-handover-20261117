import importlib.util,json,threading,unittest,http.client
from pathlib import Path
from unittest.mock import patch
spec=importlib.util.spec_from_file_location('owner_admin',Path(__file__).with_name('owner_admin.py'))
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class FakeOwner:
 def __init__(self):self.calls=[]
 def profile(self):return {'user':{'username':'rmsama','role':'admin'},'config':{'provider':'deepseek','configured':True}}
 def call(self,op,data):self.calls.append((op,data));return {'ok':True}
class Tests(unittest.TestCase):
 def setUp(self):
  self.owner=FakeOwner();self.server=m.Server(self.owner);self.thread=threading.Thread(target=self.server.serve_forever,daemon=True);self.thread.start()
  self.addCleanup(self.server.server_close);self.addCleanup(self.server.shutdown)
 def request(self,path,method='GET',data=None,headers=None):
  conn=http.client.HTTPConnection('127.0.0.1',self.server.server_port,timeout=3)
  headers=dict(headers or {})
  body=json.dumps(data).encode() if data is not None else None
  if body:headers.setdefault('Content-Type','application/json')
  conn.request(method,path,body,headers);res=conn.getresponse();raw=res.read();out=(res.status,dict(res.getheaders()),raw);conn.close();return out
 def auth(self):
  status,headers,raw=self.request('/api/bootstrap','POST',{'launch':self.server.launch},{'Origin':self.server.origin})
  self.assertEqual(status,200);self.assertIn('HttpOnly',headers['Set-Cookie']);self.assertIn('SameSite=Strict',headers['Set-Cookie'])
  return {'Cookie':headers['Set-Cookie'].split(';')[0],'X-Fangyu-CSRF':json.loads(raw)['csrf'],'Origin':self.server.origin}
 def test_public_page_does_not_authorize_api(self):
  self.assertEqual(self.request('/api/profile')[0],403)
  self.assertEqual(self.request('/api/bootstrap','POST',{'launch':'wrong'})[0],403)
  self.assertEqual(self.owner.calls,[])
 def test_owner_handshake_then_profile(self):
  headers=self.auth();status,_,raw=self.request('/api/profile',headers=headers)
  self.assertEqual(status,200);self.assertEqual(json.loads(raw)['user']['role'],'admin')
  self.assertNotIn(self.server.launch.encode(),raw);self.assertNotIn(self.server.cookie.encode(),raw)
 def test_cross_site_and_rebinding_rejected_even_with_cookie(self):
  headers=self.auth();headers['Origin']='https://other.example'
  self.assertEqual(self.request('/api/cloud','POST',{'operation':'ai_config_save','data':{}},headers)[0],403)
  headers['Origin']=self.server.origin;headers['Host']='other.example'
  self.assertEqual(self.request('/api/profile',headers=headers)[0],403);self.assertEqual(self.owner.calls,[])
 def test_csrf_needed_before_writes(self):
  headers=self.auth();headers.pop('X-Fangyu-CSRF')
  self.assertEqual(self.request('/api/cloud','POST',{'operation':'ai_config_save','data':{}},headers)[0],403)
  self.assertEqual(self.owner.calls,[])
 def test_no_platform_paid_or_arbitrary_rpc(self):
  headers=self.auth()
  for op in ['command_submit','login','intent_analyze','keyword_suggest','publish','device_revoke']:
   self.assertEqual(self.request('/api/cloud','POST',{'operation':op,'data':{}},headers)[0],403)
  self.assertEqual(self.owner.calls,[])
 def test_reviewed_configuration_once_without_automatic_retry(self):
  status,_,raw=self.request('/api/cloud','POST',{'operation':'ai_config_save','data':{'config':{'provider':'openai'}}},self.auth())
  self.assertEqual(status,200);self.assertEqual(len(self.owner.calls),1)
 def test_private_resources_never_served(self):
  for target in ['/private/owner.dpapi','/assets/../private/owner.dpapi','/authorize.cjs','/api/cloud']:
   self.assertEqual(self.request(target)[0],404)
 def test_public_projection_removes_nested_credentials(self):
  value=m.public({'config':{'api_key':'secret','api_keys':{'openai':'secret'},'token':'secret','model':'model'},'users':[{'username':'rmsama','salt':'x','digest':'x'}]})
  self.assertEqual(value,{'config':{'model':'model'},'users':[{'username':'rmsama'}]})
 def test_revoked_or_operator_identity_not_an_owner(self):
  owner=object.__new__(m.Owner);owner.owner_file=Path('unused')
  owner.core=type('Core',(),{'store':type('Store',(),{'get':lambda self,*a:{'id':'u','tenant_id':'t','username':'rmsama','role':'operator'}})()})()
  with patch.object(m,'read_private',return_value={'id':'u','tenant_id':'t','username':'rmsama','role':'admin'}):
   with self.assertRaises(m.IntegrationError):owner.user()
 def test_cross_tenant_cloud_grant_is_rejected_before_storage(self):
  owner=object.__new__(m.Owner)
  for user in [{'username':'kk0002','role':'operator'},{'username':'rmsama','role':'operator'},{'username':'rmsama','role':'admin','disabled':True}]:
   with patch.object(m,'request_json',return_value={'contract':'fangyu-workspace-v1','company_id':m.COMPANY,'environment_id':m.ENV,'user':user}):
    with self.assertRaises(m.IntegrationError):owner.accept_grant({'token':'irrelevant'})
if __name__=='__main__':unittest.main()
