import test from 'node:test';
import assert from 'node:assert/strict';
import {createOwnerAdmin, acceptedCatalog, deviceOverview} from '../site/owner-admin.mjs';

class FakeElement {
  constructor(tag = 'div') {
    this.tagName = tag.toUpperCase(); this.children = []; this.listeners = new Map();
    this._value = ''; this._text = ''; this.hidden = false; this.disabled = false; this.checked = false;
    this.dataset = {}; this.attributes = new Map();
    const classes = new Set();
    this.classList = {add: name => classes.add(name), remove: name => classes.delete(name), contains: name => classes.has(name), toggle: (name, force) => {if (force ?? !classes.has(name)) classes.add(name); else classes.delete(name);}};
  }
  set value(value) { this._value = String(value); }
  get value() { return this._value; }
  set textContent(value) { this._text = String(value); this.children = []; }
  get textContent() { return this._text || this.children.map(child => child.textContent).join(''); }
  replaceChildren(...children) { this.children = children; this._text = ''; if (this.tagName === 'SELECT') this.value = children[0]?.value || ''; }
  append(...children) { this.children.push(...children); }
  addEventListener(name, handler) { this.listeners.set(name, handler); }
  dispatch(name) { return this.listeners.get(name)?.({preventDefault() {}}); }
  querySelectorAll() { return this.formControls || []; }
  setAttribute(name, value) { this.attributes.set(name, value); }
  removeAttribute(name) { this.attributes.delete(name); }
}

function fixture() {
  const ids = ['ai-config-form','ai-enabled','ai-provider','ai-model','ai-effort-label','ai-effort','ai-daily-budget','ai-key','ai-key-help','ai-configured','ai-clear-key','ai-usd-rate-label','ai-usd-rate','ai-rules-version','ai-save','ai-save-feedback','ai-state-chip','ai-current-model','ai-budget-state','page-feedback','page-ai','page-devices','page-title','page-subtitle','device-summary','devices-online','devices-offline','devices-revoked','device-list','refresh','refresh-devices'];
  const elements = Object.fromEntries(ids.map(id => [id, new FakeElement(id.includes('provider') || id === 'ai-model' || id === 'ai-effort' ? 'select' : 'div')]));
  const controls = ['ai-enabled','ai-provider','ai-model','ai-effort','ai-daily-budget','ai-key','ai-clear-key','ai-usd-rate','ai-rules-version','ai-save'];
  elements['ai-config-form'].formControls = controls.map(id => elements[id]);
  elements['ai-effort-label'].hidden = true;
  const tabs = ['ai','devices'].map(page => {const button = new FakeElement('button'); button.dataset.page = page; return button;});
  const pageEvents = new Map(), historyCalls = [];
  const doc = {getElementById: id => elements[id], createElement: tag => new FakeElement(tag), querySelectorAll: selector => selector === '[data-page]' ? tabs : [], defaultView: {location: {hash: '#launch-token', pathname: '/'}, history: {replaceState: (...args) => historyCalls.push(args)}, addEventListener: (name, fn) => pageEvents.set(name, fn)}};
  return {doc, elements, tabs, pageEvents, historyCalls};
}

const config = {
  enabled: true, provider: 'openai', model: 'gpt-5.4-mini', daily_budget_cny: 5, usd_cny_rate: 7.5, rules_version: '2026-10',
  model_catalog: [
    {provider: 'openai', id: 'gpt-5.4-mini', label: 'GPT 5.4 mini', reasoning_efforts: ['none','low','medium']},
    {provider: 'deepseek', id: 'deepseek-flash', label: '<img src=x onerror=alert(1)>', reasoning_efforts: []},
    {provider: 'openai', id: '<script>', label: 'bad', reasoning_efforts: []}
  ],
  providers: {openai: {model: 'gpt-5.4-mini', reasoning_effort: 'low', configured: true}, deepseek: {model: 'deepseek-flash', configured: false}}
};
const budget = {spent_cny: 0.2, remaining_cny: 4.8, limit_cny: 5};
const response = value => ({ok: true, json: async () => value});
const tick = () => new Promise(resolve => setImmediate(resolve));

test('backend catalog controls model and effort; provider switch clears key', async () => {
  const {doc, elements: e, pageEvents, historyCalls} = fixture();
  const calls = [];
  createOwnerAdmin(doc, async (url, options) => {
    calls.push({url, options});
    if (url === '/api/bootstrap') return response({csrf: 'csrf-test', contract: 'fangyu-owner-admin-v1'});
    if (url === '/api/profile') return response({user: {username: 'rmsama', role: 'admin'}, config, budget});
    if (url === '/api/cloud') return response({devices: []});
    throw Error('unexpected');
  });
  await tick(); await tick();
  assert.equal(e['ai-state-chip'].textContent, '已启用');
  assert.equal(e['ai-provider'].value, 'openai');
  assert.deepEqual(e['ai-model'].children.map(option => option.value), ['gpt-5.4-mini']);
  assert.equal(e['ai-effort'].value, 'low');
  assert.equal(e['ai-effort-label'].hidden, false);
  assert.equal(e['ai-daily-budget'].value, '5');
  e['ai-key'].value = 'sensitive';
  e['ai-provider'].value = 'deepseek'; e['ai-provider'].dispatch('change');
  assert.equal(e['ai-key'].value, '');
  assert.equal(e['ai-model'].children[0].textContent, '<img src=x onerror=alert(1)>');
  assert.equal(e['ai-effort-label'].hidden, true);
  assert.match(e['ai-key-help'].href, /deepseek/);
  e['ai-key'].value = 'other-secret'; pageEvents.get('pagehide')();
  assert.equal(e['ai-key'].value, '');
  assert.equal(calls[0].url, '/api/bootstrap');
  assert.equal(calls[0].options.method, 'POST');
  assert.equal(JSON.parse(calls[0].options.body).launch, 'launch-token');
  assert.deepEqual(historyCalls[0], [null, '', '/']);
  assert.equal(calls[1].url, '/api/profile');
  assert.equal(acceptedCatalog(config).length, 2);
});

test('model selection keeps entered key and missing key is never shown as enabled', async () => {
  const {doc, elements: e} = fixture();
  const unconfigured = {...config, model_catalog: [
    ...config.model_catalog.filter(item => item.id !== '<script>'),
    {provider: 'openai', id: 'gpt-5.4', label: 'GPT 5.4', reasoning_efforts: ['low','high']}
  ], providers: {...config.providers, openai: {...config.providers.openai, configured: false}}};
  createOwnerAdmin(doc, async url => url === '/api/bootstrap'
    ? response({csrf: 'csrf-test', contract: 'fangyu-owner-admin-v1'})
    : response({user: {username: 'rmsama', role: 'admin'}, config: unconfigured, budget}));
  await tick(); await tick();
  assert.equal(e['ai-state-chip'].textContent, '待配置密钥');
  e['ai-key'].value = 'new-key'; e['ai-model'].value = 'gpt-5.4'; e['ai-model'].dispatch('change');
  assert.equal(e['ai-key'].value, 'new-key');
  assert.deepEqual(e['ai-effort'].children.map(option => option.value), ['low','high']);
});

test('save locks duplicate submissions, sends CSRF and clears key after failure', async () => {
  const {doc, elements: e} = fixture();
  let rejectSave; let posts = 0; let sent;
  const request = async (url, options) => {
    if (url === '/api/bootstrap') return response({csrf: 'csrf-test', contract: 'fangyu-owner-admin-v1'});
    if (url === '/api/profile') return response({user: {username: 'rmsama', role: 'admin'}, config, budget});
    if (url === '/api/cloud') { posts++; sent = options; return new Promise((_, reject) => {rejectSave = reject;}); }
    throw Error('unexpected');
  };
  const controller = createOwnerAdmin(doc, request); await tick(); await tick();
  e['ai-key'].value = 'secret';
  const saving = controller.save({preventDefault() {}});
  assert.equal(e['ai-save'].disabled, true);
  await controller.save({preventDefault() {}});
  assert.equal(posts, 1);
  assert.equal(sent.headers['X-Fangyu-CSRF'], 'csrf-test');
  assert.equal(JSON.parse(sent.body).data.api_key, 'secret');
  rejectSave(Error('private server body'));
  await saving;
  assert.equal(e['ai-key'].value, '');
  assert.equal(e['ai-save'].disabled, false);
  assert.equal(e['ai-save-feedback'].textContent, '保存结果未确认，请刷新状态后核对。');
  assert.doesNotMatch(e['ai-save-feedback'].textContent, /private/);
});

test('failed profile read remains unloaded, with no invented model or budget', async () => {
  const {doc, elements: e} = fixture();
  createOwnerAdmin(doc, async url => url === '/api/bootstrap'
    ? response({csrf: 'csrf-test', contract: 'fangyu-owner-admin-v1'})
    : ({ok: false, json: async () => ({error: 'private'})}));
  await tick(); await tick();
  assert.equal(e['ai-save'].disabled, true);
  assert.equal(e['ai-current-model'].textContent, '尚未读取');
  assert.equal(e['ai-budget-state'].textContent, '预算状态待读取');
  assert.equal(e['ai-configured'].textContent, '密钥状态待读取');
  assert.match(e['page-feedback'].textContent, /读取失败/);
});

test('confirmed save re-reads cloud config and clears key', async () => {
  const {doc, elements: e} = fixture();
  const operations = [];
  const updated = {...config, enabled: false, daily_budget_cny: 8};
  const controller = createOwnerAdmin(doc, async (url, options) => {
    if (url === '/api/bootstrap') return response({csrf: 'csrf-test', contract: 'fangyu-owner-admin-v1'});
    if (url === '/api/profile') return response({user: {username: 'rmsama', role: 'admin'}, config, budget});
    const operation = JSON.parse(options.body).operation; operations.push(operation);
    if (operation === 'ai_config_save') return response({config: {provider: 'openai'}});
    if (operation === 'ai_config_read') return response({config: updated});
    if (operation === 'ai_profile') return response({budget});
    throw Error('unexpected operation');
  });
  await tick(); await tick();
  e['ai-key'].value = 'secret';
  await controller.save({preventDefault() {}});
  assert.deepEqual(operations, ['ai_config_save','ai_config_read','ai_profile']);
  assert.equal(e['ai-key'].value, '');
  assert.equal(e['ai-state-chip'].textContent, '未启用');
  assert.equal(e['ai-daily-budget'].value, '8');
  assert.equal(e['ai-save-feedback'].textContent, '企业配置已保存。');
});

test('device summary uses online, owner and version without actions', async () => {
  const now = Date.now() / 1000;
  assert.deepEqual(deviceOverview([{last_seen: now - 10}, {last_seen: now - 200}, {revoked: true, last_seen: now}], now), {online: 1, offline: 1, revoked: 1});
  const {doc, elements: e} = fixture();
  let posted;
  const controller = createOwnerAdmin(doc, async (url, options) => {
    if (url === '/api/bootstrap') return response({csrf: 'csrf-test', contract: 'fangyu-owner-admin-v1'});
    if (url === '/api/profile') return response({user: {username: 'rmsama', role: 'admin'}, config, budget});
    posted = JSON.parse(options.body); return response({devices: [{name: '前台电脑', owner: 'staff', version: '1.2', last_seen: now}]});
  });
  await tick(); await tick();
  e['ai-key'].value = 'secret'; controller.navigate('devices'); await tick();
  assert.equal(e['ai-key'].value, '');
  assert.equal(posted.operation, 'devices');
  assert.equal(e['devices-online'].textContent, '1');
  assert.match(e['device-list'].children[0].textContent, /staff · 在线 · 当前版本 1.2/);
  assert.equal(e['device-list'].children[0].children.length, 1);
});
