"""Owner-only local management portal; existing cloud auth and DPAPI are reused."""
import argparse, hashlib, hmac, json, os, secrets, sys, threading, time, webbrowser
from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from http.cookies import SimpleCookie
from urllib.parse import urlsplit, parse_qs

PROJECT=Path(__file__).resolve().parents[2]
HOME=Path(__file__).resolve().parent
sys.path.insert(0,str(PROJECT/'work/app/src'))
from core.engine import Core
from integrations import Integrations, IntegrationError, protect, request_json, remembered_expiry, NoRedirect
from assistant.employee_workspace import ASSETS, SVG_NAMES, IMAGE_NAME

ENV='fh6-d5ga45c0ddae7008c'
COMPANY='fangyu-apartment-client'
ENDPOINT='https://fh6-d5ga45c0ddae7008c-1439321968.ap-shanghai.app.tcloudbase.com/fangyu-workspace'
PRIVATE=HOME/'private'
OPERATIONS=frozenset({'ai_config_read','ai_config_save','ai_profile','devices','members'})
SECRET_KEYS=frozenset({'token','refresh_token','pending_refresh','api_key','api_keys','password','password_hash','authorization','cookie','digest','salt','secret','secretkey','secretid'})


def public(value):
    if isinstance(value,dict):return {k:public(v) for k,v in value.items() if isinstance(k,str) and k.lower() not in SECRET_KEYS}
    if isinstance(value,list):return [public(v) for v in value]
    return value


def write_private(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    if path.is_symlink() or path.parent.is_symlink():raise ValueError('private_path_invalid')
    tmp=path.with_suffix('.tmp');tmp.write_bytes(protect(json.dumps(value).encode()));tmp.replace(path)


def read_private(path):
    if path.is_symlink() or path.parent.is_symlink():raise ValueError('private_path_invalid')
    return json.loads(protect(path.read_bytes(),decrypt=True))


class Owner:
    def __init__(self):
        if os.name!='nt' or getattr(sys,'frozen',False):raise ValueError('owner_local_source_only')
        if PRIVATE.is_symlink():raise ValueError('private_path_invalid')
        self.core=Core(PRIVATE)
        self.core.deployment_config={'id':COMPANY,'name':'方隅公寓','authMode':'managed',
            'managedWorkspace':{'environment_id':ENV,'endpoint':ENDPOINT}}
        self.integrations=Integrations(self.core)
        self.lock=threading.RLock()
        self.owner_file=PRIVATE/'owner.dpapi'

    def bootstrap(self,password):
        with self.lock:
            result=self.integrations.enter({'username':'rmsama','password':password})
            user=result.get('user') or {}
            if user.get('username')!='rmsama' or user.get('role')!='admin':
                raise ValueError('verified_admin_required')
            write_private(self.owner_file,{k:user[k] for k in ('id','tenant_id','username','role')})
            return {'authorized':True,'username':user['username'],'role':user['role'],'password_retained':False}

    def accept_grant(self,grant):
        # The cloud must prove this already-authorized administrator before storage.
        result=request_json(ENDPOINT,{'operation':'me','environment_id':ENV},grant['token'])
        profile=result.get('user') or {}
        if (result.get('contract')!='fangyu-workspace-v1' or result.get('company_id')!=COMPANY
            or result.get('environment_id')!=ENV or profile.get('username')!='rmsama'
            or profile.get('role')!='admin' or profile.get('disabled')):
            raise IntegrationError('管理员授权身份未通过核对')
        absolute=remembered_expiry(grant,grant['device_id'])
        if absolute is None or not time.time()<grant['expires']<=time.time()+8*3600+5:
            raise IntegrationError('管理员授权有效期无效')
        tenant='cloud-'+hashlib.sha256((ENV+'\n'+COMPANY).encode()).hexdigest()[:24]
        uid=hashlib.sha256((tenant+'\n'+'rmsama').encode()).hexdigest()
        with self.lock,self.integrations.lock,self.core.lock:
            if not self.core.store.get('tenants',tenant):
                self.core.store.put('tenants',self.core._record({'id':tenant,'name':'方隅公寓管理','company_id':COMPANY},tenant))
            user=self.core._record({'id':uid,'username':'rmsama','role':'admin','disabled':False,'cloud_bound':True,'can_reply':False},tenant)
            self.core.store.put('users',user)
            config=self.integrations._read(tenant)
            config['cloud']={'environment_id':ENV,'endpoint':ENDPOINT}
            config.setdefault('sessions',{})[uid]={k:grant[k] for k in ('token','expires','device_id','refresh_token','refresh_idle_expires','refresh_absolute_expires')}
            config['sessions'][uid]['username']='rmsama'
            self.integrations._write(tenant,config)
            write_private(self.owner_file,{k:user[k] for k in ('id','tenant_id','username','role')})
        return {'authorized':True,'username':'rmsama','role':'admin','password_retained':False}

    def user(self):
        identity=read_private(self.owner_file)
        current=self.core.store.get('users',identity['id'])
        if (not current or any(current.get(k)!=identity.get(k) for k in ('id','tenant_id','username','role'))
            or current.get('role')!='admin' or current.get('username')!='rmsama' or current.get('disabled')):
            raise IntegrationError('本机维护授权需重新建立')
        verified=self.integrations.verify_identity(current)
        if not verified or verified.get('role')!='admin' or verified.get('username')!='rmsama':
            raise IntegrationError('本机维护授权暂不可用，请检查网络或联系维护人员')
        return verified

    def call(self,operation,data):
        if operation not in OPERATIONS or not isinstance(data,dict):raise ValueError('operation_not_allowed')
        if any(key in data for key in ('operation','environment_id','endpoint','token','authorization','cookie')):
            raise ValueError('data_not_allowed')
        with self.lock:
            user=self.user()
            config=self.integrations._read(user['tenant_id'])
            return public(self.integrations._cloud(config,user,operation,**data))

    def profile(self):
        config=self.call('ai_config_read',{})
        budget=self.call('ai_profile',{})
        return {'user':{'username':'rmsama','role':'admin'},'config':config['config'],'budget':budget.get('budget')}


class Server(ThreadingHTTPServer):
    daemon_threads=True
    def __init__(self,owner,port=0):
        super().__init__(('127.0.0.1',port),Handler)
        self.owner=owner;self.launch=secrets.token_urlsafe(32);self.cookie=secrets.token_urlsafe(32)
        self.csrf=secrets.token_urlsafe(32)
        self.origin='http://127.0.0.1:'+str(self.server_port)
        self.cookie_name='fy_owner_'+str(self.server_port)


class Handler(BaseHTTPRequestHandler):
    def log_message(self,*args):pass
    def valid_host(self):return self.headers.get('Host')==urlsplit(self.server.origin).netloc
    def same_origin(self):
        origin=self.headers.get('Origin')
        return (origin in (None,self.server.origin) and self.headers.get('Sec-Fetch-Site') in (None,'same-origin','none'))
    def authorized(self):
        try:
            cookie=SimpleCookie();cookie.load(self.headers.get('Cookie',''))
            value=cookie.get(self.server.cookie_name)
            return bool(value and hmac.compare_digest(value.value,self.server.cookie))
        except Exception:return False
    def send(self,status,value,kind='application/json; charset=utf-8',cookie=False):
        raw=json.dumps(value,ensure_ascii=False).encode() if kind.startswith('application/json') else value
        self.send_response(status);self.send_header('Content-Type',kind);self.send_header('Content-Length',str(len(raw)))
        self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Referrer-Policy','no-referrer')
        self.send_header('Content-Security-Policy',"default-src 'self'; img-src 'self' data: https:; style-src 'self'; script-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
        if cookie:self.send_header('Set-Cookie',f'{self.server.cookie_name}={self.server.cookie}; HttpOnly; SameSite=Strict; Path=/')
        self.end_headers();self.wfile.write(raw)
    def denied(self,status=403):self.send(status,{'error':'本机维护授权无效，请从桌面管理入口打开'})
    def do_GET(self):
        if not self.valid_host() or not self.same_origin():return self.denied()
        parsed=urlsplit(self.path)
        if parsed.path=='/api/profile':
            if not self.authorized():return self.denied()
            try:return self.send(200,self.server.owner.profile())
            except Exception:return self.send(503,{'error':'企业配置暂时无法读取，请检查网络或维护授权'})
        if parsed.path=='/api/health':
            if not self.authorized():return self.denied()
            return self.send(200,{'contract':'fangyu-owner-admin-v1','pid':os.getpid()})
        local={'/':('index.html','text/html; charset=utf-8'),'/owner-admin.mjs':('owner-admin.mjs','text/javascript; charset=utf-8'),'/owner-admin.css':('owner-admin.css','text/css; charset=utf-8')}
        if parsed.path in local:
            filename,kind=local[parsed.path];target=HOME/'site'/filename
        elif parsed.path.startswith('/assets/'):
            name=parsed.path[len('/assets/'):]
            if name in ASSETS:filename,kind=ASSETS[name];target=PROJECT/'work/app/src/web/workspace'/filename
            elif name in SVG_NAMES or IMAGE_NAME.fullmatch(name):
                target=PROJECT/'work/app/src/web/workspace/assets'/name
                kind='image/svg+xml' if name.endswith('.svg') else 'image/webp' if name.endswith('.webp') else 'image/png'
            else:return self.send(404,{'error':'资源不存在'})
        else:return self.send(404,{'error':'资源不存在'})
        if not target.is_file():return self.send(404,{'error':'资源不存在'})
        return self.send(200,target.read_bytes(),kind)
    def do_POST(self):
        if not self.valid_host() or not self.same_origin():return self.denied()
        if self.headers.get('Content-Type','').split(';')[0]!='application/json':return self.denied(400)
        try:
            length=int(self.headers.get('Content-Length','0'))
            if not 0<length<=32768:raise ValueError()
            data=json.loads(self.rfile.read(length))
            if not isinstance(data,dict):raise ValueError()
        except Exception:return self.send(400,{'error':'请求格式无效'})
        if self.path=='/api/bootstrap':
            nonce=data.get('launch','')
            if not self.authorized() and (not isinstance(nonce,str) or not hmac.compare_digest(nonce,self.server.launch)):
                return self.denied()
            return self.send(200,{'csrf':self.server.csrf,'contract':'fangyu-owner-admin-v1'},cookie=True)
        if self.path!='/api/cloud':return self.send(404,{'error':'操作不存在'})
        csrf=self.headers.get('X-Fangyu-CSRF','')
        if not self.authorized() or not hmac.compare_digest(csrf,self.server.csrf):return self.denied()
        if set(data)!={'operation','data'} or data.get('operation') not in OPERATIONS or not isinstance(data.get('data'),dict):
            return self.send(403,{'error':'管理入口不支持此操作'})
        try:return self.send(200,self.server.owner.call(data['operation'],data['data']))
        except IntegrationError:return self.send(503,{'error':'企业操作未完成，请核对网络、密钥或维护授权；没有自动重试'})
        except ValueError:return self.send(400,{'error':'配置未通过校验，请核对所选模型、密钥和预算'})
        except Exception:return self.send(503,{'error':'企业操作未完成，请核对网络与配置；没有自动重试'})


def active_runtime():
    path=PRIVATE/'runtime.dpapi'
    if not path.exists():return None
    try:
        from urllib.request import Request,build_opener
        state=read_private(path)
        url=state['origin']
        parsed=urlsplit(url)
        if parsed.scheme!='http' or parsed.hostname!='127.0.0.1' or not parsed.port or parsed.path or parsed.query or parsed.fragment:return None
        request=Request(url+'/api/health',headers={'Cookie':state['cookie_name']+'='+state['cookie']})
        with build_opener(NoRedirect()).open(request,timeout=2) as response:value=json.load(response)
        if value.get('contract')=='fangyu-owner-admin-v1' and value.get('pid')==state.get('pid'):return state
    except Exception:return None


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--bootstrap',action='store_true');parser.add_argument('--no-browser',action='store_true')
    args=parser.parse_args()
    if args.bootstrap:
        result=Owner().bootstrap(sys.stdin.read().strip());print(json.dumps(result));return
    prior=active_runtime()
    if prior:
        if not args.no_browser:webbrowser.open(prior['origin']+'/#'+prior['launch'])
        return
    owner=Owner();owner.user()
    server=Server(owner)
    state={'origin':server.origin,'pid':os.getpid(),'launch':server.launch,'cookie':server.cookie,'cookie_name':server.cookie_name}
    write_private(PRIVATE/'runtime.dpapi',state)
    if not args.no_browser:webbrowser.open(server.origin+'/#'+server.launch)
    server.serve_forever()

if __name__=='__main__':
    try:main()
    except Exception:
        if os.name=='nt':
            import ctypes
            ctypes.windll.user32.MessageBoxW(None,'管理后台未打开。请检查网络，或联系维护人员恢复本机授权。','方隅管理后台',0x10)
        raise SystemExit(1)
