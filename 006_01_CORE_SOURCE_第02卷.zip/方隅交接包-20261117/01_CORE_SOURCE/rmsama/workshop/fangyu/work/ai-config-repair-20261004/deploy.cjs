// Code-only integration requested by the user; config, data and permissions stay intact.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const project=path.resolve(__dirname,'../..'),cloud=path.join(project,'work/cloud');
const prior=JSON.parse(fs.readFileSync(path.join(__dirname,'../openai-integration-20261004/deployment.json')));
const baseline=prior.verified_code_copy,BASE=prior.candidate_sha,stage=path.join(__dirname,'stage');
const reportFile=path.join(__dirname,'deployment.json'),reviewFile=path.join(__dirname,'preflight.json');
const ENV='fh6-d5ga45c0ddae7008c',FN='fangyu-workspace',COMPANY='fangyu-apartment-client';
const guards=require('../continuous-qa-deploy/deploy.cjs');
const {digest,walk}=require(path.join(cloud,'verify_live_function_tree.cjs'));
const files=['ai_contract.cjs','ai_provider.cjs','ai_enterprise.cjs','site/index.html','site/app.mjs','site/enterprise-model.mjs','site/enterprise-ui.mjs','site/site.css'];
const hash=v=>crypto.createHash('sha256').update(v).digest('hex');
const canonical=o=>JSON.stringify(Object.entries(o).sort(([a],[b])=>a.localeCompare(b)));
const save=(file,value)=>fs.writeFileSync(file,JSON.stringify(value,null,2)+'\n');
async function connect(){
 const {getCredentialWithoutCheck}=require(path.join(project,'work/cloud-tools/node_modules/@cloudbase/toolbox'));
 const Manager=require(path.join(project,'work/cloud-tools/node_modules/@cloudbase/manager-node'));
 const sdk=require(path.join(baseline,'node_modules/@cloudbase/node-sdk'));
 const credential=await getCredentialWithoutCheck();
 if(!credential?.secretId||!credential.secretKey)throw Error('credential_unavailable');
 const options={env:ENV,secretId:credential.secretId,secretKey:credential.secretKey};
 if(credential.token)options.sessionToken=credential.token;
 return {manager:new Manager({secretId:credential.secretId,secretKey:credential.secretKey,token:credential.token,envId:ENV,region:'ap-shanghai'}),db:sdk.init(options).database()};
}
async function idle(manager,db){
 const acl=await manager.commonService().call({Action:'DescribeDatabaseACL',Param:{CollectionName:'fangyu_workspace_private',EnvId:ENV}});
 if(acl.AclTag!=='ADMINONLY')throw Error('private_acl_differs');
 const response=await db.collection('fangyu_workspace_private').doc(COMPANY).get(),state=response?.data?.[0]?.state;
 if(response.code||state?.companyId!==COMPANY||!Array.isArray(state.commands)||state.commands.some(c=>['queued','claimed','running'].includes(c.status)))throw Error('commands_not_idle');
 const pending=await db.collection('fangyu_ai_ledger').where({companyId:COMPANY,status:'reserved'}).limit(100).get();
 if(pending.code||!Array.isArray(pending.data)||pending.data.some(row=>row.attempts?.length))throw Error('provider_may_be_in_flight');
 return {commands_idle:true,provider_requests_idle:true,ai_config_revision:state.enterpriseAi?.revision??0,
  current_provider:state.enterpriseAi?.provider||'deepseek',admin_usernames:state.users.filter(u=>u.role==='admin'&&!u.disabled).map(u=>u.username)};
}
async function download(manager,label,expected){
 const folder=fs.mkdtempSync(path.join(__dirname,'live-'+label+'-'));
 await manager.functions.downloadFunctionCode({envId:ENV,functionName:FN,destPath:folder});
 if(expected&&digest(folder)!==expected)throw Error('live_tree_differs');return folder;
}
function buildStage(){
 if(prior.phase!=='active'||digest(baseline)!==BASE)throw Error('baseline_differs');
 if(fs.existsSync(stage))throw Error('stage_exists');
 fs.cpSync(baseline,stage,{recursive:true,errorOnExist:true,force:false});
 for(const rel of files){
  const source=path.join(cloud,'workspace',rel);
  if(rel.startsWith('site/')){
   const local=path.join(project,'work/app/src/web/workspace',rel.slice(5));
   if(!fs.readFileSync(local).equals(fs.readFileSync(source)))throw Error('source_mirror_differs');
  }
  fs.copyFileSync(source,path.join(stage,rel));
 }
 return localCheck();
}
function localCheck(){
 const left=walk(baseline),right=walk(stage);
 if(JSON.stringify(left)!==JSON.stringify(right))throw Error('candidate_file_list_differs');
 const changed=left.filter(f=>hash(fs.readFileSync(path.join(baseline,f)))!==hash(fs.readFileSync(path.join(stage,f))));
 if(changed.length!==files.length||changed.some(f=>!files.includes(f)))throw Error('candidate_delta_differs');
 return {baseline_sha:BASE,candidate_sha:digest(stage),changed_files:changed};
}
async function main(){
 const mode=process.argv[2];if(!['--read-only','--stage','--deploy','--rollback'].includes(mode))throw Error('invalid_mode');
 if(mode==='--stage')return buildStage();
 const {manager,db}=await connect();
 if(mode==='--read-only'){
  const gate=await idle(manager,db),detail=await manager.functions.getFunctionDetail(FN);
  if(detail.Status!=='Active')throw Error('function_not_active');
  const live=await download(manager,'preflight',BASE);
  const review={read_only:true,baseline_sha:BASE,baseline_copy:live,environment_sha:hash(canonical(guards.flagsOf(detail))),
   stable_sha:hash(JSON.stringify(guards.stableConfig(detail))),...gate,reviewed_at:new Date().toISOString()};
  save(reviewFile,review);return review;
 }
 const local=localCheck(),review=JSON.parse(fs.readFileSync(reviewFile)),detail=await manager.functions.getFunctionDetail(FN);
 if(hash(canonical(guards.flagsOf(detail)))!==review.environment_sha||hash(JSON.stringify(guards.stableConfig(detail)))!==review.stable_sha)throw Error('configuration_changed');
 const expected=mode==='--rollback'?BASE:local.candidate_sha,desired=mode==='--rollback'?baseline:stage;
 if(mode==='--deploy'){
  if(fs.existsSync(reportFile))throw Error('already_attempted');
  const gate=await idle(manager,db);if(gate.ai_config_revision!==review.ai_config_revision)throw Error('ai_configuration_changed');
  await download(manager,'before',BASE);
 }
 const report={phase:mode==='--rollback'?'rollback_started':'upload_started',authorization:'User explicitly requested fixing enterprise configuration saves, hiding employee budgets, tracking usage and locking the selected model on 2026-10-04.',
  ...local,baseline_copy:review.baseline_copy,environment_sha:review.environment_sha,stable_sha:review.stable_sha,config_unchanged:true,data_unchanged:true,platform_requested:false,paid_ai_requested:false,
  started_at:new Date().toISOString()};save(reportFile,report);
 const upload=await manager.functions.updateFunctionCode({func:{name:FN,runtime:'Nodejs20.19',handler:'index.main',installDependency:false},functionRootPath:cloud,functionPath:desired,deployMode:'cos'});
 report.request_id=upload.RequestId||null;save(reportFile,report);
 let verified=null;
 for(let attempt=0;attempt<5;attempt++){
  const fresh=await manager.functions.getFunctionDetail(FN);
  if(fresh.Status==='Active'){
   const folder=await download(manager,'verify'),sha=digest(folder);
   if(sha===expected){verified=folder;break;}
   if(sha!==BASE&&sha!==local.candidate_sha)throw Error('unknown_live_code');
  }
  if(attempt<4)await new Promise(resolve=>setTimeout(resolve,2500));
 }
 if(!verified)throw Error('uploaded_tree_not_verified');
 const final=await manager.functions.getFunctionDetail(FN);
 if(hash(canonical(guards.flagsOf(final)))!==review.environment_sha||hash(JSON.stringify(guards.stableConfig(final)))!==review.stable_sha)throw Error('configuration_changed_after_upload');
 Object.assign(report,{phase:mode==='--rollback'?'rolled_back':'active',verified_code_copy:verified,finished_at:new Date().toISOString()});save(reportFile,report);
 return {phase:report.phase,code_sha:expected,environment_unchanged:true,data_unchanged:true,paid_ai_requested:false};
}
if(require.main===module)main().then(value=>console.log(JSON.stringify(value))).catch(error=>{console.error(JSON.stringify({stopped:true,error:String(error.message).slice(0,90),no_automatic_retry:true}));process.exitCode=1;});
