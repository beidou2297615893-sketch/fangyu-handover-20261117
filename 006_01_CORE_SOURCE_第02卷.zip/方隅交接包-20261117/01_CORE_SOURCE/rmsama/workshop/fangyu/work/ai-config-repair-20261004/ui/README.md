# 企业 AI 网页 UI 修复记录（2026-10-04）

范围：`work/app/src/web/workspace/{enterprise-ui.mjs,app.mjs,index.html}` 与 `work/cloud/workspace/site/` 对应镜像；`work/cloud/workspace/{openai-ui.test.cjs,enterprise-ui.test.cjs}`。`enterprise-model.mjs` 和 `site.css` 未改；原件在 `before/`。

- 员工资料读取不写入预算金额，管理员保留今日已用、上限、剩余金额；初始标记和登出重置均隐藏金额元素。员工可见的 AI 余额、预算、费用类状态、采集详情及全局错误提示统一为「AI 暂不可用／仍待分析」，不触碰评论正文中的租金预算。
- 普通网页企业配置在保存后用 `ai_config_read` 回读核对提交的服务商、模型、推理强度、启用状态、日预算、汇率和规则版本。保存响应未知时仅在回读字段相符且不涉及密钥时确认；密钥写入结果不可回读确认时明确提示。提交时立即清空密钥，其余草稿在失败时保留；控件在所有退出路径解锁。
- 管理员 AI 配置预算表单保留；服务器 AI 费用、token 统计及密钥存储逻辑未改。现有等待动效与视觉布局未动。

验证：`node --check` 对 `enterprise-ui.mjs`、`app.mjs` 通过；`node --test` 对 `enterprise-ui.test.cjs`、`collection-progress-wiring.test.cjs`、`openai-ui.test.cjs`、`site.test.cjs` 共 48 项通过。五个 UI 资产源文件与云候选镜像 SHA256 一致。未部署、未访问真实 API、未打开用户浏览器；配置真实保存仍需合并后由主任务验证。
