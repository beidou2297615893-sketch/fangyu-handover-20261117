const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const ui=fs.readFileSync(path.join(__dirname,'site/enterprise-ui.mjs'),'utf8');
const labelSource=ui.match(/export function aiModelStatus\([^]*?\n\}/)[0].replace('export ','');
const aiModelStatus=vm.runInNewContext(`${labelSource};aiModelStatus`);
const catalog=[{id:'gpt-6.1-sol',provider:'openai',label:'GPT-6.1 Sol',reasoning_efforts:['low','medium','high','xhigh','max']},
 {id:'gpt-5.4-mini',provider:'openai',label:'GPT-5.4 Mini',reasoning_efforts:['none','low','medium','high','xhigh']},
 {id:'deepseek-flash',provider:'deepseek',label:'DeepSeek Flash',reasoning_efforts:[]}];
const config={provider:'openai',model:'gpt-6.1-sol',enabled:true,configured:true,reasoning_effort:'low',revision:2,model_catalog:catalog,
 providers:{openai:{configured:true,model:'gpt-6.1-sol',reasoning_effort:'low'},deepseek:{configured:true,model:'deepseek-flash'}}};
test('model status follows configured, busy and actual identity and refuses invented names',()=>{
 assert.equal(aiModelStatus(),'AI 待配置');
 assert.equal(aiModelStatus({profile:{...config,enabled:false}}),'GPT‑6.1 Sol · 未启用');
 assert.equal(aiModelStatus({profile:config}),'GPT‑6.1 Sol · 已配置');
 assert.equal(aiModelStatus({profile:config,keywordBusy:true}),'GPT‑6.1 Sol · 正在联想关键词');
 assert.equal(aiModelStatus({profile:config,analysis:{status:'running',model:'gpt-5.4-mini-2026-03-17'}}),'GPT‑5.4 mini（2026-03-17） · 正在分析');
 assert.equal(aiModelStatus({profile:{...config,model:'gpt-6.6'}}),'AI 模型待核对');
 assert.doesNotMatch(aiModelStatus({profile:{...config,model:'secret-do-not-render'}}),/secret/);
});
function makeHarness(){
 const elements=new Map();
 const get=id=>{
  if(!elements.has(id))elements.set(id,{value:'',checked:false,hidden:false,disabled:false,textContent:'',href:'',classList:{remove(){}},replaceChildren(...items){this.options=items;this.value=items[0]?.value||'';}});
  return elements.get(id);
 };
 get('ai-provider').value='openai';
 const source=ui.slice(ui.indexOf('function renderAiProvider('),ui.indexOf('async function openAi('));
 const render=Function('deps',`const {$,el,initial}=deps;let aiConfig=initial;${source};return {renderAiProvider,renderAiEffort};`)({$:get,el:(_,text)=>({textContent:text,value:''}),initial:config});
 return {...render,get};
}
test('switching provider clears typed credentials and restores its own model and key status',()=>{
 const h=makeHarness();h.get('ai-key').value='fake-openai-secret';h.get('ai-clear-key').checked=true;
 h.renderAiProvider(true);assert.equal(h.get('ai-key').value,'');assert.equal(h.get('ai-clear-key').checked,false);
 assert.equal(h.get('ai-model').value,'gpt-6.1-sol');assert.equal(h.get('ai-effort').value,'low');
 h.get('ai-key').value='another-fake-openai-secret';h.get('ai-provider').value='deepseek';h.renderAiProvider(true);
 assert.equal(h.get('ai-key').value,'');assert.equal(h.get('ai-model').value,'deepseek-flash');
 assert.equal(h.get('ai-effort-label').hidden,true);assert.equal(h.get('ai-usd-rate-label').hidden,true);
 assert.match(h.get('ai-key-help').href,/platform\.deepseek\.com/);
 h.get('ai-provider').value='openai';h.renderAiProvider(true);assert.equal(h.get('ai-model').value,'gpt-6.1-sol');
 h.get('ai-model').value='gpt-5.4-mini';h.renderAiEffort();assert.equal(h.get('ai-effort').value,'none');
});
test('configuration submission locks provider and clears key after network failure',async()=>{
 const h=makeHarness();h.renderAiProvider(true);h.get('ai-key').value='fake-key-for-test';h.get('ai-enabled').checked=true;
 h.get('ai-daily-budget').value='5';h.get('ai-rules-version').value='rules';h.get('ai-usd-rate').value='7.5';
 const ids=['ai-provider','ai-model','ai-effort','ai-key','ai-enabled','ai-daily-budget','ai-usd-rate','ai-rules-version'];
 h.get('ai-config-form').elements=ids.map(h.get);let captured;
 const source=ui.slice(ui.indexOf('async function saveAi(){'),ui.indexOf('function renderUpdate(){'));
 const save=Function('deps',`const {$,cloud,profile,renderAiProvider,initial}=deps;let aiConfig=initial;${source};return saveAi;`)({$:h.get,initial:config,profile:async()=>{},renderAiProvider:h.renderAiProvider,
  cloud:{call:async(name,data)=>{captured={name,data};assert.ok(ids.every(id=>h.get(id).disabled));throw Error('offline');}}});
 await assert.rejects(save(),/offline/);assert.equal(captured.name,'ai_config_save');
 assert.equal(captured.data.config.provider,'openai');assert.equal(captured.data.config.reasoning_effort,'low');
 assert.equal(captured.data.api_key,'fake-key-for-test');assert.equal(h.get('ai-key').value,'');
 assert.ok(ids.every(id=>!h.get(id).disabled));
});
