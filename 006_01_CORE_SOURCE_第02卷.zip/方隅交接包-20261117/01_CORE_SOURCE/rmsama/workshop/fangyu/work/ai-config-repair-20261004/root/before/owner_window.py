"""Native owner portal using the already-delivered WebView2 shell."""
import ctypes,json,os,subprocess,sys,threading,time
from pathlib import Path
import owner_admin as portal
from desktop import run_desktop,focus_process_window

class Host:
    def __init__(self):self.company={'id':'fangyu-owner-admin'};self.closing=False;self.stop=threading.Event()
    def close_owned_jobs(self):self.closing=True
    def shutdown(self):self.stop.set()
    def serve_forever(self,**kwargs):self.stop.wait()


def focus_owner_window(pid):
    # Only restore the WinForms top-level window of the mutex-owned local app.
    from ctypes import wintypes
    u=ctypes.windll.user32
    u.GetWindowThreadProcessId.argtypes=[wintypes.HWND,ctypes.POINTER(wintypes.DWORD)]
    u.GetClassNameW.argtypes=[wintypes.HWND,wintypes.LPWSTR,ctypes.c_int]
    u.ShowWindow.argtypes=[wintypes.HWND,ctypes.c_int]
    u.SetForegroundWindow.argtypes=[wintypes.HWND]
    matches=[]
    CB=ctypes.WINFUNCTYPE(wintypes.BOOL,wintypes.HWND,wintypes.LPARAM)
    def visit(handle,_):
        owner=wintypes.DWORD();u.GetWindowThreadProcessId(handle,ctypes.byref(owner))
        if owner.value==pid:
            name=ctypes.create_unicode_buffer(200);u.GetClassNameW(handle,name,200)
            if name.value.startswith('WindowsForms10.Window'):matches.append(handle)
        return True
    callback=CB(visit);u.EnumWindows(callback,0)
    if not matches:return False
    u.ShowWindow(matches[0],9);u.SetForegroundWindow(matches[0]);return True


def main():
    from ctypes import wintypes
    kernel=ctypes.windll.kernel32
    kernel.CreateMutexW.argtypes=[ctypes.c_void_p,wintypes.BOOL,wintypes.LPCWSTR];kernel.CreateMutexW.restype=wintypes.HANDLE
    kernel.CloseHandle.argtypes=[wintypes.HANDLE]
    handle=kernel.CreateMutexW(None,False,'Local\\FangyuOwnerAdminWindow20261004')
    if not handle:raise RuntimeError('owner_window_lock_failed')
    try:
        if kernel.GetLastError()==183:
            marker=portal.read_private(portal.PRIVATE/'window.dpapi')
            if not focus_owner_window(int(marker['pid'])):raise RuntimeError('owner_window_waiting')
            return
        state=portal.active_runtime()
        if state is None:
            subprocess.Popen([sys.executable,str(portal.HOME/'owner_admin.py'),'--no-browser'],cwd=str(portal.PROJECT),creationflags=subprocess.CREATE_NO_WINDOW)
            deadline=time.monotonic()+15
            while time.monotonic()<deadline:
                state=portal.active_runtime()
                if state:break
                time.sleep(.15)
            if not state:raise RuntimeError('owner_service_not_ready')
        portal.write_private(portal.PRIVATE/'window.dpapi',{'pid':os.getpid(),'server_pid':state['pid']})
        host=Host()
        def ready(window):
            # Confirm the native renderer and actual app markup, without operating user browsers.
            if window.evaluate_js('document.title')!='方隅管理后台':raise RuntimeError('owner_page_not_loaded')
            window.show()
            proof={'pid':os.getpid(),'title':'方隅管理后台','native_renderer':'edgechromium','login_form_source_present':False,'native_loaded_title_confirmed':True,'source':'native loaded callback'}
            (portal.HOME/'native-window-proof.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        run_desktop(host,state['origin']+'/#'+state['launch'],portal.PRIVATE/'desktop','方隅管理后台',ready_callback=ready,ready_timeout=30)
    finally:kernel.CloseHandle(handle)

if __name__=='__main__':
    try:main()
    except Exception:
        ctypes.windll.user32.MessageBoxW(None,'管理后台未打开。请检查网络或联系维护人员恢复本机授权。','方隅管理后台',0x10)
        raise SystemExit(1)
