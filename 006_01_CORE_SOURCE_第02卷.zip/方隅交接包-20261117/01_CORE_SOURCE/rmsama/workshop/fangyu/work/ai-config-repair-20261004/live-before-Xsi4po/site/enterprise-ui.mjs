const {effectiveIntent,intentFacts,intentLabels,continuousPayload,matchingContinuousTask,continuousStartAction,continuousPresentation,groupComments,updatePresentation,displayCommentDate,workspaceHeaderDate,replyAccountSelection}=await import(new URL('?asset=enterprise-model.mjs',import.meta.url));
const $=id=>document.getElementById(id);
const el=(tag,text,cls)=>{const n=document.createElement(tag);if(text!==undefined)n.textContent=String(text);if(cls)n.className=cls;return n;};
export function displayIntent(lead){
 if(lead?.analysis_status==='missing_text'&&!lead.manual_intent&&!lead.ai_intent&&!String(lead.text||'').trim())
  return {status:'pending',level:null,label:'待核实',kind:'uncertain',reason:'评论正文缺失，补齐后自动分析'};
 return effectiveIntent(lead);
}
export function aiModelStatus({profile={},analysis={},keywordBusy=false}={}){
 const labels={'gpt-6.1-sol':'GPT‑6.1 Sol','gpt-5.4-mini':'GPT‑5.4 mini','deepseek-flash':'DeepSeek Flash','deepseek-v4-pro':'DeepSeek V4 Pro'};
 const labelFor=model=>{
  if(Object.hasOwn(labels,model))return labels[model];
  if(typeof model==='string')for(const [id,label] of Object.entries(labels))if(model.startsWith(id+'-')&&/^\d{4}-\d{2}-\d{2}$/.test(model.slice(id.length+1)))return `${label}（${model.slice(id.length+1)}）`;
  return '';
 };
 if(!profile.configured)return 'AI 待配置';
 const label=labelFor(profile.model);if(!label)return 'AI 模型待核对';
 if(!profile.enabled)return `${label} · 未启用`;
 if(keywordBusy)return `${label} · 正在联想关键词`;
 if(analysis.status==='running')return `${labelFor(analysis.model)||label} · 正在分析`;
 return `${label} · ${analysis.status==='paused'?'分析已暂停':'已配置'}`;
}
export function analysisStatusView({analysis={},profileStatus='unknown',pending=null,imported=0,taskId='',city=''}){
 const code=analysis.code||'',balance=code==='AI_PROVIDER_BALANCE',providerAuth=code==='AI_PROVIDER_AUTH';
 const budget=code==='AI_DAILY_BUDGET',config=code==='AI_NOT_CONFIGURED',service=code==='AI_TRANSACTION_UNAVAILABLE';
 const context=code==='AI_CONTEXT_REQUIRED',missing=Number(analysis.excluded_missing_text||0);
 const enabled=profileStatus==='enabled',saved=Number(imported||0)>0||Number(pending||0)>0||missing>0;
 const safeMessage=typeof analysis.message==='string'&&analysis.message.length<=180&&!/token|cookie|Traceback|Error:|https?:\/\//i.test(analysis.message)?analysis.message:'';
 const summary=balance?'AI 余额不足':providerAuth?'AI 密钥需检查':context?'AI 待补范围':
  profileStatus==='not_configured'||config?'AI 待配置':profileStatus==='disabled'?'AI 未启用':budget?'AI 预算已用完':
  service||profileStatus==='unavailable'?'AI 暂不可用':missing&&!pending?'无正文待核实':pending>0?`待分析 ${pending} 条`:'分析状态';
 const state=balance?(safeMessage&&/余额|充值/.test(safeMessage)?safeMessage:'企业 AI 余额不足；请管理员充值后继续分析，评论已保存'):
  providerAuth?(safeMessage&&/密钥|API/.test(safeMessage)?safeMessage:'企业 AI 密钥需管理员检查；评论仍待分析'):
  context?(!String(city||'').trim()?'补充任务城市后自动分析；评论已保存':safeMessage||'核对帖子与评论资料后自动分析'):
  missing&&!pending?`${missing} 条评论正文缺失，待核实；补齐后自动分析`:
  profileStatus==='not_configured'?saved?'评论已保存；企业 AI 尚未配置，待管理员启用':'企业 AI 尚未配置，当前不会自动分析':
  profileStatus==='disabled'?saved?'评论已保存；企业 AI 未启用，待管理员启用':'企业 AI 未启用，当前不会自动分析':
  profileStatus==='unavailable'?'AI 状态暂不可用，请核对分析结果':!enabled?'AI 状态待读取':
  budget?'今日 AI 预算已用完，明日恢复分析':config?'企业 AI 尚未启用，请联系管理员配置':
  service?'企业 AI 暂不可用，评论待分析':safeMessage||(pending!==null?`待分析 ${pending} 条`:'采集后自动分析');
 const retryVisible=!!taskId&&enabled&&!budget&&!config&&!service&&
  (analysis.status==='pending'&&code&&(analysis.retry_count===undefined||analysis.retry_count>=3)||
   ['failed','retry_wait','paused'].includes(analysis.status));
 return {summary,state,retryVisible,retryLabel:balance?'继续分析':providerAuth?'检查密钥后继续分析':'重新分析',enabled};
}
const ANALYSIS_FAILURE_TEXT=Object.freeze({
 AI_PROVIDER_BALANCE:'企业 AI 余额不足，充值后点“继续分析”',
 AI_PROVIDER_AUTH:'企业 AI 密钥需管理员检查；这不是员工登录问题',
 AI_DAILY_BUDGET:'今日企业 AI 预算已用完，评论已保存，明日继续分析',
 AI_BILLING_UNKNOWN:'AI 费用尚未核实，评论已保存，请管理员核对后继续分析',
 AI_NOT_CONFIGURED:'企业 AI 尚未配置，请管理员启用后继续分析',
 AI_CONFIG_CHANGED:'企业 AI 模型已变化，请重新分析',
 AI_CONTEXT_REQUIRED:'补充任务城市或缺失资料后自动分析',
 AI_INVALID_OUTPUT:'AI 返回未通过校验，评论仍待分析，请管理员核对',
});
const KEYWORD_FAILURE_TEXT=Object.freeze({
 AI_PROVIDER_BALANCE:'企业 AI 余额不足，请管理员充值后重新推荐',
 AI_PROVIDER_AUTH:'企业 AI 密钥需管理员检查，修复后重新推荐；这不是员工登录问题',
 AI_DAILY_BUDGET:'今日企业 AI 预算已用完，请明日重新推荐',
 AI_BILLING_UNKNOWN:'AI 费用尚未核实，请管理员核对后重新推荐',
 AI_NOT_CONFIGURED:'企业 AI 尚未配置，请管理员启用后重新推荐',
 AI_CONFIG_CHANGED:'企业 AI 模型已变化，请重新推荐关键词',
 AI_CONTEXT_REQUIRED:'请补充任务城市或缺失资料后重新推荐',
 AI_INVALID_OUTPUT:'AI 关键词返回未通过校验，请管理员核对后重新推荐',
});
export function commandFailure(name,answer){
 const code=typeof answer?.result?.code==='string'?answer.result.code:'';
 const knownAI=name==='intent_analyze_pending'||name==='keyword_recommend';
 const messages=name==='keyword_recommend'?KEYWORD_FAILURE_TEXT:ANALYSIS_FAILURE_TEXT;
 const fixed=knownAI&&Object.hasOwn(messages,code)?messages[code]:'';
 const message=knownAI?fixed||'操作尚未完成，请核对状态':answer?.error||'操作尚未完成，请核对状态';
 const error=Error(message);
 if(fixed)error.code=code;
 if(['uncertain','expired','queued','running','claimed'].includes(answer?.status)||!answer){error.requestId=answer?.requestId;error.commandId=answer?.commandId;}
 return error;
}
export function mediaUrl(value){try{const u=new URL(String(value||''));return u.protocol==='https:'&&!u.username&&!u.password&&/(^|\.)(xhscdn\.com|xiaohongshu\.com)$/.test(u.hostname)?u.href:'';}catch{return '';}}
export function avatarSource(url,leadId='',kind='author',localWorkspace=false){
 if(localWorkspace&&typeof leadId==='string'&&leadId.trim()&&leadId.length<=160&&['author','post_author'].includes(kind))return `/saved-avatar/${encodeURIComponent(leadId)}?kind=${kind}`;
 return mediaUrl(url)||'?asset=fy-icon-16-user.png';
}
function setAvatar(n,url,name='',leadId='',kind='author',localWorkspace=false){n.alt=name?`${name}的头像`:'';n.referrerPolicy='no-referrer';n.loading='lazy';n.onerror=()=>{n.onerror=null;n.src='?asset=fy-icon-16-user.png';n.dataset.fallback='true';};const source=avatarSource(url,leadId,kind,localWorkspace);n.src=source;n.dataset.fallback=String(source==='?asset=fy-icon-16-user.png');return n;}
const avatar=(url,name,leadId='',kind='author',localWorkspace=false)=>setAvatar(el('img',undefined,'person-avatar'),url,name,leadId,kind,localWorkspace);
function sourceLink(url,title){const n=el(/^https:\/\//.test(url||'')?'a':'span',title);if(n.tagName==='A'){n.href=url;n.target='_blank';n.rel='noopener noreferrer';}return n;}
export async function confirmFreshCollectionAccess(action,refresh,held){
 if(action==='continuous_pause')return;
 if(action!=='continuous_start'&&action!=='continuous_resume')throw Error('未知采集操作');
 await refresh();
 if(held())throw Error('持续只读验收未开放或已到期');
}
export function requireAccountReviewClear(accounts,accountId,localWorkspace=true){
 const account=(accounts||[]).find(item=>item.id===accountId&&item.platform==='xiaohongshu');
 if(!account||account.status!=='ready')throw Error('所选小红书账号状态已变化，请刷新账号状态');
 if(account.requires_review===true){
  const reason=account.review_reason;
  const destination=localWorkspace?'左侧「小红书账号」':'对应电脑的方隅工作台「小红书账号」';
  throw Error(reason==='verification_required'?`采集请求暂未被小红书接受，请查看手机是否有提醒，并到${destination}核对`:reason==='unknown'?`账号安全记录暂无法核对，请稍后在${destination}检查`:`账号需人工复核，请到${destination}核对`);
 }
 return account;
}
export function createEnterpriseWorkspace({execute,cloud,getState,getUser,held,collectionHeld,onError,onPage,onWorkspaceAccounts=()=>{},localWorkspace=false,beforeStart=async()=>{}}) {
 let keywordsExpanded=false,worklistTimer=0,worklistRefreshing=false;
 let keywords=[],selected=new Set(),libraryId='',taskId='',hydratedTaskId='',savedForStart=null,savedForStartDevice='',pendingSave=null,task=null,pollTimer=0,clockTimer=0,queueTimer=0,detailFrame=0,confirmedReplies=new Set(),confirmedAccount='',worklist='pending',groupBy='note',groupKey='',offset=0,groupOffset=0,total=0,groupsTotal=0,groupRows=[],expandedGroups=new Set(),selectionId='',selectedLead=null,reply=null,replyNeedsCheck=false,queue=null,rows=[],readGeneration=0,detailGeneration=0,disposed=false,aiProfileStatus='unknown',aiProfile={},aiConfig=null,keywordBusy=false,analysisBusy=false,updateState=null,updateBusy=false,updateError='';
 const form=$('task'),field=name=>form.elements.namedItem(name),feedback=$('continuous-feedback');
 const settingsDialog=$('collection-dialog');let settingsReturnFocus=null,invalidQueued=false;
 $('continuous-heading').after(feedback);
 const progressSteps=$('continuous-steps'),sourceStepLabel=el('span','搜索帖子'),sourceDoneIcon=el('img',undefined,'continuous-step-done-icon');
 sourceDoneIcon.src='?asset=fy-icon-50-check.png';sourceDoneIcon.alt='';sourceDoneIcon.setAttribute('aria-hidden','true');progressSteps.firstElementChild.replaceChildren(sourceDoneIcon,sourceStepLabel);
 let headerDateTimer=0;
 function showHeaderDate(){const node=$('workspace-date');if(node)node.textContent=workspaceHeaderDate();}
 function startHeaderDate(){if(!$('workspace-date'))return;showHeaderDate();if(!headerDateTimer){headerDateTimer=setInterval(showHeaderDate,60000);headerDateTimer.unref?.();}}
 startHeaderDate();
 const safetyLink=el('button','去小红书账号','text-button');safetyLink.type='button';safetyLink.addEventListener('click',()=>onPage('devices'));safetyLink.hidden=true;$('continuous-toggle').after(safetyLink);
 let feedbackTimer=0,snapshotUnconfirmed=false;
 function report(message,error=false){clearTimeout(feedbackTimer);feedback.textContent=message;feedback.hidden=!message;feedback.classList.toggle('is-error',error);if(message&&!error&&!/正在|核对/.test(message))feedbackTimer=setTimeout(()=>{feedback.hidden=true;feedback.textContent='';},5000);}
 function markSnapshotUnconfirmed(){snapshotUnconfirmed=true;report('状态读取未完成；下方是上次进度，请刷新状态核对',true);}
 function renderCollectionSummary(){const city=field('city').value.trim()||'城市未设置',range=field('comment_date_range').value,rangeText={3:'近三个月',6:'近六个月',12:'近一年',custom:'自定义日期'}[range]||'时间未设置';$('collection-summary-text').textContent=`${city} · ${rangeText} · 已选 ${chosen().length} 个关键词`;}
 function openCollectionDialog(trigger,focusTarget=null,message=''){if(!settingsDialog.open){settingsReturnFocus=trigger||document.activeElement;settingsDialog.showModal();}$('keyword-options').open=true;syncKeywordAdjustment();if(focusTarget?.closest?.('.manual-keywords'))focusTarget.closest('.manual-keywords').open=true;$('collection-dialog-feedback').textContent=message;requestAnimationFrame(()=>{if(settingsDialog.open)(focusTarget||field('city')).focus();});}
 function closeCollectionDialog(){if(settingsDialog.open)settingsDialog.close();}
 async function action(name,data={}){const answer=await execute(name,data);if(answer?.status!=='succeeded')throw commandFailure(name,answer);return answer.result||{};}
 const canReply=()=>getUser()?.can_reply!==false;
 const locks=new WeakSet();
 function guard(fn){return async event=>{event?.preventDefault();const button=event?.currentTarget;if(button?.disabled||button&&locks.has(button))return;if(button)locks.add(button);if(button instanceof HTMLButtonElement){button.disabled=true;button.setAttribute('aria-busy','true');}try{await fn(event);}catch(error){report(error.message||'操作未完成',true);if(['reply-save','reply-confirm','queue-send','queue-prepare','queue-refresh','queue-cancel'].includes(button?.id))$('reply-feedback').textContent=error.message||'操作结果待核对';if(button?.id==='ai-config-form'){$('ai-configured').textContent=error.message||'企业配置保存失败';$('ai-configured').classList.add('is-error');}onError(error);}finally{if(button)locks.delete(button);if(button instanceof HTMLButtonElement){button.disabled=false;button.removeAttribute('aria-busy');}if(['reply-save','reply-confirm','queue-send','queue-prepare','queue-refresh','queue-cancel'].includes(button?.id)){updateReply(false);renderQueue();}if(button?.id==='save-keywords')updateKeywordCount();if(button?.id==='continuous-toggle')renderContinuous();if(button?.id?.startsWith('update-')||button?.id==='open-update')renderUpdate();}};}
 function chosen(){return [...new Set([...selected,...String(field('keywords')?.value||'').split(/\n/).map(x=>x.trim()).filter(Boolean)])];}
 function context(){return {city:field('city').value.trim(),area:field('area').value.trim(),seeds:$('keyword-seed').value.split(/[\n，,]/).map(x=>x.trim()).filter(Boolean),count:Number($('keyword-count').value)};}
 function renderKeywords(){
  field('keywords').required=false;
  const host=$('keyword-groups');host.replaceChildren();
  const visible=keywordsExpanded?keywords:keywords.slice(0,6);
  const section=el('section',undefined,'keyword-group'),grid=el('div',undefined,'keyword-grid');section.append(grid);if(visible.length)host.append(section);
  for(const item of visible){const group=String(item.group||'').trim();const label=el('label',undefined,'keyword-option'),box=el('input'),copy=el('span',undefined,'keyword-copy'),title=el('span',item.keyword,'keyword-phrase');box.type='checkbox';box.checked=selected.has(item.keyword);box.setAttribute('aria-label',group?`${item.keyword}，分类：${group}`:item.keyword);if(group)label.title=`分类：${group}`;label.classList.toggle('checked',box.checked);
   box.addEventListener('change',()=>{box.checked?selected.add(item.keyword):selected.delete(item.keyword);label.classList.toggle('checked',box.checked);updateKeywordCount();});
   if(item.recommended===true)title.append(el('small','推荐','keyword-recommended'));else if(item.source==='task_selected')title.append(el('small','任务已选','keyword-task-selected'));copy.append(title);if(item.reason)copy.append(el('small',item.reason,'keyword-reason'));label.append(box,copy);grid.append(label);
  }
  if(!keywords.length)host.append(el('p','输入需求后可联想完整搜索词，也可手动增补关键词。','keyword-empty'));
  $('keywords-expand').hidden=keywords.length<=6;$('keywords-expand').textContent=keywordsExpanded?'收起关键词':`查看全部 ${keywords.length} 个`;
  const fromTask=keywords.length>0&&keywords.every(k=>k.source==='task_selected');
  $('keyword-heading-title').textContent='关键词';$('keywords-recommended').disabled=!keywords.some(k=>k.recommended===true);
  updateKeywordCount();
 }
 function updateKeywordCount(){const selectedWords=chosen(),preview=$('keyword-selected-preview');$('keyword-options-summary').textContent=`调整关键词 · 已选 ${selectedWords.length} 个`;$('keyword-selection-count').textContent=`· 已选 ${selectedWords.length} 个`;$('save-keywords').disabled=!libraryId;preview.replaceChildren(...(selectedWords.length?[...selectedWords.slice(0,3).map(word=>el('span',word,'keyword-chip')),...(selectedWords.length>3?[el('span',`另有 ${selectedWords.length-3} 个`,'keyword-chip-more')]:[])]:[el('span','尚未选择，点“调整”添加','keyword-preview-empty')]));renderCollectionSummary();}
 function syncKeywordAdjustment(){const open=$('keyword-options').open,button=$('keyword-adjust');button.textContent=open?'收起':'调整';button.setAttribute('aria-expanded',String(open));}
 async function recommend(){const data=context();if(!data.city){openCollectionDialog($('suggest-keywords'),field('city'),'先设置城市，再点“推荐词”');return;}if(!data.seeds.length)throw Error('请填写租房需求');
  keywordBusy=true;renderContinuous();report('AI 正在联想完整搜索词…');
  try{const result=await action('keyword_recommend',data);keywords=result.keywords||[];keywordsExpanded=false;libraryId=result.library_id||'';selected=new Set(keywords.filter(k=>k.recommended).map(k=>k.keyword));renderKeywords();openCollectionDialog($('suggest-keywords'),$('keyword-groups').querySelector('input')||field('keywords'),'已生成推荐词，请核对后点“完成调整”；采集仍需单独开始');if(['queued','running','waiting'].includes(task?.continuous?.status)){feedback.textContent='';feedback.hidden=true;}else report(result.cache_hit?'已复用关键词组合，待核对':'关键词已推荐，待核对');void profile();}
  finally{keywordBusy=false;renderContinuous();}
 }
 async function restoreLibrary(id){const answer=await action('keyword_library',id?{library_id:id}:{}),libraries=answer.items||[];const choice=id?libraries.find(x=>x.id===id):libraries[0];
  const host=$('keyword-library-list');host.replaceChildren();for(const entry of libraries){const b=el('button',`${entry.request?.city||'城市未提供'} · ${entry.keywords?.length||0} 个词`,'secondary');b.type='button';b.addEventListener('click',guard(()=>restoreLibrary(entry.id)));host.append(b);}
  if(!libraries.length)host.append(el('p','还没有收藏的关键词组合','help'));
  if(choice){libraryId=choice.id;keywords=choice.keywords||[];selected=new Set(choice.selected||keywords.filter(k=>k.recommended).map(k=>k.keyword));field('city').value=choice.request?.city||field('city').value;field('area').value=choice.request?.area||'';$('keyword-seed').value=(choice.request?.seeds||[]).join('，');renderKeywords();report('已读取本机词库');}
 }
 async function saveLibrary(){await action('keyword_library',{library_id:libraryId,selected:chosen()});report('关键词组合已收藏');}
 function cancelPoll(){clearInterval(worklistTimer);worklistTimer=0;clearTimeout(pollTimer);clearInterval(clockTimer);clearTimeout(queueTimer);pollTimer=clockTimer=queueTimer=0;}
 function schedule(failed=false){clearTimeout(pollTimer);const active=['queued','running'].includes(task?.continuous?.status);if(!disposed&&taskId&&getUser())pollTimer=setTimeout(()=>refreshContinuous().catch(error=>{onError(error);schedule(true);}),failed?60000:active?8000:30000);}
 function renderContinuous(){
  const account=getState().accounts?.find(item=>item.id===task?.account_id),view=continuousPresentation(task,Date.now(),account),host=$('continuous-panel');host.dataset.state=view.status;host.dataset.historyResolved=String(view.historyResolved);host.classList.toggle('is-active',view.active);$('continuous-heading').textContent='采集状态';if(view.active&&!feedback.classList.contains('is-error')&&/^(关键词已推荐|已复用关键词组合|关键词组合已收藏|已读取本机词库)/.test(feedback.textContent)){feedback.textContent='';feedback.hidden=true;}
  $('continuous-phase').textContent=view.heading;$('continuous-message').textContent=view.active?'':account?.requires_review===true&&!localWorkspace?'采集已暂停，请在对应电脑打开方隅工作台完成账号复核':view.message;
  const errorDetails=$('continuous-error-details'),errorText=$('continuous-error-text');if(errorText.textContent!==view.detail)errorDetails.open=false;errorText.textContent=view.detail;errorDetails.hidden=!view.detail;
  const values=[['continuous-read',view.read,'已读取'],['continuous-imported',view.imported,'累计新增'],['continuous-duplicates',view.duplicates,'重复'],['continuous-analyzed',task?.analysis?.last_analyzed,'最近分析']];
  for(const [id,n,label] of values)$(id).textContent=typeof n==='number'?`${label==='累计新增'?'新增':label} ${n} 条`:`${label==='累计新增'?'新增':label} —`;
  const elapsed=view.elapsed;$('continuous-elapsed').textContent=elapsed===null?'':`已运行 ${String(Math.floor(elapsed/60)).padStart(2,'0')}:${String(elapsed%60).padStart(2,'0')}`;
  $('continuous-next').textContent=view.nextSeconds===null?'':`等待下一次读取 ${view.nextSeconds} 秒`;
  renderCollectionSummary();
  let sameConditions=false;try{sameConditions=!!matchingContinuousTask(task?[task]:[],continuousPayload(Object.fromEntries(new FormData(form)),chosen()));}catch{}
  $('continuous-toggle').hidden=!taskId||!view.active&&(sameConditions||view.requiresLogin||account?.requires_review===true);$('continuous-toggle').disabled=view.status==='paused'&&task?.continuous?.inflight;$('continuous-toggle').textContent=view.active?'暂停采集':view.requiresLogin?'重新登录':account?.requires_review===true?'核对账号':'恢复采集';$('continuous-toggle').dataset.action=view.active?'continuous_pause':'continuous_resume';safetyLink.hidden=!!taskId||!view.requiresLogin&&account?.requires_review!==true;
  host.dataset.accountAction=String(!!taskId&&(view.requiresLogin||account?.requires_review===true));
  $('create-task').hidden=view.active;$('create-task').textContent=sameConditions&&!view.requiresLogin&&account?.requires_review!==true&&continuousStartAction(task)==='continuous_resume'?'恢复采集':'开始采集';$('continuous-spinner').hidden=!view.active;
  progressSteps.dataset.phase=view.phase||view.status;
  const sourceReached=['reading_comments','filtering','saving','waiting'].includes(view.phase),scope=task?.scope;
  sourceStepLabel.textContent='搜索';
  progressSteps.dataset.sourceDone=String(sourceReached&&['search_comments','comments'].includes(scope));
  progressSteps.dataset.searchDone=String(sourceReached&&scope==='search_comments');
  const status=analysisStatusView({analysis:task?.analysis||{},profileStatus:aiProfileStatus,pending:view.analysisPending,imported:task?.continuous?.imported,taskId,city:task?.city});
  $('analysis-details-summary').textContent=status.summary;$('analysis-state').textContent=status.state;
  $('ai-model-state').textContent=aiModelStatus({profile:aiProfile,analysis:analysisBusy?{status:'running'}:task?.analysis||{},keywordBusy});$('ai-model-state').dataset.busy=String(keywordBusy||analysisBusy||task?.analysis?.status==='running');
  if(view.active&&task?.analysis?.code==='AI_PROVIDER_BALANCE')$('continuous-message').textContent='AI 余额不足，评论已保存，待管理员充值';
  progressSteps.lastElementChild.hidden=!status.enabled;
  $('analysis-retry').hidden=!status.retryVisible;$('analysis-retry').textContent=status.retryLabel;
  const source=task?.progress?.current_source||task?.progress||{},title=source.content_title||source.note_title||'';$('continuous-source').hidden=!title;$('continuous-source').replaceChildren(...(title?[sourceLink(source.note_url||'',`来自：${title}`)]:[]));
 }
 async function refreshContinuous(){
  if(!taskId||disposed)return;const current=taskId,deviceId=getState().selected;
  try{
  if(localWorkspace){
   const snapshot=await action('workspace_state',{});
   if(current!==taskId||deviceId!==getState().selected||disposed)return;
   if(!Array.isArray(snapshot.tasks))throw Error('采集状态未完整读取，请刷新核对');
   if(Array.isArray(snapshot.accounts))onWorkspaceAccounts(snapshot.accounts);
   syncSnapshot({...snapshot,authoritative:true});
  }else{
   const result=await action('continuous_status',{task_id:taskId});
   if(current!==taskId||deviceId!==getState().selected||disposed)return;
   task={...task,...result.task,continuous:result.continuous||task?.continuous};renderContinuous();schedule();
  }
  }catch(error){if(current===taskId&&deviceId===getState().selected&&!disposed)markSnapshotUnconfirmed();throw error;}
  if($('workspace').dataset.page==='leads')void loadWorklist(offset).catch(onError);else if($('workspace').dataset.page==='tasks')void latest();
 }
 function syncSnapshot(snapshot){
  // A confirmed empty store must clear deleted progress even while conditions are edited.
  if(snapshot.authoritative&&Array.isArray(snapshot.tasks)&&!snapshot.tasks.length&&snapshot.truncated!==true&&!pendingSave){
   clearTimeout(pollTimer);clearInterval(clockTimer);pollTimer=clockTimer=0;
   taskId='';hydratedTaskId='';savedForStart=null;savedForStartDevice='';task=null;
   if(snapshotUnconfirmed){snapshotUnconfirmed=false;report('');}
   renderContinuous();return;
  }
  if(settingsDialog.open){
   const current=(snapshot.tasks||[]).find(item=>item.id===taskId);
   if(current){task=current;renderContinuous();}
   if(snapshot.authoritative&&snapshotUnconfirmed){snapshotUnconfirmed=false;report('');}
   schedule();
   return;
  }
  const tasks=snapshot.tasks||[],live=t=>t.continuous_enabled&&['queued','running','waiting'].includes(t.continuous?.status);
  const current=tasks.find(t=>t.id===taskId),active=tasks.find(live);
  const first=tasks.find(t=>t.continuous_enabled&&['queued','running','waiting','paused','blocked','failed','interrupted'].includes(t.continuous?.status));
  let editing=false;
  if(task&&hydratedTaskId===taskId)try{editing=!matchingContinuousTask([task],continuousPayload(Object.fromEntries(new FormData(form)),chosen()));}catch{editing=true;}
  if((editing||pendingSave)&&taskId&&!current)return;
  const candidate=current&&(editing||pendingSave||live(current)||!active)?current:active||current||(first&&matchingContinuousTask(tasks,first));
  if(snapshot.authoritative&&snapshotUnconfirmed){snapshotUnconfirmed=false;report('');}
  if(candidate){task=candidate;taskId=candidate.id;if(hydratedTaskId!==taskId){field('city').value=task.city||'';field('area').value=task.area||'';field('comment_date_range').value={'3months':'3','6months':'6','12months':'12'}[task.comment_date_range]||task.comment_date_range||'3';field('comment_date_from').value=task.comment_date_from||'';field('comment_date_to').value=task.comment_date_to||'';$('custom-comment-dates').hidden=task.comment_date_range!=='custom';$('keyword-seed').value=(task.keywords||[]).slice(0,3).join('，');keywords=(task.keywords||[]).map(keyword=>({keyword,group:'已选关键词',recommended:false,source:'task_selected'}));selected=new Set(task.keywords||[]);field('keywords').value='';field('account_id').value=task.account_id||field('account_id').value;hydratedTaskId=taskId;renderKeywords();if(!settingsDialog.open)$('keyword-options').open=false;syncKeywordAdjustment();}renderContinuous();if(!clockTimer)clockTimer=setInterval(renderContinuous,1000);schedule();}
  else{taskId='';hydratedTaskId='';task=null;renderContinuous();}
 }
 async function start(event){
  if(settingsDialog.open){closeCollectionDialog();return;}
  if(pendingSave)throw Error('保存结果待核对，请先刷新状态');
   const values=Object.fromEntries(new FormData(event.currentTarget));let data;
   try{data=continuousPayload(values,chosen());}catch(error){const target=!field('city').value.trim()?field('city'):field('comment_date_range').value==='custom'&&(!field('comment_date_from').value||!field('comment_date_to').value||field('comment_date_from').value>field('comment_date_to').value)?!field('comment_date_from').value?field('comment_date_from'):field('comment_date_to'):field('keywords');openCollectionDialog(event.submitter||$('create-task'),target,error.message);return;}
   const deviceId=getState().selected;
   const unchanged=()=>!!matchingContinuousTask([{...data,id:'requested'}],continuousPayload(Object.fromEntries(new FormData(form)),chosen()));
  const account=getState().accounts.find(a=>a.id===data.account_id&&a.platform==='xiaohongshu'&&a.status==='ready');if(!account)throw Error('请先登录小红书账号');
   await confirmFreshCollectionAccess('continuous_start',()=>beforeStart(data.account_id,'continuous_start'),collectionHeld);
   if(getState().selected!==deviceId||!unchanged())throw Error('当前电脑或采集条件已变化，请重新确认');
   const snapshot=await action('workspace_state',{});
   if(getState().selected!==deviceId)throw Error('当前电脑已变化，请重新读取任务');
    requireAccountReviewClear(snapshot.accounts,data.account_id,localWorkspace);
    if(!unchanged())throw Error('采集条件已变化，请重新确认');
   const matches=(snapshot.tasks||[]).filter(item=>matchingContinuousTask([item],data));
   const active=matches.find(item=>continuousStartAction(item)==='display');
   if(savedForStart&&!matchingContinuousTask([savedForStart],data))savedForStart=null;
   const savedOnDevice=savedForStartDevice===deviceId?matchingContinuousTask(savedForStart?[savedForStart]:[],data):null;
   const existing=active||matchingContinuousTask(matches,data)||savedOnDevice;
   if(!existing&&snapshot.truncated)throw Error('历史任务列表未完整读取，暂勿新建；请刷新或联系管理员核对原任务');
   if(existing){
    taskId=existing.id;hydratedTaskId=taskId;task=existing;
    const next=continuousStartAction(existing);
    if(next==='display'||existing.continuous?.inflight){savedForStart=null;renderContinuous();schedule();report('');return;}
    const result=await action(next,{task_id:taskId});savedForStart=null;task={...task,...result.task,continuous:result.continuous};
    if(!settingsDialog.open)$('keyword-options').open=false;renderContinuous();if(!clockTimer)clockTimer=setInterval(renderContinuous,1000);schedule();report('');void profile();return;
   }
   report('正在保存采集条件…');let saved;
   try{saved=await action('task_save',data);}catch(error){if(error.requestId){pendingSave={commandId:error.commandId,requestId:error.requestId,data,deviceId};$('create-task').dataset.uncertain='true';}report(error.requestId?'保存结果待核对，请刷新状态，暂勿重复开始':error.message,true);throw error;}
    taskId=saved.id;hydratedTaskId=taskId;task={...data,...saved};if(!taskId)throw Error('保存结果待核对，请刷新状态');
    savedForStart=task;savedForStartDevice=deviceId;if(!unchanged())throw Error('采集条件已变化；旧条件已保存，请重新点击开始');report('采集条件已保存，正在开始…');const result=await action('continuous_start',{task_id:taskId});savedForStart=null;task={...task,...result.task,continuous:result.continuous};if(!settingsDialog.open)$('keyword-options').open=false;renderContinuous();if(!clockTimer)clockTimer=setInterval(renderContinuous,1000);schedule();report('');void profile();
 }
 async function toggle(){if(!taskId)return;const account=getState().accounts?.find(item=>item.id===task?.account_id),view=continuousPresentation(task,Date.now(),account);if(!view.active&&(view.requiresLogin||account?.requires_review===true)){onPage('devices');return;}const name=$('continuous-toggle').dataset.action,currentTaskId=taskId,accountId=task?.account_id;await confirmFreshCollectionAccess(name,()=>beforeStart(accountId,name),collectionHeld);if(currentTaskId!==taskId||accountId!==task?.account_id)throw Error('采集任务或账号已变化，请刷新后重试');const result=await action(name,{task_id:taskId});task={...task,...result.task,continuous:result.continuous};if(name==='continuous_resume'&&!settingsDialog.open)$('keyword-options').open=false;renderContinuous();report('');schedule();}
 async function profile(){if(!getUser())return;try{const result=await cloud.call('ai_profile'),p=result.config||result,b=result.budget;if(!getUser())return;aiProfile={provider:p.provider,model:p.model,enabled:!!p.enabled,configured:!!p.configured,reasoning_effort:p.reasoning_effort,revision:p.revision};aiProfileStatus=!p.configured?'not_configured':p.enabled?'enabled':'disabled';$('ai-budget-state').textContent=b?`AI 今日已用 ¥${Number(b.spent_cny||0).toFixed(3)} / ¥${b.limit_cny} · 剩余 ¥${Number(b.remaining_cny||0).toFixed(3)}`:p.configured?'企业 AI 已配置':'企业 AI 待管理员配置';if(!p.enabled)$('ai-budget-state').textContent+=' · 未启用';}catch{aiProfile={};aiProfileStatus='unavailable';$('ai-budget-state').textContent='AI 预算状态暂不可用';}renderContinuous();}
 async function latest(){if(!getUser()||!getState().selected)return;try{const result=await action('leads_list',{worklist:'all',sort:'newest',offset:0,limit:3});const host=$('latest-discoveries');host.replaceChildren();for(const lead of result.items||[]){
  const row=el('div',undefined,'discovery-row'),person=el('button',undefined,'discovery-person'),copy=el('button',lead.text||'评论正文未提供','discovery-comment'),intent=effectiveIntent(lead),badge=el('span',intent.label,'intent-tag');person.type=copy.type='button';badge.dataset.level=intent.kind;
  const identity=el('span');identity.append(el('strong',lead.author||'用户未提供'),el('small',displayCommentDate(lead.published_at)));person.append(avatar(lead.author_avatar_url,lead.author,lead.id,'author',localWorkspace),identity);
  const open=()=>{onPage('leads');void loadWorklist(0).then(()=>selectLead(lead));};person.addEventListener('click',open);copy.addEventListener('click',open);
  const source=el('div',undefined,'discovery-source');source.append(sourceLink(lead.note_url||lead.url,lead.content_title||'查看原帖'));
  row.append(person,copy,source,badge,el('span',lead.reply_state==='sent'?'已回复':'未回复','reply-tag'));host.append(row);
 }if(!result.items?.length)host.append(el('p','还没有发现评论','help'));}catch{/* Keep prior results on a transient read failure. */}}
 function worklistParams(page){return {worklist,sort:'intent',group_by:groupBy,group_offset:groupOffset,offset:page,limit:25,...(groupKey?{group_key:groupKey}:{}),...($('worklist-intent').value?{intent_level:$('worklist-intent').value}:{}),...($('worklist-query').value.trim()?{query:$('worklist-query').value.trim()}: {})};}
 async function openPending(){worklist='pending';offset=0;groupKey='';groupOffset=0;$('worklist-query').value='';$('worklist-intent').value='';closeDetail();await loadWorklist(0);}
 function scheduleDetailViewport(){if(detailFrame||disposed)return;detailFrame=requestAnimationFrame(()=>{detailFrame=0;const detail=$('reply-detail');if(detail.hidden||window.matchMedia('(max-width:980px)').matches){detail.style.removeProperty('--reply-visible-height');return;}const top=detail.getBoundingClientRect().top;detail.style.setProperty('--reply-visible-height',`${Math.max(0,Math.floor(window.innerHeight-top-16))}px`);});}
 async function loadWorklist(page=0){
  if(!worklistTimer)worklistTimer=setInterval(async()=>{if(disposed||taskId||worklistRefreshing||!getUser()||$('workspace').dataset.page!=='leads')return;worklistRefreshing=true;try{await loadWorklist(offset);}catch(error){onError(error);}finally{worklistRefreshing=false;}},30000);
  const generation=++readGeneration,device=getState().selected,params=worklistParams(page);$('worklist-feedback').textContent='正在读取评论…';$('pending-bell-dot').hidden=true;
  try{const result=await action('leads_list',params);if(generation!==readGeneration||device!==getState().selected||disposed)return;
   rows=result.items||[];total=result.total||0;offset=page;groupRows=result.groups||[];groupsTotal=result.groups_total||0;renderWorklist();$('pending-bell-dot').hidden=!(params.worklist==='pending'&&!params.group_key&&!params.intent_level&&!params.query&&params.group_offset===0&&page===0&&Number.isFinite(Number(result.total))&&Number(result.total)>0);$('worklist-feedback').textContent=rows.length?'':'没有符合条件的评论';
   if(selectionId&&!rows.some(x=>x.id===selectionId))closeDetail();else if(selectionId){selectedLead=rows.find(x=>x.id===selectionId);renderDetailInfo(selectedLead);}
  }catch(error){if(generation===readGeneration){$('worklist-feedback').textContent='评论读取失败，请重试';throw error;}}
 }
 function renderWorklist(){
  if($('workspace').dataset.page==='leads')$('page-heading').textContent=groupBy==='note'?'帖子分组的跟进工作台':'评论跟进工作台';
  const host=$('worklist-groups');host.replaceChildren();$('pending-tab').classList.toggle('active',worklist==='pending');$('all-tab').classList.toggle('active',worklist==='all');
  $('pending-tab').setAttribute('aria-selected',String(worklist==='pending'));$('all-tab').setAttribute('aria-selected',String(worklist==='all'));
  (worklist==='pending'?$('pending-count'):$('all-count')).textContent=String(total);$('pending-nav-count').textContent=worklist==='pending'?String(total):$('pending-nav-count').textContent;
  const groups=groupComments(rows,groupBy);for(const group of groups){const section=el('section',undefined,'post-group'),heading=el('div',undefined,'post-group-heading'),count=groupRows.find(g=>g.key===group.key)?.count,expansionKey=`${groupBy}:${group.key}`;
   section.dataset.groupKey=expansionKey;
   const fold=el('button',undefined,'group-fold');fold.setAttribute('aria-label','收起评论');fold.type='button';fold.setAttribute('aria-expanded','true');heading.append(groupBy==='note'?sourceLink(group.url,group.label):el('span',group.label),el('span',count===undefined?`本页 ${group.items.length} 条评论`:`${count} 条评论`,'group-count'));section.append(heading);
   if(groupBy==='note'){const first=group.items[0]||{},meta=el('div',undefined,'group-post-meta');if(first.content_author_avatar_url||localWorkspace&&first.id)meta.append(avatar(first.content_author_avatar_url,group.author,first.id,'post_author',localWorkspace));meta.append(el('span',group.author||'博主未提供'));if(first.content_published_at)meta.append(el('time',displayCommentDate(first.content_published_at)));heading.append(meta);}const body=el('div',undefined,'post-group-comments');fold.addEventListener('click',()=>{body.hidden=!body.hidden;fold.classList.toggle('collapsed',body.hidden);fold.setAttribute('aria-label',body.hidden?'展开评论':'收起评论');fold.setAttribute('aria-expanded',String(!body.hidden));});heading.prepend(fold);
   const selectedBeyond=group.items.slice(3).some(item=>item.id===selectionId),expanded=expandedGroups.has(expansionKey)||selectedBeyond;
   for(const [index,lead] of group.items.entries()){const card=el('button',undefined,'work-comment');card.type='button';card.dataset.leadId=lead.id;card.hidden=index>=3&&!expanded;card.classList.toggle('selected',lead.id===selectionId);card.setAttribute('aria-pressed',String(lead.id===selectionId));const copy=el('div',undefined,'work-comment-copy'),top=el('div',undefined,'work-comment-top'),intent=displayIntent(lead),badge=el('span',intent.label,'intent-tag');badge.dataset.level=intent.kind;
    top.append(el('strong',lead.author||'用户未提供'),badge,el('span',lead.reply_state==='sent'?'已回复':lead.reply_state==='unknown'?'结果待核对':lead.reply_state==='draft'?'草稿':'未回复','reply-tag'));copy.append(top,el('p',lead.text||'评论正文未提供'),el('small',displayCommentDate(lead.published_at)));card.append(avatar(lead.author_avatar_url,lead.author,lead.id,'author',localWorkspace),copy);card.addEventListener('click',guard(()=>selectLead(lead)));body.append(card);}
   if(group.items.length>3){const more=el('button',selectedBeyond?'关闭右侧详情后可收起':expanded?'收起本组评论':`查看本页其余 ${group.items.length-3} 条评论`,'group-more');more.type='button';more.disabled=selectedBeyond;more.setAttribute('aria-expanded',String(expanded));more.addEventListener('click',()=>{expanded?expandedGroups.delete(expansionKey):expandedGroups.add(expansionKey);renderWorklist();[...host.children].find(item=>item.dataset.groupKey===expansionKey)?.querySelector('.group-more')?.focus({preventScroll:true});});body.append(more);}
   section.append(body);host.append(section);}
  $('worklist-page').textContent=`${total?offset+1:0}–${Math.min(offset+rows.length,total)} / ${total}`;$('worklist-prev').disabled=offset<=0;$('worklist-next').disabled=offset+25>=total;
  const select=$('worklist-group-key'),value=select.value;select.setAttribute('aria-label','筛选分组');select.replaceChildren(new Option('全部分组',''));for(const group of groupRows)select.append(new Option(`${group.label} (${group.count})`,group.key));select.value=groupKey||value;
  $('worklist-group-prev').disabled=groupOffset<=0;$('worklist-group-next').disabled=groupOffset+30>=groupsTotal;$('worklist-group-page').textContent=groupsTotal>30?`${groupOffset+1}–${Math.min(groupOffset+30,groupsTotal)} / ${groupsTotal} 组`:'';
 }
 function closeDetail(){const previous=selectionId;detailGeneration++;selectionId='';selectedLead=null;reply=null;replyNeedsCheck=false;$('reply-detail').hidden=true;$('reply-detail').style.removeProperty('--reply-visible-height');$('worklist-layout').classList.remove('has-detail');renderWorklist();const target=[...$('worklist-groups').querySelectorAll('[data-lead-id]')].find(n=>n.dataset.leadId===previous);target?.focus({preventScroll:true});}
 function renderDetailInfo(lead){if(!lead)return;const intent=displayIntent(lead);setAvatar($('reply-avatar'),lead.author_avatar_url,lead.author,lead.id,'author',localWorkspace);$('reply-user').textContent=lead.author||'用户未提供';$('reply-date').textContent=displayCommentDate(lead.published_at);$('reply-post').replaceChildren(sourceLink(lead.note_url||lead.url,lead.content_title||'帖子标题未提供'));$('reply-post-author').textContent=lead.content_author||'博主未提供';setAvatar($('reply-post-avatar'),lead.content_author_avatar_url,lead.content_author,lead.id,'post_author',localWorkspace);$('reply-post-avatar').hidden=!localWorkspace&&!mediaUrl(lead.content_author_avatar_url);const cover=$('reply-cover'),coverUrl=mediaUrl(lead.content_cover_url);cover.hidden=!coverUrl;cover.referrerPolicy='no-referrer';cover.onerror=()=>{cover.hidden=true;};if(coverUrl)cover.src=coverUrl;else cover.removeAttribute('src');$('reply-post-date').textContent=lead.content_published_at?displayCommentDate(lead.content_published_at):'';$('reply-original').textContent=lead.text||'评论正文未提供';$('reply-intent').textContent=intent.label;$('reply-intent').dataset.level=intent.kind;
  const extractedFacts=intentFacts(lead),facts=extractedFacts||[];$('reply-evidence').replaceChildren(...facts.map(x=>{const chip=el('span',x.value,'evidence-chip');chip.title=x.evidence||'';return chip;}));$('reply-analysis-status').textContent=lead.analysis_status==='missing_text'&&!String(lead.text||'').trim()?'评论正文缺失，补齐后自动分析':intent.kind==='pending'?(aiProfileStatus==='not_configured'||aiProfileStatus==='disabled'?'企业 AI 尚未启用，配置后自动分析':aiProfileStatus==='enabled'?'等待自动分析':'正在核对 AI 状态'):facts.length?'':extractedFacts===null?'此条尚无结构化关键信息':'未提及明确的预算、入住或通勤要求';$('reply-analysis-details').hidden=!intent.reason&&!intent.evidence?.length;$('reply-reason').textContent=intent.reason||'尚未完成 AI 分析';$('manual-intent').value=intent.status==='graded'?intent.level:intent.status;
  // effectiveIntent already explains a legacy grade in reply-reason.
  $('legacy-intent-note').textContent='';
  const platformIp=lead.ip_location||lead.region||'未提供',contentRegion=lead.content_region||lead.ai_intent?.content_region||'待核实';$('reply-metadata').textContent=`平台 IP 属地：${platformIp}；内容提及地区：${contentRegion}；日期与地区：${lead.verification_status==='pending'?'待核实':'以原文为准'}`;
 }
 async function selectLead(lead){const generation=++detailGeneration;selectionId=lead.id;selectedLead=lead;replyNeedsCheck=false;$('reply-detail').hidden=false;$('worklist-layout').classList.add('has-detail');renderDetailInfo(lead);renderWorklist();scheduleDetailViewport();$('reply-text').value='';$('reply-feedback').textContent='正在读取草稿…';$('reply-save').disabled=true;$('reply-confirm').disabled=true;
  const result=await action('reply_status',{lead_id:lead.id});if(generation!==detailGeneration)return;reply=result.status?result:{status:'none'};$('reply-text').value=reply.text||'';updateReply();scheduleDetailViewport();$('reply-detail').focus({preventScroll:true});
 }
 function updateReply(writeFeedback=true){const text=$('reply-text').value;$('reply-count').textContent=`${text.length} / 1000`;const current=reply?.status||'none';const states={none:'尚未保存草稿',draft:'草稿已保存，待确认',approved:'已确认，待排队',copied:'已复制，未发送',sent:'已回复',unknown:'发送结果待核对',sending:'正在发送'};if(writeFeedback)$('reply-feedback').textContent=canReply()?(states[current]||'状态待核对'):'你可以保存草稿，确认和发送由获授权成员完成';$('reply-save').disabled=replyNeedsCheck||!selectionId||['sent','unknown','sending'].includes(current);$('reply-confirm').disabled=replyNeedsCheck||!canReply()||!reply?.id||['sent','unknown','sending'].includes(current)||text.trim()!==String(reply?.text||'').trim();
  const select=$('reply-account'),prior=select.value,choice=replyAccountSelection(getState().accounts,prior||reply?.review_account_id||field('account_id').value);select.replaceChildren(new Option('选择回复账号',''));for(const account of choice.eligible)select.append(new Option(account.name||account.id,account.id));select.value=choice.value;select.closest('label').hidden=!choice.showChoice;select.disabled=['running','awaiting_collection'].includes(queue?.status);const approved=current==='approved';$('reply-confirm').textContent=approved?'加入队列':'确认回复';if(!select.value)$('reply-confirm').disabled=true;if(approved&&(!reply.review_account_id||reply.review_account_id!==select.value)){$('reply-confirm').disabled=true;if(writeFeedback)$('reply-feedback').textContent='请重新保存草稿并核对当前回复账号';}if(canReply()&&!choice.eligible.length&&writeFeedback)$('reply-feedback').textContent='小红书账号需要登录或核实，暂不能确认回复';if(replyNeedsCheck&&writeFeedback)$('reply-feedback').textContent='正在核对回复状态…';
 }
 async function saveReply(){const id=selectionId,text=$('reply-text').value.trim();if(!id||!text)throw Error('请填写回复内容');const result=await action('reply_prepare',{lead_id:id,text});if(id!==selectionId)return;reply=result;updateReply();await loadWorklist(offset);}
 async function confirmReply(){if(!canReply())throw Error('尚未获得回复确认权限');if(!reply?.id||!selectionId)throw Error('请先保存草稿');const accountId=$('reply-account').value;if(!accountId)throw Error('请选择回复账号');if(confirmedAccount&&confirmedAccount!==accountId)throw Error('账号已变化，请重新确认所选回复');if(confirmedReplies.size>=20&&!confirmedReplies.has(reply.id))throw Error('一次最多确认 20 条回复');if($('reply-text').value.trim()!==reply.text?.trim())throw Error('内容已改变，请重新保存草稿');if(reply.status==='approved'){if(reply.review_account_id!==accountId)throw Error('请重新保存草稿并核对当前回复账号');}else{if(reply.status!=='draft')throw Error('当前回复不能确认，请核对状态');reply=await action('reply_review',{reply_id:reply.id,account_id:accountId,confirmed:true});}confirmedReplies.add(reply.id);confirmedAccount=accountId;updateReply();renderQueue();}
 function renderQueue(){const labels={ready:'队列已准备',awaiting_collection:'等待采集暂停',running:'顺序发送中',completed:'发送完成',stopped:'发送已停止',interrupted:'发送中断，需要核对',cancelled:'队列已取消',unknown:'结果未知，需要核对'};const terminal=['completed','stopped','interrupted','cancelled','unknown'].includes(queue?.status),canContinue=queue?.status==='awaiting_collection'&&queue.wait_expired===true;$('reply-queue').hidden=!queue&&!confirmedReplies.size;$('queue-feedback').textContent=queue?`${labels[queue.status]||'状态待核对'} · 已处理 ${queue.processed??0} / ${queue.reply_ids?.length??confirmedReplies.size} · 已发送 ${queue.sent??0}${queue.message?` · ${queue.message}`:''}`:`已确认 ${confirmedReplies.size} 条回复`;$('queue-prepare').disabled=!canReply()||!confirmedReplies.size||['running','awaiting_collection','interrupted','unknown'].includes(queue?.status);$('queue-send').textContent=canContinue?'继续发送':'开始发送';$('queue-send').disabled=!canReply()||held()||!queue||terminal||!(queue.status==='ready'||canContinue);$('queue-refresh').disabled=!queue;$('queue-cancel').disabled=!queue||terminal;$('queue-gate').textContent=held()?'公开回复尚未开放；草稿与确认状态已保留。':'';}
 async function prepareQueue(){if(!canReply()||!confirmedReplies.size)throw Error('请先确认回复');queue=await action('reply_queue_prepare',{reply_ids:[...confirmedReplies],account_id:confirmedAccount,confirmed:true});renderQueue();}
 function scheduleQueue(){clearTimeout(queueTimer);if(['running','awaiting_collection'].includes(queue?.status))queueTimer=setTimeout(()=>queueAction('reply_queue_status').catch(error=>{onError(error);scheduleQueue();}),3000);}
 async function refreshSelectedReply(){const id=selectionId,generation=detailGeneration;if(!id)return;replyNeedsCheck=true;updateReply();try{const result=await action('reply_status',{lead_id:id});if(id!==selectionId||generation!==detailGeneration)return;reply=result.status?result:{status:'none'};replyNeedsCheck=false;updateReply();}catch(error){if(id===selectionId){$('reply-feedback').textContent='回复状态读取失败，请重新打开此评论核对';updateReply(false);}onError(error);}}
 async function queueAction(name){if(!queue?.id&&!queue?.queue_id)throw Error('请先准备队列');if(name==='reply_queue_send'&&(!canReply()||held()||!(queue.status==='ready'||queue.status==='awaiting_collection'&&queue.wait_expired===true)))throw Error('当前队列不能发送，请核对状态');queue=await action(name,{queue_id:queue.id||queue.queue_id,...(name==='reply_queue_send'?{authorized:true}:{})});if(['completed','stopped','interrupted','cancelled','unknown'].includes(queue.status)){if(['completed','stopped','cancelled'].includes(queue.status)){confirmedReplies.clear();confirmedAccount='';}await loadWorklist(offset);await refreshSelectedReply();}renderQueue();scheduleQueue();}
 async function correct(){if(!selectionId)return;const value=$('manual-intent').value;if(!value)throw Error('请选择人工判断的意向');const status=['uncertain','unrelated'].includes(value)?value:'graded';const lead=await action('intent_correct',{lead_id:selectionId,status,level:status==='graded'?value:null,reason:$('manual-reason').value.trim()});selectedLead=lead;renderDetailInfo(lead);await loadWorklist(offset);}
 function renderAiProvider(clearKey=false){
  if(clearKey){$('ai-key').value='';$('ai-clear-key').checked=false;}
  const provider=$('ai-provider').value,entry=aiConfig?.providers?.[provider]||
   (provider===aiConfig?.provider?aiConfig:{}),catalog=(aiConfig?.model_catalog||[]).filter(item=>item.provider===provider);
  $('ai-model').replaceChildren(...catalog.map(item=>{const option=el('option',item.label);option.value=item.id;return option;}));
  if(catalog.some(item=>item.id===entry.model))$('ai-model').value=entry.model;
  $('ai-configured').classList.remove('is-error');$('ai-configured').textContent=entry.configured?'该供应商密钥已配置':'请填写该供应商的 API 密钥';
  $('ai-key-help').href=provider==='openai'?'https://platform.openai.com/api-keys':'https://platform.deepseek.com/api_keys';
  $('ai-key-help').textContent=provider==='openai'?'获取 OpenAI API 密钥':'获取 DeepSeek API 密钥';
  $('ai-usd-rate-label').hidden=provider!=='openai';renderAiEffort(entry.reasoning_effort);
 }
 function renderAiEffort(preferred){
  const item=(aiConfig?.model_catalog||[]).find(item=>item.provider===$('ai-provider').value&&item.id===$('ai-model').value);
  const efforts=item?.reasoning_efforts||[],labels={none:'关闭推理',low:'低 · 更快',medium:'中',high:'高',xhigh:'超高',max:'最高'};
  $('ai-effort').replaceChildren(...efforts.map(value=>{const option=el('option',labels[value]||value);option.value=value;return option;}));
  $('ai-effort-label').hidden=!efforts.length;
  $('ai-effort').value=efforts.includes(preferred)?preferred:item?.id==='gpt-5.4-mini'&&efforts.includes('none')?'none':efforts.includes('low')?'low':efforts[0]||'';
 }
 async function openAi(){if(getUser()?.role!=='admin')return;const result=await cloud.call('ai_config_read'),c=result.config;aiConfig=c;
  // An old server exposes only DeepSeek. Never submit an unsupported provider to it.
  if(!Array.isArray(c.model_catalog))aiConfig={...c,provider:'deepseek',model_catalog:[{id:'deepseek-flash',provider:'deepseek',label:'DeepSeek Flash',reasoning_efforts:[]},{id:'deepseek-v4-pro',provider:'deepseek',label:'DeepSeek V4 Pro',reasoning_efforts:[]}]};
  $('ai-provider').value=aiConfig.provider||'deepseek';$('ai-provider').querySelector('option[value="openai"]').disabled=!aiConfig.model_catalog.some(item=>item.provider==='openai');
  $('ai-enabled').checked=!!c.enabled;$('ai-daily-budget').value=c.daily_budget_cny;$('ai-usd-rate').value=c.usd_cny_rate||7.5;$('ai-rules-version').value=c.rules_version;renderAiProvider(true);$('ai-dialog').showModal();
 }
 async function saveAi(){const key=$('ai-key').value,provider=$('ai-provider').value;
  const config={provider,enabled:$('ai-enabled').checked,model:$('ai-model').value,daily_budget_cny:Number($('ai-daily-budget').value),rules_version:$('ai-rules-version').value};
  if(aiConfig?.model_catalog?.some(item=>item.provider==='openai')){config.usd_cny_rate=Number($('ai-usd-rate').value);if(provider==='openai')config.reasoning_effort=$('ai-effort').value;}
  else delete config.provider;
  const data={config,...(key?{api_key:key}:{}),...($('ai-clear-key').checked?{clear_api_key:true}:{})};
  const controls=[...$('ai-config-form').elements];for(const control of controls)control.disabled=true;$('ai-configured').textContent='正在保存…';
  try{const result=await cloud.call('ai_config_save',data);aiConfig=result.config;renderAiProvider(true);$('ai-configured').classList.remove('is-error');$('ai-configured').textContent='企业配置已保存';await profile();}
  finally{$('ai-key').value='';for(const control of controls)control.disabled=false;}
 }
 function renderUpdate(){const view=updatePresentation(updateState||{});$('update-version').textContent=updateState?`当前版本 ${view.installedVersion}${view.installedRelease===null?'':` · 发布 ${view.installedRelease}`}${view.candidateRelease===null?'':` · 可用发布 ${view.candidateRelease}`}`:'';$('update-state').textContent=updateState?view.label:'';$('update-feedback').textContent=updateError||(updateBusy?'正在核对更新状态…':view.message||'正在读取更新状态…');$('update-feedback').classList.toggle('is-error',!!updateError);$('update-restart').hidden=!(view.restart||['pending_restart','awaiting_close'].includes(view.status));for(const [id,visible,allowed] of [['update-check',view.configured,view.canCheck],['update-download',view.canDownload,view.canDownload],['update-install',view.canInstall,view.canInstall]]){const button=$(id);button.hidden=!visible;button.disabled=updateBusy||updateUnknown||!allowed;}$('update-refresh').disabled=updateBusy;}
 async function updateAction(name){if(getUser()?.role!=='admin')throw Error('更新由管理员管理');const view=updatePresentation(updateState||{});if(name==='update_download'&&!view.canDownload||name==='update_install'&&!view.canInstall||name==='update_check'&&!view.canCheck)throw Error('请先刷新并核对更新状态');updateBusy=true;updateError='';renderUpdate();try{updateState=await action(name,{});updateUnknown=false;}catch(error){updateUnknown=!!error.requestId;updateError=updateUnknown?'操作结果待核对，请刷新状态后继续':error.message||'更新操作未完成';throw error;}finally{updateBusy=false;renderUpdate();}}
 async function openUpdate(){if(getUser()?.role!=='admin')return;$('update-dialog').showModal();await updateAction('update_status');}
  $('keywords-expand').addEventListener('click',()=>{keywordsExpanded=!keywordsExpanded;renderKeywords();});$('keywords-recommended').addEventListener('click',()=>{if(!keywords.some(k=>k.recommended===true))return;selected=new Set(keywords.filter(k=>k.recommended===true).map(k=>k.keyword));renderKeywords();renderContinuous();});$('keywords-all').addEventListener('click',()=>{selected=new Set(keywords.map(k=>k.keyword));renderKeywords();renderContinuous();});
 $('suggest-keywords').addEventListener('click',guard(recommend));$('save-keywords').addEventListener('click',guard(saveLibrary));$('open-keyword-library').addEventListener('click',guard(async()=>{$('keyword-library').hidden=!$('keyword-library').hidden;if(!$('keyword-library').hidden)await restoreLibrary();}));
 field('keywords').addEventListener('input',updateKeywordCount);form.addEventListener('input',renderContinuous);form.addEventListener('change',renderContinuous);field('comment_date_range').addEventListener('change',()=>{$('custom-comment-dates').hidden=field('comment_date_range').value!=='custom';});
 form.addEventListener('invalid',event=>{if(!settingsDialog.contains(event.target))return;event.preventDefault();if(invalidQueued)return;invalidQueued=true;openCollectionDialog($('create-task'),event.target,'请补全采集条件');queueMicrotask(()=>{invalidQueued=false;});},true);
 $('collection-adjust').addEventListener('click',event=>openCollectionDialog(event.currentTarget));$('collection-dialog-close').addEventListener('click',closeCollectionDialog);$('collection-dialog-done').addEventListener('click',closeCollectionDialog);settingsDialog.addEventListener('close',()=>{const target=settingsReturnFocus;settingsReturnFocus=null;renderCollectionSummary();if(target?.isConnected!==false)target?.focus?.();if(target&&taskId&&!disposed)void refreshContinuous().catch(onError);});
 $('keyword-adjust').addEventListener('click',()=>{$('keyword-options').open=!$('keyword-options').open;syncKeywordAdjustment();});$('keyword-options').addEventListener('toggle',syncKeywordAdjustment);
 $('continuous-toggle').addEventListener('click',guard(toggle));$('continuous-add-keywords').addEventListener('click',()=>{$('keyword-options').open=true;syncKeywordAdjustment();field('keywords').closest('details').open=true;field('keywords').focus();});
 $('analysis-retry').addEventListener('click',guard(async()=>{analysisBusy=true;renderContinuous();try{await action('intent_analyze_pending',{task_id:taskId});report('已完成本批分析');await refreshContinuous();}finally{analysisBusy=false;renderContinuous();}}));
 $('latest-open-all').addEventListener('click',()=>{onPage('leads');void loadWorklist(0).catch(onError);});
 for(const [id,value] of [['pending-tab','pending'],['all-tab','all']])$(id).addEventListener('click',guard(async()=>{worklist=value;offset=0;groupKey='';groupOffset=0;closeDetail();await loadWorklist();}));
 $('worklist-group-by').addEventListener('change',guard(async event=>{groupBy=event.currentTarget.value;groupKey='';groupOffset=0;closeDetail();await loadWorklist();}));
 $('worklist-group-key').addEventListener('change',guard(async event=>{groupKey=event.currentTarget.value;closeDetail();await loadWorklist();}));
 $('worklist-intent').addEventListener('change',guard(()=>loadWorklist()));$('worklist-filter').addEventListener('submit',guard(()=>loadWorklist()));
 $('worklist-prev').addEventListener('click',guard(()=>loadWorklist(Math.max(0,offset-25))));$('worklist-next').addEventListener('click',guard(()=>loadWorklist(offset+25)));
 $('worklist-group-prev').addEventListener('click',guard(async()=>{groupOffset=Math.max(0,groupOffset-30);await loadWorklist();}));$('worklist-group-next').addEventListener('click',guard(async()=>{groupOffset+=30;await loadWorklist();}));
 $('reply-close').addEventListener('click',closeDetail);$('reply-text').addEventListener('input',updateReply);$('reply-save').addEventListener('click',guard(saveReply));$('reply-confirm').addEventListener('click',guard(confirmReply));$('manual-intent-save').addEventListener('click',guard(correct));
 $('reply-account').addEventListener('change',()=>{if(confirmedReplies.size&&$('reply-account').value!==confirmedAccount){confirmedReplies.clear();confirmedAccount='';queue=null;clearTimeout(queueTimer);$('reply-feedback').textContent='回复账号已变化，请重新确认每条草稿';renderQueue();updateReply(false);}else updateReply();});$('queue-prepare').addEventListener('click',guard(prepareQueue));
 for(const [id,name] of [['queue-send','reply_queue_send'],['queue-refresh','reply_queue_status'],['queue-cancel','reply_queue_cancel']])$(id).addEventListener('click',guard(()=>queueAction(name)));
 $('ai-provider').addEventListener('change',()=>renderAiProvider(true));$('ai-model').addEventListener('change',()=>renderAiEffort());
 $('open-ai-config').addEventListener('click',guard(openAi));$('ai-config-form').addEventListener('submit',guard(saveAi));$('ai-close').addEventListener('click',()=>{$('ai-key').value='';$('ai-dialog').close();});$('ai-dialog').addEventListener('close',()=>{$('ai-key').value='';});$('open-update').addEventListener('click',guard(openUpdate));$('update-close').addEventListener('click',()=>$('update-dialog').close());for(const [id,name] of [['update-check','update_check'],['update-download','update_download'],['update-install','update_install'],['update-refresh','update_status']])$(id).addEventListener('click',guard(()=>updateAction(name)));
 // The footer belongs to the detail scrollport so its actions remain visible.
 $('reply-detail').append($('reply-detail').querySelector('.detail-reply-actions'));
 $('reply-detail').querySelector('.detail-reply-actions').prepend($('reply-detail').querySelector('.reply-edit-meta'));
 window.addEventListener('resize',scheduleDetailViewport);
 window.addEventListener('scroll',scheduleDetailViewport,{passive:true});
 document.addEventListener('keydown',event=>{if(event.key==='Escape'&&selectedLead){closeDetail();$('pending-tab').focus();}});
 renderKeywords();renderContinuous();
 return {start,syncSnapshot,markSnapshotUnconfirmed,loadWorklist,openPending,profile,latest,reset(){settingsReturnFocus=null;closeCollectionDialog();disposed=false;startHeaderDate();cancelPoll();taskId='';hydratedTaskId='';savedForStart=null;savedForStartDevice='';pendingSave=null;snapshotUnconfirmed=false;aiProfileStatus='unknown';aiProfile={};aiConfig=null;keywordBusy=false;analysisBusy=false;updateState=null;updateBusy=false;updateUnknown=false;updateError='';$('pending-bell-dot').hidden=true;$('keyword-options').open=false;syncKeywordAdjustment();delete $('create-task').dataset.uncertain;task=null;readGeneration++;detailGeneration++;rows=[];selectionId='';selectedLead=null;reply=null;replyNeedsCheck=false;queue=null;confirmedReplies.clear();confirmedAccount='';keywords=[];selected.clear();libraryId='';$('ai-key').value='';$('ai-dialog').close();$('update-dialog').close();closeDetail();renderContinuous();renderKeywords();},async refresh(){if(pendingSave){if(pendingSave.deviceId!==getState().selected){report('当前电脑已变化，请回到原电脑核对保存结果，暂勿重复开始',true);return;}if(!pendingSave.commandId){report('保存结果仍待核对，请联系管理员查看原操作；暂勿重复开始',true);return;}const result=await cloud.inspect(pendingSave.commandId);if(result?.status==='succeeded'&&result.result?.id){savedForStart={...pendingSave.data,...result.result};savedForStartDevice=pendingSave.deviceId;taskId=savedForStart.id;task=savedForStart;pendingSave=null;delete $('create-task').dataset.uncertain;$('create-task').disabled=false;report('设置已保存，点击开始采集继续此任务');}else if(['failed','cancelled'].includes(result?.status)){pendingSave=null;delete $('create-task').dataset.uncertain;$('create-task').disabled=false;report('设置未保存，可以重新开始',true);}else{report('保存结果仍待核对，暂勿重复开始',true);return;}}await refreshContinuous();await profile();},onPage(name){if(name==='leads')return loadWorklist();if(name==='tasks'){void profile();void latest();}},dispose(){settingsReturnFocus=null;closeCollectionDialog();disposed=true;clearInterval(headerDateTimer);headerDateTimer=0;cancelPoll();if(detailFrame)cancelAnimationFrame(detailFrame);}};
}
