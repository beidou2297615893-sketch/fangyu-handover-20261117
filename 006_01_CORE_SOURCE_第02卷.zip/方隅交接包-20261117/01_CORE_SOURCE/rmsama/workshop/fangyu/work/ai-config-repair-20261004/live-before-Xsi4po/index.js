const cloudbase = require('@cloudbase/node-sdk');
const {createService} = require('./service.cjs');
const {serveSite} = require('./site.cjs');
const {releaseState} = require('./release.cjs');
const {listPage} = require('./shared_leads_v2.cjs');
let service;
function createStore(db, companyId) {
  return {
    transaction: async callback => db.runTransaction(async transaction => {
      const ref = transaction.collection('fangyu_workspace_private').doc(companyId);
      const snapshot = await ref.get();
      const value = Array.isArray(snapshot.data) ? snapshot.data[0] : snapshot.data;
      const before = value?.state || null;
      const output = await callback(before, transaction);
      // Read-only requests should not rewrite the entire company document.
      // The service state is JSON-only, so this also detects housekeeping edits.
      if (JSON.stringify(output.state) !== JSON.stringify(before)) {
        await ref.set({state: output.state});
      }
      return output.result;
    }),
    listSharedPage: async (cursor, revision, username, sessionDigest) => {
      const page = await listPage(db, companyId, cursor);
      const snapshot = await db.collection('fangyu_workspace_private').doc(companyId).get();
      const value = Array.isArray(snapshot.data) ? snapshot.data[0] : snapshot.data;
      const state = value?.state;
      if (state?.revision !== revision || state?.sharedLeadsMode !== 'v2' ||
          !state.users?.some(user => user.username === username && !user.disabled) ||
          !state.sessions?.some(session => session.username === username && session.digest === sessionDigest && session.expires > Math.floor(Date.now() / 1000))) return null;
      return page;
    }
  };
}
function getService() {
  if (service) return service;
  const environmentId = process.env.TCB_ENV;
  const companyId = process.env.COMPANY_ID;
  if (!environmentId || companyId !== 'fangyu-apartment-client') throw new Error('Deployment identity missing');
  const options = {env: environmentId};
  if (process.env.CLOUDBASE_APIKEY) options.accessKey = process.env.CLOUDBASE_APIKEY;
  const db = cloudbase.init(options).database();
  // Use the installed package entry (dist/commonjs), not stale SDK source files.
  const store = createStore(db, companyId);
  const release=releaseState();
  service = createService({store, environmentId, companyId, initialAdmin: process.env.INITIAL_ADMIN_USERNAME, initialPassword: process.env.INITIAL_ADMIN_PASSWORD,
    releaseApproved: release.active, releaseVersion: release.version,
    pairingApproved: release.pairingAllowed, pairingVersion: release.pairingVersion,
    platformQaDeviceId: release.platformQaDeviceId,qaContinuousUntil:release.qaContinuousUntil,
    continuousReadonlyDeviceId:release.continuousReadonlyDeviceId});
  return service;
}
exports.main = async event => {
  const headers = {'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff'};
  const reply = (statusCode, body) => ({statusCode, headers, body: JSON.stringify(body)});
  try {
    if (event.httpMethod === 'GET') return serveSite(event);
    if (event.httpMethod !== 'POST') return reply(405, {error: 'POST only'});
    const raw = event.isBase64Encoded ? Buffer.from(event.body || '', 'base64').toString('utf8') : event.body || '';
    if (typeof raw !== 'string' || Buffer.byteLength(raw) > 400000) return reply(413, {error: 'Request too large'});
    let payload;
    try { payload = JSON.parse(raw); } catch { return reply(400, {error: 'Invalid JSON'}); }
    const requestHeaders = Object.fromEntries(Object.entries(event.headers || {}).map(([k, v]) => [k.toLowerCase(), v]));
    const token = String(requestHeaders.authorization || '').replace(/^Bearer\s+/i, '');
    const result = await getService()(payload, token);
    return reply(result.status, result.data);
  } catch (error) {
    // SDK error messages can embed a failed private-document write, including an API key.
    // Keep fixed diagnostics only; never log raw payloads, state, or exception messages.
    console.error('FANGYU_SERVICE_ERROR', /^[A-Za-z0-9_.-]{1,80}$/.test(String(error.code || error.name || 'unknown')) ? String(error.code || error.name || 'unknown') : 'unknown');
    // Never return credentials or SDK connection details to the caller.
    return reply(503, {error: 'Workspace is not configured or temporarily unavailable'});
  }
};
exports.createStore = createStore;
