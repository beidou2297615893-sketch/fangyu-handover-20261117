const ACTIONS = new Set(['assistant_status','assistant_workspace_state','assistant_account_safety',
  'assistant_account_signal','assistant_account_login','assistant_new_account_login','assistant_job_status','assistant_cancel_login']);
const QR_JOB = /^[a-f0-9]{24}$/;

export async function localAssistantCall(action,data={},fetcher=fetch){
  if(!ACTIONS.has(action)||!data||typeof data!=='object'||Array.isArray(data))throw Error('账号请求无效');
  const response=await fetcher('/api',{method:'POST',credentials:'same-origin',redirect:'error',cache:'no-store',
    headers:{'Content-Type':'application/json','X-Local-App':'1'},body:JSON.stringify({action,data})});
  let value;
  try{value=await response.json();}catch{throw Error('本机助手响应无法读取，请核对状态');}
  if(!response.ok)throw Error(value?.error||'本机助手暂时无法连接');
  return value;
}

export function safeXhsImageUrl(value){
  if(typeof value!=='string'||value.length>2048)return '';
  try{
    const url=new URL(value);
    const host=url.hostname.toLowerCase();
    if(url.protocol!=='https:'||url.username||url.password||!url.pathname||
      !(host==='xhscdn.com'||host.endsWith('.xhscdn.com')||host==='xiaohongshu.com'||host.endsWith('.xiaohongshu.com')))return '';
    return value;
  }catch{return '';}
}

export function reviewSignal(accountId,safety){
  if(typeof accountId!=='string'||!accountId||safety?.state!=='review_required'||
    !Number.isSafeInteger(safety.activity_revision_bytes)||safety.activity_revision_bytes<0)throw Error('请先刷新账号复核记录');
  return {account_id:accountId,kind:'review_completed',revision:safety.activity_revision_bytes};
}

export async function recoverConnection(accountId,safety,record,check){
  if(typeof record!=='function'||typeof check!=='function')throw Error('连接检查暂不可用');
  const data=reviewSignal(accountId,safety);
  await record(data);
  return check(accountId);
}

const make=(tag,text,className)=>{const element=document.createElement(tag);if(text!==undefined)element.textContent=String(text);if(className)element.className=className;return element;};
const reasonText=reason=>({verification_required:'平台要求核对电脑端请求。请查看手机小红书是否有提示，并核对上次操作结果。',
  ip_blocked:'平台访问受限，请先人工核实账号。',not_authenticated:'登录状态失效，请先核对手机与账号。',
  manual_signal:'此前有人记录了安全提醒，请核对账号与上次操作。',other_risk:'账号出现异常，请先人工核实。',
  unknown:'操作结果或记录尚不确定，请核对后再决定。'})[reason]||'请核对账号状态与上次操作结果。';
export function accountRecovery(account){
  const blocked=account?.requires_review===true;
  const verification=blocked&&account.review_reason==='verification_required';
  const expired=blocked&&account.review_reason==='not_authenticated'&&account.status==='login_required';
  const reportedLogout=blocked&&account.review_reason==='manual_signal'&&account.status==='login_required';
  const reauth=expired||reportedLogout;
  return {blocked,verification,reauth,canLogin:!blocked&&account?.status!=='logging_in',label:expired?'电脑登录已失效':reportedLogout?'电脑登录需要更新':verification?(account?.status==='login_required'?'登录验证未完成':'连接需要验证'):blocked?'等待账号确认':'',
    message:expired?'这台电脑的登录已失效。请先核对手机状态，再在此扫码更新登录。':reportedLogout?'这台电脑当前需要登录。请先核对手机状态，再为此账号重新登录。':verification?(account?.status==='login_required'?'小红书未放行电脑端登录。请查看手机小红书提示和账号记录，核对后检查连接。':'电脑登录已保存，平台要求核对本次请求。请查看手机小红书提示和账号记录，核对后检查连接。'):blocked?'请先核实账号和上次操作结果，再确认复核。':'',
    reviewLabel:reauth?'已核对手机，重新扫码登录':'账号已核实，检查连接'};
}
const statusText=account=>account.requires_review?'需要确认':({ready:'已连接',logging_in:'连接中',
  login_required:'需要登录',identity_mismatch:'扫码身份不一致',identity_unverified:'账号身份待核实',
  duplicate_identity:'账号记录重复',duplicate_identity_remote:'企业身份登记冲突',
  identity_cloud_unavailable:'企业身份校验不可用',session_recovery_required:'登录需要恢复'})[account.status]||'状态待核对';
export function accountVisualState(account,status,{loginActive=false,loginInterrupted=false}={}){
  if(account?.requires_review===true||status?.safety_hold===true||status?.state==='held'||loginInterrupted)return 'attention';
  if(['identity_mismatch','duplicate_identity','duplicate_identity_remote'].includes(account?.status))return 'error';
  if(account?.status==='login_required'||account?.status==='session_recovery_required'||account?.status==='identity_unverified')return 'attention';
  if(loginActive||account?.status==='logging_in'||account?.status==='identity_cloud_unavailable'||status?.state!=='online')return 'waiting';
  return account?.status==='ready'?'connected':'waiting';
}
const accountName=account=>String(account.platform_nickname||account.name||'小红书账号');
const validCount=value=>Number.isSafeInteger(value)&&value>=0;
export function safetyView(record){
  const scope=record?.history_scope;
  const complete=validCount(record?.phone_report_count)&&validCount(record?.computer_incident_count)&&
    validCount(record?.phone_report_counts?.unexpected_logout)&&validCount(record?.phone_report_counts?.phone_verification)&&
    Array.isArray(record?.incident_history)&&scope?.days===30&&scope?.timeline_limit===20&&
    validCount(scope?.record_limit)&&typeof scope?.truncated_by_time==='boolean'&&typeof scope?.truncated_by_records==='boolean';
  return {complete:!!complete,phoneCount:complete?record.phone_report_count:null,
    computerCount:complete?record.computer_incident_count:null,
    phoneState:record?.phone_state==='reported_issue'?'已报送手机异常':record?.phone_state==='reviewed'?'已人工复核':'手机状态未确认'};
}
export function shanghaiTime(seconds){
  if(!Number.isFinite(seconds)||seconds<0||seconds>253402300799)return '尚无记录';
  return new Intl.DateTimeFormat('zh-CN',{timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit',
    hour:'2-digit',minute:'2-digit',hour12:false}).format(new Date(seconds*1000));
}
const sourceText=source=>({phone_report:'员工报送',computer_http:'电脑请求',computer_cli:'电脑连接',computer_http_cli:'电脑请求与连接'})[source]||'来源待核对';
const gapText=seconds=>Number.isFinite(seconds)&&seconds>0?(seconds>=60?`${new Intl.NumberFormat('zh-CN',{maximumFractionDigits:1}).format(seconds/60)} 分钟`:`${new Intl.NumberFormat('zh-CN',{maximumFractionDigits:1}).format(seconds)} 秒`):'暂无可用间隔';

export function createPlatformAccount({root,onAccountsChanged=()=>{},onOpenCollection=()=>{},checkAccount,fetcher=fetch,confirmReview=message=>window.confirm(message)}){
  if(!root)throw Error('缺少小红书账号页面');
  const legacy=root.querySelector('.account-layout');
  if(legacy)legacy.hidden=true;
  const shell=make('section',undefined,'platform-account-shell');
  shell.innerHTML='<div class="platform-account-list" hidden></div><div class="platform-account-detail"></div><div class="platform-account-qr" hidden><div class="platform-account-qr-head"><strong>等待扫码</strong><button type="button" class="text-button platform-account-qr-close">取消</button></div><span class="platform-account-spinner" aria-hidden="true"></span><p class="platform-account-qr-message" role="status" aria-live="polite"></p><img class="platform-account-qr-image" alt="小红书登录二维码" hidden></div><p class="platform-account-alert" role="status" aria-live="polite"></p><div class="platform-account-tools"></div>';
  root.prepend(shell);
  const alert=shell.querySelector('.platform-account-alert'),list=shell.querySelector('.platform-account-list'),
    detail=shell.querySelector('.platform-account-detail'),qr=shell.querySelector('.platform-account-qr'),
    qrImage=shell.querySelector('.platform-account-qr-image'),qrMessage=shell.querySelector('.platform-account-qr-message'),tools=shell.querySelector('.platform-account-tools');
  let accounts=[],status=null,selectedId='',safety=null,safetyId='',revision=0,loginJob='',loginMode='qr',pollTimer=0,refreshSerial=0,busy=false,reportMenuOpen=false,timelineOpen=false,auditOpen=false,flowStage=0,loginInterrupted=false;
  const call=(action,data)=>localAssistantCall(action,data,fetcher);
  let messageKind='';
  const message=(text,error=false,kind='action')=>{messageKind=kind;alert.textContent=text||'';alert.classList.toggle('is-error',error);};
  const loginAllowed=()=>status?.state==='online'&&status?.safety_hold!==true&&status?.account_safety_available===true;
  const browserLogin=()=>status?.login_method==='browser';
  const reviewAllowed=()=>['online','held'].includes(status?.state)&&status?.account_safety_available===true;
  function stopPolling(){clearTimeout(pollTimer);pollTimer=0;}
  function reset(){refreshSerial++;revision++;stopPolling();loginJob='';loginMode='qr';accounts=[];status=null;selectedId='';safety=null;safetyId='';busy=false;reportMenuOpen=false;timelineOpen=false;auditOpen=false;flowStage=0;loginInterrupted=false;shell.removeAttribute('data-tone');shell.classList.toggle('is-connected',false);shell.classList.toggle('is-login-active',false);list.replaceChildren();detail.replaceChildren();tools.replaceChildren();qr.hidden=true;qrImage.hidden=true;qrImage.removeAttribute('src');message('');}
  function renderAccounts(){
    shell.setAttribute('aria-busy',String(busy||!!loginJob));list.replaceChildren();const named=accounts.filter(item=>item.status||item.platform_nickname);list.hidden=named.length<2;
    for(const account of named.length>1?named:[]){
      const action=make('button',accountName(account),'secondary platform-account-switch');action.type='button';action.disabled=busy||!!loginJob;
      action.setAttribute('aria-pressed',String(account.id===selectedId));
      action.addEventListener('click',()=>void selectAccount(account.id));list.append(action);
    }
    if(status?.safety_hold||status?.state==='held')message('当前平台操作尚未开放；已保存的账号与安全记录仍可查看。',false,'state');
    else if(!status?.account_safety_available)message('正在连接工作台，请稍候…',false,'state');
    else if(messageKind==='state')message('');
  }
  function renderDetail(){
    detail.replaceChildren();tools.replaceChildren();const account=accounts.find(item=>item.id===selectedId)||{id:'',name:'小红书账号',status:'login_required'};
    detail.hidden=false;
    const record=safetyId===account.id?safety:null,view=safetyView(record),recovery=accountRecovery(account);
    const heading=make('div',undefined,'platform-account-detail-head');
    const avatar=make('img',undefined,'platform-account-avatar');avatar.alt='';avatar.referrerPolicy='no-referrer';avatar.onerror=()=>{avatar.onerror=null;avatar.src='?asset=fy-icon-16-user.png';};avatar.src=safeXhsImageUrl(account.platform_avatar_url)||'?asset=fy-icon-16-user.png';
    const title=make('div',undefined,'platform-account-detail-title');title.append(make('h3',accountName(account)),make('span',loginJob?(loginInterrupted?'连接中断':flowStage===1?'正在核对':'等待扫码'):statusText(account),'platform-account-state'));
    heading.append(avatar,title);detail.append(heading);
    const connected=account.status==='ready'&&!recovery.blocked&&!loginJob;
    const visualState=accountVisualState(account,status,{loginActive:!!loginJob||busy&&!qr.hidden,loginInterrupted});
    shell.setAttribute('data-tone',visualState);
    shell.classList.toggle('is-connected',visualState==='connected');shell.classList.toggle('is-login-active',!loginInterrupted&&(!!loginJob||busy&&!qr.hidden));
    const steps=make('ol',undefined,'platform-account-steps'),current=connected?2:flowStage;
    for(const [index,label] of ['扫码登录','自动核对','已连接'].entries()){
      const step=make('li');step.append(make('span',index+1,'platform-account-step-number'),make('strong',label));
      step.classList.toggle('is-current',index===current);step.classList.toggle('is-done',index<current);
      if(index===current)step.setAttribute('aria-current','step');steps.append(step);
    }
    detail.append(steps);
    const intro=make('div',undefined,'platform-account-intro');intro.hidden=!qr.hidden;
    intro.append(make('h2',connected?'小红书已连接':recovery.blocked?'先确认手机状态':'扫码后自动连接'),
      make('p',connected?'可以回到采集页开始工作。':recovery.blocked?'手机恢复正常后，点下方按钮继续。':'用小红书 App 扫码并确认即可。'));
    detail.append(intro);
    const primary=make('button',connected?'去采集':recovery.blocked?'恢复连接':account.status==='logging_in'?'正在连接…':'登录小红书','platform-account-primary');primary.type='button';
    primary.disabled=busy||!!loginJob||account.status==='logging_in'||(recovery.blocked?!reviewAllowed():!loginAllowed());
    primary.hidden=!!loginJob||busy&&!qr.hidden;
    primary.addEventListener('click',()=>connected?onOpenCollection():recovery.blocked?void completeReview(account.id,browserLogin()&&loginAllowed()&&account.status!=='session_recovery_required'):void beginLogin(account.id));
    detail.append(primary);
    const audit=make('details',undefined,'platform-account-audit');audit.open=auditOpen;
    audit.append(make('summary','异常记录与更多操作'));
    audit.addEventListener('toggle',()=>{auditOpen=audit.open;});
    audit.append(make('p',view.phoneState,'platform-account-phone-state'));
    const maintenance=make('div',undefined,'platform-account-detail-actions');
    const refreshButton=make('button','刷新状态','secondary platform-account-refresh');refreshButton.type='button';refreshButton.disabled=busy||!!loginJob;
    refreshButton.addEventListener('click',()=>void refresh().catch(()=>{}));maintenance.append(refreshButton);
    const newButton=make('button','添加其他账号','secondary platform-account-new');newButton.type='button';newButton.disabled=!loginAllowed()||busy||!!loginJob;
    newButton.addEventListener('click',()=>void beginLogin());maintenance.append(newButton);
    if(account.id&&loginAllowed()&&!recovery.blocked&&account.status==='ready'){
      const check=make('button','检查连接','secondary');check.type='button';check.disabled=busy||!!loginJob;
      check.addEventListener('click',()=>void checkConnection(account.id));maintenance.append(check);
    }
    audit.append(maintenance);
    const stats=make('div',undefined,'platform-account-stats');
    for(const [label,count] of [['近30天已记录手机异常',view.phoneCount],['近 30 天电脑错误',view.computerCount]]){
      const card=make('div',undefined,'platform-account-stat');card.append(make('span',label),make('strong',count===null?'记录尚不完整':`${count} 次`));
      if(view.complete&&label==='近30天已记录手机异常')card.append(make('small',`异常退出 ${record.phone_report_counts.unexpected_logout} 次 · 提示验证 ${record.phone_report_counts.phone_verification} 次`));
      stats.append(card);
    }
    audit.append(stats);
    const actions=make('div',undefined,'platform-account-detail-actions');
    const report=make('button','报告手机异常','secondary platform-account-report-trigger');report.type='button';report.disabled=busy||!!loginJob||!account.id;
    report.setAttribute('aria-expanded',String(reportMenuOpen));report.setAttribute('aria-controls','platform-account-report-menu');
    report.addEventListener('click',()=>{reportMenuOpen=!reportMenuOpen;renderDetail();detail.querySelector('.platform-account-report-trigger')?.focus?.();});actions.append(report);
    audit.append(actions);
    const menu=make('div',undefined,'platform-account-report-menu');menu.id='platform-account-report-menu';menu.hidden=!reportMenuOpen;
    menu.addEventListener('keydown',event=>{if(event.key==='Escape'){reportMenuOpen=false;renderDetail();detail.querySelector('.platform-account-report-trigger')?.focus?.();}});
    menu.append(make('p','只记录实际遇到的情况。报送后暂停相关操作，等待人工核实。'));
    for(const [kind,label] of [['unexpected_logout','手机异常退出'],['phone_verification','手机提示验证']]){
      const button=make('button',label,'secondary');button.type='button';button.disabled=busy;
      button.addEventListener('click',()=>void reportSignal(account.id,kind,label));menu.append(button);
    }
    audit.append(menu);
    const recordBox=make('section',undefined,'platform-account-record-box');recordBox.append(make('h4','异常记录'));
    if(!record){recordBox.append(make('p',account.id?'正在读取账号记录…':'登录后会保留异常记录。'));audit.append(recordBox);tools.append(audit);return;}
    if(!view.complete)recordBox.append(make('p','记录尚不完整。请刷新；旧版服务暂不能提供手机与电脑的完整统计。','platform-account-incomplete'));
    if(record.state==='review_required')recordBox.append(make('p',record.message||reasonText(account.review_reason),'platform-account-review-note'));
    const times=make('div',undefined,'platform-account-times');
    for(const [label,value] of [['上次手机异常',record.previous_phone_anomaly_at],['本次手机异常',record.last_phone_anomaly_at]]){
      const item=make('div');item.append(make('span',label),make('strong',view.complete?shanghaiTime(value):'记录尚不完整'));times.append(item);
    }
    recordBox.append(times);
    const timeline=make('details',undefined,'platform-account-timeline');timeline.open=timelineOpen;
    timeline.addEventListener('toggle',()=>{timelineOpen=timeline.open;});timeline.append(make('summary','查看最近记录'));
    if(view.complete){
      if(!record.incident_history.length)timeline.append(make('p','近 30 天暂无已记录事件。'));
      for(const event of record.incident_history.slice(0,20)){
        const row=make('div',undefined,'platform-account-event');
        row.append(make('time',shanghaiTime(event?.at)),make('strong',typeof event?.kind==='string'?event.kind:'事件待核对'),
          make('span',sourceText(event?.source),'platform-account-event-source'),make('p',typeof event?.label==='string'?event.label:'记录说明缺失'));
        timeline.append(row);
      }
      const scope=record.history_scope;
      if(scope.truncated_by_time||scope.truncated_by_records)timeline.append(make('small','这里只展示近 30 天、最多 20 条最近事件；部分旧记录未纳入统计。'));
    }else timeline.append(make('p','旧版记录尚不完整，暂不能展示可靠时间线。'));
    recordBox.append(timeline);audit.append(recordBox);
    const advice=make('section',undefined,'platform-account-advice');advice.append(make('h4','谨慎操作建议'));
    if(view.complete){
      for(const [key,label] of [['collection','采集间隔'],['reply','回复间隔']]){
        const item=record.interval_advice?.[key],card=make('div',undefined,'platform-account-advice-card');
        card.append(make('strong',label),make('p',typeof item?.recommendation==='string'&&item.recommendation?item.recommendation:'暂无法给出具体间隔建议。'));
        card.append(make('small',`最近观察：${gapText(item?.observed_gap_seconds)}；建议先试：${gapText(item?.suggested_trial_gap_seconds)}`));
        if(typeof item?.reason==='string'&&item.reason){const why=make('details');why.append(make('summary','为什么这样建议？'),make('p',item.reason));card.append(why);}
        advice.append(card);
      }
      const loginAdvice=make('p',typeof record.next_login_recommendation==='string'&&record.next_login_recommendation?record.next_login_recommendation:'登录建议尚未提供。','platform-account-login-advice');advice.append(loginAdvice);
      if(typeof record.next_login_reason==='string'&&record.next_login_reason){const why=make('details');why.append(make('summary','查看登录建议依据'),make('p',record.next_login_reason));advice.append(why);}
    }else advice.append(make('p','记录尚不完整，先核对账号和手机提示；暂不推荐具体间隔。'));
    const caveat=make('details',undefined,'platform-account-caveat');caveat.append(make('summary','建议如何使用？'),make('p','这些间隔是根据已记录操作给出的谨慎试行建议，不代表平台官方安全阈值。遇到验证或异常退出时，先暂停并核实上次操作。'));
    advice.append(caveat);audit.append(advice);tools.append(audit);
  }
  async function refresh(){
    const current=++refreshSerial;try{
      const nextStatus=await call('assistant_status');
      const snapshot=await call('assistant_workspace_state');
      if(current!==refreshSerial)return;
      status=nextStatus;accounts=(Array.isArray(snapshot.accounts)?snapshot.accounts:[]).filter(item=>item?.platform==='xiaohongshu'&&typeof item.id==='string');
      if(!accounts.some(item=>item.id===selectedId)){selectedId=accounts.find(item=>item.requires_review)?.id||accounts.find(item=>item.status||item.platform_nickname)?.id||accounts[0]?.id||'';safety=null;safetyId='';reportMenuOpen=false;timelineOpen=false;}
      onAccountsChanged(accounts);renderAccounts();renderDetail();
      if(selectedId)await loadSafety(selectedId);
    }catch(error){if(current!==refreshSerial)return;message(error.message||'账号状态读取失败',true);throw error;}
  }
  async function selectAccount(accountId){if(!accounts.some(item=>item.id===accountId))return;selectedId=accountId;safety=null;safetyId='';reportMenuOpen=false;timelineOpen=false;renderAccounts();renderDetail();await loadSafety(accountId);}
  async function loadSafety(accountId){
    if(!accountId)return;const current=++revision;
    try{const value=await call('assistant_account_safety',{account_id:accountId});
      if(current!==revision||selectedId!==accountId)return;safety=value;safetyId=accountId;renderDetail();
    }catch(error){if(current!==revision)return;safety=null;safetyId='';renderDetail();message(error.message||'复核记录读取失败',true);}
  }
  async function completeReview(accountId,browserReauth=false){
    let data;try{if(safetyId!==accountId)throw Error('请先刷新账号复核记录');data=reviewSignal(accountId,safety);}catch(error){message(error.message,true);return;}
    if(busy||loginJob)return;
    if(!confirmReview(browserReauth?'手机小红书能正常浏览，且没有待完成的验证或限制吗？确认后扫码，电脑会自动核对连接。':'手机小红书已恢复正常，并且上次操作结果已核实吗？确认后会检查电脑连接。'))return;
    const reauth=browserReauth||accountRecovery(accounts.find(item=>item.id===accountId)).reauth;
    busy=true;renderAccounts();renderDetail();
    try{message(reauth?(browserLogin()?'正在准备网页登录…':'正在准备二维码…'):'正在检查连接…');await recoverConnection(accountId,safety,payload=>call('assistant_account_signal',payload),reauth?async id=>{safety=null;safetyId='';await refresh();await beginLogin(id,true);}:verifyConnection);safety=null;safetyId='';await refresh();}
    catch(error){safety=null;safetyId='';message(error.message||'连接未确认，采集保持暂停。请先核对手机提示。',true);await refresh().catch(()=>{});}
    finally{busy=false;renderAccounts();renderDetail();}
  }
  async function verifyConnection(accountId){
    if(typeof checkAccount!=='function')throw Error('连接检查暂不可用，请稍后再试');
    const checked=await checkAccount(accountId);
    if(checked?.status==='ready'&&checked.requires_review!==true){message('连接正常，不需要重新扫码。');return checked;}
    throw Error(checked?.requires_review?'电脑端请求仍未通过，请核对手机提示与本次操作；采集保持暂停。':browserLogin()?'登录需要更新，请使用此页的网页登录。':'登录需要更新，请使用此页的扫码登录。');
  }
  async function checkConnection(accountId){
    if(busy||loginJob)return;busy=true;renderAccounts();renderDetail();message('正在检查连接…');
    try{await verifyConnection(accountId);await refresh();}
    catch(error){message(error.message||'连接检查未完成，请稍后再试',true);await refresh().catch(()=>{});}
    finally{busy=false;renderAccounts();renderDetail();}
  }
  async function reportSignal(accountId,kind,label){
    if(busy||loginJob)return;
    if(!confirmReview(`确认${label}？记录后该账号相关平台操作会暂停，需人工核实。`))return;
    reportMenuOpen=false;busy=true;renderAccounts();renderDetail();
    try{await call('assistant_account_signal',{account_id:accountId,kind});message('安全提醒已记录，相关操作将暂停。');await refresh();}
    catch(error){message(error.message||'提醒未记录，请核对状态',true);await loadSafety(accountId);}
    finally{busy=false;renderAccounts();renderDetail();}
  }
  async function beginLogin(accountId='',afterReview=false){
    if(!loginAllowed()||loginJob||busy&&!afterReview)return;
    const account=accounts.find(item=>item.id===accountId);
    if(account&&!accountRecovery(account).canLogin){message('请先完成手机验证并核实账号，暂勿重复扫码。',true);return;}
    busy=true;flowStage=0;loginInterrupted=false;loginMode=browserLogin()?'browser':'qr';qr.hidden=false;qrImage.hidden=true;message('');shell.querySelector('.platform-account-qr-head strong').textContent='准备登录';shell.querySelector('.platform-account-qr-close').textContent='取消';qrMessage.textContent='正在准备小红书二维码…';renderAccounts();renderDetail();
    try{const result=await call(accountId?'assistant_account_login':'assistant_new_account_login',accountId?{account_id:accountId}:{});
      if(!QR_JOB.test(result?.login_job||''))throw Error('登录任务编号无效，请核对助手状态');
      loginMode=result.mode==='browser'?'browser':'qr';loginJob=result.login_job;pollLogin(loginJob);await refresh();
    }catch(error){shell.querySelector('.platform-account-qr-head strong').textContent='登录未完成';qrMessage.textContent=error.message||'二维码未准备好，请稍后再试。';shell.querySelector('.platform-account-qr-close').textContent='返回';}
    finally{busy=false;renderAccounts();renderDetail();}
  }
  async function pollLogin(job){
    stopPolling();if(job!==loginJob||qr.hidden)return;
    try{
      const value=await call('assistant_job_status',{job_id:job});
      if(job!==loginJob||qr.hidden)return;
      if(value.mode==='browser')loginMode='browser';
      if(value.status==='running'){
        if(loginMode==='browser'&&value.phase==='waiting_browser'){message('');flowStage=0;qrImage.hidden=true;shell.querySelector('.platform-account-qr-head strong').textContent='等待扫码';qrMessage.textContent='在小红书登录窗口扫码并确认，随后自动连接。';}
        else if(loginMode==='browser'&&value.phase==='opening_browser'){flowStage=0;qrImage.hidden=true;qrMessage.textContent='正在准备小红书二维码…';}
        else if(value.phase==='closing_previous_login'){message('');flowStage=0;qrImage.hidden=true;shell.querySelector('.platform-account-qr-head strong').textContent='正在准备登录';qrMessage.textContent='正在关闭上一个登录窗口，随后自动打开…';}
        else if(value.phase==='verifying_identity'){message('');flowStage=1;qrImage.hidden=true;shell.querySelector('.platform-account-qr-head strong').textContent='正在自动核对';qrMessage.textContent='已收到扫码确认，正在核对电脑连接…';}
        else if(value.phase==='confirming_connection'){message('');flowStage=1;qrImage.hidden=true;shell.querySelector('.platform-account-qr-head strong').textContent='正在自动连接';qrMessage.textContent='账号已确认，正在连接工作台…';}
        else if(['saving_session','cleaning_candidate'].includes(value.phase)){message('');flowStage=1;qrImage.hidden=true;shell.querySelector('.platform-account-qr-head strong').textContent='正在保存登录';qrMessage.textContent='正在完成连接，马上就好…';}
        else if(value.qr_ready){message('');flowStage=0;shell.querySelector('.platform-account-qr-head strong').textContent='等待扫码';if(qrImage.hidden){qrImage.src=`/assistant-qr/${job}?t=${Date.now()}`;qrImage.hidden=false;}qrMessage.textContent='用小红书 App 扫码并确认，随后自动连接。';}
        else qrMessage.textContent='正在等待二维码…';
        renderAccounts();renderDetail();
        pollTimer=setTimeout(()=>void pollLogin(job),1500);return;
      }
      loginJob='';qrImage.hidden=true;shell.querySelector('.platform-account-qr-head strong').textContent='登录未完成';shell.querySelector('.platform-account-qr-close').textContent='返回';qrMessage.textContent=value.error||'连接未完成，请查看手机提示后再试。';
      if(value.status==='completed'){qr.hidden=true;flowStage=2;message('');}
      await refresh();
    }catch(error){loginInterrupted=true;qrImage.hidden=true;shell.querySelector('.platform-account-qr-head strong').textContent='连接中断';qrMessage.textContent=error.message||'扫码结果尚未确认，请取消后再试。';renderAccounts();renderDetail();}
  }
  shell.querySelector('.platform-account-qr-close').addEventListener('click',async()=>{const job=loginJob,mode=loginMode;stopPolling();busy=true;renderAccounts();renderDetail();if(job&&mode==='browser'){try{await call('assistant_cancel_login',{job_id:job});}catch{busy=false;message('登录窗口尚未关闭，请先关闭小红书登录窗口。',true);renderAccounts();renderDetail();return;}}loginJob='';flowStage=0;qr.hidden=true;qrImage.hidden=true;qrImage.removeAttribute('src');busy=false;void refresh().catch(()=>{});});
  return {refresh,reset,openReview(accountId=''){
    if(accountId){selectedId=accountId;safety=null;safetyId='';}
    if(accountId&&!accounts.some(item=>item.id===accountId))return;
    const target=accounts.find(item=>item.id===selectedId)||accounts.find(item=>item.requires_review)||accounts[0];
    if(target)void selectAccount(target.id);
  },setAccounts(items){if(!Array.isArray(items))return;accounts=items.filter(item=>item?.platform==='xiaohongshu'&&typeof item.id==='string');renderAccounts();renderDetail();}};
}
