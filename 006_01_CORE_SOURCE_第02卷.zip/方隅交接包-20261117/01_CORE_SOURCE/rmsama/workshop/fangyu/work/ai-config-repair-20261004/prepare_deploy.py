"""Reuse the existing reviewed code-only CloudBase deployment workflow."""
from pathlib import Path

folder=Path(__file__).resolve().parent
project=folder.parents[1]
source=project/'work/openai-integration-20261004/deploy.cjs'
code=source.read_text('utf-8')
changes={
 "path.join(__dirname,'baseline-review.json')":"path.join(__dirname,'../openai-integration-20261004/deployment.json')",
 "const files=['ai_contract.cjs','ai_provider.cjs','ai_enterprise.cjs','site/index.html','site/enterprise-ui.mjs','site/site.css'];":
 "const files=['ai_contract.cjs','ai_provider.cjs','ai_enterprise.cjs','site/index.html','site/app.mjs','site/enterprise-model.mjs','site/enterprise-ui.mjs','site/site.css'];",
 "User explicitly requested OpenAI API integration, switchable DeepSeek and truthful frontend model display on 2026-10-04.":
 "User explicitly requested fixing enterprise configuration saves, hiding employee budgets, tracking usage and locking the selected model on 2026-10-04."
}
for old,new in changes.items():
    if code.count(old)!=1:raise RuntimeError('deployment_template_changed')
    code=code.replace(old,new)
destination=folder/'deploy.cjs'
if destination.exists():raise RuntimeError('deployment_script_already_exists')
destination.write_text(code,'utf-8')
print('deployment workflow prepared; no cloud changes')
