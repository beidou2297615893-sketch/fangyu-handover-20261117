"""Verify owner configuration only; never call a paid model or print secrets."""
import argparse, importlib.util, json, sys, uuid
from pathlib import Path

project=Path(__file__).resolve().parents[3]
module_path=project/'work/owner-admin-20261004/owner_admin.py'
spec=importlib.util.spec_from_file_location('verified_owner_portal',module_path)
portal=importlib.util.module_from_spec(spec);spec.loader.exec_module(portal)

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--verify-save',action='store_true')
    args=parser.parse_args();owner=portal.Owner()
    profile=owner.profile();current=profile['config']
    report={'paid_model_calls':0,'platform_calls':0,'admin_verified':profile['user']['role']=='admin',
            'provider':current['provider'],'model':current['model'],'revision':current['revision'],
            'openai_key_configured':current['providers']['openai']['configured'],
            'usage_visible_to_admin':isinstance(profile.get('usage'),dict)}
    if args.verify_save:
        fields=('provider','enabled','model','daily_budget_cny','usd_cny_rate','rules_version')
        values={field:current[field] for field in fields}
        if current['provider']=='openai':values['reasoning_effort']=current['reasoning_effort']
        request_id=str(uuid.uuid4())
        result=owner.call('ai_config_save',{'config':values,'request_id':request_id,
                                         'expected_revision':current['revision']})
        fresh=owner.call('ai_config_read',{})['config']
        checked=(fresh['last_save_id']==request_id and fresh['revision']==current['revision']+1
                 and all(fresh[field]==value for field,value in values.items())
                 and fresh['providers']==current['providers'])
        if not checked:raise RuntimeError('save_verification_failed')
        report.update(save_round_trip_verified=True,key_field_submitted=False,
                      selected_settings_unchanged=True,new_revision=fresh['revision'])
    destination=Path(__file__).with_name('real-save-proof.json' if args.verify_save else 'real-profile-proof.json')
    destination.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8')
    print(json.dumps(report,ensure_ascii=False))

if __name__=='__main__':
    try:main()
    except Exception as exc:
        print(json.dumps({'verified':False,'safe_code':getattr(exc,'code','OWNER_PROBE_FAILED'),
                          'error_type':type(exc).__name__,'paid_model_calls':0}));sys.exit(1)
