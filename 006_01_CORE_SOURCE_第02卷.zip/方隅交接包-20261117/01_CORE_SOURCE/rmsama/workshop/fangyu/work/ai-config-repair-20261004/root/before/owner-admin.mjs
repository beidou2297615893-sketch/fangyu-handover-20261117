const PROVIDERS = Object.freeze({openai: 'OpenAI', deepseek: 'DeepSeek'});
const KEY_URLS = Object.freeze({openai: 'https://platform.openai.com/api-keys', deepseek: 'https://platform.deepseek.com/api_keys'});
const EFFORT_LABELS = Object.freeze({none: '关闭推理', low: '低 · 更快', medium: '中', high: '高', xhigh: '超高', max: '最高'});
const MODEL_ID = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,79}$/;
const SAFE_ERROR = '保存结果未确认，请刷新状态后核对。';

export function acceptedCatalog(config) {
  if (!Array.isArray(config?.model_catalog)) return [];
  const seen = new Set();
  return config.model_catalog.filter(item => {
    if (!item || !Object.hasOwn(PROVIDERS, item.provider) || typeof item.id !== 'string' || !MODEL_ID.test(item.id)) return false;
    const key = `${item.provider}:${item.id}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  }).map(item => ({
    id: item.id,
    provider: item.provider,
    label: typeof item.label === 'string' && item.label.trim() ? item.label.slice(0, 100) : item.id,
    reasoning_efforts: Array.isArray(item.reasoning_efforts) ? item.reasoning_efforts.filter(value => Object.hasOwn(EFFORT_LABELS, value)) : []
  }));
}

export function modelChoices(config, provider) {
  return acceptedCatalog(config).filter(item => item.provider === provider);
}

export function providerEntry(config, provider) {
  return config?.providers?.[provider] && typeof config.providers[provider] === 'object'
    ? config.providers[provider]
    : provider === config?.provider ? config : {};
}

export function deviceOverview(devices, nowSeconds = Date.now() / 1000) {
  const rows = Array.isArray(devices) ? devices : [];
  const online = rows.filter(item => !item.revoked && Number(item.last_seen) > 0 && nowSeconds - Number(item.last_seen) < 90).length;
  const revoked = rows.filter(item => !!item.revoked).length;
  return {online, offline: rows.length - online - revoked, revoked};
}

function node(doc, tag, content, className) {
  const element = doc.createElement(tag);
  if (content !== undefined) element.textContent = String(content);
  if (className) element.className = className;
  return element;
}

export function createOwnerAdmin(doc, request = fetch.bind(globalThis)) {
  const $ = id => doc.getElementById(id);
  const state = {csrf: '', config: null, profile: null, catalog: [], busy: false, page: 'ai', generation: 0};
  const form = $('ai-config-form');
  const formControls = [...form.querySelectorAll('input,select,button')];
  const key = $('ai-key');
  const clearKey = () => { key.value = ''; $('ai-clear-key').checked = false; };
  const setFeedback = (message, error = false) => {
    $('page-feedback').textContent = message;
    $('page-feedback').classList.toggle('is-error', error);
  };
  const setSaveFeedback = (message, error = false) => {
    $('ai-save-feedback').textContent = message;
    $('ai-save-feedback').classList.toggle('is-error', error);
  };
  const setEnabled = enabled => {
    for (const control of formControls) control.disabled = !enabled || state.busy;
    $('ai-save').disabled = !enabled || state.busy;
    if (enabled) $('ai-effort').disabled = $('ai-effort-label').hidden || state.busy;
  };
  const resetView = () => {
    state.config = null; state.catalog = []; state.profile = null;
    $('ai-provider').replaceChildren(node(doc, 'option', '状态待读取'));
    $('ai-model').replaceChildren(node(doc, 'option', '状态待读取'));
    $('ai-effort').replaceChildren();
    $('ai-state-chip').textContent = '待读取';
    $('ai-current-model').textContent = '尚未读取';
    $('ai-budget-state').textContent = '预算状态待读取';
    $('ai-configured').textContent = '密钥状态待读取';
    clearKey(); setEnabled(false);
  };
  const json = async (url, options = {}) => {
    const response = await request(url, {cache: 'no-store', credentials: 'same-origin', ...options});
    if (!response.ok) throw Error('request failed');
    return response.json();
  };
  const cloud = (operation, data = {}) => {
    if (!state.csrf) throw Error('bootstrap missing');
    return json('/api/cloud', {method: 'POST', headers: {'Content-Type': 'application/json', 'X-Fangyu-CSRF': state.csrf}, body: JSON.stringify({operation, data})});
  };
  const model = () => state.catalog.find(item => item.provider === $('ai-provider').value && item.id === $('ai-model').value);
  const showEfforts = preferred => {
    const entry = model();
    const efforts = entry?.reasoning_efforts || [];
    $('ai-effort').replaceChildren(...efforts.map(value => {
      const option = node(doc, 'option', EFFORT_LABELS[value]); option.value = value; return option;
    }));
    $('ai-effort-label').hidden = efforts.length === 0;
    $('ai-effort').disabled = efforts.length === 0 || state.busy;
    const chosen = efforts.includes(preferred) ? preferred : entry?.id === 'gpt-5.4-mini' && efforts.includes('none') ? 'none' : efforts.includes('low') ? 'low' : efforts[0] || '';
    $('ai-effort').value = chosen;
  };
  const showProvider = (provider, preferredModel, preferredEffort) => {
    clearKey();
    const choices = modelChoices(state.config, provider);
    $('ai-model').replaceChildren(...choices.map(item => {
      const option = node(doc, 'option', item.label); option.value = item.id; return option;
    }));
    $('ai-model').value = choices.some(item => item.id === preferredModel) ? preferredModel : choices[0]?.id || '';
    const entry = providerEntry(state.config, provider);
    $('ai-configured').textContent = entry.configured ? '该供应商密钥已配置' : '请填写该供应商的 API 密钥';
    $('ai-key-help').href = KEY_URLS[provider];
    $('ai-key-help').textContent = `获取 ${PROVIDERS[provider]} API 密钥`;
    $('ai-usd-rate-label').hidden = provider !== 'openai';
    showEfforts(preferredEffort);
  };
  const showConfig = config => {
    if (!config || typeof config !== 'object') throw Error('config missing');
    const catalog = acceptedCatalog(config);
    if (!catalog.length) throw Error('catalog missing');
    state.config = config; state.catalog = catalog;
    const providers = Object.keys(PROVIDERS).filter(provider => catalog.some(item => item.provider === provider));
    $('ai-provider').replaceChildren(...providers.map(provider => {
      const option = node(doc, 'option', PROVIDERS[provider]); option.value = provider; return option;
    }));
    const selected = providers.includes(config.provider) ? config.provider : providers[0];
    $('ai-provider').value = selected;
    $('ai-enabled').checked = !!config.enabled;
    $('ai-daily-budget').value = Number.isFinite(Number(config.daily_budget_cny)) ? config.daily_budget_cny : 5;
    $('ai-usd-rate').value = Number.isFinite(Number(config.usd_cny_rate)) ? config.usd_cny_rate : 7.5;
    $('ai-rules-version').value = typeof config.rules_version === 'string' ? config.rules_version : '';
    const entry = providerEntry(config, selected);
    showProvider(selected, entry.model, entry.reasoning_effort);
    const selectedModel = model();
    const activeProvider = Object.hasOwn(PROVIDERS, config.provider) ? config.provider : selected;
    const activeEntry = providerEntry(config, activeProvider);
    $('ai-state-chip').textContent = !config.enabled ? '未启用' : activeEntry.configured ? '已启用' : '待配置密钥';
    $('ai-current-model').textContent = `${PROVIDERS[selected]} · ${selectedModel?.label || '模型待读取'}`;
    setEnabled(true);
  };
  const showBudget = budget => {
    if (!budget || typeof budget !== 'object') { $('ai-budget-state').textContent = '预算状态暂不可用'; return; }
    const spent = Number(budget.spent_cny), remaining = Number(budget.remaining_cny), limit = Number(budget.limit_cny);
    $('ai-budget-state').textContent = [spent, remaining, limit].every(Number.isFinite)
      ? `今日已用 ¥${spent.toFixed(3)} / ¥${limit.toFixed(2)} · 剩余 ¥${remaining.toFixed(3)}`
      : '预算状态暂不可用';
  };
  const showDevices = devices => {
    if (!Array.isArray(devices)) throw Error('devices missing');
    const counts = deviceOverview(devices);
    $('devices-online').textContent = counts.online;
    $('devices-offline').textContent = counts.offline;
    $('devices-revoked').textContent = counts.revoked;
    $('device-summary').hidden = false;
    const list = $('device-list'); list.replaceChildren();
    if (!devices.length) list.append(node(doc, 'p', '当前没有助手设备。', 'empty'));
    for (const device of devices) {
      const online = !device.revoked && Number(device.last_seen) > 0 && Date.now() / 1000 - Number(device.last_seen) < 90;
      const status = device.revoked ? '已停用' : online ? '在线' : '离线';
      const version = device.version ? `${online ? '当前' : '上次上报'}版本 ${String(device.version).slice(0, 80)}` : '版本待上报';
      const row = node(doc, 'div', undefined, 'row maintenance-row');
      const body = node(doc, 'div');
      body.append(node(doc, 'strong', String(device.name || '未命名设备').slice(0, 100)), node(doc, 'small', `${String(device.owner || '归属未知').slice(0, 80)} · ${status} · ${version}`));
      row.append(body); list.append(row);
    }
  };
  const refreshAi = async (initial = false) => {
    if (state.busy) return;
    const generation = ++state.generation;
    resetView(); setSaveFeedback(''); setFeedback('正在读取企业配置…');
    try {
      const result = initial ? await json('/api/profile') : await cloud('ai_config_read');
      if (generation !== state.generation) return;
      if (initial && (result?.user?.role !== 'admin' || result?.user?.username !== 'rmsama')) throw Error('profile invalid');
      const config = initial ? result?.config : result?.config;
      showConfig(config);
      if (initial) showBudget(result?.budget);
      else {
        try { const profile = await cloud('ai_profile'); if (generation === state.generation) showBudget(profile?.budget); }
        catch { if (generation === state.generation) showBudget(null); }
      }
      if (generation === state.generation) setFeedback('');
    } catch {
      if (generation !== state.generation) return;
      resetView(); setFeedback('企业配置读取失败，请刷新状态后重试。', true);
    }
  };
  const refreshDevices = async () => {
    setFeedback('正在读取设备状态…');
    try { const result = await cloud('devices'); showDevices(result?.devices); setFeedback(''); }
    catch { $('device-summary').hidden = true; $('device-list').replaceChildren(node(doc, 'p', '设备状态读取失败，请刷新后重试。', 'empty')); setFeedback('设备状态读取失败，请刷新后重试。', true); }
  };
  const navigate = page => {
    if (state.busy || page !== 'ai' && page !== 'devices') return;
    clearKey(); state.page = page;
    $('page-ai').hidden = page !== 'ai'; $('page-devices').hidden = page !== 'devices';
    $('page-title').textContent = page === 'ai' ? '企业 AI' : '设备';
    $('page-subtitle').textContent = page === 'ai' ? '查看真实配置，选择服务和模型。' : '查看在线状态、归属和客户端版本。';
    for (const button of doc.querySelectorAll('[data-page]')) {
      button.classList.toggle('active', button.dataset.page === page);
      if (button.dataset.page === page) button.setAttribute('aria-current', 'page'); else button.removeAttribute('aria-current');
    }
    setFeedback('');
    if (page === 'devices') void refreshDevices();
  };
  const save = async event => {
    event?.preventDefault();
    if (state.busy || !state.config) return;
    const selected = model(), provider = $('ai-provider').value;
    if (!selected || selected.provider !== provider) { setSaveFeedback('请先选择有效模型。', true); return; }
    const daily = Number($('ai-daily-budget').value), rate = Number($('ai-usd-rate').value);
    if (!Number.isFinite(daily) || daily < 0 || daily > 1000 || !Number.isFinite(rate) || rate < 1 || rate > 20) {
      setSaveFeedback('请核对预算和汇率。', true); return;
    }
    const config = {provider, enabled: $('ai-enabled').checked, model: selected.id, daily_budget_cny: daily, rules_version: $('ai-rules-version').value};
    if (state.catalog.some(item => item.provider === 'openai')) config.usd_cny_rate = rate;
    if (provider === 'openai' && selected.reasoning_efforts.length) config.reasoning_effort = $('ai-effort').value;
    const data = {config};
    if (key.value) data.api_key = key.value;
    if ($('ai-clear-key').checked) data.clear_api_key = true;
    state.busy = true; setEnabled(false); $('refresh').disabled = true; setSaveFeedback('正在保存…');
    let saved = false;
    try {
      const result = await cloud('ai_config_save', data);
      if (!result?.config) throw Error('save unconfirmed');
      saved = true; clearKey();
      const fresh = await cloud('ai_config_read');
      showConfig(fresh?.config);
      setSaveFeedback('企业配置已保存。');
      try { const profile = await cloud('ai_profile'); showBudget(profile?.budget); } catch { showBudget(null); }
    } catch {
      clearKey();
      if (saved) { resetView(); setSaveFeedback('配置已保存，但状态读取失败，请刷新核对。', true); }
      else setSaveFeedback(SAFE_ERROR, true);
    } finally { state.busy = false; setEnabled(!!state.config); $('refresh').disabled = false; clearKey(); }
  };
  const bootstrap = async () => {
    resetView();
    try {
      const localWindow = doc.defaultView;
      const result = await json('/api/bootstrap', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({launch: localWindow?.location?.hash?.slice(1) || ''})
      });
      if (result?.contract !== 'fangyu-owner-admin-v1' || typeof result.csrf !== 'string' || !result.csrf) throw Error('bootstrap invalid');
      state.csrf = result.csrf;
      localWindow?.history?.replaceState(null, '', localWindow.location.pathname);
      await refreshAi(true);
    } catch { resetView(); setFeedback('本机管理服务未就绪，请刷新页面后重试。', true); }
  };
  $('ai-provider').addEventListener('change', () => { if (state.busy || !state.config) return; showProvider($('ai-provider').value, providerEntry(state.config, $('ai-provider').value).model, providerEntry(state.config, $('ai-provider').value).reasoning_effort); });
  $('ai-model').addEventListener('change', () => { showEfforts(providerEntry(state.config, $('ai-provider').value).reasoning_effort); });
  $('ai-clear-key').addEventListener('change', () => { if ($('ai-clear-key').checked) key.value = ''; });
  form.addEventListener('submit', save);
  for (const button of doc.querySelectorAll('[data-page]')) button.addEventListener('click', () => navigate(button.dataset.page));
  $('refresh').addEventListener('click', () => { clearKey(); void (state.page === 'ai' ? refreshAi() : refreshDevices()); });
  $('refresh-devices').addEventListener('click', () => { void refreshDevices(); });
  doc.defaultView?.addEventListener('pagehide', clearKey);
  void bootstrap();
  return {state, refreshAi, refreshDevices, navigate, save, clearKey};
}

if (typeof document !== 'undefined' && document.getElementById('ai-config-form')) createOwnerAdmin(document);
