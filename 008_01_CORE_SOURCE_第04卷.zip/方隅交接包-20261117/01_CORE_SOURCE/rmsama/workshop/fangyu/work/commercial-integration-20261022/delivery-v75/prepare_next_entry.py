from pathlib import Path
import ast,hashlib,json
D=Path(__file__).resolve().parent;W=D.parent
source=W/'delivery-v74/install_verified_entry.py';raw=source.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='3546cae5107b722c6c6959ab5b6fff1b38e548a1e011d344c17dee960051face'
text=raw.decode('utf-8');tree=ast.parse(text);lines=text.splitlines(keepends=True)
replacement={
 'ACCEPTED':'ACCEPTED = {}\n',
 'INSTALLATION_REVIEWED':'INSTALLATION_REVIEWED = False  # Fixed final75 acceptance still required.\n',
 'OLD_LAUNCHER_SHA':"OLD_LAUNCHER_SHA = 'ae5afe6372c00c63c36d85c25ffe1cf5c2e9139b26dc6383210e0b8d109b1518'\n",
 'OLD_FROZEN_SHA':"OLD_FROZEN_SHA = 'f0a3079ce651227ce4a9f3dd764db83927d90c2b3e3e119e9aada3db36b9584c'\n"}
nodes=[n for n in tree.body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id in replacement]
assert len(nodes)==4
for n in sorted(nodes,key=lambda n:n.lineno,reverse=True):lines[n.lineno-1:n.end_lineno]=[replacement[n.targets[0].id]]
text=''.join(lines)
anchor="    closure(F / 'candidate-unified-v73', 'c0a72be807965903a5cbb9dfee9ba6549a6157ccf622fd7df86a9ef1397a167b', 3156)"
assert text.count(anchor)==1
text=text.replace(anchor,anchor+"\n    closure(F / 'candidate-unified-v74', '22e8969074ee54babe2d28619d95944bac78d4ae5f2085ed41541f0d833ccae7', 3282)")
old="    expected = P / 'work/commercial-integration-20261022/delivery-v74'";new=old.replace('v74','v75')
assert text.count(old)==1;text=text.replace(old,new)
newtree=ast.parse(text)
functions=lambda t:{n.name:ast.dump(n,include_attributes=False) for n in t.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
before,after=functions(tree),functions(newtree)
assert {k for k in before if before[k]!=after[k]}=={'check','main'}
target=D/'install_verified_entry.py';assert not target.exists();target.write_text(text,encoding='utf-8')
report={'sourceSha256':hashlib.sha256(raw).hexdigest(),'draftSha256':hashlib.sha256(target.read_bytes()).hexdigest(),
 'allFunctionsExceptCheckAndMainIdentical':True,'checkOnlyAdds74Rollback':True,'mainOnlyUpdatesExactFolder75':True,
 'accepted':{},'installationReviewed':False,'canonicalWritten':False}
(D/'NEXT-ENTRY-DRAFT.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report))
