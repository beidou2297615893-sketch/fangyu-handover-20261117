from pathlib import Path
import ast,hashlib,json
W=Path(__file__).resolve().parent;P=W.parents[2]
F=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v82/project';S=W/'source-candidate'
origins=json.loads((W/'BEFORE-ORIGINS.json').read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(rel,origin,text):
    path=S/rel;ast.parse(text);path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists():assert path.read_text('utf-8')==text
    else:path.write_text(text,'utf-8')
    origins.append({'path':rel,'beforeOrigin':str(origin),
        'beforeSha256':sha(origin),'afterSha256':sha(path)})
rel='work/ui-runtime-r55/src/core/adapters.py';origin=F/rel;t=origin.read_text('utf-8')
for operation,call in [('search','_douyin_search_call'),('comments','_douyin_comments_call')]:
    needle=('    def search(self, platform, task, verification=False):\n        self._guard_platform(platform)\n' if operation=='search' else
        '    def comments(self,platform,task):\n        self._guard_platform(platform)\n')
    assert t.count(needle)==1
    t=t.replace(needle,needle+f"""        if platform=='douyin' and task.get('{call}') is None:
            from .douyin_customer_tasks import current
            scope=current(self)
            if scope is not None:return scope.read('{operation}',task)
""")
write(rel,origin,t)
for rel in ('work/ui-runtime-r55/src/assistant/business.py','work/shared-backend-integration/vendor-src/assistant/business.py'):
    origin=F/rel;t=origin.read_text('utf-8')
    needle='    def _verify_first_douyin_search(self,user,task):\n        """Reuse the original first-search probe on an explicit own task only."""\n'
    assert t.count(needle)==(1 if 'vendor-src' in rel else 0)
    t=t.replace(needle,needle+"""        from core.douyin_customer_tasks import current
        customer_scope=current(self.core.adapters)
        if customer_scope is not None:
            # The first actual owned_search performs the original UID checks.
            # Never set or borrow the global legacy search_verified flag.
            customer_scope.check()
            return
""")
    needle="            lease_owner='batch:'+task['id']\n            leased=False\n"
    assert t.count(needle)==1
    t=t.replace(needle,needle+"            customer_context=None;customer_scope=None\n")
    needle="                leased=True\n                self._claim_xhs_account(account)\n"
    assert t.count(needle)==1
    t=t.replace(needle,needle+"""                from core.douyin_customer_tasks import collection_scope
                customer_context=collection_scope(self,user,task)
                customer_scope=customer_context.__enter__()
""")
    needle="            finally:\n                runtime=self.core.adapters.xhs_page_runtime\n                if leased and (runtime is None or not runtime.has_pending_batch(task['id'])):\n"
    assert t.count(needle)==1
    t=t.replace(needle,"""            finally:
                if customer_context is not None:customer_context.__exit__(None,None,None)
                runtime=self.core.adapters.xhs_page_runtime
                if leased and (runtime is None or not runtime.has_pending_batch(task['id'])):
""")
    needle="            if result.get('summary') and self._xiaohongshu_held():\n"
    assert t.count(needle)==1
    t=t.replace(needle,"""            if customer_scope is not None:
                from core.douyin_customer_tasks import NOTICE
                result['message']=str(result.get('message') or '')+'；'+NOTICE
            if result.get('summary') and self._xiaohongshu_held():
""")
    write(rel,origin,t)
(W/'BEFORE-ORIGINS.json').write_text(json.dumps(origins,ensure_ascii=False,indent=2),'utf-8')
print('Bounded original adapter and task_run consumers constructed')
