"""Run the existing read-only scope/rule audit with a new evidence directory."""
from pathlib import Path
import ast,hashlib,json
W=Path(__file__).resolve().parents[1]
original=W/'audit_store_data.py'
before=original.read_text('utf-8')
needle="OUT=W/'store-data-audit';OUT.mkdir(exist_ok=True)"
assert before.count(needle)==1
after=before.replace(needle,"OUT=W/'delivery-v71/data-audit-before-install';OUT.mkdir(exist_ok=True)")
def assertions(text):return [ast.dump(n,include_attributes=False) for n in ast.walk(ast.parse(text)) if isinstance(n,ast.Assert)]
assert assertions(before)==assertions(after)
namespace={'__name__':'__main__','__file__':str(original)}
exec(compile(after,str(original),'exec'),namespace)
result=namespace['result']
assert result['business']['commentRows']==1888
assert result['business']['uniqueAuthorsByPlatform']==1129
assert result['business']['allTasksGubei'] and result['business']['allCommentsJoinGubei']
assert not result['structuralProblems'] and not result['materialReferenceProblems']
assert all(s['unchangedFromInstalledV63'] for s in result['stores'] if s['storeId']!='fy_s_d343f3a378f48e1bab55df4f')
proof={'originalSha256':hashlib.sha256(original.read_bytes()).hexdigest(),'originalAssertionsRetained':True,'productionWrite':False,'onlyOutputRouteChanged':True,'status':'PASS_REAL_BUSINESS_SCOPE_AND_THIRTEEN_STORE_RULES'}
(namespace['OUT']/'ROUTE-RECEIPT.json').write_text(json.dumps(proof,indent=2)+'\n','utf-8')
