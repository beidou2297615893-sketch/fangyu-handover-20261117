from pathlib import Path
import ast,hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
C=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/candidate-unified-v68')
S=C/'project';staged=json.loads((C/'STAGED.json').read_text('utf-8'));R=Path(staged['release'])
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(C/'UNIFIED-PINS.json')=='2e5ef460a79c631e87abb9674f4f41ada971962822f9732b1bf582eced5fe6fa'
unified=json.loads((C/'UNIFIED-PINS.json').read_text('utf-8'));checked=[]
assert len(unified['files'])==3113
for item in unified['files']:
 p=S/item['path'];assert p.is_relative_to(S) and not p.is_symlink()
 assert p.stat().st_size==item['bytes'] and sha(p)==item['sha256'],item['path']
 checked.append(item['path'])
spec=importlib.util.spec_from_file_location('frozen_closure_host',R/'ui_native_host.py');host=importlib.util.module_from_spec(spec);spec.loader.exec_module(host)
manifest,files=host.verify_release(R,staged['manifest_sha256'])
source=host.verify_backend_dependencies(R,files,S)
required=['workbench_backend.py','ui_native_host.py','customer_workbench.py','customer_intent_workbench.py','keyword_effect_workbench.py',
 'resources/content-workbench/content_workflow.py','resources/content-workbench/workflow_methods.py',
 'resources/content-gateway/gateway_adapter.py','resources/content-gateway/trusted_method_pins.py',
 'web/pages/interaction-inbox.mjs','web/pages/keyword-effect.css','web/pages/keyword-effect.mjs','web/pages/customer-intent-correction.mjs']
for name in required:assert name in files,name
assert (source/'core/interaction_inbox.py').is_file() if 'source' in locals() else True
vendor=R/'resources/platform-runtime/vendor-src';provenance=json.loads((vendor/'SOURCE.json').read_text('utf-8'))
assert len(provenance['files'])==13
provenance_differences=[]
for name,pins in provenance['files'].items():
 assert sha(vendor/name)==pins['candidate_sha256'],name
 if pins['source_sha256'] is not None and sha(source/name)!=pins['source_sha256']:
  provenance_differences.append({'file':name,'declaredSourceSha':pins['source_sha256'],'frozenSourceSha':sha(source/name),'candidateShaVerified':True})
assert not provenance_differences,provenance_differences
assert (source/'core/interaction_inbox.py').is_file() and (source/'assistant/intent_correction.py').is_file()
trial=provenance['source_trial'];cli=S/trial['xiaohongshu']['root'];guard=json.loads((cli/'guard-manifest.json').read_text('utf-8'))
assert trial['xiaohongshu']['root']=='work/source-v66-worker/component/artifacts/platform-cli-guarded'
assert sha(cli/'guard-manifest.json')==trial['xiaohongshu']['guard_manifest_sha256']
assert guard==trial['xiaohongshu']['expected']
assert sha(cli/'platform-cli.exe')==guard['exe_sha256']
spec=importlib.util.spec_from_file_location('frozen_cli_tree_verifier',source/'core/runtime_guards.py')
tree=importlib.util.module_from_spec(spec);spec.loader.exec_module(tree)
assert tree.cli_runtime_tree_sha256(cli)==guard['runtime_tree_sha256']
company=json.loads((S/trial['company_file']).read_text('utf-8'));assert sha(S/trial['company_file'])==trial['company_sha256']
assert company['runtime']['cli_source_sha256']==guard['source_sha256'] and company['runtime']['public_send_hold'] is True
assert company['runtime']['release_approved'] is False and trial['component_use_policy']=='pending'
runtime=(R/'resources/platform-runtime/platform_runtime.py').read_text('utf-8')
assert trial['xiaohongshu']['root'] in runtime
constants={}
for n in ast.parse((vendor/'assistant/employee_distribution.py').read_text('utf-8')).body:
 if isinstance(n,ast.Assign) and isinstance(n.value,ast.Constant):
  for t in n.targets:
   if isinstance(t,ast.Name):constants[t.id]=n.value.value
for key,field in [('WORKBENCH_SOURCE_SHA256','source_sha256'),('WORKBENCH_EXE_SHA256','exe_sha256'),('WORKBENCH_TREE_SHA256','runtime_tree_sha256')]:assert constants[key]==guard[field]
report=dict(status='PASS_RUNTIME_CLOSURE_WITH_PROVENANCE_DIFFERENCES' if provenance_differences else 'PASS',provenanceDifferences=provenance_differences,unifiedFiles=len(checked),releaseFiles=len(files),vendorPins=13,release=str(R),
 manifest=staged['manifest_sha256'],unifiedPinsSha=sha(C/'UNIFIED-PINS.json'),
 requiredFrozenHashes={name:sha(R/name) for name in required},cliPath=trial['xiaohongshu']['root'],
 cliSha=guard['exe_sha256'],cliRuntimeTreeSha=guard['runtime_tree_sha256'],cliExecuted=False,productionAccess=False,componentUsePolicy=trial['component_use_policy'])
(W/'CLOSURE-RESULTS.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf-8');print(json.dumps(report,ensure_ascii=False))
