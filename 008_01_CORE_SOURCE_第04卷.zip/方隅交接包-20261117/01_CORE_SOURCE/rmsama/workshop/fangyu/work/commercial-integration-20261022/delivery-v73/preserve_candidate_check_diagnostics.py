"""Retain root's launcher diagnostics outside the immutable source closure."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,stat
D=Path(__file__).resolve().parent;P=D.parents[2]
C=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v73'
PROJECT=C/'project';SOURCE=PROJECT/'work/ui-native-r57/state/lifecycle'
DEST=D/'candidate-entry-runtime-diagnostics'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
assert sha((C/'UNIFIED-PINS.json').read_bytes())=='c0a72be807965903a5cbb9dfee9ba6549a6157ccf622fd7df86a9ef1397a167b'
pins=json.loads((C/'UNIFIED-PINS.json').read_text('utf-8'))['files']
expected={row['path'] for row in pins}
extras={'work/ui-native-r57/state/lifecycle/.write.lock','work/ui-native-r57/state/lifecycle/lifecycle.jsonl'}
actual={p.relative_to(PROJECT).as_posix() for p in PROJECT.rglob('*') if p.is_file()}
assert len(pins)==3156 and actual-expected==extras and expected<=actual
for row in pins: assert sha((PROJECT/row['path']).read_bytes())==row['sha256']
assert SOURCE.resolve().is_relative_to(PROJECT.resolve()) and DEST.resolve().is_relative_to(D.resolve())
assert not DEST.exists()
rows=[json.loads(line) for line in (SOURCE/'lifecycle.jsonl').read_text('utf-8').splitlines()]
assert rows and {r['pid'] for r in rows}=={23596,30508}
assert all(r['release']=='ui-r57-20261022T221409Z-61609cff' and r['utc'].startswith('2026-10-22T22:18:') for r in rows)
assert {r['pid'] for r in rows if r['stage']=='launcher_exit'}=={23596,30508}
owned=[]
for name in ('.write.lock','lifecycle.jsonl'):
    source=SOURCE/name;target=DEST/name
    for item in (source,*source.parents):
        info=item.lstat();assert not item.is_symlink() and not getattr(info,'st_file_attributes',0)&0x400
    info=source.stat();assert stat.S_ISREG(info.st_mode) and info.st_nlink==1
    raw=source.read_bytes();owned.append((source,target,raw))
assert len(owned[0][2])==1 and len(owned[1][2])==1888
DEST.mkdir()
for source,target,raw in owned:
    assert source.read_bytes()==raw and not target.exists()
    source.rename(target)
    assert not source.exists() and target.read_bytes()==raw
actual={p.relative_to(PROJECT).as_posix() for p in PROJECT.rglob('*') if p.is_file()}
assert actual==expected
for row in pins: assert sha((PROJECT/row['path']).read_bytes())==row['sha256']
record={'status':'PASS_ROOT_OWNED_CHECK_DIAGNOSTICS_PRESERVED_AND_EXACT_CLOSURE_RESTORED',
        'createdAt':datetime.now(timezone.utc).isoformat(),'cause':'Original candidate launcher diagnostics() always writes ROOT/state, even for --check and --self-test. Root ran these two original flags directly at 22:18 UTC.',
        'toolChunks':['962f1b','143371'],'ownedExitedPids':[23596,30508],
        'runtimeArtifacts':[{'original':str(source),'preserved':str(target),'bytes':len(raw),'sha256':sha(raw)} for source,target,raw in owned],
        'pinnedFilesVerifiedBeforeAndAfter':3156,'pinnedFilesOrManifestsChanged':False,
        'runtimeFilesDeleted':False,'productionFilesOrProcessesTouched':False,
        'futureCheckLocation':'Canonical N next-launch wrapper has its own N/state outside the immutable candidate project; do not execute candidate launcher directly again.',
        'invalidSourceReceipt':'a0aefb28271240a1afe8912f8faf65b411aa9027a4c6638a7830e61169fc3998; independent reviewer must generate a fresh closure receipt.'}
(D/'CANDIDATE-DIAGNOSTICS-RECOVERY.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':record['status'],'pinnedFiles':3156,'preservedRuntimeFiles':2},ensure_ascii=False))
