from pathlib import Path
import hashlib,json
D=Path(__file__).resolve().parent
source=D.parent/'delivery-v76/prepare_next_entry.py'
raw=source.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='e71486fa31b0e86379837b0d56e5fbb31a6cb7bef6c6c7418a472b6d76a6d7af'
text=raw.decode('utf-8')
changes=[
 ('Immutable final76 acceptance still required.','Immutable final77 acceptance still required.'),
 ("old.replace('v74', 'v76')","old.replace('v74', 'v77')"),
 ("'mainOnlyUpdatesExactFolder76'","'mainOnlyUpdatesExactFolder77'"),
 ("'checkOnlyAdds74And75Rollback'","'checkOnlyAdds74And75And76Rollback'"),
]
for old,new in changes:
    assert text.count(old)==1,old
    text=text.replace(old,new)
old="    closure(F / 'candidate-unified-v75', 'b8168fdab20627f3daf96ac18b82a99071ed8f9ff9363b73decca990cc5ef0fc', 3288)\")"
new="    closure(F / 'candidate-unified-v75', 'b8168fdab20627f3daf96ac18b82a99071ed8f9ff9363b73decca990cc5ef0fc', 3288)\\n    closure(F / 'candidate-unified-v76', 'c36ef66631478cde825cb6b3b5ec2a9d169d204e711de0751fbb4b84f57d5ecd', 3288)\")"
assert text.count(old)==1
text=text.replace(old,new)
target=D/'prepare_next_entry_derived.py'
assert not target.exists()
target.write_text(text,encoding='utf-8')
(D/'ENTRY-GENERATOR-DERIVATION.json').write_text(json.dumps({'sourceSha256':hashlib.sha256(raw).hexdigest(),'derivedGeneratorSha256':hashlib.sha256(target.read_bytes()).hexdigest(),'scope':'Exact 77 folder/comment/report and add fixed F76 rollback closure; N75 CAS remains unchanged; original v74 safety functions preserved','noCanonicalWrite':True},indent=2)+'\n',encoding='utf-8')
print('PREPARED_EMPTY_V77_ENTRY_GENERATOR_ONLY')
