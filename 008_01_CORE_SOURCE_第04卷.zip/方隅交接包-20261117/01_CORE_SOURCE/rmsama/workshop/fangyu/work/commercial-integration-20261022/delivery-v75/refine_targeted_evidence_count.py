from pathlib import Path
import ast,hashlib,json
D=Path(__file__).resolve().parent;p=D/'install_verified_entry.py';raw=p.read_bytes()
sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha(raw)=='f295258d57bdc9141b8d72436fa74d99d14fe72bab89f3ff4f9a22acc7a54268'
needle=b"    if type(spec['files']) is not int or spec['files'] < 1 or type(spec['http_groups']) is not int or spec['http_groups'] < 32:"
assert raw.count(needle)==1
insert="""    # Exact local recovery acceptance: thirteen newly run HTTP groups.
    # Prior unchanged checks are not relabelled as new executions.
    targeted_recovery = (candidate == 'candidate-unified-v75'
        and spec['delivery'] == 'delivery-v75'
        and spec['release_id'] == 'ui-r57-20261023T024648Z-ca2e7385'
        and spec['unified_sha'] == 'b8168fdab20627f3daf96ac18b82a99071ed8f9ff9363b73decca990cc5ef0fc'
        and spec['http_groups'] == 13 and spec['recovery_checkpoint'] is True
        and isinstance(spec['evidence'], dict)
        and spec['evidence'].get('frozen-native/SUMMARY.json') == '2c126bd2e4616539b2b81b79566dce30b451962aa92fa52542961641fdf95f90'
        and spec['evidence'].get('frozen-native/source-independent.json') == '7753387fbb469efecbeb08611db00302aebfca1de5a189980f0abe7074fc8014')
""".encode()
new=raw.replace(needle,insert+needle.replace(b"spec['http_groups'] < 32:",b"(spec['http_groups'] < 32 and not targeted_recovery):"))
oldtree,newtree=ast.parse(raw.decode()),ast.parse(new.decode())
functions=lambda tree:{n.name:ast.dump(n,include_attributes=False) for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
a,b=functions(oldtree),functions(newtree);assert {k for k in a if a[k]!=b[k]}=={'reviewed_spec'}
(D/'ENTRY-FILLED-RETAINED-COUNT-RED.py').write_bytes(raw);p.write_bytes(new)
out={'beforeSha256':sha(raw),'afterSha256':sha(new),'onlyReviewedSpecChanged':True,
 'original32MinimumForAllOtherCandidatesRetained':True,'exact75RecoveryOnlyNewCount13':True,
 'notPlatformOrTaskPermissionGuardChange':True,'originalCasBackupRollbackPrepareInstallIdentical':True,
 'knownPreexistingLeaseRedRetained':True,'installationReviewed':False,'canonicalWritten':False}
(D/'TARGETED-EVIDENCE-COUNT-DECISION.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out))
