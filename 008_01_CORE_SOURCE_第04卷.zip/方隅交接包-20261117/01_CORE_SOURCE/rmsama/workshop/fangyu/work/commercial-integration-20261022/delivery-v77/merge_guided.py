from pathlib import Path,PurePosixPath
from datetime import datetime,timezone
import hashlib,json,shutil,stat

D=Path(__file__).resolve().parent;W=D.parent;P=W.parents[1]
S=P/'work/parallel-integration-20261018/final-integration/stage-02/project'
C=W/'content-guided-methods-candidate/readable-font-revision'
INDEPENDENT_SHA='a33bcfa669c76606f5643f15036fef652d88dc37e27321a5e9032b44bd1b59d0'
LIBRARY_SHA='4fb6c302bbda90bbe8918bde816052e821707b0d4ed686cddc9a727549f36382'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert INDEPENDENT_SHA is not None and LIBRARY_SHA is not None,'Two actual fixed independent receipts required'
I=W/'guided-method-entry-independent-review/FINAL-RECEIPT.json'
L=W/'guided-library-contract-independent-review/FINAL-RECEIPT.json'
assert sha(I)==INDEPENDENT_SHA and sha(L)==LIBRARY_SHA
assert sha(C/'SEALED.json')=='d83806379810b8eec8d8925a177376a8c82e9446e4e1752c96c5794e11cd5e1e'
assert sha(C/'FINAL-RECEIPT.json')=='4c8ed537d79cfc6ef45a5003e5681fe5f3251b60fc52218f96d1cf7621c0eb0a'
assert sha(C/'SOURCE-FILES.json')=='a2c5978a8539999faa41804e17aa3d131126cfe3edb1e16fc05688790eaccb05'
pins=json.loads((C/'SOURCE-FILES.json').read_text('utf-8'))['files']
assert len(pins)==17 and len({p['path'].casefold() for p in pins})==17
protected={p['path']:p['afterSha256'] for p in json.loads((W/'delivery-v76/MERGE.json').read_text('utf-8'))['files']}
protected.update({p['path']:p['afterSha256'] for p in json.loads((D/'MERGE-CSS.json').read_text('utf-8'))['files']})
assert not set(protected)&{p['path'] for p in pins}
for relative,expected in protected.items():assert sha(S/relative)==expected,relative
assert not (D/'MERGE-GUIDED.json').exists()
for item in pins:
    rel=PurePosixPath(item['path'])
    assert not rel.is_absolute() and '..' not in rel.parts and rel.parts[0]=='work'
    target=S/item['path'];candidate=C/'source-candidate'/item['path'];backup=D/'source-before'/item['path']
    for path in (target,candidate):
        for parent in (path,*path.parents):
            if parent.exists():assert not parent.is_symlink() and not getattr(parent.lstat(),'st_file_attributes',0)&0x400
    assert sha(candidate)==item['sha256'] and stat.S_ISREG(candidate.stat().st_mode) and candidate.stat().st_nlink==1
    if item['beforeSha256'] is None:assert not target.exists()
    else:assert sha(target)==item['beforeSha256'] and not backup.exists()
for item in pins:
    if item['beforeSha256'] is not None:
        backup=D/'source-before'/item['path'];backup.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(S/item['path'],backup);assert sha(backup)==item['beforeSha256']
created=[]
try:
    for item in pins:
        target=S/item['path'];target.parent.mkdir(parents=True,exist_ok=True)
        if item['beforeSha256'] is None:created.append(target)
        target.write_bytes((C/'source-candidate'/item['path']).read_bytes());assert sha(target)==item['sha256']
    for relative,expected in protected.items():assert sha(S/relative)==expected,relative
except Exception:
    for item in pins:
        if item['beforeSha256'] is not None:shutil.copyfile(D/'source-before'/item['path'],S/item['path'])
    for target in created:
        assert target.resolve().is_relative_to(S.resolve())
        if target.exists():target.unlink()
    raise
report={'status':'ROOT_MERGED_EXACT_GUIDED_OVERLAY','atUtc':datetime.now(timezone.utc).isoformat(),'files':pins,
 'functionalIndependentSha256':sha(I),'libraryContractIndependentSha256':sha(L),
 'f76FourModeSourcesAndStatusCssPreserved':True,'protectedSourcePins':protected,
 'productionCanonicalOrFrozenWritten':False,'authorQaProjectCopied':False}
(D/'MERGE-GUIDED.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':report['status'],'files':len(pins),'productionWritten':False}))
