from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
W=Path(__file__).parent;P=W.parents[2]
F=P/'work/parallel-integration-20261018/final-integration'
S=F/'stage-02/project';C=F/'candidate-unified-v63/project'
files={
 'xhs_commands':'work/speed-collection-worker/component/artifacts/platform-cli-guarded/_internal/xhs_cli/cli.py',
 'dy_commands':'work/ui-runtime-r55/work/runtime/douyin-bridge/lib/commands/index.js',
 'dy_dm':'work/ui-runtime-r55/work/runtime/douyin-bridge/lib/commands/dm.js',
 'dy_script':'work/ui-runtime-r55/work/runtime/douyin-bridge/scripts/douyin.user.js',
 'dy_license':'work/ui-runtime-r55/work/runtime/douyin-bridge/LICENSE',
 'adapter':'work/ui-runtime-r55/src/core/adapters.py',
 'native_reply':'work/ui-native-r57/reply_workbench.py',
 'native_send':'work/ui-native-r57/reply_delivery.py',
 'reviewed_queue':'work/ui-runtime-r55/src/core/review_queue.py',
 'manifest_registration':'work/shared-backend-integration/vendor-src/app.py',
}
out={'checked_at':datetime.now(timezone.utc).isoformat(),'scope':'read-only code inspection; no production DB/platform/identity access','files':{}}
for k,rel in files.items():
    raw=(S/rel).read_bytes()
    out['files'][k]={'path':str(S/rel),'sha256':hashlib.sha256(raw).hexdigest(),
       'same_as_frozen_v63':(C/rel).is_file() and raw==(C/rel).read_bytes()}
(W/'LOCAL-CODE-EVIDENCE.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),'utf-8')
print(json.dumps({'files':len(files),'same_as_frozen_v63':all(x['same_as_frozen_v63'] for x in out['files'].values()),'production_reads':False}))
