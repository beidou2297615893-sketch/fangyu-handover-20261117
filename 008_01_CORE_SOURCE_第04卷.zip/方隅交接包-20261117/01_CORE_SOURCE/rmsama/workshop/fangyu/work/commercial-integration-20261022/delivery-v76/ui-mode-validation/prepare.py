from pathlib import Path
import hashlib, json

W = Path(__file__).resolve().parent
P = W.parents[3]
source = P / 'work/commercial-integration-20261022/v75-final-source-independent-review/serve_ui.py'
raw = source.read_bytes()
text = raw.decode('utf-8')
old = "W=Path(__file__).resolve().parent;P=W.parents[2];S=W/'project';stage=json.loads((W/'STAGE.json').read_text('utf-8-sig'));R=Path(stage['release']);blocked=[];cloudcalls=[]"
new = "W=Path(__file__).resolve().parent;P=W.parents[3];S=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v76/project';stage=json.loads((S.parent/'STAGED.json').read_text('utf-8-sig'));R=Path(stage['release']);blocked=[];cloudcalls=[]"
assert text.count(old) == 1
text = text.replace(old, new)
old = "backend.core.store.put('tasks',task);before=records();dump('UI-ORIGINAL-RECORDS.json',before)"
new = "task.update(pause_reason='account_mode_blocked',last_message='该账号正在执行回复，请先暂停并等待当前操作结束');backend.core.store.put('tasks',task);before=records();dump('UI-ORIGINAL-RECORDS.json',before)"
assert text.count(old) == 1
text = text.replace(old, new)
old = "'sourceOnlyPrivateStage':True"
assert text.count(old) == 1
text = text.replace(old, "'actualF76Stage':True,'controlledPersistedPauseReasonFixture':True")
target = W / 'serve_ui.py'
assert not target.exists()
target.write_text(text, encoding='utf-8')
receipt = {
    'sourceSha256': hashlib.sha256(raw).hexdigest(),
    'derivedSha256': hashlib.sha256(target.read_bytes()).hexdigest(),
    'changes': ['Exact original F76 project/release path', 'Seed persisted local-mode paused task in own database', 'Honest fixture metadata'],
    'auditAndFactoryUnchanged': True,
    'productionWritten': False,
    'platformModelOrSendCalls': 0,
}
(W / 'PREPARATION.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
print(json.dumps(receipt))
