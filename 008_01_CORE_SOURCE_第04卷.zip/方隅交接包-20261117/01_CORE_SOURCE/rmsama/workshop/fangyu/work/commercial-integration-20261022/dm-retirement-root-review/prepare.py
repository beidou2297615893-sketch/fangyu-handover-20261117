from pathlib import Path
import hashlib, json
C=Path(__file__).resolve().parent
A=C.parent/'dm-f79-retirement-candidate'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(A/'FINAL-RECEIPT.json')=='e650ab25e09967fb068acc18465cd8ee53a64cd906b8859f1aa99d85f02c646c'
assert sha(A/'SEALED.json')=='19a6c409d57eeaaa301b281bf8b11657e18ee1f957d81001dcb160e9496ca56c'
assert sha(A/'SOURCE-PINS.json')=='f8cda5b056e23393c300422d339503d79f2f6ceb1ef7fab56822fac238b68848'
manifest=json.loads((A/'SOURCE-PINS.json').read_text('utf-8'))
rows=manifest if isinstance(manifest,list) else manifest['files']
for row in rows:
    expected=row.get('afterSha256') or row.get('sha256') or row['after']['sha256']
    assert sha(A/'final-source'/row['path'])==expected
    assert sha(A/'qa-only-project'/row['path'])==expected
inputs=json.loads((A/'INPUTS.json').read_text('utf-8'))
(C/'INPUTS.json').write_text(json.dumps({'stage':inputs['stage'],'authorFinalSha256':sha(A/'FINAL-RECEIPT.json'),'allSuccessorSourcesVerified':len(rows),'productionAccess':False},indent=2),'utf-8')
original=(A/'test_retirement_factory.py').read_text('utf-8')
anchor="S=W/'qa-only-project'"
assert original.count(anchor)==1
adapted=original.replace(anchor,"S=W.parent/'dm-f79-retirement-candidate/qa-only-project'")
(C/'test_retirement_factory.py').write_text(adapted,'utf-8')
(C/'test_retirement_ui.mjs').write_bytes((A/'test_retirement_ui.mjs').read_bytes())
print(json.dumps({'status':'PREPARED_ORIGINAL_FACTORY_OWN_OUTPUT_ONLY','sourceFiles':len(rows),'originalTestSha256':sha(A/'test_retirement_factory.py'),'adaptation':'Only source project location, source stage metadata and own evidence/output directory'}))
