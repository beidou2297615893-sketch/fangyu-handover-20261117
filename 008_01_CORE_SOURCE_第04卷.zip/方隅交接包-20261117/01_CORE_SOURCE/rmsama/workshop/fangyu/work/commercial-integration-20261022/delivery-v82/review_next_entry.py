"""Independent root review of the mature next-launch-only transaction."""
from pathlib import Path
from datetime import datetime, timezone
import ast, hashlib, json, subprocess, sys

D=Path(__file__).resolve().parent
W=D.parent
P=D.parents[2]
E=W/'f82-next-entry-candidate'
N=P/'work/ui-native-r57'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(E/'FINAL-RECEIPT.json')=='fd7518fe6f5f29637c82d9650d32543a4c1bf5e96fb42154057511f36d8115af'
assert sha(E/'SEALED.json')=='f7c7df3eaff58728dc479ac04119f34fd92bd7c32470d935fc79ed8981e83cea'
entry=E/'install_verified_entry.py'
assert sha(entry)=='cabc185ff1f198bc9a69d396afe6d2eabc85452297466923a1268328d4ef39f0'
old=(W/'f81-next-entry-candidate/install_verified_entry.py').read_bytes()
new=entry.read_bytes()
def functions(raw):
    return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(raw).body if isinstance(n,ast.FunctionDef)}
a,b=functions(old),functions(new)
assert a.keys()==b.keys() and {name for name in a if a[name]!=b[name]}=={'check','main'}
assert a['install']==b['install'] and a['prepare']==b['prepare'] and a['reviewed_spec']==b['reviewed_spec']
tree=ast.parse(new)
constants={n.targets[0].id:ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign)
    and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id in ('ACCEPTED','INSTALLATION_REVIEWED')}
assert constants['INSTALLATION_REVIEWED'] is False
assert set(constants['ACCEPTED'])=={'candidate-unified-v82'}
expected={'run_workbench.py':'8a5f57b6f243b3c0a01099b377d650e3452839a46b608a5ca6c2705d27a2eebd',
    'FROZEN.json':'c4f2d085c491344bd382e12fb3e13d43d91892d849a93dcfde0b4c74cbcffb26',
    'state/production-workspace.json':'14cf53964f5d44d123e989805ea741669ab3f05054e730ddcb299a0aac51a9cb'}
assert all(sha(N/name)==pin for name,pin in expected.items())
process=subprocess.run([sys.executable,'-I','-B',str(entry),'--candidate','candidate-unified-v82','--check'],
    capture_output=True,encoding='utf-8',errors='replace',timeout=180)
assert process.returncode==0,(process.stdout,process.stderr)
result=json.loads(process.stdout)
assert result['status']=='CHECK_ONLY' and result['writes']==0 and not result['restart'] and result['verifiedFiles']==3856
assert all(sha(N/name)==pin for name,pin in expected.items())
receipt={'status':'PASS_F82_NEXT_ENTRY_INDEPENDENT_REVIEW','createdUtc':datetime.now(timezone.utc).isoformat(),
    'approvedForNextLaunchOnly':True,'actualReadOnlyCheckPassed':True,'actualN81CasPinsVerified':True,
    'originalInstallTransactionAndCasBackupRollbackUnchanged':True,'reviewedEntrySha256':sha(entry),
    'reviewedAuthorReceiptSha256':sha(E/'FINAL-RECEIPT.json'),'reviewedAuthorSealSha256':sha(E/'SEALED.json'),
    'rootFinalPinsSha256':sha(D/'FINAL-PINS.json'),'rootAggregateValidationSha256':sha(D/'AGGREGATE-VALIDATION.json'),
    'actualCheck':result,'originalMethodsIdenticalExceptTwoInspectedLocalPreparationFunctions':True,
    'inspectedDifferences':['Exact F82 fixed source and local evidence allowlist','Current N81 compare-and-swap pins',
        'Additional F81 rollback closure','Own prepared validation/evidence paths'],
    'productionDataRead':False,'nativeWritten':False,'windowStoppedOrRestarted':False,
    'platformOrModelCalls':0,'ordinaryPackageOrHumanPlatformAcceptance':False,'fullGoalComplete':False}
target=D/'NEXT-ENTRY-ROOT-REVIEW.json'
assert not target.exists()
target.write_text(json.dumps(receipt,ensure_ascii=False,indent=2),'utf-8')
print(json.dumps({'status':receipt['status'],'rootReviewSha256':sha(target)}))
