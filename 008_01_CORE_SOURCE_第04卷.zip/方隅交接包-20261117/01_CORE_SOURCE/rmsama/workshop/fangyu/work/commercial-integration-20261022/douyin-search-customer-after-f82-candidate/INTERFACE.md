# 独立抖音客户只读搜索后继

精确基线：已封 customer-read-purpose-after-f82-candidate FINAL b0d839d70ea5276566ecc484c565c907715450dba23993b386b1cf4bdd376f52；另外的普通 Core / Adapter / Business 来自固定 F82。只写本目录。

## 本候选源码范围

- 共享 `customer_read_distribution.py`：严格注册 `douyin_owned_keyword_search_page`，固定首屏、offset0、最多20、只读、无发送；index容量由明确用途集合派生；绑定实际原 Core/调用者/CLI/完整脚本材料。不会借账号或评论用途。
- `core/douyin_search_policy.py`：仅新增受信 customer 路径及本用途的新读租约检查；保留原 internal review 完整验证。
- 新 `core/douyin_customer_tasks.py`：仅正常 Business task_run 的当前线程生命周期；原任务、租户、员工、门店、账号、设备与原 batch lease 绑定。每个原逻辑页在原 Store 中记 started/completed，unknown不重派。原页键不随账号/connId变化而重新生成。所有 CLI job 继续用原 task_id，原 task_stop/cancel 命中同一物理进程。
- `core/adapters.py`：搜索、评论各一处 typed scope 分派；原 typed `owned_search` / `owned_comments` 自身持有原账号 OS 锁、Bridge 通道锁及 UID 前后核对。原通用命令没有获新权限。
- `core/engine.py`：只在 `_handle` 原 XHS 全局 gate 加当前 typed Douyin task 例外；原 `_run_inner`、导入、过滤、稳定来源去重、分类、分析及 pipeline 函数不变。
- 实际 active vendor `assistant/business.py`：纯 task_save 拆出全局平台hold；读取仍需独立用途与新读租约；普通 task_run 的 scope 生命周期；首读走原 typed 搜索而不设置全局 search_verified。canonical business 历史实现不变。

## 共享租约接点

依赖另一个已固定合同：customer-read-cloud-lease-candidate/CUSTOMER-READ-LEASE-SPEC.json，SHA 18071d2e8609dbd15369488239157689ebf8a15251465974522c83b703503055。真正版本 1.2.0-read.1，不冒充旧pilot或管理员源码。

只调用 `assistant.customer_read_lease.current(server, purpose) -> bool`。目的严格为原搜索或原视频评论；无 helper、无实际认证 heartbeat、目的缺失、过期、撤销或错误绑定都拒绝。新 helper/原 Runner/Service/Runtime 接点归 knowledge_review_4；本目录不改这些活动源，也不注入 dict 或 fake lease。

## 验证分层

source-probe7 的固定旧载荷只验证内层原 factory/业务/Core/CLI/完整脚本/自有 VM 与 Store。其 source-admin 外层 `_executor` 被原 pilot lease 拒绝这一事实保留；这不是商业可用或真人平台通过。当前源已接新读租约，等待精确共享依赖和真正客户描述后再固定输入验证。不得拿旧载荷结果为后继 lease 分支背书。

最新固定 source-joint1/probe_entry-joint2.py 已 PASS12：实际原 createService 本机对端完成 login/pair/enroll/poll；原 Service/Runner/DeviceSession 创建新只读租约，原账号 status 经 CLI/完整脚本 VM 核 UID，原 outer start_acquisition/worker、Core 导入/去重、unknown 原键不重派和真实云合同 hold/撤销均通过。23 个实际 Node 子进程，零真人平台/模型请求，全部自有服务已关。

该运行依赖 shared-read-lease-qa-v1 固定七源；另一作者 v2/v3 的 Runtime 原按钮/snapshot/AI 补线并未混入该载荷，不冒称已由本轮验证。最终合版、真正主 EXE、部署云及本人平台验收仍由根组合继续。纯本机规划另有 source-planning1 PASS7。源码差量严格只有六个 Python 文件，材料例子放在 material-examples，最终须按真实组合字节重算。

task_save 本身只保存本机计划，新增验证要求零 CLI/零平台网络，状态、自动执行等注入字段继续拒绝。发送、私信、直播、连续原许可、自然登录及 public_send_hold 均未扩大。
