from pathlib import Path
import ast,hashlib,json,re
W=Path(__file__).resolve().parent;P=W.parents[2];S=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v79/project';O=W/'source-candidate'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def base(rel):return (S/rel).read_bytes().decode('utf-8')
def write(rel,text):
 p=O/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(text.encode('utf-8'))
def replace(text,old,new):
 assert text.count(old)==1,(old[:100],text.count(old));return text.replace(old,new)
native='work/ui-native-r57/';legacy='work/ui-runtime-r55/src/';runtime='work/ui-runtime-r55/work/runtime/douyin-bridge/'
# New transport is a separate fixed entry; all existing identity/comment DM
# source/material pins remain unchanged and no private grant is enabled.
browser=O/runtime/'lib/dm_workbench_browser.js';cli=O/runtime/'dm_workbench_cli.js'
text=cli.read_text('utf-8');text=re.sub("const BROWSER_SHA='[^']+';",f"const BROWSER_SHA='{sha(browser)}';",text);cli.write_bytes(text.encode())
transport=O/legacy/'core/dm_transport.py';text=transport.read_text('utf-8');pins={n:sha(O/runtime/n if (O/runtime/n).exists() else S/runtime/n) for n in ['dm_workbench_cli.js','lib/dm_workbench_browser.js','lib/client/bridge-client.js']};text=re.sub(r'^PINS=.*$',f'PINS={pins!r}',text,flags=re.M);transport.write_bytes(text.encode())
rel=legacy+'core/adapters.py';text=base(rel);eol='\r\n' if '\r\n' in text else '\n'
text=replace(text,'        self.platform_guard=None','        self.platform_guard=None'+eol+'        self._dm_calls=threading.local()')
text=replace(text,'        if callable(self.platform_guard):self.platform_guard(platform)','        if callable(self.platform_guard):self.platform_guard(platform)'+eol+"        guard=getattr(self._dm_calls,'guard',None)"+eol+'        if guard is not None:guard()')
anchor='    def send(self,platform,lead,text,account_dir):'
text=replace(text,anchor,'    def direct_messages(self,account,operation,request_id,directory,**kwargs):'+eol+'        from .dm_transport import direct_messages'+eol+'        return direct_messages(self,account,operation,request_id,directory,**kwargs)'+eol+eol+anchor);write(rel,text)
rel=legacy+'core/engine.py';text=base(rel);eol='\r\n' if '\r\n' in text else '\n'
anchor="        if used>=limit: raise CoreError('当前员工今日回复限额已用完（%s 条）'%limit)"
line="        used+=sum(1 for r in self.store.list('ui_dm_drafts_v1',tenant) if r.get('attempted_by')==user['id'] and r.get('state') in ('sending','sent','unknown') and r.get('attempted_at','').startswith(today))"
text=replace(text,anchor,line+eol+anchor)
anchor="        if sent>=int(account.get('daily_send_limit') or 20): raise CoreError('该账号今日发送额度已用完')"
line="        sent+=sum(1 for r in self.store.list('ui_dm_drafts_v1',tenant) if r.get('account_id')==account['id'] and r.get('state') in ('sending','sent','unknown') and r.get('attempted_at','').startswith(today))"
text=replace(text,anchor,line+eol+anchor);write(rel,text)
rel='work/shared-backend-integration/platform_runtime.py';text=base(rel);eol='\r\n' if '\r\n' in text else '\n'
anchor='    def reply_guard(self,user,account_id):'
addition='''    def dm_guard(self,user,account_id,*,for_send=False):
        # Reuse the original device/session/license/QA/account gates. This does
        # not create a grant, bypass a held profile, or add a new account mode.
        user=self._principal(user);executor=self._executor(user)
        account=self._account(user,account_id)
        if account.get('platform')!='douyin':
            raise PlatformRuntimeError('DM_PLATFORM_UNAVAILABLE','此平台私信传输尚未接通',422)
        if account.get('status')!='ready':
            raise PlatformRuntimeError('DM_ACCOUNT_NOT_READY','请先在账号页核对本人登录状态',409)
        code,message=self._readiness(user,account)
        if code:raise PlatformRuntimeError(code.upper(),message)
        self.server._platform_execution_guard(account['platform'])
        executor._guard_platform_qa_command('reply_queue_send' if for_send else 'task_run',{} if for_send else {'max_batches':1})
        if for_send:self.core._public_reply_guard(account['platform'])
        if not account.get('conn_id') or not re.fullmatch('[1-9][0-9]{0,24}',str(account.get('platform_uid') or '')):
            raise PlatformRuntimeError('DM_IDENTITY_REQUIRED','请先核对本人抖音稳定身份与固定窗口',409)
        return executor

'''.replace('\n',eol)
text=replace(text,anchor,addition+anchor);write(rel,text)
rel=native+'workbench_backend.py';text=base(rel);eol='\r\n' if '\r\n' in text else '\n'
text=replace(text,"REPLY_ACTIONS = frozenset(","DM_ACTIONS = frozenset(('dm_workspace_read','dm_listen_start','dm_listen_stop','dm_request_read','dm_draft_save','dm_draft_review','dm_queue_prepare','dm_queue_start','dm_queue_cancel','dm_queue_read'))"+eol+"REPLY_ACTIONS = frozenset(")
text=replace(text,'                 materials_factory=None, rental_factory=None, reply_factory=None, delivery_factory=None, remote_factory=None,','                 materials_factory=None, rental_factory=None, reply_factory=None, delivery_factory=None, remote_factory=None, dm_factory=None,')
anchor='        self.workflow = workflow_factory(self.core, _deny_cloud, company=deepcopy(company))'
text=replace(text,anchor,'        self.dm_workbench = (dm_factory(self.core,self.platform_runtime,self.reply_workbench,self.reply_delivery) if dm_factory else None)'+eol+anchor)
text=replace(text,'            self.closed = True','            self.closed = True'+eol+'            if self.dm_workbench is not None:self.dm_workbench.close()')
anchor='        if action in INTERACTION_ACTIONS:'
addition='''        if action in DM_ACTIONS:
            try:
                with self.lock:
                    user,profile=self._identity(token)
                    store_id=self._selected_store(user,profile)
                    if not isinstance(data,dict) or data.get('storeId')!=store_id:
                        raise WorkbenchError('STORE_FORBIDDEN','当前门店已变化，请重新读取',403)
                    if self.dm_workbench is None:raise WorkbenchError('DM_UNAVAILABLE','私信组件尚未装入本版本',503)
                    return {'dmWorkspace':self.dm_workbench.execute(action,user,store_id,data,lambda:self._delivery_identity(token))}
            except WorkbenchError:raise
            except Exception as error:
                code,status=getattr(error,'code',None),getattr(error,'status',400)
                if isinstance(code,str) and type(status) is int and status in (400,401,403,404,409,422,503):raise WorkbenchError(code,str(error),status) from None
                raise WorkbenchError('DM_UNAVAILABLE','私信操作暂不可用；请核对原请求结果，草稿保持',503) from None
'''.replace('\n',eol)
text=replace(text,anchor,addition+anchor);write(rel,text)
rel=native+'ui_native_host.py';text=base(rel);eol='\r\n' if '\r\n' in text else '\n'
text=replace(text,"'rental_assessment.py','reply_workbench.py','reply_delivery.py'))):","'rental_assessment.py','reply_workbench.py','reply_delivery.py','dm_workbench.py'))):")
text=replace(text,"'reply_delivery.py',"+eol+"                  'workspace_binding.py'","'reply_delivery.py','dm_workbench.py',"+eol+"                  'workspace_binding.py'")
# API_ACTIONS is a literal set extension, preserving original host/body guards.
anchor="API_ACTIONS = "
tree=ast.parse(text);node=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='API_ACTIONS' for t in n.targets))
lines=text.splitlines(keepends=True);old=''.join(lines[node.lineno-1:node.end_lineno]);new=old.rstrip()+" | frozenset(('dm_workspace_read','dm_listen_start','dm_listen_stop','dm_request_read','dm_draft_save','dm_draft_review','dm_queue_prepare','dm_queue_start','dm_queue_cancel','dm_queue_read'))"+eol;text=text.replace(old,new,1)
anchor="    platform_entry = files.get('resources/platform-runtime/platform_runtime.py')"
addition='''    dm_entry=files.get('dm_workbench.py')
    if dm_entry is not None:
        dm_module=importlib.util.module_from_spec(importlib.util.spec_from_loader('fangyu_scoped_dm',loader=None))
        dm_module.__file__=str(root/dm_entry['path'])
        dm_raw=read_public(root/dm_entry['path'],dm_entry['sha256'],dm_entry['size'])
        exec(compile(dm_raw,dm_module.__file__,'exec'),dm_module.__dict__)
        extra['dm_factory']=dm_module.DMWorkbench
'''.replace('\n',eol)
text=replace(text,anchor,addition+anchor);write(rel,text)
rel=native+'freeze_ui.py';text=base(rel);eol='\r\n' if '\r\n' in text else '\n'
anchor="    copy_public(HERE / 'reply_delivery.py', release / 'reply_delivery.py')"
text=replace(text,anchor,anchor+eol+"    copy_public(HERE / 'dm_workbench.py', release / 'dm_workbench.py')");write(rel,text)
print('Patched only owned sources; existing comments/identity/runtime material files unchanged')
