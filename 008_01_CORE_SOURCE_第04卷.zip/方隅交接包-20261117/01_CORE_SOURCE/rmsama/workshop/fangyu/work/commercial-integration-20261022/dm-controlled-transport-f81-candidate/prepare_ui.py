from pathlib import Path
W=Path(__file__).resolve().parent;OLD=W.parent/'dm-f79-candidate'
t=(W/'test_factory_dm.py').read_text('utf-8');prefix=t[:t.index(' assert read(account)')]
prefix=prefix.replace(" and not path.is_relative_to(OUT):raise RuntimeError('Own evidence/data only')"," and not path.is_relative_to(OUT) and path!=W/'UI-SERVER.json':raise RuntimeError('Own evidence/data only')")
assert "path!=W/'UI-SERVER.json'" in prefix
old=(OLD/'serve_dm_ui.py').read_text('utf-8');body=old[old.index(' # Explicit own synthetic positive permission'):old.index('\nfinally:')]
cleanup=t[t.index('\nfinally:'):]
(W/'serve_dm_ui.py').write_text(prefix+body+cleanup,'utf-8')
(W/'test_dm_ui.mjs').write_bytes((OLD/'test_dm_ui.mjs').read_bytes())
print('Original full index/fit DM UI assertions retained, actual typed Bridge/userscript fixture')
