from pathlib import Path
import hashlib,json
W=Path(__file__).resolve().parent;R=W/'complete-readonly-context'
assert not R.exists();R.mkdir()
text=(W/'bound-readonly-snapshot/serve_ui.py').read_text('utf-8')
anchor="runtime.service.vault=SimpleNamespace(read=lambda:deepcopy(saved));runtime.service.device=deepcopy(saved['device']);runtime.service.state='online'"
addition="""
 from assistant.business import BusinessExecutor
 from assistant.xhs_app_context import bind_executor_session
 executor=BusinessExecutor(runtime.server,company['managedWorkspace']['environment_id'],company['id'],user['username']);runtime.service.executor=executor
 class DeviceCloud:
  def call(self,operation,data,credential):
   assert operation=='device_account_claim' and credential==saved['token'];return {'claimed':True}
  def close(self):pass
 runtime.service._cloud=lambda:DeviceCloud();executor.account_claim=runtime.service._claim_xhs_account;bind_executor_session(runtime.service,executor,saved)
"""
assert text.count(anchor)==1;text=text.replace(anchor,anchor+addition)
anchor="task.update(pause_reason='account_mode_blocked',last_message='该账号正在执行回复，请先暂停并等待当前操作结束');backend.core.store.put('tasks',task);before=records();dump('UI-ORIGINAL-RECORDS.json',before)"
addition="""
 readiness=runtime._collection_readiness(user,backend.core.store.get('accounts','diverse-fixture-account-0'))
 dump('READINESS.json',{'code':readiness[0],'message':readiness[1],'syntheticTemporaryQaContext':True,'noNaturalCloudGrant':True})
 assert not readiness[0],readiness
"""
assert text.count(anchor)==1;text=text.replace(anchor,anchor+addition)
(R/'serve_ui.py').write_text(text,encoding='utf-8')
(R/'test_mode_ui.cjs').write_bytes((W/'bound-readonly-snapshot/test_mode_ui.cjs').read_bytes())
(R/'PREPARATION.json').write_text(json.dumps({'reason':'Original collection readiness also requires a bound original BusinessExecutor. Complete own synthetic QA context using original bind_executor_session, preserve all product guards.','syntheticCloudAndDeviceContext':True,'naturalCloudGrant':False,'productChanged':False,'oldRedRetained':True,'serverSha256':hashlib.sha256((R/'serve_ui.py').read_bytes()).hexdigest()},indent=2),encoding='utf-8')
print(str(R))
