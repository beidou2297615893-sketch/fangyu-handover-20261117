const readline=require('node:readline'),path=require('node:path');
const {fixture,IDS}=require('./cloud-fixture.cjs');
const {ProviderError}=require("C:\\\u79ef\u6728\u8f6f\u4ef6\u5de5\u574a\\\u9879\u76ee\\\u65b9\u9685\u516c\u5bd3\u5ba2\u6237\u7248\\work\\commercial-integration-20261022\\content-cloud-v3-final\\candidate\\ai_provider.cjs");
const deny=()=>{throw new Error('TEST_NETWORK_FORBIDDEN')};globalThis.fetch=deny;
for(const name of ['node:http','node:https']){const n=require(name);n.request=deny;n.get=deny;}
const net=require('node:net');net.connect=deny;net.createConnection=deny;
let current,output,mode='success',release,entered=false,statusBlock=false,statusEntered=false,statusRelease;
async function provider(req){
 entered=true;
 if(mode==='block')await new Promise(resolve=>{release=resolve});
 if(mode==='timeout')throw new ProviderError('AI_PROVIDER_TIMEOUT');
 return {model:req.model,...(req.provider==='openai'?{service_tier:'default'}:{}),
  usage:req.provider==='openai'?{prompt_tokens:100,completion_tokens:50,total_tokens:150,prompt_tokens_details:{cached_tokens:0},completion_tokens_details:{reasoning_tokens:0}}:
  {prompt_tokens:100,prompt_cache_hit_tokens:20,prompt_cache_miss_tokens:80,completion_tokens:50},
  choices:[{finish_reason:'stop',message:{content:JSON.stringify(output)}}]};
}
async function handle(m){
 if(m.command==='init'){output=m.output;current=await fixture({provider,now:()=>Date.now()});return {ids:IDS};}
 if(m.command==='call'){
  if(!['login','me','logout','refresh','store_config_read','ai_profile','content_generate','content_generate_status'].includes(m.payload.operation))throw new Error('TEST_OPERATION_DENIED');
  if(m.payload.operation==='content_generate_status'&&statusBlock){statusEntered=true;await new Promise(resolve=>{statusRelease=resolve});}
  return current.call(m.payload.operation,m.payload,m.token||'');
 }
 if(m.command==='configure'){if(m.output)output=m.output;if(m.mode)mode=m.mode;if(m.statusBlock!==undefined)statusBlock=m.statusBlock;entered=false;return {ok:true};}
 if(m.command==='release'){release?.();return {ok:true};}
 if(m.command==='releaseStatus'){statusRelease?.();return {ok:true};}
 if(m.command==='policy'){current.contentOptions.enabled=m.enabled;current.restart();return {ok:true};}
 if(m.command==='revoke'){await current.changeTrustedState(s=>{s.users.find(u=>u.username===IDS.actor).disabled=true});return {ok:true};}
 if(m.command==='revokeStore'){await current.changeCentralCatalogue(row=>{row.stores=row.stores.filter(s=>s.id!==IDS.store)});return {ok:true};}
 if(m.command==='stats')return {providerCalls:current.calls(),providerTransactions:current.providerTransactions,entered,statusEntered};
 throw new Error('TEST_COMMAND_DENIED');
}
readline.createInterface({input:process.stdin,crlfDelay:Infinity}).on('line',async line=>{
 let m;try{m=JSON.parse(line);const result=await handle(m);process.stdout.write(JSON.stringify({id:m.id,ok:true,result})+'\n');}
 catch(e){process.stdout.write(JSON.stringify({id:m?.id,ok:false,error:e.message})+'\n');}
});
