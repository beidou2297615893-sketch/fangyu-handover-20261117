"""Fresh own joint payload; exact fixed sibling dependency, original cloud service."""
from pathlib import Path
import ast,hashlib,json,sys
T=Path(__file__).resolve().parent
D=T.parent/'xhs-customer-runtime-after-f82-candidate/shared-read-lease-qa-v3'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(D/'INTERFACE.json')=='76176e4ffd98335893fa53f37dbfac2ae9c6a1b86996680c414a13871ba2552e'
dependency=json.loads((D/'INTERFACE.json').read_bytes())
for row in dependency['files']:
    path=D/'source'/row['path']
    assert path.stat().st_size==row['bytes'] and sha(path)==row['sha256']
name=sys.argv[1] if len(sys.argv)>1 else 'source-joint1'
assert name.startswith('source-joint') and '/' not in name and '\\' not in name
B=T/name
t=(T/'prepare_probe.py').read_text('utf-8')
t=t.replace("for overlay in (PRE_SOURCE,SOURCE):",f"for overlay in (PRE_SOURCE,Path({str(D/'source')!r}),SOURCE):")
needle='# SOURCE mirrors continue to describe actual bytes; this adds no permissions.'
insert="""for path in (PROJECT/'work/shared-backend-integration/vendor-src').rglob('*.py'):
    target=R/'resources/platform-runtime/vendor-src'/path.relative_to(PROJECT/'work/shared-backend-integration/vendor-src')
    target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,target)
"""
assert t.count(needle)==1;t=t.replace(needle,insert+needle)
needle='# Mature held loader compatibility re-derived with the SAME false decisions.'
insert="""customer_config=read(PROJECT/'work/app/company.json')
customer_config['releaseVersion']='1.2.0-read.1'
save(PROJECT/'work/app/company.json',customer_config)
save(B/'payload/company.json',customer_config)
"""
assert t.count(needle)==1;t=t.replace(needle,insert+needle)
needle="contract=read(PROJECT/'HELD-STANDARD-MANIFEST.json')"
assert t.count(needle)==1;t=t.replace(needle,needle+"\ncontract['companyConfigDigest']=hashlib.sha256(json.dumps(customer_config,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()")
t=t.replace("'core/runtime_license_policy.py','core/adapters.py'","'core/runtime_license_policy.py','assistant/customer_read_lease.py','core/adapters.py'")
needle="    for path in ('core/douyin_comments_policy.py','core/runtime_license_policy.py'): add('source',path,'source')"
assert t.count(needle)==1;t=t.replace(needle,needle+"\n    add('source','assistant/customer_read_lease.py','source')")
ast.parse(t)
sys.argv=[str(T/'prepare_probe.py'),name]
exec(compile(t,str(T/'prepare_probe.py'),'exec'),{'__file__':str(T/'prepare_probe.py'),'__name__':'__main__'})
(B/'SHARED-DEPENDENCY.json').write_text(json.dumps({'status':'exact fixed QA dependency, not final acceptance',
    'interface':str(D/'INTERFACE.json'),'interfaceSha256':sha(D/'INTERFACE.json'),'files':dependency['files'],
    'companyChange':'releaseVersion=1.2.0-read.1 only; original source marker, holds, no portable or employee grant'},ensure_ascii=False,indent=2),'utf-8')
bridge=(T.parent/'xhs-customer-runtime-after-f82-candidate/serve_original_cloud.cjs').read_text('utf-8')
bridge=bridge.replace("ROOT=path.join(D,'../customer-read-cloud-lease-candidate/cloud-candidate-final')",
    'ROOT='+json.dumps(str(T.parent/'customer-read-cloud-lease-candidate/cloud-candidate-final').replace('\\','/')))
bridge=bridge.replace("factory-probe-7/payload/project/work/app/company.json","payload/project/work/app/company.json")
(B/'serve_original_cloud.cjs').write_text(bridge,'utf-8')
print('Fixed joint dependency and original cloud fixture prepared')
