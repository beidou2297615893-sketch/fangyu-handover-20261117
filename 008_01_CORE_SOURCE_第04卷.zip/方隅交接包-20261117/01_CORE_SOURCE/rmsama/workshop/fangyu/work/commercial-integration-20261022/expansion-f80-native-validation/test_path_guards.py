"""Actual pinned QA-only Native factory/Core/Store/HTTP and real Windows APIs."""
from pathlib import Path
from copy import deepcopy
import base64,hashlib,http.client,importlib.util,io,json,os,sys,threading,time,traceback,uuid,wave
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=W.parents[2];S=Path('C:\\积木软件工坊\\项目\\方隅公寓客户版\\work\\parallel-integration-20261018\\final-integration\\candidate-unified-v80\\project');stage=json.loads((W/'QA-STAGE.json').read_text('utf-8'));R=Path(stage['release']);case=sys.argv[1];assert case in ('root','temp','asset','normal');OUT=W/('path-fixed-'+case);OUT.mkdir(exist_ok=True);events=[];checks=[];blocked=[];processes=[]
def save(n,v):(OUT/n).write_text(json.dumps(v,ensure_ascii=False,indent=2),'utf-8')
def audit(event,args):
 if event=='subprocess.Popen':
  executable=Path(args[0]).resolve();assert executable==Path('C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe').resolve();assert '-File' in str(args[1]) and 'windows_media_bridge.ps1' in str(args[1]) and '-Command' not in str(args[1]) and '-EncodedCommand' not in str(args[1]);assert Path(args[2]).resolve().is_relative_to(OUT);processes.append({'executable':str(executable),'argv':str(args[1]),'cwd':str(args[2])})
 if event in ('os.system','os.startfile','os.posix_spawn'):blocked.append(event);raise RuntimeError('Forbidden process')
 if event in ('socket.connect','socket.bind') and (not isinstance(args[1],tuple) or args[1][0] not in ('127.0.0.1','::1')):blocked.append(event);raise RuntimeError('Loopback only')
 if event=='socket.getaddrinfo' and args[0] not in ('127.0.0.1','::1','localhost',None):blocked.append(event);raise RuntimeError('No external DNS')
 if event=='sqlite3.connect' and not Path(args[0]).resolve().is_relative_to(OUT):blocked.append(event);raise RuntimeError('Own DB only')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  if os.fsdecode(args[0]).lower()==os.devnull.lower():return
  path=Path(os.fsdecode(args[0])).absolute();mode,flags=args[1] or '',args[2] or 0
  if (any(c in str(mode) for c in 'wax+') or isinstance(flags,int) and flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC)) and not path.is_relative_to(W):blocked.append(event);raise RuntimeError('Own writes only')
sys.addaudithook(audit)
def load(name,path):
 m=importlib.util.module_from_spec(importlib.util.spec_from_loader(name,loader=None));m.__file__=str(path);sys.modules[name]=m;exec(compile(path.read_bytes(),str(path),'exec'),m.__dict__);return m
fixture=load('media_services_original_identity',P/'work/acquisition-core-repair-20261018/gui-fixture/base_fixture.py');cloud=fixture.CloudStandin(json.loads((P/'work/central-store-config/compiled-fixture.json').read_text('utf-8-sig')));company=json.loads((S/'work/app/company.json').read_text('utf-8-sig'))
def transport(*a,**k):v=cloud(*a,**k);v['environment_id']=company['managedWorkspace']['environment_id'];return v
integration=load('integrations',R/'resources/platform-runtime/vendor-src/integrations.py');integration.request_json=transport
host=load('media_services_actual_qa_host',R/'ui_native_host.py');_,files=host.verify_release(R,stage['manifest_sha256']);host.verify_backend_dependencies(R,files,S)
headers={};backend=None;server=None;worker=None;passed=False;serial=0
def start():
 global backend,server,worker,origin
 backend=host.create_backend(R,files,project_root=S,data_dir=OUT/'data',company=company)
 server=host.StaticServer(R,files,backend=backend,cookie_name='media_services_qa');worker=threading.Thread(target=server.serve_forever,daemon=True);worker.start();origin='http://127.0.0.1:'+str(server.server_port)
def stop():
 global server
 if server:server.shutdown();worker.join(3);server.server_close();backend.close();server=None
def request(method,path,data=None,expected=200):
 c=http.client.HTTPConnection('127.0.0.1',server.server_port,timeout=60);c.request(method,path,json.dumps(data,ensure_ascii=False).encode() if data is not None else None,headers);r=c.getresponse();raw=r.read();h=dict(r.getheaders());status=r.status;c.close();body=json.loads(raw);value=deepcopy(data)
 if value and value.get('action')=='login':value['data']['password']='synthetic omitted'
 if value:
  for key in ('dataBase64',):
   if key in value.get('data',{}):value['data'][key]='omitted synthetic bytes'
 recorded=deepcopy(body)
 if 'dataBase64' in recorded.get('result',{}):recorded['result']['dataBase64']='omitted synthetic bytes'
 if 'dataBase64' in recorded.get('result',{}).get('speechPreview',{}):recorded['result']['speechPreview']['dataBase64']='omitted synthetic bytes'
 events.append({'method':method,'path':path,'request':value,'status':status,'body':recorded});save('HTTP.json',events);assert status==expected,(status,expected,recorded);return body,h
def action(name,data,expected=200):return request('POST','/api/workbench',{'action':name,'data':data},expected)[0]
def login():
 headers.clear();boot,_=request('GET','/api/workbench/bootstrap');headers.update({'Origin':origin,'Content-Type':'application/json','X-Fangyu-CSRF':boot['csrfToken']});logged,h=action_headers= request('POST','/api/workbench',{'action':'login','data':{'username':'fixture-admin','password':fixture.PASSWORD}});headers['Cookie']=h['Set-Cookie'].split(';',1)[0];headers['X-Fangyu-CSRF']=logged['csrfToken']
 if logged['selection']['storeId']!=cloud.first_store:action('select_store',{'storeId':cloud.first_store,'expectedRevision':logged['selection']['revision']})
 return backend.core.session(headers['Cookie'].split('=',1)[1])
def workspace():return action('content_workspace_read',base)['workspace']
def records():
 with backend.core.store.connect() as db:return [dict(r) for r in db.execute('SELECT entity,id,tenant_id,body FROM records ORDER BY entity,id')]
def wait_speech(request_id):
 for _ in range(200):
  result=action('media_speech_read',{**base,'requestId':request_id})['result']
  if result['speechJob']['state']!='running':return result
  time.sleep(.1)
 raise AssertionError('Owned speech job timeout')
def snapshot(path):
 return {str(p.relative_to(path)):hashlib.sha256(p.read_bytes()).hexdigest() for p in path.rglob('*') if p.is_file()}
outside=OUT/'other-workspace';before_outside=snapshot(outside);outside_writes=[]
def observe(event,args):
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  p=Path(os.fsdecode(args[0])).absolute();mode,flags=args[1] or '',args[2] or 0
  if (any(c in str(mode) for c in 'wax+') or isinstance(flags,int) and flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC)) and p.resolve().is_relative_to(outside):outside_writes.append({'requested':str(p),'resolved':str(p.resolve())})
sys.addaudithook(observe)
try:
 start();user=login();account={'id':'owned-path-account','tenant_id':user['tenant_id'],'cloud_owner':user['username'],'store_id':cloud.first_store,'platform':'xiaohongshu','status':'disconnected','name':'自有路径控制账号'};backend.core.store.put('accounts',account)
 base={'storeId':cloud.first_store,'accountId':account['id'],'platform':'xiaohongshu'};workspace();before=records()
 from PIL import Image,ImageDraw
 image=Image.new('RGB',(700,200),'white');ImageDraw.Draw(image).text((30,30),'OWNED OCR BOUNDARY SAMPLE',fill='black',font_size=36);buffer=io.BytesIO();image.save(buffer,format='PNG')
 body=action('media_ocr_preview',{**base,'filename':'owned.png','dataBase64':base64.b64encode(buffer.getvalue()).decode()},200 if case=='normal' else 409)
 if case=='normal':
  result=body['result']['filePreview'];assert result['previewOnly'] is True and 'OWNED' in result['text'].upper(),result
  assert len(processes)==1
  nested=OUT/'data/nested-media-parent/link/not-created/deeper'
  try:backend.media_workbench.checked_directory(nested,create=True)
  except Exception as error:assert getattr(error,'code',None)=='MEDIA_PATH_DENIED'
  else:raise AssertionError('Original Native bound shared directory guard accepted nested reparse ancestor')
  assert not (outside/'not-created').exists()
 else:
  assert body['error']['code']=='MEDIA_PATH_DENIED',body
  assert not processes
 assert records()==before and snapshot(outside)==before_outside and not outside_writes
 save('RESULTS.json',{'status':'PASS','case':case,'originalFactoryHttp':True,'realWindowsOcr':case=='normal','beforeOutside':before_outside,'afterOutside':snapshot(outside),'outsideWrites':outside_writes,'processes':processes,'recordsUnchanged':True,'productionAccess':False})
 passed=True
finally:
 stop();save('FINAL.json',{'status':'PASS' if passed else 'FAIL','ownServicesClosed':server is None,'blocked':blocked,'outsideWrites':outside_writes,'productionAccess':False})
