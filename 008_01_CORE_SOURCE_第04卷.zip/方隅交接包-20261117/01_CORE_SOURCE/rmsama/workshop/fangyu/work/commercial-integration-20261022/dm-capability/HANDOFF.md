# 评论客户转私信：本次结论与接入条件

核查时间：2026年10月22日。写入仅本目录，生产源码/数据库/账号会话/正式入口未改；没有平台读取、登录、评论、私信或发布，没有新增费用。

## 可直接向用户说明

**目前这批小红书评论客户不能在现工作台一键批量私信。** 当前封装的小红书CLI没有私信命令，评论/@通知不是私信；不是改一下发送按钮就能实现。

**抖音已有底层单条私信代码，但现工作台回复页没有接这条路径，批量私信也明确未开放。** 需要本人账号和接收人核验、真实回执验证后才可标为可用；不能凭命令文件存在就承诺可发。

上述为当前软件事实，不等于“小红书平台绝对不支持私信”。专业号私信通及新的网页IM候选是其他接入路线，需要分别核查账号权限和实现。

## 当前实际源码证据

以S=P/work/parallel-integration-20261018/final-integration/stage-02/project为根；LOCAL-CODE-EVIDENCE.json记录精确路径、SHA及与冻结v63逐文件一致结果。

| 层级 | 已核对事实 | 含义 |
|---|---|---|
| 小红书CLI注册表 | `.../platform-cli-guarded/_internal/xhs_cli/cli.py`：注册comment/reply、notifications/unread等，没有DM | notifications的mentions/likes/connections分别是评论/@、赞藏、新关注，不能当私信收件箱 |
| 抖音CLI注册表 | `work/ui-runtime-r55/work/runtime/douyin-bridge/lib/commands/index.js`实际注册dm，即使cli.js帮助未列出 | 早先仅看帮助会误判；本次已据实现纠正 |
| 抖音DM命令 | `lib/commands/dm.js`通过当前连接创建会话，再发DM；只有status_code=0、send_message_body.status=0、正整数server_message_id且check_code不拒绝才报sent | 本地版本比当前上游库原件更严格；未知或失败禁止自动重试 |
| 当前产品Adapter | `core/adapters.py::send`已有`_message_channel=dm`分支，要求douyin、明确conn_id及正整数author_id；必须返回message_id | 接收人是抖音数值UID，不是昵称、sec_uid或OpenAPI open_id |
| 当前工作台草稿 | `work/ui-native-r57/reply_workbench.py`的reply_save硬编码`channel:'comment'` | r57产品页面当前保存出来的是评论草稿 |
| 发送队列 | `core/review_queue.py::_validate`只接受channel=comment；旧队列也明确拒绝dm | 批量私信没有完整产品合同，不应绕过队列守卫 |
| 跨账号防重 | `reply_delivery.py`包裹Core._send_reply并按同平台作者ID加原子客户声明；结果不明保留锁 | 如扩私信，需保留同一防重路径并补DM特有的接收人/回执测试，不能另开裸CLI发送 |

## 两个需要修正的“已验证”口径

1. `vendor-src/app.py`目前给抖音设置`dm_contract_verified=(dm.js存在)`。这只能说明安装了文件，**不是本人账号可以送达私信的证据**。不要直接把该布尔值暴露成“已验证可批量私信”。
2. 当前抖音网页脚本`_getMyUid`仍有short_id、UIFID和localStorage等fallback；这些字段不能未经身份绑定就当数值UID。扩DM前要改为当前已核实账号UID与当前IM参与者严格一致，缺失时停在待核验，不靠猜值继续。

## 本轮实际测试

`test_existing_dm_receipt.cjs`直接调用当前产品dm.js，注入虚构Bridge返回，7项通过：明确服务端消息ID成功、空响应、缺消息ID、平台拒绝、消息状态拒绝、check_code拒绝、零ID。每项最多模拟一次创建会话和一次发送，不自动重试。回执见DM-RECEIPT-TESTS.json。

**0网络调用、0真实平台请求、0真实发送；没有证明消息送达，也未验证陌生人权限、账号会话和多账号并发。**

## GitHub新候选与许可证

- [jackwener/xiaohongshu-cli注册表](https://github.com/jackwener/xiaohongshu-cli/blob/main/xhs_cli/cli.py)：本次线上与本地命令注册表均未见DM；匿名仓库元数据license=null，本地旧核查只有配置Apache声明，新增分发仍需补齐对应许可材料，不据缺字段推断禁止或允许。
- [Yht20927/douyin-cli固定版本MIT许可](https://github.com/Yht20927/douyin-cli/blob/4073159bea585de6d33a4747a475669440737932/LICENSE)：已核根MIT文本，当前产品也保留LICENSE。代码许可与平台账号/接口/营销权限是不同事项。
- [OpenCLI私信PR #2536](https://github.com/jackwener/OpenCLI/pull/2536)：截至本次直接GitHub API核对仍open；main固定fe5f1d96aff01c32fd84f86b52af922bfe6ca93f的完整树无dm文件，只有notifications。维护者在10月12日说明当前PR可能把历史同文消息当发送成功，且发送前没有绑定目标会话，要求修正接收人和新出站消息完整回执后才接收。因此**不选择原样接入商业发送**。作者自述live成功不能覆盖维护者已复现的缺陷。
- 搜索索引曾把上述DM标题误关联PR2554；匿名API查明2554是arxiv改动，本报告已拒用该搜索关联。纠正证据见PUBLIC-SOURCES.json与OPENCLI-DM-SOURCE-CHECK.json。
- Catbus/Spider_XHS私信实现此前有对应非商业上游限制未核清，继续不纳入商业运行；BodaFu/auto-rednote的桌面私信路线仅macOS，不适合当前Windows成品；creatorhub根许可此前未核清。不能因为代码可见而全部装入商业包。

## 官方能力与使用条件

- [抖音官方企业私信接入方案](https://open.douyin.com/platform/resource/docs/ability/enterprise-account-open-ability/message-solution/)明确需用户授权，权限针对审核通过企业号；企业私信有平台频控规则。现有网页版逆向Bridge不因此自动获得官方企业接口权限。
- [抖音官方发私信接口说明](https://open.douyin.com/platform/resource/docs/openapi/enterprise-open-ability/message-management-enterprise/message-to-user/)的enterprise.im页面列出非互关主动触达与用户主动咨询后的频控，并提示内测申请已暂停。**该页是特定企业OpenAPI的规则，不是个人网页CLI的通用发送额度，也不能据此保证当前账号能申请或能群发。** 不应把收到评论当成收到用户私信/已经有官方会话与接收方openid。
- [小红书官方专业号私信通入口](https://pro.xiaohongshu.com/im/multiCustomerService)网页内容需账号权限，匿名未取得有效业务文档，不推断已可调用。
- [小红书官方帮助：收不到私信](https://school.xiaohongshu.com/helper/detail/1237?jumpFrom=customer)的搜索摘要说明陌生人信箱与互关私信列表不同；正文匿名本次未展开，不据此编造固定日上限/陌生人条数。对方隐私、关系和当前风控的真实限制仍以账号内实际平台回执为准。

## 最短可交付路线

1. 小红书先保持“评论回复”真实标签；可以提供来源明确的私信草稿/复制与用户主页入口，让本人在平台确认后操作。不要把复制、打开主页或准备草稿登记成发送成功。
2. 抖音复用现有单条DM实现，先补账号UID绑定、收件人/草稿/发送账号快照、稳定client_msg_id与发送回执落库。只凭message_id也不把“已发出”解释为“客户已阅读”。未知结果保留，不重发。
3. 先经过本人账号与一个明确授权对象的单条真实验收，再考虑批量。批量需复用现有客户原子防重、发送队列/同账号互斥、逐条权限和拒绝联系拦截、额度与停止条件；不能旁路ReviewedReplyQueues去调用DM脚本。
4. 如走官方企业私信，单独核实企业账号和应用权限、授权回调以及接收方openid/会话来源，不能用评论author_id直接顶替。

本目录DM-UI-CONTRACT.json只是供主窗口采用的诚实能力文案，未接入UI；默认两平台sendEnabled=false。用户本人不在，本轮跳过真实授权/登录/送达验收，不提问等待，不影响其他可完成集成。
