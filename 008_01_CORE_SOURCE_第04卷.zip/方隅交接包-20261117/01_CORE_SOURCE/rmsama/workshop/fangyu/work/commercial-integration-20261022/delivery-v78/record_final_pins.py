from pathlib import Path
import hashlib,json
D=Path(__file__).resolve().parent;P=D.parents[2];F=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v78'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert (D/'ASSEMBLY-SOURCE.json').is_file()
merge=json.loads((D/'ASSEMBLY-SOURCE.json').read_text('utf-8'));assert len(merge['files'])==12
u=json.loads((F/'UNIFIED-PINS.json').read_text('utf-8'));s=json.loads((F/'STAGED.json').read_text('utf-8'));R=Path(s['release']);m=json.loads((R/'RELEASE.json').read_text('utf-8'))
result={'rootExplicitFinalPins':True,'candidate':'candidate-unified-v78','unifiedPinsSha256':sha(F/'UNIFIED-PINS.json'),'stagedSha256':sha(F/'STAGED.json'),'manifestSha256':sha(R/'RELEASE.json'),'releaseId':s['release_id'],'unifiedFileCount':len(u['files']),'releaseFileCount':len(m['files']),'launcherSha256':sha(F/'project/work/ui-native-r57'/('run_candidate.'+s['release_id']+'.py'))}
assert result['unifiedFileCount']==3308 and result['releaseFileCount']==274,'Review any unexpected resource changes before activation'
target=D/'FINAL-PINS.json';assert not target.exists();target.write_text(json.dumps(result,indent=2),'utf-8')
print(json.dumps(result));print('ROOT_PINS_SHA256='+sha(target))
