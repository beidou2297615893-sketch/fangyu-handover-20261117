from pathlib import Path
W=Path(__file__).resolve().parent
text=(W/'test_factory_dm.py').read_text('utf-8')
anchor=" assert core.store.get('ui_dm_drafts_v1',d1['id'])==old_unknown\n assert all(v['foreignModeBlocked']"
assert text.count(anchor)==1
extra=''' # F79 integration: preserve account lifecycle safety alongside DM workers.
 def deletion(a,key):return {'storeId':store,'accountId':a['id'],'platform':a['platform'],'expectedNickname':a.get('platform_nickname') or a.get('name',''),'confirmed':True,'requestId':key}
 slow_listen[0]=True;stop_received.clear();before=len(wire)
 active_listener=mutate('dm_listen_start',{'accountId':other['id'],'confirmed':True,'timeoutMs':20000})
 for _ in range(200):
  if len(wire)>before:break
  time.sleep(.02)
 assert len(wire)>before and core.account_mode_status(other['id'],user['tenant_id'])['status']=='active'
 account_before=deepcopy(core.store.get('accounts',other['id']));key='dm-f79-delete-active-listener'
 response,_=action('account_delete',deletion(other,key),409)
 assert response['error']['code']=='ACCOUNT_BUSY' and core.store.get('accounts',other['id'])==account_before
 assert action('account_delete_request',{'storeId':store,'requestId':key})[0]['accountDeletion']['state']=='not_started'
 assert core.store.get('ui_dm_drafts_v1',d1['id'])==old_unknown
 dm('dm_listen_stop',{'id':active_listener['id']});slow_listen[0]=False
 checks.append('F79 original account deletion rejects active real DM listener atomic lease before service/receipt; account and original unknown unchanged, explicit own stop releases')
 retired={**other,'id':'dm-f79-retirable-account','platform_uid':'9007199254741555','conn_id':'dm-f79-retirable-connection','name':'合成可移除账号'}
 core.store.put('accounts',retired)
 oldtask={'id':'dm-f79-retained-task','tenant_id':user['tenant_id'],'cloud_owner':user['username'],'store_id':store,'platform':'douyin','account_id':retired['id'],'status':'paused','cursor':{'page':7},'created_at':'2026-10-23T00:00:00Z'}
 core.store.put('tasks',oldtask)
 retained={'id':'dm-f79-retained-comment','tenant_id':user['tenant_id'],'cloud_owner':user['username'],'store_id':store,'platform':'douyin','task_id':oldtask['id'],'author_id':'9007199254741666','text':'仅合成客户评论，账号移除后保留'}
 core.store.put('leads',retained)
 before_dm={entity:deepcopy(core.store.list(entity,user['tenant_id'])) for entity in ['ui_dm_conversations_v1','ui_dm_messages_v1','ui_dm_drafts_v1','ui_dm_queues_v1']}
 before_wire=len(wire);key='dm-f79-delete-idle-retirable';data=deletion(retired,key)
 action('account_delete',{**data,'confirmed':False},400)
 action('account_delete',{**data,'expectedNickname':'另一个昵称'},409)
 assert core.store.get('accounts',retired['id'])==retired and len(wire)==before_wire
 checks.append('F79 deletion explicit confirmation and exact current nickname CAS remain enforced with DM component loaded; no extra wire')
 result,_=action('account_delete',data)
 assert result['accountDeletion']['state']=='deleted' and core.store.get('accounts',retired['id']) is None
 retained_task=core.store.get('tasks',oldtask['id'])
 assert retained_task['account_id']=='' and retained_task['account_removed'] is True and retained_task['cursor']==oldtask['cursor'] and retained_task['cloud_owner']==oldtask['cloud_owner'] and retained_task['store_id']==store
 assert core.store.get('leads',retained['id'])==retained and all(core.store.list(entity,user['tenant_id'])==rows for entity,rows in before_dm.items()) and len(wire)==before_wire
 assert action('account_delete',data)[0]['accountDeletion']['state']=='deleted'
 assert action('account_delete_request',{'storeId':store,'requestId':key})[0]['accountDeletion']['state']=='deleted'
 assert core.store.get('ui_dm_drafts_v1',d1['id'])==old_unknown
 checks.append('F79 original service/Business/Core idle account deletion retires only old task binding, retains cursor/customer and all DM records; same original delete key replays without wire')
 dm('dm_workspace_read',{'accountId':retired['id']},403)
 assert read(other)['accountId']==other['id'] and core.store.get('accounts',other['id'])==account_before
 checks.append('Deleted account cannot regain DM scope; another exact owner/store account retains its original workspace and identity')
'''
text=text.replace(anchor,extra+anchor)
(W/'test_factory_f79_regression.py').write_text(text,'utf-8')
# Reuse source finalizer with only fixed baseline/pins and existing notice input.
old=W.parent/'dm-product-integration-candidate'
text=(old/'finalize_source.py').read_text('utf-8').replace("stage-02/project'","candidate-unified-v79/project'").replace("candidate-unified-v77'","candidate-unified-v79'")
(W/'finalize_source.py').write_text(text,'utf-8')
(W/'UPSTREAM-REFRESH.json').write_bytes((old/'UPSTREAM-REFRESH.json').read_bytes())
text=(W.parent/'v79-final-source-independent-review/test_keyword_composition.cjs').read_text('utf-8')
oldProject="const project=v=>path.join(P,'work/parallel-integration-20261018/final-integration/candidate-unified-v'+v,'project');"
newProject="const project=v=>v===79?path.join(O,'qa-only-project'):path.join(P,'work/parallel-integration-20261018/final-integration/candidate-unified-v'+v,'project');"
assert oldProject in text
text=text.replace(oldProject,newProject)
oldStage="const stage=JSON.parse(fs.readFileSync(path.join(project(v),'../STAGED.json'),'utf8'));"
newStage="const stage=JSON.parse(fs.readFileSync(v===79?path.join(O,'QA-STAGE-PINS.json'):path.join(project(v),'../STAGED.json'),'utf8'));if(v===79)Object.assign(stage,stage.stage);"
assert oldStage in text
text=text.replace(oldStage,newStage)
(W/'test_keyword_composition.cjs').write_text(text,'utf-8')
print('Prepared four finite F79/DM original-factory compatibility groups; no product edits')
