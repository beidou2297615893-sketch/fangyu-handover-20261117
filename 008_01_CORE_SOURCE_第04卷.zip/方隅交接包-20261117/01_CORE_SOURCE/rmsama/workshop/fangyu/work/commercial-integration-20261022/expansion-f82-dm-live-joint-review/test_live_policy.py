from pathlib import Path
p=Path(__file__).resolve().parent/'test_factory.py';exec(compile(p.read_text('utf-8').split('passed=False\ntry:')[0],str(p),'exec'),globals())
from unittest.mock import patch
passed=False
try:
 c=Case('current-store-policy-cas');first=c.capture('live-policy-frozen-original-key')['livestream'];lead=c.rows()['leads'][0];task=c.core.store.get('tasks',lead['task_id'])
 assert task['account_id']=='' and task['livestream_collection_account_id']==c.account['id'];assert task['city']=='上海' and task['store_id']==c.store and task['livestream_local_prompt_version']=='gubei-demand-context-20261022-v2'
 assert set(task['livestream_intent_policy'])=={'tenant_id','owner','revision','digest','actor_fingerprint'} and 'policy' not in task['livestream_intent_policy'];assert all('policy' not in (v.get('livestream_intent_policy') or {}) for v in c.core.handle('list',{'entity':'tasks'},c.user))
 before=len([v for v in ai_wire if v['operation']=='intent_analyze']);from assistant.intent_rule_management import IntentRuleManagement
 manager=IntentRuleManagement(c.core,c.user['tenant_id'],c.user['username'],company);snapshot=manager.snapshot(c.user);policy=deepcopy(snapshot['policy']);policy['name']='本人显式更新后的合成规则'
 manager.execute('intent_rules_save',{'policy':policy,'expected_revision':snapshot['revision'],'idempotency_key':'live-policy-change-original'},c.user)
 c.analyze();job=c.core.store.get('ai_jobs',task['id']);assert job['code']=='AI_CONTEXT_REQUIRED' and len([v for v in ai_wire if v['operation']=='intent_analyze'])==before and c.core.store.get('leads',lead['id'])==lead,job
 n=c.stats()['routeReads'];c.capture('live-after-policy-change-newkey',409);assert c.stats()['routeReads']==n
 assert c.query('live-policy-frozen-original-key')['livestream']['state']=='received'
 for action,data in [('run_task',{'id':task['id']}),('save',{'entity':'tasks','record':{'id':task['id'],'scope':'search'}})]:
  try:c.core.handle(action,data,c.user)
  except ValueError as error:assert '直播分析任务' in str(error),str(error)
  else:raise AssertionError('Typed live task was accepted as generic collection')
 assert c.stats()['routeReads']==n and c.core.store.get('tasks',task['id'])==task
 groups.append({'group':'policy_snapshot_and_typed_task_original_guard','result':'PASS','newIntentDispatches':0,'originalTaskAndLeadUnchanged':True});c.close()
 c=Case('captured-account-retirement-analysis');captured=c.capture('live-delete-account-captured-original')['livestream'];lead=c.rows()['leads'][0];task=deepcopy(c.core.store.get('tasks',lead['task_id']));assert not lead.get('ai_intent') and task['account_id']==''
 before=c.stats()['routeReads'];deleted=c.action('account_delete',{'storeId':c.store,'accountId':c.account['id'],'platform':'douyin','expectedNickname':c.account['name'],'confirmed':True,'requestId':'live-delete-collector-original-001'});assert deleted['accountDeletion']['state']=='deleted' and c.core.store.get('accounts',c.account['id']) is None,deleted
 assert c.core.store.get('tasks',task['id'])==task and c.stats()['routeReads']==before
 dispatch_before=sum(v['operation']=='intent_analyze' for v in ai_wire);c.analyze();assert c.core.store.get('leads',lead['id']).get('ai_intent',{}).get('status')=='graded';assert sum(v['operation']=='intent_analyze' for v in ai_wire)==dispatch_before+1
 assert c.query('live-delete-account-captured-original')['livestream']['analysis']['analyzed']==1
 people,_=c.req('GET','/api/workbench/customers?platform=douyin');assert len(people['customers']['items'])==1 and people['customers']['items'][0]['sourceType']=='livestream_chat' and people['customers']['items'][0]['commentReplyAllowed'] is False
 assert c.core.store.get('tasks',task['id'])==task and c.stats()['routeReads']==before
 groups.append({'group':'capture_then_original_account_delete_preserves_original_AI_task_rules_customer','result':'PASS','platformReadsAfterDeletion':0,'syntheticOriginalAIWorkerDispatch':1,'taskAndSourceVersionUnchanged':True});c.close()
 passed=True
finally:
 error=traceback.format_exc() if sys.exc_info()[0] else None
 for c in cases:
  if c.child and c.child.poll() is None:
   try:c.close()
   except BaseException:error=(error or '')+traceback.format_exc()
 save(OUT/'RESULTS.json',{'status':'PASS' if passed and not error else 'RED','groups':groups,'groupCount':len(groups),'httpRequests':sum(len(c.requests) for c in cases),'error':error,'actualOriginalFactory':True,'realNativePlatformModelCalls':0,'stage':stage});print(json.dumps({'status':'PASS' if passed and not error else 'RED','groups':len(groups),'httpRequests':sum(len(c.requests) for c in cases),'evidence':str(OUT)}))
