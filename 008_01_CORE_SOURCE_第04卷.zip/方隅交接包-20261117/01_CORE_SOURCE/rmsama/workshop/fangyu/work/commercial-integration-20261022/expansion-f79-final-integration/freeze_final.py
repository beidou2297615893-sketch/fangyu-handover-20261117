from pathlib import Path
from datetime import datetime, timezone
import ast, hashlib, importlib.util, json, subprocess, sys
sys.dont_write_bytecode=True
C=Path(__file__).resolve().parent; P=C.parents[2]
S=C/'project'; F=P/'work/parallel-integration-20261018/final-integration'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
composition=json.loads((C/'COMPOSITION.json').read_text('utf-8'))
assert [x['component'] for x in composition['components']]==['dm','dm-retirement','schedule','query','media']
changed=sorted({r['path'] for component in composition['components'] for r in component['files']})
for relative in changed:
    if relative.endswith('.py'):ast.parse((S/relative).read_bytes(),filename=relative)
node=Path('C:/Users/rmsama/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe')
for relative in changed:
    if relative.endswith(('.js','.mjs')):
        subprocess.run([str(node),'--check',str(S/relative)],check=True,capture_output=True)
(C/'SOURCE-PRECHECK.json').write_text(json.dumps({'status':'SYNTAX_ONLY_NOT_ACCEPTANCE','sourcePaths':len(changed),'compositionSha256':sha(C/'COMPOSITION.json'),'productionAccess':False},indent=2),'utf-8')
spec=importlib.util.spec_from_file_location('root_original_final_freezer',F/'freeze_unified.py')
builder=importlib.util.module_from_spec(spec);spec.loader.exec_module(builder)
builder.SOURCE=S;sys.argv=[str(F/'freeze_unified.py'),'--candidate','candidate-unified-v80']
builder.main()
frozen=F/'candidate-unified-v80'
stage=json.loads((frozen/'STAGED.json').read_text('utf-8'))
pins=json.loads((frozen/'UNIFIED-PINS.json').read_text('utf-8'))
receipt={'status':'INACTIVE_AGGREGATE_FROZEN_PENDING_JOINT_ACCEPTANCE_NOT_INSTALLED',
    'createdUtc':datetime.now(timezone.utc).isoformat(),'project':str(frozen/'project'),
    'stagePath':str(frozen/'STAGED.json'),'stageSha256':sha(frozen/'STAGED.json'),
    'manifestSha256':stage['manifest_sha256'],'unifiedPinsSha256':sha(frozen/'UNIFIED-PINS.json'),
    'fileCount':len(pins['files']),'resourceCount':stage['files'],
    'compositionSha256':sha(C/'COMPOSITION.json'),'sourcePaths':len(changed),
    'components':[x['component'] for x in composition['components']],
    'productionAccess':False,'canonicalOrInstalledWritten':False,
    'realPlatformOrModelCalls':0,'commercialGoalComplete':False}
(C/'FROZEN-INPUTS.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),'utf-8')
print(json.dumps(receipt,ensure_ascii=False))
