from pathlib import Path
import argparse,ast,hashlib,json
D=Path(__file__).resolve().parent;sha=lambda raw:hashlib.sha256(raw).hexdigest()
p=argparse.ArgumentParser();p.add_argument('--review-sha',required=True);args=p.parse_args()
review=D.parent/'v79-canonical-entry-independent-review/FINAL-RECEIPT.json';assert sha(review.read_bytes())==args.review_sha
receipt=json.loads(review.read_text('utf-8'));assert receipt['actualOriginalReadOnlyCheckPassed'] is True and receipt['allOriginalFunctionsAndCasBackupRollbackUnchanged'] is True
entry=D/'install_verified_entry.py';raw=entry.read_bytes();assert sha(raw)==receipt['reviewedEntrySha256']=='01a261ca6b30c2bf2076ac0b5a622484fd81b1989dcd19361014cc7db2420ed1'
needle=b'INSTALLATION_REVIEWED = False';assert raw.count(needle)==1;new=raw.replace(needle,b'INSTALLATION_REVIEWED = True');assert sha(new)==receipt['expectedSingleBoolTrueSha256IfExactBytesReplacement']
oldtree,newtree=ast.parse(raw.decode()),ast.parse(new.decode());assert len(oldtree.body)==len(newtree.body)
changes=[a for a,b in zip(oldtree.body,newtree.body) if ast.dump(a,include_attributes=False)!=ast.dump(b,include_attributes=False)];assert len(changes)==1 and isinstance(changes[0],ast.Assign) and changes[0].targets[0].id=='INSTALLATION_REVIEWED'
backup=D/'ENTRY-BEFORE-ROOT-APPROVAL.py';assert not backup.exists();backup.write_bytes(raw);entry.write_bytes(new)
out={'status':'ROOT_APPROVED_REVIEWED_TECHNICAL_NEXT_LAUNCH_INSTALL','reviewSha256':sha(review.read_bytes()),'beforeSha256':sha(raw),'afterSha256':sha(new),'onlyReviewedBooleanChanged':True,'commercialGoalComplete':False,'actualNativeFirstStartVerified':False,'canonicalWrittenByThisScript':False};(D/'ROOT-ENTRY-APPROVAL.json').write_text(json.dumps(out,indent=2),'utf-8');print(json.dumps(out))
