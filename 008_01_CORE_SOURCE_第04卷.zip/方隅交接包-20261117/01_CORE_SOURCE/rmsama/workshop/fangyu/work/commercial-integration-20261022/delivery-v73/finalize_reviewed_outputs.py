"""Deliver only the reviewed held SFX; preserve old outputs and current application."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import shutil

P = Path('C:/积木软件工坊/项目/方隅公寓客户版').resolve()
W = P / 'work/commercial-integration-20261022'
D = W / 'delivery-v73'
A = W / 'final-installer-upgrade-audit'
R = A / 'runtime-message-candidate'
OUT = P / 'outputs/三合一交付'
PACKAGE = OUT / '普通电脑内测版'
NEW_SHA = '38d3fcc329f44a38045cc1e9865d2a5312464c58fa918a3555e5a7c110ad4eb8'
OLD_SHA = '344f863c4427e8be90406bc5d3d5173f773db5546fe7be2783015ddb752ae2e7'

def require(ok, reason):
    if not ok:
        raise RuntimeError(reason)

def sha(path):
    with path.open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()

def pin(path, expected):
    require(path.is_file() and sha(path) == expected, 'Pinned file changed: ' + path.name)

pins = {
    A / 'FINAL-RECEIPT.json': '1a353acaa7c179e228a6b50b5c0de905a168d8c9bb161d641449735ced5aeca2',
    A / 'FINAL-INSTALLER-SUCCESSOR-HANDOFF.json': '47f227913bd1c077f3d64159bd4cddedf932ad2724ec282ef1ad83af9e188b65',
    R / 'installer.runtime-message-shortcut.py': '5f9b4d7ab00b6348d07d15a241ad804cf593ec137d576e5a3ce67476df01dca9',
    R / 'SFX-BUILD-RECEIPT.json': '62053fd8818643b7d70cd7bbef3ae5d9bab9d66bdf5dc5f164c4405c71a78dc9',
    R / 'SUCCESSOR-VALIDATION.json': 'dff35a1ce8df5f77cf5f1a188fe3ca16b8e2504af16241a361dab634060c7f49',
    W / 'installer-successor-independent-review/SOURCE-FINAL-RECEIPT.json': '55f3e68bb528b8238ba66104342be971dc06e6a92f1152f6d835cf981ed13c04',
    W / 'v73-final-independent-review/STANDARD-FINAL-RECEIPT.json': 'dbbcd6855e76d2641c8bcf89e2a820a1e57ed7abf61031defd71fe3d3a609b22',
    W / 'v73-final-independent-review/SOURCE-FINAL-RECEIPT.json': '54360fa8cfd5f8257a6fc574a972c004f540fd597ce2be546f8fe58ced1f5165',
    W / 'final-store-intent-audit/SEAL.json': '6c94974d323e7d874a2ff77f548377c1055e457947f4432ba6830c98a92f3fbd',
    W / 'final-full-scope-reconciliation/DOC-CLAIM-REVIEW.json': '0801836332a5c800d445ab728003f6ecd4e4eefa0565c0008667d5a66bbde2a1',
}

# The independent final receipt is deliberately required separately at execution.
independent_path = W / 'installer-successor-independent-review/FINAL-RECEIPT.json'
approval_path = D / 'ROOT-INSTALLER-DELIVERY-APPROVAL.json'
require(approval_path.is_file(), 'Root must review and pin the independent final receipt first')
approval = json.loads(approval_path.read_text('utf-8'))
require(approval['approvedHeldSfxSha256'] == NEW_SHA, 'Wrong installer approval')
require(approval['commercialOrPlatformApproval'] is False, 'Held release boundary changed')
pins[independent_path] = approval['independentFinalReceiptSha256']
for path, expected in pins.items():
    pin(path, expected)
independent = json.loads(independent_path.read_text('utf-8'))
require(independent.get('blockingFindings') == [], 'Independent installer blockers remain')

source = R / 'FangyuWorkbenchSetup-standard-held-clean-v73-protected-upgrade.exe'
pin(source, NEW_SHA)
require(source.stat().st_size == 281270881, 'Wrong SFX length')
exe = PACKAGE / '方隅工作台_受限内测安装包.exe'
guide = PACKAGE / '安装与当前能力.txt'
current = OUT / '当前交付核对.md'
history = OUT / '今日需求与数据核对.md'
old_documents = {
    guide: '8f5743787878d30b6a8f7451d061796ef649c8792e629dc588c1b8e1543b3986',
    current: '634620036ffd3f8a2989a0d86a7adf0929684d645a992ba471fc2f533bb9d1e7',
    history: 'cee0ae5cb6e0c9a95f4578acb5f7a2660c771031cbf89ef5e8b7308886c47d48',
}
pin(exe, OLD_SHA)
for path, expected in old_documents.items():
    pin(path, expected)
archive = OUT / '历史内测版/上次保留'
before = D / 'human-documents-before-final'
receipt = D / 'CLEAN-OUTPUT-DELIVERY.json'
require(not archive.exists() and not before.exists() and not receipt.exists(), 'Preserve existing delivery history')
for path in [PACKAGE, archive, before, current, history, exe, guide]:
    require(path.resolve().is_relative_to(P), 'Resolved output escaped this project')

guide_text = '''方隅工作台：普通电脑受限内测版

这份约281MB的安装包用于独立电脑安装核对，完整业务和真实平台尚未全部验收。真实平台采集、自动发送及作品发布保持关闭。

原电脑的下一次启动入口已更新，目前打开的窗口继续保留原稳定版本，原客户、评论、账号和断点未变。无需用本内测包重装原电脑。

电脑条件
64位Windows 10或11，需要已有可用的WebView2和.NET桌面环境。无需另装Python、不要求独立显卡，也不捆绑本地大模型。缺少WebView2时会停止安装，不会自动下载；需先由本人准备官方运行时。

安装与核对
优先在独立测试电脑使用。已有正在使用的客户实例时，不要直接覆盖，先核对安装位置和保留方式。安装器按客户区分程序目录；同名快捷方式若指向其他程序或无法确认目标，会保留原快捷方式，并提示从安装后的入口打开。

首次使用需要自己的企业员工账号和门店权限。本包不含原客户名单、平台登录会话、测试管理员或原电脑凭据。

本轮包已通过内容完整性、启动自检、自有目录解包、升级和失败恢复检查。相同基础入口的前版做过桌面首启；本轮新包尚未实际打开桌面窗口，第二台实体电脑、真实员工及平台登录和完整业务仍待验收。

本轮新增
内容创作可预览并选择本店的管理话术、接待流程、口吻和资料，资料变化需重新核对。客户详情可整理原评论中明确自愿留下的联系方式，由本人逐条确认、拒绝或撤销，不会自动联系客户。

现有资料导入支持Word、PPT、纯文字和Markdown的文字内容。自动内容生成尚未开启，原客户意向分析按原方式保留。视频功能使用已有素材和提供的字幕，本包不捆绑视频处理工具，缺少已核验外置工具时会提示不可用；不包含自动转写、配音或AI视频生成。

本包不会自动回复客户、发私信或发布作品。需要本人扫码、人脸或验证码时保留断点。
'''

current_text = '''# 当前交付核对

原工作台保持运行，**下一次关闭重开后加载本轮新增功能**。没有强制重启或打断任务，原客户、账号及断点继续保留。三个窗口的完整能力尚未全部完成。

本轮新增两项：创作时可预览并勾选本店管理话术、接待流程、口吻和已有资料，资料变化需重新核对；客户详情可整理原评论中明确自愿留下的联系方式，逐条本人确认、拒绝或撤销，原文撤回后旧确认失效。这些操作不自动联系客户，也不把历史价格和样例当作已核实的房源事实。

## 已接入并验证

- **客户与回复**：人工更正保留原AI判断，更正后刷新；筛选外客户可打开，折叠与连续加载、跨页选择和实际表格下载已验证。回复仍由本人核对发送。
- **获客**：关键词、指定帖子、指定博主及自己账号互动共用原客户、任务和断点；定期检查须本人选账号、门店和频率，仅在当前工作台会话运行，重开后重新确认。新来源仍需真实平台核验。
- **内容工作区**：人设、栏目、选题、资料和手工草稿可编辑，写作任务、规则检查、人工审核、内容包及历史共用一个入口。自动内容生成尚未开启；原客户意向分析按原方式保留。
- **资料与视频**：支持Word、PPT、纯文字、Markdown的文字预览与确认保存；已核验已有视频素材加提供字幕的剪辑、播放和下载。普通电脑缺少已核验外置视频工具时提示不可用。尚不含PDF、扫描件、录音转写、配音或AI媒体生成。
- **结果登记**：本人可登记联系、预约、到访、签约、回款及实际费用，保留撤销历史。未知金额与零分开；不把联系方式确认当成留资或成交，没有利润依据时不报ROI。

前一版本通过70组接口检查；本轮复验47组关键接口，另核对宽窄界面、权限、原断点、未知结果、并发和程序完整性。使用的是独立测试数据，不能代替真实平台或本人界面验收。

## 数据与规则

| 项目 | 下一启动入口更新后的数据核对 |
|---|---:|
| 原评论 | 1,888条 |
| 按原作者归并的客户记录 | 1,129位 |
| 原采集任务 | 40个 |
| 原评论、回复、任务被丢失或改写 | 0条 |
| 原账号工作区绑定 | 保持一致 |

这些客户记录不代表每位都有租房意向、已适配门店或可以主动联系。原业务已单独备份。

现存任务和评论都关联**上海古北店**。新版本保留古北1—12个月判断规则与租期分组；其他12家店的规则输入保持原样，没有复制古北新规则。13家店核对的是词库结构、资料引用和规则输入；现价、库存和设施等事实仍需门店确认。默认帖子最近30天，可改7天或90天；历史任务保留原条件。

1,888条评论均有Codex复核记录。其中1,794条有历史DeepSeek结果，1,503条标签相同、291条不同，83.78%是一致率，不是准确率；另94条未保存AI结果，部分关联原来的未明确结果，需保留原记录核对，不能反复新建分析。历史AI中的高意向为144条评论，并非144位已确认客户。本轮没有整批重评或覆盖历史AI，后续在线新分析效果仍待核验。

## 仍需完成

- **工程缺口**：私信收发与批量队列、直播和主动互动、真实作品发布、内容定时及多账号执行、平台联想词与外部效果取数，以及自动转写、配音和生成式媒体。
- **待真实核验**：新增来源、分页、账号身份、验证后恢复；新内容生成服务接通后的实际质量；本人完整界面、第二台普通电脑安装及真实员工和平台业务。不能将这些统一写成只等扫码。

本轮受限内测安装包和说明已放在同级“普通电脑内测版”文件夹，约281MB。无需另装Python、独立显卡或本地大模型，需要既有WebView2和.NET；媒体工具另行配套。缺运行时会停止安装，同名快捷方式指向其他程序时保留原项。它仍是受限内测包，不能作为全部业务已验通的正式客户包；原电脑已另行更新下一启动入口，不必重装。

没有替本人发送真实评论、私信或作品。扫码、人脸或验证码依赖继续保留断点，不反复请求。
'''

history_text = history.read_text('utf-8')
needle = '此前对1,878条评论进行独立复核，其中1,794条有可对照的DeepSeek结果，标签一致率为83.78%。Codex更常保留具体出租帖下的简短询盘，较少因没写预算或租期而标成待确认；同时区分已经结束、供房推广和真正求租。'
require(history_text.count(needle) == 1, 'Historical review sentence changed')
history_text = history_text.replace(needle, '现存1,888条评论都有独立复核记录；其中1,794条有可对照的DeepSeek结果，1,503条标签相同、291条不同，一致率83.78%。另94条没有保存AI结果，不是复核漏比，也不等于没有需求；其原因须按原记录分别核对。Codex复核更常保留具体出租帖下的简短询盘，同时区分已经结束、供房推广和真正求租。')
history_text = history_text.replace('# 10月22日需求与数据核对\n', '# 10月22日需求与数据核对\n\n> 这是按时间保留的阶段记录，其中“正在接入”“已启动”“未切入口”均指各自当时的版本。当前以同目录《当前交付核对》为准：本轮新增设为下一次启动使用，眼前旧窗口没有被重启；完整三合一尚未完成。\n', 1)

before.mkdir()
for path in old_documents:
    shutil.copy2(path, before / path.name)
archive.mkdir(parents=True)
staged_exe = PACKAGE / '安装包待就位.tmp'
staged_guide = PACKAGE / '安装说明待就位.tmp'
require(not staged_exe.exists() and not staged_guide.exists(), 'Preserve interrupted delivery stage')
shutil.copy2(source, staged_exe)
pin(staged_exe, NEW_SHA)
staged_guide.write_text(guide_text, encoding='utf-8', newline='\n')
moved = []
placed = []
try:
    for target in [exe, guide]:
        target.rename(archive / target.name)
        moved.append(target)
    for staged, target in [(staged_exe, exe), (staged_guide, guide)]:
        os.replace(staged, target)
        placed.append(target)
except Exception:
    for target in reversed(placed):
        target.rename(archive / ('本轮未完成-' + target.name))
    for target in reversed(moved):
        (archive / target.name).rename(target)
    raise
pin(exe, NEW_SHA)
pin(archive / exe.name, OLD_SHA)
pin(archive / guide.name, old_documents[guide])
current.write_text(current_text, encoding='utf-8', newline='\n')
history.write_text(history_text, encoding='utf-8', newline='\n')

result = {
    'status': 'PASS_REVIEWED_DERIVED_V73_HELD_SFX_COPIED_AND_OLD_OUTPUTS_ARCHIVED',
    'createdAtUtc': datetime.now(timezone.utc).isoformat(),
    'deliveredInstaller': str(exe), 'sha256': sha(exe), 'bytes': exe.stat().st_size,
    'originalZipSha256': '5147dfdf36818760f0d311d73930f69c48744b22ff59c304a26635ea052579cb',
    'oldInstallerArchive': str(archive / exe.name), 'oldInstallerSha256': OLD_SHA,
    'oldGuideSha256': old_documents[guide], 'documentBackups': str(before),
    'currentDocuments': {str(path): sha(path) for path in [guide, current, history]},
    'fixedEvidence': {str(path): value for path, value in pins.items()},
    'rootApprovalSha256': sha(approval_path),
    'installerExecutedByRoot': False, 'liveAppOrCanonicalWritten': False,
    'customerDataOrSessionsOrCredentialsCopied': False,
    'nativeV73FirstWindowVerified': False, 'secondPhysicalPcVerified': False,
    'commercialOrRealPlatformApproval': False,
}
receipt.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'status': result['status'], 'installerSha256': sha(exe), 'receipt': str(receipt)}, ensure_ascii=False))
