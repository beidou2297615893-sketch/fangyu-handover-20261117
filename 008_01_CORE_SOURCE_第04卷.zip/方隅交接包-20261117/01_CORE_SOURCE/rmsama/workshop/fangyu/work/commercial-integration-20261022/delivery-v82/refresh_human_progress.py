from pathlib import Path
from datetime import datetime, timezone, timedelta
import hashlib, json, shutil

D=Path(__file__).resolve().parent
W=D.parent
P=D.parents[2]
out=P/'outputs/整合进度'
target=out/'工作台整合与客户数据核对.md'
backup=D/'progress-before'
assert not backup.exists()
backup.mkdir()
shutil.copy2(target,backup/target.name)
install=json.loads((D/'INSTALLATION-FINAL.json').read_text('utf-8'))
assert install['allSevenBusinessDigestsUnchanged'] and install['accountRecords']==3
package=json.loads((D/'STANDARD-DISTRIBUTION-DELIVERY.json').read_text('utf-8'))
assert package['ordinaryHeldScopeStillHeld'] and package['bytes']==307396837
now=(datetime.now(timezone.utc)+timedelta(hours=8)).strftime('%Y年%m月%d日%H:%M')
source=W/'expansion-f82-content-joint-validation/ui-http-68aa912ee262495e83203fdc2f66a087/experience-reference-390.png'
image=out/'复盘经验窄窗口验证.png'
shutil.copy2(source,image)
body=f'''# 工作台整合与客户数据核对

更新：{now}。本轮已安装到下一次启动入口，当前窗口没有被强制关闭。

## 现在的真实状态

18:17只读检查：原窗口的界面服务正常，仍显示旧版本；新版本需从原桌面快捷方式正常重开后加载。数据库没有运行中的采集任务，5个就绪、35个暂停，评论仍为1888条。这是时间点快照，不是实时采集计数。

你可以先复核已有客户、保存回复草稿。需要载入新功能时，先保存正在编辑的内容，再正常关闭工作台，从原桌面“方隅工作台”重开即可，无需重新安装或搬迁数据。平台扫码、人脸和验证码仍由本人完成，旧断点保留。

## 本轮新增和入口

| 入口 | 已安装的变化 | 实际边界 |
| --- | --- | --- |
| 内容运营：访谈 | 根据已保存回答填写本人阶段小结，确认后继续 | 本人确认与AI生成分开，不把自述当已核实事实 |
| 内容运营：资料与引用 | 复盘经验可以采用、撤回，并在下一任务明确选择使用 | 经验仍需验证，不自动修改门店事实、SOP或代码 |
| 内容运营：联网找参考 | 明确填写检索词，选择摘要结果后保存为待核资料 | 原文未抓取；不自动引用、生成或发布 |
| 多样化获客：直播 | 明确账号和直播窗口，单轮读取接入原客户与分析队列；等待时可查看进度 | 开发链已验，真实原生直播窗口和平台实采未验，不承诺十房并发 |
| 私信准备 | 固定命令接线、跨账号防重、未知结果保留原编号 | 真实私信发送、送达与平台历史消息仍未放行验通 |

复盘后切换页签无反应的问题已修复；等待检索或直播回执时，其他页面读取不再被整个长请求挡住。原有客户、回复草稿、账号、SOP、导入导出、排程、提字配音和扫描PDF继续保留。

本轮原业务、账号和关键词界面回归通过；私信与直播合版测试、内容流程和完整页面宽窄窗口检查通过。本机原入口检查、自检也已通过。测试使用独立数据和受控回执；没有替本人发送真实评论、私信或发布。

## 客户与账号数据

| 保存内容 | 已核对数量 |
| --- | --- |
| 账号 | 3个，更新前后元数据一致 |
| 原始评论 | 1888条 |
| 采集任务 | 40个，旧任务与断点保留 |
| DeepSeek已存分析 | 1794条，另94条没有保存结果 |
| 已存租住判断 | 1465条 |
| 回复记录 | 4条，不据此推断真实发送人数 |

更新前后七类业务内容摘要完全一致，本轮另留完整数据库备份。没有恢复旧备份覆盖当前客户。此前按稳定平台身份去重为1129位客户，不等于全部有租房意向。

软件显示仍以DeepSeek已存结果和人工更正为准，Codex复核没有悄悄覆盖软件。此前对照覆盖1888条，其中17条没有正文；1794条可以直接比较，291条判断不同。一致率不能当准确率。

[打开评论分析对照与高意向参考名单](C:/积木软件工坊/项目/方隅公寓客户版/outputs/评论分析对照/DeepSeek与Codex评论分析对照.xlsx) · [打开名单所在文件夹](C:/积木软件工坊/项目/方隅公寓客户版/outputs/评论分析对照)

## 古北与其他门店

此前核对的1888条评论和40个任务均关联古北。古北保留1—12个月租期分组，默认最近30天帖子，可选7天或90天。另12家门店未被古北规则覆盖；本轮安装没有修改业务数据库。房价、库存和设施仍以门店实际确认内容为准。

## 安装包与未完成事项

普通Windows安装包已重新编译并独立检查，约307MB，不需要独显或本地大模型，不含这台电脑的客户、账号和会话。当前包供其他电脑技术验收，仍有平台连接用途限制，不能当作已放行的完整商业交付版；第二台实体电脑首启仍未验。

本机已绑定工作区继续使用原快捷方式。真实平台采集效果、私信送达、发布、直播实采、本人原生首开，以及录音转写、完整多角色编排和热点联想等余项仍在继续。完整三合一尚未全部完成。

下面是本轮实际开发测试的窄窗口页面，使用合成资料，展示经验采用、版本与撤回；它不是当前本人账号或真实平台成功的证明。

![复盘经验窄窗口验证](C:/积木软件工坊/项目/方隅公寓客户版/outputs/整合进度/复盘经验窄窗口验证.png)
'''
target.write_text(body,'utf-8')
(D/'HUMAN-PROGRESS-DELIVERY.json').write_text(json.dumps({'path':str(target),
    'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'imageSha256':hashlib.sha256(image.read_bytes()).hexdigest(),
    'oldReportBackedUp':True,'realPlatformSuccessClaimed':False,'fullGoalComplete':False},ensure_ascii=False,indent=2),'utf-8')
print('Human progress rewritten around actual installed update, protected data and remaining scope')
