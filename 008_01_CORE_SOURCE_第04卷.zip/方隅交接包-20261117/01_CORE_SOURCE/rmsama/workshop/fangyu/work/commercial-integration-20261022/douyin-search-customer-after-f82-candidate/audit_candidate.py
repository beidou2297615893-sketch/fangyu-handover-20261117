from pathlib import Path
import ast,difflib,hashlib,json
W=Path(__file__).resolve().parent;P=W.parents[2]
F=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v82/project'
PRE=W.parent/'customer-read-purpose-after-f82-candidate/source-candidate';S=W/'source-candidate'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
allowed={
 'work/shared-backend-integration/customer_read_distribution.py':{'CustomerReadAuthority._state','CustomerReadAuthority.resolve'},
 'work/ui-runtime-r55/src/core/douyin_search_policy.py':{'DouyinSearchPolicy._snapshot','DouyinSearchPolicy.current_review','DouyinSearchPolicy.resolve'},
 'work/ui-runtime-r55/src/core/adapters.py':{'Adapters.search','Adapters.comments'},
 'work/shared-backend-integration/vendor-src/assistant/business.py':{'BusinessExecutor._verify_first_douyin_search','BusinessExecutor._execute'},
 'work/ui-runtime-r55/src/core/engine.py':{'Core._handle'},
}
def functions(tree,prefix=''):
    answer={}
    for n in tree.body:
        if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)):answer[prefix+n.name]=ast.dump(n,include_attributes=False)
        elif isinstance(n,ast.ClassDef):answer.update(functions(n,prefix+n.name+'.'))
    return answer
rows=[];checks=[];patch=[]
for path in sorted(S.rglob('*.py')):
    rel=path.relative_to(S).as_posix();origin=(PRE/rel) if (PRE/rel).is_file() else F/rel
    after=path.read_text('utf-8');ast.parse(after)
    if origin.exists():
        before=origin.read_text('utf-8');a,b=functions(ast.parse(before)),functions(ast.parse(after))
        changes={key for key in a|b if a.get(key)!=b.get(key)}
        assert changes==allowed[rel],(rel,changes,allowed[rel])
        if rel.endswith('core/engine.py'):
            for name in ('Core._run_inner','Core._import','Core._classify','Core._classify_rule','Core._run','Core._run_sequence'):
                assert a[name]==b[name]
            checks.append({'originalCoreImportFilterDedupAnalysisAndPipelineMethodsUnchanged':True,'untouchedMethods':len(a)-1})
        patch.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='before/'+rel,tofile='after/'+rel))
        rows.append({'path':rel,'beforeOrigin':str(origin),'beforeSha256':sha(origin),'afterSha256':sha(path),'changedFunctions':sorted(changes)})
    else:
        assert rel=='work/ui-runtime-r55/src/core/douyin_customer_tasks.py'
        patch.extend(difflib.unified_diff([],after.splitlines(True),fromfile='/dev/null',tofile='after/'+rel))
        rows.append({'path':rel,'beforeOrigin':None,'afterSha256':sha(path),'newPrivateModule':True})
assert len(rows)==6,rows
canonical='work/ui-runtime-r55/src/assistant/business.py'
assert not (S/canonical).exists()
checks.append({'canonicalBusinessUnchangedAndNotShippedAsDelta':sha(F/canonical)})
for rel in ('work/ui-runtime-r55/src/core/pipeline.py','work/ui-runtime-r55/src/assistant/ai_workflow.py',
        'work/shared-backend-integration/vendor-src/assistant/ai_worker.py','work/shared-backend-integration/platform_runtime.py',
        'work/ui-native-r57/ui_native_host.py'):
    assert not (S/rel).exists()
checks.append({'oldHostPlatformRuntimeAiQueueAndOriginalPipelineNotChangedByThisDelta':True})
(W/'SOURCE-FILES.json').write_text(json.dumps({'schema':1,'files':rows},ensure_ascii=False,indent=2),'utf-8')
(W/'CANDIDATE.patch').write_text(''.join(patch),'utf-8')
(W/'AST-BOUNDARY-AUDIT.json').write_text(json.dumps({'status':'PASS','checks':checks,'sourceFiles':len(rows)},ensure_ascii=False,indent=2),'utf-8')
print(json.dumps({'sourceFiles':len(rows),'ast':'PASS','patchSha256':sha(W/'CANDIDATE.patch')}))
