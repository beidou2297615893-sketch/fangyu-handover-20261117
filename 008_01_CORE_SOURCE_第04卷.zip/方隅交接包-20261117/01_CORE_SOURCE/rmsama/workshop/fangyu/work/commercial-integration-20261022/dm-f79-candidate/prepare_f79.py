from pathlib import Path
import ast,hashlib,json,runpy,shutil,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=W.parents[2];OLD=W.parent/'dm-product-integration-candidate'
F=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v79';S=F/'project'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text('utf-8-sig'))
assert sha(W.parent/'delivery-v79/FINAL-PINS.json')=='3719840ea39dfe4874fe800f48fe9b58a92987649bd524a39b8074816b6efd64'
assert sha(F/'UNIFIED-PINS.json')=='fa71e0e3cda87f55708ef00fcdfef348fb1ddeb91911d44950f599080644ad83'
assert sha(OLD/'SOURCE-PINS.json')=='634e26f6fc1432775a23638a5bb2253ae142f4c99bf4b6f76f5ad1ece2785f4e'
assert sha(OLD/'SEALED.json')=='52f82212bffb7588cc5376b2bfe6cf068b207c3ad4b3a140e854930ee57f54d4'
rows=read(F/'UNIFIED-PINS.json')['files'];m={r['path']:r for r in rows};assert len(m)==3308
assert {p.relative_to(S).as_posix() for p in S.rglob('*') if p.is_file()}==set(m)
for rel,row in m.items():assert sha(S/rel)==row['sha256'] and (S/rel).stat().st_size==row['bytes'],rel
source=read(OLD/'SOURCE-PINS.json');conflicts=[]
for row in source['files']:
    rel=row['path'];p=OLD/'final-source'/rel;assert sha(p)==row['after']['sha256'],rel
    if row['before']:
        before=S/rel;assert before.is_file()
        if sha(before)!=row['before']['sha256']:conflicts.append({'path':rel,'originalDmBase77Sha256':row['before']['sha256'],'base79Sha256':sha(before),'resolution':'Reapply original narrowly anchored DM hunk operations to exact F79 bytes; never replace with old whole file.'})
    else:
        assert rel not in m
        dest=W/'source-candidate'/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(p.read_bytes())
# Reuse the already validated exact integration edits, changing only their
# explicitly read-only baseline path into actual frozen79.
for name in ['patch_integration.py','patch_ui.py']:
    text=(OLD/name).read_text('utf-8')
    old="S=P/'work/parallel-integration-20261018/final-integration/stage-02/project'"
    assert text.count(old)==1
    text=text.replace(old,"S=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v79/project'")
    if name=='patch_ui.py':
        # F79 inserted accountDeleteRead into the same two read classifications.
        # Add DM before it; preserve the exact account deletion recovery contract.
        assert text.count('get||media||')==2 and text.count('get||mediaRead||')==2
        text=text.replace('get||media||','get||accountDeleteRead||media||').replace('get||mediaRead||','get||accountDeleteRead||mediaRead||')
    dest=W/name;dest.write_text(text,'utf-8');runpy.run_path(str(dest),run_name='__main__')
assert len([p for p in (W/'source-candidate').rglob('*') if p.is_file()])==14
(W/'MERGE-CONFLICTS.json').write_text(json.dumps({'baseline':'Exact F79','originalDmSourcePins':sha(OLD/'SOURCE-PINS.json'),'overlappingChangedPaths':conflicts,'unresolvedConflicts':[],'wholeOldFilesCopiedOver79':False,'originalDmNewFilesUnchanged':True,'onlyOwnCandidateWritten':True},ensure_ascii=False,indent=2),'utf-8')
# Copy source-only closed F79 into an independent QA project, no frozen old
# releases, live profiles, databases, credentials or author test project.
Q=W/'qa-only-project';copied=[]
for row in rows:
    rel=row['path']
    if rel.startswith(('work/ui-native-r57/releases/','work/ui-native-r57/candidates/','work/ui-native-r57/run_candidate.')):continue
    if 'state' in Path(rel).parts and not rel.endswith('state/production-workspace.json'):continue
    assert Path(rel).suffix.lower() not in ('.db','.sqlite','.sqlite3','.pyc'),rel
    dest=Q/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes((S/rel).read_bytes());copied.append(rel)
for src in (W/'source-candidate').rglob('*'):
    if src.is_file():
        dest=Q/src.relative_to(W/'source-candidate');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(src.read_bytes())
site=P/'work/desktop-python/Lib/site-packages'
for pattern in ['pywebview-*.dist-info/licenses/LICENSE','pythonnet-*.dist-info/licenses/LICENSE','clr_loader-*.dist-info/licenses/LICENSE','bottle-*.dist-info/licenses/LICENSE']:
    for src in site.glob(pattern):
        dest=Q/'work/desktop-python/Lib/site-packages'/src.relative_to(site);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(src.read_bytes())
for name in ['test_factory_dm.py','serve_dm_ui.py','test_dm_ui.mjs']:
    (W/name).write_bytes((OLD/name).read_bytes())
text=(OLD/'test_dm_browser.cjs').read_text('utf-8');text=text.replace('/final-integration/stage-02/project/work/ui-runtime-r55/work/runtime/douyin-bridge','/final-integration/candidate-unified-v79/project/work/ui-runtime-r55/work/runtime/douyin-bridge');(W/'test_dm_browser.cjs').write_text(text,'utf-8')
(W/'QA-SOURCE-INPUTS.json').write_text(json.dumps({'label':'dm-f79-qa-only-no-install','project':str(Q),'baseline':str(S),'sourceFilesCopied':len(copied),'baselineUnifiedSha256':sha(F/'UNIFIED-PINS.json'),'noDbOrPrivateSessionCopied':True,'noCanonicalWrites':True,'overlapPaths':len(conflicts)},ensure_ascii=False,indent=2),'utf-8')
print(json.dumps({'sourceFiles':14,'overlapPaths':[r['path'] for r in conflicts],'qaSourceFiles':len(copied)},ensure_ascii=False))
