"""Explicit private-message reception/drafts over the original scoped Store.

No comment records are manufactured and no constructor/read starts a platform
operation. All execution passes the existing device, account, platform and
atomic AccountModeLeases gates. Uncertain sends retain their original key.
"""
from copy import deepcopy
from datetime import datetime,timezone
import base64,hashlib,json,re,threading,uuid
from core.adapters import AdapterBusy
from core.review_queue import require_reply_permission

ACTIONS=frozenset(('dm_workspace_read','dm_listen_start','dm_listen_stop','dm_request_read','dm_draft_save','dm_draft_review','dm_queue_prepare','dm_queue_start','dm_queue_cancel','dm_queue_read'))
CONVERSATIONS='ui_dm_conversations_v1';MESSAGES='ui_dm_messages_v1';DRAFTS='ui_dm_drafts_v1';QUEUES='ui_dm_queues_v1';REQUESTS='ui_dm_requests_v1';LISTENERS='ui_dm_listeners_v1'
KEY=re.compile(r'[A-Za-z0-9_-]{8,160}\Z');UID=re.compile(r'[1-9]\d{0,19}\Z')
def valid_uid(value):return isinstance(value,str) and bool(UID.fullmatch(value)) and int(value)<=18446744073709551615
def valid_conversation(value,left,right):
 return isinstance(value,str) and len(value.split(':'))==4 and value.split(':')[:2]==['0','1'] and sorted(value.split(':')[2:])==sorted([left,right])
CONTRACT='fangyu-dm-bounded-v1'
def stamp():return datetime.now(timezone.utc).isoformat()
def digest(v):return hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
class DMError(ValueError):
 def __init__(self,code,message,status=400):super().__init__(message);self.code,self.status=code,status
def fail(code,message,status=400):raise DMError(code,message,status)

class DMWorkbench:
 def __init__(self,core,runtime,customers,delivery):
  self.core,self.runtime,self.customers,self.delivery=core,runtime,customers,delivery
  self.workers={};self.stops={};self.closed=False;self.lock=threading.RLock()
 def close(self):
  self.closed=True
  for event in tuple(self.stops.values()):event.set()
  # Original runtime.close terminates its owned CLI processes. Browser listen
  # requests also have an independent 21-second maximum lifetime and no reconnect.
 def _account(self,user,store,ident):
  require_reply_permission(self.core,user)
  try:
   account=self.core._get('accounts',ident,user['tenant_id']);self.core._account_access(user,account)
  except ValueError:fail('DM_ACCOUNT_FORBIDDEN','请选择当前门店本人拥有的账号',403)
  if account.get('cloud_owner')!=user['username'] or account.get('store_id')!=store:fail('DM_ACCOUNT_FORBIDDEN','请选择当前门店本人拥有的账号',403)
  if account.get('platform') not in ('douyin','xiaohongshu'):fail('DM_PLATFORM_UNAVAILABLE','此平台尚未接入私信',422)
  if account.get('platform_uid') and any(a.get('id')!=account['id'] and a.get('platform')==account['platform'] and a.get('platform_uid')==account['platform_uid'] for a in self.core.store.list('accounts',user['tenant_id'])):fail('DM_DUPLICATE_ACCOUNT_IDENTITY','同一平台身份存在多个账号记录，请先在账号页核对',409)
  return account
 def _scope(self,user,store,account):return {'tenant_id':user['tenant_id'],'owner':user['username'],'userId':user['id'],'storeId':store,'accountId':account['id'],'platform':account['platform']}
 def _owned(self,entity,ident,user,store,account=None):
  row=self.core.store.get(entity,ident)
  if not row or any(row.get(k)!=v for k,v in {'tenant_id':user['tenant_id'],'owner':user['username'],'userId':user['id'],'storeId':store}.items()):fail('DM_SCOPE_FORBIDDEN','私信资料不在当前员工门店范围',403)
  if account is not None and row.get('accountId')!=account['id']:fail('DM_SCOPE_FORBIDDEN','私信资料不属于当前发送账号',403)
  return row
 @staticmethod
 def _db_put(db,entity,row):db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',(entity,row['id'],row['tenant_id'],json.dumps(row,ensure_ascii=False)))
 @staticmethod
 def _db_get(db,entity,ident):
  found=db.execute('SELECT body FROM records WHERE entity=? AND id=?',(entity,ident)).fetchone();return json.loads(found['body']) if found else None
 def _mutation(self,action,user,store,data,callback):
  request=data.get('requestId')
  if not isinstance(request,str) or not KEY.fullmatch(request):fail('DM_REQUEST_INVALID','请保留本次操作编号',400)
  ident=digest([user['tenant_id'],user['id'],store,action,request]);signature=digest(data)
  with self.core.store.connect() as db:
   db.execute('BEGIN IMMEDIATE');old=self._db_get(db,REQUESTS,ident)
   if old:
    if old['signature']!=signature:fail('DM_REQUEST_CONFLICT','原操作编号的内容已变化，请读取原操作结果',409)
    return deepcopy(old['result']),True
   result=callback(db)
   self._db_put(db,REQUESTS,{'id':ident,'tenant_id':user['tenant_id'],'owner':user['username'],'userId':user['id'],'storeId':store,'action':action,'requestId':request,'signature':signature,'result':result,'createdAt':stamp()})
   return result,False
 def _source(self,user,store,account,target):
  if not isinstance(target,dict):fail('DM_TARGET_INVALID','请从当前会话或可见客户选择收件人')
  if set(target)=={'conversationId'}:
   row=self._owned(CONVERSATIONS,target['conversationId'],user,store,account)
   return {'kind':'conversation','id':row['id'],'recipientUid':row['recipientUid'],'digest':digest([row['id'],row['platformConversationId'],row['recipientUid'],row['accountUid']])}
  if set(target)=={'customerId','leadId','sourceDigest'} and self.customers is not None:
   _,_,_,person=self.customers._context(user,store,target['customerId'],platform=account['platform'])
   if target['leadId'] not in {c['lead_id'] for c in person.get('comments') or []}:fail('DM_TARGET_FORBIDDEN','原评论不在当前客户可见范围',403)
   lead=self.core._get('leads',target['leadId'],user['tenant_id'])
   if digest(lead)!=target['sourceDigest'] or lead.get('platform')!=account['platform']:fail('DM_SOURCE_CHANGED','客户原文或平台已变化，请重新核对',409)
   recipient=str(lead.get('author_id') or '')
   valid=(valid_uid(recipient) if account['platform']=='douyin' else re.fullmatch('[A-Za-z0-9_-]{1,160}',recipient))
   if not valid:fail('DM_RECIPIENT_UNVERIFIED','客户缺少稳定的平台用户编号，不能猜昵称或主页编号',422)
   return {'kind':'customer','id':lead['id'],'customerId':target['customerId'],'recipientUid':recipient,'digest':target['sourceDigest']}
  fail('DM_TARGET_INVALID','请从当前会话或可见客户选择收件人')
 def _source_current(self,user,store,account,draft):
  source=draft['source'];target={'conversationId':source['id']} if source['kind']=='conversation' else {'customerId':source['customerId'],'leadId':source['id'],'sourceDigest':source['digest']}
  if self._source(user,store,account,target)!=source:fail('DM_SOURCE_CHANGED','原收件人来源已变化，旧核对已失效',409)
 def _snapshot(self,account,draft):
  return {'draftId':draft['id'],'version':draft['version'],'text':draft['text'],'source':draft['source'],'accountId':account['id'],'accountUid':str(account.get('platform_uid') or ''),'connection':str(account.get('conn_id') or ''),'storeId':draft['storeId'],'platform':account['platform']}
 def _boundary(self,refresh,scope,account_snapshot,mode,owner,stop,*,send=False):
  if self.closed or stop.is_set():fail('DM_CANCELLED','私信操作已停止，未开始的消息不会发送',409)
  # Mirror original ReplyDelivery's lock order: adapter spawn holds lifecycle
  # lock, so its late authority check must never wait for Core in reverse order.
  if not self.core.lock.acquire(blocking=not self.core.adapters.lifecycle_lock.locked()):raise AdapterBusy('账号正在变更，本次尚未启动私信命令')
  try:
   user,profile=refresh();store=profile.get('_workbench_store_id',profile.get('store_id'))
   if store!=scope['storeId'] or user['id']!=scope['userId'] or user['username']!=scope['owner']:fail('DM_AUTH_CHANGED','当前员工或门店已变化，私信操作已停止',403)
   account=self._account(user,store,scope['accountId'])
   if any(account.get(k)!=v for k,v in account_snapshot.items()):fail('DM_ACCOUNT_CHANGED','账号身份或固定窗口已变化，请重新核对',409)
   if account['platform']!='douyin':fail('DM_PLATFORM_UNAVAILABLE','小红书暂无已核验的 Windows 私信传输，可保留草稿',422)
   if any(l.get('accountId')==account['id'] and l.get('state')=='stop_pending' and owner!='dm-stop:'+l['id'] for l in self.core.store.list(LISTENERS,user['tenant_id'])):fail('DM_STOP_UNCONFIRMED','原监听停止回执待核对，请先核对原停止操作',409)
   if send:
    current_queue=self.core.store.get(QUEUES,owner.removeprefix('dm-queue:')) or {};own_ids={i['draftId'] for i in current_queue.get('items',[])}
    if any(d.get('accountId')==account['id'] and (d.get('state')=='unknown' or d.get('state')=='sending' and d['id'] not in own_ids) for d in self.core.store.list(DRAFTS,user['tenant_id'])):fail('DM_RESULT_UNCONFIRMED','本账号原私信结果待核对，后续发送保持暂停；不会换编号重发',409)
   if self.runtime is None:fail('DM_RUNTIME_UNAVAILABLE','私信后台尚未接入',503)
   self.runtime.dm_guard(user,account['id'],for_send=send)
   self.core.acquire_account_mode(account['id'],user['tenant_id'],mode,owner)
   return user,account
  finally:self.core.lock.release()
 def _wire(self,refresh,user,store,account,operation,request,stop,owner,*,target_guard=None,**values):
  scope=self._scope(user,store,account);snap={k:account.get(k) for k in ('platform','platform_uid','conn_id','cloud_owner','store_id','status')}
  def guard():
   fresh,current=self._boundary(refresh,scope,snap,'replies' if operation=='send' else 'collection',owner,stop,send=operation=='send')
   if target_guard is not None:target_guard(fresh,current)
  guard();directory=self.core.store.directory/'accounts'/user['tenant_id']/account['id']
  return self.core.adapters.direct_messages(account,operation,request,directory,guard=guard,**values)
 def _public(self,row):return deepcopy({k:v for k,v in row.items() if k not in ('tenant_id','owner','userId','signature','connection')})
 def _draft_view(self,row):
  # Store snapshots can precede worker completion. Re-read after the worker's
  # final commit before projecting an orphaned request as unknown.
  if row.get('state')=='sending':row=self.core.store.get(DRAFTS,row['id']) or row
  value=self._public(row)
  if row.get('state')=='sending' and not any(q['id'] in self.workers and any(i['draftId']==row['id'] for i in q['items']) for q in self.core.store.list(QUEUES,row['tenant_id'])):value.update(state='unknown',lastMessage='程序已重开，原发送结果待核对，不会自动重发')
  return value
 def _page(self,rows,cursor,limit):
  if type(limit) is not int or not 1<=limit<=50:fail('DM_PAGE_INVALID','每页可读取1至50条记录')
  rows=sorted(rows,key=lambda r:(r['createdAt'],r['id']),reverse=True);fingerprint=digest([r['id'] for r in rows]);index=0
  if cursor:
   try:
    value=json.loads(base64.urlsafe_b64decode(cursor.encode()));assert set(value)=={'digest','after'} and value['digest']==fingerprint;index=next(i+1 for i,r in enumerate(rows) if r['id']==value['after'])
   except Exception:fail('DM_PAGE_CHANGED','会话记录已更新，请从第一页重新读取',409)
  selected=rows[index:index+limit];more=index+limit<len(rows)
  next_cursor=base64.urlsafe_b64encode(json.dumps({'digest':fingerprint,'after':selected[-1]['id']}).encode()).decode() if more else ''
  return {'items':[self._public(r) for r in selected],'cursor':next_cursor,'hasMore':more,'total':len(rows)}
 def read(self,user,store,data):
  account=self._account(user,store,data['accountId']);scope=self._scope(user,store,account)
  matches=lambda r:all(r.get(k)==v for k,v in scope.items())
  conversations=[r for r in self.core.store.list(CONVERSATIONS,user['tenant_id']) if matches(r)]
  answer={'actor':{'username':user['username'],'storeId':store},'accountId':account['id'],'capabilities':{'platform':account['platform'],'historyAvailable':False,'historyMessage':'仅展示本软件明确监听后已保存的记录，不回拉平台历史。','sendVerified':False,'message':'抖音需本人账号、设备许可和私信传输核验；草稿不等于已发送。' if account['platform']=='douyin' else '小红书暂无许可与 Windows 传输均已核验的私信执行件，保留需求与草稿。'},'conversations':self._page(conversations,data.get('cursor',''),data.get('limit',20)),'drafts':[self._public(r) for r in self.core.store.list(DRAFTS,user['tenant_id']) if matches(r)],'queues':[self._queue_view(r) for r in self.core.store.list(QUEUES,user['tenant_id']) if matches(r)][-20:],'listeners':[self._listener_view(r) for r in self.core.store.list(LISTENERS,user['tenant_id']) if matches(r)][-10:]}
  try:
   manifest=self.core.adapters.manifest(account['platform'])
   ready=account['platform']=='douyin' and account.get('status')=='ready' and bool(account.get('conn_id')) and valid_uid(account.get('platform_uid')) and self.runtime is not None
   answer['capabilities'].update(canListen=ready,canSend=ready and manifest.get('dm_contract_verified') is True)
  except (ValueError,RuntimeError):answer['capabilities'].update(canListen=False,canSend=False)
  chronological=lambda rows:sorted(rows,key=lambda r:(r['createdAt'],r['id']))
  answer['drafts']=[self._draft_view(r) for r in chronological(self.core.store.list(DRAFTS,user['tenant_id'])) if matches(r)]
  answer['queues']=[self._queue_view(r) for r in chronological(self.core.store.list(QUEUES,user['tenant_id'])) if matches(r)][-20:]
  answer['listeners']=[self._listener_view(r) for r in chronological(self.core.store.list(LISTENERS,user['tenant_id'])) if matches(r)][-10:]
  if any(d['state']=='unknown' for d in answer['drafts']):answer['capabilities'].update(canSend=False,message='本账号原私信结果待核对；可以读取和保存草稿，后续发送保持暂停。')
  if any(l['state']=='stop_pending' for l in answer['listeners']):answer['capabilities'].update(canListen=False,canSend=False,message='原监听停止回执待核对，请先核对原停止操作。')
  if data.get('conversationId'):
   conv=self._owned(CONVERSATIONS,data['conversationId'],user,store,account)
   answer['conversation']=self._public(conv);answer['messages']=self._page([r for r in self.core.store.list(MESSAGES,user['tenant_id']) if matches(r) and r['conversationId']==conv['id']],data.get('messageCursor',''),data.get('limit',20))
  return answer
 def _queue_view(self,row):
  if row.get('state')=='running' and row['id'] not in self.workers:row=self.core.store.get(QUEUES,row['id']) or row
  value=self._public(row)
  if value['state']=='running' and row['id'] not in self.workers:value.update(state='unknown',message='程序已重开，原发送结果待核对，不会自动续发')
  return value
 def _listener_view(self,row):
  if row.get('state') in ('listening','stopping') and row['id'] not in self.workers:row=self.core.store.get(LISTENERS,row['id']) or row
  value=self._public(row)
  if value['state'] in ('listening','stopping') and row['id'] not in self.workers:value.update(state='stopped' if value['state']=='stopping' else 'interrupted',message='监听已结束或程序已重开，不会自动继续')
  return value
 def _launch(self,ident,fn):
  with self.lock:
   if self.closed:fail('DM_CLOSED','私信后台已关闭',503)
   if ident in self.workers:return
   self.stops[ident]=threading.Event()
   def run():
    try:fn(self.stops[ident])
    finally:
     with self.lock:self.workers.pop(ident,None);self.stops.pop(ident,None)
   worker=threading.Thread(target=run,daemon=True,name='scoped-dm-once');self.workers[ident]=worker;worker.start()
 def _listen(self,row,user,account,refresh,stop):
  owner='dm-listen:'+row['id'];leased=False
  try:
   self.core.acquire_account_mode(account['id'],user['tenant_id'],'collection',owner);leased=True
   result=self._wire(refresh,user,row['storeId'],account,'listen',row['requestId'],stop,owner,timeout_ms=row['timeoutMs'])
   self._boundary(refresh,self._scope(user,row['storeId'],account),{k:account.get(k) for k in ('platform','platform_uid','conn_id','cloud_owner','store_id','status')},'collection',owner,stop)
   if result.get('contract')!=CONTRACT or result.get('state')!='received' or result.get('history_available') is not False or result.get('account_uid')!=account.get('platform_uid') or result.get('request_id')!=row['requestId'] or not isinstance(result.get('messages'),list) or len(result['messages'])>1000:fail('DM_RECEIPT_INVALID','私信读取回执不明确，保留原请求待核对',409)
   imported=0
   with self.core.store.connect() as db:
    db.execute('BEGIN IMMEDIATE')
    for msg in result['messages']:
     if (set(msg)!={'message_id','conversation_id','sender_uid','recipient_uid','text','direction','observed_at','platform_sent_at'} or any(not valid_uid(msg[k]) for k in ('message_id','sender_uid','recipient_uid')) or msg['recipient_uid']!=account['platform_uid'] or msg['sender_uid']==account['platform_uid'] or msg['direction']!='inbound' or msg['platform_sent_at'] is not None or not isinstance(msg['observed_at'],str) or len(msg['observed_at'])>80 or not isinstance(msg['text'],str) or len(msg['text'])>10000):fail('DM_MESSAGE_UNVERIFIED','私信来源身份或稳定消息编号未通过核对',409)
     ids=str(msg['conversation_id']).split(':')
     if len(ids)!=4 or ids[:2]!=['0','1'] or sorted(ids[2:])!=sorted([msg['sender_uid'],msg['recipient_uid']]):fail('DM_CONVERSATION_UNVERIFIED','私信会话参与者不明确',409)
     scope=self._scope(user,row['storeId'],account);cid=digest([scope,msg['conversation_id']]);mid=digest([scope,msg['message_id']])
     old=self._db_get(db,MESSAGES,mid)
     if old:
      if any(old[k]!=msg[v] for k,v in [('platformMessageId','message_id'),('platformConversationId','conversation_id'),('text','text'),('senderUid','sender_uid')]):fail('DM_MESSAGE_CHANGED','同一平台私信编号内容已变化，旧记录保留待核对',409)
      continue
     conversation=self._db_get(db,CONVERSATIONS,cid) or {'id':cid,**scope,'createdAt':stamp(),'platformConversationId':msg['conversation_id'],'recipientUid':msg['sender_uid'],'accountUid':account['platform_uid']}
     conversation.update(updatedAt=stamp(),lastMessagePreview=msg['text'][:100]);self._db_put(db,CONVERSATIONS,conversation)
     self._db_put(db,MESSAGES,{'id':mid,**scope,'createdAt':stamp(),'conversationId':cid,'platformConversationId':msg['conversation_id'],'platformMessageId':msg['message_id'],'senderUid':msg['sender_uid'],'text':msg['text'],'direction':'inbound','observedAt':msg['observed_at'],'platformSentAt':None,'sourceRequestId':row['requestId']});imported+=1
    current=self._db_get(db,LISTENERS,row['id']);current.update(state='stopped' if stop.is_set() else 'completed',imported=imported,message='本次监听已结束；仅保存已核对的新消息',updatedAt=stamp());self._db_put(db,LISTENERS,current)
  except Exception as error:
   current=self.core.store.get(LISTENERS,row['id']);current.update(state='stopped' if stop.is_set() else 'blocked',message=str(error),updatedAt=stamp());self.core.store.put(LISTENERS,current)
  finally:
   if leased:self.core.release_account_mode(account['id'],user['tenant_id'],owner)
 def _send(self,queue,user,account,refresh,stop):
  owner='dm-queue:'+queue['id'];leased=False
  try:
   self.core.acquire_account_mode(account['id'],user['tenant_id'],'replies',owner);leased=True
   for item in queue['items']:
    current=self.core.store.get(QUEUES,queue['id'])
    if stop.is_set() or current['state']!='running':return
    fresh,profile=refresh();draft=self._owned(DRAFTS,item['draftId'],fresh,queue['storeId'],account);self._source_current(fresh,queue['storeId'],account,draft)
    if draft.get('reviewSnapshot')!=item['snapshot'] or self._snapshot(account,draft)!=item['snapshot']:fail('DM_REVIEW_CHANGED','私信正文、来源或发送账号已变化，旧核对失效',409)
    self.core._validate_reply_text(draft['text']);self.core._employee_quota(fresh,user['tenant_id'])
    self._boundary(refresh,self._scope(user,queue['storeId'],account),{k:account.get(k) for k in ('platform','platform_uid','conn_id','cloud_owner','store_id','status')},'replies',owner,stop,send=True)
    claim,reason=self.delivery._customer_claim(user['tenant_id'],{'platform':account['platform'],'author_id':draft['source']['recipientUid']},{'id':draft['id']},account['id'])
    if reason:fail('DM_RECIPIENT_ALREADY_CONTACTED',reason,409)
    request=digest([queue['requestId'],draft['id'],draft['version']]);attempted=False
    try:
     with self.core.store.connect() as db:
      db.execute('BEGIN IMMEDIATE');d=self._db_get(db,DRAFTS,draft['id']);q=self._db_get(db,QUEUES,queue['id'])
      if d.get('state')!='reviewed' or q['state']!='running' or d.get('reviewSnapshot')!=item['snapshot']:fail('DM_REVIEW_CHANGED','原草稿或队列已变化，本条未发送',409)
      # Serialize DM reservations against other DM accounts on the original
      # records transaction; count original comments in the same daily budget.
      today=datetime.now().date().isoformat();employee_used=account_used=0
      for entry in db.execute('SELECT entity,body FROM records WHERE tenant_id=? AND entity IN (?,?)',(user['tenant_id'],'replies',DRAFTS)):
       history=json.loads(entry['body']);state=history.get('status') if entry['entity']=='replies' else history.get('state')
       if state not in ('sending','sent','unknown') or not str(history.get('attempted_at') or history.get('sent_at','')).startswith(today):continue
       if history.get('sent_by',history.get('attempted_by'))==fresh['id']:employee_used+=1
       if history.get('account_id')==account['id']:account_used+=1
      config=self.core._company(user['tenant_id']).get('defaultRules',{});employee_limit=int(fresh.get('daily_send_limit') or config.get('employeeDailyReplyLimit') or 10)
      if employee_used>=employee_limit or account_used>=int(account.get('daily_send_limit') or 20):fail('DM_DAILY_LIMIT','当前员工或账号的今日联络额度已用完，草稿保留',409)
      from core.engine import now
      d.update(state='sending',sendRequestId=request,attemptedAt=stamp(),attempted_at=now(),attempted_by=fresh['id'],account_id=account['id']);self._db_put(db,DRAFTS,d)
      for v in q['items']:
       if v['draftId']==d['id']:v.update(state='sending',requestId=request)
      self._db_put(db,QUEUES,q);attempted=True
     def target_guard(fresh,current_account):
      current_draft=self._owned(DRAFTS,draft['id'],fresh,queue['storeId'],current_account)
      self._source_current(fresh,queue['storeId'],current_account,current_draft)
      current_queue=self._owned(QUEUES,queue['id'],fresh,queue['storeId'],current_account)
      if current_draft['state']!='sending' or current_draft.get('sendRequestId')!=request or self._snapshot(current_account,current_draft)!=item['snapshot'] or current_queue['state']!='running':fail('DM_REVIEW_CHANGED','原收件人、正文、账号或发送队列已变化，本条已停止',409)
     result=self._wire(refresh,user,queue['storeId'],account,'send',request,stop,owner,target_guard=target_guard,recipient=draft['source']['recipientUid'],text=draft['text'])
     success=(result.get('contract')==CONTRACT and result.get('state')=='sent' and result.get('request_id')==request and result.get('client_message_id')==request and result.get('account_uid')==account['platform_uid'] and result.get('recipient_uid')==draft['source']['recipientUid'] and valid_uid(result.get('message_id')) and valid_conversation(result.get('conversation_id'),account['platform_uid'],draft['source']['recipientUid']))
     if not success:raise ValueError('发送结果未知，请只核对原请求，不会自动重发')
     state='sent';message='平台返回明确发出回执；不代表对方已读';receipt={k:result[k] for k in ('message_id','conversation_id','client_message_id')}
    except Exception as error:
     state='unknown' if attempted else 'reviewed';message=str(error);receipt={}
    with self.core.store.connect() as db:
     db.execute('BEGIN IMMEDIATE');d=self._db_get(db,DRAFTS,draft['id']);d.update(state=state,lastMessage=message,receipt=receipt,updatedAt=stamp());self._db_put(db,DRAFTS,d)
     c=self._db_get(db,'ui_customer_reply_guard_v1',claim['id'])
     if c and c.get('reservation')==claim['reservation']:c.update(state='sent' if state=='sent' else 'unknown' if attempted else 'released',updated_at=stamp());self._db_put(db,'ui_customer_reply_guard_v1',c)
     q=self._db_get(db,QUEUES,queue['id'])
     for v in q['items']:
      if v['draftId']==draft['id']:v.update(state=state,message=message,receipt=receipt)
     if state!='sent':q.update(state='unknown' if attempted else 'blocked',message=message)
     else:
      # A strict outgoing receipt is also a real local conversation entry. Do
      # not invent platform timestamps, delivery/read status or missing history.
      scope=self._scope(user,queue['storeId'],account);cid=digest([scope,receipt['conversation_id']]);mid=digest([scope,receipt['message_id']]);old=self._db_get(db,MESSAGES,mid)
      if old and any(old.get(k)!=v for k,v in {'platformConversationId':receipt['conversation_id'],'text':draft['text'],'direction':'outbound','sourceRequestId':request}.items()):q.update(state='blocked',message='本条已有发出回执，但消息编号与已存记录冲突；原消息未覆盖，后续暂停')
      elif not old:
       at=stamp();conversation=self._db_get(db,CONVERSATIONS,cid) or {'id':cid,**scope,'createdAt':at,'platformConversationId':receipt['conversation_id'],'recipientUid':draft['source']['recipientUid'],'accountUid':account['platform_uid']}
       conversation.update(updatedAt=at,lastMessagePreview=draft['text'][:100]);self._db_put(db,CONVERSATIONS,conversation)
       self._db_put(db,MESSAGES,{'id':mid,**scope,'createdAt':at,'conversationId':cid,'platformConversationId':receipt['conversation_id'],'platformMessageId':receipt['message_id'],'senderUid':account['platform_uid'],'text':draft['text'],'direction':'outbound','observedAt':at,'platformSentAt':None,'sourceRequestId':request,'receipt':receipt})
     self._db_put(db,QUEUES,q)
    if state!='sent':return
   q=self.core.store.get(QUEUES,queue['id'])
   if q['state']=='running':q.update(state='completed',message='所选队列已处理完成；发出不代表已读');self.core.store.put(QUEUES,q)
  except Exception as error:
   q=self.core.store.get(QUEUES,queue['id'])
   if q['state']=='running':q.update(state='blocked',message=str(error));self.core.store.put(QUEUES,q)
  finally:
   if leased:self.core.release_account_mode(account['id'],user['tenant_id'],owner)
 def execute(self,action,user,store,data,refresh):
  if not isinstance(data,dict) or data.get('storeId')!=store:fail('DM_INPUT_INVALID','请重新选择当前门店')
  try:require_reply_permission(self.core,user)
  except ValueError:fail('DM_PERMISSION_FORBIDDEN','当前员工没有私信处理权限',403)
  allowed={'dm_workspace_read':{'storeId','accountId','cursor','messageCursor','conversationId','limit'},'dm_request_read':{'storeId','action','requestId'},'dm_listen_start':{'storeId','accountId','requestId','confirmed','timeoutMs'},'dm_listen_stop':{'storeId','id'},'dm_draft_save':{'storeId','accountId','id','expectedVersion','target','text','requestId'},'dm_draft_review':{'storeId','accountId','id','expectedVersion','confirmed','requestId'},'dm_queue_prepare':{'storeId','accountId','drafts','requestId'},'dm_queue_start':{'storeId','id','snapshotDigest','confirmed','requestId'},'dm_queue_cancel':{'storeId','id'},'dm_queue_read':{'storeId','id'}}[action]
  if set(data)-allowed:fail('DM_INPUT_INVALID','私信参数含未支持内容')
  if action=='dm_workspace_read':return self.read(user,store,data)
  if action=='dm_request_read':
   ident=digest([user['tenant_id'],user['id'],store,data.get('action'),data.get('requestId')]);record=self.core.store.get(REQUESTS,ident)
   if record is None:return {'state':'not_found'}
   value=record['result'];entity=LISTENERS if record['action']=='dm_listen_start' else QUEUES if record['action'] in ('dm_queue_prepare','dm_queue_start') else DRAFTS
   current=self._owned(entity,value['id'],user,store);self._account(user,store,current['accountId'])
   return self._listener_view(current) if entity==LISTENERS else self._queue_view(current) if entity==QUEUES else self._draft_view(current)
  if action in ('dm_queue_read','dm_queue_cancel','dm_queue_start','dm_listen_stop'):
   entity=LISTENERS if action=='dm_listen_stop' else QUEUES;row=self._owned(entity,data.get('id'),user,store);account=self._account(user,store,row['accountId'])
   if action=='dm_queue_read':return self._queue_view(row)
   if action in ('dm_queue_cancel','dm_listen_stop'):
    event=self.stops.get(row['id'])
    if event:event.set()
    stopped=False;stop_owner='dm-stop:'+row['id']
    if entity==LISTENERS and row['state'] in ('listening','stopping','stop_pending'):
     # The original adapter has one serial Bridge channel. Cancel only this
     # request's owned CLI waiter first, join its finally/release, then use the
     # same original atomic collection gate for the exact local socket close.
     # No transport/channel lock is bypassed and no other process is touched.
     self.core.adapters.cancel('dm:'+row['requestId'])
     worker=self.workers.get(row['id'])
     if worker:worker.join(2)
     try:
      if worker and worker.is_alive():raise ValueError('原监听进程仍在收尾')
      result=self._wire(refresh,user,store,account,'stop',row['requestId'],threading.Event(),stop_owner)
      stopped=result.get('state')=='stopped'
     except Exception:row['message']='停止回执待核对；原监听有独立的20秒上限，不会自动重连'
     finally:
      if stopped:self.core.release_account_mode(account['id'],user['tenant_id'],stop_owner)
    with self.core.store.connect() as db:
     db.execute('BEGIN IMMEDIATE');current=self._db_get(db,entity,row['id'])
     if entity==QUEUES and current['state'] in ('prepared','running'):current.update(state='cancelled',message='后续私信已取消；已发起的一条保留真实回执或未知状态')
     if entity==LISTENERS:current.update(state='stopped' if stopped or row['state'] not in ('listening','stopping','stop_pending') else 'stop_pending',message='本次监听已收到停止回执' if stopped else row.get('message','监听已结束'))
     current['updatedAt']=stamp();self._db_put(db,entity,current)
    return self._public(current)
   if data.get('confirmed') is not True or data.get('snapshotDigest')!=row['snapshotDigest']:fail('DM_CONFIRM_REQUIRED','请逐条核对收件人、正文与发送账号后明确确认',409)
   def begin(db):
    q=self._db_get(db,QUEUES,row['id'])
    if q['state']!='prepared':fail('DM_ALREADY_SUBMITTED','原队列已提交或结果待核对，不会重发',409)
    q.update(state='running',requestId=data['requestId'],updatedAt=stamp());self._db_put(db,QUEUES,q);return self._public(q)
   result,replayed=self._mutation(action,user,store,data,begin)
   if not replayed:self._launch(row['id'],lambda event:self._send({**row,'requestId':data['requestId']},user,account,refresh,event))
   return self._queue_view(self.core.store.get(QUEUES,row['id']))
  account=self._account(user,store,data.get('accountId'));scope=self._scope(user,store,account)
  if action=='dm_listen_start':
   if account['platform']!='douyin':fail('DM_PLATFORM_UNAVAILABLE','小红书私信传输尚未接通',422)
   if data.get('confirmed') is not True or type(data.get('timeoutMs')) is not int or not 100<=data['timeoutMs']<=20000:fail('DM_CONFIRM_REQUIRED','请明确确认本次最长20秒的私信监听')
   def start(db):
    row={'id':uuid.uuid4().hex,**scope,'createdAt':stamp(),'state':'listening','requestId':data['requestId'],'timeoutMs':data['timeoutMs'],'message':'仅监听本次新消息，不回拉历史'};self._db_put(db,LISTENERS,row);return self._public(row)
   result,replayed=self._mutation(action,user,store,data,start)
   if not replayed:
    row=self.core.store.get(LISTENERS,result['id']);self._launch(row['id'],lambda event:self._listen(row,user,account,refresh,event))
   return self._listener_view(self.core.store.get(LISTENERS,result['id']))
  if action=='dm_draft_save':
   text=data.get('text');version=data.get('expectedVersion')
   if type(text) is not str or not text.strip() or len(text)>1000 or type(version) is not int or version<0:fail('DM_DRAFT_INVALID','请填写1至1000字私信草稿并核对版本')
   source=self._source(user,store,account,data.get('target'));ident=data.get('id') or uuid.uuid4().hex
   def save(db):
    old=self._db_get(db,DRAFTS,ident)
    if old:
     if any(old.get(k)!=v for k,v in scope.items()) or old['version']!=version:fail('DM_DRAFT_CHANGED','草稿版本或归属已变化',409)
     if old['state'] in ('sending','sent','unknown'):fail('DM_SEND_UNCONFIRMED','原私信已发送或结果待核对，不能覆盖或换编号重发',409)
    elif version!=0:fail('DM_DRAFT_CHANGED','草稿版本已变化',409)
    row={'id':ident,**scope,'createdAt':old['createdAt'] if old else stamp(),'updatedAt':stamp(),'version':version+1,'state':'draft','source':source,'text':text.strip()};self._db_put(db,DRAFTS,row);return self._public(row)
   return self._mutation(action,user,store,data,save)[0]
  if action=='dm_draft_review':
   draft=self._owned(DRAFTS,data.get('id'),user,store,account);self._source_current(user,store,account,draft)
   self.core._validate_reply_text(draft['text'])
   if data.get('confirmed') is not True:fail('DM_CONFIRM_REQUIRED','请本人逐条核对收件人、正文与账号')
   def review(db):
    row=self._db_get(db,DRAFTS,draft['id'])
    if row['version']!=data.get('expectedVersion') or row['state'] not in ('draft','reviewed'):fail('DM_DRAFT_CHANGED','草稿已变化或原发送待核对',409)
    row.update(state='reviewed',reviewSnapshot=self._snapshot(account,row),reviewedAt=stamp());self._db_put(db,DRAFTS,row);return self._public(row)
   return self._mutation(action,user,store,data,review)[0]
  if action=='dm_queue_prepare':
   values=data.get('drafts')
   if not isinstance(values,list) or not 1<=len(values)<=20 or len({v.get('id') for v in values if isinstance(v,dict)})!=len(values):fail('DM_QUEUE_INVALID','每次请选择1至20条不同的本人已核对草稿')
   items=[]
   for value in values:
    if set(value)!={'id','version'}:fail('DM_QUEUE_INVALID','请核对所选草稿版本')
    draft=self._owned(DRAFTS,value['id'],user,store,account);self._source_current(user,store,account,draft);snap=self._snapshot(account,draft)
    if draft['version']!=value['version'] or draft['state']!='reviewed' or draft.get('reviewSnapshot')!=snap:fail('DM_REVIEW_REQUIRED','所选草稿、收件人或账号已变化，请逐条重新核对',409)
    items.append({'draftId':draft['id'],'snapshot':snap,'state':'pending'})
   if len({v['snapshot']['source']['recipientUid'] for v in items})!=len(items):fail('DM_RECIPIENT_DUPLICATE','同一收件人本批只能选择一条私信',409)
   def prepare(db):
    row={'id':uuid.uuid4().hex,**scope,'createdAt':stamp(),'state':'prepared','items':items,'prepareRequestId':data['requestId']};row['snapshotDigest']=digest(row);self._db_put(db,QUEUES,row);return self._public(row)
   return self._mutation(action,user,store,data,prepare)[0]
  fail('DM_ACTION_INVALID','私信操作尚未开放',403)
