"""Bounded own successor; no writes to the sealed predecessor or F82."""
from pathlib import Path
import ast, hashlib, json
W=Path(__file__).resolve().parent
PRE=W.parent/'customer-read-purpose-after-f82-candidate'
P=W.parents[2]
F=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v82/project'
S=W/'source-candidate'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(PRE/'FINAL-RECEIPT.json')=='b0d839d70ea5276566ecc484c565c907715450dba23993b386b1cf4bdd376f52'
origins=[]
def write(rel,origin,text):
    path=S/rel
    assert not path.exists()
    ast.parse(text)
    path.parent.mkdir(parents=True,exist_ok=True);path.write_text(text,'utf-8')
    origins.append({'path':rel,'beforeOrigin':str(origin),'beforeSha256':sha(origin),'afterSha256':sha(path)})
rel='work/shared-backend-integration/customer_read_distribution.py'
origin=PRE/'source-candidate'/rel
t=origin.read_text('utf-8')
t=t.replace("_PURPOSES = frozenset(('douyin_owned_connection', 'douyin_owned_video_comments'))",
    "_PURPOSES = frozenset(('douyin_owned_connection', 'douyin_owned_video_comments',\n    'douyin_owned_keyword_search_page'))")
needle='_TOKEN = object()'
assert t.count(needle)==1
t=t.replace(needle,"""_SEARCH_LIMITS = {'first_page_only': True, 'max_items': 20, 'offset': 0,
    'search': True, 'comments': False, 'reply': False, 'dm': False,
    'platform_identity_before_after': True, 'real_platform_verified': False,
    'production_approval': False, 'distribution_approval': False}
"""+needle)
t=t.replace("not 1 <= len(index['reviews']) <= 3", "not 1 <= len(index['reviews']) <= len(_PURPOSES) + 1")
t=t.replace("expected = _CONNECTION_LIMITS if purpose == 'douyin_owned_connection' else _COMMENT_LIMITS",
    "expected = (_CONNECTION_LIMITS if purpose == 'douyin_owned_connection' else\n                _SEARCH_LIMITS if purpose == 'douyin_owned_keyword_search_page' else _COMMENT_LIMITS)")
needle="            required |= {(item['root'], item['path']) for item in ("
assert t.count(needle)==1
t=t.replace(needle,"""            if purpose == 'douyin_owned_keyword_search_page':
                required |= {('source', name) for name in (
                    'core/douyin_search_policy.py', 'core/douyin_owned_search.py',
                    'core/douyin_owned_comments.py', 'core/platform_reads.py',
                    'core/adapters.py', 'assistant/product_workspace.py', 'bridge.py')}
                required |= {('douyin_runtime', name) for name in (
                    'cli.js', 'lib/commands/search.js', 'lib/commands/index.js',
                    'lib/client/bridge-client.js', 'lib/server/router.js', 'lib/server/registry.js',
                    'scripts/douyin.user.js')}
"""+needle)
write(rel,origin,t)
rel='work/ui-runtime-r55/src/core/douyin_search_policy.py';origin=F/rel;t=origin.read_text('utf-8')
t=t.replace('A trusted source-only purpose for one own keyword search page, pending by default.',
    'One fixed own search page; separately reviewed internal or host-bound customer purpose.')
needle="        server=self._server\n        if (getattr(sys,'frozen',False) or not server.employee_workspace_mode"
assert t.count(needle)==1
t=t.replace(needle,"""        server=self._server
        customer=getattr(server,'_customer_distribution_purpose',lambda purpose:None)(_PURPOSE)
        scope='customer_distribution_read' if customer is not None else 'internal_self_use_read'
        if ((getattr(sys,'frozen',False) and customer is None) or not server.employee_workspace_mode""")
t=t.replace("server._runtime_license_usage_scope('internal_self_use_read')!='internal_self_use_read'",
    "server._runtime_license_usage_scope(scope)!=scope")
t=t.replace("'scope':'internal_self_use_read','executable'", "'scope':scope,'executable'")
needle='    def current_review(self):\n'
assert t.count(needle)==1
t=t.replace(needle,needle+"""        customer=getattr(self._server,'_customer_distribution_purpose',lambda purpose:None)(_PURPOSE)
        if customer is not None:
            self._snapshot()
            return customer['revision']
""")
needle='    def resolve(self):\n'
assert t.count(needle)==1
t=t.replace(needle,needle+"""        customer=getattr(self._server,'_customer_distribution_purpose',lambda purpose:None)(_PURPOSE)
        if customer is not None:
            try:
                snapshot=self._snapshot()
                return {'purpose':_PURPOSE,'revision':_digest([customer['revision'],snapshot])}
            except (ValueError,TypeError,KeyError,OSError):return None
""")
write(rel,origin,t)
(W/'BEFORE-ORIGINS.json').write_text(json.dumps(origins,ensure_ascii=False,indent=2),'utf-8')
print(json.dumps({'sourceFiles':len(origins),'predecessorFinal':sha(PRE/'FINAL-RECEIPT.json')}))
