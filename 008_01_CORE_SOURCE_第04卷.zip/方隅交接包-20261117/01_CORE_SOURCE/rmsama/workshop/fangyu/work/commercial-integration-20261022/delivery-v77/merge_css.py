from pathlib import Path
import hashlib,json,shutil
from datetime import datetime,timezone
D=Path(__file__).resolve().parent;W=D.parent;P=W.parents[1]
S=P/'work/parallel-integration-20261018/final-integration/stage-02/project'
C=W/'acquisition-status-text-size-candidate'
I=W/'acquisition-status-text-size-independent-review/FINAL-RECEIPT.json'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(I)=='6aa6f0ec40293ffa29c24cada30cfa912fab4127a6dd246a3ed2384f0f100141'
pins=json.loads((C/'SOURCE-PINS.json').read_text('utf-8'))['files'];assert len(pins)==1
item=pins[0];src=C/'candidate'/item['path'];target=S/item['path'];backup=D/'source-before'/item['path']
assert sha(target)==item['beforeSha256']=='cfff34085c0744a1cf4e5ff580f961b63890a09d70771d53bced2536da362c93'
assert sha(src)==item['afterSha256']=='6cc9e1b7fe964db1b32eb04d4321f727dae4f325974aa5b81c8f3c85718a6e83'
assert not backup.exists() and not (D/'MERGE-CSS.json').exists()
backup.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(target,backup)
target.write_bytes(src.read_bytes());assert sha(target)==item['afterSha256']
(D/'MERGE-CSS.json').write_text(json.dumps({'status':'ROOT_MERGED_ONE_CSS_FONT_DECLARATION','atUtc':datetime.now(timezone.utc).isoformat(),'independentReceiptSha256':sha(I),'files':pins,'canonicalWritten':False,'f76Written':False},indent=2)+'\n',encoding='utf-8')
print('MERGED_ONE_CSS_DECLARATION_OFFLINE_ONLY')
