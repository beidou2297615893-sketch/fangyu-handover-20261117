"""Real pinned Native factory/Core/Store/HTTP; directory/model boundaries synthetic."""
from pathlib import Path
from copy import deepcopy
import hashlib,http.client,importlib.util,json,os,sys,threading,time,uuid
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=W.parents[2];RED='--baseline-red' in sys.argv;S=Path('C:\\积木软件工坊\\项目\\方隅公寓客户版\\work\\parallel-integration-20261018\\final-integration\\candidate-unified-v82\\project');stage=json.loads((W/'F82-STAGED.json').read_text('utf-8-sig'));R=Path(stage['release']);OUT=W/(('red-manual81-' if RED else 'experience-factory-')+uuid.uuid4().hex);OUT.mkdir();blocked=[];events=[];results=[]
def save(name,v):(OUT/name).write_text(json.dumps(v,ensure_ascii=False,indent=2,default=str),'utf-8')
def audit(event,args):
 if event in ('subprocess.Popen','os.system','os.startfile','os.posix_spawn'):blocked.append(event);raise RuntimeError('No process')
 if event in ('socket.connect','socket.bind') and (not isinstance(args[1],tuple) or args[1][0] not in ('127.0.0.1','::1')):blocked.append(event);raise RuntimeError('No external socket')
 if event=='socket.getaddrinfo' and args[0] not in ('127.0.0.1','::1','localhost',None):blocked.append(event);raise RuntimeError('No external DNS')
 if event=='sqlite3.connect' and not Path(args[0]).resolve().is_relative_to(W):blocked.append(event);raise RuntimeError('Own DB only')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  path=Path(os.fsdecode(args[0])).absolute();mode,flags=args[1] or '',args[2] or 0
  if (any(c in str(mode) for c in 'wax+') or isinstance(flags,int) and flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC)) and not path.is_relative_to(W):blocked.append(event);raise RuntimeError('Own writes only')
sys.addaudithook(audit)
def load(name,path):
 m=importlib.util.module_from_spec(importlib.util.spec_from_loader(name,loader=None));m.__file__=str(path);sys.modules[name]=m;exec(compile(path.read_bytes(),str(path),'exec'),m.__dict__);return m
fixture=load('guided_original_identity_fixture',P/'work/acquisition-core-repair-20261018/gui-fixture/base_fixture.py');cloud=fixture.CloudStandin(json.loads((P/'work/central-store-config/compiled-fixture.json').read_text('utf-8-sig')));company=json.loads((S/'work/app/company.json').read_text('utf-8-sig'))
def transport(*args,**kwargs):
 value=cloud(*args,**kwargs);value['environment_id']=company['managedWorkspace']['environment_id'];return value
integration=load('integrations',R/'resources/platform-runtime/vendor-src/integrations.py');integration.request_json=transport
host=load('guided_actual_native_host',R/'ui_native_host.py');_,files=host.verify_release(R,stage['manifest_sha256']);host.verify_backend_dependencies(R,files,S)
class Model:
 def __init__(self):self.generations=[];self.statuses=[]
 def __call__(self,envelope):
  self.generations.append(deepcopy(envelope))
  if envelope['method']['id']=='learning':return {'state':'succeeded','requestId':envelope['requestId'],'output':{'summary':'合成复盘建议，效果未验证','facts':[],'hypotheses':['先核对通勤问题可能有助于沟通，尚未验证。'],'artifact':{'lessons':[{'observation':'合成访谈里反复出现通勤问题，未统计效果。','proposedRule':'下次先核对通勤条件再介绍内容，仅作待核参考。','evidenceIds':[]}],'nextTests':['在相同条件下核对少量授权样本，不自动执行。']}}}
  return {'state':'unknown','requestId':envelope['requestId']}
 def status(self,envelope):
  self.statuses.append(deepcopy(envelope));return {'state':'succeeded','requestId':envelope['requestId'],'output':{'summary':'合成定位候选，仅核原结构化合同','facts':[],'hypotheses':['访谈中的预算和房源信息仍需核实，不作为门店现价。'],'artifact':{'name':'合成门店内容账号','positioning':'帮助租房者核对入住需求的候选定位','audience':'待验证的通勤租客','pillars':['通勤问题','入住准备'],'voice':['清楚','不夸大'],'avoid':['未经核实的价格承诺']}}}
model=Model();backend=None;server=None;worker=None;headers={};data_dir=OUT/'data';passed=False
def start():
 global backend,server,worker,origin
 backend=host.create_backend(R,files,project_root=S,data_dir=data_dir,company=company,content_model_adapter=model)
 server=host.StaticServer(R,files,backend=backend,cookie_name='guided_fixture_session');worker=threading.Thread(target=server.serve_forever,daemon=True);worker.start();origin='http://127.0.0.1:'+str(server.server_port)
def stop():
 global backend,server,worker
 if server:server.shutdown();worker.join(3);server.server_close();backend.close();server=None
def request(method,path,data=None,expected=200):
 conn=http.client.HTTPConnection('127.0.0.1',server.server_port,timeout=30);conn.request(method,path,json.dumps(data,ensure_ascii=False).encode() if data is not None else None,headers);resp=conn.getresponse();raw=resp.read();found=dict(resp.getheaders());status=resp.status;conn.close();body=json.loads(raw) if raw.startswith(b'{') else {'raw':raw.decode('utf-8')};logged=deepcopy(data)
 if logged and logged.get('action')=='login':logged['data']['password']='synthetic password omitted'
 events.append({'method':method,'path':path,'request':logged,'status':status,'body':body});save('HTTP.json',events);assert status==expected,(status,expected,body);return body,found
def action(name,data,expected=200):return request('POST','/api/workbench',{'action':name,'data':data},expected)[0]
def login(name='fixture-admin',selected=None):
 headers.clear();boot,_=request('GET','/api/workbench/bootstrap');headers.update({'Origin':origin,'Content-Type':'application/json','X-Fangyu-CSRF':boot['csrfToken']});logged,h=request('POST','/api/workbench',{'action':'login','data':{'username':name,'password':fixture.PASSWORD}});headers.update(Cookie=h['Set-Cookie'].split(';',1)[0]);headers['X-Fangyu-CSRF']=logged['csrfToken'];store=selected or cloud.first_store
 if logged['selection']['storeId']!=store:action('select_store',{'storeId':store,'expectedRevision':logged['selection']['revision']})
 return backend.core.session(headers['Cookie'].split('=',1)[1]),store
serial=0
def workspace():return action('content_workspace_read',base)['workspace']
def write(name,data,expected=200,key=None,revision=None):
 global serial
 serial+=1;return action(name,{**base,'expectedRevision':workspace()['revision'] if revision is None else revision,'requestId':key or 'guided-request-'+str(serial).zfill(8),**data},expected)
def ref(session):return {'sessionId':session['id'],'sessionVersion':session['version'],'sessionDigest':session['digest'],'stageId':catalog['stages'][session['stageIndex']]['id'],'expertId':session['expertId'],'expertDigest':session['expertDigest'],'answerIds':[a['id'] for a in session['answers']]}


def source_data(task,artifact):return {'operation':'create_from_learning','taskId':task['id'],'artifactId':artifact['id'],'outputDigest':artifact['outputDigest'],'title':'先核对通勤条件','text':'待核经验：下次先问通勤范围，再讨论介绍顺序；这是建议，并无已发生效果的证明。'}
def transition(item,operation,**extra):return {'operation':operation,'experienceId':item['id'],'version':item['version'],'digest':item['digest'],'humanConfirmed':True,**extra}
def reference(item):return {'experienceId':item['id'],'version':item['version'],'digest':item['digest']}
def task_in(reply,key):return next(t for t in reply['workspace']['workflow']['tasks'] if t['id']==key)
def protected():
 with backend.core.store.connect() as db:return [dict(r) for r in db.execute("SELECT entity,id,tenant_id,body FROM records WHERE entity IN ('leads','tasks','replies','ai_jobs','ai_attempts','rental_assessments','accounts') ORDER BY entity,id")]
try:
 start();user,store=login();account={'id':'experience-admin-a','tenant_id':user['tenant_id'],'cloud_owner':user['username'],'store_id':store,'platform':'xiaohongshu','status':'disconnected','name':'合成甲员工甲店账号'}
 backend.core.store.put('accounts',account);base={'storeId':store,'accountId':account['id'],'platform':'xiaohongshu'};before=protected()
 learning=write('content_task_prepare',{'methodId':'learning','query':'合成复盘建议而非效果证明','evidenceIds':[]})['result']['task'];learned=write('content_task_run',{'taskId':learning['id']},key='experience-learning-run-original')
 assert learned['result']['task']['state']=='succeeded' and len(model.generations)==1
 artifact=next(a for a in learned['workspace']['workflow']['artifacts'] if a['id']==learned['result']['artifactId']);data=source_data(learning,artifact)
 if not RED:write('content_experience_save',data,409)
 applied=write('content_task_apply',{'taskId':learning['id']});origin_snapshot=deepcopy({'task':task_in(applied,learning['id']),'artifact':next(a for a in applied['workspace']['workflow']['artifacts'] if a['id']==artifact['id']),'plans':applied['workspace']['workflow']['plans']})
 assert origin_snapshot['plans'][0]['executed'] is False
 candidate=write('content_experience_save',data)['result']['experience'];assert candidate['state']=='candidate' and candidate['version']==1 and candidate['source']['executed'] is False and candidate['source']['outputDigest']==artifact['outputDigest']
 write('content_task_prepare',{'methodId':'persona','query':'候选未采用不可引用','experienceReferences':[reference(candidate)]},409)
 write('content_experience_save',{**transition(candidate,'adopt'),'humanConfirmed':False},400)
 rev=workspace()['revision'];adopt_key='experience-adopt-original-key';payload=transition(candidate,'adopt');adopted=write('content_experience_save',payload,key=adopt_key,revision=rev)['result']['experience']
 assert adopted['state']=='active' and adopted['version']==2 and len(adopted['history'])==2
 assert write('content_experience_save',payload,key=adopt_key,revision=rev)['replayed'] is True
 conflict=write('content_experience_save',{**payload,'humanConfirmed':False},409,key=adopt_key,revision=rev);assert conflict['error']['code']=='CONTENT_REQUEST_CONFLICT'
 write('content_experience_save',transition(candidate,'adopt'),409)
 assert len(model.generations)==1 and not model.statuses and workspace()['persona']=={} and not workspace()['workflow']['documents'] and protected()==before
 results.append('Actual original learning run/apply retains executed=false proposal; explicit review creates hypothesis candidate, adoption v2 requires literal human confirmation/CAS; original key replays and changed input conflicts, zero automatic effect/fact/persona writes')
 none=write('content_task_prepare',{'methodId':'persona','query':'未勾选经验不引用'})
 assert not task_in(none,none['result']['task']['id']).get('experienceReferences') and not task_in(none,none['result']['task']['id'])['input']['evidence']
 selected={'methodId':'persona','query':'本次明确使用已采用经验','experienceReferences':[reference(adopted)]}
 prepared=write('content_task_prepare',selected);waiting=prepared['result']['task'];input_value=task_in(prepared,waiting['id'])['input']
 assert waiting['experienceReferences']==[reference(adopted)] and input_value['instructions']=='' and input_value['evidence'] and all(e['kind']=='hypothesis' for e in input_value['evidence'])
 assert any(adopted['text'] in e['text'] for e in input_value['evidence']) and any(artifact['outputDigest'] in e['sourceLabel'] and 'v2' in e['sourceLabel'] for e in input_value['evidence'])
 write('content_task_prepare',{**selected,'experienceReferences':[reference(adopted),reference(adopted)]},409)
 write('content_task_prepare',{**selected,'experienceReferences':[{**reference(adopted),'text':'任意新正文'}]},400)
 unknown_p=write('content_task_prepare',{**selected,'query':'原未知任务保冻结经验'});unknown_id=unknown_p['result']['task']['id'];original='experience-unknown-original-key'
 unknown=write('content_task_run',{'taskId':unknown_id},key=original);frozen=deepcopy(task_in(unknown,unknown_id));assert frozen['state']=='unknown' and len(model.generations)==2
 withdrawn=write('content_experience_save',transition(adopted,'withdraw',reason='合成证据不足，本人撤回'))['result']['experience']
 assert withdrawn['state']=='withdrawn' and withdrawn['version']==3 and withdrawn['history'][:2]==adopted['history']
 current=workspace();assert next(t for t in current['workflow']['tasks'] if t['id']==unknown_id)==frozen
 stopped=write('content_task_run',{'taskId':waiting['id']},409);assert stopped['error']['code']=='CONTENT_SOURCE_CHANGED' and len(model.generations)==2
 write('content_task_prepare',selected,409);write('content_task_reconcile',{'taskId':unknown_id},409,key='experience-wrong-unknown-key')
 status=write('content_task_reconcile',{'taskId':unknown_id},key=original);assert status['result']['task']['state']=='needs_revalidation' and status['result']['newGenerationDispatched'] is False
 assert len(model.generations)==2 and len(model.statuses)==1 and model.statuses[0]['requestId']==model.generations[1]['requestId'] and model.statuses[0]['inputDigest']==model.generations[1]['inputDigest'] and model.statuses[0]['input']==model.generations[1]['input']
 assert status['result']['task']['runRequestId']==original and next(a for a in status['workspace']['workflow']['artifacts'] if a['id']==status['result']['artifactId'])['state']=='candidate_stale'
 write('content_task_apply',{'taskId':unknown_id},409);write('content_task_run',{'taskId':unknown_id},409)
 results.append('Explicit selected exact version enters existing hypothesis-only evidence with original source digest, no system instruction edit; withdrawal blocks old prepared/new selections but preserves unknown frozen input/key; exact-key status once, zero redispatch, stale result cannot apply')
 reapproved=write('content_experience_save',transition(withdrawn,'adopt'))['result']['experience'];assert reapproved['version']==4 and reapproved['state']=='active'
 write('content_task_run',{'taskId':waiting['id']},409)
 new=write('content_task_prepare',{'methodId':'persona','query':'重新审阅后的新版本','experienceReferences':[reference(reapproved)]});assert new['result']['task']['experienceReferences'][0]['version']==4
 snapshot=deepcopy(workspace()['workflow']['experiences']);stop();start();login();assert workspace()['workflow']['experiences']==snapshot
 noww=workspace();assert next(t for t in noww['workflow']['tasks'] if t['id']==learning['id'])==origin_snapshot['task'] and next(a for a in noww['workflow']['artifacts'] if a['id']==artifact['id'])==origin_snapshot['artifact'] and noww['workflow']['plans']==origin_snapshot['plans']
 assert len(model.generations)==2 and not noww['workflow']['documents'] and noww['workflowCapabilities']['canExecutePlatforms'] is False and protected()==before
 results.append('Readopt creates explicit newer version without reviving old prepared references; backend reopen retains all four history versions and unchanged original learning task/artifact/plan; no implicit document/fact/system/platform change')
 other=next(x['id'] for x in cloud.manifest['stores'] if x['id']!=store)
 operator,_=login('fixture-operator');action('content_workspace_read',base,403);action('content_experience_save',{**base,'expectedRevision':0,'requestId':'cross-owner-experience-01',**transition(reapproved,'withdraw',reason='越权测试')},403)
 operator_account={**account,'id':'experience-operator-a','cloud_owner':operator['username']};backend.core.store.put('accounts',operator_account);base={'storeId':store,'accountId':operator_account['id'],'platform':'xiaohongshu'}
 assert workspace()['workflow']['experiences']==[];write('content_experience_save',data,409);write('content_task_prepare',selected,409);action('content_workspace_read',{**base,'storeId':other},403)
 login('fixture-admin',other);other_account={**account,'id':'experience-admin-b','store_id':other};backend.core.store.put('accounts',other_account);base={'storeId':other,'accountId':other_account['id'],'platform':'xiaohongshu'}
 assert workspace()['workflow']['experiences']==[];write('content_experience_save',data,409);write('content_task_prepare',selected,409);action('content_workspace_read',{**base,'accountId':account['id']},403)
 login();base={'storeId':store,'accountId':account['id'],'platform':'xiaohongshu'};assert workspace()['workflow']['experiences']==snapshot
 assert len(model.generations)==2 and len(model.statuses)==1 and not blocked
 results.append('Two original employee logins/two stores and distinct accounts cannot borrow another source/candidate/version; original ownership/store selection/authentication remains the only authority')
 # Independent adversarial probes at the same public Interface, not private state mutation.
 # Baseline follows the intentional synthetic two-employee/two-store account additions.
 protected_before_probes=protected()
 write('content_experience_save',{**data,'source':{'executed':True}},400)
 write('content_experience_save',{**transition(reapproved,'withdraw',reason='bad typed version'),'version':True},409)
 write('content_task_prepare',{'methodId':'persona','query':'bad typed reference','experienceReferences':[{**reference(reapproved),'version':True}]},409)
 twin=write('content_experience_save',data)['result']['experience']
 twin_active=write('content_experience_save',transition(twin,'adopt'))['result']['experience']
 same_text=write('content_task_prepare',{'methodId':'persona','query':'independent equal-text distinct-source test','experienceReferences':[reference(reapproved),reference(twin_active)]})
 t=task_in(same_text,same_text['result']['task']['id']);ev=t['input']['evidence']
 assert len(ev)==2 and ev[0]['text']==ev[1]['text'] and ev[0]['evidenceId']!=ev[1]['evidenceId'] and ev[0]['sourceLabel']!=ev[1]['sourceLabel']
 assert all(e['kind']=='hypothesis' for e in ev) and t['input']['instructions']=='' and len(model.generations)==2 and len(model.statuses)==1 and protected()==protected_before_probes
 results.append('Independent extra probes: caller cannot inject source/executed proof, bool versions rejected; equal-text experiences keep distinct exact source/version evidence IDs without merging or changing instructions/generation')
 save('RESULTS.json',{'status':'PASS','checks':results,'stage':stage,'actualOriginalFactory':True,'sameStore':True,'syntheticGenerationCalls':len(model.generations),'originalKeyStatusQueries':len(model.statuses),'realModelPlatformCalls':0,'productionAccess':False,'sourcePlansStillExecutedFalse':True,'noSystemInstructionsChanged':True,'nativeWindow':False,'independentAdditionalProbes':True});passed=True
finally:
 stop();save('MODEL-ENVELOPES.json',{'generations':model.generations,'statuses':model.statuses,'syntheticOnly':True});save('FINAL.json',{'status':'PASS' if passed else 'RED_CAPTURED','blocked':blocked,'eventCount':len(events),'modelCalls':len(model.generations),'statusCalls':len(model.statuses),'productionAccess':False});(W/('LATEST-RED.json' if RED else 'LATEST-EXPERIENCE.json')).write_text(json.dumps({'directory':str(OUT),'status':'PASS' if passed else 'RED_CAPTURED'},ensure_ascii=False,indent=2),'utf-8')
print(str(OUT)+' '+('PASS' if passed else 'RED'))
