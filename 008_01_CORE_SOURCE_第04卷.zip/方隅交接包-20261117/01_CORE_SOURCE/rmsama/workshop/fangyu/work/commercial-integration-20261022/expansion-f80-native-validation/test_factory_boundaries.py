"""Actual pinned QA-only Native factory/Core/Store/HTTP and real Windows APIs."""
from pathlib import Path
from copy import deepcopy
import base64,hashlib,http.client,importlib.util,io,json,os,sys,threading,time,traceback,uuid,wave
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=W.parents[2];S=Path('C:\\积木软件工坊\\项目\\方隅公寓客户版\\work\\parallel-integration-20261018\\final-integration\\candidate-unified-v80\\project');stage=json.loads((W/'QA-STAGE.json').read_text('utf-8'));R=Path(stage['release']);OUT=W/('http-'+uuid.uuid4().hex);OUT.mkdir();events=[];checks=[];blocked=[];processes=[]
def save(n,v):(OUT/n).write_text(json.dumps(v,ensure_ascii=False,indent=2),'utf-8')
def audit(event,args):
 if event=='subprocess.Popen':
  executable=Path(args[0]).resolve();assert executable==Path('C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe').resolve();assert '-File' in str(args[1]) and 'windows_media_bridge.ps1' in str(args[1]) and '-Command' not in str(args[1]) and '-EncodedCommand' not in str(args[1]);assert Path(args[2]).resolve().is_relative_to(OUT);processes.append({'executable':str(executable),'argv':str(args[1]),'cwd':str(args[2])})
 if event in ('os.system','os.startfile','os.posix_spawn'):blocked.append(event);raise RuntimeError('Forbidden process')
 if event in ('socket.connect','socket.bind') and (not isinstance(args[1],tuple) or args[1][0] not in ('127.0.0.1','::1')):blocked.append(event);raise RuntimeError('Loopback only')
 if event=='socket.getaddrinfo' and args[0] not in ('127.0.0.1','::1','localhost',None):blocked.append(event);raise RuntimeError('No external DNS')
 if event=='sqlite3.connect' and not Path(args[0]).resolve().is_relative_to(OUT):blocked.append(event);raise RuntimeError('Own DB only')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  if os.fsdecode(args[0]).lower()==os.devnull.lower():return
  path=Path(os.fsdecode(args[0])).absolute();mode,flags=args[1] or '',args[2] or 0
  if (any(c in str(mode) for c in 'wax+') or isinstance(flags,int) and flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC)) and not path.is_relative_to(W):blocked.append(event);raise RuntimeError('Own writes only')
sys.addaudithook(audit)
def load(name,path):
 m=importlib.util.module_from_spec(importlib.util.spec_from_loader(name,loader=None));m.__file__=str(path);sys.modules[name]=m;exec(compile(path.read_bytes(),str(path),'exec'),m.__dict__);return m
fixture=load('media_services_original_identity',P/'work/acquisition-core-repair-20261018/gui-fixture/base_fixture.py');cloud=fixture.CloudStandin(json.loads((P/'work/central-store-config/compiled-fixture.json').read_text('utf-8-sig')));company=json.loads((S/'work/app/company.json').read_text('utf-8-sig'))
def transport(*a,**k):v=cloud(*a,**k);v['environment_id']=company['managedWorkspace']['environment_id'];return v
integration=load('integrations',R/'resources/platform-runtime/vendor-src/integrations.py');integration.request_json=transport
host=load('media_services_actual_qa_host',R/'ui_native_host.py');_,files=host.verify_release(R,stage['manifest_sha256']);host.verify_backend_dependencies(R,files,S)
headers={};backend=None;server=None;worker=None;passed=False;serial=0
def start():
 global backend,server,worker,origin
 backend=host.create_backend(R,files,project_root=S,data_dir=OUT/'data',company=company)
 server=host.StaticServer(R,files,backend=backend,cookie_name='media_services_qa');worker=threading.Thread(target=server.serve_forever,daemon=True);worker.start();origin='http://127.0.0.1:'+str(server.server_port)
def stop():
 global server
 if server:server.shutdown();worker.join(3);server.server_close();backend.close();server=None
def request(method,path,data=None,expected=200):
 c=http.client.HTTPConnection('127.0.0.1',server.server_port,timeout=60);c.request(method,path,json.dumps(data,ensure_ascii=False).encode() if data is not None else None,headers);r=c.getresponse();raw=r.read();h=dict(r.getheaders());status=r.status;c.close();body=json.loads(raw);value=deepcopy(data)
 if value and value.get('action')=='login':value['data']['password']='synthetic omitted'
 if value:
  for key in ('dataBase64',):
   if key in value.get('data',{}):value['data'][key]='omitted synthetic bytes'
 recorded=deepcopy(body)
 if 'dataBase64' in recorded.get('result',{}):recorded['result']['dataBase64']='omitted synthetic bytes'
 if 'dataBase64' in recorded.get('result',{}).get('speechPreview',{}):recorded['result']['speechPreview']['dataBase64']='omitted synthetic bytes'
 events.append({'method':method,'path':path,'request':value,'status':status,'body':recorded});save('HTTP.json',events);assert status==expected,(status,expected,recorded);return body,h
def action(name,data,expected=200):return request('POST','/api/workbench',{'action':name,'data':data},expected)[0]
def login():
 headers.clear();boot,_=request('GET','/api/workbench/bootstrap');headers.update({'Origin':origin,'Content-Type':'application/json','X-Fangyu-CSRF':boot['csrfToken']});logged,h=action_headers= request('POST','/api/workbench',{'action':'login','data':{'username':'fixture-admin','password':fixture.PASSWORD}});headers['Cookie']=h['Set-Cookie'].split(';',1)[0];headers['X-Fangyu-CSRF']=logged['csrfToken']
 if logged['selection']['storeId']!=cloud.first_store:action('select_store',{'storeId':cloud.first_store,'expectedRevision':logged['selection']['revision']})
 return backend.core.session(headers['Cookie'].split('=',1)[1])
def workspace():return action('content_workspace_read',base)['workspace']
def records():
 with backend.core.store.connect() as db:return [dict(r) for r in db.execute('SELECT entity,id,tenant_id,body FROM records ORDER BY entity,id')]
def wait_speech(request_id):
 for _ in range(200):
  result=action('media_speech_read',{**base,'requestId':request_id})['result']
  if result['speechJob']['state']!='running':return result
  time.sleep(.1)
 raise AssertionError('Owned speech job timeout')
try:
 start();user=login();account={'id':'independent-media-account','tenant_id':user['tenant_id'],'cloud_owner':user['username'],'store_id':cloud.first_store,'platform':'xiaohongshu','status':'disconnected','name':'独立合成素材账号'}
 backend.core.store.put('accounts',account);backend.core.store.put('accounts',{**account,'id':'independent-media-foreign','cloud_owner':'other-employee'});backend.core.store.put('accounts',{**account,'id':'independent-media-second'})
 base={'storeId':cloud.first_store,'accountId':account['id'],'platform':'xiaohongshu'};initial=workspace();baseline=records();caps=action('media_services_status',base)['result']['capabilities'];voice=next(v for v in caps['voices'] if v['language']=='zh-CN')
 speech={'requestId':'independent-literal-speech-0001','text':'合成安全试听。<speak>$(New-Item injected.marker);</speak>','voiceId':voice['id'],'rate':0,'expectedRevision':initial['revision']}
 action('media_speech_preview',{**base,**speech});preview=wait_speech(speech['requestId'])['speechPreview'];audio=base64.b64decode(preview['dataBase64'])
 with wave.open(io.BytesIO(audio),'rb') as wav:
  frames=wav.readframes(wav.getnframes());assert wav.getnchannels()==1 and wav.getsampwidth()==2 and wav.getframerate()==16000 and len(frames)==wav.getnframes()*2 and any(frames)
 assert hashlib.sha256(audio).hexdigest()==preview['sha256'] and preview['literalTextOnly'] is True and records()==baseline
 assert not list(OUT.rglob('injected.marker')) and all('New-Item' not in p['argv'] and '<speak>' not in p['argv'] for p in processes)
 save_data={**base,'previewId':preview['id'],'previewDigest':preview['previewDigest'],'expectedRevision':initial['revision'],'requestId':'independent-save-original-key','name':'独立核对音频.wav','rightsConfirmed':False,'rightsNote':'本次合成文字与系统非克隆声音，明确核对后保存。'}
 action('media_speech_save',save_data,409);assert records()==baseline
 action('media_speech_save',{**save_data,'rightsConfirmed':True,'name':'../不可覆盖.wav'},409);assert records()==baseline
 saved=action('media_speech_save',{**save_data,'rightsConfirmed':True})['result'];asset=saved['asset'];assert asset['source']=='generated_concept' and asset['kind']=='audio'
 assert action('media_speech_save',{**save_data,'rightsConfirmed':True})['result']['replayed']
 action('media_speech_save',{**save_data,'rightsConfirmed':True,'rightsNote':'原key改内容'},409)
 assert action('media_services_status',{**base,'requestId':save_data['requestId']})['result']['original']['state']=='recorded'
 assert len(backend.core.store.list('content_media_assets_v1',user['tenant_id']))==1
 (OUT/'actual-owned.wav').write_bytes(audio)
 checks.append('Original factory fixed PS argv/stdin renders literal injection-looking text into real nonempty PCM WAV; preview zero records, rights/name guards, original ASSETS/key replay exactly once')
 # No caller can choose a read or output path. Invalid/budget inputs stop before PS.
 from PIL import Image
 image=Image.new('RGB',(4097,1),'white');buffer=io.BytesIO();image.save(buffer,format='PNG')
 before_processes=len(processes);before=records()
 for data in [{'filename':'C:/not-a-file.png','dataBase64':'YQ=='},{'filename':'a.png','dataBase64':'bad'},{'filename':'a.png','dataBase64':'YQ==','inputFile':'C:/not-a-file'},{'filename':'a.png','dataBase64':base64.b64encode(buffer.getvalue()).decode()}]:action('media_ocr_preview',{**base,**data},409)
 action('media_speech_preview',{**base,**speech,'requestId':'independent-client-output-file','outputFile':'C:/not-a-file'},409)
 action('media_speech_preview',{**base,**speech,'requestId':'independent-invalid-voice','voiceId':'x;New-Item injected.marker'},409)
 assert len(processes)==before_processes and records()==before
 checks.append('Client paths/output options/voice injection and malformed or over-dimension OCR are rejected before any process or asset write')
 before=records();before_processes=len(processes)
 for override in [{'accountId':'independent-media-foreign'},{'accountId':'independent-media-second'},{'storeId':'other-store'}]:action('media_speech_read',{**base,**override,'assetId':asset['id']},409)
 action('media_speech_save',{**save_data,'rightsConfirmed':True,'accountId':'independent-media-second','requestId':'independent-cross-account-save'},409)
 assert records()==before and len(processes)==before_processes
 action('content_persona_save',{**base,'expectedRevision':initial['revision'],'requestId':'independent-original-persona-change','persona':{'name':'合成人设','positioning':'仅合成内容版本更改'}})
 action('media_speech_save',{**save_data,'rightsConfirmed':True,'requestId':'independent-stale-source-save'},409)
 altered={**account,'platform_uid':'changed-own-stable-uid'};backend.core.store.put('accounts',altered)
 action('media_speech_read',{**base,'requestId':speech['requestId']},409);backend.core.store.put('accounts',account)
 path=backend.media_workbench.root/'assets'/asset['id'];original=path.read_bytes();assert original==audio
 path.write_bytes(original[:-2]+bytes([original[-2]^1,original[-1]]))
 try:action('media_speech_read',{**base,'assetId':asset['id']},409)
 finally:path.write_bytes(original)
 readback=action('media_speech_read',{**base,'assetId':asset['id']})['result'];assert base64.b64decode(readback['dataBase64'])==audio
 checks.append('Other owner/store/account cannot read/export/save; original workspace revision and account binding invalidate old preview; modified asset bytes fail original digest without exporting')
 # Real owned process stop, then actual factory reopen of only this data root.
 current=workspace();cancel_id='independent-real-speech-cancel';long={**speech,'requestId':cancel_id,'text':'这是可以停止的自有合成配音，不会播放到扬声器。'*10,'expectedRevision':current['revision']}
 action('media_speech_preview',{**base,**long});action('media_speech_cancel',{**base,'accountId':'independent-media-foreign','requestId':cancel_id},409)
 cancel=action('media_speech_cancel',{**base,'requestId':cancel_id})['result'];result=wait_speech(cancel_id)
 assert cancel['state']=='cancel_requested' and result['speechJob']['state']=='cancelled' and 'speechPreview' not in result,(cancel,result)
 assets_before=deepcopy(backend.core.store.list('content_media_assets_v1',user['tenant_id']));stop();start();login()
 reread=action('media_speech_read',{**base,'assetId':asset['id']})['result'];assert base64.b64decode(reread['dataBase64'])==audio and reread['speech']['text']==speech['text'] and reread['asset']['rightsNote']==save_data['rightsNote']
 assert backend.core.store.list('content_media_assets_v1',user['tenant_id'])==assets_before
 action('media_speech_read',{**base,'accountId':'independent-media-second','assetId':asset['id']},409)
 assert not list(OUT.rglob('injected.marker'))
 checks.append('Actual foreign cancel denied; own registered PS job cancels without saving; original factory close/reopen retains exact authorized WAV/text/rights and refuses other account')
 passed=True;save('RESULTS.json',{'status':'PASS_INDEPENDENT_ORIGINAL_FACTORY_MEDIA_BOUNDARIES','checks':checks,'groups':4,'realWavBytes':len(audio),'realWavDurationMs':preview['probe']['durationMs'],'originalFactoryCoreStoreHttp':True,'originalProductMethodsOverridden':False,'realWindowsSapiOnly':True,'independentRealOcrAccuracyRetested':False,'ownPowershellProcesses':processes,'realModelPlatformCalls':0,'productionAccess':False,'nativeOrGui':False,'assetCount':1,'asrNotClaimed':True})
finally:
 stop();save('FINAL.json',{'status':'PASS' if passed else 'RED_CAPTURED','blocked':blocked,'groupsPassed':len(checks),'ownServicesClosed':server is None,'ownProcesses':processes,'productionAccess':False})
 print(str(OUT),flush=True)
