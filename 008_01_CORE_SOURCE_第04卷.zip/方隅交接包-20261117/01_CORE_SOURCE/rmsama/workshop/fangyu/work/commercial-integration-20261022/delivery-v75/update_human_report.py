from pathlib import Path
import hashlib,json
D=Path(__file__).resolve().parent;P=D.parents[2];target=P/'outputs/三合一交付/当前交付核对.md'
raw=target.read_bytes();text=raw.decode('utf-8-sig')
backup=D/'human-documents-before-current/当前交付核对.md';backup.parent.mkdir(parents=True,exist_ok=True);assert not backup.exists();backup.write_bytes(raw)
start=text.index('原工作台保持运行，');end=text.index('## 已接入并验证')
text=text[:start]+'''更新到10月23日上午。**账号列表读取故障已修复，原电脑的下一次启动入口已更新。请关闭当前工作台，再从原桌面快捷方式重开一次，加载修复。** 没有强制关闭当前窗口，也没有回滚覆盖客户数据。

本次核对：2个小红书账号、1个抖音账号和1,888条评论均保留，原回复及任务没有变化。“获客”保留关键词搜索；左侧新增“多样化获客”，用于指定笔记、博主主页和我的互动。页面分别显示当前任务账号与下一次采集账号，切换页面不会开始任务。

旧批次的分析结果仍待核对时，原记录和请求继续保留；符合条件后可明确选择保留旧任务，按当前账号和条件另开采集。原来的不明确结果不会自动重新分析。三个窗口的完整能力仍在集成中。

''' +text[end:]
text=text.replace('支持Word、PPT、纯文字、Markdown的文字预览与确认保存；','支持Word、PPT、文字PDF、纯文字和Markdown的文字预览与确认保存；')
text=text.replace('尚不含PDF、扫描件、录音转写、配音或AI媒体生成。','扫描件识别、录音转写、配音和AI媒体生成仍需补齐。')
old='前一版本通过70组接口检查；本轮复验47组关键接口，另核对宽窄界面、权限、原断点、未知结果、并发和程序完整性。使用的是独立测试数据，不能代替真实平台或本人界面验收。'
assert old in text
text=text.replace(old,'独立测试已覆盖账号与客户读取、明确新建任务、原请求保护、权限和宽窄窗口；这些不能代替真实平台或本人界面验收。另发现同一账号同时操作时，首次读取的互斥检查还有一处旧问题，正在修复；当前不将完整并发流程写成通过。')
text=text.replace('| 项目 | 下一启动入口更新后的数据核对 |','| 项目 | 本次更新前后核对 |').replace('| 原评论 | 1,888条 |','| 平台账号 | 3个 |\n| 原评论 | 1,888条 |')
start=text.index('本轮受限内测安装包和说明已放在同级');end=text.index('没有替本人发送真实评论',start)
text=text[:start]+'''同级“普通电脑内测版”文件夹仍是此前的受限内测包，尚未包含今天的账号显示和入口修复。新的安装包已完成技术核对，账号并发问题修复后再统一更新，不将它当作全部业务已验通的正式客户包。原电脑的启动入口已单独更新，不需要重装这个旧包。

普通电脑版本无需另装Python、独立显卡或本地大模型，需要既有WebView2和.NET；视频工具另行配套。第二台普通电脑和真实员工业务仍待验收。

''' +text[end:]
start=text.index('## 本次夜间核验交接')
text=text[:start]+'''## 夜间核验之后的继续工作

早上8点已按约定删除夜间自动监控；本人回来后继续推进了本页的修复。文字PDF和客户详情中的历史分析版本说明现已进入原电脑的下一次启动版本，不再只是源码候选。

目前继续补齐账号并发互斥、持续定位访谈、专家协作，以及上方列出的完整业务缺口。原客户、原账号和任务断点保持保全；没有替本人发送评论、私信或作品，也没有整批重新收费分析历史客户。
'''
target.write_text(text,encoding='utf-8')
out={'humanFileUpdated':True,'beforeSha256':hashlib.sha256(raw).hexdigest(),'afterSha256':hashlib.sha256(target.read_bytes()).hexdigest(),
 'productionWritten':False,'standardPackageCopied':False,'notFullGoalComplete':True,'oldReportPreserved':True}
(D/'HUMAN-REPORT-UPDATE.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out))
