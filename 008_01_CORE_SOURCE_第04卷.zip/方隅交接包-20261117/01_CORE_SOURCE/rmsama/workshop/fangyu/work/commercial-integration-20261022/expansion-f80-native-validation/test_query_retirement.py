"""Original staged Native factory/HTTP; own synthetic directory, never production."""
from pathlib import Path
from datetime import datetime, timezone, timedelta
import hashlib, http.client, importlib.util, json, os, sys, threading
sys.dont_write_bytecode = True
C = Path(__file__).resolve().parent
P = C.parents[2]
S = Path('C:\\积木软件工坊\\项目\\方隅公寓客户版\\work\\parallel-integration-20261018\\final-integration\\candidate-unified-v80\\project')
stage = json.loads((C / 'QA-STAGED.json').read_text('utf-8'))
R = Path(stage['release'])
OUT = C / 'factory-http-lifecycle-final'
OUT.mkdir()
blocked = []

def audit(event, args):
    if event in ('subprocess.Popen', 'os.system', 'os.startfile', 'os.posix_spawn'):
        blocked.append(event); raise RuntimeError('No child process')
    if event in ('socket.connect', 'socket.bind') and (not isinstance(args[1], tuple) or args[1][0] not in ('127.0.0.1', '::1')):
        blocked.append(event); raise RuntimeError('No external socket')
    if event == 'socket.getaddrinfo' and args[0] not in ('127.0.0.1', '::1', 'localhost', None):
        blocked.append(event); raise RuntimeError('No external DNS')
    if event == 'sqlite3.connect' and not Path(args[0]).resolve().is_relative_to(C):
        blocked.append(event); raise RuntimeError('Own DB only')
    if event == 'open' and isinstance(args[0], (str, bytes, os.PathLike)):
        path = Path(os.fsdecode(args[0])).absolute(); mode, flags = args[1] or '', args[2] or 0
        if (any(k in str(mode) for k in 'wax+') or isinstance(flags, int) and flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC)) and not path.is_relative_to(C):
            blocked.append(event); raise RuntimeError('Own writes only')
sys.addaudithook(audit)

def load(name, path):
    m = importlib.util.module_from_spec(importlib.util.spec_from_loader(name, loader=None))
    m.__file__ = str(path); sys.modules[name] = m
    exec(compile(path.read_bytes(), str(path), 'exec'), m.__dict__)
    return m

fixture = load('query_original_identity_fixture', P / 'work/acquisition-core-repair-20261018/gui-fixture/base_fixture.py')
cloud = fixture.CloudStandin(json.loads((P / 'work/central-store-config/compiled-fixture.json').read_text('utf-8-sig')))
company = json.loads((S / 'work/app/company.json').read_text('utf-8-sig'))
def transport(*args, **kwargs):
    value = cloud(*args, **kwargs); value['environment_id'] = company['managedWorkspace']['environment_id']; return value
integration = load('integrations', R / 'resources/platform-runtime/vendor-src/integrations.py')
integration.request_json = transport
host = load('query_original_native_host', R / 'ui_native_host.py')
_, files = host.verify_release(R, stage['manifest_sha256'])
host.verify_backend_dependencies(R, files, S)
backend = server = worker = None
headers = {}; events = []; passed = False

def request(method, path, data=None, expected=200, custom_headers=None):
    connection = http.client.HTTPConnection('127.0.0.1', server.server_port, timeout=30)
    connection.request(method, path, json.dumps(data, ensure_ascii=False).encode() if data is not None else None, custom_headers or headers)
    response = connection.getresponse(); raw = response.read(); found = dict(response.getheaders()); status = response.status
    connection.close(); body = json.loads(raw) if raw.startswith(b'{') else {'raw': raw.decode('utf-8')}
    events.append({'method': method, 'path': path, 'action': data.get('action') if data else None, 'status': status})
    assert status == expected, (status, expected, body)
    return body, found

def action(name, data, expected=200, custom_headers=None):
    return request('POST', '/api/workbench', {'action': name, 'data': data}, expected, custom_headers)[0]

try:
    backend = host.create_backend(R, files, project_root=S, data_dir=OUT / 'data', company=company)
    server = host.StaticServer(R, files, backend=backend, cookie_name='query_fixture_session')
    worker = threading.Thread(target=server.serve_forever, daemon=True); worker.start()
    origin = 'http://127.0.0.1:' + str(server.server_port)
    boot, _ = request('GET', '/api/workbench/bootstrap')
    headers.update({'Origin': origin, 'Content-Type': 'application/json', 'X-Fangyu-CSRF': boot['csrfToken']})
    logged, found = request('POST', '/api/workbench', {'action': 'login', 'data': {'username': 'fixture-admin', 'password': fixture.PASSWORD}})
    headers.update(Cookie=found['Set-Cookie'].split(';', 1)[0]); headers['X-Fangyu-CSRF'] = logged['csrfToken']
    store = cloud.first_store
    if logged['selection']['storeId'] != store:
        action('select_store', {'storeId': store, 'expectedRevision': logged['selection']['revision']})
    user = backend.core.session(headers['Cookie'].split('=', 1)[1])
    task = {'id': 'query-factory-task', 'tenant_id': user['tenant_id'], 'cloud_owner': user['username'],
        'store_id': store, 'account_id': 'query-factory-account', 'platform': 'xiaohongshu', 'status': 'running',
        'scope': 'search_comments', 'keywords': ['合成古北短租'], 'pipeline': None, 'continuous_enabled': False,
        'comment_keyword_mode': 'all', 'comment_depth': 'main', 'region': '', 'unknown_policy': 'exclude'}
    backend.core.store.put('accounts', {'id': task['account_id'], 'tenant_id': user['tenant_id'],
        'cloud_owner': user['username'], 'store_id': store, 'platform': 'xiaohongshu', 'status': 'disconnected'})
    backend.core.store.put('tasks', task)
    from core.pipeline import collect_batch
    class LocalAdapter:
        def search(self, platform, query):
            assert query['keywords'] == ['合成古北短租']; query['_page_info'] = {'has_more': False}
            return [{'url': 'https://www.xiaohongshu.com/explore/0123456789abcdef01234567', 'title': '合成帖子', 'author': '合成博主', 'author_id': 'poster'}]
        def comments(self, platform, query):
            query['_page_info'] = {'has_more': False}
            return [{'platform': platform, 'source_id': 'comment:factory-comment', 'comment_id': 'factory-comment',
                'note_url': query['note_url'], 'url': query['note_url'], 'text': '想了解短租一个月', 'author_id': 'factory-customer', 'author': '示例客户'}]
    rows = collect_batch(LocalAdapter(), task, lambda: backend.core.store.put('tasks', task))
    for row in rows: row['task_id'] = task['id']
    backend.core._import(rows, user['tenant_id'], user, collection_task=task, observed_comments=rows)
    day = datetime.now(timezone(timedelta(hours=8))).date().isoformat()
    data = {'storeId': store, 'dateFrom': day, 'dateTo': day, 'platform': 'xiaohongshu'}
    with backend.core.store.connect() as db:
        before = [tuple(r) for r in db.execute("SELECT entity,id,body FROM records WHERE entity NOT IN ('users') ORDER BY entity,id")]
    report = action('keyword_effect_read', data)['keywordEffect']
    assert report['queryAttribution']['groups'][0]['keyword'] == '合成古北短租'
    assert report['queryAttribution']['total']['commentsSeen'] == 1
    action('keyword_effect_read', {**data, 'storeId': 'other-store'}, 403)
    action('keyword_effect_read', data, 403, {**headers, 'X-Fangyu-CSRF': 'wrong'})
    action('keyword_effect_read', data, 403, {**headers, 'Origin': 'https://example.invalid'})
    with backend.core.store.connect() as db:
        after = [tuple(r) for r in db.execute("SELECT entity,id,body FROM records WHERE entity NOT IN ('users') ORDER BY entity,id")]
    assert before == after
    (OUT / 'REPORT.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    # Independent F79 lifecycle control: original account-delete transition,
    # followed by the same original authorized read-only HTTP metrics endpoint.
    before_retirement = report
    leads_before = backend.core.store.list('leads', user['tenant_id'])
    provenance_before = backend.core.store.list('lead_query_observations_v1', user['tenant_id'])
    account = backend.core.store.get('accounts', task['account_id'])
    retired = backend.core.handle('account_delete', {'id': account['id'], 'expected_account_digest': backend.core.account_delete_digest(account)}, user)
    assert retired['ok'] and backend.core.store.get('accounts', account['id']) is None
    retained_task = backend.core.store.get('tasks', task['id'])
    assert retained_task['account_id'] == '' and retained_task['account_removed'] is True
    assert backend.core.store.list('leads', user['tenant_id']) == leads_before
    assert backend.core.store.list('lead_query_observations_v1', user['tenant_id']) == provenance_before
    after_retirement = action('keyword_effect_read', data)['keywordEffect']
    observed = {'beforeTotalComments': before_retirement['total']['commentsSeen'], 'afterTotalComments': after_retirement['total']['commentsSeen'], 'beforeQueryComments': before_retirement['queryAttribution']['total']['commentsSeen'], 'afterQueryComments': after_retirement['queryAttribution']['total']['commentsSeen'], 'taskRetiredByOriginalCore': True, 'originalLeadsUnchanged': True, 'originalProvenanceUnchanged': True, 'sameAuthorizedHttpEndpoint': True, 'unverifiedStoreCommentsExcluded': after_retirement['quality']['unverifiedStoreCommentsExcluded']}
    (C / 'ACCOUNT-RETIREMENT-RESULT.json').write_text(json.dumps(observed, indent=2), 'utf-8')
    assert observed['afterTotalComments'] == observed['beforeTotalComments'] and observed['afterQueryComments'] == observed['beforeQueryComments'], observed
    lifecycle_checks = ['Original account deletion keeps traditional and trusted query totals', 'Original customer/comment/provenance bytes retained']
    def rows_snapshot():
        with backend.core.store.connect() as db:
            return [tuple(row) for row in db.execute("SELECT entity,id,body FROM records WHERE entity!='users' ORDER BY entity,id")]
    original_retired = backend.core.store.get('tasks', task['id'])
    before_reads = rows_snapshot()
    for _ in range(2):
        repeated = action('keyword_effect_read', data)['keywordEffect']
        assert repeated['total']['commentsSeen'] == repeated['queryAttribution']['total']['commentsSeen'] == 1
    assert rows_snapshot() == before_reads
    lifecycle_checks.append('Repeated authorized read does not recount or write original records')
    # Real original close/reopen, followed by the same current managed actor.
    server.shutdown();worker.join(3);server.server_close();backend.close()
    backend = host.create_backend(R, files, project_root=S, data_dir=OUT / 'data', company=company)
    server = host.StaticServer(R, files, backend=backend, cookie_name='query_fixture_session')
    worker = threading.Thread(target=server.serve_forever, daemon=True);worker.start()
    origin = 'http://127.0.0.1:' + str(server.server_port);headers.clear()
    boot, _ = request('GET', '/api/workbench/bootstrap')
    headers.update({'Origin': origin, 'Content-Type': 'application/json', 'X-Fangyu-CSRF': boot['csrfToken']})
    logged, found = request('POST', '/api/workbench', {'action':'login','data':{'username':'fixture-admin','password':fixture.PASSWORD}})
    headers.update(Cookie=found['Set-Cookie'].split(';',1)[0]);headers['X-Fangyu-CSRF']=logged['csrfToken']
    user = backend.core.session(headers['Cookie'].split('=',1)[1])
    reopened = action('keyword_effect_read', data)['keywordEffect']
    assert reopened['total']['commentsSeen'] == reopened['queryAttribution']['total']['commentsSeen'] == 1
    assert backend.core.store.list('leads',user['tenant_id']) == leads_before
    assert backend.core.store.list('lead_query_observations_v1',user['tenant_id']) == provenance_before
    lifecycle_checks.append('Actual factory reopen preserves same-scope retired statistics without backfill')
    for label, changed in [('not-explicit-retired',{**original_retired,'account_removed':False}),('foreign-owner',{**original_retired,'cloud_owner':'other-employee'}),('no-store',{**original_retired,'store_id':None}),('foreign-store',{**original_retired,'store_id':'other-store'}),('platform-changed',{**original_retired,'platform':'douyin'})]:
        backend.core.store.put('tasks',changed)
        hidden = action('keyword_effect_read',data)['keywordEffect']
        assert hidden['total']['commentsSeen'] == hidden['queryAttribution']['total']['commentsSeen'] == 0,(label,hidden)
        backend.core.store.put('tasks',original_retired)
    lifecycle_checks.append('Missing retirement, foreign owner/store, absent store and changed platform receive no retired exception')
    backend.core.store.put('accounts',account)
    hidden = action('keyword_effect_read',data)['keywordEffect']
    assert hidden['queryAttribution']['total']['commentsSeen'] == hidden['total']['commentsSeen'] == 0
    with backend.core.store.connect() as db:db.execute('DELETE FROM records WHERE entity=? AND id=?',('accounts',account['id']))
    lifecycle_checks.append('Forged retired flag cannot use a still-existing old account')
    audits = [row for row in backend.core.store.list('audit',user['tenant_id']) if row.get('action')=='account_delete']
    with backend.core.store.connect() as db:
        for row in audits:db.execute('DELETE FROM records WHERE entity=? AND id=?',('audit',row['id']))
    hidden = action('keyword_effect_read',data)['keywordEffect']
    assert hidden['total']['commentsSeen'] == hidden['queryAttribution']['total']['commentsSeen'] == 0
    for row in audits:backend.core.store.put('audit',row)
    lifecycle_checks.append('No original deletion audit means no retired exception; no task checkpoint can supply it')
    # Old conventional observations must remain usable even without query-v1.
    with backend.core.store.connect() as db:
        old_observations=[tuple(row) for row in db.execute("SELECT entity,id,tenant_id,body FROM records WHERE entity IN ('lead_task_observations_v1','lead_query_observations_v1') ORDER BY entity,id")]
        db.execute('DELETE FROM records WHERE entity=?',('lead_query_observations_v1',))
    conventional_only=action('keyword_effect_read',data)['keywordEffect']
    assert conventional_only['total']['commentsSeen']==1 and conventional_only['queryAttribution']['total']['commentsSeen']==0
    with backend.core.store.connect() as db:
        db.execute('DELETE FROM records WHERE entity=?',('lead_task_observations_v1',))
    unproved=action('keyword_effect_read',data)['keywordEffect']
    assert unproved['total']['commentsSeen']==unproved['queryAttribution']['total']['commentsSeen']==0
    with backend.core.store.connect() as db:
        for row in old_observations:db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',row)
    lifecycle_checks.append('Conventional-only trusted observations survive account retirement without any query-v1 record')
    lifecycle_checks.append('Retirement flag/audit/raw lead without any original observation never creates attributed history')
    fresh_account={**account,'id':'query-new-independent-account'};backend.core.store.put('accounts',fresh_account)
    rebound={**original_retired,'account_id':fresh_account['id'],'account_removed':False};backend.core.store.put('tasks',rebound)
    rebound_report=action('keyword_effect_read',data)['keywordEffect']
    assert rebound_report['queryAttribution']['total']['commentsSeen']==0
    backend.core.store.put('tasks',original_retired)
    lifecycle_checks.append('Rebinding never validates old-account query evidence as a new account query')
    action('keyword_effect_read',{**data,'storeId':'other-store'},403)
    saved_user=backend.core.store.get('users',user['id']);backend.core.store.put('users',{**saved_user,'disabled':True})
    try:
        actor={**user,'_workbench_store_id':store}
        backend.keyword_effect_workbench.read(actor,store,data)
    except Exception as error:
        assert getattr(error,'code',None)=='AUTH_REQUIRED',(type(error).__name__,str(error))
    else:raise AssertionError('Revoked current identity accepted')
    backend.core.store.put('users',saved_user)
    lifecycle_checks.append('Foreign store HTTP rejects and revoked current actor cannot use retired proof')
    # Separate new task and account produce new internal proof. They never
    # reuse or rewrite the old task, original query row or account binding.
    newtask={**task,'id':'query-new-independent-task','account_id':fresh_account['id'],'keywords':['新账号合成检索词'],'pipeline':None}
    newtask.pop('_query_page',None);newtask.pop('_pipeline_next',None)
    backend.core.store.put('tasks',newtask)
    class NewAdapter(LocalAdapter):
        def search(self,platform,query):
            assert query['keywords']==['新账号合成检索词'];query['_page_info']={'has_more':False}
            return [{'url':'https://www.xiaohongshu.com/explore/1123456789abcdef01234567','title':'合成新帖','author':'合成新博主','author_id':'new-poster'}]
        def comments(self,platform,query):
            query['_page_info']={'has_more':False}
            return [{'platform':platform,'source_id':'comment:new-factory-comment','comment_id':'new-factory-comment','note_url':query['note_url'],'url':query['note_url'],'text':'合成新评论','author_id':'new-factory-customer','author':'合成新客户'}]
    newrows=collect_batch(NewAdapter(),newtask,lambda:backend.core.store.put('tasks',newtask))
    for row in newrows:row['task_id']=newtask['id']
    backend.core._import(newrows,user['tenant_id'],user,collection_task=newtask,observed_comments=newrows)
    combined=action('keyword_effect_read',data)['keywordEffect']
    assert combined['queryAttribution']['total']['commentsSeen']==2 and len(combined['queryAttribution']['groups'])==2
    assert all(row['commentsSeen']==1 for row in combined['queryAttribution']['groups'])
    assert backend.core.store.get('tasks',task['id'])==original_retired
    assert all(backend.core.store.get('lead_query_observations_v1',row['id'])==row for row in provenance_before)
    lifecycle_checks.append('A new account/task collects independently; old retired query stays counted once and byte-identical')
    (C/'RETIREMENT-FACTORY-RESULTS.json').write_text(json.dumps({'status':'PASS','checks':lifecycle_checks,'beforeAfterRetirement':observed,'queryTotalAfterIndependentNewTask':2,'originalAccountDeleteWithDigest':True,'actualFactoryReopen':True,'originalRetiredRecordsUnchanged':True,'realPlatformOrModelCalls':0,'productionAccess':False},ensure_ascii=False,indent=2),'utf-8')
    passed = True
finally:
    if server: server.shutdown(); server.server_close()
    if worker: worker.join(3)
    if backend: backend.close()
    (C / 'FACTORY-RESULTS.json').write_text(json.dumps({'status': 'PASS' if passed else 'RED',
        'originalVerifyReleaseDependenciesCreateBackendAndHTTP': True, 'checks': 4,
        'syntheticEnterpriseAuthorityAndPlatformReadPayload': True,
        'realPlatformOrModelCalls': 0, 'nativeDesktopWindowOpened': False, 'blocked': blocked,
        'allOwnServersClosed': worker is None or not worker.is_alive(), 'events': events}, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({'status': 'PASS' if passed else 'RED', 'checks': 4, 'blocked': blocked}))
