"""Real original factory/HTTP/guards/Adapters/Popen/NodeCLI, synthetic Bridge only."""
from pathlib import Path
from copy import deepcopy
from types import SimpleNamespace
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
import hashlib,http.client,importlib.util,json,os,re,shlex,sys,threading,time,uuid,subprocess
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=W.parents[2];S=Path('C:\\积木软件工坊\\项目\\方隅公寓客户版\\work\\parallel-integration-20261018\\final-integration\\candidate-unified-v82\\project')
stage=json.loads(Path('C:\\积木软件工坊\\项目\\方隅公寓客户版\\work\\parallel-integration-20261018\\final-integration\\candidate-unified-v82\\STAGED.json').read_text('utf-8-sig'));R=Path(stage['release'])
OUT=W/('factory-'+uuid.uuid4().hex);OUT.mkdir();events=[];wire=[];blocked=[];processes=[];checks=[];reply_permission=[True]
save=lambda name,v:(OUT/name).write_text(json.dumps(v,ensure_ascii=False,indent=2,default=str),'utf-8')
def audit(event,args):
 if event=='subprocess.Popen':
  argv=args[1];argv=[v.strip('"') for v in shlex.split(argv,posix=False)] if isinstance(argv,str) else argv
  assert Path(argv[0]).resolve()==S/'work/ui-runtime-r55/work/runtime/douyin-bridge/node.exe',argv
  assert Path(argv[1]).resolve() in (S/'work/ui-runtime-r55/work/runtime/douyin-bridge/dm_workbench_cli.js',W/'bridge_fixture.cjs'),argv
  assert Path(args[2]).resolve().is_relative_to(OUT),args;processes.append(list(argv))
 elif event in ('os.system','os.startfile','os.posix_spawn'):blocked.append(event);raise RuntimeError('Only fixed internal CLI process')
 if event in ('socket.connect','socket.bind') and (not isinstance(args[1],tuple) or args[1][0] not in ('127.0.0.1','::1')):blocked.append(event);raise RuntimeError('Loopback only')
 if event=='socket.getaddrinfo' and args[0] not in ('127.0.0.1','::1','localhost',None):raise RuntimeError('No external DNS')
 if event=='sqlite3.connect' and not Path(args[0]).resolve().is_relative_to(OUT):raise RuntimeError('Own DB only')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  path=Path(os.fsdecode(args[0])).absolute();mode,flags=args[1] or '',args[2] or 0
  if (any(c in str(mode) for c in 'wax+') or isinstance(flags,int) and flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC)) and not path.is_relative_to(OUT):raise RuntimeError('Own evidence/data only')
sys.addaudithook(audit)
def load(name,path):
 m=importlib.util.module_from_spec(importlib.util.spec_from_loader(name,loader=None));m.__file__=str(path);sys.modules[name]=m;exec(compile(path.read_bytes(),str(path),'exec'),m.__dict__);return m
fixture=load('dm_original_identity_fixture',P/'work/acquisition-core-repair-20261018/gui-fixture/base_fixture.py');cloud=fixture.CloudStandin(json.loads((P/'work/central-store-config/compiled-fixture.json').read_text('utf-8-sig')));company=json.loads((S/'work/app/company.json').read_text('utf-8-sig'))
def transport(*a,**k):
 value=cloud(*a,**k);value['environment_id']=company['managedWorkspace']['environment_id'];value['user']['can_reply']=reply_permission[0];return value
integration=load('integrations',R/'resources/platform-runtime/vendor-src/integrations.py');integration.request_json=transport
host=load('dm_actual_native_host',R/'ui_native_host.py');_,files=host.verify_release(R,stage['manifest_sha256']);host.verify_backend_dependencies(R,files,S)
backend=host.create_backend(R,files,project_root=S,data_dir=OUT/'data',company=company);runtime=backend.platform_runtime;core=backend.core
runtime.server._configure_bundled();runtime._platform_setup=True
core.remote_safety_hold=False;core.employee_release_device_id='dm-synthetic-device';core.employee_release_until_monotonic=time.monotonic()+600
accounts={};send_state=['sent'];bridge_calls=[];slow_listen=[False];listen_corrupt=[False];late_revoke=[False];stop_received=threading.Event()
class Bridge(BaseHTTPRequestHandler):
 def log_message(self,*a):pass
 def do_POST(self):
  data=json.loads(self.rfile.read(int(self.headers['Content-Length'])));assert self.path=='/admit'
  account=next(a for a in accounts.values() if a['conn_id']==data['connId']);operation=data['operation']
  assert data['expectedUid']==account['platform_uid']
  mode=core.account_mode_status(account['id'],user['tenant_id']);assert mode['status']=='active' and mode['mode']==('replies' if operation=='send' else 'collection'),mode
  foreign=type(core.continuous.leases)(core.store,'foreign-dm-review')
  try:foreign.acquire(account['id'],user['tenant_id'],'publishing','foreign-publication')
  except ValueError:pass
  else:raise AssertionError('Original atomic mode lease bypassed')
  args=[data['expectedUid'],data['recipient'],data['text'],data['requestId']] if operation=='send' else [data['expectedUid'],data['requestId'],data['timeoutMs']] if operation=='listen' else [data['requestId']]
  wire.append({'operation':operation,'args':args,'connection':data['connId'],'mode':mode,'foreignModeBlocked':True,'realTypedRouter':True})
  if operation=='stop':stop_received.set()
  if late_revoke[0] and operation=='listen':reply_permission[0]=False
  raw=json.dumps({'unknown':send_state[0]=='unknown','corrupt':listen_corrupt[0]}).encode()
  self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
bridge=ThreadingHTTPServer(('127.0.0.1',0),Bridge);bt=threading.Thread(target=bridge.serve_forever,daemon=True);bt.start()
bridge_process=subprocess.Popen([str(S/'work/ui-runtime-r55/work/runtime/douyin-bridge/node.exe'),str(W/'bridge_fixture.cjs'),str(bridge.server_port),str(OUT)],cwd=OUT,stdout=(OUT/'BRIDGE-STDOUT.txt').open('wb'),stderr=(OUT/'BRIDGE-STDERR.txt').open('wb'))
for _ in range(300):
 if (OUT/'BRIDGE-READY.json').exists():break
 assert bridge_process.poll() is None,'Fixture bridge exited'
 time.sleep(.02)
bridge_config=json.loads((OUT/'BRIDGE-READY.json').read_text('utf-8'))
def bridge_control(path,data={}):
 c=http.client.HTTPConnection('127.0.0.1',bridge_config['port'],timeout=10);c.request('POST','/fixture/'+path,json.dumps(data).encode(),{'Authorization':'Bearer '+bridge_config['token'],'Content-Type':'application/json'});r=c.getresponse();raw=r.read();c.close();assert r.status==200,(r.status,raw);return json.loads(raw)
def browser_conn(uid):return bridge_control('create',{'uid':uid})['connId']
server=host.StaticServer(R,files,backend=backend,cookie_name='dm_fixture_session');st=threading.Thread(target=server.serve_forever,daemon=True);st.start();origin='http://127.0.0.1:'+str(server.server_port);headers={};passed=False
def request(method,path,payload=None):
 c=http.client.HTTPConnection('127.0.0.1',server.server_port,timeout=30);c.request(method,path,json.dumps(payload,ensure_ascii=False).encode() if payload else None,headers);r=c.getresponse();raw=r.read();status=r.status;found=dict(r.getheaders());c.close();value=json.loads(raw);log=deepcopy(payload)
 if log and log.get('action')=='login':log['data']['password']='synthetic omitted'
 events.append({'method':method,'path':path,'payload':log,'status':status,'body':value});save('HTTP.json',events);return status,value,found
def action(name,data,expected=200):
 code,body,h=request('POST','/api/workbench',{'action':name,'data':data});assert code==expected,(name,code,body);return body,h
serial=0
def dm(name,data,expected=200):return action(name,{'storeId':store,**data},expected)[0].get('dmWorkspace')
def mutate(name,data,expected=200,key=None):
 global serial
 serial+=1;return dm(name,{**data,'requestId':key or 'dm-fixture-operation-'+str(serial).zfill(6)},expected)
def read(account,**data):return dm('dm_workspace_read',{'accountId':account['id'],**data})
def wait_queue(ident):
 for _ in range(300):
  row=dm('dm_queue_read',{'id':ident})
  if row['state'] not in ('prepared','running'):return row
  time.sleep(.03)
 raise AssertionError('Queue did not settle')
def draft(account,conv,text):
 d=mutate('dm_draft_save',{'accountId':account['id'],'expectedVersion':0,'target':{'conversationId':conv['id']},'text':text})
 return mutate('dm_draft_review',{'accountId':account['id'],'id':d['id'],'expectedVersion':d['version'],'confirmed':True})
def prepare(account,ds):return mutate('dm_queue_prepare',{'accountId':account['id'],'drafts':[{'id':d['id'],'version':d['version']} for d in ds]})
def start(q,key=None):return mutate('dm_queue_start',{'id':q['id'],'snapshotDigest':q['snapshotDigest'],'confirmed':True},key=key)
try:
 _,boot,_=request('GET','/api/workbench/bootstrap');headers.update({'Content-Type':'application/json','Origin':origin,'X-Fangyu-CSRF':boot['csrfToken']});_,logged,h=request('POST','/api/workbench',{'action':'login','data':{'username':'fixture-admin','password':fixture.PASSWORD}});headers['Cookie']=h['Set-Cookie'].split(';',1)[0];headers['X-Fangyu-CSRF']=logged['csrfToken'];store=cloud.first_store
 if logged['selection']['storeId']!=store:action('select_store',{'storeId':store,'expectedRevision':logged['selection']['revision']})
 user={**core.session(headers['Cookie'].split('=',1)[1]),'_workbench_store_id':store}
 from assistant.business import BusinessExecutor
 from assistant.xhs_app_context import bind_executor_session
 executor=BusinessExecutor(runtime.server,company['managedWorkspace']['environment_id'],company['id'],user['username']);runtime.service.executor=executor
 saved={'state':'bound','environment_id':company['managedWorkspace']['environment_id'],'company_id':company['id'],'token':'synthetic-device-token','device':{'id':'dm-synthetic-device','owner':user['username']}}
 runtime.service.vault=SimpleNamespace(read=lambda:deepcopy(saved));runtime.service.device=deepcopy(saved['device']);runtime.service.state='online'
 class DeviceCloud:
  def call(self,operation,data,credential):return {'claimed':True}
  def close(self):pass
 runtime.service._cloud=lambda:DeviceCloud();executor.account_claim=runtime.service._claim_xhs_account;bind_executor_session(runtime.service,executor,saved)
 from assistant.douyin_connection_service import _components
 component_revision=_components(runtime.server);assert len(component_revision)==64
 checks.append('Original active account connection _components accepts exact new reviewed Bridge material with original purpose and held grant unchanged')
 from core.douyin_comments_policy import DouyinCommentsPolicy
 comment_review=DouyinCommentsPolicy(runtime.server).resolve()
 assert comment_review and comment_review['purpose']=='douyin_owned_video_comments' and len(comment_review['revision'])==64,comment_review
 save('ACTIVE-PURPOSES.json',{'accountComponentsRevision':component_revision,'commentPurposeResolve':comment_review,'bridgeRuntime':str(runtime.server.bridge.runtime),'sourceResources':str(core.resources_dir),'scope':runtime.server._runtime_license_usage_scope('internal_self_use_read'),'publicSendHold':runtime.server.company['runtime']['public_send_hold'],'platformRequests':0})
 checks.append('Additional F82 original main-comment-purpose resolver accepts exact combined reviewed source with original fixed purpose and no network')
 for i in range(2):
  a={'id':'dm-fixture-account-'+str(i),'tenant_id':user['tenant_id'],'cloud_owner':user['username'],'store_id':store,'platform':'douyin','status':'ready','name':'合成私信账号','platform_uid':str(9007199254740993+i),'conn_id':'dm-synthetic-connection-'+str(i)};a['conn_id']=browser_conn(a['platform_uid']);accounts[a['id']]=a;core.store.put('accounts',a)
 account=list(accounts.values())[0];other=list(accounts.values())[1]
 config=core.store.directory/'bridge'/user['tenant_id']/'config.json';config.parent.mkdir(parents=True,exist_ok=True);config.write_text(json.dumps({'bridge':{'host':'127.0.0.1','port':bridge_config['port'],'token':bridge_config['token']}}),'utf-8')
 assert read(account)['conversations']['total']==0 and not wire;checks.append('Original factory read is empty and starts zero CLI/platform calls')
 listener=mutate('dm_listen_start',{'accountId':account['id'],'confirmed':True,'timeoutMs':100})
 for _ in range(200):
  value=read(account)
  if value['listeners'][-1]['state'] not in ('listening',):break
  time.sleep(.03)
 assert value['conversations']['total']==4,(value,wire,processes)
 convs=value['conversations']['items'];assert len(wire)==1 and wire[0]['operation']=='listen';checks.append('Actual original adapter/Popen/new NodeCLI reads one bounded synthetic Bridge batch into original Store with four stable conversations')
 from assistant.customer_list import _person
 task={'id':'dm-comment-source-task','tenant_id':user['tenant_id'],'cloud_owner':user['username'],'store_id':store,'platform':'douyin','account_id':account['id'],'status':'completed'};core.store.put('tasks',task)
 lead={'id':'dm-original-comment-source','tenant_id':user['tenant_id'],'cloud_owner':user['username'],'store_id':store,'task_id':task['id'],'platform':'douyin','author_id':'9007199254741111','comment_id':'dm-source-comment','text':'仅合成原评论，保留来源并由本人另核私信','note_url':'https://www.douyin.com/video/1234567890123456789','created_at':'2026-10-23T04:40:00Z'};core.store.put('leads',lead)
 digest_lead=lambda r:hashlib.sha256(json.dumps(r,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
 target_comment={'customerId':_person(lead)[0],'leadId':lead['id'],'sourceDigest':digest_lead(lead)}
 original_draft=mutate('dm_draft_save',{'accountId':account['id'],'expectedVersion':0,'target':target_comment,'text':'来自原评论的独立私信草稿'})
 assert original_draft['source']['kind']=='customer' and original_draft['source']['recipientUid']==lead['author_id']
 changed={**lead,'text':'原评论已变化，旧核对不可采用'};core.store.put('leads',changed);before=len(wire)
 mutate('dm_draft_review',{'accountId':account['id'],'id':original_draft['id'],'expectedVersion':1,'confirmed':True},409)
 assert len(wire)==before and core.store.get('leads',lead['id'])==changed and core.store.get('ui_dm_drafts_v1',original_draft['id'])['state']=='draft'
 checks.append('Real original customer/detail scope resolves explicit Douyin comment to stable UID; source-digest change rejects old review without creating or mutating customers/comments')
 d=draft(account,convs[0],'仅合成单条私信');q=prepare(account,[d]);before=len(wire);start(q);blocked_q=wait_queue(q['id']);assert len(wire)==before and blocked_q['state']=='blocked';checks.append('Original held public-send guard refuses a reviewed DM with zero CLI send; draft retained')
 # Explicit synthetic-only normal permission configuration, not a production
 # grant, test seam, runtime function replacement or permission bypass.
 for config_value in (runtime.server.company,core.deployment_config):
  flags=config_value['runtime'];flags['public_send_hold']=False;flags['public_reply_hold']=False;flags['public_replies']='enabled';flags.pop('platform_qa_device_id',None)
 # The original device session correctly rejects a changed config binding.
 # Bind a fresh original synthetic session to this explicitly changed fixture.
 executor=BusinessExecutor(runtime.server,company['managedWorkspace']['environment_id'],company['id'],user['username']);runtime.service.executor=executor
 executor.account_claim=runtime.service._claim_xhs_account;bind_executor_session(runtime.service,executor,saved)
 manifest_path=core.store.directory/'adapters/douyin.json';manifest=json.loads(manifest_path.read_text('utf-8'));manifest['dm_contract_verified']=True;manifest_path.write_text(json.dumps(manifest),'utf-8')
 q=prepare(account,[d]);start(q);sent=wait_queue(q['id']);assert sent['state']=='completed' and sent['items'][0]['state']=='sent',sent;assert wire[-1]['args'][0]==account['platform_uid'] and wire[-1]['operation']=='send';checks.append('Explicit own-fixture permit traverses unchanged device/held gates and original mode lease to actual CLI; stable server ID receipt means sent, never read')
 sent_history=read(account,conversationId=convs[0]['id'])['messages'];assert sent_history['total']==3 and sent_history['items'][0]['direction']=='outbound' and sent_history['items'][0]['platformMessageId']=='9223372036854775807' and sent_history['items'][0]['platformSentAt'] is None;checks.append('Only strict sent receipt appends an outgoing conversation message with stable server ID, original request key and no invented platform time/delivery/read status')
 # Concurrent original DM workers for the same platform UID, two accounts.
 mutate('dm_listen_start',{'accountId':other['id'],'confirmed':True,'timeoutMs':100})
 for _ in range(200):
  other_view=read(other)
  if other_view['listeners'][-1]['state']!='listening':break
  time.sleep(.02)
 other_sent=next(c for c in other_view['conversations']['items'] if c['recipientUid']==convs[0]['recipientUid'])
 already=prepare(other,[draft(other,other_sent,'同UID已由另账号成功，不应重发')]);before=len(wire);start(already)
 assert wait_queue(already['id'])['state']=='blocked' and len(wire)==before
 checks.append('Another account same stable UID after successful DM is blocked with zero typed dispatch, independent of conversation/message IDs')
 same_peer=next(c for c in other_view['conversations']['items'] if c['recipientUid']==convs[2]['recipientUid'])
 cq1=prepare(account,[draft(account,convs[2],'同一客户两账号竞争第一条')]);cq2=prepare(other,[draft(other,same_peer,'同一客户两账号竞争第二条')])
 bridge_control('options',{'uid':account['platform_uid'],'options':{'delaySendMs':600}});before=len(wire);start(cq1)
 for _ in range(200):
  if len(wire)>before:break
  time.sleep(.01)
 start(cq2);assert wait_queue(cq2['id'])['state']=='blocked'
 assert wait_queue(cq1['id'])['state']=='completed' and len(wire)==before+1
 bridge_control('options',{'uid':account['platform_uid'],'options':{'delaySendMs':0}})
 checks.append('Two account HTTP queues overlap while first synthetic IM send waits; original atomic stable-customer claim admits exactly one typed command')
 # Seed a pre-existing successful COMMENT record, not a pretend new send.
 history_lead={'id':'dm-existing-success-comment-lead','tenant_id':user['tenant_id'],'cloud_owner':user['username'],'store_id':store,'task_id':task['id'],'platform':'douyin','author_id':convs[3]['recipientUid'],'text':'合成既有评论来源'}
 history_reply={'id':'dm-existing-success-comment-reply','tenant_id':user['tenant_id'],'lead_id':history_lead['id'],'account_id':account['id'],'status':'sent','text':'合成既有成功评论回执'}
 core.store.put('leads',history_lead);core.store.put('replies',history_reply)
 comment_peer=next(c for c in other_view['conversations']['items'] if c['recipientUid']==history_lead['author_id'])
 old_comment=prepare(other,[draft(other,comment_peer,'先前评论成功，不应跨渠道重发')]);before=len(wire);start(old_comment)
 assert wait_queue(old_comment['id'])['state']=='blocked' and len(wire)==before
 assert core.store.get('leads',history_lead['id'])==history_lead and core.store.get('replies',history_reply['id'])==history_reply
 checks.append('Pre-existing synthetic sent COMMENT with same platform UID blocks batch DM across accounts; original lead/reply records remain unchanged')
 send_state[0]='unknown';d1=draft(account,convs[1],'仅合成未知私信');d2=draft(account,convs[2],'不应继续发送');q=prepare(account,[d1,d2]);before=len(wire);key='dm-fixture-original-unknown-key';start(q,key);unknown=wait_queue(q['id']);assert unknown['state']=='unknown' and len(wire)==before+1 and unknown['items'][1]['state']=='pending',unknown
 old_unknown=deepcopy(core.store.get('ui_dm_drafts_v1',d1['id']));again=start(q,key);assert again['state']=='unknown' and len(wire)==before+1
 mutate('dm_queue_start',{'id':q['id'],'snapshotDigest':q['snapshotDigest'],'confirmed':True},409,key='dm-other-key-must-not-retry')
 recovery=dm('dm_request_read',{'action':'dm_queue_start','requestId':key});assert recovery['state']=='unknown' and core.store.get('ui_dm_drafts_v1',d1['id'])==old_unknown;checks.append('First unknown stops selected queue; original key reopens current unknown, different key cannot send; old unknown bytes preserved')
 # Same recipient via another owned account is blocked by the preserved shared
 # atomic customer reservation, not a nickname heuristic or second lock table.
 mutate('dm_listen_start',{'accountId':other['id'],'confirmed':True,'timeoutMs':100})
 for _ in range(200):
  value=read(other)
  if value['listeners'][-1]['state']!='listening':break
  time.sleep(.03)
 target=next(c for c in value['conversations']['items'] if c['recipientUid']==convs[1]['recipientUid']);db=draft(other,target,'不应跨账号重发');qb=prepare(other,[db]);before=len(wire);start(qb);refused=wait_queue(qb['id']);assert refused['state']=='blocked' and len(wire)==before and core.store.get('ui_dm_drafts_v1',d1['id'])==old_unknown;checks.append('Another account targeting the same stable UID is blocked by original atomic customer claim before any CLI send')
 assert core.store.get('ui_dm_drafts_v1',d1['id'])==old_unknown
 before_reopen=len(wire);processes_before_reopen=len(processes)
 server.shutdown();st.join(3);server.server_close();backend.close()
 backend=host.create_backend(R,files,project_root=S,data_dir=OUT/'data',company=company);runtime=backend.platform_runtime;core=backend.core
 server=host.StaticServer(R,files,backend=backend,cookie_name='dm_fixture_session');st=threading.Thread(target=server.serve_forever,daemon=True);st.start();origin='http://127.0.0.1:'+str(server.server_port);headers={}
 _,boot,_=request('GET','/api/workbench/bootstrap');headers.update({'Content-Type':'application/json','Origin':origin,'X-Fangyu-CSRF':boot['csrfToken']})
 _,logged,h=request('POST','/api/workbench',{'action':'login','data':{'username':'fixture-admin','password':fixture.PASSWORD}});headers['Cookie']=h['Set-Cookie'].split(';',1)[0];headers['X-Fangyu-CSRF']=logged['csrfToken']
 if logged['selection']['storeId']!=store:action('select_store',{'storeId':store,'expectedRevision':logged['selection']['revision']})
 recovered=dm('dm_request_read',{'action':'dm_queue_start','requestId':key});assert recovered['state']=='unknown' and len(wire)==before_reopen
 assert start(q,key)['state']=='unknown' and len(wire)==before_reopen and len(processes)==processes_before_reopen
 assert core.store.get('ui_dm_drafts_v1',d1['id'])==old_unknown
 checks.append('Fresh original create_backend reopened same own Store; unknown original request read and same-key start remain unknown with zero new CLI or transport')
 assert all(v['foreignModeBlocked'] for v in wire) and all((core.account_mode_status(a['id'],user['tenant_id']) or {}).get('status')=='idle' for a in accounts.values())
 assert not blocked;save('RESULTS.json',{'status':'PASS_HARDEST_DM_FACTORY_REAL_CLI_SYNTHETIC_BRIDGE','checks':checks,'stage':stage,'actualFactoryCoreStoreHttpAdaptersPopenNodeCli':True,'originalModeAndScopeGuardsNotReplaced':True,'originalDeviceSessionWithExplicitSyntheticLease':True,'positiveSendFixtureConfigOnly':{'publicSendHold':False,'dmContractVerified':True,'realSendDestination':'own loopback Bridge simulator only'},'realPlatformModelCalls':0,'productionAccess':False,'wire':wire,'processCount':len(processes),'oldUnknownByteIdentical':True,'historyNotClaimed':True});passed=True
finally:
 server.shutdown();st.join(3);server.server_close();backend.close();bridge_control('shutdown');bridge_process.wait(timeout=10);bridge.shutdown();bt.join(3);bridge.server_close();save('FINAL.json',{'status':'PASS' if passed else 'RED_CAPTURED','checks':checks,'blocked':blocked,'wire':wire,'processes':processes,'allOwnServersClosed':not st.is_alive() and not bt.is_alive()});print(str(OUT),flush=True)
