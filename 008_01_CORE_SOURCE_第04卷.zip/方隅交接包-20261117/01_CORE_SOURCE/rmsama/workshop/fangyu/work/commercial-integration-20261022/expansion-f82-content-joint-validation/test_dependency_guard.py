from pathlib import Path
from types import ModuleType
import hashlib,json,shutil,sys,uuid,traceback
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;O=W/('dependency-probe-'+uuid.uuid4().hex);O.mkdir();S=W/'qa-only-project/work/ui-native-r57';checks=[];calls=[]
shutil.copyfile(S/'public_search_provider.py',O/'public_search_provider.py');shutil.copytree(S/'public_research_vendor',O/'public_research_vendor')
def audit(event,args):
 if event in ('subprocess.Popen','os.system','os.startfile','socket.connect','socket.bind','socket.getaddrinfo'):raise RuntimeError('No network/browser/process in dependency probe')
sys.addaudithook(audit)
p=O/'public_search_provider.py';m=ModuleType('public_dependency_probe');m.__file__=str(p);exec(compile(p.read_bytes(),str(p),'exec'),m.__dict__)
def transport(*args):calls.append(True);return 200,(W/'DDGS-RAW-RESPONSE.html').read_bytes()
def invoke():return m.search('上海 古北 服务式公寓',response_transport=transport)
def reject(label,change,restore):
 before=len(calls)
 try:
  change()
  try:invoke()
  except m.ProviderError as e:assert e.code=='PUBLIC_SEARCH_DEPENDENCY_INVALID',e.code
  else:raise AssertionError('Unpinned dependency executed: '+label)
  assert len(calls)==before;checks.append({'case':label,'result':'PASS','providerReadDelta':0})
 finally:restore()
passed=False
try:
 root=O/'public_research_vendor/runtime';native=next((root/'primp').glob('*.pyd'));native_raw=native.read_bytes()
 reject('cold native DLL byte tamper rejected before first extension load',lambda:native.write_bytes(b'XX'+native_raw[2:]),lambda:native.write_bytes(native_raw))
 assert len(invoke()['results'])==5;checks.append({'case':'original fixed 225-file loader real parser','result':'PASS'})
 root=O/'public_research_vendor/runtime';source=root/'ddgs/ddgs.py';raw=source.read_bytes()
 reject('cached loaded Python source tamper before each later call',lambda:source.write_bytes(raw+b'\nraise RuntimeError("UNPINNED_MARKER")\n'),lambda:source.write_bytes(raw))
 cache=root/'ddgs/__pycache__';reject('empty pycache directory',lambda:cache.mkdir(),lambda:cache.rmdir())
 extra=root/'lxml/late_unlisted.pyd';reject('late unlisted native shadow',lambda:extra.write_bytes(b'not a real DLL'),lambda:extra.unlink())
 manifest=O/'public_research_vendor/DEPENDENCY-PINS.json';raw=manifest.read_bytes()
 reject('dependency manifest cannot repin itself',lambda:manifest.write_bytes(raw+b' '),lambda:manifest.write_bytes(raw))
 assert len(invoke()['results'])==5;checks.append({'case':'restored original closure recovers','result':'PASS'})
 passed=True
finally:
 result={'status':'PASS' if passed else 'RED','checks':checks,'readCount':len(calls),'realExternalRequests':0,'pinnedRuntimeFiles':225,'usesRealFixedDDGSParser':True,'noGlobalDependencyChanges':True,'scope':'application import integrity, not an OS sandbox or protection against same-privilege concurrent native file replacement'}
 (O/'RESULTS.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n','utf-8');print(json.dumps({'status':result['status'],'checks':len(checks),'directory':str(O)},ensure_ascii=False))
