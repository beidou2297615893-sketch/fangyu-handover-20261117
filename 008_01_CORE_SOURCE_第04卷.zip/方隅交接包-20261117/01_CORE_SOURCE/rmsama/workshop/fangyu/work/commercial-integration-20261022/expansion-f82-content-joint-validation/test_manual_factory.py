"""Real pinned Native factory/Core/Store/HTTP; directory/model boundaries synthetic."""
from pathlib import Path
from copy import deepcopy
import hashlib,http.client,importlib.util,json,os,sys,threading,time,uuid
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=W.parents[2];A=W.parent/'guided-manual-f81-candidate';RED=False;S=Path('C:\\积木软件工坊\\项目\\方隅公寓客户版\\work\\parallel-integration-20261018\\final-integration\\candidate-unified-v82\\project');stage=json.loads((W/'F82-STAGED.json').read_text('utf-8-sig'));R=Path(stage['release']);OUT=W/('independent-factory-'+uuid.uuid4().hex);OUT.mkdir();blocked=[];events=[];results=[]
def save(name,v):(OUT/name).write_text(json.dumps(v,ensure_ascii=False,indent=2,default=str),'utf-8')
def audit(event,args):
 if event in ('subprocess.Popen','os.system','os.startfile','os.posix_spawn'):blocked.append(event);raise RuntimeError('No process')
 if event in ('socket.connect','socket.bind') and (not isinstance(args[1],tuple) or args[1][0] not in ('127.0.0.1','::1')):blocked.append(event);raise RuntimeError('No external socket')
 if event=='socket.getaddrinfo' and args[0] not in ('127.0.0.1','::1','localhost',None):blocked.append(event);raise RuntimeError('No external DNS')
 if event=='sqlite3.connect' and not Path(args[0]).resolve().is_relative_to(W):blocked.append(event);raise RuntimeError('Own DB only')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  path=Path(os.fsdecode(args[0])).absolute();mode,flags=args[1] or '',args[2] or 0
  if (any(c in str(mode) for c in 'wax+') or isinstance(flags,int) and flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC)) and not path.is_relative_to(W):blocked.append(event);raise RuntimeError('Own writes only')
sys.addaudithook(audit)
def load(name,path):
 m=importlib.util.module_from_spec(importlib.util.spec_from_loader(name,loader=None));m.__file__=str(path);sys.modules[name]=m;exec(compile(path.read_bytes(),str(path),'exec'),m.__dict__);return m
fixture=load('guided_original_identity_fixture',P/'work/acquisition-core-repair-20261018/gui-fixture/base_fixture.py');cloud=fixture.CloudStandin(json.loads((P/'work/central-store-config/compiled-fixture.json').read_text('utf-8-sig')));company=json.loads((S/'work/app/company.json').read_text('utf-8-sig'))
def transport(*args,**kwargs):
 value=cloud(*args,**kwargs);value['environment_id']=company['managedWorkspace']['environment_id'];return value
integration=load('integrations',R/'resources/platform-runtime/vendor-src/integrations.py');integration.request_json=transport
host=load('guided_actual_native_host',R/'ui_native_host.py');_,files=host.verify_release(R,stage['manifest_sha256']);host.verify_backend_dependencies(R,files,S)
class Model:
 def __init__(self):self.generations=[];self.statuses=[]
 def __call__(self,envelope):self.generations.append(deepcopy(envelope));return {'state':'unknown','requestId':envelope['requestId']}
 def status(self,envelope):
  self.statuses.append(deepcopy(envelope));return {'state':'succeeded','requestId':envelope['requestId'],'output':{'summary':'合成定位候选，仅核原结构化合同','facts':[],'hypotheses':['访谈中的预算和房源信息仍需核实，不作为门店现价。'],'artifact':{'name':'合成门店内容账号','positioning':'帮助租房者核对入住需求的候选定位','audience':'待验证的通勤租客','pillars':['通勤问题','入住准备'],'voice':['清楚','不夸大'],'avoid':['未经核实的价格承诺']}}}
model=Model();backend=None;server=None;worker=None;headers={};data_dir=OUT/'data';passed=False
def start():
 global backend,server,worker,origin
 backend=host.create_backend(R,files,project_root=S,data_dir=data_dir,company=company,content_model_adapter=model)
 server=host.StaticServer(R,files,backend=backend,cookie_name='guided_fixture_session');worker=threading.Thread(target=server.serve_forever,daemon=True);worker.start();origin='http://127.0.0.1:'+str(server.server_port)
def stop():
 global backend,server,worker
 if server:server.shutdown();worker.join(3);server.server_close();backend.close();server=None
def request(method,path,data=None,expected=200):
 conn=http.client.HTTPConnection('127.0.0.1',server.server_port,timeout=30);conn.request(method,path,json.dumps(data,ensure_ascii=False).encode() if data is not None else None,headers);resp=conn.getresponse();raw=resp.read();found=dict(resp.getheaders());status=resp.status;conn.close();body=json.loads(raw) if raw.startswith(b'{') else {'raw':raw.decode('utf-8')};logged=deepcopy(data)
 if logged and logged.get('action')=='login':logged['data']['password']='synthetic password omitted'
 events.append({'method':method,'path':path,'request':logged,'status':status,'body':body});save('HTTP.json',events);assert status==expected,(status,expected,body);return body,found
def action(name,data,expected=200):return request('POST','/api/workbench',{'action':name,'data':data},expected)[0]
def login(name='fixture-admin',selected=None):
 headers.clear();boot,_=request('GET','/api/workbench/bootstrap');headers.update({'Origin':origin,'Content-Type':'application/json','X-Fangyu-CSRF':boot['csrfToken']});logged,h=request('POST','/api/workbench',{'action':'login','data':{'username':name,'password':fixture.PASSWORD}});headers.update(Cookie=h['Set-Cookie'].split(';',1)[0]);headers['X-Fangyu-CSRF']=logged['csrfToken'];store=selected or cloud.first_store
 if logged['selection']['storeId']!=store:action('select_store',{'storeId':store,'expectedRevision':logged['selection']['revision']})
 return backend.core.session(headers['Cookie'].split('=',1)[1]),store
serial=0
def workspace():return action('content_workspace_read',base)['workspace']
def write(name,data,expected=200,key=None,revision=None):
 global serial
 serial+=1;return action(name,{**base,'expectedRevision':workspace()['revision'] if revision is None else revision,'requestId':key or 'guided-request-'+str(serial).zfill(8),**data},expected)
def ref(session):return {'sessionId':session['id'],'sessionVersion':session['version'],'sessionDigest':session['digest'],'stageId':catalog['stages'][session['stageIndex']]['id'],'expertId':session['expertId'],'expertDigest':session['expertDigest'],'answerIds':[a['id'] for a in session['answers']]}

def no_ai():return {'tasks':deepcopy(workspace()['workflow']['tasks']),'artifacts':deepcopy(workspace()['workflow']['artifacts']),'persona':deepcopy(workspace()['persona'])}
def create_answer():
 s=write('content_guided_save',{'operation':'create'})['result']['guidedSession']
 return write('content_guided_save',{'operation':'answer','sessionId':s['id'],'sessionVersion':s['version'],'stageId':'goals','questionId':'goal','answer':'合成自述，只帮助租客核对通勤，不承诺价格或转化。'})['result']['guidedSession']
def manual(s,**extra):
 return {'operation':'confirm_stage_manual','sessionId':s['id'],'sessionVersion':s['version'],'sessionDigest':s['digest'],'stageId':catalog['stages'][s['stageIndex']]['id'],'libraryDigest':catalog['digest'],'summary':'本人阶段小结：先核对通勤需求；业务判断尚需事实验证。','humanConfirmed':True,**extra}
def protected():
 with backend.core.store.connect() as db:return [dict(r) for r in db.execute("SELECT entity,id,tenant_id,body FROM records WHERE entity IN ('leads','tasks','replies','ai_jobs','ai_attempts','rental_assessments','accounts') ORDER BY entity,id")]
try:
 start();user,store=login();account={'id':'manual-admin-a','tenant_id':user['tenant_id'],'cloud_owner':user['username'],'store_id':store,'platform':'xiaohongshu','status':'disconnected','name':'合成甲员工甲店账号'}
 backend.core.store.put('accounts',account);base={'storeId':store,'accountId':account['id'],'platform':'xiaohongshu'}
 before=protected();catalog=action('content_guided_catalog_read',base)['result']['guidedCatalog'];s=create_answer();untouched=no_ai();payload=manual(s)
 revision=workspace()['revision'];key='manual-explicit-confirm-original-key'
 reply=write('content_guided_save',payload,key=key,revision=revision);advanced=reply['result']['guidedSession']
 assert advanced['stageIndex']==1 and advanced['version']==s['version']+1
 record=advanced['confirmedStages'][0];assert record['source']=='manual' and record['modelGenerated'] is False and record['kind']=='hypothesis' and record['verificationStatus']=='user_assertion_unverified'
 assert record['answerIds']==[s['answers'][0]['id']] and record['sourceSessionDigest']==s['digest'] and record['confirmedBy']==user['username'] and not ({'taskId','artifactId'}&set(record))
 assert no_ai()==untouched and not model.generations and not model.statuses and protected()==before
 assert write('content_guided_save',payload,key=key,revision=revision)['replayed'] is True
 conflict_before=deepcopy(action('content_guided_read',{**base,'sessionId':s['id']})['result']['guidedSessions'][0])
 write('content_guided_save',{**payload,'summary':'Changed after first confirmation; original key must not mutate.'},409,key=key,revision=revision)
 assert action('content_guided_read',{**base,'sessionId':s['id']})['result']['guidedSessions'][0]==conflict_before and not model.generations
 same=action('content_guided_read',{**base,'sessionId':s['id']})['result']['guidedSessions'][0];assert same==advanced
 stop();start();user,store=login();assert action('content_guided_read',{**base,'sessionId':s['id']})['result']['guidedSessions'][0]==advanced
 results.append('Original factory+HTTP answer -> explicit manual summary -> next stage; exact actor/source/answer history persisted across backend reopen and same-key receipt replay; zero model calls/tasks/artifacts/persona/business changes')
 # Every current source token and explicit confirmation is checked before commit.
 s=create_answer();data=manual(s)
 write('content_guided_save',{**data,'humanConfirmed':False},400)
 write('content_guided_save',{**data,'humanConfirmed':1},400)
 write('content_guided_save',{**data,'summary':' '},400)
 write('content_guided_save',{**data,'summary':'x'*2001},400)
 write('content_guided_save',{**data,'sessionDigest':'0'*64},409)
 write('content_guided_save',{**data,'libraryDigest':'0'*64},409)
 write('content_guided_save',{**data,'stageId':'audience'},409)
 write('content_guided_save',{**data,'taskId':'forged-task'},400)
 oldrevision=workspace()['revision'];s2=write('content_guided_save',{'operation':'answer','sessionId':s['id'],'sessionVersion':s['version'],'stageId':'goals','questionId':'resources','answer':'补充合成授权素材，原小结必须重新核对。'})['result']['guidedSession']
 write('content_guided_save',data,409)
 write('content_guided_save',manual(s2),409,revision=oldrevision)
 empty=write('content_guided_save',{'operation':'create'})['result']['guidedSession'];write('content_guided_save',manual(empty),409)
 assert not model.generations and no_ai()==untouched
 results.append('False/nonboolean confirmation, empty/oversized summary, wrong stage/session/library digests, forged task fields, stale answer/session/workspace CAS and no-answer stage all refused')
 # Real original actor sessions, two stores; account ownership does not transfer.
 admin_headers=deepcopy(headers);other=next(x['id'] for x in cloud.manifest['stores'] if x['id']!=store)
 operator,_=login('fixture-operator');action('content_guided_read',{**base,'sessionId':s['id']},403)
 action('content_guided_save',{**base,'expectedRevision':0,'requestId':'manual-cross-owner-key-01',**manual(s2)},403)
 operator_account={**account,'id':'manual-operator-a','cloud_owner':operator['username']};backend.core.store.put('accounts',operator_account)
 base={'storeId':store,'accountId':operator_account['id'],'platform':'xiaohongshu'};operator_s=create_answer();operator_done=write('content_guided_save',manual(operator_s))['result']['guidedSession'];assert operator_done['confirmedStages'][0]['confirmedBy']=='fixture-operator'
 action('content_guided_read',{**base,'storeId':other},403)
 user,_=login('fixture-admin',other);other_account={**account,'id':'manual-admin-b','store_id':other};backend.core.store.put('accounts',other_account)
 base={'storeId':other,'accountId':other_account['id'],'platform':'xiaohongshu'};second_s=create_answer();write('content_guided_save',manual(second_s));action('content_guided_read',{**base,'sessionId':operator_s['id']},404)
 # Original account not in selected store is rejected, not aliased to the new one.
 action('content_guided_read',{**base,'accountId':account['id']},403)
 results.append('Two original login employees and two authorized stores persist independently; cross-owner, cross-store/account and foreign session IDs refuse; no alternate identity/auth system')
 user,store=login();base={'storeId':store,'accountId':account['id'],'platform':'xiaohongshu'}
 prepared_s=create_answer();pending=write('content_task_prepare',{'methodId':'persona','query':'合成人工推进前的未派发任务','guidedReference':ref(prepared_s)})['result']['task']
 manually_advanced=write('content_guided_save',manual(prepared_s))['result']['guidedSession'];manual_id=manually_advanced['confirmedStages'][0]['id']
 stale=write('content_task_run',{'taskId':pending['id']},409);assert stale['error']['code']=='CONTENT_SOURCE_CHANGED' and not model.generations
 write('content_task_apply',{'taskId':manual_id},409)
 results.append('Manual advancement makes a previously prepared AI input stale before dispatch; human confirmation record cannot be applied as an AI task or artifact')
 unknown_s=create_answer();t=write('content_task_prepare',{'methodId':'persona','query':'合成原模型未知任务','guidedReference':ref(unknown_s)})['result']['task'];run_key='manual-old-model-unknown-key-01'
 unknown=write('content_task_run',{'taskId':t['id']},key=run_key)['result']['task'];assert unknown['state']=='unknown' and len(model.generations)==1
 frozen=deepcopy(workspace()['workflow']);write('content_guided_save',manual(unknown_s),409);write('content_task_run',{'taskId':t['id']},409)
 stop();start();login();assert workspace()['workflow']==frozen;write('content_guided_save',manual(unknown_s),409);write('content_task_reconcile',{'taskId':t['id']},409,key='manual-not-original-key')
 assert workspace()['workflow']==frozen and len(model.generations)==1 and not model.statuses
 # Exact original key queries the same frozen input, it does not redispatch.
 status=write('content_task_reconcile',{'taskId':t['id']},key=run_key)
 assert status['result']['task']['state']=='succeeded' and len(model.generations)==1 and len(model.statuses)==1 and model.statuses[0]['requestId']==model.generations[0]['requestId'] and model.statuses[0]['inputDigest']==model.generations[0]['inputDigest']
 assert not status['result']['task'].get('appliedRefs') and status['workspace']['persona']=={}
 write('content_guided_save',{'operation':'confirm_stage','sessionId':unknown_s['id'],'sessionVersion':unknown_s['version'],'taskId':t['id']},409)
 results.append('Old unknown original task/key and frozen input survive manual rejection and reopen byte-for-byte; wrong-key reconcile and rerun refused; exact original-key status queries once with zero redispatch, no implicit apply')
 # Manual progress never grants publication or claims generated output.
 final=workspace();assert final['workflowCapabilities']['canExecutePlatforms'] is False
 assert all(c.get('source')=='manual' and not c.get('modelGenerated') and not c.get('artifactId') for z in final['workflow']['guidedSessions'] for c in z['confirmedStages'])
 assert not blocked
 save('RESULTS.json',{'status':'PASS','checks':results,'stage':stage,'actualOriginalFactory':True,'sameStorePersistence':True,'manualModelCalls':0,'syntheticGenerationsForUnknownRegression':len(model.generations),'originalKeyStatusQueries':len(model.statuses),'realModelPlatformCalls':0,'productionAccess':False,'nativeWindow':False});passed=True
finally:
 stop();save('MODEL-ENVELOPES.json',{'generation':model.generations,'status':model.statuses,'syntheticOnly':True});save('FINAL.json',{'status':'PASS' if passed else 'RED_CAPTURED','blocked':blocked,'eventCount':len(events),'modelCalls':len(model.generations),'statusCalls':len(model.statuses),'productionAccess':False});(W/('LATEST-RED.json' if RED else 'LATEST-MANUAL.json')).write_text(json.dumps({'directory':str(OUT),'status':'PASS' if passed else 'RED_CAPTURED'},ensure_ascii=False,indent=2),'utf-8')
print(str(OUT)+' '+('PASS' if passed else 'RED'))
