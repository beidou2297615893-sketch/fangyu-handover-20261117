from pathlib import Path
import json, urllib.request, urllib.error
from datetime import datetime,timezone

W=Path(__file__).parent
urls={
 'opencli_dm_pr':'https://api.github.com/repos/jackwener/OpenCLI/pulls/2554',
 'xhs_repo':'https://api.github.com/repos/jackwener/xiaohongshu-cli',
 'dy_repo':'https://api.github.com/repos/Yht20927/douyin-cli',
}
out={'checked_at':datetime.now(timezone.utc).isoformat(),'customer_data_in_queries':False,'checks':{}}
for key,url in urls.items():
    try:
        req=urllib.request.Request(url,headers={'User-Agent':'fangyu-source-review','Accept':'application/vnd.github+json'})
        with urllib.request.urlopen(req,timeout=20) as r:v=json.load(r)
        allowed=('html_url','state','merged','merged_at','closed_at','updated_at','pushed_at','default_branch','archived','disabled','title','merge_commit_sha')
        safe={k:v.get(k) for k in allowed if k in v}
        if key.endswith('repo'):safe['license']=(v.get('license') or {}).get('spdx_id')
        if key.endswith('pr'):
            safe['head_sha']=(v.get('head') or {}).get('sha');safe['base_sha']=(v.get('base') or {}).get('sha')
        out['checks'][key]={'source':url,'status':'read','metadata':safe}
    except Exception as e:
        out['checks'][key]={'source':url,'status':'unverified','error_type':type(e).__name__}
(W/'PUBLIC-SOURCES.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),'utf-8')
print(json.dumps(out,ensure_ascii=False))
