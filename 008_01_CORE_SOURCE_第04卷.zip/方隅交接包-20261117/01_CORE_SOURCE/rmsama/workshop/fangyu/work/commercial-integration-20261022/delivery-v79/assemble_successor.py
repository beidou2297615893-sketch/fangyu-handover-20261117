from pathlib import Path
import hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent;W=D.parent;P=D.parents[2];F=P/'work/parallel-integration-20261018/final-integration'
base=F/'candidate-unified-v78';S=W/'account-recovery-successor-source/project';assert not S.exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(base/'UNIFIED-PINS.json')=='80b52eafeb19fcce7a7095a5a2e4df799d9f0cd35e534901f57c20287ec30631'
pins=json.loads((base/'UNIFIED-PINS.json').read_text('utf-8'))['files']
for row in pins:
 raw=(base/'project'/row['path']).read_bytes();assert hashlib.sha256(raw).hexdigest()==row['sha256'];target=S/row['path'];target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
relative='work/ui-approved-implementation/ui-preview/pages/diversified-acquisition.mjs';target=S/relative;before=target.read_bytes();text=before.decode('utf-8')
anchor="    if(live(s).canResume&&!live(s).taskScope?.source&&!sourceSelection(s)?.source)return;\n    event.stopImmediatePropagation();"
assert text.count(anchor)==1
text=text.replace(anchor,anchor.replace('    event.stopImmediatePropagation();','    if(acquire.freshAcquisitionCapture?.(s))return;\n    event.stopImmediatePropagation();'))
after=text.encode('utf-8');target.write_bytes(after)
canonical=F/'stage-02/project'/relative;assert canonical.read_bytes()==before
backup=D/'source-before'/relative;backup.parent.mkdir(parents=True,exist_ok=True);backup.write_bytes(before);canonical.write_bytes(after)
receipt={'status':'SOURCE_FIXED_NOT_INSTALLED','baselineFilesVerified':len(pins),'baselineCandidate':'candidate-unified-v78','baselineUnifiedSha256':sha(base/'UNIFIED-PINS.json'),'path':relative,'beforeSha256':hashlib.sha256(before).hexdigest(),'afterSha256':sha(target),'reason':'Keyword wrapper previously swallowed strictly eligible fresh-acquisition click before original acquire handler. Delegate only when existing full fresh capture succeeds.','actualF78UiFailureRetained':True,'productionAccess':False,'nativeEntryChanged':False}
(D/'SUCCESSOR-SOURCE.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),'utf-8')
spec=importlib.util.spec_from_file_location('urgent_original_freezer',F/'freeze_unified.py');builder=importlib.util.module_from_spec(spec);spec.loader.exec_module(builder);builder.SOURCE=S
sys.argv=[str(F/'freeze_unified.py'),'--candidate','candidate-unified-v79'];builder.main()
