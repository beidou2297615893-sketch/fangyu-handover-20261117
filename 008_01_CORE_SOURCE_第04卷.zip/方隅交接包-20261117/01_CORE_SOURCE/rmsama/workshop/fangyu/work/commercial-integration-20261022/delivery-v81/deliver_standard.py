from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,shutil
D=Path(__file__).resolve().parent;W=D.parent;P=D.parents[2]
A=W/'f81-standard-package-candidate';R=W/'f81-standard-package-independent-review'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for path,pin in [(A/'FINAL-RECEIPT.json','d48ad68321f7a17a2f7d10469b537aac7dca425441eb45e95bd686b08eba01d8'),
                 (A/'SEALED.json','770385d2912047ece8839f9e87e4ef712251e197ba0f78c821677c5835d31049'),
                 (R/'FINAL-RECEIPT.json','372f58a0bb2d953d29741a9efa1618b3740323b8edf7dcaf7d24a12458ccd027'),
                 (R/'SEALED.json','5d8cae3267f929a2ffb3251f98cbab437817dcc2edf792ee547e3f3599bd1e82')]:assert sha(path)==pin
assert sha(D/'INSTALLATION-FINAL.json')=='76d9a17c0581a2841fdfd7ec6e18a6bc21e9d7950956133670fe8e527072bdaf'
source=A/'standard-held-clean-v81/FangyuWorkbenchSetup-standard-held-clean-v81.exe'
expected='c75279f48e68088fb27cb9013d3c0e91e7590d3f24ee22a8b763c03d64ab40a8'
assert sha(source)==expected and source.stat().st_size==286027236
out=P/'outputs/三合一交付';out.mkdir(exist_ok=True)
target=out/'方隅工作台安装程序.exe';previous=D/'previous-human-delivery';previous.mkdir()
for name in ('方隅工作台安装程序.exe','当前交付核对.md','安装与使用说明.md'):
    old=out/name
    if old.exists():shutil.copy2(old,previous/name)
shutil.copy2(source,target);assert sha(target)==expected
review='''# 方隅工作台当前交付核对

本机更新已安装，原桌面快捷方式下次打开会加载。当前窗口没有被强制关闭；这台电脑继续用原快捷方式即可，无需为了本轮更新重新安装。

本轮新增或完善：内容排程、图片提字与文字配音、私信草稿及原结果核对、关键词带来客户的统计、扫描PDF资料预览与确认入库。原有获客、客户、账号、SOP和导入导出继续保留。

账号与客户资料在更新前后核对一致：3个账号、1888条评论、40个任务、1794条DeepSeek分析等均保留；按稳定平台身份去重为1129位客户，不等于全部都有租房意向。独立备份仍覆盖当前核对的七类客户业务内容，没有恢复旧数据覆盖现状。

同文件夹的“方隅工作台安装程序.exe”是重新构建并独立检查的普通Windows安装包，约286MB，不需要独显或安装本地大模型。它用于其他电脑新装或已确认安装位置的升级；首次需要本人登录企业和平台账号，本机历史客户没有打包到安装程序里。

当前是受限可用版本。真实平台采集效果、真实发布、真实私信传输及另一台实体电脑首启等尚未全部验收；直播等完整三合一余项仍在继续。草稿、排程、模拟回执或本机测试通过，不能当作真实发送、发布或整套商业成品全部完成。

当前详细进度、客户判断差异及已通过与待验证事项，可在“整合进度”的核对文件中查看。原“今日需求与数据核对”保留此前的完整需求范围。
'''
guide='''# 安装与使用说明

本机已经更新：继续从原桌面“方隅工作台”快捷方式重开一次即可，账号与客户资料保留。不需要再运行安装包才能使用本轮修复。

其他电脑安装：运行同文件夹的“方隅工作台安装程序.exe”，按提示选择安装位置。已有安装时先正常退出软件；不同客户的软件和资料分别保留。首次打开后由本人登录企业、选择门店并连接自己的平台账号。

采集时先确认采集账号，回复时再确认发送账号。客户清单归门店保存，切换或从软件移除账号不会把历史客户当作应删除的数据。本人验证码、人脸或扫码仍需按平台页面完成。

本轮可使用：原获客与客户流程、内容排程、资料与扫描PDF预览、系统提字、系统声音配音、私信草稿与结果核对。系统提字及配音使用电脑已有的语言和声音；扫描PDF支持有明确页数、尺寸和格式限制的普通文件，先核对预览与资料类别，再确认保存。

真实一键私信和真实平台发布尚未完成接通验收，具体操作能力以软件提示为准；保存或准备任务不会自动替本人发送。不要把尚未验收的功能向客户承诺为已经可用。另一个实体电脑的实际首启和账号连接仍待验证。
'''
(out/'当前交付核对.md').write_text(review,'utf-8');(out/'安装与使用说明.md').write_text(guide,'utf-8')
receipt={'status':'FIXED_F81_RESTRICTED_STANDARD_INSTALLER_DELIVERED_LOCALLY',
    'createdUtc':datetime.now(timezone.utc).isoformat(),'path':str(target),'folder':str(out),
    'bytes':target.stat().st_size,'sha256':sha(target),'rootActualInstallationSha256':sha(D/'INSTALLATION-FINAL.json'),
    'authorFinalSha256':sha(A/'FINAL-RECEIPT.json'),'independentFinalSha256':sha(R/'FINAL-RECEIPT.json'),
    'oldHumanReviewBackedUp':True,'realPlatformOrMessagingCalls':0,'localOnlyNoExternalPublication':True,
    'secondPhysicalComputerVerified':False,'fullCommercialGoalComplete':False}
(D/'STANDARD-DISTRIBUTION-DELIVERY.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),'utf-8')
print(json.dumps({'status':receipt['status'],'bytes':receipt['bytes'],'sha256':receipt['sha256']}))
