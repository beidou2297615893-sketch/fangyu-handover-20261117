from pathlib import Path
from datetime import datetime,timezone
import ast,hashlib,json
D=Path(__file__).resolve().parent;W=D.parent;P=D.parents[2]
F=P/'work/parallel-integration-20261018/final-integration';C=F/'candidate-unified-v81';S=C/'project';B=F/'candidate-unified-v80/project'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(C/'UNIFIED-PINS.json')=='306fde02917f0f52bd0788069c56a802fbeb1a6ae428209533ea056c6e7a368c'
assert sha(C/'STAGED.json')=='a8a24d5ad8ea63c36b19133b8e9e8c9385ff092f7f4de906c426722a9650718b'
pins=json.loads((C/'UNIFIED-PINS.json').read_text('utf-8'));stage=json.loads((C/'STAGED.json').read_text('utf-8'))
for row in pins['files']:assert sha(S/row['path'])==row['sha256']
evidence=[]
def include(path,expected=None):
    if expected:assert sha(path)==expected
    evidence.append({'path':str(path.relative_to(W)),'sha256':sha(path),'bytes':path.stat().st_size})
include(W/'scanned-pdf-f80-integration/FROZEN-INPUTS.json','b99b98c16ef42a8fd4d7cc02f9fbe2caffe3a1639d98c0b6c46dc35b505f69fb')
include(W/'scanned-pdf-f79-independent-review/FINAL-RECEIPT.json','1614e72b92a377199bf104ff0c79815a242e7dba7a9e0e9a6ff86df9c909ff70')
include(W/'scanned-pdf-f79-independent-review/SEALED.json','a4521b7ae3a83fd196fb74aeb879c3e0d1f313af0b5acf252c5c0a21694dbf21')
include(W/'expansion-f81-joint-regression/FINAL-RECEIPT.json','c141c97253b86a4dd736abc070c3639ada9e5c8456cf6dcf1a2ac1ae7a53be39')
include(W/'expansion-f81-joint-regression/SEALED.json','61fbe38f52c2012eaf13206c2043c31daf99dfc7ec1528192635ae0a6ef9f843')
include(W/'delivery-v80/AGGREGATE-VALIDATION.json','80080b5b8dd6390d1d158081dbce4c1e899cacc76ca32e89dfbe777bf653232e')
V=W/'scanned-pdf-f81-native-validation';latest=json.loads((V/'LATEST-HTTP.json').read_text('utf-8'));out=Path(latest['directory'])
assert out.is_relative_to(V)
r=json.loads((out/'RESULTS.json').read_text('utf-8'));f=json.loads((out/'FINAL.json').read_text('utf-8'))
assert r['status']=='PASS_REAL_SCANNED_PDF_ORIGINAL_FACTORY_HTTP' and len(r['checks'])==7
assert r['realPlatformModelPaidCalls']==0 and r['previewsZeroRecords'] and not r['productionAccess']
assert f['status']=='PASS' and f['serverStopped'] and not f['blocked']
include(out/'RESULTS.json');include(out/'FINAL.json');include(V/'ADAPTATIONS.json')
assert (B/'work/ui-runtime-r55/src/core/engine.py').read_bytes()==(S/'work/ui-runtime-r55/src/core/engine.py').read_bytes()
def funcs(root):
    tree=ast.parse((root/'work/ui-native-r57/ui_native_host.py').read_bytes())
    return {n.name:ast.dump(n,include_attributes=False) for n in tree.body if isinstance(n,ast.FunctionDef)}
a,b=funcs(B),funcs(S)
assert a.keys()==b.keys() and {k for k in a if a[k]!=b[k]}=={'_knowledge_file_factory','create_backend'}
composition=json.loads((W/'scanned-pdf-f80-integration/COMPOSITION.json').read_text('utf-8'))
assert composition['sourcePaths']==7
receipt={'status':'PASS_FIXED_F81_COMBINED_SCAN_AND_ORIGINAL_BUSINESS_NOT_PLATFORM_OR_FULL_GOAL_COMPLETION',
    'createdUtc':datetime.now(timezone.utc).isoformat(),'candidate':C.name,'sourceFilesVerified':len(pins['files']),
    'releaseResources':stage['files'],'originalBusinessGroups':47,'originalAccountGroups':8,'keywordWrapperGroups':11,
    'independentScannerFactoryGroups':5,'independentScannerHttpRequests':26,
    'rootActualF81ScannerFactoryGroups':7,'fullIndexScannerUiChecks':16,'fullIndexWidths':[1255,390],
    'allCoreEngineBytesSameAsAcceptedF80':True,'hostFunctionDifferencesOnlyKnowledgeFactoryAndCreateBackend':True,
    'referenceF80OtherFeatureAcceptance':'Exact unchanged DM/G11/query/media source/resources; F80 actual factory/UI proofs referenced, not all rerun',
    'rootOmittedOneTestGroup':'Author isolated-QA resource-tamper/restore group only; formal F81 never modified',
    'expectedLostReceiptTraceRetained':'Win10053 follows explicitly abandoned local response; same original key/reopen assertions passed',
    'productionAccess':False,'canonicalOrInstalledWritten':False,'realPlatformOrModelCalls':0,
    'limits':['Ordinary F81 clean package still being freshly built and reviewed',
              'Current human Native first-open/real platform sampling remain unverified',
              'Restricted JPEG/Flate RGB/gray scan PDFs within explicit budgets; not every PDF or ASR',
              'Real DM transport/history, real publication/livestream and other full-scope items remain'],
    'evidence':evidence}
assert not (D/'AGGREGATE-VALIDATION.json').exists()
(D/'AGGREGATE-VALIDATION.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),'utf-8')
final={'rootExplicitFinalPins':True,'candidate':C.name,'unifiedPinsSha256':sha(C/'UNIFIED-PINS.json'),
    'stagedSha256':sha(C/'STAGED.json'),'manifestSha256':stage['manifest_sha256'],'releaseId':stage['release_id'],
    'unifiedFileCount':len(pins['files']),'releaseFileCount':stage['files'],'launcherSha256':sha(Path(stage['launcher'])),
    'validationSha256':sha(D/'AGGREGATE-VALIDATION.json')}
(D/'FINAL-PINS.json').write_text(json.dumps(final,ensure_ascii=False,indent=2),'utf-8')
print(json.dumps({'status':receipt['status'],'validationSha256':sha(D/'AGGREGATE-VALIDATION.json'),'finalPinsSha256':sha(D/'FINAL-PINS.json')}))
