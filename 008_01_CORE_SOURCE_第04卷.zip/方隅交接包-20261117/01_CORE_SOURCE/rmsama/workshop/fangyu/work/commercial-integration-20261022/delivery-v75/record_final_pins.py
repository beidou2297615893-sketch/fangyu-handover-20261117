from pathlib import Path
import hashlib,json
D=Path(__file__).resolve().parent;P=D.parents[2];F=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v75'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
u=json.loads((F/'UNIFIED-PINS.json').read_text('utf-8'));s=json.loads((F/'STAGED.json').read_text('utf-8'))
r=Path(s['release']);m=json.loads((r/'RELEASE.json').read_text('utf-8'))
out={'rootExplicitFinalPins':True,'candidate':'candidate-unified-v75','unifiedPinsSha256':sha(F/'UNIFIED-PINS.json'),
 'stagedSha256':sha(F/'STAGED.json'),'manifestSha256':sha(r/'RELEASE.json'),'releaseId':s['release_id'],
 'unifiedFileCount':len(u['files']),'releaseFileCount':len(m['files']),
 'launcherSha256':sha(F/'project/work/ui-native-r57'/('run_candidate.'+s['release_id']+'.py'))}
assert out['unifiedPinsSha256']=='b8168fdab20627f3daf96ac18b82a99071ed8f9ff9363b73decca990cc5ef0fc'
target=D/'FINAL-PINS.json';assert not target.exists();target.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(out));print('ROOT_PINS_SHA256='+sha(target))
