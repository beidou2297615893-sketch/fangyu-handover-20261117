"""Keep the tested installer, pin v73 and the intact current v72 rollback."""
from pathlib import Path
import ast,hashlib,json
D=Path(__file__).resolve().parent;W=D.parent
source=W/'delivery-v72/install_verified_entry.py'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(source)=='02a608ec3662823d399e779e32d23f233503ead1e969b6a3c61681f3394558ee'
raw=source.read_text('utf-8');tree=ast.parse(raw)
pins=json.loads((D/'FINAL-PINS.json').read_text('utf-8'))
summary_path=D/'frozen-native/SUMMARY.json'
summary=json.loads(summary_path.read_text('utf-8'))
assert summary['candidate']==pins['candidate']=='candidate-unified-v73'
assert summary['unifiedPinsSha']==pins['unifiedPinsSha256']
assert summary['totalHttpGroups']>=32 and not summary['realModelCalls'] and not summary['realPlatformRequests'] and not summary['productionAccess']
evidence={}
for name,expected in summary['evidenceSha256'].items():
    assert Path(name).name==name and name.endswith('.json')
    path=D/'frozen-native'/name; assert sha(path)==expected
    evidence['frozen-native/'+name]=expected
evidence['frozen-native/SUMMARY.json']=sha(summary_path)
assert len(evidence)>=5
spec={'release_id':pins['releaseId'],'unified_sha':pins['unifiedPinsSha256'],
      'files':pins['unifiedFileCount'],'release_sha':pins['manifestSha256'],
      'candidate_launcher_sha':pins['launcherSha256'],'recovery_checkpoint':True,
      'evidence':evidence,'delivery':'delivery-v73','http_groups':summary['totalHttpGroups'],
      'staged_sha':pins['stagedSha256']}
new_constants={
    'ACCEPTED':{pins['candidate']:spec},
    'OLD_LAUNCHER_SHA':'ee6c06f25c9cacd5927bd3c90f6246da184150aee101f59db19e222d4eea8797',
    'OLD_FROZEN_SHA':'9da70aed55d22c33b1e76ebb2362defcaaf61a7f25feea64e3542919ab929160',
}
lines=raw.splitlines(keepends=True);changes=[]
for node in tree.body:
    if isinstance(node,ast.Assign):
        for target in node.targets:
            if isinstance(target,ast.Name) and target.id in new_constants:
                changes.append((node.lineno-1,node.end_lineno,target.id+' = '+repr(new_constants[target.id])+'\n'))
assert len(changes)==3
for start,end,value in sorted(changes,reverse=True):lines[start:end]=[value]
text=''.join(lines)
old="expected = P / 'work/commercial-integration-20261022/delivery-v72'"
assert text.count(old)==1
text=text.replace(old,"expected = P / 'work/commercial-integration-20261022/delivery-v73'")
anchor="    closure(F / 'candidate-unified-v65', V65_UNIFIED_SHA, V65_ROLLBACK_FILES)"
extra="    closure(F / 'candidate-unified-v72', '1a1c49af3fee70e1270a5fe71e12d24b6a35480814dc16c7a02205ae0d139295', 3152)"
assert text.count(anchor)==1;text=text.replace(anchor,anchor+'\n'+extra)
compile(text,'install_verified_entry.py','exec')
oldfunc={n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)}
newfunc={n.name:n for n in ast.parse(text).body if isinstance(n,ast.FunctionDef)}
for name in oldfunc:
    if name not in ('check','main'):
        assert ast.dump(oldfunc[name],include_attributes=False)==ast.dump(newfunc[name],include_attributes=False),name
newcheck=newfunc['check'];added=[n for n in newcheck.body if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name) and n.value.func.id=='closure' and 'candidate-unified-v72' in ast.unparse(n)]
assert len(added)==1;newcheck.body.remove(added[0])
assert ast.dump(oldfunc['check'],include_attributes=False)==ast.dump(newcheck,include_attributes=False)
dest=D/'install_verified_entry.py';assert not dest.exists();dest.write_text(text,encoding='utf-8',newline='\n')
record={'status':'ROOT_REVIEWED_EXACT_V73_NEXT_LAUNCH_INSTALLER_PREPARED',
        'sourceScriptSha256':sha(source),'scriptSha256':sha(dest),'candidate':pins['candidate'],
        'fixedEvidenceCount':len(evidence),'originalCasBackupRollbackFunctionsUnchanged':True,
        'checkOnlyStrengthenedWithCurrentV72Closure':True,'currentV72AndOlderV65RollbackRetained':True,
        'canonicalInstallPerformed':False,'runningV72Restarted':False,
        'intendedAction':'Update next-launch entry only, leaving the current immutable v72 process running.'}
(D/'INSTALLER-REVIEW.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps(record))
