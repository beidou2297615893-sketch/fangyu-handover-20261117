from pathlib import Path
import hashlib, json, shutil
from datetime import datetime, timezone

D = Path(__file__).resolve().parent
W = D.parent
P = W.parents[1]
F = P / 'work/parallel-integration-20261018/final-integration'
S = F / 'stage-02/project'
C = W / 'platform-preflight-mode-lease-candidate'
INDEPENDENT_SHA = 'aec11172c01f9701dc310d7fde71169195ce9b1c2d85a8bf9b8f2628007583d5'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

assert INDEPENDENT_SHA is not None, 'Independent final acceptance required'
independent = W / 'platform-preflight-mode-lease-independent-review/FINAL-RECEIPT.json'
assert sha(independent) == INDEPENDENT_SHA
assert sha(C / 'SEALED.json') == '0d887c8140d2098df04c607421c69be3bf022b7f53c61ba9710c1da634ac38d5'
assert sha(C / 'FINAL-RECEIPT.json') == '0a5b5d3b6c4dc715a1fa9c34f0495cd8458511163e60871921b42e965119c15f'
assert sha(C / 'SOURCE-PINS.json') == '8bf45d090b869ea8342d09f683fa11ba75cbb881025c78571b48a3a59de33b04'
assert sha(C / 'CHANGES.patch') == '193abdbede40e50524dfbfa8f3fb25f9ae38fc095025c18dd1937f7cd6634a38'
pins = json.loads((C / 'SOURCE-PINS.json').read_text('utf-8'))['files']
assert len(pins) == 4
assert not (D / 'MERGE.json').exists()
for item in pins:
    target = S / item['path']
    candidate = C / 'candidate' / item['path']
    original = F / 'candidate-unified-v75/project' / item['path']
    assert sha(target) == sha(original) == item['beforeSha256'], item['path']
    assert sha(candidate) == item['afterSha256'], item['path']
    backup = D / 'source-before' / item['path']
    assert not backup.exists()
for item in pins:
    backup = D / 'source-before' / item['path']
    backup.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(S / item['path'], backup)
    assert sha(backup) == item['beforeSha256']
try:
    for item in pins:
        (S / item['path']).write_bytes((C / 'candidate' / item['path']).read_bytes())
        assert sha(S / item['path']) == item['afterSha256']
except Exception:
    for item in pins:
        shutil.copyfile(D / 'source-before' / item['path'], S / item['path'])
    raise
report = {
    'status': 'ROOT_MERGED_ACCEPTED_FOUR_SOURCE_FILES',
    'atUtc': datetime.now(timezone.utc).isoformat(),
    'authorReceiptSha256': sha(C / 'FINAL-RECEIPT.json'),
    'independentReceiptSha256': sha(independent),
    'files': pins,
    'canonicalOrProductionWritten': False,
    'f75Written': False,
}
(D / 'MERGE.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(report, ensure_ascii=False))
