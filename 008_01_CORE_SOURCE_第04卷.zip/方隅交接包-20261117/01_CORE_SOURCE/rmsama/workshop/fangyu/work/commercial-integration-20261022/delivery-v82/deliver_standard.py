"""Deliver the reviewed technical installer locally, preserving prior files."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, shutil, uuid

D=Path(__file__).resolve().parent
W=D.parent
P=D.parents[2]
A=W/'f82-standard-package-candidate'
R=W/'f82-standard-package-independent-review'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for path,pin in [
    (A/'FINAL-RECEIPT.json','69d0b8946a3da256e4101cd3842c7fa8eb294843796518caaa63faffc83a377b'),
    (A/'SEALED.json','e770983443035f71ddbb05d8f07f60305d60a75d1cd1e425048f5fd5f5d676a5'),
    (R/'FINAL-RECEIPT.json','bc62c902646dd9606661a374a78c5bba3324331d7df472019e096454e90adcae'),
    (R/'SEALED.json','4271d17f507d2bed71a9b9a39682d5342e6089aafac9f77b4eaf4f055c413495'),
    (D/'INSTALLATION-FINAL.json','aea29dc53636aa8ce69de480bd9a67c80e40fb36f38103ab147d24faddd88665')]:
    assert sha(path)==pin,path
source=A/'standard-held-clean-v82/FangyuWorkbenchSetup-standard-held-clean-v82.exe'
expected='90ae659a9bab079c50b45ec68b341ab2cc72e134aac32d6f12aedd8be5a5b488'
assert sha(source)==expected and source.stat().st_size==307396837
out=P/'outputs/三合一交付'
target=out/'方隅工作台安装程序.exe'
old_expected='c75279f48e68088fb27cb9013d3c0e91e7590d3f24ee22a8b763c03d64ab40a8'
assert out.is_dir() and out.resolve().is_relative_to((P/'outputs').resolve())
assert target.is_file() and sha(target)==old_expected
for path in (out,target,*out.parents):
    assert not path.is_symlink() and not getattr(path.lstat(),'st_file_attributes',0)&0x400
previous=D/'previous-human-delivery'
assert not previous.exists()
previous.mkdir()
for name in ('方隅工作台安装程序.exe','当前交付核对.md','安装与使用说明.md'):
    old=out/name
    if old.exists():
        shutil.copy2(old,previous/name)
staged=D/('standard-delivery-'+uuid.uuid4().hex+'.tmp')
shutil.copyfile(source,staged)
assert sha(staged)==expected and sha(target)==old_expected
os.replace(staged,target)
assert sha(target)==expected
review='''# 方隅工作台当前交付核对

本机下一次启动入口已经更新；当前窗口没有被强制关闭。从原桌面快捷方式正常重开即可加载，不需要为了本轮更新重新安装。

本轮新增：本人确认访谈阶段小结、复盘经验的采用与撤回、公开检索结果选存待核资料、直播单轮读取与原分析队列的接线、私信固定命令接线。内容排程、提字配音、扫描PDF、客户、账号、SOP和导入导出继续保留。

本机更新前后七类业务内容与账号元数据核对一致：3个账号、1888条评论、40个任务、1794条已存DeepSeek分析等均保留；另有一份本轮最新完整数据库备份。没有恢复旧备份覆盖当前数据。软件内的判断仍使用原DeepSeek结果和人工更正，未用Codex复核悄悄覆盖。

本机原入口检查、自检、原业务和新功能合版测试已通过，完整页面也做了宽窄窗口测试。这些测试使用独立数据及受控回执，不能当作真实平台已经采集、发信或发布的证明；本人实际原生窗口首次打开仍待确认。

同文件夹安装程序约307MB，已重新编译并独立检查，不需要独显或本地大模型。它目前用于其他电脑的技术验收，仍保留原平台连接用途限制，尚不能当作已经放行的商业交付版。编译后的抖音组件路径已修正，但路径正确不会自动解除用途限制。当前这台电脑继续用原快捷方式与原工作区。

真实私信送达、平台历史消息、直播实采、实际发布、第二台实体电脑，以及录音转写和多角色完整编排等余项仍未完成全部验收。公开检索当前是摘要与来源链接，原文未抓取，保存后仍需核实和明确选择引用。
'''
guide='''# 安装与使用说明

这台电脑：保存正在编辑的内容后，正常关闭工作台，再从原桌面“方隅工作台”快捷方式重开。账号、客户、旧任务与断点保留；无需再运行安装程序。

开始采集前确认采集账号，准备回复时确认发送账号。已有客户归门店保存，切换或从软件移除账号不会删除历史客户。平台验证码、人脸和扫码仍需本人按页面完成。

内容运营：访谈里可以填写本人阶段小结后确认继续；复盘经验需要本人采用，并在下一次任务里明确选择使用，也可以撤回。公开检索只搜索明确填写的检索词，选择结果后存为待核参考；它不会自动变成门店事实，也不会自动生成或发布内容。

多样化获客里的直播入口已接开发流程：明确选择账号和直播窗口，单轮读取后进入原分析队列。真实原生直播子窗和平台实采尚未验通，不承诺十房并发；私信真实发送和平台历史消息同样未完成验收。保存草稿或计划不会替本人自动发送。

其他电脑：同文件夹安装程序供64位Windows技术验收，尚有平台连接用途限制。不要把它当作已经放行的商业版本分发承诺。第二台实体电脑的真实原生首启、系统组件和账号连接仍待验证；安装程序不含这台电脑的客户、账号或登录会话。
'''
(out/'当前交付核对.md').write_text(review,'utf-8')
(out/'安装与使用说明.md').write_text(guide,'utf-8')
receipt={'status':'FIXED_F82_RESTRICTED_TECHNICAL_INSTALLER_DELIVERED_LOCALLY',
    'createdUtc':datetime.now(timezone.utc).isoformat(),'path':str(target),'folder':str(out),
    'bytes':target.stat().st_size,'sha256':sha(target),'rootActualInstallationSha256':sha(D/'INSTALLATION-FINAL.json'),
    'authorFinalSha256':sha(A/'FINAL-RECEIPT.json'),'independentFinalSha256':sha(R/'FINAL-RECEIPT.json'),
    'oldHumanDeliveryBackedUp':True,'atomicInstallerReplacement':True,
    'localOnlyNoExternalPublication':True,'ordinaryHeldScopeStillHeld':True,
    'realPlatformOrMessagingCalls':0,'secondPhysicalComputerVerified':False,'fullCommercialGoalComplete':False}
(D/'STANDARD-DISTRIBUTION-DELIVERY.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),'utf-8')
print(json.dumps({'status':receipt['status'],'bytes':receipt['bytes'],'sha256':receipt['sha256']}))
