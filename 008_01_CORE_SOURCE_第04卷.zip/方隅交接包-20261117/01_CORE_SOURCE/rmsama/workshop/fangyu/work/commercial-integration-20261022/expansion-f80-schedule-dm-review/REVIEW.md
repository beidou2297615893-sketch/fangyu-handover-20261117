F80冻结合版G11/私信代表回归通过，未安装、未改源。真实固定3328源码和282资源的完整文件集合及逐SHA在执行前后均一致；所有测试直接读F80冻结源，无作者project/state复制。G11原factory脚本和13项UI断言原样；DM仅两行project/stage输入适配，5组工厂/15项UI原断言全部保留。

G11代表4组：safety保原unknown intent/key并禁止换key重派；reopen保持久计划与原编号、撤回RAM授权和切店授权；contention原账号模式互斥与未知发布阻回复；recover-claim保原prepared intent/key、旧worker迟到不能覆盖新审批。50/100压力矩阵未重跑。

DM实际原verify/read_public/依赖/create_backend/Core/Store/HTTP+受控NodeCLI+自有loopback Bridge五组绿：默认hold/当前owner店权限；unknown原key单次传输及跨账号原customer claim；原评论来源CAS/监听删除互斥/显式停止；原factory真实关闭重开及账号删除后原请求查询；退休proof与当前权限负例。完整index/fit/iframe真实headless Chromium双宽1255/390共15项绿，原unknown只读卡无发送入口，重复查原编号零重派，另一账号不继承原请求。

G11完整index/fit双宽13项绿：打开不建计划、固定本人稿件版本/账号/时间、确认后才arm、默认原publication hold准确显示、暂停和换账号不移植草稿或启动，字号/横向溢出均保原阈值。所有自有服务均关闭。

边界：G11正向使用明确自有OwnedPublishPort及合成grant/session，DM正向仅自有临时fixture设备/适配器许可和loopback Bridge；封源及正式hold未变，不能当真实平台发布/私信已通。XHS DM传输/平台历史分页仍无已验证正式能力；无Native窗口/生产profile/真实平台/模型/付费。未验证普通编译包/第二电脑/真实账号；未重跑旧全量或媒体作者矩阵，不把媒体自测记作本次独审。
