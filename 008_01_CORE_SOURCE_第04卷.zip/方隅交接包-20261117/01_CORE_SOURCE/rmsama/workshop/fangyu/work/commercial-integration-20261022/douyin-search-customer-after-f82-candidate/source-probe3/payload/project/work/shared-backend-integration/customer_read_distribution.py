"""Host-bound, material-checked customer read purposes; never account authority.

The Native host supplies manifest-verified bytes. No company flag, HTTP field,
QA permit, source-mode fallback, or send purpose can create this capability.
"""
from copy import deepcopy
from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import stat
import sys

_SCOPE = 'customer_distribution_read'
_SCHEMA = 'fangyu_customer_read_material_index_v1'
_PURPOSES = frozenset(('douyin_owned_connection', 'douyin_owned_video_comments',
    'douyin_owned_keyword_search_page'))
_RUNTIME_PURPOSE = 'xiaohongshu_guarded_read'
_CONNECTION_LIMITS = {'account_network': 'fixed_identity_js_only',
    'native_loaded_bytes_verified': False, 'public_send_grant': False}
_COMMENT_LIMITS = {'main_page_only': True, 'max_comments': 20, 'search': False,
    'reply': False, 'dm': False, 'platform_identity_before_after': True,
    'real_platform_verified': False}
_SEARCH_LIMITS = {'first_page_only': True, 'max_items': 20, 'offset': 0,
    'search': True, 'comments': False, 'reply': False, 'dm': False,
    'platform_identity_before_after': True, 'real_platform_verified': False,
    'production_approval': False, 'distribution_approval': False}
_TOKEN = object()


def _digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
        separators=(',', ':'), allow_nan=False).encode('utf-8')).hexdigest()


def _parse(raw):
    def pairs(items):
        value = {}
        for key, item in items:
            if key in value: raise ValueError('customer_read_review_pending')
            value[key] = item
        return value
    if type(raw) is not bytes or not 1 <= len(raw) <= 1048576:
        raise ValueError('customer_read_review_pending')
    return json.loads(raw.decode('utf-8'), object_pairs_hook=pairs,
        parse_constant=lambda value: (_ for _ in ()).throw(ValueError('invalid number')))


def _company(config):
    if type(config) is not dict: raise ValueError('customer_read_review_pending')
    runtime, managed = config.get('runtime'), config.get('managedWorkspace')
    if (type(runtime) is not dict or type(managed) is not dict
            or config.get('edition') != 'customer' or config.get('personalMode') is not False
            or config.get('authMode') != 'managed' or runtime.get('public_send_hold') is not True
            or runtime.get('role') != 'local_assistant_only'
            or runtime.get('ui_entry') != 'employee_workspace'
            or any(key in runtime for key in ('private_evaluation', 'private_evaluation_session_id',
                'platform_qa_device_id', 'portable_employee_release'))):
        raise ValueError('customer_read_review_pending')
    return {key: deepcopy(config.get(key)) for key in
        ('id', 'edition', 'personalMode', 'authMode', 'releaseVersion', 'platforms')} | {
        'environment_id': managed.get('environment_id'), 'endpoint': managed.get('endpoint'),
        'role': runtime['role'], 'ui_entry': runtime['ui_entry'],
        'public_send_hold': True, 'executable': runtime.get('executable'),
        'cli_source_sha256': runtime.get('cli_source_sha256'),
        'xiaohongshu_automation': runtime.get('xiaohongshu_automation')}


def _material_file(path, root):
    # Reuse the original root containment check, then enforce the compiled
    # host's complete ancestry and single-link regular-file boundary as well.
    from core.runtime_license_policy import _plain
    checked = _plain(path, root)
    for part in (checked, *checked.parents):
        info = part.lstat()
        if part.is_symlink() or getattr(info, 'st_file_attributes', 0) & 0x400:
            raise ValueError('customer_read_review_pending')
    info = checked.stat()
    if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
        raise ValueError('customer_read_review_pending')
    return checked


def _relative(value):
    return (type(value) is str and value and '\\' not in value and ':' not in value
        and all(part not in ('', '.', '..') for part in value.split('/')))


def _same_limits(value, expected):
    return (type(value) is dict and value == expected
        and all(type(value[key]) is type(item) for key, item in expected.items()))


@dataclass(frozen=True, slots=True, repr=False)
class CustomerReadAuthority:
    _token: object
    _project: Path
    _release: Path
    _index_raw: bytes
    _documents: tuple

    def _state(self, server):
        from app import AppServer
        from core.runtime_license_policy import _plain, _file_hash
        if (self._token is not _TOKEN or type(server) is not AppServer
                or not getattr(sys, 'frozen', False) or server.closing
                or not server.employee_workspace_mode
                or getattr(server, 'self_operating_read', False)):
            raise ValueError('customer_read_review_pending')
        project = Path(sys.executable).resolve().parent / 'project'
        if project != self._project or project.resolve() != project:
            raise ValueError('customer_read_review_pending')
        source = project / 'work/ui-runtime-r55/src'
        roots = {'source': source, 'vendor': self._release / 'resources/platform-runtime/vendor-src',
            'douyin_runtime': source.parent / 'work/runtime/douyin-bridge', 'release': self._release}
        if (Path(server.core.resources_dir) != source / 'resources'
                or Path(server.bridge.runtime) != roots['douyin_runtime']
                or not self._release.is_relative_to(project / 'work/ui-native-r57/releases')):
            raise ValueError('customer_read_review_pending')
        index = _parse(self._index_raw)
        if (set(index) != {'schema', 'scope', 'company_binding', 'executable', 'reviews'}
                or index['schema'] != _SCHEMA or index['scope'] != _SCOPE
                or index['company_binding'] != _company(server.company)
                or index['executable'] != Path(sys.executable).name
                or index['executable'] != server.company['runtime'].get('executable')
                or type(index['reviews']) is not list or not 1 <= len(index['reviews']) <= len(_PURPOSES) + 1):
            raise ValueError('customer_read_review_pending')
        index_path = _material_file(self._release / 'resources/customer-read/review-index.json', self._release)
        if index_path.read_bytes() != self._index_raw:
            raise ValueError('customer_read_review_pending')
        records, seen = {}, set()
        for row in index['reviews']:
            if (type(row) is not dict or set(row) != {'purpose', 'path', 'sha256', 'bytes'}
                    or row['purpose'] not in _PURPOSES | {_RUNTIME_PURPOSE} or row['purpose'] in seen
                    or not _relative(row['path']) or type(row['bytes']) is not int
                    or not 1 <= row['bytes'] <= 1048576
                    or type(row['sha256']) is not str or not re.fullmatch('[0-9a-f]{64}', row['sha256'])):
                raise ValueError('customer_read_review_pending')
            path = _material_file(self._release / row['path'], self._release)
            raw = path.read_bytes()
            if len(raw) != row['bytes'] or hashlib.sha256(raw).hexdigest() != row['sha256']:
                raise ValueError('customer_read_review_pending')
            if (row['purpose'], raw) not in self._documents:
                raise ValueError('customer_read_review_pending')
            records[row['purpose']] = (row, _parse(raw)); seen.add(row['purpose'])
        return index, roots, records, _material_file, _file_hash

    def scope_for(self, server):
        try:
            self._state(server)
            return _SCOPE
        except (ValueError, TypeError, KeyError, OSError, AttributeError):
            return None

    def resolve(self, server, purpose):
        try:
            if purpose not in _PURPOSES: return None
            index, roots, records, plain, file_hash = self._state(server)
            if purpose not in records: return None
            row, review = records[purpose]
            expected = (_CONNECTION_LIMITS if purpose == 'douyin_owned_connection' else
                _SEARCH_LIMITS if purpose == 'douyin_owned_keyword_search_page' else _COMMENT_LIMITS)
            if (set(review) != {'schema', 'scope', 'purpose', 'company_binding', 'limits',
                    'materials', 'distribution_basis', 'evidence'}
                    or review['schema'] != 'fangyu_customer_read_purpose_review_v1'
                    or review['scope'] != _SCOPE or review['purpose'] != purpose
                    or review['company_binding'] != index['company_binding']
                    or not _same_limits(review['limits'], expected)
                    or type(review['materials']) is not list or not 1 <= len(review['materials']) <= 1024
                    or review['evidence'] != {'review_layer':'license_and_source',
                        'real_platform_verified':False,'native_loaded_bytes_verified':False,'public_send_grant':False}):
                raise ValueError('customer_read_review_pending')
            basis = review['distribution_basis']
            if (type(basis) is not dict or set(basis) != {'reviewer_ref', 'reviewed_at',
                    'license', 'license_material', 'permission', 'evidence_material'}
                    or basis['license'] != 'MIT' or basis['permission'] != 'scoped_customer_read_only'
                    or not isinstance(basis['reviewer_ref'], str) or not basis['reviewer_ref'].strip()):
                raise ValueError('customer_read_review_pending')
            stamp = datetime.fromisoformat(basis['reviewed_at'].replace('Z', '+00:00'))
            if stamp.tzinfo is None or stamp > datetime.now(timezone.utc):
                raise ValueError('customer_read_review_pending')
            seen, facts = set(), []
            for item in review['materials']:
                if (type(item) is not dict or set(item) != {'root', 'path', 'sha256', 'bytes', 'role'}
                        or item['root'] not in roots or not _relative(item['path'])
                        or (item['root'], item['path']) in seen or type(item['bytes']) is not int
                        or item['bytes'] < 0 or type(item['sha256']) is not str
                        or not re.fullmatch('[0-9a-f]{64}', item['sha256'])
                        or item['role'] not in ('source', 'dependency', 'license', 'review_evidence')):
                    raise ValueError('customer_read_review_pending')
                path = plain(roots[item['root']] / item['path'], roots[item['root']])
                before = path.stat()
                if before.st_size != item['bytes'] or file_hash(path).lower() != item['sha256']:
                    raise ValueError('customer_read_review_pending')
                after = plain(roots[item['root']] / item['path'], roots[item['root']]).stat()
                if (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) != (
                        after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns):
                    raise ValueError('customer_read_review_pending')
                seen.add((item['root'], item['path'])); facts.append(item)
            required = {('vendor', 'app.py'), ('vendor', 'account_connections.py'),
                ('vendor', 'assistant/douyin_connection_service.py'),
                ('source', 'core/douyin_comments_policy.py'), ('source', 'core/runtime_license_policy.py'),
                ('release', 'ui_native_host.py'),
                ('release', 'resources/platform-runtime/platform_runtime.py'),
                ('release', 'resources/platform-runtime/customer_read_distribution.py'),
                ('douyin_runtime', 'node.exe'), ('douyin_runtime', 'LICENSE')}
            if purpose == 'douyin_owned_keyword_search_page':
                required |= {('source', name) for name in (
                    'core/douyin_search_policy.py', 'core/douyin_owned_search.py',
                    'core/douyin_owned_comments.py', 'core/platform_reads.py',
                    'core/adapters.py', 'core/douyin_customer_tasks.py', 'core/engine.py',
                    'core/pipeline.py', 'core/store.py', 'core/continuous.py',
                    'assistant/business.py', 'assistant/product_workspace.py', 'bridge.py')}
                required.add(('vendor', 'assistant/business.py'))
                required |= {('douyin_runtime', name) for name in (
                    'cli.js', 'lib/commands/search.js', 'lib/commands/index.js',
                    'lib/client/bridge-client.js', 'lib/server/router.js', 'lib/server/registry.js',
                    'scripts/douyin.user.js')}
            required |= {(item['root'], item['path']) for item in (
                basis['license_material'], basis['evidence_material']) if type(item) is dict
                    and set(item) == {'root', 'path'}}
            if (not required <= seen
                    or basis['license_material'] != {'root': 'douyin_runtime', 'path': 'LICENSE'}
                    or self._state(server)[0] != index):
                raise ValueError('customer_read_review_pending')
            return {'purpose': purpose, 'scope': _SCOPE,
                'revision': _digest([row['sha256'], index['company_binding'], facts])}
        except (ValueError, TypeError, KeyError, OSError, AttributeError):
            return None

    def runtime_license_review(self, server, purpose):
        # Return the original schema only. The original RuntimeLicensePolicy
        # retains artifact/guard/tree/material checks and the frozen exe root.
        try:
            if purpose != _RUNTIME_PURPOSE: return None
            index, roots, records, plain, file_hash = self._state(server)
            if purpose not in records: return None
            value = records[purpose][1]
            if (type(value) is not dict or value.get('kind') != 'runtime_component_use_review'
                    or value.get('route') != 'guarded_cli_v1' or value.get('usage_scope') != _SCOPE
                    or value.get('company_id') != server.company.get('id')):
                return None
            return deepcopy(value)
        except (ValueError, TypeError, KeyError, OSError, AttributeError):
            return None


def is_authority(value):
    return type(value) is CustomerReadAuthority and value._token is _TOKEN


def load_authority(project_root, release_root, index_raw, read_document):
    """Called only by the manifest-verifying Native host, never public JSON."""
    index = _parse(index_raw)
    if type(index) is not dict or type(index.get('reviews')) is not list:
        raise ValueError('customer_read_review_pending')
    documents = []
    for row in index['reviews']:
        if type(row) is not dict or not _relative(row.get('path')):
            raise ValueError('customer_read_review_pending')
        documents.append((row.get('purpose'), read_document(row['path'])))
    return CustomerReadAuthority(_TOKEN, Path(project_root).resolve(),
        Path(release_root).resolve(), index_raw, tuple(documents))
