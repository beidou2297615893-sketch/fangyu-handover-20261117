from pathlib import Path
import ast
W=Path(__file__).resolve().parent;PRE=W.parent/'customer-read-purpose-after-f82-candidate'
t=(PRE/'probe_body.py.in').read_text('utf-8')
t=t[:t.index("    original_douyin=runtime.server.company")]
t=t.replace('import uuid','import uuid,subprocess,shlex')
t=t.replace('backend = server = None','backend = server = None\nadmission_checks=[]')
t=t.replace("    if event in ('os.system','os.startfile','os.posix_spawn','subprocess.Popen'):\n        raise RuntimeError('No platform, browser or subprocess in scoped read admission probe')", """    if event=='subprocess.Popen':
        argv=args[1];argv=[part.strip('"') for part in shlex.split(argv,posix=False)] if isinstance(argv,str) else argv
        br=P/'work/ui-runtime-r55/work/runtime/douyin-bridge'
        assert Path(argv[0]).resolve()==br/'node.exe',argv
        assert Path(argv[1]).resolve() in (br/'cli.js',W/'qa-fixtures/search_bridge_fixture.cjs'),argv
        assert Path(args[2]).resolve().is_relative_to(OUT) or (Path(argv[1]).resolve()==br/'cli.js' and argv[2]=='connections' and Path(args[2]).resolve()==br),args
        if Path(argv[1]).resolve()==br/'cli.js' and argv[2] in ('search','comment-page'):
            from core import adapters as adapter_module
            account_root=Path(args[2]).resolve()
            mode=core.account_mode_status(account_root.name,user['tenant_id'])
            assert mode['mode']=='collection' and mode['status']=='active' and mode['owner'].startswith('batch:')
            assert account_root in getattr(adapter_module._account_lock_owner,'paths',set())
            channel=core.adapters.channel_locks.get('douyin:'+str(account_root.parent));assert channel and channel.locked(),'Original shared Douyin Bridge channel not held'
            foreign=type(core.continuous.leases)(core.store,'foreign-search-synthetic-runtime')
            try:foreign.acquire(account_root.name,user['tenant_id'],'replies','foreign-reply')
            except ValueError:pass
            else:raise AssertionError('Original atomic collection lease bypassed')
            admission_checks.append({'command':argv[2],'originalBatchLease':True,'originalOsAndChannelLocks':True,'foreignReplyRejected':True})
        processes.append(list(argv))
    if event in ('os.system','os.startfile','os.posix_spawn'):
        raise RuntimeError('No platform/browser process')""")
t=t.replace("    assert DouyinSearchPolicy(runtime.server).resolve() is None\n    assert runtime.server._customer_distribution_purpose('douyin_owned_keyword_search_page') is None", """    search_review=DouyinSearchPolicy(runtime.server).resolve()
    assert search_review and search_review['purpose']=='douyin_owned_keyword_search_page'
    assert runtime.server._customer_distribution_purpose('douyin_owned_keyword_search_page') is not None""")
t=t.replace("'searchAndXhsPending':True", "'searchIndependentPurposeResolved':True,'xhsPending':True")
t=t.replace("    device_calls=[];held=[False];revoked=[False]", "    device_calls=[];held=[False];revoked=[False];commands=[];outcomes={}")
t=t.replace("return {'safety_hold':held[0],'command':None,'poll_after':1}","return {'safety_hold':held[0],'command':commands.pop(0) if commands and not data.get('busy') else None,'poll_after':1}")
t=t.replace("            if operation in ('contact_events_sync','contact_responses_sync'):","""            if operation=='device_result':outcomes[data['command_id']]=deepcopy(data);return {'acknowledged':True}
            if operation in ('contact_events_sync','contact_responses_sync'):""")
t+=(W/'task_probe_tail.py.in').read_text('utf-8')
ast.parse(t);(W/'probe_body.py.in').write_text(t,'utf-8')
entry=(W/'prepare_entry.py').read_text('utf-8')
needle="prefix=(B/'standard_loader_prefix.py').read_text('utf-8')"
entry=entry.replace(needle,"exact_write(B/'payload/qa-fixtures/search_bridge_fixture.cjs',(W/'search_bridge_fixture.cjs').read_bytes())\n"+needle)
(W/'prepare_entry.py').write_text(entry,'utf-8')
print('Own original-factory representative body prepared')
