from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
D=Path(__file__).resolve().parent;W=D.parent;P=D.parents[2];N=P/'work/ui-native-r57'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before=json.loads((D/'PROTECTED-BUSINESS-BEFORE-INSTALL.json').read_text('utf-8'))
after=json.loads((D/'PROTECTED-BUSINESS-AFTER-INSTALL.json').read_text('utf-8'))
diag=json.loads((D/'ACTUAL-ENTRY-DIAGNOSTICS.json').read_text('utf-8'))
assert after['sameAsBeforeInstall'] and after['status']=='PASS_CURRENT_BUSINESS_AND_ACCOUNT_METADATA_UNCHANGED'
assert diag['status']=='PASS_INSTALLED_ORIGINAL_CANONICAL_DIAGNOSTICS_NOT_NATIVE_FIRST_START'
assert sha(N/'run_workbench.py')==diag['launcherSha256']=='8a5f57b6f243b3c0a01099b377d650e3452839a46b608a5ca6c2705d27a2eebd'
assert sha(N/'FROZEN.json')==diag['frozenSha256']=='c4f2d085c491344bd382e12fb3e13d43d91892d849a93dcfde0b4c74cbcffb26'
assert sha(N/'state/production-workspace.json')==diag['bindingSha256']==before['bindingSha256']
approval=json.loads((W/'f81-next-entry-candidate/ROOT-ENTRY-APPROVAL.json').read_text('utf-8'))
assert approval['onlyReviewedBooleanChanged'] and approval['afterSha256']=='b5f2ea5da66e3c902aaaac0bd11b03e8bbb2b7b9c5d83ee3c4b096e345b6a523'
evidence=[]
for name in ('FINAL-PINS.json','AGGREGATE-VALIDATION.json','NEXT-ENTRY-ROOT-REVIEW.json',
             'ACTUAL-ENTRY-DIAGNOSTICS.json','ACTUAL-ENTRY-CHECK.json','ACTUAL-ENTRY-SELF-TEST.json',
             'PROTECTED-BUSINESS-BEFORE-INSTALL.json','PROTECTED-BUSINESS-AFTER-INSTALL.json','SOURCE-MERGE-APPLIED.json'):
    evidence.append({'path':name,'sha256':sha(D/name),'bytes':(D/name).stat().st_size})
receipt={'status':'INSTALLED_F81_NEXT_LAUNCH_AND_ACTUAL_ORIGINAL_ENTRY_DIAGNOSTICS_PASS',
    'createdUtc':datetime.now(timezone.utc).isoformat(),'candidate':'candidate-unified-v81',
    'release':'ui-r57-20261023T065644Z-af092274','sourceFiles':3332,'resources':284,
    'launcherSha256':diag['launcherSha256'],'frozenSha256':diag['frozenSha256'],'bindingSha256':diag['bindingSha256'],
    'accountRecords':after['accountRecords'],'allSevenBusinessDigestsUnchanged':after['sameAsBeforeInstall'],
    'businessCounts':{key:value['rows'] for key,value in after['protectedTablesAndEntities'].items()},
    'sourceBackup':'source-before','entryBackup':str(W/'f81-next-entry-candidate/next-launch-prepared/candidate-unified-v81/canonical-entry-before'),
    'oldWindowNotStoppedOrReplaced':True,'nativeHumanFirstOpenVerified':False,
    'realPlatformCollectionOrMessagingVerified':False,'scannedPdfIncluded':True,
    'ordinaryCleanDistributionStillInReview':True,'realPlatformOrModelCalls':0,
    'fullGoalComplete':False,'evidence':evidence}
target=D/'INSTALLATION-FINAL.json';assert not target.exists();target.write_text(json.dumps(receipt,ensure_ascii=False,indent=2),'utf-8')
print(json.dumps({'status':receipt['status'],'finalSha256':sha(target),'counts':receipt['businessCounts'],'accounts':receipt['accountRecords']}))
