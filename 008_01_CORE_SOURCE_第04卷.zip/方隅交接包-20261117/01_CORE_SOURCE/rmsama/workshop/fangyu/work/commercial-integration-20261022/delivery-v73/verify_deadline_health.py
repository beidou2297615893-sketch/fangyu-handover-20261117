"""One post-copy read-only health and business preservation check."""
from pathlib import Path
from datetime import datetime, timezone
import ast
import ctypes
from ctypes import wintypes
import hashlib
import http.client
import json
import subprocess
import sys

D = Path(__file__).resolve().parent
P = D.parents[2]
N = P / 'work/ui-native-r57'

def require(ok, message):
    if not ok:
        raise RuntimeError(message)

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

before = json.loads((D / 'ACTUAL-NEXT-LAUNCH-VERIFICATION.json').read_text('utf-8'))
kernel = ctypes.WinDLL('kernel32', use_last_error=True)
kernel.OpenProcess.argtypes = (wintypes.DWORD, wintypes.BOOL, wintypes.DWORD)
kernel.OpenProcess.restype = wintypes.HANDLE
kernel.GetProcessTimes.argtypes = (wintypes.HANDLE,) + (ctypes.POINTER(wintypes.FILETIME),) * 4
kernel.GetProcessTimes.restype = wintypes.BOOL
kernel.GetExitCodeProcess.argtypes = (wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD))
kernel.GetExitCodeProcess.restype = wintypes.BOOL
kernel.CloseHandle.argtypes = (wintypes.HANDLE,)
kernel.CloseHandle.restype = wintypes.BOOL
processes = {}
for pid, expected in before['runningProcessCreationTimesUnchanged'].items():
    handle = kernel.OpenProcess(0x1000, False, int(pid))
    require(bool(handle), 'Original application process unavailable')
    try:
        creation, ended, elapsed_kernel, elapsed_user = (wintypes.FILETIME() for _ in range(4))
        code = wintypes.DWORD()
        require(kernel.GetProcessTimes(handle, ctypes.byref(creation), ctypes.byref(ended), ctypes.byref(elapsed_kernel), ctypes.byref(elapsed_user)), 'Process times unavailable')
        require(kernel.GetExitCodeProcess(handle, ctypes.byref(code)), 'Process status unavailable')
        actual = {'creationFiletime': (creation.dwHighDateTime << 32) | creation.dwLowDateTime, 'stillActive': code.value == 259}
        require(actual == expected, 'Original application process changed')
        processes[pid] = actual
    finally:
        kernel.CloseHandle(handle)
connection = http.client.HTTPConnection('127.0.0.1', 57610, timeout=10)
connection.request('GET', '/')
response = connection.getresponse()
body = response.read()
connection.close()
require(response.status == 200 and b'workspace-frame' in body, 'Original application page unavailable')
require(sha(N / 'run_workbench.py') == before['canonicalLauncherSha256'], 'Next entry changed')
require(sha(N / 'FROZEN.json') == before['canonicalFrozenSha256'], 'Next release changed')

# Reuse the original audited read-only queries, extending only the evidence phase.
original = D / 'capture_business_readonly.py'
derived = D / 'capture_business_before_deadline.py'
require(not derived.exists(), 'Preserve earlier final protection script')
source = original.read_text('utf-8')
old = "assert phase in {'before-install','after-install'}"
new = "assert phase in {'before-install','after-install','before-deadline'}"
require(source.count(old) == 1, 'Original phase check changed')
updated = source.replace(old, new)
old_ast, new_ast = ast.parse(source), ast.parse(updated)
for tree in (old_ast, new_ast):
    tree.body = [node for node in tree.body if not (isinstance(node, ast.Assert) and isinstance(node.test, ast.Compare) and isinstance(node.test.left, ast.Name) and node.test.left.id == 'phase')]
require(ast.dump(old_ast, include_attributes=False) == ast.dump(new_ast, include_attributes=False), 'Read-only query implementation changed')
derived.write_text(updated, encoding='utf-8')
run = subprocess.run([sys.executable, '-E', '-B', '-X', 'utf8', str(derived), 'before-deadline'], capture_output=True, timeout=30, creationflags=subprocess.CREATE_NO_WINDOW)
require(run.returncode == 0, run.stderr.decode('utf-8', errors='replace'))
after_data = D / 'PROTECTED-BUSINESS-BEFORE-DEADLINE.json'
data = json.loads(after_data.read_text('utf-8'))
prior_data = json.loads((D / 'PROTECTED-BUSINESS-AFTER-INSTALL.json').read_text('utf-8'))
require(data['protectedTablesAndEntities'] == prior_data['protectedTablesAndEntities'], 'Protected business rows changed')
require(data['bindingSha256'] == prior_data['bindingSha256'], 'Business binding changed')
output = P / 'outputs/三合一交付/普通电脑内测版/方隅工作台_受限内测安装包.exe'
require(sha(output) == '38d3fcc329f44a38045cc1e9865d2a5312464c58fa918a3555e5a7c110ad4eb8', 'Final output changed')
frozen = P / 'work/parallel-integration-20261018/final-integration/candidate-unified-v73'
require(sha(frozen / 'UNIFIED-PINS.json') == 'c0a72be807965903a5cbb9dfee9ba6549a6157ccf622fd7df86a9ef1397a167b', 'Frozen manifest changed')
manifest = json.loads((frozen / 'UNIFIED-PINS.json').read_text('utf-8'))
expected_files = {row['path'] for row in manifest['files']}
actual_files = {path.relative_to(frozen / 'project').as_posix() for path in (frozen / 'project').rglob('*') if path.is_file()}
require(actual_files == expected_files and len(actual_files) == 3156, 'Frozen exact file set changed')
for row in manifest['files']:
    require(sha(frozen / 'project' / row['path']) == row['sha256'], 'Frozen source bytes changed: ' + row['path'])
receipt = {
    'status': 'PASS_DEADLINE_HELD_DELIVERY_WITH_ORIGINAL_RUNNING_APP_AND_BUSINESS_PRESERVED',
    'capturedAtUtc': datetime.now(timezone.utc).isoformat(),
    'actualRunningRelease': before['actualStillRunningRelease'],
    'nextLaunchRelease': before['nextLaunchRelease'],
    'processesUnchanged': processes, 'originalHttp200': True,
    'canonicalEntryUnchangedAfterOutputCopy': True,
    'protectedRowsEqualBackupAndPrePostInstall': True,
    'protectedDataReceiptSha256': sha(after_data),
    'deliveredSfxSha256': sha(output),
    'deliveryReceiptSha256': sha(D / 'CLEAN-OUTPUT-DELIVERY.json'),
    'newNativeWindowOpened': False, 'originalApplicationRestarted': False,
    'realSendsOrPaidModelCalls': 0, 'productionWritten': False, 'frozenExact3156AllHashesVerified': True, 'candidateCorrectionsMerged': False,
}
target = D / 'DEADLINE-HEALTH.json'
require(not target.exists(), 'Preserve final health receipt')
target.write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'status': receipt['status'], 'receiptSha256': sha(target)}, ensure_ascii=False))
