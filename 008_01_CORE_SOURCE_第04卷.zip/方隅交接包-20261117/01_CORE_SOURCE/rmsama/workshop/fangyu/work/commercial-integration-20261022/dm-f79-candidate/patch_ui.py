from pathlib import Path
W=Path(__file__).resolve().parent;P=W.parents[2];S=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v79/project';O=W/'source-candidate'
def replace(text,old,new):assert text.count(old)==1,(old[:100],text.count(old));return text.replace(old,new)
def put(rel,text):
 dest=O/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(text.encode('utf-8'))
prefix='work/ui-approved-implementation/ui-preview/'
rel=prefix+'backend.mjs';text=(S/rel).read_bytes().decode('utf-8');nl='\r\n' if '\r\n' in text else '\n'
text=replace(text,"const CONTACT_ACTIONS=", "const DM_ACTIONS=new Set('dm_workspace_read dm_listen_start dm_listen_stop dm_request_read dm_draft_save dm_draft_review dm_queue_prepare dm_queue_start dm_queue_cancel dm_queue_read'.split(' '));"+nl+"const CONTACT_ACTIONS=")
text=replace(text,'    const read=get||accountDeleteRead||media||','    const read=DM_ACTIONS.has(action)||get||accountDeleteRead||media||')
text=replace(text,'    const shortRead=get||accountDeleteRead||mediaRead||',"    const shortRead=['dm_workspace_read','dm_request_read','dm_queue_read'].includes(action)||get||accountDeleteRead||mediaRead||")
text=replace(text,'  return {...safety,publicContactAction:',"  return {...safety,dmAction:(action,data)=>{if(!DM_ACTIONS.has(action))throw new WorkbenchError('私信操作无效','INPUT_INVALID');return request(action,data);},publicContactAction:");put(rel,text)
rel=prefix+'app.mjs';text=(S/rel).read_bytes().decode('utf-8')
text=replace(text,'interactionInboxAction:(action,data)=>backend.interactionInboxAction(action,data),','dmAction:(action,data)=>backend.dmAction(action,data),interactionInboxAction:(action,data)=>backend.interactionInboxAction(action,data),');put(rel,text)
rel=prefix+'pages/reply.mjs';text=(S/rel).read_bytes().decode('utf-8');nl='\r\n' if '\r\n' in text else '\n'
text="import {renderDM,bindDM,syncDM} from './reply-dm.mjs';"+nl+text
text=replace(text,'export const sync=syncConnected;',"export const sync=(state,ctx)=>state.replyChannel==='dm'?syncDM(state,ctx):syncConnected(state,ctx);")
text=replace(text,'export const preload=preloadConnected;',"export const preload=(state,ctx)=>state.replyChannel==='dm'?undefined:preloadConnected(state,ctx);")
text=replace(text,"  if(state.connection!=='preview')return renderConnected(state);","  if(state.connection!=='preview')return `<div class=\"rp-tabs\" role=\"tablist\" aria-label=\"回复通道\" style=\"margin-bottom:14px\"><button type=\"button\" class=\"rp-tab ${state.replyChannel!=='dm'?'is-active':''}\" data-reply-channel=\"comment\" aria-selected=\"${state.replyChannel!=='dm'}\">评论回复</button><button type=\"button\" class=\"rp-tab ${state.replyChannel==='dm'?'is-active':''}\" data-reply-channel=\"dm\" aria-selected=\"${state.replyChannel==='dm'}\">私信</button></div>${state.replyChannel==='dm'?renderDM(state):renderConnected(state)}`;")
text=replace(text,"  if(ctx.state.connection!=='preview')return bindConnected(root,ctx);","  if(ctx.state.connection!=='preview'){root.querySelectorAll('[data-reply-channel]').forEach(el=>el.addEventListener('click',()=>ctx.update(state=>{state.replyChannel=el.dataset.replyChannel;})));return ctx.state.replyChannel==='dm'?bindDM(root,ctx):bindConnected(root,ctx);}");put(rel,text)
print('Reply channel tab + scoped original backend API only; preview/original comment workflow preserved')
