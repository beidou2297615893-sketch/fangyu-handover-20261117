私信产品接入源码候选已封定，等待第二作者独审。未合源、未安装，运行中的 77 不变。

唯一可合目录为 final-source：9 个旧文件最小增量 + 5 个新文件，28 个 hunk，逐字节重放通过；测试数据、QA 项目、合成员工与授权均不在可合树。

已实现：回复下评论/私信两 tab；原鉴权与 Store 内的稳定账号/门店/员工/收件人会话和消息分页；本人显式一次监听与停止；独立草稿、逐条核对、单条/所选队列最后确认；严格发出回执才追加出站消息，绝不称送达/已读。打开页面仅原本地读取，自动生成/监听/发送均为零。原账号模式 lease、device/scope/held、customer claim 和请求恢复不替换；原评论/AI/意向记录不改。原日回复额度加入 DM 的 sending/sent/unknown，避免换通道漏计。

证据分层：20 个真实原 verify/read_public/create_backend/Core/Store/HTTP/Adapters/Popen/Node CLI 检查使用自有 loopback Bridge；21 个 VM 检查执行真实原 uint64 protobuf 与新增浏览器程序，HTTP/WebSocket/签名为明确合成边界；33 个 headless Chromium 原完整 index/fit/iframe 检查含逐条/最后确认、所选批量、15 秒编辑节点保留、账号/平台切换和宽 1255/390。最小有效字号 14.45px。均不是 Native/CUA/真实平台。

正向发送只在自有合成配置明确撤掉原 hold 并通过原 DeviceSession/BusinessExecutor 授权后对 loopback 执行；产品 company/public hold 未动，原 dm_contract_verified 默认 false 未动。这不等于自然云许可或真实私信传输已核验。

明确未覆盖：真实平台读/发、投递/已读、普通编译 EXE/SFX、第二台电脑。上游没有经本次核验可复用的历史拉取合同，所以只分页本软件显式监听保存的消息及严格出站回执，historyAvailable=false；不假造平台历史。小红书 Windows 可信可商用 DM 传输仍不可用，只能从当前可见原评论保存草稿。未知发送仅保留原请求/本地状态，停止后续，未伪造平台对账能力。

依赖复用：固定 MIT Yht20927/douyin-cli 原实现、既有 Windows Node/BridgeClient/protobuf 与 Python 标准库。旧 userscript/CLI/DM 文件及原连接材料 pins 全保留；新增固定 entry 与 browser program，不用原 UID 回退猜测与随机 send ID，不接入未合并的 XHS PR。需要未来正常 freeze/依赖清单/标准包闭包再验，不把源码候选当商包。

原红保留：权限错误泛化、worker 视图/读取快照竞态、窄窗溢出与夜间色彩红均有原目录。当前最终源修复后绿；截图 DOM 刚更新时脱离为自有截图取样竞态，改用原完整 viewport 截图，断言未放宽。请不要复制整个候选工作目录。
