"""Reviewed code-only update, no configuration or provider changes.

Fresh full baseline CAS, one update attempt, then separate full-code readback.
Temporary signed URLs and raw CLI output remain memory-only.
"""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,importlib.util,json,re,shutil,subprocess

W=Path(__file__).resolve().parent;O=W/'content-cloud-v3-final2'
EXPECTED='744ec24509d6602618543d6c760130de1d7b45a0acc05be89aa09592a03c5a02'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rows=json.loads((O/'FILES-SHA256.json').read_text(encoding='utf-8'));h=hashlib.sha256()
for r in rows:
    p=O/'candidate'/r['path'];assert not p.is_symlink() and sha(p)==r['sha256']
    h.update((r['path']+'\0'+r['sha256']+'\n').encode())
assert len(rows)==5616 and h.hexdigest()==EXPECTED
assert sha(O/'content-cloud-v3-closed-code.zip')=='ffd2457413a70e21dd8aeae4bc7238d28619d1d53263db0e6820451e7d08bae6'
assert 'CONTENT_RELEASE_ENABLED=false' in (O/'candidate/content_release.cjs').read_text(encoding='utf-8').replace(' ','')
assert 'LEGACY_AI_EXTENSIONS_ENABLED=false' in (O/'candidate/legacy_release.cjs').read_text(encoding='utf-8').replace(' ','')
assert not (O/'UPDATE-ATTEMPT.json').exists(),'An attempt exists; reconcile it instead of retrying'
checker=W/'content-cloud-v3-delivery/tools/check_live_code_readonly.py'
spec=importlib.util.spec_from_file_location('cloud_baseline_readonly',checker);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.ROOT=O;m.main() # aborts if current code ZIP differs from exact old baseline
report={'status':'UPDATE_SUBMITTED_ONCE','startedAtUtc':datetime.now(timezone.utc).isoformat(),'expectedCodeTree':EXPECTED,'configurationChanged':False,'environmentVariablesRead':False,'realModelCalls':0,'rawOutputPersisted':False,'fixedContentEnabled':False,'fixedLegacyExtensionsEnabled':False}
journal=O/'UPDATE-ATTEMPT.json'
journal.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
shell=shutil.which('pwsh') or shutil.which('powershell');assert shell
command="& 'C:/Users/rmsama/AppData/Roaming/npm/tcb.ps1' -e fh6-d5ga45c0ddae7008c -r ap-shanghai fn code update fangyu-workspace --dir '"+str(O/'candidate').replace('\\','/')+"' --deployMode cos --json"
try:
    response=subprocess.run([shell,'-NoProfile','-NonInteractive','-Command',command],cwd=O,capture_output=True,timeout=180)
    report.update(cliExitCode=response.returncode,status='CLI_RETURNED_REQUIRES_FULL_READBACK' if response.returncode==0 else 'CLI_FAILED_REQUIRES_FULL_READBACK')
    raw=re.sub(r'\x1b\[[0-9;]*[a-zA-Z]','',response.stdout.decode('utf-8',errors='replace'))
    # Whitelisted identifiers only, never save temporary URLs or raw errors.
    report['requestIds']=sorted(set(re.findall(r'"(?:RequestId|requestId)"\s*:\s*"([A-Za-z0-9_-]{8,100})"',raw)))
except subprocess.TimeoutExpired:
    report['status']='CLI_TIMED_OUT_REQUIRES_FULL_READBACK'
except Exception:
    report['status']='CLI_RESULT_UNKNOWN_REQUIRES_FULL_READBACK'
finally:
    report['finishedAtUtc']=datetime.now(timezone.utc).isoformat()
    journal.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False))
