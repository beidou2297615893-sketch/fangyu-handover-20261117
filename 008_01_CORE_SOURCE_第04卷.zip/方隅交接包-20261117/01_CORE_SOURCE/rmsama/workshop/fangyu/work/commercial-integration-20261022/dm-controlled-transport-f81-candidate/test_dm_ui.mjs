import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';import {createRequire} from 'node:module';
const require=createRequire(import.meta.url),{chromium}=require('C:/Users/rmsama/.codex/skills/xhs-note-creator/node_modules/playwright-core');
const W=path.dirname(fileURLToPath(import.meta.url)),info=JSON.parse(fs.readFileSync(path.join(W,'UI-SERVER.json'),'utf8')),out=info.directory;
const browser=await chromium.launch({headless:true,executablePath:'C:/Users/rmsama/AppData/Local/ms-playwright/chromium_headless_shell-1234/chrome-headless-shell-win64/chrome-headless-shell.exe'}),page=await browser.newPage({viewport:{width:1255,height:1132}}),errors=[],checks=[],http=[],metrics=[];
page.on('pageerror',e=>errors.push(String(e)));await page.route('**/*',r=>new URL(r.request().url()).hostname==='127.0.0.1'?r.continue():r.abort());const frame=page.frameLocator('#workspace-frame');
page.on('response',async r=>{try{if(r.request().method()==='POST'&&r.request().postDataJSON()?.action?.startsWith('dm_'))http.push({action:r.request().postDataJSON().action,status:r.status(),body:await r.json()});}catch{}});
const check=(value,label)=>{if(!value)throw Error(label);checks.push(label);};
async function action(name,trigger){const response=page.waitForResponse(r=>{try{return r.request().method()==='POST'&&r.request().postDataJSON()?.action===name}catch{return false}});await trigger();const r=await response,body=await r.json();check(r.status()===200,name+' original HTTP accepted');return body.dmWorkspace;}
const modal=()=>frame.locator('#modal');let passed=false;
try{
 await page.goto(info.origin);await frame.locator('#login-name').fill(info.username);await frame.locator('#login-pass').fill(info.password);await frame.locator('.login-submit').click();await frame.locator('[data-nav="reply"]').waitFor();
 if(await frame.locator('#work-store-choice').count()){const values=await frame.locator('#work-store-choice').evaluate(e=>[...e.options].map(o=>o.value).filter(Boolean));await frame.locator('#work-store-choice').selectOption(values[0]);await modal().locator('.modal-confirm').click();}
 await frame.locator('[data-switch-platform="douyin"]').click();await frame.locator('[data-nav="reply"]').click();await frame.locator('[data-reply-channel="dm"]').click();
 await frame.locator('[data-dm-conversation]').first().waitFor();check(await frame.locator('[data-dm-workspace]').count()===1,'Private messages is a connected subtab under original reply page');
 check(!http.some(x=>['dm_listen_start','dm_queue_start'].includes(x.action)),'Opening reply/DM reads only; no automatic listen or send');
 await frame.locator('[data-dm-conversation]').first().click();await frame.locator('.dm-bubble').getByText('收到的私信',{exact:true}).first().waitFor();
 await frame.locator('[data-dm-text]').fill('仅合成界面私信核对 <img src=x onerror=alert(1)>');
 const node=await frame.locator('[data-dm-text]').elementHandle();await page.waitForTimeout(15500);
 check(await frame.locator('[data-dm-text]').evaluate((e,n)=>e===n,node),'Original polling does not rebuild the edited textarea after 15 seconds');
 check((await frame.locator('[data-dm-text]').inputValue()).includes('<img'),'Typed text survives original refresh interval');
 const saved=await action('dm_draft_save',()=>frame.locator('[data-dm-save]').click());await frame.locator('[data-dm-review]:not([disabled])').waitFor();
 await frame.locator('[data-dm-review]').click();await modal().locator('[data-dm-confirm]').waitFor();
 check((await modal().textContent()).includes(saved.source.recipientUid)&&(await modal().textContent()).includes(saved.accountId),'Individual review names the concrete sender account and full stable recipient UID');
 check(await modal().locator('.rp-confirm-quote img').count()===0,'Confirmation escapes candidate text and does not create HTML images');
 let before=http.filter(x=>x.action==='dm_draft_review').length;await modal().locator('.modal-confirm').click();await page.waitForTimeout(150);
 check(await modal().isVisible()&&http.filter(x=>x.action==='dm_draft_review').length===before,'Unchecked individual confirmation cannot submit even one draft');
 await modal().locator('[data-dm-confirm]').check();await action('dm_draft_review',()=>modal().locator('.modal-confirm').click());await modal().waitFor({state:'hidden'});
 await action('dm_queue_prepare',()=>frame.locator('[data-dm-prepare-single]').click());await frame.locator('[data-dm-send-queue]').first().waitFor();
 check(!http.some(x=>x.action==='dm_queue_start'),'Save, individual review and prepared single queue do not send');
 await frame.locator('[data-dm-send-queue]').first().click();await modal().locator('[data-dm-final-confirm]').waitFor();before=http.filter(x=>x.action==='dm_queue_start').length;
 await modal().locator('.modal-confirm').click();await page.waitForTimeout(150);check(await modal().isVisible()&&http.filter(x=>x.action==='dm_queue_start').length===before,'Unchecked final authorization does not dispatch queue');
 await modal().locator('[data-dm-final-confirm]').check();await action('dm_queue_start',()=>modal().locator('.modal-confirm').click());await modal().waitFor({state:'hidden'});await frame.getByText('所选队列已处理完成；发出不代表已读',{exact:true}).waitFor();
 check(http.filter(x=>x.action==='dm_queue_start').length===1,'Explicit final authorization dispatches one original request; UI displays receipt without read/delivery claim');
 // Two separate reviewed recipients are selected explicitly; preparing or
 // cancelling their final review does not emit another send request.
 for(const index of [1,2]){
  await frame.locator('[data-dm-conversation]').nth(index).click();await frame.locator('[data-dm-text]').fill('仅合成所选私信 '+index);
  await action('dm_draft_save',()=>frame.locator('[data-dm-save]').click());await frame.locator('[data-dm-review]:not([disabled])').waitFor();await frame.locator('[data-dm-review]').click();await modal().locator('[data-dm-confirm]').check();await action('dm_draft_review',()=>modal().locator('.modal-confirm').click());await modal().waitFor({state:'hidden'});
 }
 await frame.locator('[data-dm-checked]').nth(0).check();await frame.locator('[data-dm-checked]').nth(1).check();
 const selected=await action('dm_queue_prepare',()=>frame.locator('[data-dm-prepare-batch]').click());check(selected.items.length===2&&new Set(selected.items.map(i=>i.snapshot.source.recipientUid)).size===2,'Selected batch freezes exactly two individually reviewed stable recipients');
 await frame.locator('[data-dm-send-queue]').last().click();await modal().locator('[data-dm-final-confirm]').waitFor();
 const reviewText=await modal().textContent();check(selected.items.every(i=>reviewText.includes(i.snapshot.source.recipientUid)),'Final selected-batch modal displays every full stable recipient UID');await modal().locator('.modal-cancel').click();check(http.filter(x=>x.action==='dm_queue_start').length===1,'Cancelling selected-batch authorization produces zero additional send requests');
 for(const width of [1255,390]){
  await page.setViewportSize({width,height:1100});await frame.locator('[data-dm-workspace]').scrollIntoViewIfNeeded();
  const outer=await page.evaluate(()=>{let scale=1;for(let e=document.querySelector('#workspace-frame');e;e=e.parentElement){const c=getComputedStyle(e);if(c.transform!=='none'){const m=new DOMMatrix(c.transform);scale*=Math.hypot(m.c,m.d);}const z=parseFloat(c.zoom);if(Number.isFinite(z)&&z>0)scale*=z;}return {scale,width:innerWidth,scroll:document.documentElement.scrollWidth};});
  const local=await frame.locator('[data-dm-workspace]').evaluate((panel,outerScale)=>{const values=[];for(const e of panel.querySelectorAll('p,small,label,button,select,textarea,strong')){const c=getComputedStyle(e);if(!e.getClientRects().length||c.visibility==='hidden'||c.display==='none')continue;let scale=outerScale;for(let a=e;a;a=a.parentElement){const s=getComputedStyle(a);if(s.transform!=='none'){const m=new DOMMatrix(s.transform);scale*=Math.hypot(m.c,m.d);}const z=parseFloat(s.zoom);if(Number.isFinite(z)&&z>0)scale*=z;}values.push({tag:e.tagName,className:e.className,fontPx:parseFloat(c.fontSize),effectiveFontPx:parseFloat(c.fontSize)*scale,text:e.textContent.slice(0,80)});}return {client:panel.clientWidth,scroll:panel.scrollWidth,grid:getComputedStyle(panel.querySelector('.dm-workspace')).gridTemplateColumns,values};},outer.scale);
  metrics.push({width,outer,...local});check(local.values.length>20&&local.values.every(v=>v.effectiveFontPx>=14-0.01),'All visible DM text effective font >=14 at original full fit '+width);
  check(local.scroll<=local.client+1&&outer.scroll<=outer.width+1,'Full original index/fit/iframe has no DM horizontal overflow '+width);
  check(width!==390||local.grid.split(' ').length===1,'Narrow DM uses vertical panels');
  if(width===390){await frame.locator('[data-dm-text]').scrollIntoViewIfNeeded();await frame.locator('[data-dm-text]').fill('仅合成窄窗可编辑草稿');await action('dm_draft_save',()=>frame.locator('[data-dm-save]').click());check(await frame.locator('[data-dm-text]').inputValue()==='仅合成窄窗可编辑草稿','Narrow vertical workspace reaches composer and saves through original HTTP');await page.screenshot({path:path.join(out,'dm-390-composer-viewport.png')});}
  await page.screenshot({path:path.join(out,'dm-'+width+'.png')});
 }
 await frame.locator('[data-dm-account]').selectOption(info.accounts[1]);await frame.getByText('暂没有已监听保存的会话。',{exact:true}).waitFor();check(await frame.locator('[data-dm-draft]').count()===0,'Changing sender account hides prior account conversations and drafts');
 await frame.locator('[data-switch-platform="xiaohongshu"]').click();await frame.getByText('当前门店没有此平台的本人账号，请先到账号页核对。',{exact:true}).waitFor();check(await frame.locator('[data-dm-listen]').isDisabled(),'Switching platform never reuses Douyin recipient or execution capabilities');
 check(errors.length===0,'No browser module/runtime errors');passed=true;
}catch(error){fs.writeFileSync(path.join(out,'UI-ERROR.json'),JSON.stringify({error:String(error),checks,http,metrics,errors},null,2));await page.screenshot({path:path.join(out,'UI-ERROR.png')});throw error;}
finally{fs.writeFileSync(path.join(out,'UI-RESULTS.json'),JSON.stringify({status:passed?'PASS':'RED_CAPTURED',checks,http,metrics,errors,actualOriginalIndexFitIframe:true,originalHostHttp:true,actualNodeCliSyntheticBridgeOnly:true,realModelPlatformCalls:0,noNative:true},null,2));await browser.close();fs.writeFileSync(info.stop,'stop own UI fixture');}
console.log(JSON.stringify({status:'PASS',checks:checks.length,directory:out}));
