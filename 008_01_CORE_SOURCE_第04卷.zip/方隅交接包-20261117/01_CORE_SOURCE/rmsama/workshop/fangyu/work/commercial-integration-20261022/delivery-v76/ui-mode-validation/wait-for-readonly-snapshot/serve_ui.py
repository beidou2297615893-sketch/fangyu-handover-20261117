from pathlib import Path
import hashlib,http.client,importlib.util,json,os,sys,threading,time
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=W.parents[4];S=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v76/project';stage=json.loads((S.parent/'STAGED.json').read_text('utf-8-sig'));R=Path(stage['release']);blocked=[];cloudcalls=[]
def audit(event,args):
 if event in ('subprocess.Popen','os.system','os.startfile','os.posix_spawn'):blocked.append(event);raise RuntimeError('No product process')
 if event in ('socket.connect','socket.bind') and (not isinstance(args[1],tuple) or args[1][0] not in ('127.0.0.1','::1')):blocked.append(event);raise RuntimeError('No external socket')
 if event=='socket.getaddrinfo' and args[0] not in ('127.0.0.1','::1','localhost',None):blocked.append(event);raise RuntimeError('No external DNS')
 if event=='sqlite3.connect' and not Path(args[0]).resolve().is_relative_to(W):blocked.append(event);raise RuntimeError('Own DB only')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  p=Path(os.fsdecode(args[0])).absolute();m,f=args[1] or '',args[2] or 0
  if (any(c in str(m) for c in 'wax+') or isinstance(f,int) and f&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC)) and not p.is_relative_to(W):blocked.append(event);raise RuntimeError('Own writes only')
sys.addaudithook(audit)
def dump(name,v):(W/name).write_text(json.dumps(v,ensure_ascii=False,indent=2,default=str),'utf-8')
def load(name,path):
 m=importlib.util.module_from_spec(importlib.util.spec_from_loader(name,loader=None));m.__file__=str(path);sys.modules[name]=m;exec(compile(path.read_bytes(),str(path),'exec'),m.__dict__);return m
fixture=load('diverse_original_cloud_fixture',P/'work/acquisition-core-repair-20261018/gui-fixture/base_fixture.py');cloud=fixture.CloudStandin(json.loads((P/'work/central-store-config/compiled-fixture.json').read_text('utf-8-sig')));company=json.loads((S/'work/app/company.json').read_text('utf-8-sig'))
def transport(url,data,token=''):
 cloudcalls.append(data['operation']);assert data['operation'] not in ('intent_analyze','ai_attempt_status','device_account_claim')
 value=cloud(url,data,token);value['environment_id']=company['managedWorkspace']['environment_id'];return value
integration=load('integrations',R/'resources/platform-runtime/vendor-src/integrations.py');integration.request_json=transport
host=load('diverse_actual_native_host',R/'ui_native_host.py');_,files=host.verify_release(R,stage['manifest_sha256']);host.verify_backend_dependencies(R,files,S);backend=host.create_backend(R,files,project_root=S,data_dir=W/('native-data-'+str(time.time_ns())),company=company)
server=host.StaticServer(R,files,backend=backend,cookie_name='diverse_fixture_session');thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start();origin='http://127.0.0.1:'+str(server.server_port)
def request(method,path,payload=None,headers=None):
 c=http.client.HTTPConnection('127.0.0.1',server.server_port,timeout=20)
 try:c.request(method,path,json.dumps(payload,ensure_ascii=False).encode() if payload is not None else None,headers or {});r=c.getresponse();raw=r.read();found=dict(r.getheaders());status=r.status
 finally:c.close()
 return status,json.loads(raw),found
def records():
 with backend.core.store.connect() as db:return [dict(r) for r in db.execute('SELECT entity,id,tenant_id,body FROM records ORDER BY entity,id')]
try:
 code,boot,_=request('GET','/api/workbench/bootstrap');assert code==200
 headers={'Content-Type':'application/json','Origin':origin,'X-Fangyu-CSRF':boot['csrfToken']}
 code,logged,head=request('POST','/api/workbench',{'action':'login','data':{'username':'fixture-admin','password':fixture.PASSWORD}},headers);assert code==200
 cookie=head['Set-Cookie'].split(';',1)[0];headers.update(Cookie=cookie);store=cloud.first_store
 if logged['selection']['storeId']!=store:
  code,selected,_=request('POST','/api/workbench',{'action':'select_store','data':{'storeId':store,'expectedRevision':logged['selection']['revision']}},headers);assert code==200
 user=backend.core.session(cookie.split('=',1)[1]);user['_workbench_store_id']=store
 for i,platform in enumerate(('xiaohongshu','xiaohongshu','douyin')):
  backend.core.store.put('accounts',{'id':'diverse-fixture-account-'+str(i),'tenant_id':user['tenant_id'],'cloud_owner':user['username'],'store_id':store,'platform':platform,'name':'合成平台账号'+str(i),'status':'ready','platform_uid':'fixture-uid-'+str(i)})
 # No old held-scope migration is part of this UI candidate. This is a valid own paused task.
 task={'id':'diverse-fixture-old-task','tenant_id':user['tenant_id'],'cloud_owner':user['username'],'store_id':store,'platform':'xiaohongshu','account_id':'diverse-fixture-account-0','name':'合成原关键词任务','status':'paused','scope':'search_comments','keywords':['租房'],'excludes':[],'city':'上海','region':'','comment_keyword_mode':'all','unknown_policy':'exclude','continuous_enabled':False,'created_at':'2026-10-23T00:00:00Z','cursor':{'page':3,'cursor':'original-ui-cursor'}}
 task.update(pause_reason='account_mode_blocked',last_message='该账号正在执行回复，请先暂停并等待当前操作结束');backend.core.store.put('tasks',task);before=records();dump('UI-ORIGINAL-RECORDS.json',before)
 dump('UI-SERVER.json',{'origin':origin,'cookieName':'diverse_fixture_session','cookieValue':cookie.split('=',1)[1],'storeId':store,'taskId':task['id'],'stage':stage,'realNativeFactory':True,'actualF76Stage':True,'controlledPersistedPauseReasonFixture':True,'productionAccess':False})
 print('READY '+origin,flush=True)
 while not (W/'STOP-UI-SERVER').exists():time.sleep(.2)
 after=records();business=lambda rows:[r for r in rows if r['entity'] not in ('workbench_selection_v1','users')]
 dump('UI-NATIVE-RESULTS.json',{'status':'PASS' if business(before)==business(after) else 'RECORDS_CHANGED_REVIEW','businessRecordsByteIdentical':business(before)==business(after),'allRecordsByteIdentical':before==after,'beforeRecords':len(before),'afterRecords':len(after),'syntheticTransportOperations':cloudcalls,'realExternalCalls':0,'blocked':blocked,'taskAndAccountRowsUnchanged':all(r in after for r in before if r['entity'] in ('tasks','accounts'))})
finally:
 server.shutdown();thread.join(3);server.server_close();backend.close();dump('UI-SERVER-CLOSED.json',{'closed':not thread.is_alive(),'blocked':blocked})
