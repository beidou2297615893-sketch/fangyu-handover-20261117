"""Derive the final read-only check without replacing earlier evidence."""
from pathlib import Path

D = Path(__file__).resolve().parent
source = (D / 'verify_final_delivery_health.py').read_text('utf-8')
for old, new in [
    ('capture_business_after_output_copy.py', 'capture_business_before_deadline.py'),
    ('after-output-copy', 'before-deadline'),
    ('PROTECTED-BUSINESS-AFTER-OUTPUT-COPY.json', 'PROTECTED-BUSINESS-BEFORE-DEADLINE.json'),
    ('FINAL-DELIVERY-HEALTH.json', 'DEADLINE-HEALTH.json'),
    ('PASS_FINAL_HELD_DELIVERY_WITH_ORIGINAL_RUNNING_APP_AND_BUSINESS_PRESERVED', 'PASS_DEADLINE_HELD_DELIVERY_WITH_ORIGINAL_RUNNING_APP_AND_BUSINESS_PRESERVED'),
]:
    if old not in source:
        raise RuntimeError('Original verification text changed: ' + old)
    source = source.replace(old, new)
marker = 'receipt = {\n'
if source.count(marker) != 1:
    raise RuntimeError('Ambiguous receipt construction')
source = source.replace(marker, '''frozen = P / 'work/parallel-integration-20261018/final-integration/candidate-unified-v73'
require(sha(frozen / 'UNIFIED-PINS.json') == 'c0a72be807965903a5cbb9dfee9ba6549a6157ccf622fd7df86a9ef1397a167b', 'Frozen manifest changed')
manifest = json.loads((frozen / 'UNIFIED-PINS.json').read_text('utf-8'))
expected_files = {row['path'] for row in manifest['files']}
actual_files = {path.relative_to(frozen / 'project').as_posix() for path in (frozen / 'project').rglob('*') if path.is_file()}
require(actual_files == expected_files and len(actual_files) == 3156, 'Frozen exact file set changed')
for row in manifest['files']:
    require(sha(frozen / 'project' / row['path']) == row['sha256'], 'Frozen source bytes changed: ' + row['path'])
''' + marker)
source = source.replace("'productionWritten': False,", "'productionWritten': False, 'frozenExact3156AllHashesVerified': True, 'candidateCorrectionsMerged': False,")
target = D / 'verify_deadline_health.py'
if target.exists():
    raise RuntimeError('Preserve earlier deadline verifier')
target.write_text(source, encoding='utf-8')
print('Prepared final read-only deadline verification; not executed.')
