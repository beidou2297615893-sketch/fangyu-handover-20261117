from pathlib import Path
p=Path(__file__).resolve().parent/'test_public_factory.py'
text=p.read_text('utf-8').split('\ntry:\n start();login();')[0]
gate=__import__('json').loads((p.parent/'INPUT-GATE.json').read_text('utf-8'))
text=text.replace("S=W/'qa-only-project'",'S=Path('+repr(gate['project'])+')').replace("json.loads((W/'QA-STAGE.json').read_text('utf-8'))","json.loads((W/'F82-STAGED.json').read_text('utf-8-sig'))")
exec(compile(text,str(p),'exec'),globals())
entered=threading.Event();release=threading.Event();worker=None;done=[];errors=[];passed=False
original=source
def delayed(method,url,payload):
 result=original(method,url,payload);entered.set()
 if not release.wait(10):raise RuntimeError('Own concurrency fixture release timed out')
 return result
try:
 start();login();account={'id':'public-concurrency-account','tenant_id':user['tenant_id'],'cloud_owner':user['username'],'store_id':store,'platform':'xiaohongshu','name':'并发公开参考合成账号','status':'ready','platform_uid':'synthetic-public-only'};core.store.put('accounts',account)
 backend._public_search_response_transport=delayed
 payload=base(query='公开参考在途读取样本',confirmedPublicQuery=True,expectedRevision=revision(),requestId='f82-public-concurrent-original-key')
 def run():
  try:done.append(action('content_public_research_preview',payload))
  except BaseException:errors.append(traceback.format_exc())
 worker=threading.Thread(target=run);worker.start();assert entered.wait(10)
 started=time.monotonic();current=read(requestId=payload['requestId']);elapsed=time.monotonic()-started
 assert elapsed<1 and worker.is_alive() and not done and current['receipt']['state']=='unknown',(elapsed,current)
 save('CONCURRENT-HTTP.json',{'workspaceReadSeconds':elapsed,'providerResponseStillInFlight':True,'originalReceiptState':current['receipt']['state'],'requestId':payload['requestId'],'providerReplays':len(calls),'realExternalCalls':0,'fullBusinessBody':current})
 release.set();worker.join(10);assert not worker.is_alive() and not errors and done[0]['result']['publicResearch']['state']=='received'
 before=len(calls);again=action('content_public_research_preview',payload);assert again['replayed'] and len(calls)==before==1
 checks.append({'group':'actual_F82_Native_public_preview_inflight_read_original_key','result':'PASS','readSeconds':elapsed,'sourceResponseReplays':1,'replayExternalDispatches':0});passed=True
finally:
 release.set()
 if worker:worker.join(12)
 if sys.exc_info()[0]:save('ERROR.json',{'traceback':traceback.format_exc()})
 if server:server.shutdown();server.server_close()
 if backend:backend.close()
 for t in threads:t.join(3)
 save('RESULTS.json',{'status':'PASS' if passed else 'RED','groups':checks,'groupCount':len(checks),'httpRequests':len(events),'workerErrors':errors,'stage':stage,'originalVerifiedNativeFactory':True,'externalPlatformModelCalls':0,'allOwnThreadsClosed':all(not t.is_alive() for t in threads) and (worker is None or not worker.is_alive())})
 print(json.dumps({'status':'PASS' if passed else 'RED','evidence':str(OUT),'httpRequests':len(events)},ensure_ascii=False))
