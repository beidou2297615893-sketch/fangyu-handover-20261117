// Private-message channel. Never loads preview people or comment-send actions.
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const actor=s=>`${s.authEpoch||0}|${s.user}|${s.storeId||''}|${s.activePlatform||'xiaohongshu'}`;
const active=s=>s.connection==='connected'&&Boolean(s.session)&&s.page==='reply'&&s.replyChannel==='dm';
const labels={draft:'草稿 · 未发送',reviewed:'已逐条核对 · 未发送',prepared:'等待最后确认',running:'正在处理',sent:'平台已返回发出回执',unknown:'原结果待核对 · 禁止重发',completed:'本次已结束',blocked:'已暂停',cancelled:'后续已取消',listening:'本次正在监听',stopping:'正在停止',stop_pending:'原停止回执待核对',sending:'本条正在发送',stopped:'已停止',interrupted:'原监听已结束'};
const key=()=>globalThis.crypto?.randomUUID?.()||`dm-${Date.now()}-${Math.random().toString(36).slice(2)}`;
const storage=scope=>'fangyu-dm-request-v1:'+scope;
function model(s){
 if(!s.dmLive||s.dmLive.actor!==actor(s)){
  const v=s.dmLive={actor:actor(s),accountId:'',conversationId:'',value:null,text:'',draft:null,checked:[],dirty:false,busy:false,error:'',pending:null,generation:0,loaded:false};
  try{const p=JSON.parse(localStorage.getItem(storage(v.actor))||'null');if(p&&p.actor===v.actor&&typeof p.requestId==='string'&&typeof p.action==='string')v.pending=p;}catch{}
 }
 return s.dmLive;
}
const accounts=s=>(s.platform?.accounts||[]).filter(a=>a.platform===(s.activePlatform||'xiaohongshu'));
function sourceFromComment(s){
 const r=s.replyLive,row=r?.detail?.comments?.find(c=>c.id===r.leadId);
 return r?.actor===actor(s)&&row&&r.selectedId&&row.sourceDigest?{target:{customerId:r.selectedId,leadId:row.id,sourceDigest:row.sourceDigest},name:r.detail?.item?.name||'当前客户',quote:row.text,platform:row.platform}:null;
}
function own(s,v){return active(s)&&s.dmLive===v&&actor(s)===v.actor;}
function remember(v,p){v.pending=p;try{p?localStorage.setItem(storage(v.actor),JSON.stringify(p)):localStorage.removeItem(storage(v.actor));}catch{}}
function accept(s,v,result){
 if(!own(s,v))return false;
 if(result?.actor&&(result.actor.username!==s.user||result.actor.storeId!==s.storeId))throw Error('员工或门店已变化，请重新读取。');
 if(result?.accountId&&result.accountId!==v.accountId)throw Error('发送账号已变化，请重新读取。');return true;
}
async function load(s,ctx,v,extra={}){
 if(!v.accountId||v.busy)return;const generation=++v.generation,accountId=v.accountId;
 try{
  const r=(await ctx.dmAction('dm_workspace_read',{storeId:s.storeId,accountId,...(v.conversationId?{conversationId:v.conversationId}:{}),...extra})).dmWorkspace;
  if(!own(s,v)||generation!==v.generation||accountId!==v.accountId)return;
  if(!accept(s,v,r))return;v.value=r;v.loaded=true;v.error='';if(!v.dirty)ctx.update(()=>{});
 }catch(e){if(own(s,v)&&generation===v.generation){v.error=e.message;if(!v.dirty)ctx.update(()=>{});}}
}
async function mutate(s,ctx,v,action,data){
 if(v.busy||v.pending||!own(s,v))return null;
 const requestId=key(),pending={actor:v.actor,action,requestId,accountId:v.accountId};remember(v,pending);v.busy=true;v.error='';ctx.update(()=>{});
 try{
  const r=(await ctx.dmAction(action,{storeId:s.storeId,...data,requestId})).dmWorkspace;
  if(!own(s,v))return null;remember(v,null);v.busy=false;return r;
 }catch(e){if(own(s,v)){v.error=e.message;v.busy=false;ctx.update(()=>{});}return null;}
}
async function recover(s,ctx,v){
 if(!v.pending||v.busy)return;const p={...v.pending};v.busy=true;
 try{
  const r=(await ctx.dmAction('dm_request_read',{storeId:s.storeId,action:p.action,requestId:p.requestId})).dmWorkspace;
  if(!own(s,v)||v.pending?.requestId!==p.requestId)return;
  remember(v,null);v.error=r.state==='unknown'?'原私信结果待核对，不会再次发送。':r.state==='not_found'?'后台确认原操作没有记录；请核对内容后再明确操作。':'';
  if(p.action.startsWith('dm_draft_')&&r.id){v.draft=r;v.text=r.text;v.dirty=false;}
 }catch(e){if(own(s,v))v.error=e.message;}
 finally{if(own(s,v)){v.busy=false;await load(s,ctx,v);ctx.update(()=>{});}}
}
function target(v){return v.externalTarget?.target||(v.conversationId?{conversationId:v.conversationId}:null);}
function chooseDraft(v,d){v.draft=d;v.text=d?.text||'';v.dirty=false;}
export function syncDM(s,ctx){
 if(!active(s)||!s.storeId)return;const v=model(s),list=accounts(s);
 // The original reply page does not poll account snapshots. Obtain one
 // original scoped, read-only snapshot even when entered immediately after a
 // platform switch; never turn an absent cached snapshot into no-accounts.
 if(!v.accountRead){v.accountRead=true;queueMicrotask(async()=>{if(own(s,v))await ctx.refreshPlatform({manual:true});});}
 if(v.accountId&&!list.some(a=>a.id===v.accountId)){v.accountId='';v.value=null;v.loaded=false;v.conversationId='';v.externalTarget=null;chooseDraft(v,null);}
 if(!v.accountId&&list[0])v.accountId=list[0].id;
 if(!v.loaded&&!v.busy&&!v.scheduled&&v.accountId){v.scheduled=true;queueMicrotask(async()=>{v.scheduled=false;if(own(s,v)){if(v.pending)await recover(s,ctx,v);else await load(s,ctx,v);}});}
 const running=v.value?.listeners?.some(l=>['listening','stopping'].includes(l.state))||v.value?.queues?.some(q=>q.state==='running');
 if(running&&!v.timer&&!v.dirty&&!v.busy){v.timer=setTimeout(async()=>{v.timer=null;if(own(s,v)&&!v.dirty&&!v.busy)await load(s,ctx,v);},700);}
}
export function renderDM(s){
 const v=model(s),a=accounts(s),value=v.value,caps=value?.capabilities||{},conv=value?.conversation,source=sourceFromComment(s),locked=v.busy||Boolean(v.pending),d=v.draft;
 const candidates=(value?.drafts||[]).filter(r=>r.state==='reviewed');
 return `<style>.dm-workspace{display:grid;grid-template-columns:minmax(210px,.8fr) minmax(260px,1.1fr) minmax(270px,1fr);gap:14px;align-items:start}.dm-panel{min-width:0;background:var(--panel,#fff);color:var(--ink,#244260);border:1px solid var(--rule,#dbe4ee);border-radius:14px;padding:16px;overflow-wrap:anywhere}.dm-panel p,.dm-note,.dm-panel small{font-size:17px!important;line-height:1.55}.dm-panel textarea{box-sizing:border-box;width:100%;min-height:160px;font-size:18px;padding:12px;border:1px solid #ccd8e6;border-radius:10px}.dm-row{display:flex;gap:8px;align-items:center;margin-bottom:10px}.dm-row>*{min-width:0}.dm-row select{flex:1}.dm-conversation{display:block;text-align:left;width:100%;padding:12px;border:1px solid #e0e8f1;border-radius:10px;background:#fff;margin:7px 0;overflow-wrap:anywhere}.dm-conversation[aria-pressed=true]{background:#edf3fc;border-color:#809bc1}.dm-bubble{padding:12px;background:#eff4fb;border-radius:12px;margin:10px 0;white-space:pre-wrap;overflow-wrap:anywhere}.dm-toolbar{display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin-bottom:14px}.reply-page .dm-panel button{white-space:normal;overflow-wrap:anywhere;max-width:100%;min-width:0}.dm-row{flex-wrap:wrap}.dm-draft-row button{flex:1;text-align:left}.dm-draft-row>input{flex:0 0 18px}.shell[data-platform=douyin] :is(.dm-conversation,.dm-bubble){background:#19364e;color:#e6f3ff;border-color:#365771}.shell[data-platform=douyin] .dm-panel .rp-text-link{color:#71dce6}.shell[data-platform=douyin] .dm-conversation[aria-pressed=true]{background:#22506a;border-color:#61b0c3}.dm-toolbar select{max-width:100%}.dm-history{max-height:430px;overflow:auto}.dm-warn{padding:12px;border-radius:10px;background:#fff4df;color:#805925;font-size:17px}.dm-panel label{font-size:17px}.dm-draft-row{display:flex;gap:8px;padding:9px;border-top:1px solid #edf1f6}@media(max-width:1100px){.dm-workspace{grid-template-columns:1fr}.dm-history{max-height:320px}}</style>
 <section class="reply-page" data-dm-workspace><div class="dm-toolbar"><strong>发送账号</strong><select data-dm-account aria-label="私信发送账号" ${locked?'disabled':''}>${a.map(x=>`<option value="${esc(x.id)}" ${x.id===v.accountId?'selected':''}>${esc(x.platformNickname||x.platform_nickname||x.name||'本人账号')}</option>`).join('')}</select><button class="rp-secondary" data-dm-refresh ${locked?'disabled':''}>重新读取本机记录</button><button class="rp-secondary" data-dm-listen ${locked||!caps.canListen?'disabled':''}>仅监听一次 · 最长20秒</button>${(value?.listeners||[]).filter(l=>['listening','stopping','stop_pending'].includes(l.state)).map(l=>`<button class="rp-secondary" data-dm-stop="${esc(l.id)}">${l.state==='stop_pending'?'核对原停止操作':'停止本次监听'}</button>`).join('')}</div>
 <p class="dm-note">${esc(caps.historyMessage||'打开此页只读取本机记录，不会启动平台监听或发送。')}</p><div class="dm-warn" role="status">${esc(v.error||caps.message||(!a.length?'当前门店没有此平台的本人账号，请先到账号页核对。':'正在读取本人账号的私信记录…'))}${v.pending?' <button data-dm-recover>核对原操作结果</button>':''}</div>
 <div class="dm-workspace"><section class="dm-panel"><h3>已保存会话</h3><div class="dm-history">${(value?.conversations?.items||[]).map(c=>`<button class="dm-conversation" data-dm-conversation="${esc(c.id)}" aria-pressed="${v.conversationId===c.id}"><strong>收件人尾号 ${esc(c.recipientUid.slice(-6))}</strong><p>${esc(c.lastMessagePreview)}</p></button>`).join('')||'<p>暂没有已监听保存的会话。</p>'}</div>${value?.conversations?.hasMore?'<button class="rp-secondary" data-dm-more-conversations>下一页会话</button>':''}${source?'<button class="rp-secondary" data-dm-from-comment>从当前原评论准备私信</button>':''}<h3>已保存草稿</h3>${(value?.drafts||[]).map(x=>`<div class="dm-draft-row">${x.state==='reviewed'?`<input type="checkbox" data-dm-checked="${esc(x.id)}" ${v.checked.includes(x.id)?'checked':''} aria-label="选择此条已核对私信">`:''}<button class="rp-text-link" data-dm-draft="${esc(x.id)}">${esc(labels[x.state]||x.state)} · ${esc(x.text.slice(0,30))}</button></div>`).join('')||'<p>草稿尚未保存。</p>'}<button class="rp-secondary" data-dm-prepare-batch ${locked||!v.checked.length?'disabled':''}>准备选中的私信队列</button></section>
 <section class="dm-panel"><h3>${conv?`与尾号 ${esc(conv.recipientUid.slice(-6))} 的已保存消息`:'会话与原评论来源'}</h3>${v.externalTarget?`<div class="dm-bubble"><strong>${esc(v.externalTarget.name)} · 原评论</strong><p>${esc(v.externalTarget.quote)}</p><small>评论不是私信，收件人仍须本人逐条核对。</small></div>`:''}<div class="dm-history">${(value?.messages?.items||[]).map(m=>`<div class="dm-bubble"><strong>${m.direction==="outbound"?"平台回执已发出 · 非送达或已读":"收到的私信"}</strong><p>${esc(m.text)}</p><small>${m.direction==="outbound"?"本机回执记录于":"本软件看到于"} ${esc(m.observedAt)}；平台发送时间未提供。</small></div>`).join('')||'<p>选择会话后展示已保存的入站消息。尚未取得的历史不做推测。</p>'}</div>${value?.messages?.hasMore?'<button class="rp-secondary" data-dm-more-messages>下一页消息</button>':''}<h3>本次队列</h3>${(value?.queues||[]).slice().reverse().map(q=>`<div class="dm-bubble"><strong>${esc(labels[q.state]||q.state)}</strong><p>${esc(q.message||'仅保存本次选择，尚未发送。')}</p>${q.items.map(i=>`<p>${esc(i.snapshot.text)} · ${esc(labels[i.state]||i.state)}</p>`).join('')}${q.state==='prepared'?`<button class="rp-primary" data-dm-send-queue="${esc(q.id)}" ${locked||!caps.canSend?'disabled':''}>核对完整队列并发送</button>`:''}${['prepared','running'].includes(q.state)?`<button class="rp-secondary" data-dm-cancel="${esc(q.id)}">取消后续条目</button>`:''}</div>`).join('')||'<p>没有待处理队列。</p>'}</section>
 <section class="dm-panel"><h3>私信草稿与核对</h3><p>${target(v)?'收件人来自当前可见的真实会话或原评论。':'请先选择一个会话，或从当前原评论选择收件人。'}</p><textarea data-dm-text maxlength="1000" aria-label="私信草稿" placeholder="输入本人确认的私信内容，不会自动生成或发送" ${locked||['sending','sent','unknown'].includes(d?.state)?'disabled':''}>${esc(v.text)}</textarea><small data-dm-count>${v.text.length} / 1000</small><div class="dm-row"><button class="rp-secondary" data-dm-save ${locked||!target(v)||!v.text.trim()?'disabled':''}>保存私信草稿</button><button class="rp-secondary" data-dm-review ${locked||!d||v.dirty||d.state!=='draft'?'disabled':''}>逐条本人核对</button></div><button class="rp-primary" data-dm-prepare-single ${locked||v.dirty||d?.state!=='reviewed'?'disabled':''}>准备这一条私信</button><p>保存、核对和准备队列都不会发送。结果未知时保留原操作，不提供换编号重发。</p>${d?`<p role="status">${esc(labels[d.state]||d.state)}${d.lastMessage?' · '+esc(d.lastMessage):''}</p>`:''}</section></div></section>`;
}
export function bindDM(root,ctx){
 const s=ctx.state,v=model(s);const change=fn=>{fn();ctx.update(()=>{});};
 root.querySelector('[data-dm-account]')?.addEventListener('change',e=>change(()=>{v.accountId=e.target.value;v.loaded=false;v.conversationId='';v.value=null;v.externalTarget=null;v.checked=[];chooseDraft(v,null);}));
 root.querySelector('[data-dm-refresh]')?.addEventListener('click',async()=>{await ctx.refreshPlatform({manual:true});if(own(s,v))await load(s,ctx,v);});root.querySelector('[data-dm-recover]')?.addEventListener('click',()=>recover(s,ctx,v));
 root.querySelectorAll('[data-dm-conversation]').forEach(el=>el.addEventListener('click',()=>{v.conversationId=el.dataset.dmConversation;v.externalTarget=null;chooseDraft(v,null);load(s,ctx,v);}));
 root.querySelector('[data-dm-from-comment]')?.addEventListener('click',()=>change(()=>{const source=sourceFromComment(s);if(source){v.externalTarget=source;v.conversationId='';chooseDraft(v,null);}}));
 root.querySelector('[data-dm-more-conversations]')?.addEventListener('click',()=>load(s,ctx,v,{cursor:v.value.conversations.cursor}));root.querySelector('[data-dm-more-messages]')?.addEventListener('click',()=>load(s,ctx,v,{messageCursor:v.value.messages.cursor}));
 root.querySelector('[data-dm-text]')?.addEventListener('input',e=>{v.text=e.target.value;v.dirty=true;root.querySelector('[data-dm-count]').textContent=v.text.length+' / 1000';root.querySelector('[data-dm-save]').disabled=v.busy||Boolean(v.pending)||!target(v)||!v.text.trim();root.querySelector('[data-dm-review]').disabled=true;root.querySelector('[data-dm-prepare-single]').disabled=true;});
 root.querySelectorAll('[data-dm-draft]').forEach(el=>el.addEventListener('click',()=>change(()=>{const d=v.value.drafts.find(x=>x.id===el.dataset.dmDraft);chooseDraft(v,d);v.externalTarget=d.source.kind==='customer'?{target:{customerId:d.source.customerId,leadId:d.source.id,sourceDigest:d.source.digest},name:'原客户',quote:'来源保留在原客户评论；再次发送前由后台重新核对。'}:null;v.conversationId=d.source.kind==='conversation'?d.source.id:'';})));
 root.querySelectorAll('[data-dm-checked]').forEach(el=>el.addEventListener('change',()=>change(()=>{v.checked=el.checked?[...new Set([...v.checked,el.dataset.dmChecked])]:v.checked.filter(id=>id!==el.dataset.dmChecked);}))); 
 root.querySelector('[data-dm-save]')?.addEventListener('click',async()=>{const d=await mutate(s,ctx,v,'dm_draft_save',{accountId:v.accountId,...(v.draft?{id:v.draft.id}:{}),expectedVersion:v.draft?.version||0,target:target(v),text:v.text});if(d){chooseDraft(v,d);await load(s,ctx,v);}});
 root.querySelector('[data-dm-review]')?.addEventListener('click',()=>{
  const d=v.draft,expected={actor:v.actor,accountId:v.accountId,id:d.id,version:d.version,text:v.text};
  ctx.modal({title:'本人逐条核对私信 · 不发送',html:`<p>发送账号：${esc(accounts(s).find(a=>a.id===v.accountId)?.platformNickname||accounts(s).find(a=>a.id===v.accountId)?.name||"本人账号")}（${esc(v.accountId)}）</p><p>收件人平台用户编号：${esc(d.source.recipientUid)}。来源：${d.source.kind==="customer"?"当前可见原评论":"本账号已保存入站会话"}。</p><p>请本人核对来源与完整正文。</p><blockquote class="rp-confirm-quote">${esc(v.text)}</blockquote><label><input type="checkbox" data-dm-confirm> 我已核对收件人和发送账号，正文无误</label>`,confirmLabel:'保存这条核对',onConfirm:async()=>{
   if(!document.querySelector('[data-dm-confirm]')?.checked||!own(s,v)||v.accountId!==expected.accountId||v.draft?.id!==expected.id||v.draft.version!==expected.version||v.text!==expected.text||v.dirty)return false;
   const saved=await mutate(s,ctx,v,'dm_draft_review',{accountId:v.accountId,id:d.id,expectedVersion:d.version,confirmed:true});if(saved){chooseDraft(v,saved);await load(s,ctx,v);}return Boolean(saved);
  }});
 });
 async function prepare(ds){const q=await mutate(s,ctx,v,'dm_queue_prepare',{accountId:v.accountId,drafts:ds.map(d=>({id:d.id,version:d.version}))});if(q){v.checked=[];await load(s,ctx,v);}}
 root.querySelector('[data-dm-prepare-single]')?.addEventListener('click',()=>prepare([v.draft]));root.querySelector('[data-dm-prepare-batch]')?.addEventListener('click',()=>prepare(v.value.drafts.filter(d=>v.checked.includes(d.id)&&d.state==='reviewed')));
 root.querySelector('[data-dm-listen]')?.addEventListener('click',()=>ctx.modal({title:'仅监听一次',html:'<p>只接收本人当前账号接下来最多20秒的新入站私信，并保存可核对的消息。不会回拉历史、自动回复或调用模型。</p>',confirmLabel:'开始这一次监听',onConfirm:async()=>{const r=await mutate(s,ctx,v,'dm_listen_start',{accountId:v.accountId,confirmed:true,timeoutMs:20000});if(r)await load(s,ctx,v);return Boolean(r);}}));
 root.querySelectorAll('[data-dm-stop]').forEach(el=>el.addEventListener('click',async()=>{try{await ctx.dmAction('dm_listen_stop',{storeId:s.storeId,id:el.dataset.dmStop});await load(s,ctx,v);}catch(e){v.error=e.message;ctx.update(()=>{});}}));
 root.querySelectorAll('[data-dm-cancel]').forEach(el=>el.addEventListener('click',async()=>{try{await ctx.dmAction('dm_queue_cancel',{storeId:s.storeId,id:el.dataset.dmCancel});await load(s,ctx,v);}catch(e){if(own(s,v)){v.error=e.message;ctx.update(()=>{});}}}));
 root.querySelectorAll('[data-dm-send-queue]').forEach(el=>el.addEventListener('click',()=>{
  const q=v.value.queues.find(q=>q.id===el.dataset.dmSendQueue),expected={actor:v.actor,accountId:v.accountId,id:q.id,digest:q.snapshotDigest};
  ctx.modal({title:'最后确认发送所选私信',html:`<p>发送账号：${esc(accounts(s).find(a=>a.id===v.accountId)?.name||'本人账号')}（${esc(v.accountId)}）</p>${q.items.map(i=>`<div class="rp-confirm-quote"><strong>收件人平台用户编号 ${esc(i.snapshot.source.recipientUid)}</strong><p>${esc(i.snapshot.text)}</p></div>`).join('')}<p>逐条顺序处理，任意结果未知即停止后续。发出不代表对方已读。</p><label><input type="checkbox" data-dm-final-confirm> 我明确授权本次所选收件人与正文的真实私信发送</label>`,confirmLabel:'授权本次发送',onConfirm:async()=>{
   if(!document.querySelector('[data-dm-final-confirm]')?.checked||!own(s,v)||v.accountId!==expected.accountId||!v.value.queues.some(x=>x.id===expected.id&&x.snapshotDigest===expected.digest&&x.state==='prepared'))return false;
   const r=await mutate(s,ctx,v,'dm_queue_start',{id:q.id,snapshotDigest:q.snapshotDigest,confirmed:true});if(r)await load(s,ctx,v);return Boolean(r);
  }});
 }));
}
