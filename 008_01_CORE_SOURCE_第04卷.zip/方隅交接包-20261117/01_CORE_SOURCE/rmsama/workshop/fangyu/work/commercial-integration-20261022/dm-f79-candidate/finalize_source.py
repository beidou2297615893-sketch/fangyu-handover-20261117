"""Freeze this owned source overlay only; never writes canonical or a release."""
from pathlib import Path
from datetime import datetime,timezone
import ast,difflib,hashlib,json,re,shutil
W=Path(__file__).resolve().parent;P=W.parents[2]
S=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v79/project'
F=S.parents[1]/'candidate-unified-v79';O=W/'source-candidate';D=W/'final-source'
sha=lambda b:hashlib.sha256(b).hexdigest()
put=lambda name,v:(W/name).write_text(json.dumps(v,ensure_ascii=False,indent=2),'utf-8')
pins=json.loads((F/'UNIFIED-PINS.json').read_text('utf-8-sig'));baseline={r['path']:r for r in pins['files']}
rows=[];patch=[];unchanged=[];D.mkdir(exist_ok=True)
for path in sorted(p for p in O.rglob('*') if p.is_file()):
 rel=path.relative_to(O).as_posix();after=path.read_bytes();before=(S/rel).read_bytes() if (S/rel).is_file() else b''
 if before==after:unchanged.append({'path':rel,'sha256':sha(before)});continue
 if (S/rel).exists():assert sha(before)==baseline[rel]['sha256'],rel
 assert not path.is_symlink() and path.suffix not in ('.db','.sqlite','.sqlite3','.pyc','.pyd'),rel
 for marker in (b'CloudStandin',b'fixture-admin',b'synthetic-device',b'dm-fixture-account',b'fixture-password'):assert marker not in after,(rel,marker)
 dest=D/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(after)
 rows.append({'path':rel,'change':'modified' if (S/rel).is_file() else 'added','before':{'sha256':sha(before),'size':len(before)} if (S/rel).is_file() else None,'after':{'sha256':sha(after),'size':len(after)},'beforeCRLF':before.count(b'\r\n'),'afterCRLF':after.count(b'\r\n'),'beforeBareLF':before.count(b'\n')-before.count(b'\r\n'),'afterBareLF':after.count(b'\n')-after.count(b'\r\n')})
 patch.extend(difflib.diff_bytes(difflib.unified_diff,before.splitlines(keepends=True),after.splitlines(keepends=True),fromfile=('a/'+rel).encode(),tofile=('b/'+rel).encode(),n=3))
raw=b''.join(patch);(W/'SOURCE.patch').write_bytes(raw)
# Apply every hunk to the pinned baseline bytes in memory, including original
# CRLF content lines; no permissive whitespace normalization or fuzzy matching.
lines=raw.splitlines(keepends=True);index=0;replayed=[]
while index<len(lines):
 assert lines[index].startswith(b'--- a/');rel=lines[index][6:].rstrip(b'\r\n').decode();index+=1
 assert lines[index].startswith(b'+++ b/');index+=1
 base=(S/rel).read_bytes().splitlines(keepends=True) if (S/rel).is_file() else [];out=[];old_index=0
 while index<len(lines) and lines[index].startswith(b'@@ '):
  match=re.match(rb'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',lines[index]);assert match
  start=max(0,int(match[1])-1);assert start>=old_index;out.extend(base[old_index:start]);old_index=start;index+=1
  removed=added=0
  while index<len(lines) and not lines[index].startswith((b'@@ ',b'--- a/')):
   line=lines[index];index+=1
   if line[:1] in (b' ',b'-'):assert old_index<len(base) and base[old_index]==line[1:],rel;old_index+=1;removed+=1
   if line[:1] in (b' ',b'+'):out.append(line[1:]);added+=1
   assert line[:1] in (b' ',b'-',b'+'),line[:50]
  assert removed==int(match[2] or 1) and added==int(match[4] or 1),rel
 out.extend(base[old_index:]);body=b''.join(out);assert body==(D/rel).read_bytes(),rel;replayed.append({'path':rel,'sha256':sha(body)})
assert len(rows)==14 and len(replayed)==14
assert set(r['path'] for r in rows)==set(p.relative_to(D).as_posix() for p in D.rglob('*') if p.is_file())
# Check function-level changes in the old Python files, without counting class
# containers as independent changes to every method.
def functions(body):
 result={}
 def walk(node,prefix=''):
  for n in ast.iter_child_nodes(node):
   if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)):
    result[prefix+n.name]=ast.dump(n,include_attributes=False)
   elif isinstance(n,ast.ClassDef):walk(n,prefix+n.name+'.')
 walk(ast.parse(body));return result
changes={}
for row in rows:
 rel=row['path']
 if row['before'] and rel.endswith('.py'):
  a,b=functions((S/rel).read_bytes()),functions((D/rel).read_bytes());changes[rel]={'modified':[n for n in a if n in b and a[n]!=b[n]],'added':[n for n in b if n not in a],'removed':[n for n in a if n not in b]}
engine=changes['work/ui-runtime-r55/src/core/engine.py'];assert set(engine['modified'])=={'Core._employee_quota','Core._prepare_send'} and not engine['added'] and not engine['removed'],engine
assert not changes['work/shared-backend-integration/platform_runtime.py']['modified']
license_path=S/'work/ui-runtime-r55/work/runtime/douyin-bridge/LICENSE'
put('LICENSE-AND-INTEGRATION.json',{'thirdParty':'Yht20927/douyin-cli','upstreamCommit':'4073159bea585de6d33a4747a475669440737932','license':'MIT','existingLicense':{'path':str(license_path),'sha256':sha(license_path.read_bytes())},'copyrightNoticeRetained':True,'newDependencies':[],'reuse':['existing bundled Windows Node executable','unchanged MIT BridgeClient','unchanged original uint64 protobuf encoder/decoder/helper globals','original Python stdlib, Store and device/session/lease/CLI lifecycle'],'newRuntimeEntries':['work/ui-runtime-r55/src/core/dm_transport.py','work/ui-native-r57/dm_workbench.py','work/ui-runtime-r55/work/runtime/douyin-bridge/dm_workbench_cli.js','work/ui-runtime-r55/work/runtime/douyin-bridge/lib/dm_workbench_browser.js','work/ui-approved-implementation/ui-preview/pages/reply-dm.mjs'],'mergeRequirements':['Apply this exact overlay to original source, preserving other candidates hunks; engine has only two quota count additions','Run original freeze_ui stage/freeze for new Native dm_workbench public module + JS graph; regenerate native RELEASE and dependency manifests normally','Include the two new fixed Node sources and original unchanged BridgeClient in unified/shipped closed set; Python PINS and CLI BROWSER_SHA are exact','Ordinary standard builder must harvest the new core module; no new pip/npm/GPU/model dependency','Retain original public-send hold and dm_contract_verified=false; this candidate never grants a real transmission permission'],'notValidated':['real platform IM/account schema/current browser connection','live send or receive/read delivery','compiled ordinary Windows standard EXE/SFX','second computer','platform historical conversation/message API','XHS Windows licensed DM transport'],'historyPolicy':'Only locally saved messages from explicit bounded current requests and strictly acknowledged outgoing receipts; no platform history endpoint or guessed UID fallback','xhsCapability':'Draft only; execution explicitly unavailable','upstreamRefresh':{'path':str(W/'UPSTREAM-REFRESH.json'),'sha256':sha((W/'UPSTREAM-REFRESH.json').read_bytes())}})
put('SOURCE-PINS.json',{'status':'SOURCE_ONLY_CANDIDATE_NOT_INSTALLED','createdAt':datetime.now(timezone.utc).isoformat(),'baseline':str(S),'baselineUnified':{'path':str(F/'UNIFIED-PINS.json'),'sha256':sha((F/'UNIFIED-PINS.json').read_bytes())},'mergeDirectory':str(D),'files':rows,'oldFiles':sum(r['change']=='modified' for r in rows),'newFiles':sum(r['change']=='added' for r in rows),'unchangedCopiedWorkingFilesExcluded':unchanged,'patch':{'path':str(W/'SOURCE.patch'),'sha256':sha(raw),'size':len(raw),'hunks':sum(l.startswith(b'@@ ') for l in lines)},'byteExactReplay':replayed,'functionChanges':changes,'canonicalOrRuntimeWritten':False,'noQADataInMergeTree':True})
print(json.dumps({'files':len(rows),'old':sum(r['change']=='modified' for r in rows),'new':sum(r['change']=='added' for r in rows),'hunks':sum(l.startswith(b'@@ ') for l in lines),'sourcePins':sha((W/'SOURCE-PINS.json').read_bytes()),'patch':sha(raw),'changes':changes},ensure_ascii=False))
