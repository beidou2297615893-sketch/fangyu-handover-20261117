from pathlib import Path
from datetime import datetime, timezone
import ast, hashlib, json
D=Path(__file__).resolve().parent;W=D.parent;P=D.parents[2]
F=P/'work/parallel-integration-20261018/final-integration'
C=F/'candidate-unified-v80';S=C/'project';B=F/'candidate-unified-v79/project'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(C/'UNIFIED-PINS.json')=='ad24e091a0a2be1fe1e30b9ea75fb20709e05d49e6b49f9b4a3b63298e62757f'
assert sha(C/'STAGED.json')=='1bbce34364b8a8769131bebf1ea1a2edfe83b25a6861756bd72a95923bd895e1'
stage=json.loads((C/'STAGED.json').read_text('utf-8'))
pins=json.loads((C/'UNIFIED-PINS.json').read_text('utf-8'))
for row in pins['files']:assert sha(S/row['path'])==row['sha256']
evidence=[]
def include(path,expected=None):
    if expected:assert sha(path)==expected
    evidence.append({'path':str(path.relative_to(W)),'sha256':sha(path),'bytes':path.stat().st_size})
include(W/'expansion-f79-final-integration/FROZEN-INPUTS.json','d4c5bdcd4463d995bf4db213aad7965f89379fe09571d83ef5ac91507ad9f504')
include(W/'expansion-f79-joint-regression/FINAL-RECEIPT.json','0239d978f22bef059764cc495ec3f66ff0df521bf7a9a07ac3f3ee68fce53e6e')
include(W/'expansion-f79-joint-regression/SEALED.json','92b6501a129d1a959dafd83e81ea61b8a457216e6db92f94e7cc4404d44a9dba')
include(W/'expansion-f80-schedule-dm-review/FINAL-RECEIPT.json','0b869619c4d4197724a4c1cbf1d7a41df50bf9312e66dd0feba4f690860d9d82')
include(W/'expansion-f80-schedule-dm-review/SEALED.json','418e0e0dc5e5f2daf1d883668a6dbef64edea70358b80f23aa80776b6f6a1ae9')
V=W/'expansion-f80-native-validation'
for name in ('root','temp','asset','normal'):
    folder=V/('path-fixed-'+name)
    r=json.loads((folder/'RESULTS.json').read_text('utf-8'))
    f=json.loads((folder/'FINAL.json').read_text('utf-8'))
    assert r['status']=='PASS' and r['recordsUnchanged'] and not r['outsideWrites']
    assert f['ownServicesClosed'] and not f['blocked']
    if name!='normal':assert not r['processes']
    include(folder/'RESULTS.json');include(folder/'FINAL.json')
folder=V/'http-2d0b10770cfe472eadd29a2a9af5d024'
r=json.loads((folder/'RESULTS.json').read_text('utf-8'));f=json.loads((folder/'FINAL.json').read_text('utf-8'))
assert r['status']=='PASS_INDEPENDENT_ORIGINAL_FACTORY_MEDIA_BOUNDARIES' and r['groups']==4
assert r['realModelPlatformCalls']==0 and f['ownServicesClosed'] and not f['blocked']
include(folder/'RESULTS.json');include(folder/'FINAL.json')
factory=json.loads((V/'FACTORY-RESULTS.json').read_text('utf-8'))
lifecycle=json.loads((V/'RETIREMENT-FACTORY-RESULTS.json').read_text('utf-8'))
assert factory['status']==lifecycle['status']=='PASS' and factory['checks']==4
assert factory['allOwnServersClosed'] and len(lifecycle['checks'])==12
assert lifecycle['originalRetiredRecordsUnchanged'] and lifecycle['realPlatformOrModelCalls']==0
include(V/'FACTORY-RESULTS.json');include(V/'RETIREMENT-FACTORY-RESULTS.json');include(V/'OWN-JUNCTION-FIXTURES.json')
def methods(root):
    tree=ast.parse((root/'work/ui-runtime-r55/src/core/engine.py').read_bytes())
    core=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='Core')
    return {n.name:ast.dump(n,include_attributes=False) for n in core.body if isinstance(n,ast.FunctionDef)}
old,new=methods(B),methods(S)
changed={k for k in old if old[k]!=new.get(k)}
assert changed=={'_employee_quota','_save','_import','_run_inner','_prepare_send'}
assert old.keys()==new.keys()
for name in ('account_delete_digest','_delete_account_locked','_account_access','_task_access'):
    assert name in old and old[name]==new[name]
receipt={'status':'PASS_FIXED_F80_AGGREGATE_PRIVATE_ACCEPTANCE_NOT_PLATFORM_OR_COMMERCIAL_COMPLETION',
    'createdUtc':datetime.now(timezone.utc).isoformat(),'candidate':C.name,
    'sourceFilesVerified':len(pins['files']),'releaseResources':stage['files'],
    'originalBusinessGroups':47,'originalAccountGroups':8,'keywordWrapperGroups':11,
    'scheduleFactoryRepresentativeGroups':4,'scheduleFullIndexUiChecks':13,
    'dmFactoryGroups':5,'dmFullIndexUiChecks':15,
    'rootIndependentMediaPathGroups':4,'rootIndependentMediaBoundaryGroups':4,
    'rootOriginalQueryFactoryGroups':4,'rootQueryRetirementLifecycleGroups':12,
    'coreOriginalMethodsUnchanged':len(old)-len(changed),'coreChangedMethods':sorted(changed),
    'rootFirstPathHarnessRed':'Missing precreated own junction; retained path-root/FINAL.json. New physical path-fixed fixtures actually tested.',
    'productionAccess':False,'canonicalOrInstalledWritten':False,'realPlatformOrModelCalls':0,
    'limits':['Not a native human first-open or current platform login/collection receipt',
              'DM real transport/history and real publication remain held or unverified',
              'Ordinary compiled package and another physical computer acceptance remain',
              'Scanned PDF successor and other full-scope items are not included in F80'],
    'evidence':evidence}
assert not (D/'AGGREGATE-VALIDATION.json').exists()
(D/'AGGREGATE-VALIDATION.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),'utf-8')
final={'rootExplicitFinalPins':True,'candidate':C.name,'unifiedPinsSha256':sha(C/'UNIFIED-PINS.json'),
       'stagedSha256':sha(C/'STAGED.json'),'manifestSha256':stage['manifest_sha256'],
       'releaseId':stage['release_id'],'unifiedFileCount':len(pins['files']),'releaseFileCount':stage['files'],
       'launcherSha256':sha(Path(stage['launcher'])),'validationSha256':sha(D/'AGGREGATE-VALIDATION.json')}
(D/'FINAL-PINS.json').write_text(json.dumps(final,ensure_ascii=False,indent=2),'utf-8')
print(json.dumps({'status':receipt['status'],'validationSha256':sha(D/'AGGREGATE-VALIDATION.json'),'finalPinsSha256':sha(D/'FINAL-PINS.json')}))
