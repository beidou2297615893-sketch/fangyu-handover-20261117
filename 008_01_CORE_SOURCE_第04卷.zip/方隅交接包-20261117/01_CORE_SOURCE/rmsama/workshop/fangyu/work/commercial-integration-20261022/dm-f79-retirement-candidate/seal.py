from pathlib import Path
import ast,datetime,hashlib,json
W=Path(__file__).resolve().parent;C=W.parent/'dm-f79-candidate';Old=W.parent/'dm-f79-independent-review';Q=W/'qa-only-project';O=W/'factory-e3c0c23304cd4bc18133881d113d94c6';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pins=json.loads((W/'SOURCE-PINS.json').read_text('utf-8'));assert len(pins['files'])==2
for row in pins['files']:
 assert sha(C/'final-source'/row['path'])==row['before']['sha256']
 assert sha(W/'final-source'/row['path'])==sha(Q/row['path'])==row['after']['sha256']
paths={r['path'] for r in pins['files']};base=json.loads((C/'SOURCE-PINS.json').read_text('utf-8'));unchanged={}
for row in base['files']:
 if row['path'] not in paths:assert sha(Q/row['path'])==row['after']['sha256'];unchanged[row['path']]=sha(Q/row['path'])
rel='work/ui-native-r57/dm_workbench.py'
def methods(p):
 cls=next(n for n in ast.parse(p.read_bytes()).body if isinstance(n,ast.ClassDef) and n.name=='DMWorkbench')
 return {n.name:ast.dump(n,include_attributes=False) for n in cls.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
a=methods(C/'final-source'/rel);b=methods(W/'final-source'/rel)
assert set(b)-set(a)=={'_retired_request_view'} and not set(a)-set(b)
for name in a:
 if name!='execute':assert a[name]==b[name],name
old=(C/'final-source'/rel).read_text('utf-8');new=(W/'final-source'/rel).read_text('utf-8')
extra="   if entity==QUEUES and self.core.store.get('accounts',current['accountId']) is None:\n    return self._retired_request_view(record,current,user,store,refresh)\n   self._account(user,store,current['accountId'])\n"
assert new.count(extra)==1
restored=new[new.index(' def execute('):].replace(extra,"   self._account(user,store,current['accountId'])\n").replace("   current=self._owned(entity,value['id'],user,store)\n   self._account", "   current=self._owned(entity,value['id'],user,store);self._account")
assert restored==old[old.index(' def execute('):]
assert sha(C/'SEALED.json')=='629459cd38891f60a752678059b270e747f5f7c53430e71412c30017fb29950e'
assert sha(Old/'SEALED.json')=='366a12552d831a05d99184ec23733e1ee1b88b01c45e4ffa1d33d0f2a444f251'
company=Q/'work/app/company.json';assert sha(company)==sha(C/'qa-only-project/work/app/company.json') and json.loads(company.read_text('utf-8'))['runtime']['public_send_hold'] is True
result=json.loads((O/'RESULTS.json').read_text('utf-8'));end=json.loads((O/'FINAL.json').read_text('utf-8'));ui=json.loads((O/'UI-RESULTS.json').read_text('utf-8'));green=json.loads((O/'RETIREMENT-GREEN.json').read_text('utf-8'));afterui=json.loads((O/'AFTER-UI.json').read_text('utf-8'))
assert result['status']=='PASS_REPRESENTATIVE' and len(result['checks'])==5 and all(x.get('result')=='PASS' for x in result['checks'])
assert end['allOwnServersClosed'] and ui['status']=='PASS' and len(ui['checks'])==15 and not ui['errors']
assert afterui['exactlyOneSyntheticSend'] and afterui['unknownDraftByteUnchanged'] and afterui['claimByteUnchanged']
assert '该客户正在发送或上次结果待核对' in green['crossAccountClaimStillBlocked']['message']
preservation={'sourceOnlyFiles':2,'allOtherDmV1FilesUnchanged':unchanged,'allPriorDmMethodsAstUnchangedExceptOriginalRequestReadBranch':True,'executeExactInverseRestoresOriginal':True,'newHelperOnlyReadCalls':True,'nativeRuntimeCoreAdaptersHostPermissionsModeDeletionWireAndSendSourcesUnchanged':True,'defaultSourceCompanyHoldByteUnchanged':sha(company),'originalDmSealStillFixed':sha(C/'SEALED.json'),'independentRedSealStillFixed':sha(Old/'SEALED.json')}
(W/'PRESERVATION.json').write_text(json.dumps(preservation,ensure_ascii=False,indent=2)+'\n','utf-8')
notes='''DM 原账号移除后的未知结果恢复（两份源的后继）

修复结果：本人当前员工/门店授权及私信权限仍有效，且原请求、原队列、原未知草稿和软件账号移除回执、原 Core 删除审计相互一致时，可继续按原编号只读查看未知结果。原账号不存在不再让该查询直接403。缺证、伪删除、他人、异店和撤权仍拒绝。执行、发送、监听、账号删除 CAS、原模式租约、原客户防重、默认 hold 全部保持。

界面：原移除账号、原编号、原未知条目独立展示，说明只读待核；仍可选用其他当前账号，其执行仍受原客户占位约束。原编号单独保存在只读查询槽，不用当前账号重建操作，也不永久锁住其他账号的草稿。没有新增认证库或客户库。

证据：最终5组原 Native 工厂（89次自有HTTP调用；请求数不是组数）、9个边界反例，以及原完整 index/fit/iframe 的 development headless Chromium15项（1255/390）。第一次 synthetic unknown 仅一次发送；真实关闭重开后查询、账号删除、后续原 key 查询均零新增平台命令；跨账号对照明确命中原客户占位原因。未知草稿/队列/原占位完整字节未变。真实平台/模型调用0，所有自有服务关闭。

原红在 dm-f79-independent-review 保留。本候选首轮factory-40f5786ed8314bc3a6f3281c3f40d605的退休查询和UI通过，但重开后跨账号被更早设备门拒绝，不能算claim命中。第二轮factory-29c394f2aa804c5e858cfcd7280b145b收紧原因断言后因原public hold拒绝而RED，完整异常/HTTP保留。最终只补本测试自己的原合成device RAM许可和临时QA配置，经原会话重绑定后精确命中原claim；没有替换守卫、没有改源hold。

仅final-source两文件可叠加至原已封DM14；qa-only-project及其新manifest用于诚实原工厂校验，非正式冻结或分发包。真实自然授权、抖音线协议、真实发收/历史及普通电脑实机仍未验证，原hold继续保留。只读删除凭据是原Store的受控业务记录，摘要用于关联一致性，不宣称密码学不可伪造或OS沙箱。
'''
(W/'HANDOFF.md').write_text(notes,'utf-8')
summary={'status':'PASS_SOURCE_ONLY_RETIREMENT_SUCCESSOR','groups':5,'negativeCases':9,'factoryHttpRequests':result['httpRequests'],'chromiumChecks':15,'chromiumDmHttpRequests':len(ui['http']),'sizes':[1255,390],'effectiveWarningMinPx':min(m['inner']['effectivePx'] for m in ui['metrics']),'allOtherDmV1SourceCountUnchanged':len(unchanged),'originalUnknownKey':'review-fixed-original-unknown-key','afterDeleteLookup':'200 unknown accountRemoved=true','oneSyntheticSendTotal':True,'oldDraftQueueClaimExactUnchanged':True,'postDeleteCrossAccountRefusal':'original customer claim exact reason','realPlatformModelCalls':0,'allOwnServicesClosed':True,'officialSourceOrNativeWrites':False}
(W/'SUMMARY.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n','utf-8')
evidence=[W/'SOURCE-PINS.json',W/'SOURCE.patch',W/'PRESERVATION.json',W/'HANDOFF.md',W/'SUMMARY.json',W/'INPUTS.json',O/'RESULTS.json',O/'FINAL.json',O/'HTTP.json',O/'RETIREMENT-GREEN.json',O/'RETIREMENT-NEGATIVES.json',O/'UNKNOWN-ACCOUNT-DELETE.json',O/'UI-RESULTS.json',O/'AFTER-UI.json',O/'retirement-1255.png',O/'retirement-390.png']
receipt={'status':summary['status'],'createdUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'mergeDirectory':str(W/'final-source'),'sourcePinsSha256':sha(W/'SOURCE-PINS.json'),'patchSha256':sha(W/'SOURCE.patch'),'summary':summary,'stage':json.loads((W/'INPUTS.json').read_text('utf-8'))['stage'],'evidence':{str(p.relative_to(W)):sha(p) for p in evidence},'originalRedReceiptSha256':sha(Old/'FINAL-RECEIPT.json'),'protectedSourceAndCurrentUserWindowUntouched':True}
(W/'FINAL-RECEIPT.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n','utf-8')
seal={'status':'SEALED_STOP_WRITING','receiptSha256':sha(W/'FINAL-RECEIPT.json'),'sourcePinsSha256':sha(W/'SOURCE-PINS.json'),'files':{str(p.relative_to(W)):sha(p) for p in [W/'FINAL-RECEIPT.json',*evidence,*[W/'final-source'/r['path'] for r in pins['files']]]}}
(W/'SEALED.json').write_text(json.dumps(seal,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps({'receipt':sha(W/'FINAL-RECEIPT.json'),'sealed':sha(W/'SEALED.json'),'sourcePins':sha(W/'SOURCE-PINS.json'),'patch':sha(W/'SOURCE.patch'),'files':pins['files'],'summary':summary},ensure_ascii=False,indent=2))
