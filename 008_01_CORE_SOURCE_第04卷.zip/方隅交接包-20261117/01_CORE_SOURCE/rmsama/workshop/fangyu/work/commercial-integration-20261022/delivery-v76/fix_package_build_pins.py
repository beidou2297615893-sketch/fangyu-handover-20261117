from pathlib import Path
import hashlib, json
D=Path(__file__).resolve().parent
T=D.parent/'next-release-integration-preflight/standard-tools-v76'
B=T/'standard-held-clean-v76'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
build=json.loads((B/'BUILD.json').read_text('utf-8'))
assert build['files']==3931 and build['installerSha256']=='602f2bc7f30743c5c83b9b9194ab9e706e40f98e344ed956bbea543c63b466a8'
paths=['BUILD.json','STAGE.json','FILE-MANIFEST.json','standard_entry.py','installer.protected.py',
 'payload/project/SHIPPED-PINS.json','payload/project/HELD-STANDARD-MANIFEST.json',
 'dist/FangyuWorkbench/FangyuWorkbench.exe',build['portableZip'],build['installer']]
pins={rel:{'sha256':sha(B/rel),'bytes':(B/rel).stat().st_size} for rel in paths}
assert pins[build['portableZip']]['sha256']==build['portableSha256']
assert pins[build['installer']]['sha256']==build['installerSha256']
out={'status':'FIXED_V76_STANDARD_BUILD_INPUTS_FOR_INDEPENDENT_REVIEW_NOT_DELIVERY_APPROVAL',
 'rootFinalPinsSha256':sha(D/'FINAL-PINS.json'),'rootFinalPins':json.loads((D/'FINAL-PINS.json').read_text('utf-8')),
 'package':str(B),'builderSha256':sha(T/'build_clean_next.py'),'toolingSha256':sha(T/'TOOLING.json'),
 'pins':pins,'codeAndArchivesStoppedWriting':True,'nativeStarted':False,'productionAccess':False,
 'realPlatformOrModelCalls':0,'publicOutputCopied':False,'independentPackageReviewPending':True}
target=D/'BUILD-FIXED-PINS.json';assert not target.exists()
target.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':out['status'],'descriptorSha256':sha(target),'installerSha256':build['installerSha256'],'files':build['files']}))
