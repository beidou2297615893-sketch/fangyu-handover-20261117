from pathlib import Path
import hashlib,json,re
W=Path(__file__).resolve().parent;P=W.parents[2];S=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v81/project';O=W/'source-candidate';Q=W/'qa-only-project'
B='work/ui-runtime-r55/work/runtime/douyin-bridge/'
sha=lambda b:hashlib.sha256(b).hexdigest()
changes=[]
def write(rel,text):
 old=S/rel;raw=text.encode('utf-8')
 if old.exists() and b'\r\n' in old.read_bytes():raw=raw.replace(b'\r\n',b'\n').replace(b'\n',b'\r\n')
 for root in [O,Q]:
  p=root/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
 changes.append({'path':rel,'beforeOrigin':'immutable F81','before':{'sha256':sha(old.read_bytes()),'bytes':old.stat().st_size} if old.exists() else None,'after':{'sha256':sha(raw),'bytes':len(raw)}})
def read(rel):return (S/rel).read_text('utf-8')
def sub(text,a,b):
 assert text.count(a)==1,(a[:100],text.count(a));return text.replace(a,b)
write(B+'lib/server/dm.js',(W/'dm.js').read_text('utf-8'))
t=read(B+'lib/server/registry.js')
t=sub(t,"      userAgent: meta.userAgent || '',","      userAgent: meta.userAgent || '',\n      dmContract: meta.dmContract || '',\n      dmSourceDigest: meta.dmSourceDigest || '',")
t=sub(t,'  getAll(site) {', '''  dmConnection(connId, sourceDigest) {
    const conn=this.getById('douyin.com',connId);
    if(!conn||conn.ws!==null||conn.dmContract!=='fangyu-dm-typed-v1'||conn.dmSourceDigest!==sourceDigest||Date.now()-Date.parse(conn.lastActivity)>90000)return null;
    try{const u=new URL(conn.url);if(u.protocol!=='https:'||u.hostname!=='www.douyin.com'||u.username||u.password)return null;}catch{return null;}
    return conn;
  }

  getAll(site) {''')
write(B+'lib/server/registry.js',t)
t=read(B+'lib/server/router.js')
t=sub(t,"const { safeSerialize } = require('../shared/serialize');","const { safeSerialize } = require('../shared/serialize');\nconst { DMRouter } = require('./dm');")
t=sub(t,'    this._pending = new Map();','    this._pending = new Map();\n    this.dm = new DMRouter(this);')
t=sub(t,'      if (pending) {','      if (pending && !pending.dmConnId) {')
t=sub(t,"      if (method === 'POST' && path === '/api/call') {","      if (method === 'POST' && path === '/api/dm/call') return this.dm.call(req,res);\n      if (method === 'POST' && path === '/api/dm/result') return this.dm.result(req,res);\n      if (method === 'POST' && path === '/api/call') {")
t=sub(t,"userAgent: body.userAgent || '' };","userAgent: body.userAgent || '', dmContract: body.dmContract || '', dmSourceDigest: body.dmSourceDigest || '' };")
t=sub(t,'      const cmd = queue.shift();\n      if (queue.length === 0) this._pollQueue.delete(queueKey);','      const cmd = queue.shift();\n      if (queue.length === 0) this._pollQueue.delete(queueKey);\n      if (cmd.dm) { this._sendJson(res,200,cmd.dm); return; }')
t=sub(t,'    const pending = this._pending.get(id);\n    if (pending) {','    const pending = this._pending.get(id);\n    if (pending && pending.dmConnId) return this._sendJson(res,409,{ok:false,error:"Typed DM result requires its exact connection route"});\n    if (pending) {')
write(B+'lib/server/router.js',t)
t=read(B+'lib/client/bridge-client.js')
t=sub(t,'  async status() {', '''  async directMessages(command) {
    if(!['127.0.0.1','localhost'].includes(this.host)||!this.token)throw new Error('Explicit local DM Bridge configuration required');
    return this._post('/api/dm/call',command);
  }

  async status() {''')
write(B+'lib/client/bridge-client.js',t)
t=read(B+'dm_workbench_cli.js')
a=t.index(" const install=require('./lib/dm_workbench_browser');")
b=t.index('\n}',a)
t=t[:a]+''' const command={operation,connId:options['--conn-id'],expectedUid:options['--expected-uid'],requestId:options['--request-id']};
 if(operation==='listen')command.timeoutMs=Number(options['--timeout']);
 if(operation==='send'){command.recipient=options['--recipient'];command.text=options['--text'];}
 const reply=await call(command);
 if(reply?.ok!==true||reply.connection!==command.connId||reply.value?.contract!=='fangyu-dm-bounded-v1'||reply.value?.request_id!==command.requestId)throw Error('DM fixed connection/result unconfirmed');
 return reply.value;'''+t[b:]
t=sub(t,'p=>client.call(p)','p=>client.directMessages(p)')
write(B+'dm_workbench_cli.js',t)
# Convert the already bundled codec from a static eval string into a callable
# static factory for the typed handler. The old generic Bridge still receives
# that same codec through its original static injection; DM never calls eval.
t=read(B+'scripts/douyin.user.js')
t=sub(t,"            userAgent: navigator.userAgent,","            userAgent: navigator.userAgent,\n            dmContract: CONFIG.token ? 'fangyu-dm-typed-v1' : '',\n            dmSourceDigest: CONFIG.token ? 'b0847e7a4cb2804317d1001786baa0b0fa9cc8ad333457e065bb37266f64db8b' : '',")
t=sub(t,"      if (msg.type === 'eval') {",'''      if (msg.type === 'fangyu-dm') {
        // Dispatch in parallel only to permit the exact listener stop command.
        // No automatic retry, reconnect or expression evaluation in this path.
        handleFixedDM(msg).catch(function(){ /* original host retains unknown */ });
        poll();
      } else if (msg.type === 'eval') {''')
t=sub(t,'  var DM_BRIDGE_CODE = (function () {/*','''  function reviewedDMCodec(page) {
    const document=page.document,localStorage=page.localStorage,crypto=page.crypto;
    function getCookie(name){const m=document.cookie.match(new RegExp('(?:^|; )'+name+'=([^;]*)'));return m?decodeURIComponent(m[1]):'';}''')
t=sub(t,"*/}).toString().match(/\\/\\*([\\s\\S]*)\\*\\//)[1];\n  unsafeWindow.eval(DM_BRIDGE_CODE);",'''    return {proto:_DM_PROTO,helpers:_DM_HELPERS};
  }
  var DM_BRIDGE_CODE='var __dmCodec=('+reviewedDMCodec.toString()+')(window);var _DM_PROTO=__dmCodec.proto;var _DM_HELPERS=__dmCodec.helpers;';
  unsafeWindow.eval(DM_BRIDGE_CODE);''')
browser=read(B+'lib/dm_workbench_browser.js');fn=browser[browser.index('function installReviewedDM'):].rstrip().removesuffix(';')
typed='''
  // BEGIN FIXED TYPED DM HANDLER (no caller source/eval)
  let fixedDM=null;
  function fixedDMApi(){
    if(fixedDM)return fixedDM;
    const page=unsafeWindow;
    if(page.location.protocol!=='https:'||page.location.hostname!=='www.douyin.com')throw Error('Exact Douyin page required');
    const codec=reviewedDMCodec(page),_DM_PROTO=codec.proto,_DM_HELPERS=codec.helpers;
    const window={},fetch=page.fetch.bind(page),WebSocket=page.WebSocket,crypto=page.crypto;
    const install='''+fn+''';
    install('b0847e7a4cb2804317d1001786baa0b0fa9cc8ad333457e065bb37266f64db8b');
    fixedDM=window.__fangyuDMV1;return fixedDM;
  }
  async function handleFixedDM(msg){
    if(!CONFIG.token||!connId||msg.contract!=='fangyu-dm-typed-v1'||msg.sourceDigest!=='b0847e7a4cb2804317d1001786baa0b0fa9cc8ad333457e065bb37266f64db8b')throw Error('Fixed DM source/config required');
    const c=msg.command,fields=['operation','connId','expectedUid','requestId',...(c?.operation==='listen'?['timeoutMs']:c?.operation==='send'?['recipient','text']:[])];
    if(!c||c.connId!==connId||!['listen','stop','send'].includes(c.operation)||Object.keys(c).some(k=>!fields.includes(k))||fields.some(k=>!Object.hasOwn(c,k)))throw Error('Fixed DM connection/fields required');
    let value,error;
    try{
      const api=fixedDMApi();
      value=c.operation==='listen'?await api.listen(c.expectedUid,c.requestId,c.timeoutMs):c.operation==='stop'?api.stop(c.requestId):await api.send(c.expectedUid,c.recipient,c.text,c.requestId);
    }catch(e){error='DM result unconfirmed; preserve original request';}
    await gmFetch(CONFIG.server+'/api/dm/result',{method:'POST',headers:{'Content-Type':'application/json'},data:JSON.stringify({id:msg.id,connId:connId,value:value,error:error})});
  }
  // END FIXED TYPED DM HANDLER
'''
t=sub(t,"  console.log('[Bridge:Douyin] DM Bridge lib injected');",typed+"\n  console.log('[Bridge:Douyin] DM Bridge lib injected');")
write(B+'scripts/douyin.user.js',t)
t=read('work/ui-runtime-r55/src/core/dm_transport.py')
start=t.index('PINS={');end=t.index('\ndef direct_messages',start)
pins={r['path'][len(B):]:r['after']['sha256'] for r in changes if r['path'].startswith(B)}
pins['lib/dm_workbench_browser.js']=sha((S/(B+'lib/dm_workbench_browser.js')).read_bytes())
t=t[:start]+'PINS='+repr(pins)+t[end:]
t=sub(t,'if len(PINS)!=3:','if len(PINS)!='+str(len(pins))+':')
write('work/ui-runtime-r55/src/core/dm_transport.py',t)
(W/'SOURCE-FILES.draft.json').write_text(json.dumps({'baseline':str(S),'files':changes},ensure_ascii=False,indent=2),'utf-8')
print(json.dumps({'sourceFiles':len(changes),'dmPins':len(pins),'paths':[r['path'] for r in changes]},ensure_ascii=False))
