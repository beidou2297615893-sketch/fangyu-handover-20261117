"""Windows-only OCR/local voice services over the ORIGINAL media scope/Store.

No voice/model/FFmpeg binary or Python dependency is bundled. The fixed Windows
bridge has no network/provider or user command option; voices are OS Desktop
Microsoft voices. Recognition is a preview, never an automatic business fact.
"""
from pathlib import Path
from copy import deepcopy
import base64,ctypes,hashlib,io,json,os,re,stat,subprocess,tempfile,threading,time,unicodedata,uuid,wave
from PIL import Image
from .cpu_media_engine import checked_file,digest,fail,MediaError,_WindowsJob
from .media_production import MediaProduction,ASSETS,exact,ident,now

ACTIONS=frozenset('media_services_status media_ocr_preview media_speech_preview media_speech_cancel media_speech_save media_speech_read'.split())
SCRIPT_SHA='229d87a3c263ff4c8254141a2410cbe09661f046d8f9f671144f7dadf05db0bc'
LICENSE_SHA='693ec2093ced2cd46d24646644e9fca8cb3b3edce928e6df35522962e3175041'
MAX_IMAGE=2*1024*1024;MAX_WAV=2*1024*1024

def _text(value,limit):
    if not isinstance(value,str) or not value.strip() or len(value)>limit or any(unicodedata.category(c) in ('Cf','Cs') or ord(c)<32 and c not in '\n\r\t' for c in value):fail('MEDIA_INPUT_INVALID','请输入有效的普通文字')
    return value

class WindowsBridge:
    def __init__(self,root):self.root=Path(root)
    def call(self,value,cancel=None):
        if os.name!='nt':fail('MEDIA_SERVICE_UNAVAILABLE','此电脑没有 Windows 系统提字与声音服务；不会下载工具')
        here=Path(__file__).resolve().parent
        for name,pin in [('windows_media_bridge.ps1',SCRIPT_SHA),('LICENSE-microsoft-samples.txt',LICENSE_SHA)]:
            if hashlib.sha256(checked_file(here/name,here,100000)).hexdigest()!=pin:fail('MEDIA_SERVICE_INVALID','媒体服务组件校验未通过')
        buffer=ctypes.create_unicode_buffer(32768)
        if not ctypes.windll.kernel32.GetWindowsDirectoryW(buffer,len(buffer)):fail('MEDIA_SERVICE_UNAVAILABLE','Windows 系统位置无法核对')
        exe=Path(buffer.value)/'System32/WindowsPowerShell/v1.0/powershell.exe'
        if not exe.is_file():fail('MEDIA_SERVICE_UNAVAILABLE','此电脑没有可用的 Windows PowerShell 5 系统组件')
        process=subprocess.Popen([str(exe),'-NoLogo','-NoProfile','-NonInteractive','-File',str(here/'windows_media_bridge.ps1')],executable=str(exe),stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,cwd=self.root,shell=False,creationflags=subprocess.CREATE_NO_WINDOW)
        job=_WindowsJob(process)
        finished=threading.Event()
        def watch():
            while not finished.wait(.05):
                if cancel is not None and cancel.is_set():
                    if process.poll() is None:process.terminate()
                    return
        watcher=threading.Thread(target=watch,daemon=True);watcher.start()
        try:
            try:stdout,_=process.communicate(json.dumps(value,ensure_ascii=False).encode('utf-8'),timeout=45)
            except subprocess.TimeoutExpired:fail('MEDIA_SERVICE_TIMEOUT','本机媒体处理超时，本次未保存；请缩小输入后重试')
            if cancel is not None and cancel.is_set():fail('MEDIA_SERVICE_CANCELLED','这次配音已停止，没有保存素材')
            if process.returncode or len(stdout)>600000:fail('MEDIA_SERVICE_UNAVAILABLE','系统媒体服务未完成，请检查已安装的语言或声音；本次未保存')
            try:result=json.loads(stdout.decode('utf-8-sig'))
            except (ValueError,UnicodeError):fail('MEDIA_SERVICE_INVALID','系统媒体回执无法核对')
            if not isinstance(result,dict) or result.get('status')!='ok':fail('MEDIA_SERVICE_UNAVAILABLE','当前系统语言或声音不可用；不会自动下载')
            return result
        finally:
            finished.set();watcher.join(timeout=1)
            if process.poll() is None:process.kill();process.wait(timeout=3)
            job.close()

class MediaServices:
    def __init__(self,native):
        self.native=native;self.owner=native.owner;self.lock=threading.RLock();self.previews={};self.worker_lock=threading.RLock();self.workers={}
        self.root=native.root;self.root.mkdir(parents=True,exist_ok=True);self.temp=self.root/'services-temp';self.temp.mkdir(exist_ok=True)
        self.bridge=WindowsBridge(self.temp)
    def close(self):
        for worker in list(self.workers.values()):worker['cancel'].set()
        for worker in list(self.workers.values()):
            if worker.get('thread'):worker['thread'].join(timeout=3)
        self.previews.clear()
    def service(self):
        component=self.owner._content_component();module=__import__('sys').modules[component.__module__]
        return MediaProduction(component(self.owner.core.store),module.ContentScope,self.root,self.native.ingest,None)
    def _workspace(self,data,token):
        return self.owner._content_dispatch('content_workspace_read',{k:data[k] for k in ('storeId','accountId','platform')},token)
    def _current(self,before,data,token,fresh):
        fresh();after=self._workspace(data,token)
        if before['workspace']['actor']!=after['workspace']['actor'] or before['workspace']['revision']!=after['workspace']['revision']:fail('MEDIA_SCOPE_CHANGED','账号、门店或内容版本已变化，本次结果未采用')
        after['actor']=deepcopy(after['workspace']['actor'])
        return after
    @staticmethod
    def _view_audio(raw):
        try:
            with wave.open(io.BytesIO(raw),'rb') as w:
                duration=w.getnframes()/w.getframerate()
                if w.getnchannels()!=1 or w.getsampwidth()!=2 or w.getframerate()!=16000 or not 0<duration<=60:raise ValueError()
                return {'durationMs':round(duration*1000),'channels':1,'sampleRate':16000,'sampleBytes':2,'hasAudio':True}
        except (ValueError,wave.Error,EOFError,ZeroDivisionError):fail('MEDIA_OUTPUT_INVALID','配音格式或时长未通过核对，本次未保存')
    def _render_speech(self,worker,request,scope,user,binding,before,data,token,fresh):
        try:
            with tempfile.TemporaryDirectory(prefix='speech-',dir=self.temp) as directory:
                out=Path(directory)/'output.wav';found=self.bridge.call({'operation':'tts','text':request['text'],'voiceId':request['voiceId'],'rate':request['rate'],'outputFile':str(out)},worker['cancel'])
                raw=checked_file(out,Path(directory),MAX_WAV)
            info=self._view_audio(raw);self._current(before,data,token,fresh)
            if worker['cancel'].is_set():fail('MEDIA_SERVICE_CANCELLED','这次配音已停止，没有保存素材')
            preview={'id':uuid.uuid4().hex,'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'mime':'audio/wav','text':request['text'],'voiceId':request['voiceId'],'voiceName':found['voiceName'],'voiceLanguage':found['voiceLanguage'],'voiceVersion':found['voiceVersion'],'systemVersion':found['systemVersion'],'rate':request['rate'],'expectedRevision':request['expectedRevision'],'probe':info,'literalTextOnly':True,'source':'generated_concept','saved':False}
            preview['previewDigest']=digest(preview)
            with self.lock:
                self.previews[preview['id']]={'public':preview,'raw':raw,'time':time.monotonic(),'scope':scope.checked(),'actorId':user['id'],'binding':binding}
            with self.worker_lock:worker.update(state='succeeded',previewId=preview['id'])
        except Exception as error:
            with self.worker_lock:worker.update(state='cancelled' if worker['cancel'].is_set() else 'failed',code=getattr(error,'code','MEDIA_SERVICE_FAILED'),message=str(error) if hasattr(error,'code') else '本次配音未完成，没有保存素材')
    def dispatch(self,action,data,token):
        user,store,request,authority,fresh,binding=self.native.context(token,data)
        base={'accountId','platform'};before=self._workspace(data,token);service=self.service();scope=service._scope(user,store,request)
        if action=='media_speech_cancel':
            exact(request,base|{'requestId'});key=digest([scope.checked(),user['id'],ident(request['requestId'])])
            with self.worker_lock:
                worker=self.workers.get(key)
                if worker and worker['state']=='running':worker['cancel'].set()
                result={'requestId':request['requestId'],'state':'cancel_requested' if worker and worker['state']=='running' else worker['state'] if worker else 'not_found','saved':False}
            after=self._current(before,data,token,fresh);after['result']=result;return after
        with self.lock:
            stamp=time.monotonic();self.previews={k:v for k,v in self.previews.items() if stamp-v['time']<600}
            if action=='media_services_status':
                exact(request,base|({'requestId'} if 'requestId' in request else set()))
                capabilities=self.bridge.call({'operation':'capabilities'});assets=[]
                with service.store.connect() as db:
                    actor,_=service._authority(db,user,scope,authority,False)
                    for raw in db.execute('SELECT id,body FROM records WHERE entity=? AND tenant_id=?',(ASSETS,scope.tenant_id)):
                        row=json.loads(raw['body'])
                        if row.get('kind')=='audio' and row.get('scope')==scope.checked() and row.get('actorId')==actor['id']:
                            assets.append(service._asset_view(service._record(db,ASSETS,row['id'],scope,actor)))
                result={'capabilities':capabilities,'assets':assets[-64:],'asrAvailable':False,'asrMessage':'录音转写尚未启用。系统旧识别器的代表样本覆盖和准确率未通过；可导入已有核对文本。','systemComponentsOnly':True,'downloads':False}
                if 'requestId' in request:result['original']=service.query_request(user,store,{k:request[k] for k in ('accountId','platform','requestId')},authority)
            elif action=='media_ocr_preview':
                exact(request,base|{'filename','dataBase64'})
                name=_text(request['filename'],180)
                if any(c in name for c in '/\\:\x00') or Path(name).suffix.lower() not in ('.png','.jpg','.jpeg'):fail('KNOWLEDGE_UNSUPPORTED','系统提字支持2MB以内PNG/JPG扫描图片；扫描PDF请先另存为图片')
                value=request['dataBase64']
                if not isinstance(value,str) or len(value)>4*((MAX_IMAGE+2)//3):fail('MEDIA_LIMIT','扫描图片限2MB')
                try:raw=base64.b64decode(value,validate=True)
                except (ValueError,TypeError):fail('MEDIA_INPUT_INVALID','图片数据不完整')
                if not 0<len(raw)<=MAX_IMAGE:fail('MEDIA_LIMIT','扫描图片限2MB')
                try:
                    image=Image.open(io.BytesIO(raw))
                    if image.format not in ('PNG','JPEG') or getattr(image,'n_frames',1)!=1 or not 0<image.width<=4096 or not 0<image.height<=4096 or image.width*image.height>12000000:raise ValueError()
                    image.load();image=image.convert('RGB')
                except (OSError,ValueError,Image.DecompressionBombError):fail('MEDIA_INPUT_INVALID','请使用4096边长、1200万像素以内的单页PNG/JPG图片')
                with tempfile.TemporaryDirectory(prefix='ocr-',dir=self.temp) as directory:
                    path=Path(directory)/'input.png';image.save(path)
                    found=self.bridge.call({'operation':'ocr','inputFile':str(path)})
                lines=found.get('lines')
                if not isinstance(lines,list) or not 0<len(lines)<=2000 or any(not isinstance(t,str) for t in lines):fail('KNOWLEDGE_EMPTY','未识别到可用文字，请换清晰图片；本次未保存')
                blocks=[{'location':'图片第'+str(i)+'行','text':_text(t,5000)} for i,t in enumerate(lines,1) if t.strip()]
                text='\n\n'.join('【'+name+'｜'+b['location']+'】\n'+b['text'] for b in blocks)
                if not blocks or len(text)>100000:fail('MEDIA_LIMIT','提取文字为空或超过10万字，请拆分图片')
                preview={'filename':name,'fileSha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'type':'system_ocr','blocks':blocks,'text':text,'title':Path(name).stem[:120],'sourceLabel':name+' · 系统OCR识别，待核原图','notice':'这是机器识别的图片文字，可能漏字或错字。请逐行核对原图，确认资料类型后再保存；不代表已经核实门店事实。','previewOnly':True,'requiresManualKindConfirmation':True,'instructionsExecuted':False,'externalResourcesFetched':False,'omittedContentNotice':True,'ocrLanguage':found['language']}
                result={'filePreview':preview}
            elif action=='media_speech_preview':
                exact(request,base|{'text','voiceId','rate','expectedRevision','requestId'})
                text=_text(request['text'],300)
                if not isinstance(request['voiceId'],str) or not re.fullmatch('[a-f0-9]{24}',request['voiceId']) or type(request['rate']) is not int or request['rate'] not in (-2,0,2):fail('MEDIA_INPUT_INVALID','请选择本机声音和语速')
                if type(request['expectedRevision']) is not int or request['expectedRevision']!=before['workspace']['revision']:fail('MEDIA_VERSION_CONFLICT','内容版本已变化，请重新读取后预览')
                caps=self.bridge.call({'operation':'capabilities'});voice=next((v for v in caps['voices'] if v['id']==request['voiceId']),None)
                if not voice or re.search('[\u3400-\u9fff]',text) and voice['language']!='zh-CN':fail('MEDIA_VOICE_UNAVAILABLE','这段文字需要中文系统声音；当前未安装或未选择，不会改用英文声音')
                if len(self.previews)>=8:fail('MEDIA_CAPACITY','当前预览较多，请稍后再试')
                key=digest([scope.checked(),user['id'],ident(request['requestId'])]);fingerprint=digest(request)
                with self.worker_lock:
                    if key in self.workers:
                        worker=self.workers[key]
                        if worker['inputDigest']!=fingerprint:fail('MEDIA_REQUEST_CONFLICT','此配音预览编号对应其他文字或声音，请核对原预览')
                        after=self._current(before,data,token,fresh);after['result']={'speechJob':{'requestId':request['requestId'],'state':worker['state']},'newGenerationDispatched':False};return after
                    if len(self.workers)>=32:fail('MEDIA_CAPACITY','本轮配音记录较多，请重新打开后继续')
                    if sum(v['state']=='running' for v in self.workers.values())>=2:fail('MEDIA_BUSY','电脑已有配音在处理，请稍后再试')
                    worker={'cancel':threading.Event(),'state':'running','inputDigest':fingerprint};self.workers[key]=worker
                self.native.storage_limit(MAX_WAV)
                thread=threading.Thread(target=self._render_speech,args=(worker,deepcopy(request),scope,user,binding,before,deepcopy(data),token,fresh),daemon=True);worker['thread']=thread;thread.start()
                result={'speechJob':{'requestId':request['requestId'],'state':'running'},'newGenerationDispatched':True}
            elif action=='media_speech_save':
                exact(request,base|{'previewId','previewDigest','expectedRevision','requestId','name','rightsConfirmed','rightsNote'})
                ident(request['requestId']);ident(request['previewId']);name=_text(request['name'],80);note=_text(request['rightsNote'],300)
                if request['rightsConfirmed'] is not True or not name.endswith('.wav') or any(c in name for c in '/\\:'):fail('MEDIA_RIGHTS_REQUIRED','请核对配音原文与声音，并确认有权使用后保存WAV')
                fresh()
                with service.store.connect() as db:
                    db.execute('BEGIN IMMEDIATE');actor,row=service._authority(db,user,scope,authority,True)
                    old=service._receipt(db,actor,scope,request['requestId'],'import',request)
                    if old:result={'asset':service._asset_view(service._record(db,ASSETS,old['targetId'],scope,actor)),'replayed':True}
                    else:
                        value=self.previews.get(request['previewId'])
                        if not value or value['scope']!=scope.checked() or value['actorId']!=actor['id'] or value['binding']!=binding or value['public']['previewDigest']!=request['previewDigest']:fail('MEDIA_SOURCE_CHANGED','原配音预览已失效或归属变化，请重新读取；本次未保存')
                        if type(request['expectedRevision']) is not int or request['expectedRevision']!=row['revision'] or request['expectedRevision']!=value['public']['expectedRevision']:fail('MEDIA_VERSION_CONFLICT','账号内容版本已变化，配音未保存')
                        count=sum(1 for raw in db.execute('SELECT body FROM records WHERE entity=? AND tenant_id=?',(ASSETS,scope.tenant_id)) if json.loads(raw['body']).get('scope')==scope.checked())
                        if count>=64:fail('MEDIA_CAPACITY','当前账号素材已到64份，请先整理')
                        self.native.storage_limit(len(value['raw']));aid=uuid.uuid4().hex;folder=self.root/'assets';folder.mkdir(exist_ok=True)
                        with (folder/aid).open('xb') as stream:stream.write(value['raw'])
                        asset={'id':aid,'tenant_id':scope.tenant_id,'scope':scope.checked(),'owner':actor['username'],'actorId':actor['id'],'workspaceId':row['id'],'name':name,'kind':'audio','sha256':value['public']['sha256'],'bytes':len(value['raw']),'source':'generated_concept','rightsNote':note,'rightsConfirmed':True,'probe':value['public']['probe'],'createdAt':now(),'speech':{k:value['public'][k] for k in ('text','voiceId','voiceName','voiceLanguage','voiceVersion','systemVersion','rate','previewDigest')}}
                        service._put(db,ASSETS,asset);service._receipt(db,actor,scope,request['requestId'],'import',request,aid);service._commit(db);result={'asset':service._asset_view(asset),'replayed':False}
            elif action=='media_speech_read':
                if set(request)==base|{'requestId'}:
                    key=digest([scope.checked(),user['id'],ident(request['requestId'])])
                    with self.worker_lock:
                        worker=self.workers.get(key);result={'speechJob':{'requestId':request['requestId'],'state':worker['state'] if worker else 'not_found'},'newGenerationDispatched':False}
                        if worker and worker['state'] in ('failed','cancelled'):result['speechJob'].update(code=worker.get('code'),message=worker.get('message'))
                    if worker and worker['state']=='succeeded':
                        value=self.previews.get(worker['previewId'])
                        if not value or value['scope']!=scope.checked() or value['actorId']!=user['id'] or value['binding']!=binding:fail('MEDIA_SOURCE_CHANGED','原配音预览已失效，请核对原任务')
                        result['speechPreview']={**value['public'],'dataBase64':base64.b64encode(value['raw']).decode('ascii')}
                    after=self._current(before,data,token,fresh);after['result']=result;return after
                exact(request,base|{'assetId'})
                with service.store.connect() as db:
                    actor,_=service._authority(db,user,scope,authority,False);asset=service._record(db,ASSETS,request['assetId'],scope,actor)
                    if asset['kind']!='audio':fail('MEDIA_INPUT_INVALID','请选择本账号配音素材')
                raw=checked_file(service._asset_path(asset),self.root,MAX_WAV)
                if hashlib.sha256(raw).hexdigest()!=asset['sha256']:fail('MEDIA_INPUT_CHANGED','配音文件已变化，未返回内容')
                result={'asset':service._asset_view(asset),'speech':deepcopy(asset['speech']),'mime':'audio/wav','dataBase64':base64.b64encode(raw).decode('ascii')}
            else:fail('MEDIA_ACTION_FORBIDDEN','媒体服务操作未开放')
            try:after=self._current(before,data,token,fresh)
            except Exception:
                if action=='media_speech_save':raise MediaError('MEDIA_RESULT_UNCONFIRMED','配音保存结果需按原编号核对，未重新保存',mutation_committed=None) from None
                raise
            # Media assets use their existing durable receipt, not the content
            # workspace revision. OCR/voice previews never save a workspace.
            after['result']=result;return after
