// Fixed, authenticated DM transport. No expression, script, selector or history input.
'use strict';
const {randomUUID}=require('crypto');
const CONTRACT='fangyu-dm-typed-v1';
const SOURCE='b0847e7a4cb2804317d1001786baa0b0fa9cc8ad333457e065bb37266f64db8b';
const uid=v=>typeof v==='string'&&/^[1-9]\d{0,19}$/.test(v)&&BigInt(v)<=18446744073709551615n;
const key=v=>typeof v==='string'&&/^[A-Za-z0-9_-]{8,160}$/.test(v);
function validate(body){
 if(!body||typeof body!=='object'||Array.isArray(body))throw Error('Fixed DM fields required');
 const {operation,connId,expectedUid,requestId}=body;
 const allowed=['operation','connId','expectedUid','requestId',...(operation==='listen'?['timeoutMs']:operation==='send'?['recipient','text']:[])];
 if(!['listen','stop','send'].includes(operation)||Object.keys(body).some(k=>!allowed.includes(k))||allowed.some(k=>!Object.hasOwn(body,k)))throw Error('Fixed DM command required');
 if(typeof connId!=='string'||!/^[A-Za-z0-9_-]{1,160}$/.test(connId)||!uid(expectedUid)||!key(requestId))throw Error('Exact DM identity required');
 if(operation==='listen'&&(!Number.isInteger(body.timeoutMs)||body.timeoutMs<100||body.timeoutMs>20000))throw Error('Bounded DM listen required');
 if(operation==='send'&&(!uid(body.recipient)||body.recipient===expectedUid||typeof body.text!=='string'||!body.text.trim()||body.text.length>1000))throw Error('Exact DM recipient/text required');
 return {...body};
}
class DMRouter{
 constructor(router){this.router=router;this.requests=new Map();}
 authorized(req,res){
  const r=this.router;
  if(!r.token||req.headers.authorization!=='Bearer '+r.token){r._sendJson(res,403,{ok:false,error:'Explicit local Bridge token required for DM'});return false;}
  return true;
 }
 async call(req,res){
  const r=this.router;if(!this.authorized(req,res))return;
  const body=await r._parseBody(req,res);if(body===null)return;
  let command;try{command=validate(body);}catch(e){return r._sendJson(res,400,{ok:false,error:e.message});}
  const conn=r.registry.dmConnection(command.connId,SOURCE);
  if(!conn)return r._sendJson(res,409,{ok:false,error:'Exact reviewed HTTP-polling DM connection unavailable; no fallback'});
  const idKey=JSON.stringify([command.connId,command.expectedUid,command.operation,command.requestId]);
  const input=JSON.stringify(command);let item=this.requests.get(idKey);
  if(item){if(item.input!==input)return r._sendJson(res,409,{ok:false,error:'Original DM request input changed'});return r._sendJson(res,200,await item.promise);}
  // This is a bounded transport receipt cache, never a second business queue.
  // Do not evict an uncertain receipt and thereby permit its redispatch.
  if(this.requests.size>=2048)return r._sendJson(res,429,{ok:false,error:'DM receipt capacity reached; reconcile original requests'});
  const id=randomUUID();item={input};this.requests.set(idKey,item);
  item.promise=new Promise(resolve=>{
   const settle=(value,error)=>{
    const pending=r._pending.get(id);if(!pending)return;
    clearTimeout(pending.timer);r._pending.delete(id);
    const q=r._pollQueue.get(conn.id);if(q){const rest=q.filter(c=>c.msgId!==id);if(rest.length)r._pollQueue.set(conn.id,rest);else r._pollQueue.delete(conn.id);}
    resolve(error?{ok:false,error:'DM result unconfirmed; preserve original request',connection:conn.id}:{ok:true,value,connection:conn.id});
   };
   const timer=setTimeout(()=>settle(null,true),30000);
   r._pending.set(id,{timer,dmConnId:conn.id,resolve:value=>settle(value,false),reject:()=>settle(null,true)});
   const payload={ok:true,type:'fangyu-dm',id,contract:CONTRACT,sourceDigest:SOURCE,command};
   const waiters=r._pollWaiters.get(conn.id);
   if(waiters?.length){const waiter=waiters.shift();if(!waiters.length)r._pollWaiters.delete(conn.id);clearTimeout(waiter.timer);r._sendJson(waiter.res,200,payload);}
   else{if(!r._pollQueue.has(conn.id))r._pollQueue.set(conn.id,[]);r._pollQueue.get(conn.id).push({msgId:id,dm:payload});}
  });
  return r._sendJson(res,200,await item.promise);
 }
 async result(req,res){
  const r=this.router;if(!this.authorized(req,res))return;
  const body=await r._parseBody(req,res);if(body===null)return;
  if(!body||typeof body!=='object'||Array.isArray(body)||Object.keys(body).some(k=>!['id','connId','value','error'].includes(k))||typeof body.id!=='string'||typeof body.connId!=='string')return r._sendJson(res,400,{ok:false,error:'Fixed DM result required'});
  const pending=r._pending.get(body.id);
  if(!pending?.dmConnId||pending.dmConnId!==body.connId||!r.registry.dmConnection(body.connId,SOURCE))return r._sendJson(res,409,{ok:false,error:'DM result connection differs'});
  // Wrong-shape browser data is not promoted into a delivery receipt.
  const command=body.value;
  if(body.error||!command||command.contract!=='fangyu-dm-bounded-v1')pending.reject();else pending.resolve(command);
  return r._sendJson(res,200,{ok:true});
 }
}
module.exports={DMRouter,validate,CONTRACT,SOURCE};
