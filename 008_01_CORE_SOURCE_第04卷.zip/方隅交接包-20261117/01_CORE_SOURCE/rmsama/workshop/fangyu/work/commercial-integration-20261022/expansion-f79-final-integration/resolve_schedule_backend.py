from pathlib import Path
import difflib,hashlib,json
C=Path(__file__).resolve().parent;P=C.parents[2];rel='work/ui-approved-implementation/ui-preview/backend.mjs';F=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v79/project'
base=(F/rel).read_bytes();incoming=(C.parent/'content-schedule-f79-candidate/overlay'/rel).read_bytes();current=(C/'project'/rel).read_bytes();sha=lambda raw:hashlib.sha256(raw).hexdigest()
ops=[op for op in difflib.SequenceMatcher(None,base,incoming,autojunk=False).get_opcodes() if op[0]!='equal'];assert len(ops)==1,ops
tag,start,end,other_start,other_end=ops[0];assert tag=='insert' and start==end;addition=incoming[other_start:other_end]
assert addition==b"schedule_plan','content_schedule_read','content_schedule_arm','content_schedule_control','content_schedule_tick','content_schedule_reconcile','content_"
anchor=base[start-100:end+100];replacement=base[start-100:start]+addition+base[end:end+100];assert current.count(anchor)==1
result=current.replace(anchor,replacement);assert result.replace(addition,b'',1)==current
out=C/'resolutions/schedule'/rel;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(result)
(C/'SCHEDULE-BACKEND-RESOLUTION.json').write_text(json.dumps({'status':'EXACT_SIX_ACTION_INSERTION_ONLY_IN_EXISTING_CONTENT_ACTION_ALLOWLIST','sourceBeforeSha256':sha(base),'sourceAfterSha256':sha(incoming),'compositionBeforeSha256':sha(current),'compositionAfterSha256':sha(result),'allDmAndF79OtherBytesPreserved':True,'insertedBytes':len(addition)},indent=2),'utf-8');print('Resolved exact schedule whitelist insertion without replacing DM/account actions')
