from pathlib import Path
W=Path(__file__).resolve().parent;OLD=W.parent/'dm-f79-candidate'
t=(OLD/'test_factory_dm.py').read_text('utf-8')
t=t.replace('import hashlib,http.client,importlib.util,json,os,re,shlex,sys,threading,time,uuid','import hashlib,http.client,importlib.util,json,os,re,shlex,sys,threading,time,uuid,subprocess')
t=t.replace("  assert Path(argv[1]).resolve()==S/'work/ui-runtime-r55/work/runtime/douyin-bridge/dm_workbench_cli.js',argv","  assert Path(argv[1]).resolve() in (S/'work/ui-runtime-r55/work/runtime/douyin-bridge/dm_workbench_cli.js',W/'bridge_fixture.cjs'),argv")
a=t.index('class Bridge(BaseHTTPRequestHandler):');b=t.index('server=host.StaticServer',a)
t=t[:a]+'''class Bridge(BaseHTTPRequestHandler):
 def log_message(self,*a):pass
 def do_POST(self):
  data=json.loads(self.rfile.read(int(self.headers['Content-Length'])));assert self.path=='/admit'
  account=next(a for a in accounts.values() if a['conn_id']==data['connId']);operation=data['operation']
  assert data['expectedUid']==account['platform_uid']
  mode=core.account_mode_status(account['id'],user['tenant_id']);assert mode['status']=='active' and mode['mode']==('replies' if operation=='send' else 'collection'),mode
  foreign=type(core.continuous.leases)(core.store,'foreign-dm-review')
  try:foreign.acquire(account['id'],user['tenant_id'],'publishing','foreign-publication')
  except ValueError:pass
  else:raise AssertionError('Original atomic mode lease bypassed')
  args=[data['expectedUid'],data['recipient'],data['text'],data['requestId']] if operation=='send' else [data['expectedUid'],data['requestId'],data['timeoutMs']] if operation=='listen' else [data['requestId']]
  wire.append({'operation':operation,'args':args,'connection':data['connId'],'mode':mode,'foreignModeBlocked':True,'realTypedRouter':True})
  if operation=='stop':stop_received.set()
  if late_revoke[0] and operation=='listen':reply_permission[0]=False
  raw=json.dumps({'unknown':send_state[0]=='unknown','corrupt':listen_corrupt[0]}).encode()
  self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
bridge=ThreadingHTTPServer(('127.0.0.1',0),Bridge);bt=threading.Thread(target=bridge.serve_forever,daemon=True);bt.start()
bridge_process=subprocess.Popen([str(S/'work/ui-runtime-r55/work/runtime/douyin-bridge/node.exe'),str(W/'bridge_fixture.cjs'),str(bridge.server_port),str(OUT)],cwd=OUT,stdout=(OUT/'BRIDGE-STDOUT.txt').open('wb'),stderr=(OUT/'BRIDGE-STDERR.txt').open('wb'))
for _ in range(300):
 if (OUT/'BRIDGE-READY.json').exists():break
 assert bridge_process.poll() is None,'Fixture bridge exited'
 time.sleep(.02)
bridge_config=json.loads((OUT/'BRIDGE-READY.json').read_text('utf-8'))
def bridge_control(path,data={}):
 c=http.client.HTTPConnection('127.0.0.1',bridge_config['port'],timeout=10);c.request('POST','/fixture/'+path,json.dumps(data).encode(),{'Authorization':'Bearer '+bridge_config['token'],'Content-Type':'application/json'});r=c.getresponse();raw=r.read();c.close();assert r.status==200,(r.status,raw);return json.loads(raw)
def browser_conn(uid):return bridge_control('create',{'uid':uid})['connId']
''' +t[b:]
t=t.replace("accounts[a['id']]=a;core.store.put('accounts',a)","a['conn_id']=browser_conn(a['platform_uid']);accounts[a['id']]=a;core.store.put('accounts',a)")
t=t.replace("'port':bridge.server_port,'token':'synthetic-only'","'port':bridge_config['port'],'token':bridge_config['token']")
t=t.replace("accounts[third['id']]=third;core.store.put('accounts',third)","third['conn_id']=browser_conn(third['platform_uid']);accounts[third['id']]=third;core.store.put('accounts',third)")
# Capture the actual typed transport before its own service is stopped. The
# original HTTP assertions, permission checks, original request and Store
# persistence checks below remain unchanged.
t=t.replace(" bridge.shutdown();", " bridge_control('shutdown');bridge_process.wait(timeout=10);bridge.shutdown();")
# Original source uses a combined cleanup line; require the inserted shutdown.
if "bridge_process.wait(timeout=10)" not in t:
 t=t.replace('bridge.shutdown();',"bridge_control('shutdown');bridge_process.wait(timeout=10);bridge.shutdown();")
assert "bridge_process.wait(timeout=10)" in t
anchor=" runtime.service._cloud=lambda:DeviceCloud();executor.account_claim=runtime.service._claim_xhs_account;bind_executor_session(runtime.service,executor,saved)"
assert t.count(anchor)==1
t=t.replace(anchor,anchor+"\n from assistant.douyin_connection_service import _components\n component_revision=_components(runtime.server);assert len(component_revision)==64\n checks.append('Original active account connection _components accepts exact new reviewed Bridge material with original purpose and held grant unchanged')")
anchor=" assert core.store.get('ui_dm_drafts_v1',d1['id'])==old_unknown\n assert all(v['foreignModeBlocked']"
assert t.count(anchor)==1
t=t.replace(anchor,""" assert core.store.get('ui_dm_drafts_v1',d1['id'])==old_unknown
 before_reopen=len(wire);processes_before_reopen=len(processes)
 server.shutdown();st.join(3);server.server_close();backend.close()
 backend=host.create_backend(R,files,project_root=S,data_dir=OUT/'data',company=company);runtime=backend.platform_runtime;core=backend.core
 server=host.StaticServer(R,files,backend=backend,cookie_name='dm_fixture_session');st=threading.Thread(target=server.serve_forever,daemon=True);st.start();origin='http://127.0.0.1:'+str(server.server_port);headers={}
 _,boot,_=request('GET','/api/workbench/bootstrap');headers.update({'Content-Type':'application/json','Origin':origin,'X-Fangyu-CSRF':boot['csrfToken']})
 _,logged,h=request('POST','/api/workbench',{'action':'login','data':{'username':'fixture-admin','password':fixture.PASSWORD}});headers['Cookie']=h['Set-Cookie'].split(';',1)[0];headers['X-Fangyu-CSRF']=logged['csrfToken']
 if logged['selection']['storeId']!=store:action('select_store',{'storeId':store,'expectedRevision':logged['selection']['revision']})
 recovered=dm('dm_request_read',{'action':'dm_queue_start','requestId':key});assert recovered['state']=='unknown' and len(wire)==before_reopen
 assert start(q,key)['state']=='unknown' and len(wire)==before_reopen and len(processes)==processes_before_reopen
 assert core.store.get('ui_dm_drafts_v1',d1['id'])==old_unknown
 checks.append('Fresh original create_backend reopened same own Store; unknown original request read and same-key start remain unknown with zero new CLI or transport')
 assert all(v['foreignModeBlocked']""")
anchor=" send_state[0]='unknown';d1=draft(account,convs[1]"
assert t.count(anchor)==1
t=t.replace(anchor,""" # Concurrent original DM workers for the same platform UID, two accounts.
 mutate('dm_listen_start',{'accountId':other['id'],'confirmed':True,'timeoutMs':100})
 for _ in range(200):
  other_view=read(other)
  if other_view['listeners'][-1]['state']!='listening':break
  time.sleep(.02)
 other_sent=next(c for c in other_view['conversations']['items'] if c['recipientUid']==convs[0]['recipientUid'])
 already=prepare(other,[draft(other,other_sent,'同UID已由另账号成功，不应重发')]);before=len(wire);start(already)
 assert wait_queue(already['id'])['state']=='blocked' and len(wire)==before
 checks.append('Another account same stable UID after successful DM is blocked with zero typed dispatch, independent of conversation/message IDs')
 same_peer=next(c for c in other_view['conversations']['items'] if c['recipientUid']==convs[2]['recipientUid'])
 cq1=prepare(account,[draft(account,convs[2],'同一客户两账号竞争第一条')]);cq2=prepare(other,[draft(other,same_peer,'同一客户两账号竞争第二条')])
 bridge_control('options',{'uid':account['platform_uid'],'options':{'delaySendMs':600}});before=len(wire);start(cq1)
 for _ in range(200):
  if len(wire)>before:break
  time.sleep(.01)
 start(cq2);assert wait_queue(cq2['id'])['state']=='blocked'
 assert wait_queue(cq1['id'])['state']=='completed' and len(wire)==before+1
 bridge_control('options',{'uid':account['platform_uid'],'options':{'delaySendMs':0}})
 checks.append('Two account HTTP queues overlap while first synthetic IM send waits; original atomic stable-customer claim admits exactly one typed command')
 # Seed a pre-existing successful COMMENT record, not a pretend new send.
 history_lead={'id':'dm-existing-success-comment-lead','tenant_id':user['tenant_id'],'cloud_owner':user['username'],'store_id':store,'task_id':task['id'],'platform':'douyin','author_id':convs[3]['recipientUid'],'text':'合成既有评论来源'}
 history_reply={'id':'dm-existing-success-comment-reply','tenant_id':user['tenant_id'],'lead_id':history_lead['id'],'account_id':account['id'],'status':'sent','text':'合成既有成功评论回执'}
 core.store.put('leads',history_lead);core.store.put('replies',history_reply)
 comment_peer=next(c for c in other_view['conversations']['items'] if c['recipientUid']==history_lead['author_id'])
 old_comment=prepare(other,[draft(other,comment_peer,'先前评论成功，不应跨渠道重发')]);before=len(wire);start(old_comment)
 assert wait_queue(old_comment['id'])['state']=='blocked' and len(wire)==before
 assert core.store.get('leads',history_lead['id'])==history_lead and core.store.get('replies',history_reply['id'])==history_reply
 checks.append('Pre-existing synthetic sent COMMENT with same platform UID blocks batch DM across accounts; original lead/reply records remain unchanged')
 send_state[0]='unknown';d1=draft(account,convs[1]""")
(W/'test_factory_dm.py').write_text(t,'utf-8')
print('Prepared original factory assertions with real typed Bridge/userscript fixture, synthetic IM only')
