"""Root acceptance: fixed evidence and exact compiled shell/payload, no execution."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import marshal
import types
from PyInstaller.archive.readers import CArchiveReader

P = Path('C:/积木软件工坊/项目/方隅公寓客户版')
W = P / 'work/commercial-integration-20261022'
D = W / 'delivery-v73'
R = W / 'final-installer-upgrade-audit/runtime-message-candidate'
I = W / 'installer-successor-independent-review/FINAL-RECEIPT.json'

def require(ok, reason):
    if not ok:
        raise RuntimeError(reason)

def sha(path):
    with path.open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()

def normalized(code):
    if not isinstance(code, types.CodeType):
        return tuple(normalized(v) for v in code) if isinstance(code, tuple) else code
    return (code.co_argcount, code.co_posonlyargcount, code.co_kwonlyargcount,
            code.co_nlocals, code.co_stacksize, code.co_flags, code.co_code,
            tuple(normalized(v) for v in code.co_consts), code.co_names,
            code.co_varnames, code.co_freevars, code.co_cellvars,
            getattr(code, 'co_exceptiontable', b''))

pins = {
    I: '3842ce722300543b9896e4e40e4f47c6bd3a6ea03f3e909f6e1a9b12157344ca',
    R / 'installer.runtime-message-shortcut.py': '5f9b4d7ab00b6348d07d15a241ad804cf593ec137d576e5a3ce67476df01dca9',
    R / 'FangyuWorkbenchSetup-standard-held-clean-v73-protected-upgrade.exe': '38d3fcc329f44a38045cc1e9865d2a5312464c58fa918a3555e5a7c110ad4eb8',
    R / 'SFX-BUILD-RECEIPT.json': '62053fd8818643b7d70cd7bbef3ae5d9bab9d66bdf5dc5f164c4405c71a78dc9',
    W / 'final-installer-upgrade-audit/FINAL-RECEIPT.json': '1a353acaa7c179e228a6b50b5c0de905a168d8c9bb161d641449735ced5aeca2',
    P / 'work/ui-native-r57/run_workbench.py': '64f6129e337016f1eb87a7200563fd9cf390b4615d54118b95f9e9d66d48d102',
    P / 'work/ui-native-r57/FROZEN.json': '8d2f1967a1c7cb9230c5db73c3940e36db113d77308743060fa29b1825cb414a',
}
for path, expected in pins.items():
    require(path.is_file() and sha(path) == expected, 'Acceptance pin changed: ' + path.name)
independent = json.loads(I.read_text('utf-8'))
require(independent['blockingFindings'] == [], 'Independent installer blocker')
source = R / 'installer.runtime-message-shortcut.py'
sfx = R / 'FangyuWorkbenchSetup-standard-held-clean-v73-protected-upgrade.exe'
build = json.loads((R / 'SFX-BUILD-RECEIPT.json').read_text('utf-8'))
with sfx.open('rb') as stream:
    stream.seek(-269904095, 2)
    embedded = hashlib.file_digest(stream, 'sha256').hexdigest()
require(embedded == '5147dfdf36818760f0d311d73930f69c48744b22ff59c304a26635ea052579cb', 'Embedded ZIP changed')
archive = CArchiveReader(str(sfx))
expected_code = [normalized(compile(source.read_bytes(), str(source), 'exec', optimize=o)) for o in (0, 1, 2)]
matches = []
for name, row in archive.toc.items():
    if row[-1] != 's':
        continue
    code = marshal.loads(archive.extract(name))
    if normalized(code) in expected_code:
        matches.append(name)
require(matches == ['installer.runtime-message-shortcut'], 'Compiled installer/source mismatch')
require(build['releaseApproved'] is False and build['publicSendHold'] is True, 'Held policy changed')
result = {
    'status': 'ROOT_ACCEPTED_INDEPENDENTLY_REVIEWED_HELD_INSTALLER_FOR_OUTPUT_COPY',
    'atUtc': datetime.now(timezone.utc).isoformat(),
    'approvedHeldSfxSha256': pins[sfx], 'installerBytes': sfx.stat().st_size,
    'independentFinalReceiptSha256': pins[I],
    'rootCompiledSourceRecheck': matches, 'rootEmbeddedZipSha256': embedded,
    'sourcePatchReadAndAccepted': True,
    'fixedEvidence': {str(path): value for path, value in pins.items()},
    'commercialOrPlatformApproval': False, 'appExecuted': False,
    'liveCanonicalModified': False, 'realDesktopOrMenuTouched': False,
}
target = D / 'ROOT-INSTALLER-DELIVERY-APPROVAL.json'
require(not target.exists(), 'Preserve root acceptance receipt')
target.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'status': result['status'], 'receiptSha256': sha(target)}, ensure_ascii=False))
