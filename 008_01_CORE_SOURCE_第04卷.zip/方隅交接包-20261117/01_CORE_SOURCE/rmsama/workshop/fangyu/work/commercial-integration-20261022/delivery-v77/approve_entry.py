from pathlib import Path
import ast, hashlib, json

D = Path(__file__).resolve().parent
sha = lambda raw: hashlib.sha256(raw).hexdigest()
review = D.parent / 'v77-canonical-entry-independent-review/FINAL-RECEIPT.json'
assert sha(review.read_bytes()) == '9a4e8db4cfb9b135872bc9524cc023c745769d77a2a7cd4bc762a34a77a2657c'
receipt = json.loads(review.read_text('utf-8'))
assert receipt['actualOriginalReadOnlyCheckPassed'] is True
assert receipt['allOriginalFunctionsAndCasBackupRollbackUnchanged'] is True
entry = D / 'install_verified_entry.py'
raw = entry.read_bytes()
assert sha(raw) == receipt['reviewedEntrySha256'] == 'c726c55f799d92194f6727005bf2dff30a352532c2b15c2e7252d8ca4659d36a'
needle = b'INSTALLATION_REVIEWED = False'
assert raw.count(needle) == 1
new = raw.replace(needle, b'INSTALLATION_REVIEWED = True')
assert sha(new) == receipt['expectedSingleBoolTrueSha256IfExactBytesReplacement']
oldtree, newtree = ast.parse(raw.decode()), ast.parse(new.decode())
assert len(oldtree.body) == len(newtree.body)
changes = [a for a, b in zip(oldtree.body, newtree.body)
           if ast.dump(a, include_attributes=False) != ast.dump(b, include_attributes=False)]
assert len(changes) == 1 and isinstance(changes[0], ast.Assign)
assert changes[0].targets[0].id == 'INSTALLATION_REVIEWED'
backup = D / 'ENTRY-BEFORE-ROOT-APPROVAL.py'
assert not backup.exists()
backup.write_bytes(raw)
entry.write_bytes(new)
out = {'status': 'ROOT_APPROVED_REVIEWED_TECHNICAL_NEXT_LAUNCH_INSTALL',
       'reviewSha256': sha(review.read_bytes()), 'beforeSha256': sha(raw),
       'afterSha256': sha(new), 'onlyReviewedBooleanChanged': True,
       'commercialGoalComplete': False, 'actualNativeFirstStartVerified': False,
       'canonicalWrittenByThisScript': False}
(D / 'ROOT-ENTRY-APPROVAL.json').write_text(json.dumps(out, indent=2), encoding='utf-8')
print(json.dumps(out))
