# 合版接点与必须重算的材料

本目录只提供六个 Python 源差量，以及针对自有固定载荷生成的客户搜索材料例子。根组合器必须针对最终实际物理字节重新生成材料；不得复制本次例子后宣称最终闭包通过。

1. 基线为已封 customer-read-purpose-after-f82 的十一源及原固定 F82。仅六源清单见 SOURCE-FILES.json，canonical `assistant/business.py`、原导入/过滤/去重/AI/pipeline 函数不变。
2. 本任务修改共享 authority 的严格用途集合及 search 分支。须和另一作者三个 XHS natural 用途按明确名称集合合并，不能接受任意用途，也不能保留固定容量 3。
3. 新 `assistant/customer_read_lease.py`、原 Runner/Service/employee_workspace/Runtime、connection 和 comments 的七个接点由另一作者提供。本任务只是精确依赖其固定 QA 快照；它们不属于这六源差量，正式采用必须使用其最终 sealed 源。
4. 先合并六源、另一作者 Runtime/lease/XHS 与根 cloud 新只读合同；保持原 defaults、company/tenant/device/account/store/UID/lifecycle、public_send_hold、DM/live 合同与所有发送限制。
5. ordinary customer 描述只显式使用真实新版本 1.2.0-read.1。不得添加 portable_employee_release、QA 账号、固定开发设备，不能把旧 source-admin 标记删掉来凑通。源码入口继续原 internal 目的，不消费 frozen carrier。
6. 对真正运行根按原 reviewed purpose 分别重算 canonical connection/comments/search review、active vendor connection/service 及其 consumers/SOURCE 映射；只改相应材料 hash/bytes，不改原 purpose、limits、public_send_grant 或 evidence 权限值。旧 internal review 是独立合同，不能以客户材料替换。
7. 再按实际最终根生成 customer 三个 Dy purpose 材料：connection、video comments、keyword search。搜索固定为首屏 offset 0、最多 20、原 UID 前后核对、无回复/私信/发送。搜索 review 必须绑定 `douyin_customer_tasks.py`、Core/Adapters/原 Store/pipeline/continuous、实际 vendor Business、原 helper、CLI/Router/Registry/Client/完整 userscript 与 MIT 通知。
8. 合并 XHS 独立原 schema 材料后生成正式 review-index；company_binding 绑定真实 company，验证不接受 HTTP 选择 review/scope、错公司、软链接/reparse、材料变化、撤权生命周期。scope 成功不等于设备或账号授权。
9. 最后重算 backend-dependencies 完整 Python 列表、held code manifest 与 guard 的原假决定、RELEASE、SHIPPED、编译入口与外层 EXE 包清单。主 EXE 不放入内部材料索引，避免自指循环。

当前 source-joint1 是 source/sys.frozen 代表，并非主工作台实际编译。自有完整 userscript VM 只证明原链路接点，不能当作本人自然登录、真实平台读取、真实采集速度、Native WebView 或第二台电脑验收。
