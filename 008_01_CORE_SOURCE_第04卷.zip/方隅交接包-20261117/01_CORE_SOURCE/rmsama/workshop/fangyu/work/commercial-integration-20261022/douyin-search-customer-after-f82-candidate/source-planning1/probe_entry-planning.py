"""Relocatable standard Windows entry over the unchanged fixed r57 host.

This independently installed application initializes only its own empty data
directory. It grants no enterprise/device/platform permissions. Existing local
production binding and sessions are never consulted or copied.
"""
from pathlib import Path, PurePosixPath
import argparse, hashlib, http.client, importlib.util, importlib.machinery, json, os, socket, stat, sys
import threading
import time, uuid
sys.dont_write_bytecode = True
RELEASE_ID = 'ui-r57-20261023T095243Z-1c9a271f'
RELEASE_SHA = '3fe896214dd73876327ecac5b07fb19b1e6855dd8e272719d622c5a76c0efef1'
CLOSURE_SHA = '6b0f5c2818e19590542ee38baa6bd0c061824025c1dd2082d08ce716b02a5743'

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def exact(path, expected):
    for item in (path, *path.parents):
        info = item.lstat()
        if item.is_symlink() or getattr(info, 'st_file_attributes', 0) & 1024:
            raise RuntimeError('程序路径不能包含链接或重定向')
    before = path.stat()
    if not stat.S_ISREG(before.st_mode) or before.st_nlink != 1:
        raise RuntimeError('程序文件类型无效')
    raw = path.read_bytes()
    after = path.stat()
    if (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) != (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns) or sha(raw) != expected:
        raise RuntimeError('程序文件校验失败')
    return raw

def output(value, path=None):
    raw = json.dumps(value, ensure_ascii=False, indent=2) + '\n'
    if path:
        with Path(path).open('x', encoding='utf-8') as stream:
            stream.write(raw)
    elif sys.stdout is not None:
        print(raw)

def load_host(root):
    project = root / 'project'
    closure = json.loads(exact(project / 'SHIPPED-PINS.json', CLOSURE_SHA))
    names = set()
    for row in closure['files']:
        relative = PurePosixPath(row['path'])
        if relative.is_absolute() or '..' in relative.parts or ':' in str(relative) or ('\\' in str(relative)) or (str(relative) in names):
            raise RuntimeError('程序清单路径无效')
        names.add(str(relative))
        raw = exact(project / relative, row['sha256'])
        if len(raw) != row['bytes']:
            raise RuntimeError('程序文件长度不匹配')
    actual = set()
    for path in project.rglob('*'):
        info = path.lstat()
        if path.is_symlink() or getattr(info, 'st_file_attributes', 0) & 1024:
            raise RuntimeError('程序目录包含未允许的链接或重定向')
        if '__pycache__' in path.relative_to(project).parts or path.suffix.lower() in ('.pyc', '.pyo'):
            raise RuntimeError('程序目录包含未允许的 Python 缓存代码')
        if path.is_file():
            actual.add(path.relative_to(project).as_posix())
    if actual != names | {'SHIPPED-PINS.json'}:
        raise RuntimeError('程序实际文件集合与完整清单不一致')
    code_pins = {row['path']: row for row in closure['files']}
    original_get_code = importlib.machinery.SourceFileLoader.get_code

    def source_only(loader, fullname):
        path = Path(loader.path).absolute()
        if path.is_relative_to(project):
            relative = path.relative_to(project).as_posix()
            row = code_pins.get(relative)
            if row is None or path.suffix.lower() != '.py':
                raise ImportError('未允许的程序代码来源')
            raw = exact(path, row['sha256'])
            return compile(raw, str(path), 'exec', dont_inherit=True, optimize=0)
        return original_get_code(loader, fullname)
    importlib.machinery.SourceFileLoader.get_code = source_only

    def code_audit(event, args):
        if event == 'open' and isinstance(args[0], (str, bytes, os.PathLike)):
            path = Path(os.fsdecode(args[0])).absolute()
            if path.is_relative_to(project) and path.suffix.lower() in ('.pyc', '.pyo'):
                raise PermissionError('程序不接受缓存字节码')
        if event == 'import' and len(args) > 1 and isinstance(args[1], str):
            path = Path(args[1]).absolute()
            if path.is_relative_to(project) and path.suffix.lower() in ('.pyd', '.dll', '.pyc', '.pyo'):
                row = code_pins.get(path.relative_to(project).as_posix())
                if row is None or path.suffix.lower() in ('.pyc', '.pyo'):
                    raise ImportError('未允许的扩展程序来源')
                exact(path, row['sha256'])
    sys.addaudithook(code_audit)
    release = project / 'work/ui-native-r57/releases' / RELEASE_ID
    raw = exact(release / 'RELEASE.json', RELEASE_SHA)
    manifest = json.loads(raw)
    entry = next((row for row in manifest['files'] if row['path'] == 'ui_native_host.py'))
    module = importlib.util.module_from_spec(importlib.util.spec_from_loader('fangyu_standard_native_host', loader=None))
    module.__file__ = str(release / 'ui_native_host.py')
    sys.modules[module.__name__] = module
    exec(compile(exact(release / 'ui_native_host.py', entry['sha256'].lower()), module.__file__, 'exec'), module.__dict__)
    return (module, project, release, closure)

def short_native_icon(release, state):
    """Keep .NET's legacy Icon file constructor below its path length limit."""
    manifest = json.loads(exact(release / 'RELEASE.json', RELEASE_SHA))
    row = next((item for item in manifest['files'] if item['path'] == 'resources/brand.ico'), None)
    if row is None:
        return
    source = release / 'resources/brand.ico'
    raw = exact(source, row['sha256'].lower())
    target = state / 'window.ico'
    if target.exists():
        exact(target, sha(raw))
    else:
        with target.open('xb') as stream:
            stream.write(raw)
        exact(target, sha(raw))
    if len(str(target)) >= 248:
        raise RuntimeError('Windows 用户资料路径过长，请使用标准用户资料目录')
    import webview
    original = webview.start

    def start(*args, **kwargs):
        if kwargs.get('icon') == str(source):
            kwargs['icon'] = str(target)
        return original(*args, **kwargs)
    webview.start = start

def own_directories():
    local = os.environ.get('LOCALAPPDATA')
    if not local or not Path(local).is_absolute():
        raise RuntimeError('Windows 用户资料目录不可用')
    root = Path(local) / 'FangyuWorkbenchStandard'
    for folder in (root, root / 'data', root / 'state'):
        folder.mkdir(parents=True, exist_ok=True)
        for item in (folder, *folder.parents):
            if item.is_symlink() or getattr(item.lstat(), 'st_file_attributes', 0) & 1024:
                raise RuntimeError('工作资料目录不能重定向')
    return (root / 'data', root / 'state')

def main():
    root = Path(sys.executable).resolve().parent if getattr(sys, 'frozen', False) else Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description='方隅工作台')
    group = parser.add_mutually_exclusive_group()
    group.add_argument('--check', action='store_true')
    group.add_argument('--self-test', action='store_true')
    parser.add_argument('--result-file')
    args = parser.parse_args()
    host, project, release, closure = load_host(root)
    data, state = own_directories()
    if args.check or args.self_test:
        argv = ['--check'] if args.check else ['--self-test']
        code = host.main(release, RELEASE_SHA, state, argv, project_root=project, data_dir=data)
        if code:
            raise RuntimeError('启动检查未通过')
        output({'status': 'PASS', 'releaseId': RELEASE_ID, 'frozen': getattr(sys, 'frozen', False) is True, 'internalStandardCandidate': True, 'commercialDistributionApproved': False, 'action': argv[0], 'closureFilesVerified': len(closure['files'])}, args.result_file)
        return 0
    short_native_icon(release, state)
    return host.main(release, RELEASE_SHA, state, [], project_root=project, data_dir=data)

if hasattr(sys.stdout,'reconfigure'):sys.stdout.reconfigure(encoding='utf-8')
"""Own cloud responses only; no browser, platform, model or arbitrary process."""
import traceback
from copy import deepcopy
from types import SimpleNamespace
import uuid,subprocess,shlex

actual_compiled = getattr(sys, 'frozen', False) is True
if actual_compiled:
    W = Path(sys.executable).resolve().parent
else:
    W = Path(__file__).resolve().parent / 'payload'
    sys.frozen = True
    sys.executable = str(W / 'FangyuWorkbench.exe')
P = W/'project'
OUT = W/('factory-'+uuid.uuid4().hex); OUT.mkdir()
events, checks, processes, threads = [], [], [], []
backend = server = None
admission_checks=[]
tamper = [False]
save = lambda name,value:(OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2,default=str),'utf-8')
def audit(event,args):
    if event=='subprocess.Popen':
        argv=args[1];argv=[part.strip('"') for part in shlex.split(argv,posix=False)] if isinstance(argv,str) else argv
        br=P/'work/ui-runtime-r55/work/runtime/douyin-bridge'
        assert Path(argv[0]).resolve()==br/'node.exe',argv
        assert Path(argv[1]).resolve() in (br/'cli.js',W/'qa-fixtures/search_bridge_fixture.cjs'),argv
        assert Path(args[2]).resolve().is_relative_to(OUT) or (Path(argv[1]).resolve()==br/'cli.js' and argv[2]=='connections' and Path(args[2]).resolve()==br),args
        if Path(argv[1]).resolve()==br/'cli.js' and argv[2] in ('search','comment-page'):
            from core import adapters as adapter_module
            account_root=Path(args[2]).resolve()
            mode=core.account_mode_status(account_root.name,user['tenant_id'])
            assert mode['mode']=='collection' and mode['status']=='active' and mode['owner'].startswith('batch:')
            assert account_root in getattr(adapter_module._account_lock_owner,'paths',set())
            channel=core.adapters.channel_locks.get('douyin:'+str(account_root.parent));assert channel and channel.locked(),'Original shared Douyin Bridge channel not held'
            foreign=type(core.continuous.leases)(core.store,'foreign-search-synthetic-runtime')
            try:foreign.acquire(account_root.name,user['tenant_id'],'replies','foreign-reply')
            except ValueError:pass
            else:raise AssertionError('Original atomic collection lease bypassed')
            admission_checks.append({'command':argv[2],'originalBatchLease':True,'originalOsAndChannelLocks':True,'foreignReplyRejected':True})
        processes.append(list(argv))
    if event in ('os.system','os.startfile','os.posix_spawn'):
        raise RuntimeError('No platform/browser process')
    if event in ('socket.connect','socket.bind') and (not isinstance(args[1],tuple) or args[1][0] not in ('127.0.0.1','::1')):
        raise RuntimeError('Loopback only')
    if event=='socket.getaddrinfo' and args[0] not in ('127.0.0.1','::1','localhost',None):
        raise RuntimeError('No external DNS')
    if event=='sqlite3.connect' and not Path(args[0]).resolve().is_relative_to(OUT):
        raise RuntimeError('Own DB only')
    if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
        path=Path(os.fsdecode(args[0])).absolute();mode,flags=args[1] or '',args[2] or 0
        writing=any(c in str(mode) for c in 'wax+') or isinstance(flags,int) and flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC)
        if writing and not path.is_relative_to(OUT) and not (tamper[0] and path.is_relative_to(P)):
            raise RuntimeError('Own evidence/data or explicit own-copy tamper only')
sys.addaudithook(audit)

def load(name,path):
    module=importlib.util.module_from_spec(importlib.util.spec_from_loader(name,loader=None));module.__file__=str(path)
    sys.modules[name]=module;exec(compile(path.read_bytes(),str(path),'exec'),module.__dict__);return module

def denied(call, code=None):
    try:call()
    except Exception as error:
        if code is not None:assert str(error)==code,(str(error),code)
        return type(error).__name__+': '+str(error)
    raise AssertionError('Expected original guard rejection')

def binding_denied():
    return denied(lambda:connection._binding(runtime.service))

passed=False
try:
    host,project,release,closure=load_host(W)
    manifest,files=host.verify_release(release,RELEASE_SHA)
    host.verify_backend_dependencies(release,files,project)
    fixture=load('customer_read_own_cloud',W/'qa-fixtures/cloud_fixture.py')
    cloud=fixture.CloudStandin(json.loads((W/'qa-fixtures/compiled-fixture.json').read_bytes()))
    company=json.loads((project/'work/app/company.json').read_bytes())
    def transport(*args,**kwargs):
        value=cloud(*args,**kwargs);value['environment_id']=company['managedWorkspace']['environment_id'];return value
    integration=load('integrations',release/'resources/platform-runtime/vendor-src/integrations.py')
    integration.request_json=transport
    backend=host.create_backend(release,files,project_root=project,data_dir=OUT/'data',company=company)
    runtime=backend.platform_runtime;core=backend.core
    runtime.server._configure_bundled();runtime._platform_setup=True
    from assistant import douyin_connection_service as connection
    from core.douyin_comments_policy import DouyinCommentsPolicy
    from core.douyin_search_policy import DouyinSearchPolicy
    assert runtime.server._runtime_license_usage_scope()=='customer_distribution_read'
    assert runtime.server._runtime_license_usage_scope('internal_self_use_read') is None
    account_revision=connection._components(runtime.server)
    comment=DouyinCommentsPolicy(runtime.server).resolve()
    assert len(account_revision)==64 and comment and comment['purpose']=='douyin_owned_video_comments'
    search_review=DouyinSearchPolicy(runtime.server).resolve()
    assert search_review is None
    assert runtime.server._customer_distribution_purpose('douyin_owned_keyword_search_page') is None
    assert runtime.server._customer_read_authority.runtime_license_review(runtime.server,'xiaohongshu_guarded_read') is None
    assert runtime.server.company['runtime']['public_send_hold'] is True
    assert runtime.server.company['runtime']['release_approved'] is False
    assert runtime.server.company['runtime']['xiaohongshu_automation']=='hold'
    checks.append({'group':'original-host-and-factory-customer-purpose-resolve','accountRevision':account_revision,
        'comment':comment,'scope':'customer_distribution_read','searchMissingHelperMaterialClosed':True,'xhsPending':True,'originalHolds':True})
    assert binding_denied()
    checks.append({'group':'component-scope-is-not-cloud-device-account-grant','unboundOriginalBindingRejected':True})

    server=host.StaticServer(release,files,backend=backend,cookie_name='customer_read_fixture_session')
    thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start();threads.append(thread)
    origin='http://127.0.0.1:'+str(server.server_port);headers={}
    def request(method,path,payload=None):
        c=http.client.HTTPConnection('127.0.0.1',server.server_port,timeout=40)
        c.request(method,path,json.dumps(payload,ensure_ascii=False).encode() if payload is not None else None,headers)
        r=c.getresponse();raw=r.read();h=dict(r.getheaders());status=r.status;c.close()
        try:value=json.loads(raw)
        except ValueError:value={'nonJsonResponse':True}
        events.append({'method':method,'path':path,'action':payload.get('action') if payload else None,'status':status})
        return status,value,h
    _,boot,_=request('GET','/api/workbench/bootstrap')
    headers.update({'Content-Type':'application/json','Origin':origin,'X-Fangyu-CSRF':boot['csrfToken']})
    status,logged,h=request('POST','/api/workbench',{'action':'login','data':{'username':'fixture-admin','password':fixture.PASSWORD}})
    assert status==200,(status,logged)
    headers['Cookie']=h['Set-Cookie'].split(';',1)[0];headers['X-Fangyu-CSRF']=logged['csrfToken']
    user=core.session(headers['Cookie'].split('=',1)[1]);store=cloud.first_store
    status,body,_=request('POST','/api/workbench',{'action':'customer_read_scope','data':{'usage_scope':'internal_self_use_read','approved':True}})
    assert status==403 and runtime.server._runtime_license_usage_scope()=='customer_distribution_read'
    checks.append({'group':'original-http-no-scope-or-review-selection','status':status})

    # The real Service.bind, DPAPI vault, _run, Runner and DeviceSession consume
    # only owned synthetic cloud responses. No device ID/session is injected.
    device_calls=[];held=[False];revoked=[False];commands=[];outcomes={}
    class OwnDeviceCloud:
        def __init__(self,*args,**kwargs):pass
        def call(self,operation,data,credential):
            device_calls.append(operation)
            if operation=='device_enroll':return {'device':{'id':'owned-customer-device','owner':'fixture-admin','name':'自有隔离设备'}}
            if operation=='device_poll':
                if revoked[0]:
                    from assistant.transport import CloudError
                    raise CloudError(403,'device_revoked')
                return {'safety_hold':held[0],'command':commands.pop(0) if commands and not data.get('busy') else None,'poll_after':1}
            if operation=='device_result':outcomes[data['command_id']]=deepcopy(data);return {'acknowledged':True}
            if operation in ('contact_events_sync','contact_responses_sync'):return {'acknowledged':[]}
            if operation=='account_claim':return {'claimed':True}
            raise AssertionError('Unexpected cloud operation '+operation)
        def close(self):pass
    runtime.service.cloud_factory=OwnDeviceCloud
    runtime.service.bind('owned_customer_connection_code_abcdefghijklmnopqrstuvwxyz0123456789')
    deadline=time.monotonic()+10
    while runtime.service.state!='online' and time.monotonic()<deadline:time.sleep(.03)
    assert runtime.service.state=='online',runtime.service.status()
    original_binding=connection._binding(runtime.service)
    assert original_binding[3]=='owned-customer-device'
    account={'id':'owned-customer-account','tenant_id':user['tenant_id'],'cloud_owner':user['username'],
        'store_id':store,'platform':'douyin','status':'ready','name':'隔离账号','platform_uid':'9007199254741999'}
    core.store.put('accounts',account)
    assert connection._binding(runtime.service,account['id'])[4]['id']==account['id']
    checks.append({'group':'original-cloud-bind-runner-dpapi-session-and-owned-account-admission',
        'deviceEnrollCalls':device_calls.count('device_enroll'),'pollObserved':device_calls.count('device_poll')>0,
        'originalDeviceSessionCreated':True,'syntheticBoundaryOnly':True,'nativeOrPlatformLoginClaim':False})

    user={**user,'_workbench_store_id':store}
    account={**account,'status':'login_required'};core.store.put('accounts',account)
    executor=runtime.service.executor
    def execute(action,data):return runtime._execute(executor,user,action,data)
    base={'name':'合成只保存不读取','platform':'douyin','account_id':account['id'],
        'keywords':['上海古北'],'scope':'search_comments','daily_limit':3,'target_count':20}
    before=len(processes);before_cloud=list(cloud.calls)
    plan=execute('task_save',base)
    assert plan['id'] and len(processes)==before and cloud.calls==before_cloud
    assert core.store.get('tasks',plan['id'])['status']=='ready' and plan['id'] not in core.running
    assert not core.store.list('leads',user['tenant_id'])
    checks.append({'group':'ordinary-inner-local-task-plan-save-with-unlogged-account-no-readlease',
        'cliProcesses':0,'platformRequests':0,'modelRequests':0,'cloudOperationAddedByPlan':False,
        'newCustomers':0,'autoStarted':False,'outerRuntimePlanningGateSeparate':True})
    for extra in ({'status':'ready'},{'last_result':{'status':'completed'}},{'automatic_run':True},
            {'_customer_douyin_task':True},{'usage_scope':'customer_distribution_read'}):
        denied(lambda:execute('task_save',{**base,**extra}));assert len(processes)==before
    checks.append({'group':'planning-original-field-whitelist-blocks-state-auto-run-and-scope-injection',
        'rejectedInputs':5,'cliProcesses':0})
    ready={**account,'status':'ready','conn_id':'owned-not-a-real-browser'};core.store.put('accounts',ready)
    assert runtime.server._customer_distribution_purpose('douyin_owned_keyword_search_page') is None
    assert DouyinSearchPolicy(runtime.server).resolve() is None
    denied(lambda:execute('task_run',{'task_id':plan['id'],'max_batches':1}))
    denied(lambda:core.handle('run_task_sequence',{'id':plan['id'],'max_batches':1,
        '_customer_douyin_task':True,'usage_scope':'customer_distribution_read'},user))
    assert len(processes)==before and not core.store.list('leads',user['tenant_id'])
    checks.append({'group':'missing-new-shared-readlease-helper-and-material-remain-closed',
        'taskAndCoreJsonCannotCreateTypedFrame':True,'cliProcesses':0})
    runtime.service.stop(timeout=8);assert binding_denied()
    passed=True
finally:
    if sys.exc_info()[0]:save('ERROR.json',{'traceback':traceback.format_exc()})
    if server:server.shutdown();server.server_close()
    if backend:backend.close()
    for thread in threads:thread.join(3)
    save('RESULTS.json',{'status':'PASS' if passed else 'RED','groups':checks,'groupCount':len(checks),
        'actualCompiledExe':actual_compiled,'sourceFrozenRepresentativeOnly':not actual_compiled,
        'platformRequests':0,'modelRequests':0,'actualCloudRequests':0,'cliProcesses':len(processes),
        'positiveCustomerReadLeaseUnverified':True,
        'allOwnServicesClosed':all(not t.is_alive() for t in threads) and (getattr(runtime.service,'thread',None) is None or not runtime.service.thread.is_alive())})
    print(json.dumps({'status':'PASS' if passed else 'RED','groups':len(checks),'evidence':str(OUT)},ensure_ascii=False))
