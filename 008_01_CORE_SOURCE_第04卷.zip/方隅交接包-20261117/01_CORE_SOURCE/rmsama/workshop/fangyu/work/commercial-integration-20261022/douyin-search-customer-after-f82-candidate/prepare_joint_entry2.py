from pathlib import Path
import ast,json,sys
T=Path(__file__).resolve().parent;B=T/(sys.argv[1] if len(sys.argv)>1 else 'source-joint1')
t=(B/'probe_entry-joint.py').read_text('utf-8')
t=t.replace("W.parent/'ORIGINAL-CLOUD-BRIDGE.json'","W.parent/'cloud-joint2/ORIGINAL-CLOUD-BRIDGE.json'")
needle="    assert runtime._collection_readiness(user,account)==('','')"
insert="""    observed=[]
    for row in accounts:
        state=runtime._douyin_operation(user,row,'status')
        observed.append(state)
        assert state['status']=='ready',state
    save('ORIGINAL-ACCOUNT-STATUS-OBSERVATIONS.json',observed)
    account=core.store.get('accounts',accounts[0]['id'])
    accounts=[core.store.get('accounts',row['id']) for row in accounts]
    assert runtime._collection_readiness(user,account)==('',''),runtime._collection_readiness(user,account)
"""
assert t.count(needle)==1;t=t.replace(needle,insert)
t=t.replace('deadline=time.monotonic()+8','deadline=time.monotonic()+25')
ast.parse(t);entry=B/'probe_entry-joint2.py';assert not entry.exists();entry.write_text(t,'utf-8')
C=B/'cloud-joint2';C.mkdir()
c=(B/'serve_original_cloud.cjs').read_text('utf-8')
c=c.replace('const D=__dirname,ROOT=','const D='+json.dumps(str(C).replace('\\','/'))+',ROOT=')
c=c.replace("path.join(D,'payload/project/work/app/company.json')",json.dumps(str(B/'payload/project/work/app/company.json').replace('\\','/')))
(C/'serve_original_cloud.cjs').write_text(c,'utf-8')
print('Same fixed product; original account status generates observation, no fabricated ready flag; poll wait corrected to original 15s cadence')
