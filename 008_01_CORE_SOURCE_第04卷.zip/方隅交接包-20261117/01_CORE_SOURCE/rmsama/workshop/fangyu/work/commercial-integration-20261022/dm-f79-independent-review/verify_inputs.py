from pathlib import Path
import ast,hashlib,json
W=Path(__file__).resolve().parent;C=W.parent/'dm-f79-candidate';P=W.parents[2];F=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v79/project';S=C/'qa-only-project';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
fixed={'FINAL-RECEIPT.json':'3eec74a0b654856fa4342ecc78f0328264b3ec38aea92ffa8304a455e4a8a612','SEALED.json':'629459cd38891f60a752678059b270e747f5f7c53430e71412c30017fb29950e','SOURCE-PINS.json':'3150c508129df1d69d7386f2ba5974ffe0483f3278f15f732a3cd2974ccdbbde'}
for name,pin in fixed.items():assert sha(C/name)==pin
pins=json.loads((C/'SOURCE-PINS.json').read_text('utf-8'));assert len(pins['files'])==14
for row in pins['files']:
 assert sha(C/'final-source'/row['path'])==sha(S/row['path'])==row['after']['sha256']
 if row['before']:assert sha(F/row['path'])==row['before']['sha256']
 else:assert not (F/row['path']).exists()
receipt=json.loads((C/'FINAL-RECEIPT.json').read_text('utf-8'));stage=receipt['ownedQaStage']['stage'];R=Path(stage['release']);assert R.is_relative_to(S)
assert sha(R/'RELEASE.json')=='ebe16ae93721a0c12a40a625f6486c19b5e4f86be61d99eec75c4ca6c746de6d'
assert len(json.loads((R/'RELEASE.json').read_text('utf-8'))['files'])==276
unchanged=['work/app/company.json','work/ui-runtime-r55/work/runtime/douyin-bridge/node.exe','work/ui-runtime-r55/work/runtime/douyin-bridge/lib/client/bridge-client.js','work/ui-runtime-r55/src/core/review_queue.py','work/ui-runtime-r55/src/core/continuous.py','work/ui-native-r57/reply_delivery.py']
for rel in unchanged:assert sha(S/rel)==sha(F/rel)
a_text=(F/'work/ui-native-r57/ui_native_host.py').read_bytes().decode('utf-8-sig').replace('\r\n','\n');b_text=(S/'work/ui-native-r57/ui_native_host.py').read_bytes().decode('utf-8-sig').replace('\r\n','\n')
dm_block="""    dm_entry=files.get('dm_workbench.py')
    if dm_entry is not None:
        dm_module=importlib.util.module_from_spec(importlib.util.spec_from_loader('fangyu_scoped_dm',loader=None))
        dm_module.__file__=str(root/dm_entry['path'])
        dm_raw=read_public(root/dm_entry['path'],dm_entry['sha256'],dm_entry['size'])
        exec(compile(dm_raw,dm_module.__file__,'exec'),dm_module.__dict__)
        extra['dm_factory']=dm_module.DMWorkbench
"""
assert b_text.count(dm_block)==1
find=lambda t,name:next(n for n in t.body if isinstance(n,ast.FunctionDef) and n.name==name)
for name in ('read_public','verify_backend_dependencies','create_backend'):
 a=ast.parse(a_text);b=ast.parse(b_text.replace(dm_block,''));assert ast.dump(find(a,name),include_attributes=False)==ast.dump(find(b,name),include_attributes=False),name
class RemoveOnlyDMResource(ast.NodeTransformer):
 def visit_Tuple(self,node):
  self.generic_visit(node);node.elts=[v for v in node.elts if not (isinstance(v,ast.Constant) and v.value=='dm_workbench.py')];return node
a=find(ast.parse(a_text),'verify_release');b=find(ast.parse(b_text),'verify_release');assert ast.dump(a,include_attributes=False)==ast.dump(RemoveOnlyDMResource().visit(b),include_attributes=False)
company=json.loads((S/'work/app/company.json').read_text('utf-8-sig'));assert company['runtime']['public_send_hold'] is True and company['runtime'].get('public_replies')!='enabled'
(W/'INPUTS.json').write_text(json.dumps({'fixedCandidateDocuments':fixed,'sourceFiles':pins['files'],'project':str(S),'stage':stage,'unchangedCriticalFiles':{r:sha(S/r) for r in unchanged},'defaultSourceHoldsUnchanged':True,'factoryAndCacheGuardsAstUnchangedExceptExactPinnedDMResourceLoading':True,'initialCheckerMismatch':'The first checker incorrectly required verify_release/create_backend entirely unchanged; the only accepted additions are two dm_workbench.py resource allowlists and one read_public(pin,size)+compile module loading block. Initial source input unchanged.','candidateNotFormalF79':True},ensure_ascii=False,indent=2)+'\n','utf-8')
print('14 final sources equal owned QA inputs; original cache/factory/lease/claims and default holds preserved')
