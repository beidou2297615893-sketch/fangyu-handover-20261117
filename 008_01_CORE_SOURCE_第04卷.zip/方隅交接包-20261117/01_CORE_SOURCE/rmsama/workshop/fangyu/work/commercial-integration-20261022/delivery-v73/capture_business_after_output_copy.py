"""Compare protected business rows without copying credentials or modifying production."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,sqlite3,sys
P=Path('C:/积木软件工坊/项目/方隅公寓客户版')
W=P/'work/commercial-integration-20261022';D=Path(__file__).resolve().parent
phase=sys.argv[1];assert phase in {'before-install','after-install','after-output-copy'}
sha=lambda b:hashlib.sha256(b).hexdigest()
snapshot=W/'recovery-before-next-release/20261022T174553Z/scoped-business.sqlite3'
assert sha(snapshot.read_bytes())=='d91954340064dbd12b5862589d33db42b39cb3cac73a9142169ae6ec291a09ce'
binding_path=P/'work/ui-native-r57/state/production-workspace.json'
binding=json.loads(binding_path.read_text('utf-8-sig'))
def ro(p):
    c=sqlite3.connect(p.as_uri()+'?mode=ro',uri=True);c.execute('PRAGMA query_only=ON');c.execute('BEGIN');return c
prod=ro(Path(binding['data_dir'])/'workspace.sqlite3');base=ro(snapshot)
tenants=[r[0] for r in prod.execute("SELECT DISTINCT tenant_id FROM records WHERE entity='leads' AND json_extract(body,'$.cloud_owner')=?",(binding['owner'],))]
assert len(tenants)==1
tenant=tenants[0]
entities=('leads','replies','tasks','ai_cache','rental_assessments_v1')
def read(c):
    result={}
    for name in entities:
        result['records:'+name]=c.execute('SELECT entity,id,tenant_id,body FROM records WHERE tenant_id=? AND entity=? ORDER BY entity,id,tenant_id',(tenant,name)).fetchall()
    result['unique_leads']=c.execute('SELECT * FROM unique_leads WHERE tenant_id=? ORDER BY tenant_id,platform,source_id,lead_id',(tenant,)).fetchall()
    result['contact_events']=c.execute('SELECT * FROM contact_events WHERE tenant_id=? AND cloud_owner=? ORDER BY sequence',(tenant,binding['owner'])).fetchall()
    return result
current,prior=read(prod),read(base);prod.close();base.close()
summary={}
for name,rows in current.items():
    encode=lambda r:json.dumps(r,ensure_ascii=False,separators=(',',':')).encode('utf-8')
    summary[name]={'rows':len(rows),'sha256':sha(encode(rows)),'sameAsVerifiedBackup':rows==prior[name]}
assert all(r['sameAsVerifiedBackup'] for r in summary.values()),'Protected business changed; retain actual evidence before deciding recovery'
result={'status':'PASS_PROTECTED_BUSINESS_UNCHANGED','capturedAtUtc':datetime.now(timezone.utc).isoformat(),'phase':phase,'protectedTablesAndEntities':summary,'bindingSha256':sha(binding_path.read_bytes()),'productionModified':False,'snapshotRestored':False,'credentialsOrSessionsRead':False}
dest=D/('PROTECTED-BUSINESS-'+phase.upper()+'.json')
assert not dest.exists(),'Evidence already exists; preserve the previous receipt'
if phase=='after-install':
    before=json.loads((D/'PROTECTED-BUSINESS-BEFORE-INSTALL.json').read_text('utf-8'))
    assert before['protectedTablesAndEntities']==summary and before['bindingSha256']==result['bindingSha256']
    result['sameAsBeforeInstall']=True
dest.write_text(json.dumps(result,indent=2)+'\n','utf-8')
print(json.dumps({'status':result['status'],'phase':phase,'comments':summary['records:leads']['rows'],'tasks':summary['records:tasks']['rows'],'bindingUnchanged':result['bindingSha256']=='14cf53964f5d44d123e989805ea741669ab3f05054e730ddcb299a0aac51a9cb'}))
