"""Adapt the established source CAS/backup transaction; do not execute it."""
from pathlib import Path
import ast, hashlib, json

D = Path(__file__).resolve().parent
A = D.parent/'delivery-v81/merge_canonical_source.py'
raw = A.read_text('utf-8')
changes = [
    ("B=F/'candidate-unified-v80/project';N=F/'candidate-unified-v81/project'",
     "B=F/'candidate-unified-v81/project';N=F/'candidate-unified-v82/project'"),
    ("composition=json.loads((W/'scanned-pdf-f80-integration/COMPOSITION.json').read_text('utf-8'))\npaths=sorted(r['path'] for r in composition['files'])",
     "composition=json.loads((W/'next-release-f81-expansion-composition/COMPOSITION.json').read_text('utf-8'))\npaths=sorted({r['path'] for c in composition['components'] for r in c['files']})"),
    ("expected=json.loads((D/'SOURCE-MERGE-PREPARED.json').read_text('utf-8'));assert expected['rows']==rows",
     "validation=json.loads((D/'ROOT-VALIDATION.json').read_text('utf-8'))\nassert validation['status']=='PASS_F82_ACTUAL_COMBINED_VALIDATION'\nassert validation['compositionSha256']==sha((W/'next-release-f81-expansion-composition/COMPOSITION.json').read_bytes())\nexpected=json.loads((D/'SOURCE-MERGE-PREPARED.json').read_text('utf-8'));assert expected['rows']==rows"),
]
for before, after in changes:
    assert raw.count(before) == 1
    raw = raw.replace(before, after, 1)
ast.parse(raw)
target = D/'merge_canonical_source.py'
assert not target.exists()
target.write_text(raw, 'utf-8')
capture = D/'capture_business_readonly.py'
assert not capture.exists()
capture.write_bytes((D.parent/'delivery-v81/capture_business_readonly.py').read_bytes())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
(D/'CAS-ADAPTER-PREPARATION.json').write_text(json.dumps({
    'status':'ADAPTER_PREPARED_NOT_EXECUTED_OR_SOURCE_MERGE_PREPARED',
    'matureSourceSha256':sha(A), 'adaptedSourceSha256':sha(target),
    'businessCaptureByteEqual':sha(capture)==sha(D.parent/'delivery-v81/capture_business_readonly.py'),
    'changes':'Only bound base/target, full composition path set, and explicit actual validation gate',
    'originalPerFileCasBackupAtomicWriteAndNoDbWritesRetained':True,
    'canonicalOrInstalledWritten':False}, ensure_ascii=False, indent=2)+'\n','utf-8')
print('Mature source-CAS adapter prepared; no canonical or business action executed')
