"""Actual Native auth/CSRF/runtime/store -> enterprise adapter -> actual cloud service.

Only cloud network/DB and provider are synthetic. No real platform/provider IO.
"""
from pathlib import Path
from copy import deepcopy
import hashlib,http.client,importlib.util,io,json,os,queue,subprocess,sys,threading,time,uuid
from urllib.error import HTTPError
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=Path('C:\\积木软件工坊\\项目\\方隅公寓客户版')
G=Path('C:\\积木软件工坊\\项目\\方隅公寓客户版\\work\\commercial-integration-20261022\\content-model-gateway');F=Path('C:\\积木软件工坊\\项目\\方隅公寓客户版\\work\\parallel-integration-20261018\\final-integration');C=F/'candidate-unified-v71'
S=C/'project';STAGED=json.loads((C/'STAGED.json').read_text('utf-8'));N=Path(STAGED['release'])
NODE=Path('C:/积木软件工坊/核心组件/社媒人设与内容运营组件库/runtime/tools/node-v22.23.4-win-x64/node.exe')
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);mod=importlib.util.module_from_spec(spec)
    sys.modules[name]=mod;spec.loader.exec_module(mod);return mod
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

class Bridge:
    def __init__(self):
        self.pending={};self.lock=threading.Lock();self.ops=[];self.errors=[]
        self.proc=subprocess.Popen([str(NODE),str(W/'http-fixture/native_bridge.cjs')],stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding='utf-8',creationflags=subprocess.CREATE_NO_WINDOW)
        threading.Thread(target=self.reader,daemon=True).start()
        threading.Thread(target=lambda:self.errors.extend(self.proc.stderr.readlines()),daemon=True).start()
    def reader(self):
        for line in self.proc.stdout:
            value=json.loads(line);self.pending[value['id']].put(value)
    def ask(self,command,**data):
        ident=uuid.uuid4().hex;q=queue.Queue();self.pending[ident]=q
        with self.lock:
            self.proc.stdin.write(json.dumps(dict(id=ident,command=command,**data),ensure_ascii=False)+'\n');self.proc.stdin.flush()
        result=q.get(timeout=25);self.pending.pop(ident)
        if not result['ok']:raise RuntimeError(result['error'])
        return result['result']
    def close(self):
        self.proc.stdin.close();self.proc.wait(timeout=5)

def main():
    bridge=Bridge();server=backend=None
    owned=W/('native-http-'+uuid.uuid4().hex[:10]);owned.mkdir()
    files_before={str(p.relative_to(S)):sha(p) for p in [N/'workbench_backend.py',N/'ui_native_host.py',N/'resources/content-workbench/content_workflow.py',
        N/'resources/content-gateway/gateway_adapter.py',N/'resources/platform-runtime/vendor-src/integrations.py']}
    blocked=[]
    def guard(event,args):
        if event in ('socket.connect','socket.bind') and (not isinstance(args[1],tuple) or args[1][0] not in ('127.0.0.1','::1')):
            blocked.append(event);raise RuntimeError('External sockets prohibited')
        if event=='socket.getaddrinfo' and args[0] not in ('127.0.0.1','::1','localhost',None):
            blocked.append(event);raise RuntimeError('External DNS prohibited')
        if event in ('subprocess.Popen','os.system','os.startfile','os.posix_spawn'):
            blocked.append(event);raise RuntimeError('Extra process prohibited')
        if event=='sqlite3.connect' and not Path(args[0]).resolve().is_relative_to(owned):
            blocked.append(event);raise RuntimeError('Nonfixture DB prohibited')
        if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
            flags=args[2] or 0;writing=any(c in str(args[1] or '') for c in 'wax+') or isinstance(flags,int) and bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC))
            if writing and not Path(os.fsdecode(args[0])).absolute().is_relative_to(W):
                blocked.append(event);raise RuntimeError('Nonfixture write prohibited')
    sys.addaudithook(guard)
    try:
        examples=load('gateway_native_examples',N/'resources/content-workbench/workflow_methods.py')
        ids=bridge.ask('init',output=examples.example_result('writing'))['ids']
        sys.path[:0]=[str(S/'work/ui-runtime-r55/src'),str(N)]
        integrations=load('integrations',N/'resources/platform-runtime/vendor-src/integrations.py')
        lose={'enabled':True};wires=[];profile_block={'enabled':False,'called':False}
        class Opener:
            def open(self,request,timeout):
                payload=json.loads(request.data);wires.append(deepcopy(payload))
                if payload['operation']=='ai_profile' and profile_block['enabled']:
                    profile_block['called']=True
                    raise TimeoutError('Synthetic unavailable profile must never gate local editing')
                token=request.headers.get('Authorization','').removeprefix('Bearer ')
                answer=bridge.ask('call',payload=payload,token=token)
                if payload['operation']=='content_generate' and lose['enabled']:
                    raise TimeoutError('Synthetic response lost after service commit')
                raw=json.dumps(answer['data'],ensure_ascii=False).encode()
                if answer['status']!=200:raise HTTPError(request.full_url,answer['status'],'fixture',{},io.BytesIO(raw))
                return io.BytesIO(raw)
        integrations.build_opener=lambda *args:Opener()
        host=load('gateway_native_host',N/'ui_native_host.py')
        company=dict(id=ids['company'],name='内容网关隔离验证',edition='customer',personalMode=False,
            authMode='managed',platforms=['xiaohongshu','douyin'],managedWorkspace={'environment_id':ids['env'],'endpoint':'https://no-network.invalid'})
        release=N
        _,files=host.verify_release(release,STAGED['manifest_sha256'])
        host.verify_backend_dependencies(release,files,S)
        backend=host.create_backend(release,files,project_root=S,data_dir=owned/'data',company=company)
        server=host.StaticServer(release,files,backend=backend,cookie_name='gateway_fixture_session')
        threading.Thread(target=server.serve_forever,daemon=True).start()
        origin='http://127.0.0.1:'+str(server.server_port);headers={};trace=[]
        def request(method,path,data=None,expected=200):
            conn=http.client.HTTPConnection('127.0.0.1',server.server_port,timeout=30)
            conn.request(method,path,json.dumps(data,ensure_ascii=False).encode() if data is not None else None,headers)
            response=conn.getresponse();raw=response.read();found=dict(response.getheaders());status=response.status;conn.close()
            value=json.loads(raw)
            assert status==expected,(status,value)
            return value,found
        def action(name,data,expected=200):return request('POST','/api/workbench',{'action':name,'data':data},expected)[0]
        boot,_=request('GET','/api/workbench/bootstrap');headers.update({'Content-Type':'application/json','Origin':origin,'X-Fangyu-CSRF':boot['csrfToken']})
        logged,found=request('POST','/api/workbench',{'action':'login','data':{'username':ids['actor'],'password':'[REDACTED:assigned_secret]'}})
        headers.update(Cookie=found['Set-Cookie'].split(';',1)[0]);headers['X-Fangyu-CSRF']=logged['csrfToken']
        token=headers['Cookie'].split('=',1)[1];user=backend.core.session(token)
        assert user['tenant_id']==ids['tenant']
        assert logged['selection']['storeId']==ids['store']
        backend.core.store.put('accounts',dict(id=ids['account'],tenant_id=user['tenant_id'],cloud_owner=user['username'],
            store_id=ids['store'],platform='xiaohongshu',status='disconnected',name='合成内容甲'))
        backend.platform_runtime.service.vault.write(dict(state='bound',token='f'*60,device={'id':ids['device'],'owner':ids['actor']}))
        remembered=backend.integrations._read(user['tenant_id'])['sessions'][user['id']]['device_id']
        assert remembered!=ids['device']
        for entity in ('leads','replies','ui_workbench_tone_preferences_v1'):
            backend.core.store.put(entity,dict(id='protected-'+entity,tenant_id=user['tenant_id'],cloud_owner=user['username'],text='原客户与SOP保持'))
        def oldrows():
            with backend.core.store.connect() as db:return [tuple(r) for r in db.execute("SELECT entity,id,tenant_id,body FROM records WHERE id LIKE 'protected-%' ORDER BY entity,id")]
        before_rows=oldrows();base=dict(storeId=ids['store'],accountId=ids['account'],platform='xiaohongshu');revision=0
        def read(**extra):
            nonlocal revision
            result=action('content_workspace_read',{**base,**extra});revision=result['workspace']['revision'];return result
        def save(name,expected=200,**data):
            nonlocal revision
            payload={**base,'requestId':'native-'+uuid.uuid4().hex,'expectedRevision':revision,**data}
            result=action(name,payload,expected)
            if expected==200:revision=result['workspace']['revision']
            return result,payload
        unknown=read()['workspace'];assert not unknown['contentGateway']['available']
        ready=action('content_methods_read',base)['workspace'];assert ready['contentGateway']['available'],ready['contentGateway']
        assert ready['workflowCapabilities']['canReconcileTasks']
        trace.append('actual cloud login+remember grant+central store authority+original Runtime encrypted executor vault; executor differs from remembered installation')
        save('content_knowledge_import',document={'title':'虚构资料','text':'公共厨房每周四打扫。','kind':'fact','sourceLabel':'合成说明'})
        task=save('content_task_prepare',methodId='writing',query='公共厨房')[0]['result']['task']['id']
        result,key=save('content_task_run',taskId=task)
        assert result['result']['task']['state']=='unknown',result
        assert bridge.ask('stats')['providerCalls']==1
        same=action('content_task_run',key);assert same['replayed']
        restored,_=save('content_task_reconcile',taskId=task,requestId=key['requestId'])
        assert restored['result']['task']['state']=='succeeded',restored
        assert restored['receipt']['action']=='content_task_run' and restored['receipt']['requestId']==key['requestId']
        assert restored['result']['newGenerationDispatched'] is False
        assert 'modelContext' not in json.dumps(restored) and ids['device'] not in json.dumps(restored)
        duplicate,_=save('content_task_reconcile',taskId=task,requestId=key['requestId']);assert duplicate['replayed']
        applied,_=save('content_task_apply',taskId=task);draft=applied['result']['appliedRefs']['draftIds'][0]
        save('content_draft_audit',draftId=draft,decision='approve')
        package,_=save('content_package_build',draftId=draft);assert package['result']['package']['published'] is False
        assert bridge.ask('stats')['providerCalls']==1
        save('content_task_archive',taskId=task)
        history=action('content_task_history',{**base,'taskId':task})
        assert 'modelContext' not in json.dumps(history) and ids['device'] not in json.dumps(history)
        assert history['result']['task']['input'] and history['result']['artifact']
        trace.append('HTTP lost successful response→unknown→original-key status→one candidate→apply→original audit/package; repeated queries no provider dispatch')
        profile_block['enabled']=True;profile_calls=len([p for p in wires if p['operation']=='ai_profile'])
        read();save('content_persona_save',persona={'name':'本地保存','positioning':'不等待模型服务'})
        assert profile_block['called'] is False
        assert len([p for p in wires if p['operation']=='ai_profile'])==profile_calls
        profile_block['enabled']=False
        trace.append('local workspace/persona save uses same-scope observed capability without ai_profile; unavailable profile adds no wait to local editing')
        lose['enabled']=False;bridge.ask('policy',enabled=False)
        off=action('content_methods_read',base)['workspace'];assert not off['contentGateway']['available']
        task2=save('content_task_prepare',methodId='writing',query='仍可准备')[0]['result']['task']['id']
        failed,_=save('content_task_run',taskId=task2,expected=503);assert failed['error']['code']=='CONTENT_MODEL_UNAVAILABLE'
        assert bridge.ask('stats')['providerCalls']==1
        trace.append('server default-off/unavailable exposes business state, preserves editable task, no provider call')
        bridge.ask('policy',enabled=True);read();bridge.ask('configure',mode='block')
        result_box=[];args={**base,'requestId':'native-block-'+uuid.uuid4().hex,'expectedRevision':revision,'taskId':task2}
        job=threading.Thread(target=lambda:result_box.append(action('content_task_run',args)));job.start()
        deadline=time.time()+10
        while time.time()<deadline and not bridge.ask('stats')['entered']:time.sleep(.05)
        assert bridge.ask('stats')['entered']
        started=time.monotonic();read();save('content_persona_save',persona={'name':'新定位','positioning':'本地资料仍可编辑'})
        assert time.monotonic()-started<5
        bridge.ask('release');job.join(15);assert not job.is_alive()
        assert result_box[0]['result']['task']['state']=='needs_revalidation',result_box
        read();save('content_task_apply',taskId=task2,expected=409)
        trace.append('real gateway provider waits outside Native/Store locks; concurrent local read+write complete; late result stale and apply denied')
        bridge.ask('configure',mode='timeout');read()
        task3=save('content_task_prepare',methodId='writing',query='需要核对原结果')[0]['result']['task']['id']
        uncertain,key3=save('content_task_run',taskId=task3);assert uncertain['result']['task']['state']=='unknown'
        count=bridge.ask('stats')['providerCalls']
        for _ in range(2):
            value,_=save('content_task_reconcile',taskId=task3,requestId=key3['requestId'])
            assert value['result']['task']['state']=='unknown' and value['receipt']['requestId']==key3['requestId']
        save('content_task_reconcile',taskId=task3,requestId='different-request',expected=409)
        save('content_task_archive',taskId=task3,expected=409)
        assert bridge.ask('stats')['providerCalls']==count
        trace.append('actual provider timeout/status remains unknown; repeated status, wrong key and archive cannot redispatch or erase original request')
        bridge.ask('configure',statusBlock=True);read();status_box=[]
        key_status={**base,'taskId':task3,'requestId':key3['requestId'],'expectedRevision':revision}
        job=threading.Thread(target=lambda:status_box.append(action('content_task_reconcile',key_status,403)));job.start()
        deadline=time.time()+10
        while time.time()<deadline and not bridge.ask('stats')['statusEntered']:time.sleep(.05)
        assert bridge.ask('stats')['statusEntered']
        bridge.ask('revokeStore');bridge.ask('releaseStatus');job.join(15);assert not job.is_alive()
        assert status_box and status_box[0]['error']['mutation_committed'] is True,status_box
        with backend.core.store.connect() as db:
            stored=[json.loads(r['body']) for r in db.execute("SELECT body FROM records WHERE entity='content_workspace_v1'")]
        task_records=[t for r in stored for t in r.get('workflow',{}).get('tasks',[]) if t['id']==task3]
        assert task_records and task_records[0]['state']=='unknown',task_records
        assert not task_records[0].get('artifactId')
        assert bridge.ask('stats')['providerCalls']==count
        trace.append('central store revoked while original status waits: actual cloud authority and Native after-call P1 reject; unknown receipt retained and no candidate installed')
        assert oldrows()==before_rows;assert not blocked,blocked
        for name,expected in files_before.items():assert sha(S/name)==expected,('source changed',name)
        stats=bridge.ask('stats');assert all(v is False for v in stats['providerTransactions'])
        report=dict(status='PASS',checks=trace,files=files_before,providerCalls=stats['providerCalls'],
            realProviderCalls=0,platformRequests=0,productionAccess=False,oldRowsUnchanged=True,blockedExternalAttempts=blocked,
            operations=[p['operation'] for p in wires],fixture=str(owned))
        (W/'GATEWAY-HTTP-RESULTS.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf-8')
        print(json.dumps(report,ensure_ascii=False))
    finally:
        if server:server.shutdown();server.server_close()
        if backend:backend.close()
        bridge.close()

if __name__=='__main__':main()
