"""Read-only target adaptation; all test data/evidence still in this owned dir.

This wrapper is prepared for the next frozen assembly, not an acceptance of it.
"""
from pathlib import Path
import argparse,hashlib,json
W=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--project',type=Path,required=True);p.add_argument('--stage',type=Path,required=True);p.add_argument('--stage-sha256',required=True);p.add_argument('--run',choices=('factory','dependency','ui-server'),default='factory');a=p.parse_args()
assert hashlib.sha256(a.stage.read_bytes()).hexdigest()==a.stage_sha256.lower(),'Final STAGED pin differs'
stage=json.loads(a.stage.read_text('utf-8-sig'));release=Path(stage['release']);assert release.is_relative_to(a.project),'Release not in explicit frozen project'
if a.run=='dependency':
 target=W/'test_dependency_guard.py';text=target.read_text('utf-8');old="S=W/'qa-only-project/work/ui-native-r57'";new='S=Path('+repr(str(release/'resources/content-workbench'))+')'
else:
 target=W/('test_public_factory.py' if a.run=='factory' else 'serve_ui.py');text=target.read_text('utf-8');old="S=W/'qa-only-project'";new='S=Path('+repr(str(a.project))+')'
 old_stage="json.loads((W/'QA-STAGE.json').read_text('utf-8'))";assert text.count(old_stage)==1
 text=text.replace(old_stage,'json.loads(Path('+repr(str(a.stage))+').read_text("utf-8-sig"))')
assert text.count(old)==1;text=text.replace(old,new)
exec(compile(text,str(target),'exec'),{'__file__':str(target),'__name__':'__main__'})
