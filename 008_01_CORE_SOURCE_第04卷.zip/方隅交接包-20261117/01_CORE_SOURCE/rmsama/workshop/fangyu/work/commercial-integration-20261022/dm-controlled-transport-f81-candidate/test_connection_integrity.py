"""Real original factory/HTTP/guards/Adapters/Popen/NodeCLI, synthetic Bridge only."""
from pathlib import Path
from copy import deepcopy
from types import SimpleNamespace
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
import hashlib,http.client,importlib.util,json,os,re,shlex,sys,threading,time,uuid,subprocess
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=W.parents[2];S=W/'qa-only-project'
stage_paths=sorted((S/'work/ui-native-r57/candidates').glob('*.json'));stage=json.loads(stage_paths[-1].read_text('utf-8-sig'));R=Path(stage['release'])
OUT=W/('factory-'+uuid.uuid4().hex);OUT.mkdir();events=[];wire=[];blocked=[];processes=[];checks=[];reply_permission=[True]
save=lambda name,v:(OUT/name).write_text(json.dumps(v,ensure_ascii=False,indent=2,default=str),'utf-8')
def audit(event,args):
 if event=='subprocess.Popen':
  argv=args[1];argv=[v.strip('"') for v in shlex.split(argv,posix=False)] if isinstance(argv,str) else argv
  assert Path(argv[0]).resolve()==S/'work/ui-runtime-r55/work/runtime/douyin-bridge/node.exe',argv
  assert Path(argv[1]).resolve() in (S/'work/ui-runtime-r55/work/runtime/douyin-bridge/dm_workbench_cli.js',W/'bridge_fixture.cjs'),argv
  assert Path(args[2]).resolve().is_relative_to(OUT),args;processes.append(list(argv))
 elif event in ('os.system','os.startfile','os.posix_spawn'):blocked.append(event);raise RuntimeError('Only fixed internal CLI process')
 if event in ('socket.connect','socket.bind') and (not isinstance(args[1],tuple) or args[1][0] not in ('127.0.0.1','::1')):blocked.append(event);raise RuntimeError('Loopback only')
 if event=='socket.getaddrinfo' and args[0] not in ('127.0.0.1','::1','localhost',None):raise RuntimeError('No external DNS')
 if event=='sqlite3.connect' and not Path(args[0]).resolve().is_relative_to(OUT):raise RuntimeError('Own DB only')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  path=Path(os.fsdecode(args[0])).absolute();mode,flags=args[1] or '',args[2] or 0
  if (any(c in str(mode) for c in 'wax+') or isinstance(flags,int) and flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC)) and not path.is_relative_to(OUT) and path!=S/'work/ui-runtime-r55/work/runtime/douyin-bridge/lib/client/bridge-client.js':raise RuntimeError('Own evidence/data only')
sys.addaudithook(audit)
def load(name,path):
 m=importlib.util.module_from_spec(importlib.util.spec_from_loader(name,loader=None));m.__file__=str(path);sys.modules[name]=m;exec(compile(path.read_bytes(),str(path),'exec'),m.__dict__);return m
fixture=load('dm_original_identity_fixture',P/'work/acquisition-core-repair-20261018/gui-fixture/base_fixture.py');cloud=fixture.CloudStandin(json.loads((P/'work/central-store-config/compiled-fixture.json').read_text('utf-8-sig')));company=json.loads((S/'work/app/company.json').read_text('utf-8-sig'))
def transport(*a,**k):
 value=cloud(*a,**k);value['environment_id']=company['managedWorkspace']['environment_id'];value['user']['can_reply']=reply_permission[0];return value
integration=load('integrations',R/'resources/platform-runtime/vendor-src/integrations.py');integration.request_json=transport
host=load('dm_actual_native_host',R/'ui_native_host.py');_,files=host.verify_release(R,stage['manifest_sha256']);host.verify_backend_dependencies(R,files,S)
backend=host.create_backend(R,files,project_root=S,data_dir=OUT/'data',company=company);runtime=backend.platform_runtime;core=backend.core
runtime.server._configure_bundled();runtime._platform_setup=True
core.remote_safety_hold=False;core.employee_release_device_id='dm-synthetic-device';core.employee_release_until_monotonic=time.monotonic()+600
accounts={};send_state=['sent'];bridge_calls=[];slow_listen=[False];listen_corrupt=[False];late_revoke=[False];stop_received=threading.Event()
class Bridge(BaseHTTPRequestHandler):
 def log_message(self,*a):pass
 def do_POST(self):
  data=json.loads(self.rfile.read(int(self.headers['Content-Length'])));assert self.path=='/admit'
  account=next(a for a in accounts.values() if a['conn_id']==data['connId']);operation=data['operation']
  assert data['expectedUid']==account['platform_uid']
  mode=core.account_mode_status(account['id'],user['tenant_id']);assert mode['status']=='active' and mode['mode']==('replies' if operation=='send' else 'collection'),mode
  foreign=type(core.continuous.leases)(core.store,'foreign-dm-review')
  try:foreign.acquire(account['id'],user['tenant_id'],'publishing','foreign-publication')
  except ValueError:pass
  else:raise AssertionError('Original atomic mode lease bypassed')
  args=[data['expectedUid'],data['recipient'],data['text'],data['requestId']] if operation=='send' else [data['expectedUid'],data['requestId'],data['timeoutMs']] if operation=='listen' else [data['requestId']]
  wire.append({'operation':operation,'args':args,'connection':data['connId'],'mode':mode,'foreignModeBlocked':True,'realTypedRouter':True})
  if operation=='stop':stop_received.set()
  if late_revoke[0] and operation=='listen':reply_permission[0]=False
  raw=json.dumps({'unknown':send_state[0]=='unknown','corrupt':listen_corrupt[0]}).encode()
  self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
bridge=ThreadingHTTPServer(('127.0.0.1',0),Bridge);bt=threading.Thread(target=bridge.serve_forever,daemon=True);bt.start()
bridge_process=subprocess.Popen([str(S/'work/ui-runtime-r55/work/runtime/douyin-bridge/node.exe'),str(W/'bridge_fixture.cjs'),str(bridge.server_port),str(OUT)],cwd=OUT,stdout=(OUT/'BRIDGE-STDOUT.txt').open('wb'),stderr=(OUT/'BRIDGE-STDERR.txt').open('wb'))
for _ in range(300):
 if (OUT/'BRIDGE-READY.json').exists():break
 assert bridge_process.poll() is None,'Fixture bridge exited'
 time.sleep(.02)
bridge_config=json.loads((OUT/'BRIDGE-READY.json').read_text('utf-8'))
def bridge_control(path,data={}):
 c=http.client.HTTPConnection('127.0.0.1',bridge_config['port'],timeout=10);c.request('POST','/fixture/'+path,json.dumps(data).encode(),{'Authorization':'Bearer '+bridge_config['token'],'Content-Type':'application/json'});r=c.getresponse();raw=r.read();c.close();assert r.status==200,(r.status,raw);return json.loads(raw)
def browser_conn(uid):return bridge_control('create',{'uid':uid})['connId']
server=host.StaticServer(R,files,backend=backend,cookie_name='dm_fixture_session');st=threading.Thread(target=server.serve_forever,daemon=True);st.start();origin='http://127.0.0.1:'+str(server.server_port);headers={};passed=False
def request(method,path,payload=None):
 c=http.client.HTTPConnection('127.0.0.1',server.server_port,timeout=30);c.request(method,path,json.dumps(payload,ensure_ascii=False).encode() if payload else None,headers);r=c.getresponse();raw=r.read();status=r.status;found=dict(r.getheaders());c.close();value=json.loads(raw);log=deepcopy(payload)
 if log and log.get('action')=='login':log['data']['password']='synthetic omitted'
 events.append({'method':method,'path':path,'payload':log,'status':status,'body':value});save('HTTP.json',events);return status,value,found
def action(name,data,expected=200):
 code,body,h=request('POST','/api/workbench',{'action':name,'data':data});assert code==expected,(name,code,body);return body,h
serial=0
def dm(name,data,expected=200):return action(name,{'storeId':store,**data},expected)[0].get('dmWorkspace')
def mutate(name,data,expected=200,key=None):
 global serial
 serial+=1;return dm(name,{**data,'requestId':key or 'dm-fixture-operation-'+str(serial).zfill(6)},expected)
def read(account,**data):return dm('dm_workspace_read',{'accountId':account['id'],**data})
def wait_queue(ident):
 for _ in range(300):
  row=dm('dm_queue_read',{'id':ident})
  if row['state'] not in ('prepared','running'):return row
  time.sleep(.03)
 raise AssertionError('Queue did not settle')
def draft(account,conv,text):
 d=mutate('dm_draft_save',{'accountId':account['id'],'expectedVersion':0,'target':{'conversationId':conv['id']},'text':text})
 return mutate('dm_draft_review',{'accountId':account['id'],'id':d['id'],'expectedVersion':d['version'],'confirmed':True})
def prepare(account,ds):return mutate('dm_queue_prepare',{'accountId':account['id'],'drafts':[{'id':d['id'],'version':d['version']} for d in ds]})
def start(q,key=None):return mutate('dm_queue_start',{'id':q['id'],'snapshotDigest':q['snapshotDigest'],'confirmed':True},key=key)
try:
 _,boot,_=request('GET','/api/workbench/bootstrap');headers.update({'Content-Type':'application/json','Origin':origin,'X-Fangyu-CSRF':boot['csrfToken']});_,logged,h=request('POST','/api/workbench',{'action':'login','data':{'username':'fixture-admin','password':fixture.PASSWORD}});headers['Cookie']=h['Set-Cookie'].split(';',1)[0];headers['X-Fangyu-CSRF']=logged['csrfToken'];store=cloud.first_store
 if logged['selection']['storeId']!=store:action('select_store',{'storeId':store,'expectedRevision':logged['selection']['revision']})
 user={**core.session(headers['Cookie'].split('=',1)[1]),'_workbench_store_id':store}
 from assistant.business import BusinessExecutor
 from assistant.xhs_app_context import bind_executor_session
 executor=BusinessExecutor(runtime.server,company['managedWorkspace']['environment_id'],company['id'],user['username']);runtime.service.executor=executor
 saved={'state':'bound','environment_id':company['managedWorkspace']['environment_id'],'company_id':company['id'],'token':'synthetic-device-token','device':{'id':'dm-synthetic-device','owner':user['username']}}
 runtime.service.vault=SimpleNamespace(read=lambda:deepcopy(saved));runtime.service.device=deepcopy(saved['device']);runtime.service.state='online'
 class DeviceCloud:
  def call(self,operation,data,credential):return {'claimed':True}
  def close(self):pass
 runtime.service._cloud=lambda:DeviceCloud();executor.account_claim=runtime.service._claim_xhs_account;bind_executor_session(runtime.service,executor,saved)
 from assistant.douyin_connection_service import _components
 component_revision=_components(runtime.server);assert len(component_revision)==64
 checks.append('Original active account connection _components accepts exact new reviewed Bridge material with original purpose and held grant unchanged')
 target=S/'work/ui-runtime-r55/work/runtime/douyin-bridge/lib/client/bridge-client.js';original=target.read_bytes()
 try:
  target.write_bytes(original+b'\n// own controlled tamper probe\n')
  try:_components(runtime.server)
  except ValueError as e:assert str(e)=='component_review_pending'
  else:raise AssertionError('Changed original account connection component accepted')
  try:core.adapters.direct_messages({'platform':'douyin','platform_uid':'9007199254740993','conn_id':'synthetic-connection'},'listen','integrity-original-key',OUT/'account',guard=lambda:None,timeout_ms=100)
  except ValueError as e:assert '发生变化' in str(e)
  else:raise AssertionError('Changed pinned CLI dependency accepted')
 finally:target.write_bytes(original)
 assert _components(runtime.server)==component_revision
 assert not wire and len(processes)==1 # only owned fixture host, no DM CLI
 checks.append('Mutated client is refused by both original account _components and original DM pin gate; exact restore recovers same revision, zero CLI/page dispatch')
 save('INTEGRITY-RESULTS.json',{'status':'PASS','checks':checks,'actualOriginalFactory':True,'exactOwnQaClientRestored':True,'canonicalWrites':False,'realPlatformCalls':0});passed=True

finally:
 server.shutdown();st.join(3);server.server_close();backend.close();bridge_control('shutdown');bridge_process.wait(timeout=10);bridge.shutdown();bt.join(3);bridge.server_close();save('FINAL.json',{'status':'PASS' if passed else 'RED_CAPTURED','checks':checks,'blocked':blocked,'wire':wire,'processes':processes,'allOwnServersClosed':not st.is_alive() and not bt.is_alive()});print(str(OUT),flush=True)
