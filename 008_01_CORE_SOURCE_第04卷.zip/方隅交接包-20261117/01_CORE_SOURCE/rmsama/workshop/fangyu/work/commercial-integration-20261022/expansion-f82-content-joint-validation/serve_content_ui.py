"""Owned full Native HTTP fixture for development Chromium; no Native window."""
from pathlib import Path
import hashlib,http.client,importlib.util,json,os,sys,threading,time,uuid
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=W.parents[2];stage=json.loads((W/'F82-STAGED.json').read_text('utf-8-sig'));S=Path('C:\\积木软件工坊\\项目\\方隅公寓客户版\\work\\parallel-integration-20261018\\final-integration\\candidate-unified-v82\\project');R=Path(stage['release']);out=W/('ui-http-'+uuid.uuid4().hex);out.mkdir();stop=out/'STOP';events=[]
def audit(event,args):
 if event in ('subprocess.Popen','os.system','os.startfile','os.posix_spawn'):raise RuntimeError('No child process')
 if event in ('socket.connect','socket.bind') and (not isinstance(args[1],tuple) or args[1][0] not in ('127.0.0.1','::1')):raise RuntimeError('Loopback only')
 if event=='socket.getaddrinfo' and args[0] not in ('127.0.0.1','::1','localhost',None):raise RuntimeError('No external DNS')
 if event=='sqlite3.connect' and not Path(args[0]).resolve().is_relative_to(out):raise RuntimeError('Own DB only')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  path=Path(os.fsdecode(args[0])).absolute();mode,flags=args[1] or '',args[2] or 0
  if (any(c in str(mode) for c in 'wax+') or isinstance(flags,int) and flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC)) and not path.is_relative_to(out) and path!=W/'UI-SERVER.json':raise RuntimeError('Own writes only')
sys.addaudithook(audit)
def load(name,path):
 m=importlib.util.module_from_spec(importlib.util.spec_from_loader(name,loader=None));m.__file__=str(path);sys.modules[name]=m;exec(compile(path.read_bytes(),str(path),'exec'),m.__dict__);return m
fixture=load('guided_ui_original_identity',P/'work/acquisition-core-repair-20261018/gui-fixture/base_fixture.py');cloud=fixture.CloudStandin(json.loads((P/'work/central-store-config/compiled-fixture.json').read_text('utf-8-sig')));company=json.loads((S/'work/app/company.json').read_text('utf-8-sig'))
def transport(*a,**k):
 result=cloud(*a,**k);result['environment_id']=company['managedWorkspace']['environment_id'];return result
integration=load('integrations',R/'resources/platform-runtime/vendor-src/integrations.py');integration.request_json=transport
host=load('guided_ui_actual_host',R/'ui_native_host.py');_,files=host.verify_release(R,stage['manifest_sha256']);host.verify_backend_dependencies(R,files,S)
def model(envelope):
 events.append({'operation':'generation','requestId':envelope['requestId'],'method':envelope['method']['id']})
 if envelope['method']['id']=='learning':return {'state':'succeeded','requestId':envelope['requestId'],'output':{'summary':'合成复盘建议，效果待验证','facts':[],'hypotheses':['合成通勤问题适合作为下一次验证方向。'],'artifact':{'lessons':[{'observation':'合成观察尚未验证。','proposedRule':'先核对通勤范围再讨论内容，仅作候选。','evidenceIds':[]}],'nextTests':['少量同条件样本核对，不自动执行。']}}}
 return {'state':'unknown','requestId':envelope['requestId']}
def status(envelope):events.append({'operation':'status','requestId':envelope['requestId']});return {'state':'unknown','requestId':envelope['requestId']}
model.status=status
backend=host.create_backend(R,files,project_root=S,data_dir=out/'data',company=company,content_model_adapter=model)
server=host.StaticServer(R,files,backend=backend,cookie_name='guided_ui_session');thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
origin='http://127.0.0.1:'+str(server.server_port);headers={}
def setup_request(method,payload=None):
 c=http.client.HTTPConnection('127.0.0.1',server.server_port,timeout=30);c.request(method,'/api/workbench/bootstrap' if method=='GET' else '/api/workbench',json.dumps(payload).encode() if payload else None,headers);r=c.getresponse();raw=r.read();status=r.status;h=dict(r.getheaders());c.close();assert status==200,(status,raw[:300]);return json.loads(raw),h
boot,_=setup_request('GET');headers.update({'Origin':origin,'Content-Type':'application/json','X-Fangyu-CSRF':boot['csrfToken']});logged,h=setup_request('POST',{'action':'login','data':{'username':'fixture-admin','password':fixture.PASSWORD}});headers.update(Cookie=h['Set-Cookie'].split(';',1)[0]);headers['X-Fangyu-CSRF']=logged['csrfToken']
if logged['selection']['storeId']!=cloud.first_store:setup_request('POST',{'action':'select_store','data':{'storeId':cloud.first_store,'expectedRevision':logged['selection']['revision']}})
user=backend.core.session(headers['Cookie'].split('=',1)[1]);backend.core.store.put('accounts',{'id':'guided-ui-account','tenant_id':user['tenant_id'],'cloud_owner':user['username'],'store_id':cloud.first_store,'platform':'xiaohongshu','status':'disconnected','name':'合成运营账号','platformNickname':'合成内容昵称'})
raw_response=(W/'DDGS-RAW-RESPONSE.html').read_bytes()assert hashlib.sha256(raw_response).hexdigest()=='7f893a44a98c4220b0d9d896c008945f573d5ad8afbbfc48979ac9894f9372c0'public_calls=[]def public_source(method,url,payload): assert method=='POST' and url=='https://html.duckduckgo.com/html/' assert not backend.lock._is_owned() with backend.core.store.connect() as db:db.execute('BEGIN IMMEDIATE');db.execute('ROLLBACK') public_calls.append({'query':payload['q'],'mode':'fixed-response-replay-no-external'}) (out/'PUBLIC-CALLS.json').write_text(json.dumps(public_calls,ensure_ascii=False,indent=2),'utf-8') if '等待' in payload['q']:time.sleep(2) return 200,raw_responsebackend._public_search_response_transport=public_sourceinfo={'origin':'http://127.0.0.1:'+str(server.server_port),'username':'fixture-admin','password':fixture.PASSWORD,'directory':str(out),'stop':str(stop),'stage':stage,'syntheticOnly':True};(W/'UI-SERVER.json').write_text(json.dumps(info,ensure_ascii=False,indent=2),'utf-8');print(info['origin'],flush=True)
try:
 deadline=time.monotonic()+900
 while not stop.exists() and time.monotonic()<deadline:time.sleep(.2)
finally:
 server.shutdown();thread.join(3);server.server_close();backend.close();(out/'FINAL.json').write_text(json.dumps({'status':'STOPPED_OWN_HTTP_FIXTURE','modelEvents':events,'publicProviderReplays':public_calls,'realExternalSearchCalls':0,'realModelPlatformCalls':0,'nativeWindow':False,'productionAccess':False,'threadClosed':not thread.is_alive()},ensure_ascii=False,indent=2),'utf-8')
