from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
D=Path(__file__).resolve().parent;W=D.parent
H=D/'frozen-native'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text('utf-8-sig'))
pins=read(D/'FINAL-PINS.json')
source=read(H/'FROZEN-NATIVE-HTTP-RESULTS-candidate-unified-v71.json')
content=read(H/'RESULTS-candidate-unified-v71.json');gateway=read(H/'GATEWAY-HTTP-RESULTS.json')
assert content['status'].startswith('PASS') and content['checks']==14
assert source['status'].startswith('PASS') and source['checks']==11
assert gateway['status']=='PASS' and len(gateway['checks'])==7
extra=W/'v71-final-independent-validation';independent=read(extra/'FINAL-VALIDATION.json')
assert independent['status']=='PASS_FINAL_FROZEN_INDEPENDENT_VALIDATION'
assert independent['knowledgeRealFactoryHTTP']==4 and independent['publicationActualNativeHTTP']==5
assert independent['publicationOriginalCoreRestart']==6
for key in ('unifiedPinsSha256','stagedSha256','manifestSha256','releaseId','unifiedFileCount','releaseFileCount'):
    assert independent['finalPins'][key]==pins[key],key
media=read(W/'v71-media-outcomes-frozen/SUMMARY.json')
assert media['status']=='PASS_ACTUAL_UNIFIED_V71_MEDIA8_OUTCOMES6'
sched=W/'v71-schedule-frozen-validation';s=read(sched/'VALIDATION.json')
assert s['status']=='PASS_FROZEN_V71_ORIGINAL_ASSERTIONS' and s['nativeHTTPChecks']==15 and s['browserRenderBindChecks']==5
pre=read(sched/'ENABLE-PRECONDITION-RESULTS.json')
assert 'PASS' in str(pre)
ui=read(W/'v71-readiness-ui/FINAL-READINESS-UI.json')
assert ui['status']=='PASS_V71_FROZEN_READINESS_UI' and ui['groups']==9 and ui['frozenModules']==45
evidence={}
for dest,origin in {
    'CLOSURE-RESULTS.json':extra/'CLOSURE-RESULTS.json',
    'INDEPENDENT-FINAL-VALIDATION.json':extra/'FINAL-VALIDATION.json',
    'MEDIA-OUTCOMES-SUMMARY.json':W/'v71-media-outcomes-frozen/SUMMARY.json',
    'SOURCE-SCHEDULER-FINAL.json':sched/'VALIDATION.json',
    'SOURCE-SCHEDULER-PRECONDITION.json':sched/'ENABLE-PRECONDITION-RESULTS.json',
    'READINESS-UI-FINAL.json':W/'v71-readiness-ui/FINAL-READINESS-UI.json',
}.items():
    target=H/dest
    assert not target.exists() or target.read_bytes()==origin.read_bytes()
    target.write_bytes(origin.read_bytes());evidence[dest]=sha(target)
for name in ('RESULTS-candidate-unified-v71.json','FROZEN-NATIVE-HTTP-RESULTS-candidate-unified-v71.json','GATEWAY-HTTP-RESULTS.json'):
    evidence[name]=sha(H/name)
closure=read(H/'CLOSURE-RESULTS.json')
assert closure['status']=='PASS' and closure['unifiedFiles']==3152 and closure['releaseFiles']==196
report={'status':'PASS_UNIFIED_V71_70_HTTP_AND_FROZEN_CLOSURE','timestampUtc':datetime.now(timezone.utc).isoformat(),'candidate':pins['candidate'],'release':pins['releaseId'],'unifiedPinsSha':pins['unifiedPinsSha256'],'stagedSha':pins['stagedSha256'],'releaseManifestSha':pins['manifestSha256'],'unifiedFiles':3152,'releaseFiles':196,
    'totalHttpGroups':70,'httpGroups':{'originalContent':14,'originalSource':11,'gateway':7,'media':8,'customerOutcomes':6,'knowledge':4,'publication':5,'sourceScheduler':15},
    'additionalChecks':{'publicationRestart':6,'independentSchedule':5,'readinessAppDOM':9,'knowledgeDOM':4,'scheduleChromium':5,'sourceScheduleConnectionPreconditions':3},
    'evidenceSha256':evidence,'realModelCalls':0,'realPlatformRequests':0,'productionAccess':False,'actualV71NativeCUA':False,'canonicalInstalled':False,
    'priorActualNativeUIEvidence':'v70 actual frozen media/customer-outcome CUA completed; v69 actual customer refresh/cross-page export CUA completed. These do not substitute for actual v71 installed startup.',
    'limits':['Real platform acquisition, new model generation and publication are not verified by synthetic network fixtures.','Publication protocol remains unset and cloud generation/publication release gates remain fixed closed.','Final v71 Native installed startup and data preservation are separate acceptance steps.','Ordinary-PC standalone package is a separately derived held candidate and has separate pins/validation.','Media Windows save dialog remains unverified; actual authenticated MP4 response and exact-byte export passed.']}
dest=H/'SUMMARY.json';assert not dest.exists()
dest.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps({'status':report['status'],'totalHttpGroups':70,'summarySha256':sha(dest),'frozenCandidate':pins['candidate']}))
