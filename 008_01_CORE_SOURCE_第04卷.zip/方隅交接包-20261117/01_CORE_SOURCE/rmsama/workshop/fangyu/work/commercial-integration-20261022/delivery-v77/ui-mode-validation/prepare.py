from pathlib import Path
import hashlib,json
W=Path(__file__).resolve().parent;P=W.parents[3]
old=P/'work/commercial-integration-20261022/delivery-v76/ui-mode-validation/complete-readonly-context'
raw=(old/'serve_ui.py').read_bytes();text=raw.decode('utf-8')
assert text.count('P=W.parents[4];S=')==1 and text.count('candidate-unified-v76/project')==1
text=text.replace('P=W.parents[4];S=','P=W.parents[3];S=').replace('candidate-unified-v76/project','candidate-unified-v77/project').replace('actualF76Stage','actualF77Stage')
assert not (W/'serve_ui.py').exists()
(W/'serve_ui.py').write_text(text,encoding='utf-8')
test=(old/'test_mode_ui.cjs').read_text('utf-8').replace('F76','F77')
(W/'test_mode_ui.cjs').write_text(test,encoding='utf-8')
(W/'PREPARATION.json').write_text(json.dumps({'sourceSha256':hashlib.sha256(raw).hexdigest(),'sourceFolder':str(old),'changes':'Own test directory depth and exact actual F77 path/labels only; original scope, temporary synthetic read-only QA context, font >=14 and no-overflow assertions retained','realNativeWindowOrProduction':False,'oldFontRedRetained':True},indent=2)+'\n',encoding='utf-8')
print('PREPARED_EXACT_F77_UI_TEST_WITHOUT_CHANGING_PRODUCT')
