'use strict';
// Offline public seams only: real service and index.createStore, synthetic DB/provider.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const Module = require('node:module');
const crypto = require('node:crypto');
const {AsyncLocalStorage} = require('node:async_hooks');

const GATEWAY = "C:\\\u79ef\u6728\u8f6f\u4ef6\u5de5\u574a\\\u9879\u76ee\\\u65b9\u9685\u516c\u5bd3\u5ba2\u6237\u7248\\work\\commercial-integration-20261022\\content-cloud-v3-final";
const IDS = Object.freeze({"company": "fangyu-apartment-client", "env": "overnight-fixture", "store": "fy_s_d343f3a378f48e1bab55df4f", "storeB": "fy_s_698e11d3119f2b43d202c1ed", "account": "workflow-first", "device": "fixture-platform-device", "actor": "fixture-operator", "admin": "fixture-cloud-owner", "tenant": "cloud-854ee5000df9bbc0bd4bd482"});
const NOW = Date.UTC(2026, 9, 23, 2);
const SECRET = '[REDACTED:api_key_sk]';
const PASSWORD = '[REDACTED:assigned_secret]';
const clone = value => structuredClone(value);
const copyMap = source => new Map([...source].map(([key, value]) => [key, clone(value)]));
const hash = value => crypto.createHash('sha256').update(String(value)).digest('hex');

function loadActualModules(sourceDir = path.join(GATEWAY, 'candidate')) {
  const directory = path.resolve(sourceDir), filename = path.join(directory, 'index.js');
  // SDK is the sole replaced require. Every relative/internal dependency is real.
  const actualRequire = Module.createRequire(filename);
  const sdk = Object.freeze({init() {throw new Error('FIXTURE_NETWORK_SDK_FORBIDDEN');}});
  const guardedRequire = name => name === '@cloudbase/node-sdk' ? sdk : actualRequire(name);
  const instance = {exports: {}};
  const execute = new vm.Script(Module.wrap(fs.readFileSync(filename, 'utf8')), {filename}).runInThisContext();
  execute(instance.exports, guardedRequire, instance, filename, directory);
  assert.equal(typeof instance.exports.createStore, 'function');
  const {createService} = actualRequire('./service.cjs');
  assert.equal(typeof createService, 'function');
  return {createStore: instance.exports.createStore, createService, sourceDir: directory};
}

function memoryDb({replay = false, documents: initial = []} = {}) {
  let documents = copyMap(new Map(initial));
  let queue = Promise.resolve(), rejectWrite = null, rejectCommit = null, nextTransaction = 0;
  let settlementFailures = 0;
  const transactions = new AsyncLocalStorage();
  const counters = {transactions: 0, callbackExecutions: 0, commits: 0, rollbacks: 0,
    attemptedWrites: 0, committedWrites: 0, replayedCallbacks: 0};
  const history = [];
  function refFor(map, name, id, context = null) {
    const key = `${name}/${id}`;
    return {
      async get() {
        return {data: map.has(key) ? {...clone(map.get(key)), _id: id} : []};
      },
      async set(value) {
        if (!context) throw new Error('FIXTURE_WRITE_OUTSIDE_TRANSACTION');
        if (!value || typeof value !== 'object' || Object.hasOwn(value, '_id'))
          throw new TypeError('FIXTURE_DOCUMENT_SET_REJECTS_OWN_ID');
        counters.attemptedWrites++;
        const before = map.has(key) ? clone(map.get(key)) : null;
        const metadata = {id, before, transactionId: context.id, attempt: context.attempt,
          writeIndex: context.writes.length};
        const settling = name === 'fangyu_ai_ledger' &&
          ['settled', 'billing_unknown', 'invalid_output', 'unbilled'].includes(value.status);
        if (settlementFailures > 0 && settling) {
          settlementFailures--;
          throw new Error('FIXTURE_STORAGE_FAILURE');
        }
        if (rejectWrite && rejectWrite(name, clone(value), metadata)) throw new Error('FIXTURE_STORAGE_FAILURE');
        map.set(key, clone(value));
        context.writes.push({collection: name, id});
      }
    };
  }
  const transactionFor = (map, context) => ({collection: name => ({doc: id => refFor(map, name, id, context)})});
  const db = {
    runTransaction(callback) {
      const task = queue.then(async () => {
        const id = ++nextTransaction;
        counters.transactions++;
        const configured = typeof replay === 'function' ? replay({transactionId: id}) : replay;
        const extras = configured === true ? 1 : configured === false ? 0 : configured;
        if (!Number.isInteger(extras) || extras < 0 || extras > 10) throw new TypeError('FIXTURE_REPLAY_MUST_BE_0_TO_10');
        try {
          for (let attempt = 0; attempt <= extras; attempt++) {
            const staged = copyMap(documents), context = {id, attempt, writes: []};
            counters.callbackExecutions++;
            const result = await transactions.run(context, () => callback(transactionFor(staged, context)));
            if (attempt < extras) {
              counters.replayedCallbacks++;
              history.push({transactionId: id, attempt, outcome: 'discarded', writes: clone(context.writes)});
              continue;
            }
            if (rejectCommit?.({transactionId: id, writes: clone(context.writes)}))
              throw new Error('FIXTURE_STORAGE_FAILURE');
            documents = staged; // The only commit point; other readers never see staged state.
            counters.commits++;
            counters.committedWrites += context.writes.length;
            history.push({transactionId: id, attempt, outcome: 'committed', writes: clone(context.writes)});
            return result;
          }
        } catch (error) {
          counters.rollbacks++;
          history.push({transactionId: id, outcome: 'rolled_back'});
          throw error;
        }
      });
      queue = task.catch(() => {});
      return task;
    },
    collection: name => ({doc: id => ({
      get: () => refFor(documents, name, id).get(),
      set: () => Promise.reject(new Error('FIXTURE_WRITE_OUTSIDE_TRANSACTION'))
    })})
  };
  return {db,
    state: (company = IDS.company) => clone(documents.get(`fangyu_workspace_private/${company}`)?.state ?? null),
    rows: collection => [...documents].filter(([key]) => key.startsWith(`${collection}/`)).map(([, value]) => clone(value)),
    snapshot: () => copyMap(documents),
    stats: () => ({...counters}),
    history: () => clone(history),
    inTransaction: () => transactions.getStore() !== undefined,
    rejectWriteWhen(predicate) {rejectWrite = predicate;},
    rejectCommitWhen(predicate) {rejectCommit = predicate;},
    failSettlementOnce() {settlementFailures++;},
    idle: () => queue
  };
}

function defaultResult(request) {
  const input = JSON.parse(request.messages[1].content);
  if (!Number.isInteger(input.count)) throw new Error('FIXTURE_PROVIDER_REQUIRED_FOR_THIS_OPERATION');
  const output = {keywords: Array.from({length: input.count}, (_, i) => ({keyword: `${input.city}求租需求${i + 1}`,
    group: '租房需求', recommended: i < 10, reason: '明确寻找本地租房需求'}))};
  return {model: request.model, ...(request.provider === 'openai' ? {service_tier: 'default'} : {}),
    usage: request.provider === 'openai'
      ? {prompt_tokens: 100, completion_tokens: 50, total_tokens: 150,
        prompt_tokens_details: {cached_tokens: 0}, completion_tokens_details: {reasoning_tokens: 0}}
      : {prompt_tokens: 100, prompt_cache_hit_tokens: 20, prompt_cache_miss_tokens: 80, completion_tokens: 50},
    choices: [{finish_reason: 'stop', message: {content: JSON.stringify(output)}}]};
}

async function fixture({provider, policy, contentOptions = {enabled: true, tenantId: IDS.tenant, revision: 1},
  replay = false, budget = 5, shared, clock, now, servicePeriod, sourceDir} = {}) {
  const memory = shared || memoryDb({replay});
  const {createStore, createService} = loadActualModules(sourceDir);
  const store = createStore(memory.db, IDS.company);
  let time = typeof now === 'number' ? now : NOW;
  const currentTime = () => typeof clock === 'function' ? clock() : typeof now === 'function' ? now() : time;
  let calls = 0, service, admin, staff;
  const providerTransactions = [], providerRequests = [];
  const paidProvider = async request => {
    calls++;
    providerTransactions.push(memory.inTransaction());
    assert.equal(memory.inTransaction(), false, 'provider must run after the real transaction commits');
    assert.equal(request.apiKey, SECRET);
    assert.equal(JSON.stringify(request.messages).includes(SECRET), false);
    providerRequests.push(clone({...request, apiKey: '[REDACTED:assigned_secret]'}));
    return provider ? provider(request) : defaultResult(request);
  };
  const options = {store, environmentId: IDS.env, companyId: IDS.company,
    initialAdmin: IDS.admin, initialPassword: PASSWORD, clock: currentTime,
    aiProvider: paidProvider, aiRetryDelay: async () => {}, productAccessPolicy: policy,
    servicePeriod, contentGeneration: contentOptions};
  const restart = () => {service = createService(options); return service;};
  restart();
  const call = (operation, data = {}, token = staff) => service({environment_id: IDS.env, operation, ...data}, token);
  const login = await call('login', {username: IDS.admin, password: PASSWORD}, '');
  assert.equal(login.status, 200, 'fixture admin login must use actual service');
  admin = login.data.token;
  const member = await call('member_save', {username: IDS.actor, password: PASSWORD, role: 'operator', store_id: IDS.store}, admin);
  assert.equal(member.status, 200, 'fixture member must be created through public admin action');
  async function changeTrustedState(callback) {
    return store.transaction(async (state, transaction) => {
      const next = clone(state);
      const result = await callback(next, transaction);
      return {state: next, result};
    });
  }
  await changeTrustedState(state => {
    const user = state.users.find(row => row.username === IDS.actor);
    user.tenant_id = IDS.tenant;
    user.store_id = IDS.store;
    // Synthetic authority fixtures only; no account data leaves the process.
    state.devices = [{id: IDS.device, name: 'Synthetic fixture device', owner: IDS.actor,
      digest: hash('fixture-device-token-not-real-1234567890'), revoked: false,
      created_at: Math.floor(currentTime() / 1000), last_seen: Math.floor(currentTime() / 1000)}];
    state.xhs_claims = [{device_id: IDS.device, account_id: IDS.account,
      uid_hash: hash('fixture-platform-uid-a'), created_at: Math.floor(currentTime() / 1000),
      checked_at: Math.floor(currentTime() / 1000)}];
  });
  const central=require(path.join(GATEWAY,'candidate/store_config.cjs'));
  await store.transaction(async(state,transaction)=>{
    const compiled=JSON.parse(fs.readFileSync(path.join(__dirname,'compiled.json'),'utf8'));
    const collection=transaction.collection('fangyu_workspace_private');
    const manifest=structuredClone(compiled.manifest);delete manifest._id;
    await collection.doc(central.manifestId(IDS.company)).set(manifest);
    for(const doc of compiled.documents) if(doc.doc_type==='store_config_version') {
      const clean=structuredClone(doc);delete clean._id;
      await collection.doc(central.versionId(IDS.company,compiled.manifest.active_revision,doc.store_id)).set(clean);
    }
    return {state,result:null};
  });
  async function changeCentralCatalogue(callback){
    return store.transaction(async(state,transaction)=>{
      const ref=transaction.collection('fangyu_workspace_private').doc(central.manifestId(IDS.company));
      const snapshot=await ref.get(),row=clone(snapshot.data);
      delete row._id;await callback(row,transaction);await ref.set(row);return {state,result:null};
    });
  }
  const staffLogin = await call('login', {username: IDS.actor, password: PASSWORD}, '');
  assert.equal(staffLogin.status, 200, 'fixture staff login must use actual service');
  staff = staffLogin.data.token;
  const config = await call('ai_config_save', {api_key: SECRET, config: {enabled: true, daily_budget_cny: budget}}, admin);
  assert.equal(config.status, 200, 'fixture AI configuration must use public admin action');
  return {call, admin, staff, memory, store, ids: IDS, sourceDir: path.resolve(sourceDir || path.join(GATEWAY, 'candidate')),
    contentOptions, providerTransactions, providerRequests,
    calls: () => calls, restart,
    profile: async (token = staff) => {
      const response = await call('ai_profile', {}, token);
      assert.equal(response.status, 200);
      return response.data;
    },
    readStatus: (payload, token = staff) => call('content_generate_status',
      {...(typeof payload === 'string' ? {request_id: payload} : payload), operation: 'content_generate_status'}, token),
    changeTrustedState,changeCentralCatalogue,
    advance(milliseconds) {
      if (typeof clock === 'function' || typeof now === 'function') throw new Error('FIXTURE_EXTERNAL_CLOCK_CANNOT_ADVANCE');
      if (!Number.isFinite(milliseconds) || milliseconds < 0) throw new TypeError('FIXTURE_ADVANCE_MUST_BE_NONNEGATIVE');
      time += milliseconds;
      return time;
    }
  };
}

module.exports = {fixture, memoryDb, loadActualModules, IDS, NOW, SECRET};
