from pathlib import Path
import hashlib,json,re,ast
W=Path(__file__).resolve().parent;P=W.parents[2];S=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v81/project';O=W/'source-candidate';Q=W/'qa-only-project'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((W/'SOURCE-FILES.draft.json').read_text('utf-8'));rows=manifest['files']
def put(rel,raw):
 before=(S/rel).read_bytes();raw=raw.replace(b'\r\n',b'\n')
 if b'\r\n' in before:raw=raw.replace(b'\n',b'\r\n')
 for root in [O,Q]:
  p=root/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
 rows.append({'path':rel,'beforeOrigin':'immutable F81, byte-only pin regeneration; no purpose/permission change','before':{'sha256':hashlib.sha256(before).hexdigest(),'bytes':len(before)},'after':{'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}})
rel='work/shared-backend-integration/vendor-src/douyin-connection-review.json'
old=json.loads((S/rel).read_text('utf-8'));review=json.loads((S/rel).read_text('utf-8'))
for item in review['materials']:
 if item['root']=='douyin_runtime':
  p=Q/'work/ui-runtime-r55/work/runtime/douyin-bridge'/item['path'];item['sha256']=sha(p).upper();item['bytes']=p.stat().st_size
present={(r['root'],r['path']) for r in review['materials']}
for name in ['lib/server/dm.js','dm_workbench_cli.js','lib/dm_workbench_browser.js']:
 if ('douyin_runtime',name) not in present:
  p=Q/'work/ui-runtime-r55/work/runtime/douyin-bridge'/name;review['materials'].append({'root':'douyin_runtime','path':name,'sha256':sha(p).upper(),'bytes':p.stat().st_size,'role':'source_or_declared_dependency'})
assert {k:v for k,v in review.items() if k!='materials'}=={k:v for k,v in old.items() if k!='materials'}
put(rel,json.dumps(review,ensure_ascii=False,indent=2).encode())
review_sha=sha(O/rel)
service='work/shared-backend-integration/vendor-src/assistant/douyin_connection_service.py'
t=(S/service).read_text('utf-8');updated,n=re.subn(r"_REVIEW_SHA='[A-F0-9]{64}'","_REVIEW_SHA='"+review_sha.upper()+"'",t);assert n==1
before_ast=ast.parse(t);after_ast=ast.parse(updated)
assert [(n.name,ast.dump(n,include_attributes=False)) for n in before_ast.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))]==[(n.name,ast.dump(n,include_attributes=False)) for n in after_ast.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))]
put(service,updated.encode())
rel='work/shared-backend-integration/vendor-src/SOURCE.json';value=json.loads((S/rel).read_text('utf-8'))
value['files']['assistant/douyin_connection_service.py']['candidate_sha256']=sha(O/service)
value['source_trial']['douyin']['review_sha256']=review_sha
put(rel,json.dumps(value,ensure_ascii=False,indent=2).encode())
(W/'SOURCE-FILES.draft.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),'utf-8')
# Full, explicit cross-review reference inventory. Historical/app mirrors are
# not silently promoted. Final root composition must regenerate affected
# runtime-purpose reviews over its actual merged Bridge bytes.
need=[]
baseline=json.loads((P/'work/parallel-integration-20261018/final-integration/candidate-unified-v81/UNIFIED-PINS.json').read_text('utf-8'))['files']
for f in baseline:
 rel=f['path']
 if rel.startswith('work/ui-native-r57/releases/') or Path(rel).suffix not in ('.py','.json','.js'):continue
 p=S/rel
 if p.stat().st_size>4000000:continue
 try:text=p.read_text('utf-8').lower()
 except UnicodeDecodeError:continue
 hits=[{'changedPath':r['path'],'oldSha256':r['before']['sha256'],'newSha256':r['after']['sha256']} for r in rows if r['before'] and r['before']['sha256'].lower() in text]
 if hits:need.append({'referenceFile':rel,'alreadyInSourceCandidate':any(r['path']==rel for r in rows),'references':hits})
(W/'MERGED-REPIN-REQUIREMENTS.json').write_text(json.dumps({'baseline':'immutable F81','activeVendorConnectionPinsRegenerated':True,'activeConnectionServiceAllFunctionsAstUnchanged':True,'reviewPurposeAndMaterialLimitsAndPublicSendGrantByteValuesUnchanged':True,'otherReviewReferences':need,'finalCompositionRequirement':'Root merges live+DM Bridge first, then recomputes transport CLI/source/connection/comment-purpose and dependency review pins from the actual composition. Never change purpose/material_limits or grant fields to bypass a mismatch. Regenerate ordinary freeze dependency manifest; test original account factory.','newDependencies':[]},ensure_ascii=False,indent=2),'utf-8')
print(json.dumps({'sourceFiles':len(rows),'otherPinReferenceFiles':len(need),'activeReviewSha256':review_sha}))
