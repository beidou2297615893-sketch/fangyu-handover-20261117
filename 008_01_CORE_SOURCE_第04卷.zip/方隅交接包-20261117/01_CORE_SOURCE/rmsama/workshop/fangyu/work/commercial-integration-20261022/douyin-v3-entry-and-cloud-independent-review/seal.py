from pathlib import Path
import datetime,hashlib,json
T=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_bytes());save=lambda p,v:p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n','utf-8')
assert not (T/'SEALED.json').exists()
static=read(T/'CLOUD-STATIC-AND-ZIP.json');extra=read(T/'CLOUD-EXTRA-RESULTS.json')
assert static['status']==extra['status']=='PASS'
F=T/'source-joint-v3/payload/factory-0c4d09d210ff40d5b1eda168abf5f7c4'
ui=read(F/'RESULTS.json');assert ui['allOwnServicesClosed'] is True
assert any(g['group'].startswith('v3-actual-original-http-check') for g in ui['groups'])
assert ui['status']=='RED' and "'task_id'" in read(F/'ERROR.json')['traceback']
assert read(T/'source-joint-v3/cloud-minimal2/ORIGINAL-CLOUD-BRIDGE-RESULTS.json')['status']=='STOPPED'
facts={'status':'CLOUD_REVIEW_PASS_UI_ENTRY_PASS_EXISTING_CORE_DEFECT_FOUND',
    'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'cloudSourceMergeable':True,'cloudHeldZipMergeableAsCodeCandidate':True,'cloudDeploymentVerified':False,
    'cloudIndependentChecks':{'exactSourceFiles':5,'archiveMembers':5617,'extraGroups':4,'extraActualServiceRequests':10,
        'oldEmployeeAndCommandHeldBytePreserved':True,'readonlySnapshotNeverRenewsOrMutates':True},
    'v3OriginalHttpButton':{'passed':True,'nicknameAndUidConfirmedInOwnVm':True,'snapshotReadable':True,
        'defaultExecutorHeld':True,'sourceFrozenRepresentative':True},
    'outerWorkerPassed':False,'defects':[{'source':'core/collection_query_provenance.py',
        'beforeSha256':'27c7bb6406103a7284f7b18aed03e74e12cdaf6735c594fc0d19c9099c370621',
        'reason':'Original legal imported comment can omit task_id; actual original outer worker reads comment, then commit/validation indexes missing field and pauses with KeyError.',
        'newRegression':False,'scope':'Original F82 helper, unchanged by v3/Dy six-source delta',
        'proposal':'Two lead.get(task_id) replacements; historical field kept as None; no task reassignment or permission widening.',
        'narrowOriginalStoreRedAndOwnProposedCopyGreen':'PROVENANCE-REPRO.json',
        'rootAcceptedFollowup':'Separate legacy-comment-provenance-fix-candidate, not part of cloud review.'}],
    'runtimeDependency':'shared-read-lease-qa-v3 fixed only; v4 helper/watchdog not covered here',
    'unverified':['Actual compiled main application','Natural Native/platform login and real reading speed','Actual cloud deployment/readback',
        'New-comment per-page AI and final combined v4','Second ordinary PC'],
    'productionWrites':0,'realPlatformModelRequests':0,'allOwnServicesClosed':True}
paths=['INPUTS.json','CLOUD-STATIC-AND-ZIP.json','CLOUD-EXTRA-RESULTS.json','REVIEW.md',
    'source-joint-v3/PROBE-INPUTS.json','source-joint-v3/SHARED-DEPENDENCY.json',
    'source-joint-v3/probe_entry-minimal2.py','source-joint-v3/cloud-minimal2/ORIGINAL-CLOUD-BRIDGE-RESULTS.json',
    'PROVENANCE-REPRO.json','PROPOSED-PROVENANCE.patch','proposed_collection_query_provenance.py',
    'review_cloud.py','cloud_extra.cjs','prepare.py','prepare_entry2.py','minimal_tail.py.in','provenance_repro.py']
artifacts=[T/p for p in paths]+[F/name for name in ('RESULTS.json','HTTP.json','ERROR.json','PROCESSES.json','ADMISSION-LOCKS.json','VM-EVIDENCE.json')]
facts['artifacts']=[{'path':p.relative_to(T).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)} for p in artifacts]
save(T/'FINAL-RECEIPT.json',facts)
save(T/'SEALED.json',{'status':'SEALED_STOP_WRITING','finalSha256':sha(T/'FINAL-RECEIPT.json'),
    'artifacts':facts['artifacts'],'allOwnServicesClosed':True})
print(json.dumps({'final':sha(T/'FINAL-RECEIPT.json'),'sealed':sha(T/'SEALED.json'),
    'cloud':'PASS5sources/5617archive/4extra10requests','v3HttpButton':'PASS','outerWorker':'RED existing missing-task-id',
    'allOwnServicesClosed':True}))
