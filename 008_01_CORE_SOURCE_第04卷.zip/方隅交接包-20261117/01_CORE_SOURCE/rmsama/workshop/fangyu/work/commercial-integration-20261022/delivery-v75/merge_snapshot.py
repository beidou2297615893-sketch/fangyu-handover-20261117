from pathlib import Path
import hashlib,json,os
W=Path(__file__).resolve().parents[1];D=Path(__file__).resolve().parent
S=W.parent/'parallel-integration-20261018/final-integration/stage-02/project'
sha=lambda b:hashlib.sha256(b).hexdigest()
rel='work/shared-backend-integration/platform_runtime.py'
before='d327eaca7b35afbd29b252a258004d2449aa1441586f11c6eb676f41933b45a2'
after='05001890f74b60a2183f0beb699cc1367e4a68f74935a1134c5740ec081195eb'
author=W/'platform-snapshot-held-analysis-candidate'
review=W/'platform-snapshot-held-analysis-independent-review/FINAL-RECEIPT.json'
assert sha(review.read_bytes())=='cd5a344ae8ea9d889f675e071779e1da46e53cff30718cb20ceec6d469d0832c'
assert sha((author/'FINAL-RECEIPT.json').read_bytes())=='66aaee719de8e81c9b856d311e59b9b6ed5c5fd0c18984264f914e9ebad490fa'
raw=(author/'project'/rel).read_bytes();assert sha(raw)==after
target=S/rel;assert sha(target.read_bytes())==before
backup=D/'source-before'/rel;backup.parent.mkdir(parents=True,exist_ok=True);assert not backup.exists()
backup.write_bytes(target.read_bytes())
temporary=target.with_name(target.name+'.v75-merge-tmp');assert not temporary.exists()
temporary.write_bytes(raw);os.replace(temporary,target)
assert sha(target.read_bytes())==after
result={'status':'SOURCE_ONLY_SNAPSHOT_MERGED_NOT_FROZEN_OR_INSTALLED','path':rel,'beforeSha256':before,'afterSha256':after,
        'independentReceiptSha256':sha(review.read_bytes()),'productionWritten':False,'canonicalWritten':False,'oldAnalysisExecutionGuardUnchanged':True}
(D/'MERGE-SNAPSHOT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result))
