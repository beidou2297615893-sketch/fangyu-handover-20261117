from pathlib import Path
import hashlib, json, subprocess, sys

D = Path(__file__).resolve().parent
P = D.parents[2]
N = P / 'work/ui-native-r57'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
plan = json.loads((D/'next-launch-prepared/candidate-unified-v79/CANONICAL-DELEGATION-PREPARED.json').read_text('utf-8'))
assert plan['release_id'] == 'ui-r57-20261023T054104Z-893b8383'
assert sha(N / 'run_workbench.py') == plan['launcher_sha256'].lower()
results = []
for action in ('--check', '--self-test'):
    process = subprocess.run([sys.executable, '-I', '-B', str(N / 'run_workbench.py'), action],
                             capture_output=True, timeout=120, encoding='utf-8', errors='replace')
    target = D / ('ACTUAL-ENTRY-' + action[2:].upper() + '.json')
    assert not target.exists()
    result = {'action': action, 'exitCode': process.returncode, 'stdout': process.stdout,
              'stderr': process.stderr, 'originalCanonicalEntry': True, 'nativeWindowRequested': False}
    target.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    assert process.returncode == 0, result
    results.append({'action': action, 'exitCode': process.returncode, 'evidenceSha256': sha(target)})
out = {'status': 'PASS_INSTALLED_ORIGINAL_CANONICAL_DIAGNOSTICS_NOT_NATIVE_FIRST_START',
       'checks': results, 'launcherSha256': sha(N / 'run_workbench.py'),
       'frozenSha256': sha(N / 'FROZEN.json'), 'bindingSha256': sha(N / 'state/production-workspace.json'),
       'oldWindowNotStoppedOrReplaced': True, 'noPlatformModelRequests': True}
(D / 'ACTUAL-ENTRY-DIAGNOSTICS.json').write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(out))
