from pathlib import Path
import hashlib,importlib.util,json,os,sys
sys.dont_write_bytecode=True
from final_inputs import load_verified
W=Path(__file__).resolve().parent;pins,F,S,stage,R=load_verified();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
root=json.loads(Path(json.loads((W/'ACTIVATION.json').read_text('utf-8'))['rootReceiptPath']).read_text('utf-8'))
assert sha(F/'UNIFIED-PINS.json')==root['unifiedPinsSha256']=='ad24e091a0a2be1fe1e30b9ea75fb20709e05d49e6b49f9b4a3b63298e62757f'
unified=json.loads((F/'UNIFIED-PINS.json').read_text('utf-8'));seen=set()
for row in unified['files']:
 p=S/row['path'];assert p.resolve().is_relative_to(S) and not p.is_symlink() and row['path'] not in seen
 seen.add(row['path']);assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],row['path']
assert {p.relative_to(S).as_posix() for p in S.rglob('*') if p.is_file()}==seen and len(seen)==root['fileCount']==3328
manifest=json.loads((R/'RELEASE.json').read_text('utf-8'));entry=next(x for x in manifest['files'] if x['path']=='ui_native_host.py')
raw=(R/'ui_native_host.py').read_bytes();assert len(raw)==entry['size'] and hashlib.sha256(raw).hexdigest()==entry['sha256'].lower()
host=importlib.util.module_from_spec(importlib.util.spec_from_loader('f80_readonly_closure',loader=None));host.__file__=str(R/'ui_native_host.py');exec(compile(raw,host.__file__,'exec'),host.__dict__)
_,files=host.verify_release(R,pins['manifestSha256']);source=host.verify_backend_dependencies(R,files,S)
assert len(files)==root['resourceCount']==282 and source==(S/'work/ui-runtime-r55/src')
company=json.loads((S/'work/app/company.json').read_text('utf-8-sig'));assert company['runtime']['public_send_hold'] is True and company['runtime']['release_approved'] is False and company['runtime']['xiaohongshu_automation']=='hold'
load_verified()
result={'status':'PASS_F80_ACTUAL_COMPLETE_CLOSURE','rootReceiptSha256':pins['rootReceiptSha256'],'sourceFiles':len(seen),'releaseFiles':len(files),'originalVerifyReleaseReadPublicAndDependencies':True,'cacheSourceGuardNotBypassed':True,'heldRuntimePreserved':True,'sourceWrites':False,'launcherInvoked':False,'productionAccess':False}
(W/'CLOSURE-RESULTS.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n','utf-8');print(json.dumps(result))
