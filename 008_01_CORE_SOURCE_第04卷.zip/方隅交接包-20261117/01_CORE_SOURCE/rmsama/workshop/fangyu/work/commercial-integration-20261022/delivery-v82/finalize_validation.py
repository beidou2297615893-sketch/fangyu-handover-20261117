"""Reuse the established fixed-closure/evidence acceptance for this merge."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json

D=Path(__file__).resolve().parent
W=D.parent
P=D.parents[2]
F=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v82'
S=F/'project'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text('utf-8-sig'))
assert sha(F/'UNIFIED-PINS.json')=='36a601743288689d6cff3159337ee4f548d1ee0d05366a28a83dd683a326f500'
assert sha(F/'STAGED.json')=='58581f4644aaf17bea481dd45d6ef19713bf6bdf97a303ffd790be940bb7c958'
pins=read(F/'UNIFIED-PINS.json')
stage=read(F/'STAGED.json')
assert len(pins['files'])==3856 and stage['files']==538
for row in pins['files']:
    path=S/row['path']
    assert sha(path)==row['sha256'] and path.stat().st_size==row['bytes'],row['path']
evidence=[]
def include(relative, expected=None):
    path=W/relative
    if expected:
        assert sha(path)==expected,relative
    evidence.append({'path':path.relative_to(W).as_posix(),'sha256':sha(path),'bytes':path.stat().st_size})

include('next-release-f81-expansion-composition/FROZEN-INPUTS.json','ea024e9a6742b81f62510a25f6c47c9bd48dcea70bc57c0481dfe6ee09ba636e')
include('next-release-f81-expansion-composition/REVIEW-GATES.json','24bc1b2e0b6df932e7b71588004593fd31e54156fb178e0f43bcbe150ac15ea7')
for row in read(W/'next-release-f81-expansion-composition/REVIEW-GATES.json')['reviews'].values():
    include(Path(row['final']).relative_to(W),row['finalSha256'])
    include(Path(row['seal']).relative_to(W),row['sealSha256'])
include('delivery-v82/BASELINE-VALIDATION.json')
include('expansion-f82-joint-regression/RESULTS.json')
base=read(W/'expansion-f82-joint-regression/RESULTS.json')
assert base['status']=='PASS_ACTUAL_BOUND_AGGREGATE'
assert all(base[k] for k in ('business47','account8','keywordWrapper11'))
include('expansion-f82-dm-live-joint-review/FINAL.json','181fd3a7b471742fe4eb16ef1c553c8002cfcfca5c882209eaea770d7f9cd546')
include('expansion-f82-dm-live-joint-review/SEALED.json','861b75d9d114ca8e43ef8ed61816d5f0966f1d30827f90a9cd4e18fcc1591df6')
dm=read(W/'expansion-f82-dm-live-joint-review/FINAL.json')
assert dm['totalGroups']==22 and dm['totalHttpRequests']==193
assert dm['activeAccountAndCommentPurposeActualResolve'] and dm['ownServicesClosed']
assert dm['fixedInputsBeforeAndAfterVerified'] and dm['platformModelCalls']==0 and not dm['productionDataRead']
include('expansion-f82-content-joint-validation/FINAL-RECEIPT.json','4def961de5e67e6305ba069d380f0f2bb215943d650c57f9e021d9f8f69e5eb3')
include('expansion-f82-content-joint-validation/SEALED.json','a691dcdad5ff7a618fb085b3ab01352018658e9dece7d3d56d6d6a820f6beb46')
content=read(W/'expansion-f82-content-joint-validation/FINAL-RECEIPT.json')
assert content['status']=='PASS_SCOPED_CONTENT_CHAIN' and content['factory']['groups']==21
assert content['factory']['httpLoggedWithBusinessResponses']==301 and content['ui']['checks']==37
assert content['ui']['zeroModuleRuntimeErrors'] and content['ui']['widths']==[1255,390]
assert not content['limits']['realUserDataAccess'] and content['limits']['realModels']==0
include('f82-standard-package-candidate/FINAL-RECEIPT.json','69d0b8946a3da256e4101cd3842c7fa8eb294843796518caaa63faffc83a377b')
include('f82-standard-package-candidate/SEALED.json','e770983443035f71ddbb05d8f07f60305d60a75d1cd1e425048f5fd5f5d676a5')
include('delivery-v81/AGGREGATE-VALIDATION.json','dac17dc83e3e3eecb847189cc3c108fea64ea27189e5ac59766c492046f0a702')
aggregate={'status':'PASS_FIXED_F82_LOCAL_COMBINED_RUNTIME_NOT_REAL_PLATFORM_OR_FULL_GOAL',
    'createdUtc':datetime.now(timezone.utc).isoformat(),'candidate':F.name,
    'sourceFilesVerified':len(pins['files']),'releaseResources':stage['files'],
    'originalBusinessGroups':47,'originalAccountGroups':8,'keywordWrapperGroups':11,
    'dmLiveJointFactoryGroups':22,'dmLiveJointHttpRequests':193,
    'contentJointFactoryGroups':21,'contentJointHttpResponses':301,'contentFullIndexUiChecks':37,
    'fullIndexWidths':[1255,390],'minimumEffectiveVisibleTextPx':14.45,
    'activeAccountAndCommentPurposeActualResolve':True,
    'sourceClosureVerifiedAfterAllJointTests':True,
    'referenceF81OtherFeatureAcceptance':'Unchanged media/OCR/PDF components retain original F81 evidence; old scan UI/compiled matrix not repeated in this merge',
    'productionAccess':False,'canonicalOrInstalledWritten':False,'realPlatformOrModelCalls':0,
    'newPublicSearchesInThisAcceptance':0,
    'ordinaryPackageIndependentReviewStillPending':True,
    'ordinaryHeldScopeStillHeld':True,'fullGoalComplete':False,
    'limits':['Human Native first-open, actual managed WebView registration and real platform operation remain unverified',
        'Ordinary compiled package keeps its existing held scope; account path fix does not grant internal or commercial use',
        'DM send/signature/delivery/history, live single/ten-room platform capacity and real publishing remain unverified',
        'ASR, full multi-role orchestration and other full-scope gaps remain; public source summaries are not fetched articles or verified store facts'],
    'evidence':evidence}
assert not (D/'AGGREGATE-VALIDATION.json').exists()
(D/'AGGREGATE-VALIDATION.json').write_text(json.dumps(aggregate,ensure_ascii=False,indent=2),'utf-8')
final={'rootExplicitFinalPins':True,'candidate':F.name,'unifiedPinsSha256':sha(F/'UNIFIED-PINS.json'),
    'stagedSha256':sha(F/'STAGED.json'),'manifestSha256':stage['manifest_sha256'],
    'releaseId':stage['release_id'],'unifiedFileCount':len(pins['files']),
    'releaseFileCount':stage['files'],'launcherSha256':sha(Path(stage['launcher'])),
    'validationSha256':sha(D/'AGGREGATE-VALIDATION.json')}
(D/'FINAL-PINS.json').write_text(json.dumps(final,ensure_ascii=False,indent=2),'utf-8')
(D/'ROOT-VALIDATION.json').write_text(json.dumps({'status':'PASS_F82_ACTUAL_COMBINED_VALIDATION',
    'compositionSha256':sha(W/'next-release-f81-expansion-composition/COMPOSITION.json'),
    'aggregateSha256':sha(D/'AGGREGATE-VALIDATION.json'),'finalPinsSha256':sha(D/'FINAL-PINS.json'),
    'nextLaunchOnly':True,'fullGoalComplete':False},indent=2),'utf-8')
print(json.dumps({'status':aggregate['status'],'validationSha256':sha(D/'AGGREGATE-VALIDATION.json'),
    'finalPinsSha256':sha(D/'FINAL-PINS.json')}))
