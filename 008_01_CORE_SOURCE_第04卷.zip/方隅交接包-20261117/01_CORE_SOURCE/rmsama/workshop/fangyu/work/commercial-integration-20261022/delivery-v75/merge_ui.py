from pathlib import Path
import difflib,hashlib,json,os
D=Path(__file__).resolve().parent;W=D.parent
S=W.parent/'parallel-integration-20261018/final-integration/stage-02/project'
sha=lambda b:hashlib.sha256(b).hexdigest()
fresh=W/'fresh-acquisition-recovery-candidate';nav=W/'diversified-acquisition-page-candidate'
assert sha((fresh/'FINAL-RECEIPT.json').read_bytes())=='cd304ec6a171b70bc5eee4d2ca0f5b08287c99dd9a57cefb936b7a6992e6e3f9'
assert sha((fresh/'SEALED.json').read_bytes())=='4466cf06680713e69650cad688c19e09b29a4a9d1b37a6578665d7c1989529fe'
assert sha((nav/'FINAL-RECEIPT.json').read_bytes())=='1acfdcc8171b0d3c8ceecd6d66076437fb9ff949566f3bbbae7cc98299549927'
assert sha((nav/'SEALED.json').read_bytes())=='1e5c934596cac11384c341e1cb9db4dbf24e212ac3f5774886b5571ff519501b'
navpins=json.loads((nav/'BASE-AND-CANDIDATE-PINS.json').read_text('utf-8'))['files']
freshpins=json.loads((fresh/'SOURCE-PINS.json').read_text('utf-8'))['files']
rows={}
for rel,r in navpins.items():
 raw=(nav/'candidate'/rel).read_bytes();assert sha(raw)==r['sha256']
 rows[rel]={'path':rel,'beforeSha256':r['beforeSha256'],'afterSha256':r['sha256'],'raw':raw,'origin':'sealed-diversified'}
app='work/ui-approved-implementation/ui-preview/app.mjs'
def groups(before,after):
 a,b=before.splitlines(keepends=True),after.splitlines(keepends=True)
 return [(b''.join(a[g[0][1]:g[-1][2]]),b''.join(b[g[0][3]:g[-1][4]])) for g in difflib.SequenceMatcher(a=a,b=b,autojunk=False).get_grouped_opcodes(3)]
proof={}
for r in freshpins:
 rel=r['path'];raw=(fresh/'candidate'/rel).read_bytes();assert sha(raw)==r['afterSha256']
 if rel not in rows:
  rows[rel]={'path':rel,'beforeSha256':r['beforeSha256'],'afterSha256':r['afterSha256'],'raw':raw,'origin':'sealed-fresh'};continue
 assert rel==app and rows[rel]['beforeSha256']==r['beforeSha256']
 base=(S/rel).read_bytes();assert sha(base)==r['beforeSha256']
 navraw=rows[rel]['raw'];patch=groups(base,raw);assert len(patch)==1 and b'async function startAcquisition' in patch[0][0]
 merged=navraw
 for old,new in patch:
  assert merged.count(old)==1;merged=merged.replace(old,new)
 undo=merged
 for old,new in reversed(patch):assert undo.count(new)==1;undo=undo.replace(new,old)
 assert undo==navraw
 undo=merged
 for old,new in reversed(groups(base,navraw)):assert undo.count(new)==1;undo=undo.replace(new,old)
 assert undo==raw
 rows[rel].update(raw=merged,afterSha256=sha(merged),origin='three-way-nav-plus-only-reviewed-start-function')
 proof={'appBothCandidatesByteExactAfterInverse':True,'freshHunks':len(patch),'navigationHunks':len(groups(base,navraw)),'CRLFPreserved':merged.count(b'\n')==merged.count(b'\r\n')}
assert len(rows)==8
assert not (D/'MERGE-UI.json').exists()
for rel,r in rows.items():
 target=S/rel
 if r['beforeSha256'] is None:assert not target.exists()
 else:assert sha(target.read_bytes())==r['beforeSha256']
for rel,r in rows.items():
 if r['beforeSha256'] is not None:
  backup=D/'source-before'/rel;backup.parent.mkdir(parents=True,exist_ok=True);assert not backup.exists();backup.write_bytes((S/rel).read_bytes())
changed=[]
try:
 for rel,r in rows.items():
  target=S/rel;target.parent.mkdir(parents=True,exist_ok=True);tmp=target.with_name(target.name+'.v75-merge-tmp');assert not tmp.exists()
  tmp.write_bytes(r['raw']);os.replace(tmp,target);changed.append(rel)
 for rel,r in rows.items():assert sha((S/rel).read_bytes())==r['afterSha256']
except BaseException:
 for rel in reversed(changed):
  target=S/rel
  if rows[rel]['beforeSha256'] is None:target.unlink()
  else:target.write_bytes((D/'source-before'/rel).read_bytes())
 raise
out={'status':'SOURCE_ONLY_UI_MERGED_NOT_INSTALLED','files':[{k:v for k,v in r.items() if k!='raw'} for r in rows.values()],
 'fileCount':len(rows),'proof':proof,'productionWritten':False,'canonicalWritten':False}
(D/'MERGE-UI.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in out.items() if k!='files'}))
