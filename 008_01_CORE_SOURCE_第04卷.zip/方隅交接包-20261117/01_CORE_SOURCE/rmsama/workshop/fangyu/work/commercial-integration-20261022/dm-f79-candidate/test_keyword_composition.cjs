const fs=require('fs'),path=require('path'),http=require('http'),assert=require('assert/strict'),crypto=require('crypto');
const {chromium}=require('C:/Users/rmsama/.codex/skills/xhs-note-creator/node_modules/playwright-core');
const O=__dirname,W=path.dirname(O),P=path.resolve(W,'../..');
const project=v=>v===79?path.join(O,'qa-only-project'):path.join(P,'work/parallel-integration-20261018/final-integration/candidate-unified-v'+v,'project');
const roots=Object.fromEntries([78,79].map(v=>{const stage=JSON.parse(fs.readFileSync(v===79?path.join(O,'QA-STAGE-PINS.json'):path.join(project(v),'../STAGED.json'),'utf8'));if(v===79)Object.assign(stage,stage.stage);return [v,path.join(stage.release,'web')];}));
let browser,server;const checks=[],errors=[],external=[];
const sha=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
(async()=>{
 server=http.createServer((req,res)=>{const url=new URL(req.url,'http://localhost');if(url.pathname==='/'){res.setHeader('Content-Type','text/html');res.end('<!doctype html><html><body><main id="root"></main><dialog id="modal"></dialog></body></html>');return;}
  const match=url.pathname.match(/^\/v(78|79)\/(.*)$/);if(!match){res.writeHead(404);res.end();return;}
  const root=roots[match[1]],file=path.resolve(root,decodeURIComponent(match[2]));if(!file.startsWith(path.resolve(root)+path.sep)||!fs.existsSync(file)||!fs.statSync(file).isFile()){res.writeHead(404);res.end();return;}
  res.setHeader('Content-Type',file.endsWith('.mjs')?'text/javascript':file.endsWith('.svg')?'image/svg+xml':'application/octet-stream');res.end(fs.readFileSync(file));
 });await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const origin='http://127.0.0.1:'+server.address().port;
 browser=await chromium.launch({executablePath:'C:/Users/rmsama/AppData/Local/ms-playwright/chromium_headless_shell-1234/chrome-headless-shell-win64/chrome-headless-shell.exe',headless:true});
 const page=await browser.newPage({viewport:{width:1255,height:1000}});page.on('pageerror',e=>errors.push(e.message));
 await page.route('**/*',r=>{if(r.request().url().startsWith(origin+'/'))return r.continue();external.push(r.request().url());return r.abort();});
 await page.goto(origin+'/');
 await page.evaluate(async()=>{
  const modules={78:await import('/v78/pages/diversified-acquisition.mjs'),79:await import('/v79/pages/diversified-acquisition.mjs')};
  const clone=v=>structuredClone(v);
  const sample=()=>({connection:'connected',session:{user:{tenant_id:'own-synthetic-tenant',role:'operator'}},user:'own-synthetic-user',storeId:'own-store',store:'合成门店',page:'acquire',authEpoch:2,activePlatform:'xiaohongshu',stores:[{id:'own-store',name:'合成门店',city:'上海',region:'',area:''}],selection:{revision:3,applied:{selectedKeywords:['合成短租'],excludeTerms:[]}},acquire:{selectedPlatform:'xiaohongshu',region:'',time:'最近30天'},platformAccountSelections:{xiaohongshu:'new-account'},platform:{actor:{username:'own-synthetic-user',storeId:'own-store'},device:{bound:true,state:'online'},capabilities:{collection:false,timeRanges:['最近30天']},platforms:[{id:'xiaohongshu',enabled:true,accountId:'old-account'}],accounts:[{id:'old-account',platform:'xiaohongshu',status:'ready',name:'原合成账号',collectionReady:false},{id:'new-account',platform:'xiaohongshu',status:'ready',name:'新合成账号',collectionReady:true}],lastRequest:{state:'accepted',requestId:'original-accepted-key',job:{taskId:'old-task'}},acquisition:{taskId:'old-task',taskScope:{storeId:'own-store',platform:'xiaohongshu',accountId:'old-account'},status:'paused',canPause:false,canStart:false,canResume:false,reasonCode:'account_review_required',analysis:{hold:true}}}});
  let cleanup,state,events,options;
  window.setup=(version,kind='fresh')=>{
   cleanup?.();state=sample();events={starts:[],resumes:[],verifies:[],toasts:[]};options=null;
   if(kind==='unknown'){state.platform.lastRequest.state='unconfirmed';state.acquisitionAttempt={unconfirmed:true,payload:{requestId:'original-accepted-key'}};}
   if(kind==='normal'){state.platform.capabilities.collection=true;state.platform.acquisition={status:'idle',canStart:true,canPause:false,canResume:false};state.platform.lastRequest={state:'not_started',requestId:''};}
   if(kind==='running')state.platform.acquisition.status='running';
   if(kind==='same-held')state.platformAccountSelections.xiaohongshu='old-account';
   if(kind==='foreign')state.platform.actor.storeId='other-store';
   if(kind==='resume'){
    state.platform.capabilities.collection=true;
    const today=new Date(Date.now()+8*3600000).toISOString().slice(0,10),from=new Date(Date.parse(today+'T00:00:00Z')-29*86400000).toISOString().slice(0,10);
    Object.assign(state.platform.lastRequest,{conditions:{expectedRevision:3},keywordBatch:['合成短租']});
    state.platform.acquisition={taskId:'old-task',status:'paused',canPause:false,canStart:false,canResume:true,taskScope:{storeId:'own-store',platform:'xiaohongshu',accountId:'new-account',scope:'search_comments',commentKeywordMode:'all',continuousEnabled:false,region:'',unknownPolicy:'exclude',city:'上海',area:'',commentDateRange:'all',intentMode:'all',excludes:[],dailyLimit:1000,targetCount:1000,dateFrom:from,dateTo:today,keywords:['合成短租']}};
   }
   const root=document.getElementById('root'),dialog=document.getElementById('modal');dialog.innerHTML='';if(dialog.open)dialog.close();
   const ctx={state,toast:t=>events.toasts.push(t),update:fn=>fn(state),navigate:()=>{},actions:{hasUnconfirmed:()=>false,startAcquisition:async data=>(events.starts.push(clone(data)),true),resumeAcquisition:id=>events.resumes.push(id),verifyAcquisition:()=>events.verifies.push(state.acquisitionAttempt?.payload?.requestId||state.platform.lastRequest.requestId)}};
   ctx.modal=o=>{options=o;dialog.innerHTML='<h2></h2><section></section><button id="confirm">确认</button>';dialog.querySelector('h2').textContent=o.title;dialog.querySelector('section').innerHTML=o.html;dialog.querySelector('#confirm').onclick=async()=>{const result=await o.onConfirm?.();if(result!==false&&dialog.open)dialog.close();};dialog.showModal();return dialog;};
   root.innerHTML=modules[version].keywordPage.render(state);cleanup=modules[version].keywordPage.bind(root,ctx);
   return {disabled:root.querySelector('[data-acquire-start]').disabled,label:root.querySelector('[data-acquire-start]').textContent,original:clone(state.platform.lastRequest)};
  };
  window.info=()=>({events:clone(events),title:options?.title||'',open:document.getElementById('modal').open,last:clone(state.platform.lastRequest),state:clone(state)});
  window.drift=kind=>{if(kind==='account')state.platformAccountSelections.xiaohongshu='old-account';if(kind==='store')state.storeId='other-store';if(kind==='request')state.platform.lastRequest.requestId='changed-key';};
  window.finish=()=>cleanup?.();
 });
 const click=async()=>{await page.locator('[data-acquire-start]').click();return page.evaluate(()=>info());};
 let setup=await page.evaluate(()=>window.setup(78));assert.equal(setup.disabled,false);let r=await click();assert.equal(r.title,'');assert.equal(r.events.starts.length,0);checks.push({name:'Exact F78 wrapper baseline reproduces enabled-click red',result:r.events,expectedRed:true});
 setup=await page.evaluate(()=>window.setup(79));assert.equal(setup.disabled,false);assert(setup.label.includes('使用当前账号获客'));r=await click();assert.equal(r.title,'切换执行账号，新建采集');assert.equal(r.events.starts.length,0);
 await page.locator('#confirm').click();r=await page.evaluate(()=>info());assert.equal(r.events.starts.length,0);assert.equal(r.open,true);
 await page.locator('[data-fresh-ack]').check();await page.locator('#confirm').click();r=await page.evaluate(()=>info());assert.equal(r.events.starts.length,1);assert.equal(r.events.starts[0].fresh.account.id,'new-account');assert.equal(r.events.starts[0].fresh.old.taskId,'old-task');assert.equal(r.last.requestId,'original-accepted-key');assert.equal(r.events.resumes.length,0);checks.push({name:'F79 actual wrapper delegates strictly eligible fresh, acknowledgement required, original key/task retained',events:r.events});
 for(const kind of ['account','store','request']){
  await page.evaluate(()=>window.setup(79));await click();await page.locator('[data-fresh-ack]').check();await page.evaluate(k=>drift(k),kind);await page.locator('#confirm').click();r=await page.evaluate(()=>info());assert.equal(r.events.starts.length,0);assert.equal(r.events.resumes.length,0);assert.equal(r.open,true);assert(r.events.toasts.some(t=>t.includes('已变化')));checks.push({name:'Fresh modal '+kind+' drift rejects without dispatch',events:r.events});
 }
 await page.evaluate(()=>window.setup(79,'unknown'));r=await click();assert.equal(r.title,'');assert.deepEqual(r.events.verifies,['original-accepted-key']);assert.equal(r.events.starts.length,0);assert.equal(r.events.resumes.length,0);assert.equal(r.last.requestId,'original-accepted-key');checks.push({name:'Unknown passes to original verification only, same request key',events:r.events});
 await page.evaluate(()=>window.setup(79,'normal'));r=await click();assert.equal(r.title,'确认使用关键词获客');assert.equal(r.events.starts.length,0);await page.locator('#confirm').click();r=await page.evaluate(()=>info());assert.deepEqual(r.events.starts,[{sourceKind:'keywords'}]);checks.push({name:'Ordinary keywords remain wrapper-confirmed and dispatch once',events:r.events});
 setup=await page.evaluate(()=>window.setup(79,'resume'));assert.equal(setup.disabled,false);r=await click();assert.deepEqual(r.events.resumes,['old-task']);assert.equal(r.events.starts.length,0);assert.equal(r.title,'');checks.push({name:'Matching original paused task resumes original id with zero new start',events:r.events});
 for(const kind of ['running','same-held','foreign']){setup=await page.evaluate(k=>window.setup(79,k),kind);assert.equal(setup.disabled,true,kind);r=await page.evaluate(()=>info());assert.equal(r.events.starts.length,0);assert.equal(r.title,'');checks.push({name:kind+' is still disabled with no fresh modal/start'});}
 await page.evaluate(()=>finish());assert.deepEqual(errors,[]);assert.deepEqual(external,[]);
 const result={status:'PASS_F79_REAL_KEYWORD_WRAPPER_COMPOSITION',checks,groups:checks.length,pageErrors:errors,externalRequests:external,headlessChromium:true,actualFrozenReleaseModules:true,releaseModuleSha256:sha(path.join(roots[79],'pages/diversified-acquisition.mjs')),baselineModuleSha256:sha(path.join(roots[78],'pages/diversified-acquisition.mjs')),layer:'Actual keywordPage.render+bind and original acquire/fresh modules with real Chromium capture/bubble/click; synthetic local state and action callbacks. Not full app/Native/factory/platform validation.',modelOrPlatformCalls:0,productionAccess:false};
 fs.writeFileSync(path.join(O,'KEYWORD-COMPOSITION-RESULTS.json'),JSON.stringify(result,null,2));console.log(JSON.stringify({status:result.status,groups:result.groups}));
})().catch(e=>{fs.writeFileSync(path.join(O,'KEYWORD-COMPOSITION-FAILURE.json'),JSON.stringify({error:e.stack,checks,pageErrors:errors,externalRequests:external},null,2));console.error(e);process.exitCode=1;}).finally(async()=>{await browser?.close();if(server)await new Promise(r=>server.close(r));});
