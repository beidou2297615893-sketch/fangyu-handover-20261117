from pathlib import Path
W=Path(__file__).resolve().parent;C=W.parent/'dm-f79-candidate'
src=(C/'test_factory_f79_regression.py').read_text('utf-8-sig')
head=src[:src.index('try:\n _,boot,')]
head=head.replace("S=W/'qa-only-project'", "S=W.parent/'dm-f79-candidate'/'qa-only-project'")
head=head.replace("stage_paths=sorted((S/'work/ui-native-r57/candidates').glob('*.json'));stage=json.loads(stage_paths[-1].read_text('utf-8-sig'));R=Path(stage['release'])", "stage=json.loads((W/'INPUTS.json').read_text('utf-8'))['stage'];R=Path(stage['release'])")
head=head.replace("checks=[];reply_permission", "checks=[];findings=[];reply_permission")
setup=src[src.index(' _,boot,'):src.index(" assert read(account)['conversations']")]
tail=r'''
 def settle_listener(a):
  for _ in range(250):
   value=read(a)
   if value['listeners'] and value['listeners'][-1]['state']!='listening':return value
   time.sleep(.02)
  raise AssertionError('listener did not settle')
 def deletion(a,key):return {'storeId':store,'accountId':a['id'],'platform':a['platform'],'expectedNickname':a.get('platform_nickname') or a.get('name',''),'confirmed':True,'requestId':key}
 def capture():
  return {name:deepcopy(core.store.list(name,user['tenant_id'])) for name in ['ui_dm_conversations_v1','ui_dm_messages_v1','ui_dm_drafts_v1','ui_dm_queues_v1','ui_dm_requests_v1','leads','replies','reply_customer_claims_v1']}
 assert read(account)['conversations']['total']==0 and not wire
 mutate('dm_listen_start',{'accountId':account['id'],'confirmed':True,'timeoutMs':100})
 convs=settle_listener(account)['conversations']['items'];assert len(convs)==4 and len(wire)==1
 d=draft(account,convs[0],'独审合成默认hold草稿');q=prepare(account,[d]);before=len(wire);start(q);held=wait_queue(q['id'])
 assert held['state']=='blocked' and len(wire)==before
 foreign={**account,'id':'review-foreign-owner','cloud_owner':'different-employee','platform_uid':'9007199254741777'};core.store.put('accounts',foreign)
 dm('dm_workspace_read',{'accountId':foreign['id']},403)
 wrong_store=next(s['id'] for s in cloud.manifest['stores'] if s['id']!=store)
 action('dm_workspace_read',{'accountId':account['id'],'storeId':wrong_store},403)
 reply_permission[0]=False;dm('dm_workspace_read',{'accountId':account['id']},403);reply_permission[0]=True
 detail=read(account,conversationId=convs[0]['id']);assert detail['capabilities']['historyAvailable'] is False and detail['messages']['total']==2 and len(wire)==before
 checks.append({'group':'G1_default_hold_scope_saved_history','result':'PASS','held':held,'wireDeltaSend':0,'ownerStorePermissionRejected':True,'savedHistoryOnly':True})
 save('PROGRESS.json',{'checks':checks,'findings':findings})

 # Only temporary configuration in our own factory is enabled for an original
 # device/executor lease and the loopback Bridge. Never changes sealed inputs.
 for config_value in (runtime.server.company,core.deployment_config):
  flags=config_value['runtime'];flags['public_send_hold']=False;flags['public_reply_hold']=False;flags['public_replies']='enabled';flags.pop('platform_qa_device_id',None)
 executor=BusinessExecutor(runtime.server,company['managedWorkspace']['environment_id'],company['id'],user['username']);runtime.service.executor=executor
 executor.account_claim=runtime.service._claim_xhs_account;bind_executor_session(runtime.service,executor,saved)
 manifest_path=core.store.directory/'adapters/douyin.json';manifest=json.loads(manifest_path.read_text('utf-8'));manifest['dm_contract_verified']=True;manifest_path.write_text(json.dumps(manifest),'utf-8')
 send_state[0]='unknown';d1=draft(account,convs[1],'独审未知回执原请求');d2=draft(account,convs[2],'独审后续不得发送');q=prepare(account,[d1,d2]);key='review-fixed-original-unknown-key';before=len(wire);start(q,key);unknown=wait_queue(q['id'])
 assert unknown['state']=='unknown' and unknown['items'][1]['state']=='pending' and len(wire)==before+1
 frozen_unknown=deepcopy(core.store.get('ui_dm_drafts_v1',d1['id']));frozen_queue=deepcopy(core.store.get('ui_dm_queues_v1',q['id']));wire_unknown=len(wire)
 assert start(q,key)['state']=='unknown';mutate('dm_queue_start',{'id':q['id'],'snapshotDigest':q['snapshotDigest'],'confirmed':True},409,key='review-new-key-cannot-retry')
 assert dm('dm_request_read',{'action':'dm_queue_start','requestId':key})['state']=='unknown'
 mutate('dm_listen_start',{'accountId':other['id'],'confirmed':True,'timeoutMs':100});other_convs=settle_listener(other)['conversations']['items']
 target=next(c for c in other_convs if c['recipientUid']==convs[1]['recipientUid']);od=draft(other,target,'独审跨账号同客户不得重发');oq=prepare(other,[od]);before=len(wire);start(oq);cross=wait_queue(oq['id'])
 assert cross['state']=='blocked' and len(wire)==before and core.store.get('ui_dm_drafts_v1',d1['id'])==frozen_unknown
 checks.append({'group':'G2_unknown_original_key_cross_account_claim','result':'PASS','originalKey':key,'oneSendOnly':sum(x['operation']=='send' for x in wire)==1,'secondItemPending':True,'originalUnknownUnchanged':True,'crossAccountQueue':cross})
 save('PROGRESS.json',{'checks':checks,'findings':findings})

 from assistant.customer_list import _person
 task={'id':'review-original-comment-task','tenant_id':user['tenant_id'],'cloud_owner':user['username'],'store_id':store,'platform':'douyin','account_id':other['id'],'status':'completed','cursor':{'page':7}}
 lead={'id':'review-original-comment','tenant_id':user['tenant_id'],'cloud_owner':user['username'],'store_id':store,'task_id':task['id'],'platform':'douyin','author_id':'9007199254741888','comment_id':'review-comment-stable-id','text':'原始合成评论','note_url':'https://www.douyin.com/video/1234567890123456789','created_at':'2026-10-23T04:40:00Z'}
 core.store.put('tasks',task);core.store.put('leads',lead)
 digest=lambda r:hashlib.sha256(json.dumps(r,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
 cd=mutate('dm_draft_save',{'accountId':other['id'],'expectedVersion':0,'target':{'customerId':_person(lead)[0],'leadId':lead['id'],'sourceDigest':digest(lead)},'text':'独审原评论私信草稿'})
 assert cd['source']['recipientUid']==lead['author_id']
 revised={**lead,'text':'合成原评论已修改'};core.store.put('leads',revised);before=len(wire)
 mutate('dm_draft_review',{'accountId':other['id'],'id':cd['id'],'expectedVersion':cd['version'],'confirmed':True},409)
 assert core.store.get('leads',lead['id'])==revised and core.store.get('tasks',task['id'])==task and len(wire)==before
 slow_listen[0]=True;stop_received.clear();before=len(wire);ls=mutate('dm_listen_start',{'accountId':other['id'],'confirmed':True,'timeoutMs':20000})
 for _ in range(250):
  if len(wire)>before:break
  time.sleep(.02)
 assert len(wire)>before
 old_account=deepcopy(core.store.get('accounts',other['id']));payload=deletion(other,'review-delete-active-listener')
 denied,_=action('account_delete',payload,409);assert denied['error']['code']=='ACCOUNT_BUSY' and core.store.get('accounts',other['id'])==old_account
 assert action('account_delete_request',{'storeId':store,'requestId':payload['requestId']})[0]['accountDeletion']['state']=='not_started'
 stopped=dm('dm_listen_stop',{'id':ls['id']});slow_listen[0]=False;assert stopped['state']=='stopped'
 assert core.store.get('leads',lead['id'])==revised and core.store.get('tasks',task['id'])==task and core.store.get('ui_dm_drafts_v1',d1['id'])==frozen_unknown
 checks.append({'group':'G3_comment_source_CAS_listener_delete_mutex','result':'PASS','originalCommentStableIdPreserved':True,'sourceChangeRejected':True,'activeListenerDeleteRejected':True,'explicitStop':stopped})
 save('PROGRESS.json',{'checks':checks,'findings':findings})

 # Close the actual first factory and start another through the same original
 # verified constructor. Old data, no copied author state, no __new__/sys.path.
 server.shutdown();st.join(3);server.server_close();backend.close()
 backend=host.create_backend(R,files,project_root=S,data_dir=OUT/'data',company=company);runtime=backend.platform_runtime;core=backend.core
 server=host.StaticServer(R,files,backend=backend,cookie_name='dm_fixture_session');st=threading.Thread(target=server.serve_forever,daemon=True);st.start();origin='http://127.0.0.1:'+str(server.server_port);headers={}
 _,boot,_=request('GET','/api/workbench/bootstrap');headers.update({'Content-Type':'application/json','Origin':origin,'X-Fangyu-CSRF':boot['csrfToken']})
 _,logged,h=request('POST','/api/workbench',{'action':'login','data':{'username':'fixture-admin','password':fixture.PASSWORD}});headers['Cookie']=h['Set-Cookie'].split(';',1)[0];headers['X-Fangyu-CSRF']=logged['csrfToken']
 if logged['selection']['storeId']!=store:action('select_store',{'storeId':store,'expectedRevision':logged['selection']['revision']})
 user={**core.session(headers['Cookie'].split('=',1)[1]),'_workbench_store_id':store}
 before=len(wire);recovered=dm('dm_request_read',{'action':'dm_queue_start','requestId':key});assert recovered['state']=='unknown' and len(wire)==before and core.store.get('ui_dm_drafts_v1',d1['id'])==frozen_unknown and core.store.get('ui_dm_queues_v1',q['id'])==frozen_queue
 checks.append({'group':'G4_actual_factory_reopen_unknown_then_account_delete','reopenOriginalKey':'PASS','reopenWireDelta':0})
 # Test original public account deletion, recording status rather than assuming
 # a lock policy. The account is synthetic; no platform deletion takes place.
 runtime.server._configure_bundled();runtime._platform_setup=True
 executor=BusinessExecutor(runtime.server,company['managedWorkspace']['environment_id'],company['id'],user['username']);runtime.service.executor=executor
 runtime.service.vault=SimpleNamespace(read=lambda:deepcopy(saved));runtime.service.device=deepcopy(saved['device']);runtime.service.state='online';runtime.service._cloud=lambda:DeviceCloud()
 executor.account_claim=runtime.service._claim_xhs_account;bind_executor_session(runtime.service,executor,saved)
 before_rows=capture();before=len(wire);delete_payload=deletion(account,'review-delete-durable-unknown');code,body,_=request('POST','/api/workbench',{'action':'account_delete','data':delete_payload})
 assert len(wire)==before
 rc,rb,_=request('POST','/api/workbench',{'action':'dm_request_read','data':{'storeId':store,'action':'dm_queue_start','requestId':key}})
 after_rows=capture();assert before_rows==after_rows and core.store.get('ui_dm_drafts_v1',d1['id'])==frozen_unknown
 deletion_evidence={'deleteStatus':code,'deleteBody':body,'requestReadStatus':rc,'requestReadBody':rb,'originalRequestKey':key,'wireDelta':len(wire)-before,'allCapturedDmAndCustomerRowsUnchanged':before_rows==after_rows,'beforeRows':before_rows,'afterRows':after_rows}
 save('UNKNOWN-ACCOUNT-DELETE.json',deletion_evidence)
 if code==200 and body.get('accountDeletion',{}).get('state')=='deleted' and rc==403:
  findings.append({'id':'DM_UNKNOWN_ACCOUNT_DELETE_RECOVERY','severity':'P1','title':'Deleting an account with a durable unknown DM makes its original request inaccessible','evidence':'UNKNOWN-ACCOUNT-DELETE.json','facts':['Original unknown request was readable after actual factory reopen with zero wire','Original account_delete returned deleted','Original dm_request_read for the same key then returned403','DM records and original customer claim remain durable; zero redispatch observed'],'notClaimed':'No duplicate send, cross-account claim bypass or real platform exploit demonstrated'})
  checks[-1]['result']='RED_RECOVERY_GAP'
 else:checks[-1]['result']='OBSERVED';checks[-1]['deleteAndRead']=deletion_evidence
 assert not blocked
 save('RESULTS.json',{'status':'RED_PRODUCT_GAP' if findings else 'PASS_REPRESENTATIVE','checks':checks,'findings':findings,'factory':'original verify_release + verify_backend_dependencies + read_public + create_backend','explicitQAOnly':True,'realPlatformModelCalls':0,'positiveSendDestination':'owned loopback Bridge only','defaultSourceHoldsUnchanged':True,'allWire':wire,'httpRequests':len(events)})
 passed=True
except BaseException:
 import traceback
 save('EXCEPTION.json',{'traceback':traceback.format_exc(),'checks':checks,'findings':findings,'wire':wire,'httpRequests':len(events)})
 raise
finally:
 try:server.shutdown();st.join(3);server.server_close()
 finally:
  try:backend.close()
  finally:bridge.shutdown();bt.join(3);bridge.server_close()
 save('FINAL.json',{'status':('RED_PRODUCT_GAP' if findings else 'PASS_REPRESENTATIVE') if passed else 'RED_FIXTURE_OR_PRODUCT_EXCEPTION','checks':checks,'findings':findings,'blocked':blocked,'wire':wire,'processes':processes,'allOwnServersClosed':not st.is_alive() and not bt.is_alive()})
 print(str(OUT),flush=True)
'''
(W/'test_independent_factory.py').write_text(head+'try:\n'+setup+tail,'utf-8')
print(W/'test_independent_factory.py')
