from pathlib import Path
import ast,hashlib,json
D=Path(__file__).resolve().parent;old=D.parent/'delivery-v78';W=D/'ui-recovery-validation';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
b=json.loads((W/'UI-ORIGINAL-RECORDS.json').read_text('utf-8'));a=json.loads((W/'UI-AFTER-RECORDS.json').read_text('utf-8'));key=lambda r:(r['entity'],r['id'],r['tenant_id']);bm={key(r):r for r in b};am={key(r):r for r in a}
removed=set(bm)-set(am);added=set(am)-set(bm);changed={k for k in bm.keys()&am.keys() if bm[k]!=am[k]}
assert len(removed)==1 and next(iter(removed))[:2]==('accounts','diverse-fixture-account-0')
assert {k[0] for k in added}=={'workbench_account_deletion_v1','audit'} and len(added)==2
assert {k[0] for k in changed}<={'tasks','workbench_selection_v1','ui_workbench_preferences_v1','users'},changed
for k in changed:
 if k[0]=='tasks':
  before=json.loads(bm[k]['body']);after=json.loads(am[k]['body']);assert before['cursor']==after['cursor'] and before['store_id']==after['store_id'] and before['cloud_owner']==after['cloud_owner'];assert after['account_id']=='' and after['account_removed'] is True
assert all(bm[k]==am[k] for k in bm if k[0]=='accounts' and k not in removed)
(W/'DELETE-INVARIANTS.json').write_text(json.dumps({'status':'PASS_EXPECTED_SYNTHETIC_ACCOUNT_DELETION_ONLY','removedSyntheticAccounts':1,'changedEntities':sorted({k[0] for k in changed}),'addedEntities':sorted({k[0] for k in added}),'oldTaskCursorStoreOwnerPreserved':True,'otherAccountsByteIdentical':True,'productionAccess':False,'originalRawRecordsChangedResultRetained':True},indent=2),'utf-8')
source=old/'install_verified_entry.py';assert sha(source)=='a076624810c68b32183a9c6afcda63eb425eec7686eed9ecae0b57a28c71b851'
text=source.read_text('utf-8');anchor="    expected = P / 'work/commercial-integration-20261022/delivery-v78'";assert text.count(anchor)==1;text=text.replace(anchor,anchor.replace('v78','v79')).replace('Requires final immutable78 acceptance.','Requires final immutable79 acceptance.')
functions=lambda s:{n.name:ast.dump(n,include_attributes=False) for n in ast.parse(s).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
before,after=functions(source.read_text('utf-8')),functions(text);assert {k for k in before if before[k]!=after[k]}=={'main'}
target=D/'install_verified_entry.py';assert not target.exists();target.write_text(text,'utf-8')
receipt={'sourceDraftSha256':sha(source),'draftSha256':sha(target),'onlyFunctionChange':'main exact delivery folder','acceptedEmpty':True,'installationReviewed':False,'canonicalWritten':False}
(D/'NEXT-ENTRY-DRAFT.json').write_text(json.dumps(receipt,indent=2),'utf-8')
capture=D.parent/'delivery-v77/capture_business_readonly.py';assert sha(capture)=='d9d486ecea49a649f20c5ba682b7a5e99d087de0f6f1665b4548d47ad8aa9be6';(D/capture.name).write_bytes(capture.read_bytes());print(json.dumps(receipt))
