from pathlib import Path
import hashlib, json
C=Path(__file__).resolve().parent
A=C.parent/'media-f79-pathguard-candidate'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
final='86ad9c1882b8c8b74b743d4b6df70e9588b40171dbcdaf159a66b7a8b3552698'
seal='dcf7d52576cb039318b2b28e71adf8184b4a8d4280cb77c7edf4cfda000de029'
manifest='c1f5a4885707431b1b4bf58413b061dc0772448b6a1d4116df3f60e1f83714a6'
for name,pin in [('FINAL-RECEIPT.json',final),('SEALED.json',seal),('SOURCE-FILES.json',manifest)]:
    assert sha(A/name)==pin
target=C/'assemble.py';text=target.read_text('utf-8')
before="'directory':'media-f79-candidate','final':'5ac9faa51d7132557f62aabe9e93d11f10b806a3204c0d060dd67f44a74bbdc4','seal':'0cbae483b2daa2d623c782ec4166af1c7418be007ca1bfb22915565dccf2e46b','manifest':'SOURCE-FILES.json','manifestSha':'62418cd5c18f70b38d51c9bb7085bda95394bfc42b6b0986b6446623b48ee0f1'"
after=f"'directory':'media-f79-pathguard-candidate','final':'{final}','seal':'{seal}','manifest':'SOURCE-FILES.json','manifestSha':'{manifest}'"
assert text.count(before)==1
target.write_text(text.replace(before,after),'utf-8')
target=C/'resolve_media_backend.py';text=target.read_text('utf-8')
assert text.count('media-f79-candidate/source-candidate')==1
target.write_text(text.replace('media-f79-candidate/source-candidate','media-f79-pathguard-candidate/source-candidate'),'utf-8')
print('Pinned fixed media full11; prior red draft untouched.')
