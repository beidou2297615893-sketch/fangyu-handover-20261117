from pathlib import Path
import hashlib, json
C=Path(__file__).resolve().parent
old=C.parent/'expansion-f79-integration'
text=(old/'assemble.py').read_text('utf-8')
anchor=" 'schedule':{'directory'"
assert text.count(anchor)==1
new=" 'dm-retirement':{'directory':'dm-f79-retirement-candidate','final':'e650ab25e09967fb068acc18465cd8ee53a64cd906b8859f1aa99d85f02c646c','seal':'19a6c409d57eeaaa301b281bf8b11657e18ee1f957d81001dcb160e9496ca56c','manifest':'SOURCE-PINS.json','manifestSha':'f8cda5b056e23393c300422d339503d79f2f6ceb1ef7fab56822fac238b68848','folder':'final-source','baseFolder':'dm-f79-candidate/final-source'},\n"
text=text.replace(anchor,new+anchor)
anchor="base=F/'project'/relative;target=S/relative;incoming=source/config['folder']/relative"
assert text.count(anchor)==1
text=text.replace(anchor,"base=(W/config['baseFolder']/relative) if config.get('baseFolder') else F/'project'/relative;target=S/relative;incoming=source/config['folder']/relative")
(C/'assemble.py').write_text(text,'utf-8')
for name in ('resolve_schedule_backend.py','resolve_media_backend.py'):
    (C/name).write_bytes((old/name).read_bytes())
print('Prepared new independent composer; no source files assembled yet.')
