from pathlib import Path
import hashlib,json,subprocess,uuid
W=Path(__file__).resolve().parent;P=W.parents[2];A=W.parent/'dm-controlled-transport-f81-candidate';F=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v81/project';R=W/('independent-patch-replay-'+uuid.uuid4().hex);R.mkdir()
rows=json.loads((A/'SOURCE-FILES.json').read_text('utf-8'))['files']
old=W/'independent-patch-replay'
if old.exists():
 red=[{'path':r['path'],'actualSha256':hashlib.sha256((old/r['path']).read_bytes()).hexdigest(),'expectedSha256':r['after']['sha256'],'lfNormalizedEqual':(old/r['path']).read_bytes().replace(b'\r\n',b'\n')==(W/'qa-only-project'/r['path']).read_bytes().replace(b'\r\n',b'\n')} for r in rows if hashlib.sha256((old/r['path']).read_bytes()).hexdigest()!=r['after']['sha256']]
 (W/'PATCH-FIXTURE-RED.json').write_text(json.dumps({'reason':'Initial patch fixture did not pin Git line-ending configuration. Retained replay bytes; corrected fixture explicitly uses byte-preserving no-index configuration. No product edits.','mismatches':red},ensure_ascii=False,indent=2),'utf-8')
for row in rows:
 if not row['before']:continue
 dest=R/row['path'];dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes((F/row['path']).read_bytes())
for check in (True,False):
 cmd=['git','-c','core.autocrlf=false','-c','core.safecrlf=false','apply','--no-index','--whitespace=nowarn',*(['--check'] if check else []),str(A/'SOURCE.patch')];run=subprocess.run(cmd,cwd=R,capture_output=True);assert run.returncode==0,run.stderr
for row in rows:assert hashlib.sha256((R/row['path']).read_bytes()).hexdigest()==row['after']['sha256']
(W/'PATCH-REPLAY.json').write_text(json.dumps({'status':'PASS','gitApplyCheckAndApplyExit0':True,'all10AfterBytesExact':True,'ownReplayOnly':str(R)},ensure_ascii=False,indent=2),'utf-8');print('PASS: exact independent Git patch replay for all 10 files')
