from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
D=Path(__file__).resolve().parent;W=D.parent;P=D.parents[2];N=P/'work/ui-native-r57'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before=json.loads((D/'PROTECTED-BUSINESS-BEFORE-INSTALL.json').read_text('utf-8'))
after=json.loads((D/'PROTECTED-BUSINESS-AFTER-INSTALL.json').read_text('utf-8'))
diag=json.loads((D/'ACTUAL-ENTRY-DIAGNOSTICS.json').read_text('utf-8'))
assert after['sameAsBeforeInstall'] and after['status']=='PASS_CURRENT_BUSINESS_AND_ACCOUNT_METADATA_UNCHANGED'
assert diag['status']=='PASS_INSTALLED_ORIGINAL_CANONICAL_DIAGNOSTICS_NOT_NATIVE_FIRST_START'
assert sha(N/'run_workbench.py')==diag['launcherSha256']=='b507cc91fb378662a72a5e4b538fd855b0e65e8b404d1a3747760751a967e9cb'
assert sha(N/'FROZEN.json')==diag['frozenSha256']=='4b44027f451b9efe7b727ed097564ce38c1d4957d60e0e6731570576820f2245'
assert sha(N/'state/production-workspace.json')==diag['bindingSha256']==before['bindingSha256']
approval=json.loads((W/'f80-next-entry-candidate/ROOT-ENTRY-APPROVAL.json').read_text('utf-8'))
assert approval['onlyReviewedBooleanChanged'] and approval['afterSha256']=='947f937318fe119e5709b134059c0577280fed2eed1e60b1061d76730009fa7e'
evidence=[]
for name in ('FINAL-PINS.json','AGGREGATE-VALIDATION.json','NEXT-ENTRY-ROOT-REVIEW.json',
             'ACTUAL-ENTRY-DIAGNOSTICS.json','ACTUAL-ENTRY-CHECK.json','ACTUAL-ENTRY-SELF-TEST.json',
             'PROTECTED-BUSINESS-BEFORE-INSTALL.json','PROTECTED-BUSINESS-AFTER-INSTALL.json','SOURCE-MERGE-APPLIED.json'):
    evidence.append({'path':name,'sha256':sha(D/name),'bytes':(D/name).stat().st_size})
receipt={'status':'INSTALLED_F80_NEXT_LAUNCH_AND_ACTUAL_ORIGINAL_ENTRY_DIAGNOSTICS_PASS',
    'createdUtc':datetime.now(timezone.utc).isoformat(),'candidate':'candidate-unified-v80',
    'release':'ui-r57-20261023T063552Z-a88a5df9','sourceFiles':3328,'resources':282,
    'launcherSha256':diag['launcherSha256'],'frozenSha256':diag['frozenSha256'],'bindingSha256':diag['bindingSha256'],
    'accountRecords':after['accountRecords'],'allSevenBusinessDigestsUnchanged':after['sameAsBeforeInstall'],
    'businessCounts':{key:value['rows'] for key,value in after['protectedTablesAndEntities'].items()},
    'sourceBackup':'source-before','entryBackup':str(W/'f80-next-entry-candidate/next-launch-prepared/candidate-unified-v80/canonical-entry-before'),
    'oldWindowNotStoppedOrReplaced':True,'nativeHumanFirstOpenVerified':False,
    'realPlatformCollectionOrMessagingVerified':False,'scannedPdfIncluded':False,
    'ordinaryCleanDistributionStillInReview':True,'realPlatformOrModelCalls':0,
    'fullGoalComplete':False,'evidence':evidence}
target=D/'INSTALLATION-FINAL.json';assert not target.exists();target.write_text(json.dumps(receipt,ensure_ascii=False,indent=2),'utf-8')
print(json.dumps({'status':receipt['status'],'finalSha256':sha(target),'counts':receipt['businessCounts'],'accounts':receipt['accountRecords']}))
