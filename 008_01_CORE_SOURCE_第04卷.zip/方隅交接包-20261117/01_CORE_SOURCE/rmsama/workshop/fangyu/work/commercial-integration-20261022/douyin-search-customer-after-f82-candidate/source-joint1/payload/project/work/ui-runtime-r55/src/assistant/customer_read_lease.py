"""Host-material-selected customer read heartbeat; no employee/send grant.

Only the original bound Service/Runner can consume the authenticated response.
JSON, a company flag, a material review or Core's general lease fields alone
cannot create this short-lived, purpose-checked in-memory read lease.
"""
from dataclasses import dataclass
import hashlib
import json
import math
import sys
import time

VERSION='1.2.0-read.1'
PROTOCOL='fangyu-customer-read-v1'
_SEAL=object()
_PURPOSES={
    'douyin_owned_connection':'account_identity',
    'douyin_owned_video_comments':'content_read',
    'douyin_owned_keyword_search_page':'content_read',
    'xiaohongshu_guarded_read':'content_read',
    'xiaohongshu_natural_read':'content_read',
    'xiaohongshu_identity_observation':'account_identity',
    'xiaohongshu_session_recovery':'account_session',
}
_FIELDS=frozenset(('schema','allowed','company_id','device_id','version','scope',
    'platforms','capabilities','lease_seconds','public_send_allowed','reason'))
_CAPABILITIES=['account_identity','account_session','content_read']

def _digest(value):
    return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,
        separators=(',',':'),allow_nan=False).encode()).hexdigest()

def _authority(server):
    module=sys.modules.get('fangyu_customer_read_distribution')
    value=getattr(server,'_customer_read_authority',None)
    if (module is None or not module.is_authority(value)
            or value.scope_for(server)!='customer_distribution_read'):raise ValueError('customer_read_lease_unavailable')
    return value

def _available(server,purpose):
    if purpose not in _PURPOSES:return False
    authority=_authority(server)
    if purpose.startswith('douyin_'):
        value=authority.resolve(server,purpose)
        return type(value) is dict and value.get('purpose')==purpose and value.get('scope')=='customer_distribution_read'
    if purpose=='xiaohongshu_guarded_read':
        review=authority.runtime_license_review(server,purpose)
        policy=getattr(server,'_runtime_license_policy',None)
        value=policy.resolve() if policy is not None else None
        return (getattr(server,'_customer_guarded_read_component',False) is True
            and type(review) is dict and type(value) is dict and value.get('xiaohongshu') is True)
    # Natural purposes require their own actual material interface. They do
    # not inherit CLI approval or an arbitrary WebView's existence.
    resolver=getattr(authority,'natural_material_review',None)
    return callable(resolver) and resolver(server,purpose) is not None

def enrollment_fields(server):
    """Fixed handshake metadata only; never an enrollment or execution grant."""
    try:
        company=server.company;runtime=company.get('runtime') or {}
        if (company.get('id')!='fangyu-apartment-client' or company.get('releaseVersion')!=VERSION
                or runtime.get('public_send_hold') is not True or runtime.get('release_approved') is not False
                or runtime.get('portable_employee_release') not in (None,False)
                or server.core.deployment_config!=company):return {}
        _authority(server)
        if not any(_available(server,purpose) for purpose in _PURPOSES):return {}
        return {'version':VERSION,'customer_read_protocol':PROTOCOL}
    except (OSError,ValueError,TypeError,KeyError,AttributeError):return {}

@dataclass(frozen=True,slots=True,repr=False)
class _ReadRequest:
    seal:object
    service:object
    executor:object
    session:object
    authority:object
    company_digest:str
    device_id:str
    purposes:tuple

    def valid(self,runner):
        from .xhs_app_context import _DeviceSession,_session_snapshot,_SEAL as app_seal
        from .service import AssistantService
        from .business import BusinessExecutor
        from .runner import AssistantRunner
        try:
            service=self.service;server=service.server;core=server.core
            if (self.seal is not _SEAL or type(service) is not AssistantService
                    or type(self.executor) is not BusinessExecutor or type(self.session) is not _DeviceSession
                    or type(runner) is not AssistantRunner or runner.execute is not self.executor
                    or service.executor is not self.executor or service.closed
                    or service.stop_event.is_set() or runner.revoked or runner.accept_commands is not False
                    or runner.version!=VERSION or runner.customer_read_request is not self
                    or getattr(service,'_customer_read_runner',None) is not runner
                    or self.session is not getattr(self.executor,'_xhs_app_session',None)
                    or self.session.service is not service or self.session.core is not core
                    or self.session.seal is not app_seal
                    or self.session.principal!=(self.executor.owner,self.executor.tenant,self.executor.user_id)
                    or _session_snapshot(service,service.vault.read())!=self.session.binding
                    or self.authority is not _authority(server)
                    or _digest(server.company)!=self.company_digest
                    or server.company!=core.deployment_config
                    or (service.device or {}).get('id')!=self.device_id):return False
            # Poll/enroll may recover from offline. This validates the original
            # bound object but grants no execution before an online lease.
            user=core.store.get('users',self.executor.user_id)
            return (bool(user) and user.get('cloud_bound') is True and not user.get('disabled')
                and user.get('development_local_only') is not True and user.get('role') in ('admin','operator')
                and (user.get('id'),user.get('tenant_id'),user.get('username'))==
                    (self.executor.user_id,self.executor.tenant,self.executor.owner))
        except (OSError,ValueError,TypeError,KeyError,AttributeError):return False

def request_for(service,executor,saved):
    """Original _run calls this only after original DeviceSession binding."""
    from .xhs_app_context import _DeviceSession,_session_snapshot,_SEAL as app_seal
    try:
        server=service.server;session=getattr(executor,'_xhs_app_session',None)
        if not enrollment_fields(server) or type(session) is not _DeviceSession or session.service is not service:return None
        if (session.seal is not app_seal or session.executor is not executor
                or session.core is not server.core or _session_snapshot(service,saved)!=session.binding):return None
        if (type(saved) is not dict or saved.get('state')!='bound' or service.vault.read()!=saved
                or not isinstance(saved.get('device'),dict) or not saved['device'].get('id')):return None
        purposes=tuple(p for p in _PURPOSES if _available(server,p))
        if not purposes:return None
        return _ReadRequest(_SEAL,service,executor,session,_authority(server),_digest(server.company),saved['device']['id'],purposes)
    except (OSError,ValueError,TypeError,KeyError,AttributeError):return None

@dataclass(frozen=True,slots=True,repr=False)
class _ReadLease:
    seal:object
    request:object
    runner:object
    deadline:float

def poll_fields(request,runner):
    if type(request) is _ReadRequest and request.valid(runner):
        return {'customer_read_protocol':PROTOCOL}
    return {}

def from_heartbeat(request,runner,response,poll_started):
    """Exact authenticated response; poll start limits slow/stale responses."""
    try:
        if (type(request) is not _ReadRequest or not request.valid(runner)
                or type(response) is not dict or response.get('safety_hold') is not False
                or type(poll_started) not in (int,float) or not math.isfinite(poll_started)
                or poll_started>time.monotonic()):return None
        value=response.get('customer_read_release')
        if (type(value) is not dict or set(value)!=_FIELDS
                or value['schema']!='fangyu_customer_read_lease_v1' or value['allowed'] is not True
                or value['company_id']!='fangyu-apartment-client' or value['device_id']!=request.device_id
                or value['version']!=VERSION or value['scope']!='customer_distribution_read'
                or type(value['platforms']) is not list or value['platforms']!=['xiaohongshu','douyin']
                or type(value['capabilities']) is not list or value['capabilities']!=_CAPABILITIES
                or type(value['lease_seconds']) is not int or not 1<=value['lease_seconds']<=45
                or value['public_send_allowed'] is not False or value['reason']!='ALLOWED'):return None
        deadline=poll_started+value['lease_seconds']
        if deadline<=time.monotonic():return None
        return _ReadLease(_SEAL,request,runner,deadline)
    except (OSError,ValueError,TypeError,KeyError,AttributeError):return None

def current(server,purpose):
    """Bool only. Caller still proves original actor/store/account/UID/locks."""
    try:
        if purpose not in _PURPOSES:return False
        service=server.assistant_service;lease=getattr(service,'_customer_read_lease',None)
        if (type(lease) is not _ReadLease or lease.seal is not _SEAL
                or lease.request.service is not service or lease.request.executor.server is not server
                or lease.request is not lease.runner.customer_read_request
                or lease.request.session is not getattr(service.executor,'_xhs_app_session',None)
                or purpose not in lease.request.purposes or not lease.request.valid(lease.runner)
                or service.state!='online' or lease.runner.hold_active or server.core.remote_safety_hold
                or time.monotonic()>=lease.deadline):return False
        lease.request.session.check()
        return _available(server,purpose)
    except (OSError,ValueError,TypeError,KeyError,AttributeError):return False
