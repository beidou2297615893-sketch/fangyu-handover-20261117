"""Seal already completed real-F73 checks; never synthesize a platform result."""
from pathlib import Path,PurePosixPath
from datetime import datetime,timezone
import hashlib,json
D=Path(__file__).resolve().parent;W=D.parent;J=W/'v73-integration-validation'
I=W/'v73-final-independent-review'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(J/'SEAL.json')=='79c41349da5568927f1947c78b465d6656a70d9237b96d4eb07811197fe04c33'
assert sha(J/'FINAL-VALIDATION.json')=='96e9a808231105a8989c2f3191a7d281d310c455a920f57501168df7adeed034'
assert sha(I/'SOURCE-FINAL-RECEIPT.json')=='54360fa8cfd5f8257a6fc574a972c004f540fd597ce2be546f8fe58ced1f5165'
seal=json.loads((J/'SEAL.json').read_text('utf-8'))
for rel,pin in seal['files'].items():
    pure=PurePosixPath(rel);assert not pure.is_absolute() and '..' not in pure.parts
    source=J/rel;assert source.resolve().is_relative_to(J.resolve()) and not source.is_symlink()
    assert sha(source)==pin['sha256'] and source.stat().st_size==pin['size']
joint=json.loads((J/'FINAL-VALIDATION.json').read_text('utf-8'))
independent=json.loads((I/'SOURCE-FINAL-RECEIPT.json').read_text('utf-8'))
pins=json.loads((D/'FINAL-PINS.json').read_text('utf-8'))
assert joint['rootPins']==independent['rootPins']==pins
assert joint['status']=='PASS_V73_ACTUAL_FROZEN_COMBINED_VALIDATION'
assert independent['status']=='PASS_V73_FROZEN_SOURCE_INDEPENDENT_REVIEW' and independent['blockingFindings']==[]
assert all(run['exitCode']==0 for run in joint['runs'])
assert not joint['realModelCalls'] and not joint['realPlatformCalls'] and not joint['productionAccess']
actual=joint['actual'];groups=sum(actual[key] for key in ('sharedNativeHTTPGroups','publicContactNativeHTTPGroups','customerOutcomeJointGroups','noReferenceContentGroups','knowledgeNativeHTTPGroups','sourceSchedulerNativeHTTPGroups'))
assert groups==47
out=D/'frozen-native';assert not out.exists();out.mkdir()
evidence={}
def copy(source,name,expected=None):
    assert Path(name).name==name and name.endswith('.json')
    if expected: assert sha(source)==expected
    dest=out/name;assert not dest.exists();dest.write_bytes(source.read_bytes());assert sha(dest)==sha(source)
    evidence[name]=sha(dest)
for run in joint['runs']:
    for name,expected in run.get('evidence',{}).items():copy(J/'evidence'/name,name,expected)
copy(J/'FINAL-VALIDATION.json','JOINT-VALIDATION.json')
copy(J/'SEAL.json','JOINT-SEAL.json')
copy(I/'SOURCE-FINAL-RECEIPT.json','INDEPENDENT-FINAL-VALIDATION.json')
copy(W/'shared-store-context-independent-review/FINAL-RECEIPT.json','SHARED-CONTEXT-INDEPENDENT.json','c72b3cb86f3135653d5a041f08535c7f093dbe0bd879f10dd6d0dcb3f1780122')
copy(W/'public-contact-independent-review/FINAL-RECEIPT.json','CONTACT-REVISION-INDEPENDENT.json','0b77eeaadf5e5c5265eec20629f2ccda2b90431a54038caa52eb05e65145afc1')
copy(D/'CANDIDATE-ENTRY-CHECKS.json','CANDIDATE-ENTRY-CHECKS.json')
copy(D/'CANDIDATE-DIAGNOSTICS-RECOVERY.json','CANDIDATE-DIAGNOSTICS-RECOVERY.json')
summary={'status':'PASS_UNIFIED_V73_ACTUAL_FROZEN_47_HTTP_AND_INDEPENDENT_CLOSURE',
         'timestampUtc':datetime.now(timezone.utc).isoformat(),'candidate':pins['candidate'],
         'release':pins['releaseId'],'unifiedPinsSha':pins['unifiedPinsSha256'],
         'stagedSha':pins['stagedSha256'],'releaseManifestSha':pins['manifestSha256'],
         'unifiedFiles':3156,'releaseFiles':198,'totalHttpGroups':groups,'actual':actual,
         'additionalIndependentSourceChecks':{'sourceScheduler':5,'cache':3,'scheduleHeadless':5},
         'evidenceSha256':evidence,'realModelCalls':0,'realPlatformRequests':0,'productionAccess':False,
         'canonicalInstalled':False,'currentProductionRunningRelease':'ui-r57-20261022T210347Z-c8457008',
         'limits':['Actual platform/provider responses are synthetic; no real collection, sends, posts or paid models.',
                   'Development headless layout and DOM checks are separate from CUA, actual production Native and human approval.',
                   'Old unchanged source UI evidence is referenced, not counted as newly run.',
                   'Root direct candidate check produced only lifecycle diagnostics; those exact bytes were preserved outside F and fresh independent exact closure re-sealed. No pinned file changed.',
                   'New next-launch entry, current running process and ordinary-PC derived installer have separate acceptance receipts.',
                   'Protected real business is audited read-only separately; no production writes, migrations or restores.']}
(out/'SUMMARY.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':summary['status'],'httpGroups':groups,'evidenceFiles':len(evidence),'summarySha256':sha(out/'SUMMARY.json')},ensure_ascii=False))
