from pathlib import Path
import ast,hashlib,json
D=Path(__file__).resolve().parent;W=D.parent;Q=D/'frozen-native';Q.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
root=json.loads((D/'FINAL-PINS.json').read_text('utf-8'))
checks={
 'source-independent.json':(W/'v75-final-source-independent-review/SOURCE-FINAL-RECEIPT.json','7753387fbb469efecbeb08611db00302aebfca1de5a189980f0abe7074fc8014'),
 'source-SEAL.json':(W/'v75-final-source-independent-review/SOURCE-SEALED.json','3cbc0bc55b70db80a1598334003322745dbe2f6949b7e6f470ec07ce3579ce5b'),
 'snapshot-independent.json':(W/'platform-snapshot-held-analysis-independent-review/FINAL-RECEIPT.json','cd5a344ae8ea9d889f675e071779e1da46e53cff30718cb20ceec6d469d0832c'),
 'fresh-author.json':(W/'fresh-acquisition-recovery-candidate/FINAL-RECEIPT.json','cd304ec6a171b70bc5eee4d2ca0f5b08287c99dd9a57cefb936b7a6992e6e3f9'),
 'navigation-author.json':(W/'diversified-acquisition-page-candidate/FINAL-RECEIPT.json','1acfdcc8171b0d3c8ceecd6d66076437fb9ff949566f3bbbae7cc98299549927'),
 'standard-independent.json':(W/'v75-standard-package-independent-review/FINAL-RECEIPT.json','862d04740674c26e33ccd59bf3fcf13437ab9636ce65347dad2994339c4f9af4'),
 'standard-SEAL.json':(W/'v75-standard-package-independent-review/SEALED.json','fc6a1d4b1884f9e9108cd3b79c844c6d56f9e0cae2659d1619a158bb768974fb'),
 'existing-lease-red74.json':(W/'v75-final-source-independent-review/lease-control-v74/RESULTS.json','093b96e09fffccd69f720369b2981d6ddcadeaf3a372700d492e73b4d5c8d1ad'),
 'existing-lease-red75.json':(W/'v75-final-source-independent-review/lease-control-v75/RESULTS.json','4c0ac6cff7561890bb0118653a2aa732ebd4c71a1365c04f316252ec52583b55')}
evidence={}
for name,(source,pin) in checks.items():
 raw=source.read_bytes();assert sha(raw)==pin,str(source);target=Q/name;assert not target.exists();target.write_bytes(raw);evidence['frozen-native/'+name]=pin
review=json.loads((Q/'source-independent.json').read_text('utf-8'))
assert review['rootFinalPins']==root and review['newChangeBlockingFindings']==[]
assert review['actualValidation']['originalFactorySnapshotRequests']==7 and review['actualValidation']['freshOriginalFactoryGroups']==6
assert review['preexistingBlockingEngineeringItem']['notIntroducedByNineChangedSourceFiles'] is True
summary={'status':'TARGETED_LOCAL_ACCOUNT_CUSTOMER_READ_RECOVERY_ACCEPTED_NOT_ALL_CONCURRENCY_OR_COMMERCIAL',
 'rootFinalPins':root,'totalHttpGroups':13,'countedHttpGroups':{'snapshot':7,'freshOriginalFactory':6},
 'fullIndexFitUiGroups':9,'freshUiChecks':32,'realModelCalls':0,'realPlatformRequests':0,'productionAccess':False,
 'validationOnlyOwnFixtures':True,'nativeFirstStartVerified':False,
 'knownPreexistingIssue':review['preexistingBlockingEngineeringItem'],
 'localRecoveryDecision':'Restore account/customer visibility and independent source UI on the existing device; preserve all data/sessions and pending analysis. Publishing remains held.',
 'fullConcurrencyAccepted':False,'commercialDistributionApproved':False,'publicPackageDeliveryApproved':False,
 'continuedEngineeringRequired':True,'prior57UnchangedFeatureGroupsNotRecountedAsNewTests':True}
raw=(json.dumps(summary,ensure_ascii=False,indent=2)+'\n').encode();(Q/'SUMMARY.json').write_bytes(raw);evidence['frozen-native/SUMMARY.json']=sha(raw)
spec={'release_id':root['releaseId'],'unified_sha':root['unifiedPinsSha256'],'files':root['unifiedFileCount'],
 'release_sha':root['manifestSha256'],'candidate_launcher_sha':root['launcherSha256'],'recovery_checkpoint':True,
 'evidence':evidence,'delivery':'delivery-v75','http_groups':13,'staged_sha':root['stagedSha256']}
entry=D/'install_verified_entry.py';before=entry.read_bytes();assert sha(before)=='8571ae82aca2e4f0d9d447ef0192a0df3e9abd118bfff12ed87e6cdb34e5a487'
text=before.decode();tree=ast.parse(text);node=next(n for n in tree.body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='ACCEPTED')
assert ast.literal_eval(node.value)=={}
lines=text.splitlines(keepends=True);lines[node.lineno-1:node.end_lineno]=['ACCEPTED = '+repr({'candidate-unified-v75':spec})+'\n'];text=''.join(lines);after=ast.parse(text)
assert all(ast.dump(a,include_attributes=False)==ast.dump(b,include_attributes=False) for a,b in zip([n for n in tree.body if isinstance(n,ast.FunctionDef)],[n for n in after.body if isinstance(n,ast.FunctionDef)]))
(D/'ENTRY-EMPTY-DRAFT.py').write_bytes(before);entry.write_text(text,encoding='utf-8')
out={'status':'FILLED_FIXED75_ALLOWLIST_INSTALLATION_STILL_DISABLED','entrySha256':sha(entry.read_bytes()),
 'summarySha256':evidence['frozen-native/SUMMARY.json'],'evidence':evidence,'functionsUnchanged':True,'installationReviewed':False,
 'onlyLocalReadRecoveryDecision':True,'knownPreexistingLeaseRedRetained':True,'canonicalWritten':False}
(D/'ENTRY-FILLED.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in out.items() if k!='evidence'}))
