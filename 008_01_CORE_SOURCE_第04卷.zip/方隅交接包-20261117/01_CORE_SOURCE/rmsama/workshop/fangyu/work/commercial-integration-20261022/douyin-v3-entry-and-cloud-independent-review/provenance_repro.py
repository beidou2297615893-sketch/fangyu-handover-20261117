"""Own narrow original Store reproduction, plus clearly separated two-line proposal."""
from pathlib import Path
import ast,difflib,hashlib,importlib.util,json,sqlite3,sys,traceback
T=Path(__file__).resolve().parent;P=T/'source-joint-v3/payload/project'
S=P/'work/ui-runtime-r55/src';sys.path.insert(0,str(S))
from core.store import Store
from core import collection_query_provenance as original
from core.collection_observations import OBSERVATIONS
red=T/'source-joint-v3/payload/factory-0c4d09d210ff40d5b1eda168abf5f7c4/data/workspace.sqlite3'
with sqlite3.connect(red.as_uri()+'?mode=ro',uri=True) as db:
    leads=[json.loads(r[0]) for r in db.execute("SELECT body FROM records WHERE entity='leads'")]
    tasks=[json.loads(r[0]) for r in db.execute("SELECT body FROM records WHERE entity='tasks'")]
assert len(leads)==len(tasks)==1
lead=leads[0];task=tasks[0];assert 'task_id' not in lead and lead['cloud_owner']==task['cloud_owner']
task={**task,'status':'ready'}
account={'id':task['account_id'],'tenant_id':task['tenant_id'],'cloud_owner':task['cloud_owner'],
    'platform':task['platform'],'store_id':task['store_id'],'status':'ready'}
ctx=original.page_context(task,task['pipeline']['query_provenance'],lead['note_url']);assert ctx
db=Store(T/'provenance-owned-store')
db.put('accounts',account);db.put('tasks',task);assert db.insert_leads([lead])==1
before=json.dumps(db.get('leads',lead['id']),ensure_ascii=False,sort_keys=True)
observation={**lead,'task_id':task['id']}
kwargs={'tenant_id':task['tenant_id'],'task_id':task['id'],'owner':task['cloud_owner'],
    'account_id':account['id'],'platform':task['platform'],'observations':[observation],'query_page':ctx}
try:db.insert_collection_page([],**kwargs)
except KeyError as error:
    assert str(error)=="'task_id'";failure=traceback.format_exc()
else:raise AssertionError('Original defect not reproduced')
assert not db.list(OBSERVATIONS) and json.dumps(db.get('leads',lead['id']),ensure_ascii=False,sort_keys=True)==before
source=S/'core/collection_query_provenance.py';raw=source.read_text('utf-8')
assert raw.count("lead['task_id']")==2
proposed=raw.replace("lead['task_id']","lead.get('task_id')");ast.parse(proposed)
patch=''.join(difflib.unified_diff(raw.splitlines(True),proposed.splitlines(True),
    fromfile='before/core/collection_query_provenance.py',tofile='after/core/collection_query_provenance.py'))
(T/'PROPOSED-PROVENANCE.patch').write_text(patch,'utf-8')
copy=T/'proposed_collection_query_provenance.py';copy.write_text(proposed,'utf-8')
spec=importlib.util.spec_from_file_location('core.collection_query_provenance',copy)
module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
result=db.insert_collection_page([],**kwargs);assert result['imported']==0 and result['linked_existing']==1
assert json.dumps(db.get('leads',lead['id']),ensure_ascii=False,sort_keys=True)==before
observed=db.list(module.ENTITY);assert len(observed)==1 and observed[0]['original_task_id'] is None
assert module.valid_observation(observed[0],task,lead)
again=db.insert_collection_page([],**kwargs);assert again['imported']==0 and again['linked_existing']==0
assert len(db.list(module.ENTITY))==len(db.list(OBSERVATIONS))==1
try:db.insert_collection_page([],**{**kwargs,'owner':'foreign-owner'})
except ValueError:pass
else:raise AssertionError('Ownership guard relaxed')
out={'status':'ORIGINAL_RED_PROPOSED_COPY_GREEN','originalStoreAndProvenanceDefect':failure,
    'originalSourceSha256':hashlib.sha256(source.read_bytes()).hexdigest(),
    'proposedCopySha256':hashlib.sha256(copy.read_bytes()).hexdigest(),
    'patchSha256':hashlib.sha256((T/'PROPOSED-PROVENANCE.patch').read_bytes()).hexdigest(),
    'proposalOnlyNotProductAdopted':True,'sourceWrites':0,'originalAndFinalLeadUnchanged':True,
    'originalTaskIdPreservedAsNoneNotForged':True,'sameObservationIdempotent':True,'foreignOwnerDenied':True,
    'productionOrPlatformModelRequests':0}
(T/'PROVENANCE-REPRO.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),'utf-8')
print(json.dumps({k:v for k,v in out.items() if k!='originalStoreAndProvenanceDefect'}))
