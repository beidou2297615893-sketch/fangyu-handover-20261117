from pathlib import Path
import subprocess, sys
T=Path(__file__).resolve().parent
B=T/'source-planning1'
subprocess.run([sys.executable,str(T/'prepare_entry.py'),'source-planning1'],check=True)
body=(T/'probe_body.py.in').read_text('utf-8').split('    # Leave the original AI queue')[0]
body=body.replace("assert search_review and search_review['purpose']=='douyin_owned_keyword_search_page'",'assert search_review is None')
body=body.replace("assert runtime.server._customer_distribution_purpose('douyin_owned_keyword_search_page') is not None","assert runtime.server._customer_distribution_purpose('douyin_owned_keyword_search_page') is None")
body=body.replace("'searchIndependentPurposeResolved':True","'searchMissingHelperMaterialClosed':True")
entry=B/'probe_entry-planning.py'
assert not entry.exists()
entry.write_text((B/'standard_loader_prefix.py').read_text('utf-8')+'\n'+body+(T/'planning_probe_tail.py.in').read_text('utf-8'),'utf-8')
print('Own planning entry ready')
