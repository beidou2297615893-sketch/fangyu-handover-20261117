from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,ast
W=Path(__file__).resolve().parents[1];D=Path(__file__).resolve().parent;E=D/'frozen-native'
sha=lambda b:hashlib.sha256(b).hexdigest()
root=json.loads((D/'FINAL-PINS.json').read_text('utf-8'))
assert sha((D/'FINAL-PINS.json').read_bytes())=='1016591327fc57165129dff26d4828ba76ec9ce57b14e2a21cdedd5d8904e0e9'
sources={
 'JOINT-VALIDATION.json':W/'v74-joint-factory-validation/FINAL-RECEIPT.json',
 'JOINT-SEAL.json':W/'v74-joint-factory-validation/SEAL.json',
 'scope-original-key.json':W/'v74-joint-factory-validation/SCOPE-ORIGINAL-KEY-RESULTS.json',
 'source-pdf-independent.json':W/'v74-final-source-pdf-review/FINAL-RECEIPT.json',
 'source-pdf-SEAL.json':W/'v74-final-source-pdf-review/SEALED.json',
 'pdf-FACTORY-HTTP.json':W/'v74-final-source-pdf-review/FACTORY-HTTP-RESULTS.json',
 'pdf-UI-HTTP.json':W/'v74-final-source-pdf-review/UI-HTTP-RESULTS.json',
 'pdf-cache.json':W/'v74-final-source-pdf-review/NATIVE-CACHE-RESULTS.json',
 'detail-HTTP.json':W/'v74-detail-validation/FACTORY-HTTP-RESULTS.json',
 'detail-layout.json':W/'v74-detail-validation/LAYOUT-RESULTS.json',
 'scope-binding-independent.json':W/'scoped-attempt-binding-independent-review/FINAL-RECEIPT.json',
 'notice-independent.json':W/'analysis-version-visibility-independent-review/FINAL-RECEIPT.json',
 'builder-independent.json':W/'v74-build-tool-independent-review/FINAL-RECEIPT.json',
 'standard-build.json':W/'next-release-integration-preflight/v74-build-execution/V74-BUILD-FINAL-RECEIPT.json',
 'standard-independent.json':W/'v74-standard-independent-review/FINAL-RECEIPT.json',
}
raws={name:p.read_bytes() for name,p in sources.items()}
for name in ('JOINT-VALIDATION.json','source-pdf-independent.json','detail-HTTP.json','detail-layout.json','standard-independent.json'):
    value=json.loads(raws[name]);assert str(value.get('status','')).startswith('PASS'),(name,value.get('status'))
joint=json.loads(raws['JOINT-VALIDATION.json']);pdf=json.loads(raws['source-pdf-independent.json'])
assert joint['rootPins']==root and pdf['rootFinalPins']==root
assert joint['actual']['fixedPriorHttpGroupsTotal']==47
assert pdf['actualValidation']['originalVerifyReadPublicDependencyCreateBackendCoreStoreHTTPGroups']==7
assert len(json.loads(raws['detail-HTTP.json'])['groups'])==3
assert json.loads(raws['detail-layout.json'])['originalFrozenModules'] is True
E.mkdir(exist_ok=True)
pins={}
for name,raw in raws.items():
    target=E/name
    if target.exists():assert target.read_bytes()==raw
    else:target.write_bytes(raw)
    pins['frozen-native/'+name]=sha(raw)
summary={'status':'PASS_V74_FROZEN_SOURCE_HTTP_UI_AND_HELD_STANDARD_ACCEPTANCE',
 'timestampUtc':datetime.now(timezone.utc).isoformat(),'candidate':root['candidate'],'release':root['releaseId'],
 'unifiedFiles':3282,'releaseFiles':261,'totalHttpGroups':57,
 'actual':{'priorJointHttpGroups':47,'pdfHttpGroups':7,'detailHttpGroups':3,'scopeTargetedHttpEvents':33,'pdfUiGroups':3,'detailWideNarrowAndStateUiGroups':3},
 'realModelCalls':0,'realPlatformRequests':0,'productionAccess':False,'canonicalInstalled':False,
 'actualNativeWindowVerified':False,'secondPhysicalPCVerified':False,'humanVisualApproval':False,
 'evidenceSha256':pins,'limits':['Synthetic platform/model transport only; no paid provider or public send.',
 'Headless full-stack UI is separate from actual desktop Native.',
 'Whole three-in-one scope remains open; this receipt approves this fixed incremental release only.']}
target=E/'SUMMARY.json';assert not target.exists();target.write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
pins['frozen-native/SUMMARY.json']=sha(target.read_bytes())
spec={'release_id':root['releaseId'],'unified_sha':root['unifiedPinsSha256'],'files':root['unifiedFileCount'],
 'release_sha':root['manifestSha256'],'candidate_launcher_sha':root['launcherSha256'],'recovery_checkpoint':True,
 'evidence':pins,'delivery':'delivery-v74','http_groups':57,'staged_sha':root['stagedSha256']}
script=D/'install_verified_entry.py';text=script.read_text('utf-8');assert text.count('ACCEPTED = {}')==1
text=text.replace('ACCEPTED = {}','ACCEPTED = '+repr({root['candidate']:spec}))
old="expected = P / 'work/commercial-integration-20261022/delivery-v73'"
assert text.count(old)==1;text=text.replace(old,"expected = P / 'work/commercial-integration-20261022/delivery-v74'")
ast.parse(text);assert 'INSTALLATION_REVIEWED = False' in text
script.write_text(text,encoding='utf-8')
out={'status':'ACCEPTANCE_FIXED_ENTRY_STILL_DISABLED_PENDING_INDEPENDENT_REVIEW','summarySha256':sha(target.read_bytes()),'entrySHA256':sha(script.read_bytes()),'httpGroups':57,'evidenceFiles':len(pins),'canonicalWritten':False}
(D/'FIXED-ACCEPTANCE.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps(out))
