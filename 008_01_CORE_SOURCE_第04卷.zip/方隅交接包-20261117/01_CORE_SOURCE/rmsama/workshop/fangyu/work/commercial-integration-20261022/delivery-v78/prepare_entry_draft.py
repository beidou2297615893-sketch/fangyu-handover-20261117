from pathlib import Path
import ast,hashlib,json
D=Path(__file__).resolve().parent;W=D.parent
source=W/'delivery-v77/install_verified_entry.py';raw=source.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='0034bec93c615e89a67b4b0e6011941d92c8f893500d46df1caed979deb8f8ef'
text=raw.decode('utf-8');tree=ast.parse(text);lines=text.splitlines(keepends=True)
replacements={
 'ACCEPTED':'ACCEPTED = {}\n',
 'INSTALLATION_REVIEWED':'INSTALLATION_REVIEWED = False  # Requires final immutable78 acceptance.\n',
 'OLD_LAUNCHER_SHA':"OLD_LAUNCHER_SHA = '52c4db8cddb64802121c1a77d25f86149ba321f7427a45f46a4758d577e3fe3f'\n",
 'OLD_FROZEN_SHA':"OLD_FROZEN_SHA = '745f1aa1d7e75bc38fecc29ab133d635dffb68c36072e3ac0cb406e7a8958544'\n",
}
nodes=[n for n in tree.body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id in replacements]
assert len(nodes)==4
for n in sorted(nodes,key=lambda n:n.lineno,reverse=True):lines[n.lineno-1:n.end_lineno]=[replacements[n.targets[0].id]]
text=''.join(lines)
anchor="    closure(F / 'candidate-unified-v76', 'c36ef66631478cde825cb6b3b5ec2a9d169d204e711de0751fbb4b84f57d5ecd', 3288)"
assert text.count(anchor)==1
text=text.replace(anchor,anchor+"\n    closure(F / 'candidate-unified-v77', 'cd8c1c9702c8246fbfc5f2b1ff4e1750c8324955d939075391c727199088439b', 3308)")
anchor="    expected = P / 'work/commercial-integration-20261022/delivery-v77'";assert text.count(anchor)==1
text=text.replace(anchor,anchor.replace('v77','v78'))
functions=lambda t:{n.name:ast.dump(n,include_attributes=False) for n in t.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
before,after=functions(tree),functions(ast.parse(text))
assert {k for k in before if before[k]!=after[k]}=={'check','main'}
target=D/'install_verified_entry.py';assert not target.exists();target.write_text(text,'utf-8')
receipt={'sourceSha256':hashlib.sha256(raw).hexdigest(),'draftSha256':hashlib.sha256(target.read_bytes()).hexdigest(),'allInstallerFunctionsUnchanged':True,'checkOnlyAddsF77Rollback':True,'mainOnlyChangesExactDeliveryFolder':'delivery-v78','accepted':{},'installationReviewed':False,'canonicalWritten':False}
(D/'NEXT-ENTRY-DRAFT.json').write_text(json.dumps(receipt,indent=2),'utf-8');print(json.dumps(receipt))
