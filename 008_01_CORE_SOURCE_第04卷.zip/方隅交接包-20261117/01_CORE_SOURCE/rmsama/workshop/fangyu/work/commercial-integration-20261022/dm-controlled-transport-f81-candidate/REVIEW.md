固定 F81 的私信受控传输源码候选。只合 source-candidate/ 的10文件；不合 qa-only-project、夹具、数据或证据。

原 DMWorkbench/Core/Store/账号归属、collection/replies 原子模式、草稿核对、稳定客户跨账号预留、unknown 原key、退休账号历史、UI均原字节。新增 typed /api/dm/call 与 /api/dm/result，固定 listen/stop/send；固定 HTTP polling connId、非空原本机 token、严格平台UID、原 requestId。旧脚本/错站点/错sourceDigest无回退；typed结果不能由generic /api/result或WS结果解锁。不接受调用者JS、source或history命令。

客户端经原固定NodeCLI、原BridgeClient/Router/Registry到完整userscript，直接调用静态封定的 reviewed DM 实现；旧protobuf body与旧通用Bridge后缀逐字保留。当前正向仅为合成页面、合成签名/身份/IM响应；没有读真人消息/凭据、打开真实平台页面/本人窗口、发送或调用模型；完整界面使用自有本地headless Chromium。

25个原工厂断言、8个typed合同断言、原完整界面33个断言和原账号组件/CLI反篡改代表通过。界面1255/390，最小文字14.45px；仍称已保存会话/本机记录，平台历史false。两账号同时同UID只有一条进入typed命令，另账号成功私信或旧sent评论阻断批量DM。旧评论sent是明确合成历史记录；本轮未发送评论。

默认发送暂停和dm_contract_verified原值未改。Bridge token只用于本机传输，不是应用业务授权；产品入口仍需原权限/租约/逐条与最终确认。新低层接口不替代原业务层预留。

合版必做：live与DM三向合并共享 client/router/registry 后，统一重算 core.dm_transport.PINS、CLI引用、active连接review/service/SOURCE与MERGED-REPIN-REQUIREMENTS.json列出的旧连接/评论用途材料，再正常freeze并跑原账号/读取工厂。不可把本候选10文件直接当作整个合版已经完成用途审核；不改purpose/material_limits/public_send_grant绕过。当前只精确重绑active vendor连接三pin并通过原_components；旧镜像材料列为合版未完成项。

MIT来源固定 Yht20927/douyin-cli commit4073159bea585de6d33a4747a475669440737932；官方匿名API本轮确认MIT/未归档，原LICENSE/Node/ws许可证保留。无新依赖/整包更新/默认token/模型。真实IM密钥签名、真实平台送达/已读、平台历史分页、小红书可商用DM传输、后继普通编译包都未验证；本候选不放开发送或发布。
