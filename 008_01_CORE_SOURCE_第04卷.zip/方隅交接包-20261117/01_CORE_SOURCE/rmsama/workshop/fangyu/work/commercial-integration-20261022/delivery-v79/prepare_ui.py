from pathlib import Path
import hashlib,json
D=Path(__file__).resolve().parent;old=D.parent/'delivery-v78/ui-recovery-validation';W=D/'ui-recovery-validation';W.mkdir()
for name in ['serve_ui.py','test_ui.cjs']:
 raw=(old/name).read_text('utf-8');text=raw.replace('candidate-unified-v78/project','candidate-unified-v79/project').replace('actualF78Stage','actualF79Stage').replace('Actual F78','Actual F79')
 if name=='serve_ui.py':text=text.replace('after=records();business=',"after=records();dump('UI-AFTER-RECORDS.json',after);business=")
 (W/name).write_text(text,'utf-8')
(W/'PREPARATION.json').write_text(json.dumps({'inheritsActualFullIndexFactoryTest':str(old),'actualF78RedRetained':True,'productOverrides':False,'productionAccess':False,'testHashes':{n:hashlib.sha256((W/n).read_bytes()).hexdigest() for n in ['serve_ui.py','test_ui.cjs']}},indent=2),'utf-8')
print('Prepared F79 full entry UI test')
