from pathlib import Path
import json,os,subprocess,sys
from final_inputs import load_verified
W=Path(__file__).resolve().parent;pins,F,S,stage,R=load_verified()
steps=[('shared','test_shared_context_final_http.py',['HTTP-PASS.json','LEGACY-CONTENT-RESULTS.json']),('contacts','test_contacts_final_http.py',['FACTORY-HTTP-RESULTS.json','OUTCOME-JOINT-RESULTS.json']),('knowledge','test_knowledge_final_http.py',['REAL-HOST-RESULTS.json']),('schedule','test_schedule_final_http.py',['HTTP-RESULTS.json']),('account','test_account_factory.py',['LATEST-FACTORY.json']),('keyword','test_keyword_composition.cjs',['KEYWORD-COMPOSITION-RESULTS.json'])]
runs=[];e=W/'evidence';e.mkdir(exist_ok=True);passed=False
try:
 for label,name,outputs in steps:
  command=['C:/Program Files/nodejs/node.exe',str(W/name)] if name.endswith('.cjs') else [sys.executable,'-B',str(W/name)]
  with (W/(label+'.log')).open('xb') as log:p=subprocess.run(command,cwd=W,env={**os.environ,'PYTHONIOENCODING':'utf-8','PYTHONUTF8':'1','PYTHONDONTWRITEBYTECODE':'1'},stdout=log,stderr=subprocess.STDOUT,timeout=300)
  runs.append({'label':label,'exitCode':p.returncode});assert p.returncode==0,'Regression failed: '+label
  for name in outputs:(e/(label+'-'+name)).write_bytes((W/name).read_bytes())
  print('PASS '+label,flush=True)
 def r(label,name):return json.loads((e/(label+'-'+name)).read_text('utf-8'))
 counts={'shared':r('shared','HTTP-PASS.json')['passed'],'legacy':r('shared','LEGACY-CONTENT-RESULTS.json')['groups'],'contacts':r('contacts','FACTORY-HTTP-RESULTS.json')['groupCount'],'outcomes':r('contacts','OUTCOME-JOINT-RESULTS.json')['groups'],'knowledge':r('knowledge','REAL-HOST-RESULTS.json')['passedGroups'],'schedule':r('schedule','HTTP-RESULTS.json')['checks']}
 assert counts=={'shared':13,'legacy':2,'contacts':9,'outcomes':4,'knowledge':4,'schedule':15}
 account=json.loads((W/'LATEST-FACTORY.json').read_text('utf-8'));ar=json.loads((Path(account['directory'])/'RESULTS.json').read_text('utf-8'));assert account['status']=='PASS' and len(ar['checks'])==8
 kw=r('keyword','KEYWORD-COMPOSITION-RESULTS.json');assert kw['groups']==11 and not kw['pageErrors'] and not kw['externalRequests'];load_verified();passed=True
finally:
 (W/'RESULTS.json').write_text(json.dumps({'status':'PASS_ACTUAL_BOUND_AGGREGATE' if passed else 'RED_PRESERVED','rootPins':pins,'runs':runs,'business47':passed,'account8':passed,'keywordWrapper11':passed,'notFullAppUi':True,'notDmIndependentReview':True,'realPlatformModelCalls':0,'productSourceWrites':False},ensure_ascii=False,indent=2)+'\n','utf-8')
