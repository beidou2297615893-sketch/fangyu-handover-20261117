from pathlib import Path
import hashlib,json,urllib.request
W=Path(__file__).resolve().parent;X=W.parent;P=W.parents[2]
S=P/'work/parallel-integration-20261018/final-integration/stage-02/project'
rels=['work/ui-native-r57/workbench_backend.py','work/ui-native-r57/ui_native_host.py','work/ui-native-r57/freeze_ui.py','work/ui-approved-implementation/ui-preview/pages/reply.mjs','work/ui-approved-implementation/ui-preview/backend.mjs','work/ui-runtime-r55/work/runtime/douyin-bridge/lib/commands/dm.js','work/ui-runtime-r55/work/runtime/douyin-bridge/cli.js','work/ui-runtime-r55/work/runtime/douyin-bridge/scripts/douyin.user.js','work/ui-runtime-r55/src/core/adapters.py','work/shared-backend-integration/platform_runtime.py']
files=[]
for rel in rels:
 p=S/rel
 if not p.exists():continue
 b=p.read_bytes();dest=W/'baseline'/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
 dest=W/'source-candidate'/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
 files.append({'path':rel,'beforeSha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)})
(W/'BASELINE-PINS.json').write_text(json.dumps({'baseline':str(S),'files':files,'scope':'Owned candidate only, no production data/session copied; source-only final overlay and separately synthetic QA'},ensure_ascii=False,indent=2),'utf-8')
sources=[]
for url in ['https://api.github.com/repos/Yht20927/douyin-cli','https://api.github.com/repos/jackwener/OpenCLI/pulls/2536']:
 try:
  req=urllib.request.Request(url,headers={'User-Agent':'Fangyu-offline-integration-source-audit','Accept':'application/vnd.github+json'})
  with urllib.request.urlopen(req,timeout=20) as r:data=json.load(r)
  sources.append({'url':url,'status':'read','data':{k:data.get(k) for k in ('full_name','default_branch','updated_at','pushed_at','archived','license','state','merged','merge_commit_sha')}})
 except Exception as e:sources.append({'url':url,'status':'unavailable','error':type(e).__name__+': '+str(e)})
(W/'UPSTREAM-REFRESH.json').write_text(json.dumps({'route':'social-ops-components actual catalog + agent-reach GitHub CLI (not authenticated), anonymous official GitHub API fallback','sources':sources,'pinnedReuse':'Yht20927/douyin-cli 4073159bea585de6d33a4747a475669440737932 MIT, existing product adapted implementation; no wholesale upstream update','noPlatformCalls':True},ensure_ascii=False,indent=2),'utf-8')
print(json.dumps({'sources':len(files),'githubReads':[x['status'] for x in sources]}))
