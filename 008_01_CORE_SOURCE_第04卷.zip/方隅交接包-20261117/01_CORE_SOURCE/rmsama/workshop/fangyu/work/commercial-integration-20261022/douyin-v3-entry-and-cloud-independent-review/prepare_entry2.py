from pathlib import Path
import ast,json
T=Path(__file__).resolve().parent;B=T/'source-joint-v3'
t=(B/'probe_entry-minimal.py').read_text('utf-8')
a=t.index('    account=accounts[0]')+len('    account=accounts[0]\n')
b=t.index('    chosen=accounts[0]',a)
t=t[:a]+"    user={**user,'_workbench_store_id':store}\n"+t[b:]
needle="    status,checked,_=request('POST','/api/workbench',{'action':'account_check'"
insert="""    selected_status,selected,_=request('POST','/api/workbench',{'action':'select_store','data':{'storeId':store}})
    assert selected_status==200,(selected_status,selected)
"""
assert t.count(needle)==1;t=t.replace(needle,insert+needle)
t=t.replace("W.parent/'ORIGINAL-CLOUD-BRIDGE.json'","W.parent/'cloud-minimal2/ORIGINAL-CLOUD-BRIDGE.json'")
ast.parse(t);(B/'probe_entry-minimal2.py').write_text(t,'utf-8')
C=B/'cloud-minimal2';C.mkdir()
c=(B/'serve_original_cloud.cjs').read_text('utf-8')
c=c.replace('const D=__dirname,ROOT=','const D='+json.dumps(str(C).replace('\\','/'))+',ROOT=')
c=c.replace("path.join(D,'payload/project/work/app/company.json')",json.dumps(str(B/'payload/project/work/app/company.json').replace('\\','/')))
(C/'serve_original_cloud.cjs').write_text(c,'utf-8')
print('Same fixed v3 product; explicit original select_store precedes first original account_check; no prior observation fabricated')
