"""Portable employee distribution: identity is enrolled on the destination PC.

This public bundle marker selects a validated runtime; it grants no platform
permission. The authenticated enterprise heartbeat is the authority for work.
There is deliberately no development-machine SID, permit, device ID or expiry.
"""
from .private_evaluation import COMPANY_ID, ENVIRONMENT_ID, ENDPOINT, EXE_NAME, SOURCE_SHA256
import hashlib
from pathlib import Path
import sys

VERSION = '1.1.8-pilot.1'
UPDATE_CHANNEL = 'employee-pilot'
UPDATE_BASE = 'https://fh6-d5ga45c0ddae7008c-1439321968.tcloudbaseapp.com/fangyu-employee-pilot/v1/'
UPDATE_TARGET = 'fangyu-employee-pilot-update.zip'
TRUSTED_ROOT_SHA256 = '612acf8e3eba346e6b231855125c014f1ab818c778b2975987d0ef947dfbee9f'
WORKBENCH_SOURCE_SHA256 = '67e2edfa0de1db1ed702f0c9aefd0479c1fcfaa2a46020fed2c14889f905bb43'
WORKBENCH_EXE_SHA256 = '1db77116ebedc24a379f1ad868b0d03ac313554ba0aac898242af4dd672f8084'
WORKBENCH_TREE_SHA256 = '3b4e6af322a03d5bb0195dc505758acc898ec05dcb0db06a44b600026098bd17'


def workbench_source_config_valid(config):
    """Pinned local r57 route only; a marker never grants a device lease.

    Keep the original employee package policy unchanged. The explicit host
    disables remote commands and uses the same authenticated 45-second lease.
    """
    if getattr(sys, 'frozen', False) or not isinstance(config, dict):
        return False
    runtime = config.get('runtime')
    if (not isinstance(runtime, dict)
            or runtime.get('workbench_source_release') != 'fangyu-admin-local-v1'
            or config.get('platforms') != ['xiaohongshu', 'douyin']
            or runtime.get('cli_source_sha256') != WORKBENCH_SOURCE_SHA256
            or runtime.get('public_send_hold') is not True):
        return False
    # Reuse every identity, transport, version and hold check from the fixed
    # one-platform package. Only this source host's platform set is different.
    selected = {**config, 'platforms': ['xiaohongshu'],
                'runtime': {**runtime, 'cli_source_sha256': SOURCE_SHA256}}
    return portable_employee_source_valid(selected)


def pinned_update_feed_valid(feed):
    """Accept only the employee channel and its bundled public trust anchor."""
    expected = {'enabled': True, 'metadata_url': UPDATE_BASE + 'metadata/',
                'targets_url': UPDATE_BASE + 'targets/', 'target': UPDATE_TARGET,
                'channel': UPDATE_CHANNEL}
    if not isinstance(feed, dict) or set(feed) != set(expected) | {'trusted_root'}:
        return False
    if any(feed.get(key) != value for key, value in expected.items()):
        return False
    try:
        root = Path(feed['trusted_root'])
        if (not root.is_absolute() or root.name != 'root.json'
                or root.parent.name != 'update-trust' or root.is_symlink()
                or not root.is_file() or not 100 <= root.stat().st_size <= 262144):
            return False
        return hashlib.sha256(root.read_bytes()).hexdigest() == TRUSTED_ROOT_SHA256
    except (OSError, TypeError, ValueError):
        return False


def portable_employee_source_valid(config):
    if not isinstance(config, dict):
        return False
    runtime = config.get('runtime')
    managed = config.get('managedWorkspace')
    feed = config.get('updateFeed')
    return bool(
        config.get('id') == COMPANY_ID
        and config.get('edition') == 'customer'
        and config.get('personalMode') is False
        and config.get('authMode') == 'managed'
        and config.get('releaseVersion') == VERSION
        and config.get('platforms') == ['xiaohongshu']
        and isinstance(managed, dict)
        and managed.get('environment_id') == ENVIRONMENT_ID
        and managed.get('endpoint') == ENDPOINT
        and isinstance(runtime, dict)
        and runtime.get('role') == 'local_assistant_only'
        and runtime.get('ui_entry') == 'employee_workspace'
        and runtime.get('executable') == EXE_NAME
        and runtime.get('xiaohongshu_read_transport') == 'guarded_cli_v1'
        and runtime.get('cli_source_sha256') == SOURCE_SHA256
        and runtime.get('release_approved') is False
        and runtime.get('xiaohongshu_automation') == 'hold'
        and runtime.get('portable_employee_release') is True
        and not any(key in runtime for key in (
            'private_evaluation', 'private_evaluation_session_id', 'platform_qa_device_id'))
        and (feed is None or isinstance(feed, dict) and feed.get('enabled') is False)
    )


def runtime_config_valid(config):
    if held_standard_config_valid(config):
        return True
    if workbench_source_config_valid(config):
        return True
    if portable_employee_source_valid(config):
        return True
    if not isinstance(config, dict) or not pinned_update_feed_valid(config.get('updateFeed')):
        return False
    # The immutable bundled company stays held; only the fixed installation's
    # independently pinned update policy may be overlaid at runtime.
    return portable_employee_source_valid({**config, 'updateFeed': {'enabled': False}})


def packaged_workspace(config, packaged=False):
    return bool(packaged and runtime_config_valid(config))


# Explicit internal standard distribution compatibility. This does not approve
# a commercial release, turn off a hold, enroll a device or grant a cloud lease.
HELD_STANDARD_MANIFEST_SHA256 = '861fbea6a7b7de56a39fd8b1acc9192cbab904718819339ae53486e156c24b97'


def held_standard_config_valid(config):
    import json
    import stat
    from pathlib import PurePosixPath
    if getattr(sys, 'frozen', False) is not True or type(config) is not dict:
        return False
    runtime=config.get('runtime')
    if (type(runtime) is not dict
            or runtime.get('standard_distribution_schema')!='fangyu-held-standard-r57/1'
            or runtime.get('release_approved') is not False
            or runtime.get('xiaohongshu_automation')!='hold'
            or runtime.get('public_send_hold') is not True
            or runtime.get('executable')!='FangyuWorkbench.exe'
            or config.get('id')!=COMPANY_ID or config.get('edition')!='customer'
            or config.get('personalMode') is not False or config.get('authMode')!='managed'
            or config.get('platforms')!=['xiaohongshu','douyin']
            or runtime.get('cli_source_sha256')!=WORKBENCH_SOURCE_SHA256
            or any(key in runtime for key in ('private_evaluation','private_evaluation_session_id','platform_qa_device_id','portable_employee_release'))):
        return False
    try:
        install=Path(sys.executable).resolve().parent
        project=install/'project'
        # Trust is rooted in the compiled entry's SHIPPED-PINS and native
        # RELEASE pins, which cover this derived file. No self-signing cycle.
        def read(path):
            for part in (path,*path.parents):
                info=part.lstat()
                if part.is_symlink() or getattr(info,'st_file_attributes',0)&0x400:raise ValueError
            before=path.stat()
            if not stat.S_ISREG(before.st_mode) or before.st_nlink!=1:raise ValueError
            raw=path.read_bytes();after=path.stat()
            identity=lambda value:(value.st_dev,value.st_ino,value.st_size,value.st_mtime_ns)
            if identity(before)!=identity(after):raise ValueError
            return raw
        raw=read(project/'HELD-STANDARD-MANIFEST.json')
        if hashlib.sha256(raw).hexdigest()!=HELD_STANDARD_MANIFEST_SHA256:return False
        manifest=json.loads(raw)
        if (manifest.get('schema')!='fangyu-held-standard-code-manifest-v1'
                or manifest.get('companyId')!=COMPANY_ID
                or manifest.get('channel')!='internal_standard_candidate'
                or manifest.get('commercialDistributionApproved') is not False
                or manifest.get('platformExecutionApproved') is not False
                or manifest.get('wrapperSha256')!=WORKBENCH_SOURCE_SHA256
                or manifest.get('nativeReleaseId')!=runtime.get('standard_native_release_id')):
            return False
        digest=hashlib.sha256(json.dumps(config,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
        if digest!=manifest['companyConfigDigest']:return False
        seen=set()
        for row in manifest['codeFiles']:
            relative=PurePosixPath(row['path'])
            if (relative.is_absolute() or '..' in relative.parts or ':' in str(relative)
                    or '\\' in str(relative) or str(relative) in seen):return False
            seen.add(str(relative));body=read(project/relative)
            if len(body)!=row['bytes'] or hashlib.sha256(body).hexdigest()!=row['sha256']:return False
        return bool(seen and manifest.get('codeFileCount')==len(seen))
    except (OSError,ValueError,TypeError,KeyError,AttributeError,UnicodeError):
        return False
