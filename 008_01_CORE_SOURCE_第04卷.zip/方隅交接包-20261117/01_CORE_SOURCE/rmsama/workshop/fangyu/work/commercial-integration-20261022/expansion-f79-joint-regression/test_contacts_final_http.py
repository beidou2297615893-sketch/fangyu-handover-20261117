"""Synthetic real trusted factory/Core/loopback HTTP; no production bindings."""
from pathlib import Path
from copy import deepcopy
import hashlib, http.client, importlib.util, json, os, sys, threading, time
sys.dont_write_bytecode = True
W=Path(__file__).resolve().parent;P=W.parents[2]
from final_inputs import load_verified
ROOT_PINS,F,S,STAGED,release=load_verified()
pin=ROOT_PINS['manifestSha256'];red=False

def load(name,path):
    m=importlib.util.module_from_spec(importlib.util.spec_from_loader(name,loader=None));m.__file__=str(path);sys.modules[name]=m
    exec(compile(path.read_bytes(),str(path),'exec'),m.__dict__);return m

fixture=load('contact_cloud_fixture',P/'work/acquisition-core-repair-20261018/gui-fixture/base_fixture.py')
blocked=[]
def audit(event,args):
    if event in ('subprocess.Popen','os.system','os.startfile','os.posix_spawn'):
        blocked.append(event);raise RuntimeError('No process')
    if event in ('socket.connect','socket.bind') and (not isinstance(args[1],tuple) or args[1][0] not in ('127.0.0.1','::1')):
        blocked.append(event);raise RuntimeError('No external socket')
    if event=='socket.getaddrinfo' and args[0] not in ('127.0.0.1','::1','localhost',None):
        blocked.append(event);raise RuntimeError('No external DNS')
    if event=='sqlite3.connect' and not Path(args[0]).resolve().is_relative_to(W):
        blocked.append(event);raise RuntimeError('No nonfixture DB')
    if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
        path=Path(os.fsdecode(args[0])).absolute();mode,flags=args[1] or '',args[2] or 0
        if (any(c in str(mode) for c in 'wax+') or isinstance(flags,int) and flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC)) and not path.is_relative_to(W):
            blocked.append(event);raise RuntimeError('No outside writes: '+str(path))
sys.addaudithook(audit)
integration=load('integrations',release/'resources/platform-runtime/vendor-src/integrations.py')
cloud=fixture.CloudStandin(json.loads((P/'work/central-store-config/compiled-fixture.json').read_text('utf-8-sig')))
integration.request_json=cloud
host=load('contact_candidate_host',release/'ui_native_host.py')
_,files=host.verify_release(release,pin)
observed=[];real_read=host.read_public
def traced(*a,**kw):
    raw=real_read(*a,**kw);observed.append(str(a[0]));return raw
host.read_public=traced
company=dict(id='fangyu-apartment-client',name='Synthetic contact boundary fixture',edition='customer',personalMode=False,authMode='managed',platforms=['xiaohongshu','douyin'],managedWorkspace={'environment_id':'overnight-fixture','endpoint':'https://example.invalid/fixture'})
data_dir=W/('data-'+str(time.time_ns()))
backend=host.create_backend(release,files,project_root=S,data_dir=data_dir,company=company)
assert type(backend.core).__name__=='Core'
server=host.StaticServer(release,files,backend=backend,cookie_name='contact_fixture_session')
thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
origin='http://127.0.0.1:'+str(server.server_port);headers={};calls=[];groups=[]

def req(method,path,payload=None,status=200,override=None):
    c=http.client.HTTPConnection('127.0.0.1',server.server_port,timeout=25)
    c.request(method,path,json.dumps(payload,ensure_ascii=False).encode() if payload is not None else None,headers if override is None else override)
    r=c.getresponse();raw=r.read();out=json.loads(raw) if raw.startswith(b'{') else {'text':raw.decode()};head=dict(r.getheaders());found=r.status;c.close()
    calls.append({'action':payload and payload.get('action'),'status':found})
    if status is not None:assert found==status,(found,status,out)
    return out,head,found
def call(action,data,status=200,override=None):return req('POST','/api/workbench',{'action':action,'data':data},status,override)[0]
def login(name):
    boot,_,_=req('GET','/api/workbench/bootstrap')
    headers.update({'Content-Type':'application/json','Origin':origin,'X-Fangyu-CSRF':boot['csrfToken']})
    out,head,_=req('POST','/api/workbench',{'action':'login','data':{'username':name,'password':fixture.PASSWORD}})
    headers['Cookie']=head['Set-Cookie'].split(';',1)[0];headers['X-Fangyu-CSRF']=out['csrfToken']
    return backend.core.session(headers['Cookie'].split('=',1)[1]),out
def rows():
    with backend.core.store.connect() as db:return [tuple(r) for r in db.execute('SELECT entity,id,tenant_id,body FROM records ORDER BY entity,id')]
def stable_rows():return [r for r in rows() if r[0] not in ('customer_public_contact_events','customer_public_contact_receipts')]
def read(base,**extra):return call('customer_public_contact_read',{**base,**extra})['publicContacts']
def payload(view,base,candidate=None,operation='confirm',key=None,target=None):
    return {**base,'requestId':key or 'contact-'+str(time.time_ns()),'expectedVersion':view['version'],
        'sourceDigest':view['sourceDigest'],'candidateId':candidate or view['candidates'][0]['id'],
        'operation':operation,'targetEventId':target,'confirmed':True}

try:
    user,logged=login('fixture-operator');store=cloud.first_store
    assert logged['selection']['storeId']==store
    from assistant.customer_list import _person
    for aid in ('own-a','own-b','foreign-account'):
        backend.core.store.put('accounts',dict(id=aid,tenant_id=user['tenant_id'],cloud_owner=user['username'] if aid!='foreign-account' else 'fixture-admin',store_id=store,platform='xiaohongshu',status='disconnected',name='Synthetic'))
    def seed(ident,text,aid='own-a',platform='xiaohongshu',sid=store,owner=None,uid='same-person'):
        owner=owner or user['username'];tid='task-'+ident
        task=dict(id=tid,tenant_id=user['tenant_id'],cloud_owner=owner,store_id=sid,platform=platform,account_id=aid,status='completed')
        lead=dict(id=ident,tenant_id=user['tenant_id'],cloud_owner=owner,store_id=sid,task_id=tid,
            platform=platform,author_id=uid,author='昵称绝不作为联系方式',comment_id='comment-'+ident,
            text=text,note_url='https://www.xiaohongshu.com/explore/'+'a'*24,created_at='2026-10-22T12:00:00Z')
        backend.core.store.put('tasks',task);backend.core.store.put('leads',lead);return lead
    own=seed('own-lead','😀我的电话是[REDACTED:phone_cn]。我的微信是Fangyu_123。<script>ignored()</script>')
    seed('repeat-lead','加我[REDACTED:phone_cn]，方便沟通。','own-b')
    seed('negative-lead','房号[REDACTED:phone_cn]。不要联系我[REDACTED:phone_cn]。朋友说我的微信是other_123。私我。微信。昵称Fangyu_999。')
    foreign=seed('foreign-lead','我的电话是[REDACTED:phone_cn]。','foreign-account',owner='fixture-admin',uid='foreign-person')
    other_store=next(s['id'] for s in cloud.manifest['stores'] if s['id']!=store)
    cross=seed('cross-store','我的微信是Hidden_123。',sid=other_store,uid='cross-person')
    dy=seed('douyin-lead','我的微信是Douyin_123。',platform='douyin',uid='same-person')
    separate=seed('different-person','我的电话是[REDACTED:phone_cn]。',uid='different-person')
    cid=_person(own)[0];base={'storeId':store,'customerId':cid,'platform':'xiaohongshu'}
    if red:
        failure=call('customer_public_contact_read',base,403)
        assert 'text' in failure,failure
        (W/'RED-BASE.json').write_text(json.dumps({'status':'EXPECTED_RED','reason':'Original v72 rejects missing candidate action','http':failure,'originalConstructorUsed':True},ensure_ascii=False,indent=2),'utf-8')
    else:
        before=rows();v=read(base);assert rows()==before
        assert len(v['candidates'])==2 and {c['kind'] for c in v['candidates']}=={'phone','wechat'}
        phone=next(c for c in v['candidates'] if c['kind']=='phone');wechat=next(c for c in v['candidates'] if c['kind']=='wechat')
        assert len(phone['sources'])==2 and len({s['accountId'] for s in phone['sources']})==2
        for c in v['candidates']:
            for s in c['sources']:
                assert s['originalText'][s['span']['start']:s['span']['end']]==s['span']['text']==c['value']
                assert s['author_key']==cid and s['platform']=='xiaohongshu' and s['leadId'] in ('own-lead','repeat-lead')
        assert v['candidateOnly'] and v['contactSharedFactRecorded'] is False
        listing=req('GET','/api/workbench/customers?platform=xiaohongshu')[0]['customers']
        detail=req('GET','/api/workbench/customer?id='+cid+'&platform=xiaohongshu')[0]['customer']
        (W/'UI-INITIAL-SEED.json').write_text(json.dumps({'base':base,'view':deepcopy(v),'listing':listing,'detail':detail,
            'username':user['username'],'userId':user['id'],'tenantId':user['tenant_id']},ensure_ascii=False,indent=2),'utf-8')
        separated=read({**base,'customerId':_person(separate)[0]})
        assert separated['customerId']!=cid and separated['candidates'][0]['id']!=phone['id']
        groups.append('actual trusted factory/read_public/Core/HTTP employee read; exact Unicode spans and provenance; two accounts same original author_key deduplicate; zero records written')
        untouched=stable_rows()
        # Both forms of origin protection and current owner/store/platform remain
        # on the original authenticated transport and CustomerHistory boundary.
        call('customer_public_contact_read',{**base,'storeId':other_store},403)
        call('customer_public_contact_read',{**base,'customerId':_person(foreign)[0]},404)
        call('customer_public_contact_read',{**base,'customerId':_person(cross)[0]},404)
        call('customer_public_contact_read',{**base,'platform':'douyin'},404)
        call('customer_public_contact_read',{**base,'owner':'fixture-admin'},400)
        call('customer_public_contact_read',base,403,{**headers,'Origin':'https://example.invalid'})
        call('customer_public_contact_read',base,403,{**headers,'X-Fangyu-CSRF':'invalid'})
        bad=payload(v,base);bad['confirmed']=False;call('customer_public_contact_save',bad,400)
        bad=payload(v,base);bad['value']='[REDACTED:phone_cn]';call('customer_public_contact_save',bad,400)
        bad=payload(v,base,candidate='f'*64);call('customer_public_contact_save',bad,409)
        assert stable_rows()==untouched
        groups.append('HTTP original employee/store/platform/foreign customer denial, exact fields, Origin/CSRF, explicit confirmation and candidate substitution negatives')
        # Actual simultaneous HTTP requests start with the same original CAS.
        first=payload(v,base,phone['id'],key='first-confirmation')
        second=payload(v,base,phone['id'],operation='reject',key='competing-rejection')
        gate=threading.Barrier(3);race=[]
        def compete(data):
            gate.wait();out,_,status=req('POST','/api/workbench',{'action':'customer_public_contact_save','data':data},None);race.append((status,out))
        threads=[threading.Thread(target=compete,args=(p,)) for p in (first,second)]
        for t in threads:t.start()
        gate.wait()
        for t in threads:t.join(15);assert not t.is_alive()
        assert sorted(r[0] for r in race)==[200,409],race
        good=first if next(r[1]['publicContacts']['receipt']['requestId'] for r in race if r[0]==200)==first['requestId'] else second
        v=read(base,requestId=good['requestId']);assert v['receipt']['state']=='accepted' and v['version']==1
        (W/'UI-CANONICAL.json').write_text(json.dumps({'request':good,'requestDigest':v['receipt']['requestDigest']},ensure_ascii=False,indent=2),'utf-8')
        assert call('customer_public_contact_save',good)['publicContacts']['version']==1
        call('customer_public_contact_read',{**base,'customerId':_person(separate)[0],'requestId':good['requestId']},409)
        call('customer_public_contact_save',{**good,'operation':'reject' if good['operation']=='confirm' else 'confirm'},409)
        event=next(c for c in v['candidates'] if c['id']==phone['id'])['eventId']
        rev=payload(v,base,phone['id'],'revoke','revoke-own-decision',event)
        v=call('customer_public_contact_save',rev)['publicContacts'];assert next(c for c in v['candidates'] if c['id']==phone['id'])['state']=='pending'
        assert v['history'][1]['revoked'] is True and v['version']==2
        reject=payload(v,base,phone['id'],'reject','explicit-rejection');v=call('customer_public_contact_save',reject)['publicContacts']
        assert next(c for c in v['candidates'] if c['id']==phone['id'])['state']=='reject'
        assert stable_rows()==untouched
        groups.append('two actual concurrent HTTP decisions: one append/one CAS conflict; same-key replay exactly once; mutated key rejected; explicit revoke retains history; subsequent reject; customer/comment/AI/outcome records unchanged')
        # Lost acknowledgment after original SQLite commit: query original key,
        # then exact replay. There must be one record, never a new synthetic key.
        factory=backend.public_contacts_factory
        def lost_factory(*a):
            service=factory(*a);save=service.save
            def lost(*a):save(*a);raise ConnectionError('Synthetic lost ack after original commit')
            service.save=lost;return service
        unknown=payload(v,base,wechat['id'],key='original-lost-ack')
        backend.public_contacts_factory=lost_factory
        out=call('customer_public_contact_save',unknown,409);assert out['error']['code']=='PUBLIC_CONTACT_RESULT_UNCONFIRMED'
        backend.public_contacts_factory=factory
        recovered=read(base,requestId=unknown['requestId']);assert recovered['receipt']['state']=='accepted' and recovered['version']==4
        assert call('customer_public_contact_save',unknown)['publicContacts']['version']==4
        # A cancellation receipt prevents an original late write permanently.
        target=next(c for c in recovered['candidates'] if c['id']==wechat['id'])['eventId']
        delayed=payload(recovered,base,wechat['id'],'revoke','cancel-before-late',target)
        signature=hashlib.sha256(json.dumps(delayed,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
        cancelled=call('customer_public_contact_cancel',{**base,'requestId':delayed['requestId'],'requestDigest':signature})['publicContacts']
        assert cancelled['receipt']['state']=='cancelled'
        assert call('customer_public_contact_save',delayed)['publicContacts']['receipt']['state']=='cancelled'
        assert read(base)['version']==4
        groups.append('post-commit lost-ack marked unknown; original-key receipt recovery/exact replay no second event; cancel-before-late freezes original key and prevents late append')
        # Original source digest invalidates a stale candidate even when its
        # contact text still happens to exist in another visible comment.
        v=read(base);stale=payload(v,base,phone['id'],'revoke','stale-source',next(c for c in v['candidates'] if c['id']==phone['id'])['eventId'])
        lead=backend.core.store.get('leads','own-lead');lead['text']='原评论已更正，不再提供联系方式。';backend.core.store.put('leads',lead)
        call('customer_public_contact_save',stale,409)
        now=read(base);assert len(now['candidates'])==1 and now['candidates'][0]['value']=='[REDACTED:phone_cn]'
        assert all(s['leadId']=='repeat-lead' for s in now['candidates'][0]['sources'])
        assert any(h['candidateId']==wechat['id'] and h['withdrawn'] and h['canRevoke'] for h in now['history'])
        assert 'Fangyu_123' not in json.dumps(now['history']) and all('originalCandidate' not in h and 'sources' not in h for h in now['history'])
        groups.append('changed original comment invalidates stale sourceDigest; withdrawn history is redacted but remains explicitly revocable under original current access')
        revision_cases=[('cross-sentence-refusal','我的电话是[REDACTED:phone_cn]。不要联系我。'),
            ('forwarded','转发朋友的话。我的电话是[REDACTED:phone_cn]。'),('example','示例。我的电话是[REDACTED:phone_cn]。'),
            ('fiction','我的电话是[REDACTED:phone_cn]（虚构号码）'),('invented','我的电话是[REDACTED:phone_cn]，仅为随机编造'),
            ('domain','我的微信号是abcdef.com'),('uri','我的微信是wechat://abc_123'),
            ('nickname','我的微信是Fangyu_123。这里只是昵称。')]
        revision_results=[]
        for name,text in revision_cases:
            row=seed('revision-'+name,text,uid='revision-'+name)
            scoped={**base,'customerId':_person(row)[0]};stable=rows();out=read(scoped)
            assert out['candidates']==[] and rows()==stable,(name,out)
            revision_results.append({'case':name,'text':text,'candidates':out['candidates'],'readZeroWrites':True})
        budget=seed('revision-budget','预算不超过5000。我的电话是[REDACTED:phone_cn]。',uid='revision-budget')
        assert read({**base,'customerId':_person(budget)[0]})['candidates'][0]['value']=='[REDACTED:phone_cn]'
        retract=seed('revision-retract','我的电话是[REDACTED:phone_cn]。',uid='revision-retract')
        retract_base={**base,'customerId':_person(retract)[0]};initial=read(retract_base)
        confirm=payload(initial,retract_base,key='revision-before-retract')
        confirmed=call('customer_public_contact_save',confirm)['publicContacts'];original_event=confirmed['candidates'][0]['eventId']
        retained=deepcopy(backend.core.store.get('customer_public_contact_events',original_event))
        revised=deepcopy(retract);revised['text']='想周末看房。我的电话是[REDACTED:phone_cn]。';backend.core.store.put('leads',revised)
        changed_proof=read(retract_base)
        assert changed_proof['candidates'][0]['state']=='pending' and changed_proof['candidates'][0]['requiresPriorRevoke']
        assert changed_proof['history'][0]['withdrawn'] and changed_proof['history'][0]['canRevoke']
        retract['text']='原电话撤回，请勿再使用。';backend.core.store.put('leads',retract)
        withdrawn=read(retract_base)
        assert withdrawn['candidates']==[] and len(withdrawn['history'])==1
        historical=withdrawn['history'][0];assert historical['withdrawn'] and historical['canRevoke'] and not historical['revoked']
        assert '[REDACTED:phone_cn]' not in json.dumps(withdrawn,ensure_ascii=False) and 'originalText' not in json.dumps(withdrawn)
        bad=payload(withdrawn,retract_base,confirm['candidateId'],'confirm','revision-reconfirm-old')
        call('customer_public_contact_save',bad,409)
        bad=payload(withdrawn,retract_base,confirm['candidateId'],'revoke','revision-stale-revoke',original_event)
        bad['sourceDigest']=confirmed['sourceDigest'];call('customer_public_contact_save',bad,409)
        revoke=payload(withdrawn,retract_base,confirm['candidateId'],'revoke','revision-after-retract',original_event)
        revoked_view=call('customer_public_contact_save',revoke)['publicContacts']
        assert revoked_view['candidates']==[] and len(revoked_view['history'])==2 and revoked_view['history'][1]['revoked']
        assert backend.core.store.get('customer_public_contact_events',original_event)==retained
        assert '[REDACTED:phone_cn]' not in json.dumps(revoked_view,ensure_ascii=False)
        assert call('customer_public_contact_save',revoke)['publicContacts']['version']==2
        assert read(retract_base,requestId=revoke['requestId'])['receipt']['state']=='accepted'
        (W/'UI-WITHDRAWN-SEED.json').write_text(json.dumps({'base':retract_base,'view':withdrawn,'revoked':revoked_view},ensure_ascii=False,indent=2),'utf-8')
        hidden=deepcopy(retract);hidden['cloud_owner']='fixture-admin';backend.core.store.put('leads',hidden)
        hidden_task=backend.core.store.get('tasks',hidden['task_id']);hidden_task['cloud_owner']='fixture-admin';backend.core.store.put('tasks',hidden_task)
        call('customer_public_contact_read',retract_base,404)
        (W/'REVISION-HTTP-RESULTS.json').write_text(json.dumps({'status':'PASS','independentRedReceiptSha256':'87d721e0931e58be71a0ab2ebc3641f188fe4727a51d83e4d52cac53f9e800b5',
            'negativeCases':revision_results,'budgetNotMisreadAsRefusal':True,'withdrawn':withdrawn,'revoked':revoked_view,
            'oldEventBytesRetained':True,'hiddenOldContactNotReturned':True,'noCurrentCustomerAccessDenied':True},ensure_ascii=False,indent=2),'utf-8')
        groups.append('independent eight actual HTTP counterexamples now zero candidates/zero writes; budget remains valid; withdrawal redacted history/current CAS explicit revoke/replay; old event retained and total access loss denied')
        # Re-entering with another employee cannot expose the first employee's
        # contact journal even if the incoming customer identifier is known.
        own_headers=dict(headers);admin,admin_login=login('fixture-admin')
        admin_selected=call('select_store',{'storeId':store,'expectedRevision':admin_login['selection']['revision']})
        call('customer_public_contact_read',base,404)
        admin_lead=seed('admin-visible','我的电话是[REDACTED:phone_cn]。','foreign-account',owner=admin['username'],uid='admin-person')
        admin_base={**base,'customerId':_person(admin_lead)[0]}
        assert read(admin_base)['candidates'][0]['value']=='[REDACTED:phone_cn]'
        switched=[];admin_token=headers['Cookie'].split('=',1)[1]
        def late_store_factory(*a):
            service=factory(*a);original=service.read
            def late(*a):
                result=original(*a)
                if not switched:
                    switched.append(True)
                    backend.dispatch('select_store',{'storeId':other_store,'expectedRevision':admin_selected['selection']['revision']},token=admin_token)
                return result
            service.read=late;return service
        backend.public_contacts_factory=late_store_factory
        denied=call('customer_public_contact_read',admin_base,403)
        assert denied['error']['code']=='PUBLIC_CONTACT_SCOPE_CHANGED' and 'publicContacts' not in denied
        backend.public_contacts_factory=factory
        headers.clear();headers.update(own_headers)
        original_lead=deepcopy(backend.core.store.get('leads','repeat-lead'));changed=[]
        def late_source_factory(*a):
            service=factory(*a);original=service.read
            def late(*a):
                result=original(*a)
                if not changed:
                    changed.append(True);row=deepcopy(original_lead);row['text']='已撤去原联系方式。';backend.core.store.put('leads',row)
                return result
            service.read=late;return service
        backend.public_contacts_factory=late_source_factory
        denied=call('customer_public_contact_read',base,409)
        assert denied['error']['code']=='PUBLIC_CONTACT_SOURCE_CHANGED' and 'publicContacts' not in denied
        backend.public_contacts_factory=factory;backend.core.store.put('leads',original_lead)
        groups.append('actual in-flight original select_store CAS and post-read original comment change are rejected before contact response disclosure')
        durable=read(base,requestId=unknown['requestId']);events_before=deepcopy(backend.core.store.list('customer_public_contact_events'))
        first_core=id(backend.core);backend.close()
        backend=host.create_backend(release,files,project_root=S,data_dir=data_dir,company=company)
        server.backend=backend
        assert id(backend.core)!=first_core and type(backend.core).__name__=='Core'
        reopened=read(base,requestId=unknown['requestId'])
        assert reopened['receipt']==durable['receipt'] and reopened['version']==durable['version']
        assert backend.core.store.list('customer_public_contact_events')==events_before
        groups.append('fresh actual create_backend/original Core reopens the same owned Store; original unknown request and append-only decisions survive without second events')
        assert not blocked,blocked
        seed_result={'base':base,'view':read(base),'username':user['username'],'userId':user['id'],'tenantId':user['tenant_id']}
        (W/'UI-SEED.json').write_text(json.dumps(seed_result,ensure_ascii=False,indent=2),'utf-8')
        groups.append('current employee ownership enforced through original detail_context; known author_key does not reveal another employee candidates/history')
        # Joint regression: explicit contact decisions never imply customer
        # business facts. Outcome writes keep their own original event/receipt.
        outcome_before=call('customer_outcome_read',base)['customerOutcomes']
        assert outcome_before['history']==[]
        contact_journal=deepcopy(backend.core.store.list('customer_public_contact_events'))
        outcome_request={**base,'requestId':'v73-original-outcome','expectedVersion':outcome_before['version'],
            'sourceDigest':outcome_before['sourceDigest'],'operation':'record','targetEventId':None,
            'kind':'responded','occurredOn':'2026-10-23','fact':'合成本人核对：客户已回应',
            'source':'合成原面谈记录','evidenceRef':'合成核验凭据','amountCents':None,'costCategory':None,'confirmed':True}
        outcome=call('customer_outcome_save',outcome_request)['customerOutcomes']
        assert outcome['receipt']['state']=='accepted'
        again=call('customer_outcome_save',outcome_request)['customerOutcomes'];assert again['version']==outcome['version'] and len(again['history'])==1
        recovered=call('customer_outcome_read',{**base,'requestId':outcome_request['requestId']})['customerOutcomes'];assert recovered['receipt']==outcome['receipt']
        pending={**outcome_request,'requestId':'v73-outcome-cancel-original','expectedVersion':outcome['version'],'sourceDigest':outcome['sourceDigest'],'kind':'signed'}
        signature=hashlib.sha256(json.dumps(pending,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
        cancelled=call('customer_outcome_cancel',{**base,'requestId':pending['requestId'],'requestDigest':signature})['customerOutcomes'];assert cancelled['receipt']['state']=='cancelled'
        late=call('customer_outcome_save',pending)['customerOutcomes'];assert late['receipt']['state']=='cancelled' and late['version']==outcome['version']
        report=call('customer_outcome_report',{'storeId':store,'dateFrom':'2026-10-23','dateTo':'2026-10-23'})['customerOutcomes']
        assert report['registeredCustomers']==1 and report['paymentCents'] is None and report['roi'] is None
        assert backend.core.store.list('customer_public_contact_events')==contact_journal
        (W/'OUTCOME-JOINT-RESULTS.json').write_text(json.dumps({'status':'PASS','groups':4,'trace':[
            'Public contact confirmations/rejections/revocations do not automatically record customer outcome facts',
            'Original outcome Native HTTP save/read/exact replay keeps one event under its own request key',
            'Original cancellation receipt blocks late outcome save; original contact decisions unchanged',
            'Original outcome report counts explicit customer only; missing payment/ROI remain unknown'],
            'actualFactoryAndStore':True,'realPlatformOrModelCalls':0},ensure_ascii=False,indent=2),'utf-8')
finally:
    server.shutdown();server.server_close();thread.join(3);backend.close()

if not red:
    result={'status':'PASS','groups':groups,'groupCount':len(groups),'originalFactoryAndCore':True,
        'releaseManifestSha256':pin,'files':len(files),'readPublicContactModule':any(p.endswith('customer_public_contacts.py') for p in observed),
        'http':calls,'externalAttempts':blocked,'productionAccess':False,'platformOrModelCalls':0,'serverStopped':not thread.is_alive()}
    (W/'FACTORY-HTTP-RESULTS.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),'utf-8')
    print(json.dumps({k:v for k,v in result.items() if k!='http'},ensure_ascii=False,indent=2))
else: print('EXPECTED RED: baseline rejects absent candidate action')
