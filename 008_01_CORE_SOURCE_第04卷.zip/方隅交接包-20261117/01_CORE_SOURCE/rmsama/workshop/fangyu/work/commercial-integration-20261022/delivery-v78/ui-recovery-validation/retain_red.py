from pathlib import Path
import shutil
W=Path(__file__).resolve().parent;dest=W/'first-combined-readiness-red';assert not dest.exists();dest.mkdir()
for p in W.iterdir():
    if p.is_file() and p.suffix in ('.json','.png','.txt','.py','.cjs'):shutil.copy2(p,dest/p.name)
stop=W/'STOP-UI-SERVER'
if stop.exists():stop.unlink()
