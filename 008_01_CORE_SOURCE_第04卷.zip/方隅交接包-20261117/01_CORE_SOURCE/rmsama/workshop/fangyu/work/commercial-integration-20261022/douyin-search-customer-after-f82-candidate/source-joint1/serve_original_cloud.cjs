'use strict';
const http=require('node:http'),fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const D=__dirname,ROOT="C:/\u79ef\u6728\u8f6f\u4ef6\u5de5\u574a/\u9879\u76ee/\u65b9\u9685\u516c\u5bd3\u5ba2\u6237\u7248/work/commercial-integration-20261022/customer-read-cloud-lease-candidate/cloud-candidate-final";
const {createService}=require(path.join(ROOT,'service.cjs'));
const c=JSON.parse(fs.readFileSync(path.join(D,'payload/project/work/app/company.json'),'utf8'));
let state=null,enabled=true,calls=[];
const pins=()=>Object.fromEntries(fs.readdirSync(ROOT).filter(n=>n.endsWith('.cjs')).sort().map(n=>[n,crypto.createHash('sha256').update(fs.readFileSync(path.join(ROOT,n))).digest('hex')]));
const before=pins(),store={transaction:async fn=>{const out=await fn(structuredClone(state));state=out.state;return out.result;}};
global.fetch=()=>{throw Error('No external network');};
const server=http.createServer(async(req,res)=>{
 try{
  if(req.method!=='POST')throw Error('Only owned POST fixture');
  let raw='';for await(const chunk of req){raw+=chunk;if(raw.length>1048576)throw Error('Budget');}
  const body=JSON.parse(raw||'{}');
  if(req.url==='/shutdown'){
   const after=pins();if(JSON.stringify(before)!==JSON.stringify(after))throw Error('Cloud source changed during test');
   fs.writeFileSync(path.join(D,'ORIGINAL-CLOUD-BRIDGE-RESULTS.json'),JSON.stringify({status:'STOPPED',actualOriginalCreateService:true,cloudSourcePins:before,calls,realCloudPlatformRequests:0,productionData:false,store:'own memory only'},null,2)+'\n');
   res.writeHead(200,{'Content-Type':'application/json'});res.end('{"ok":true}');server.close();return;
  }
  if(req.url==='/qa-policy'){
   if(typeof body.enabled!=='boolean')throw Error('Exact QA bool');enabled=body.enabled;
   res.writeHead(200,{'Content-Type':'application/json'});res.end('{"ok":true}');return;
  }
  if(req.url!=='/call'||typeof body.operation!=='string'||typeof body.data!=='object'||typeof body.token!=='string')throw Error('Exact owned fixture input');
  const service=createService({store,environmentId:c.managedWorkspace.environment_id,companyId:c.id,initialAdmin:'fixture-admin',initialPassword:'fixture-password-123',clock:()=>Date.now(),releaseApproved:false,customerReadReleaseEnabled:enabled,customerReadReleaseVersion:'1.2.0-read.1'});
  const result=await service({environment_id:c.managedWorkspace.environment_id,operation:body.operation,...body.data},body.token);
  calls.push({operation:body.operation,status:result.status,version:body.data.version,customerProtocol:body.data.customer_read_protocol,credentialOmitted:true});
  res.writeHead(200,{'Content-Type':'application/json'});res.end(JSON.stringify(result));
 }catch(error){res.writeHead(500,{'Content-Type':'application/json'});res.end(JSON.stringify({error:String(error)}));}
});
server.listen(0,'127.0.0.1',()=>{const p=server.address().port;fs.writeFileSync(path.join(D,'ORIGINAL-CLOUD-BRIDGE.json'),JSON.stringify({port:p,pid:process.pid,cloudSourcePins:before})+'\n');console.log(JSON.stringify({port:p,pid:process.pid,originalCreateService:true,externalNetwork:0}));});
