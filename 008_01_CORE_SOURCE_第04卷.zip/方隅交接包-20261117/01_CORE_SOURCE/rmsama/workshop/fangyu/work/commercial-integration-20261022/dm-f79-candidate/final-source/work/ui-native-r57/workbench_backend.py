"""Narrow customer login and local preset preferences over the existing core.

The host pins/imports the legacy source before loading this module. Optional
platform assembly reuses the guarded employee runtime without task recovery.
"""
import base64
import binascii
import hashlib
import json
import os
import re
import threading
import time
import unicodedata
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
from urllib.error import HTTPError

from core.engine import Core
from integrations import Integrations, IntegrationError, EmployeeLoginRequired
from assistant.ai_workflow import LocalAIWorkflow
from assistant.intent_rule_management import IntentRuleManagement


COMPANY_ID = 'fangyu-apartment-client'
ENTITY = 'ui_workbench_preferences_v1'
STORE_PREF_ENTITY = 'ui_workbench_store_presets_v2'
TONE_PREF_ENTITY = 'ui_workbench_tone_preferences_v1'
STORE_ID = re.compile(r'[A-Za-z0-9_-]{1,80}\Z')
ACTIONS = frozenset({'bootstrap', 'login', 'logout', 'select_store', 'apply_preset', 'refresh_assessments',
    'tone_preferences_read', 'tone_preferences_save'})
PLATFORM_ACTIONS = frozenset({'platform_snapshot', 'platform_prepare', 'account_create',
    'account_connect', 'account_check', 'account_job', 'account_cancel', 'account_safety',
    'account_review_confirm', 'account_verification_open', 'acquisition_start',
    'acquisition_pause', 'acquisition_resume','acquisition_verification_open','acquisition_verification_resume','account_metadata_read','account_metadata_save','account_delete','account_delete_request',
    'acquisition_source_preview','source_preset_read','source_preset_save','source_schedule_read','source_schedule_save','source_interactions_check','source_execution_enable','source_execution_read','source_execution_pause'})
INTERACTION_ACTIONS = frozenset(('interaction_inbox_read','interaction_inbox_state_save','interaction_inbox_request_read'))
OUTCOME_ACTIONS = frozenset({'customer_outcome_read','customer_outcome_save','customer_outcome_cancel','customer_outcome_report'})
PUBLIC_CONTACT_ACTIONS = frozenset({'customer_public_contact_read','customer_public_contact_save','customer_public_contact_cancel'})
CUSTOMER_ACTIONS = PUBLIC_CONTACT_ACTIONS | OUTCOME_ACTIONS | frozenset({'customers', 'customer_detail', 'customer_export','customer_handoff_read','customer_handoff_save','customer_memo_export','customer_intent_read','customer_intent_correct','customer_intent_cancel','keyword_effect_read'})
DM_ACTIONS = frozenset(('dm_workspace_read','dm_listen_start','dm_listen_stop','dm_request_read','dm_draft_save','dm_draft_review','dm_queue_prepare','dm_queue_start','dm_queue_cancel','dm_queue_read'))
REPLY_ACTIONS = frozenset({'reply_read', 'reply_save', 'reply_review', 'reply_check'})
DELIVERY_ACTIONS=frozenset({'reply_delivery_prepare','reply_delivery_start','reply_delivery_status','reply_delivery_cancel'})
REQUEST_ENTITY = 'ui_workbench_platform_requests_v1'
RULE_BUNDLE_FIELDS = {
    'rule_bundle_status': (), 'rule_bundle_export_chunk': ('revision','index'),
    'rule_bundle_import_begin': ('requestId','expectedRevision','digest','bytes','chunkCount'),
    'rule_bundle_import_chunk': ('uploadId','index','dataBase64'),
    'rule_bundle_import_prepare': ('uploadId',),
    'rule_bundle_import_commit': ('uploadId','previewDigest'),
    'rule_bundle_import_status': ('uploadId',)}
SEARCH_IDS = frozenset({'precise', 'commute'})
INTENT_IDS = frozenset({'standard', 'recent', 'rental-evidence'})
AI_RULE_ACTIONS = frozenset({'ai_readiness_read', 'ai_rules_read', 'ai_local_rules_save', 'ai_rules_export'})
VOICE_SAMPLE_ACTIONS = frozenset({'voice_samples_read','voice_samples_save','voice_samples_context'})
VOICE_SAMPLE_MODULE_SHA = '73196277073840ccc94c6b91e41fc2a26d1ba0bb5200db6ddb321680ff4610fa'
CONTENT_ACTIONS = frozenset({'content_workspace_read','content_persona_save','content_topic_save',
    'content_draft_save','content_draft_audit','content_schedule_save','content_metrics_save',
    'content_export','content_prompt_prepare','content_asset_import','content_render_cards',
    'content_guided_catalog_read','content_guided_read','content_guided_save','content_store_context_read','content_methods_read','content_knowledge_import','content_knowledge_search','content_knowledge_file_preview',
    'content_task_prepare','content_task_run','content_task_reconcile','content_task_apply','content_package_build','content_task_archive','content_task_history','content_publish_prepare','content_publish_confirm','content_publish_read','content_publish_reconcile'})
CONTENT_MODULE_SHA = '9e6687af1ea74244a3add283fc8bf72b1c25a6a3f9394483c02895cfe5dc24c6'
CONTENT_EXTENSION_LOADER_SHA = '52403b4cf00aa9de3427676263bc6dec8d3fd018dd939238be95ee741239b3af'
CONTENT_EXTENSION_PINS = {
    'content_workbench.py': CONTENT_MODULE_SHA,
    'publishing_dom_methods.py': 'e03af4798da73f663f0e4328b2ac87c2b742514a2077ab8d63f4f0f0e7112809',
    'publishing_port.py': '2de921ff45db4fa1e36e43547d0eba6921e9e47902c9f796cbd653c233f35c2f',
    'content_publishing.py': 'cd05237aef77ec6c3412da835c7477a0c2c5fe694d4d413e840ca56be6905590',
    'publication_protocol.py': 'ddb2a33dc225ee1d79ed373396c7acbea8ec8b454b3aac961ff1107589774788',
    'publication_authority_host.py': '85372eba5481a9fb5dedb420817b30599d7b78b7f4480abed62106571acfd5f1',
    'owned_publication_host.py': '72b6587a5d17742d527a808a3c5d8a516f677e23655a70e73686e48d4145e607',
    'publication_policy.py': '1f96b23b2daf5e6e227d0b1429e3680cafbc83b59aff83c80a964011aee56443',
    'content_workflow.py': '071cbd786b4b4a7561247604c0cee43c13e24c62b0feaf8ce13756e07a7634e9',
    'workflow_methods.py': '0965296e716aa3e79c96bfaba2b5b0adb00b42b06535eb71a2c0759a0f806707',
    'workflow_knowledge.py': 'bddb66dc33dfa592fa52cb3bca767bdd8fb8ccc4d4925f0ed4b7fa0174df4afc',
}
CONTENT_GATEWAY_PINS = {
    'gateway_adapter.py': '126bd07674ea39cf5c0bfd2016fba5820c28f98640f6463aabbacb6a52a6a428',
    'trusted_method_pins.py': '234a26e788ee717d3645732a6a7a90404aaf0e6eb59c7010f24e2f5192e50f13',
}


class WorkbenchError(ValueError):
    def __init__(self, code, message, status=400):
        super().__init__(message)
        self.code, self.status = code, status


class _CloudServiceUnavailable(IntegrationError):
    code = 'CLOUD_SERVICE_UNAVAILABLE'
    status = http_status = 503

    def __init__(self):
        super().__init__('企业登录云服务因余额不足暂停，请联系企业管理员恢复服务后手动重试')


def _classify_cloud_failure(error):
    # The pinned integration retains the original failed response as context.
    # Inspect that response once; never probe/retry or publish provider details.
    response = error.__context__
    if not isinstance(response, HTTPError) or response.code != 400:
        return error
    try:
        raw = response.read(8193)
        if len(raw) > 8192:
            return error
        body = json.loads(raw)
        if not isinstance(body, dict):
            return error
        for key in ('error', 'errorMessage'):
            message = body.get(key)
            if (isinstance(message, str) and 'Function is Unavailable' in message
                    and re.search(r'\bAvailableStatus\s*=\s*InsufficientBalance\b', message)):
                return _CloudServiceUnavailable()
    except (OSError, ValueError, TypeError):
        pass
    return error


class _ProfileIntegrations(Integrations):
    """Retain the verified public me projection without a second cloud request."""
    def enter(self, *args, **kwargs):
        try:
            return super().enter(*args, **kwargs)
        except IntegrationError as error:
            raise _classify_cloud_failure(error) from None

    def _cloud(self, deployment_config, user, operation, **data):
        try:
            result = super()._cloud(deployment_config, user, operation, **data)
        except IntegrationError as error:
            failure = _classify_cloud_failure(error)
            if operation == 'me':
                # Legacy verify_identity intentionally returns None for any
                # IntegrationError. Preserve its safe HTTP classification so a
                # temporary outage cannot be mistaken for revoked authority.
                self.last_verification_error = failure
            raise failure from None
        if operation == 'me':
            self.last_verified_profile = deepcopy(result.get('user'))
        return result

class _ReadOnlyDeliveryIntegrations(_ProfileIntegrations):
    """Independent verification lock; never renew or write a DPAPI session.

    Queue validation runs under Core.lock. Reusing the login verifier here would
    invert its Integrations.lock -> Core.lock order. Expiry stops the queue.
    """
    def _refresh_session(self,config,user):
        session=config.get('sessions',{}).get(user['id'],{})
        if not session.get('token') or float(session.get('expires',0))<=time.time():
            error=IntegrationError('企业会话已过期，本批已停止，请重新登录后核对')
            error.http_status=401
            raise error
        return dict(session)


class _MediaReadIntegrations(_ReadOnlyDeliveryIntegrations):
    """Fresh media-only authority, for both existing employee/admin roles.

    Never refresh credentials or rewrite local user/role state in background.
    A role change fails closed and is reconciled by the foreground path.
    """
    def verify_identity(self,user,expected_user=None):
        expected=expected_user or user
        try:
            profile=self._cloud(self._read(user['tenant_id']),user,'me')['user']
            current=self.core.store.get('users',user['id'])
            if (not current or current.get('disabled') or profile.get('disabled')
                    or current.get('cloud_bound') is not True
                    or current.get('role') not in ('operator','admin')
                    or any(current.get(key)!=expected.get(key) for key in
                        ('id','tenant_id','username','role','cloud_bound'))
                    or profile.get('username')!=current.get('username')
                    or profile.get('role')!=current.get('role')):
                return None
            return self.core._public(current)
        except (IntegrationError,KeyError,TypeError):
            return None


def _digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
        separators=(',', ':'), allow_nan=False).encode('utf-8')).hexdigest()


def _stamp():
    return datetime.now(timezone.utc).isoformat()


def _optional_platform(data):
    if 'platform' not in data:
        return None
    value=data['platform']
    if type(value) is not str or value not in ('xiaohongshu','douyin'):
        raise WorkbenchError('PLATFORM_INVALID','请选择小红书或抖音',400)
    return value


def _deny_cloud(*args, **kwargs):
    raise WorkbenchError('ACTION_NOT_AVAILABLE', '当前批次未接入 AI 或发送', 403)


class WorkbenchBackend:
    def __init__(self, project_root, data_dir=None, company=None, *, core_factory=Core,
                 integrations_factory=_ProfileIntegrations, workflow_factory=LocalAIWorkflow,
                 rules_factory=IntentRuleManagement, platform_factory=None, customer_factory=None, keyword_factory=None,
                 customer_intent_factory=None, knowledge_file_preview_factory=None, media_factory=None, outcomes_factory=None, public_contacts_factory=None,
                 materials_factory=None, rental_factory=None, reply_factory=None, delivery_factory=None, remote_factory=None, dm_factory=None,
                 content_model_adapter=None, publication_factory=None):
        self.project_root = Path(project_root).resolve()
        if company is None:
            try:
                company = json.loads((self.project_root / 'work/app/company.json').read_text('utf-8-sig'))
            except (OSError, ValueError):
                raise WorkbenchError('CONFIG_UNAVAILABLE', '企业登录配置暂不可读，请联系管理员', 503) from None
        company = deepcopy(company)
        managed = company.get('managedWorkspace') if isinstance(company, dict) else None
        if (not isinstance(company, dict) or company.get('id') != COMPANY_ID
                or company.get('edition') != 'customer' or company.get('personalMode') is not False
                or company.get('authMode') != 'managed' or not isinstance(managed, dict)
                or not managed.get('environment_id') or not managed.get('endpoint')):
            raise WorkbenchError('CONFIG_INVALID', '此入口需要方隅客户企业登录配置', 503)
        self.company = company
        self.data_dir = Path(data_dir).resolve() if data_dir is not None else (
            Path(os.environ.get('LOCALAPPDATA', Path.home() / 'AppData/Local')) /
            (COMPANY_ID + 'Workspace')).resolve()
        self.lock = threading.RLock()
        if content_model_adapter is not None and not callable(content_model_adapter):
            raise WorkbenchError('CONTENT_MODEL_CONFIG_INVALID','内容模型宿主接口配置无效',503)
        # A trusted host supplies this callable. Browser inputs cannot select an
        # adapter, endpoint or credential. None deliberately means unavailable.
        self._content_model_adapter = content_model_adapter
        if publication_factory is not None and not callable(publication_factory):
            raise WorkbenchError('PUBLISH_HOST_UNAVAILABLE','发布宿主配置无效',503)
        self._content_publication_factory=publication_factory
        self._content_publication_host=None
        self.platform_runtime = (platform_factory(project_root=self.project_root,
            data_dir=self.data_dir, company=deepcopy(company)) if platform_factory else None)
        self.core = self.platform_runtime.core if self.platform_runtime else core_factory(self.data_dir,
            self.project_root / 'work/ui-runtime-r55/src/resources', defer_startup_recovery=True)
        self.core.deployment_config = deepcopy(company)
        self.integrations = integrations_factory(self.core)
        self.customer_workbench = (customer_factory(self.core, deepcopy(company), self.project_root)
                                   if customer_factory else None)
        self.customer_intent_factory = customer_intent_factory
        self.knowledge_file_preview_factory = knowledge_file_preview_factory
        self.outcomes_factory = outcomes_factory
        self.public_contacts_factory = public_contacts_factory
        self.keyword_effect_workbench = (keyword_factory(self.core,self.customer_workbench)
                                         if keyword_factory and self.customer_workbench else None)
        self.reply_workbench = (reply_factory(self.core,self.customer_workbench)
                                if reply_factory and self.customer_workbench else None)
        if reply_factory is None and self.customer_workbench is not None:
            from reply_workbench import ReplyWorkbench
            self.reply_workbench = ReplyWorkbench(self.core,self.customer_workbench)
        self.delivery_integrations=_ReadOnlyDeliveryIntegrations(self.core)
        self.reply_delivery=None
        if self.reply_workbench is not None:
            if delivery_factory is None:
                from reply_delivery import ReplyDelivery
                delivery_factory=ReplyDelivery
            self.reply_delivery=delivery_factory(self.core,self.reply_workbench,self.platform_runtime)
        self.dm_workbench = (dm_factory(self.core,self.platform_runtime,self.reply_workbench,self.reply_delivery) if dm_factory else None)
        self.workflow = workflow_factory(self.core, _deny_cloud, company=deepcopy(company))
        self.rules_factory = rules_factory
        if materials_factory is None:
            from store_materials import StoreMaterials
            materials_factory = StoreMaterials
        if rental_factory is None:
            from rental_assessment import RentalAssessmentService
            rental_factory = RentalAssessmentService
        self.materials = materials_factory(self.core)
        self.rental_factory = rental_factory
        if self.customer_workbench is not None:
            self.customer_workbench.rental_reader = self._read_rental_assessment
            self.customer_workbench.rental_batch_reader = self._read_rental_assessments
        if self.platform_runtime is not None:
            self.platform_runtime._rental_after_import = self._assess_imported
        self.media_workbench = media_factory(self) if media_factory else None
        self.central_configs = {}
        self.closed = False
        self.remote_management = remote_factory(self) if remote_factory else None

    def close(self):
        if not self.closed:
            self.closed = True
            if self.dm_workbench is not None:self.dm_workbench.close()
            if self.media_workbench is not None:self.media_workbench.close()
            if self._content_publication_host is not None:
                self._content_publication_host.close()
            if self.platform_runtime is not None:
                self.platform_runtime.close()
            else:
                self.core.adapters.close()

    def content_video(self,token,data,range_header=""):
        if self.media_workbench is None:raise WorkbenchError("MEDIA_UNAVAILABLE","视频制作组件尚未安装",503)
        return self.media_workbench.video(token,data,range_header)

    def media(self,token,data):
        if (not isinstance(data,dict) or set(data)!={'storeId','leadId','kind'}
                or not isinstance(data.get('storeId'),str) or not STORE_ID.fullmatch(data['storeId'])
                or not isinstance(data.get('leadId'),str)
                or not re.fullmatch(r'(?:[0-9a-fA-F]{32}|[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12})',data['leadId'])
                or data.get('kind') not in ('author','post_author','cover')):
            raise WorkbenchError('INVALID_INPUT','图片来源参数无效',400)
        # Images must not hold the foreground lock while verifying over the
        # network. Each request has its own fresh verifier, with no token renew
        # or shared mutable identity cache. Public actions keep their verifier.
        if self.closed:raise WorkbenchError('BACKEND_CLOSED','本地服务已关闭',503)
        user,profile=self._identity(token,verification=_MediaReadIntegrations(self.core))
        def current_scope():
            if self.closed:raise WorkbenchError('BACKEND_CLOSED','本地服务已关闭',503)
            current=self.core.session(token)
            if (not current or current.get('disabled')
                    or any(current.get(key)!=user.get(key) for key in
                        ('id','tenant_id','username','role','cloud_bound'))):
                raise WorkbenchError('AUTH_REQUIRED','员工登录已变化，请重新读取',401)
            # No _selected_store here: that helper activates central rules and
            # performs network I/O. Media only needs the exact visible scope.
            if data['storeId']!=self._load_selection(current,self._stores(profile))['storeId']:
                raise WorkbenchError('STORE_FORBIDDEN','不能读取其他门店的图片',403)
        with self.lock:current_scope()
        result=self.customer_workbench.media(user,data['storeId'],data['leadId'],data['kind'])
        with self.lock:current_scope()
        return result

    def _remembered(self):
        row = self.core.store.get(ENTITY, 'remembered-username')
        return row.get('username', '') if row and row.get('tenant_id') == COMPANY_ID else ''

    def _remember(self, username):
        self.core.store.put(ENTITY, {'id': 'remembered-username', 'tenant_id': COMPANY_ID,
                                    'username': username, 'updated_at': _stamp()})

    def _identity(self, token, *, verification=None):
        integration=verification or self.integrations
        user = self.core.session(token)
        if not user or user.get('cloud_bound') is not True or user.get('role') not in ('operator', 'admin'):
            raise WorkbenchError('AUTH_REQUIRED', '请先使用企业员工账号登录', 401)
        # Every API request refreshes authority; an earlier cached me result
        # cannot authorize a later store selection or local write.
        integration.identity_cache.pop(user['id'], None)
        integration.last_verified_profile = None
        integration.last_verification_error = None
        verified = (integration.verify_identity(user,expected_user=user) if verification is not None
                    else integration.verify_identity(user))
        failure = integration.last_verification_error
        if isinstance(failure, _CloudServiceUnavailable):
            raise WorkbenchError(failure.code, str(failure), failure.status) from None
        if failure is not None and getattr(failure, 'http_status', None) not in (401, 403):
            raise WorkbenchError('AUTH_SERVICE_UNAVAILABLE',
                                 '企业身份服务暂不可用，已保留本机登录，请稍后手动重试', 503)
        if not verified or verified.get('role') not in ('operator', 'admin'):
            raise WorkbenchError('AUTH_REQUIRED', '员工登录已失效，请重新登录', 401)
        profile = integration.last_verified_profile
        if profile is None:  # Allows a factory using the original integration.
            config = integration._read(verified['tenant_id'])
            profile = integration._cloud(config, verified, 'me').get('user')
        if (not isinstance(profile, dict) or profile.get('username') != verified['username']
                or profile.get('role') != verified.get('role') or profile.get('disabled')):
            raise WorkbenchError('AUTH_REQUIRED', '员工身份需重新核对', 401)
        profile = deepcopy(profile)
        rows, directory_notice, central_directory = self._read_store_directory(integration, verified)
        profile['_workbench_stores'] = rows
        profile['_workbench_directory_notice'] = directory_notice
        profile['_central_directory'] = central_directory
        stores = self._stores(profile)
        selected = self._load_selection(verified, stores)['storeId']
        verified = {**verified, '_workbench_store_id':selected}
        profile['_workbench_store_id'] = selected
        return verified, profile

    def _read_store_directory(self, integration, user):
        """The central server scope is the only directory authority, including for operators."""
        try:
            config=integration._read(user['tenant_id'])
            response=integration._cloud(config,user,'store_config_read')
        except IntegrationError:
            return [],'已登录；中央门店目录尚未发布或暂不可读，保留无授权空态',None
        actor=response.get('actor') or {}; scope=response.get('scope') or {}
        rows=response.get('stores')
        valid=(response.get('contract')=='fangyu-workspace-v1' and response.get('company_id')==COMPANY_ID
            and response.get('environment_id')==self.company['managedWorkspace']['environment_id']
            and response.get('schema')=='store-config-v1' and response.get('read_only') is True
            and actor.get('username')==user['username'] and actor.get('role')==user['role']
            and scope.get('type')==('company' if user['role']=='admin' else 'store')
            and isinstance(scope.get('store_ids'),list) and isinstance(rows,list)
            and len({row.get('id') for row in rows if isinstance(row,dict)})==len(rows)
            and all(isinstance(row,dict) and isinstance(row.get('id'),str) and STORE_ID.fullmatch(row['id'])
                and row['id'] in scope['store_ids'] and isinstance(row.get('name'),str) for row in rows)
            and all(isinstance(row.get(key,''),str) and len(row.get(key,''))<=100
                and not any(ord(char)<32 for char in row.get(key,''))
                for row in rows for key in ('city','district'))
            and set(scope['store_ids'])=={row['id'] for row in rows}
            and isinstance(response.get('catalog_revision'),str)
            and isinstance(response.get('catalog_digest'),str) and re.fullmatch('[a-f0-9]{64}',response['catalog_digest']))
        if not valid:return [],'已登录；中央门店授权目录未通过核对',None
        stores=[{'id':row['id'],'name':row['name'],'description':row.get('district') or row.get('city') or '中央门店资料组',
            'region':row.get('district') or row.get('city') or '',
            'city':row.get('city',''),'area':row.get('district',''), 'materialKey':row.get('materialKey'),
            'status':row.get('status'),'configDigest':row.get('config_digest')} for row in rows]
        return stores,('当前账号未授予中央门店' if not stores else ''),response

    def _stores(self, profile):
        return deepcopy(profile.get('_workbench_stores', []))

    def _activate_central_config(self, user, profile, store_id, integration=None):
        if store_id not in {row['id'] for row in self._stores(profile)}:
            raise WorkbenchError('STORE_FORBIDDEN','中央门店授权已变化',403)
        integration=integration or self.integrations
        try:
            response=integration._cloud(integration._read(user['tenant_id']),user,'store_config_read',store_id=store_id)
        except IntegrationError:
            raise WorkbenchError('WORKSPACE_DATA_UNAVAILABLE','已登录；当前门店中央配置暂不可读，保留本机选择但停止业务操作',503) from None
        directory=profile.get('_central_directory') or {};config=response.get('config')
        actor=response.get('actor') or {};scope=response.get('scope') or {}
        if (response.get('contract')!='fangyu-workspace-v1' or response.get('company_id')!=COMPANY_ID
                or response.get('environment_id')!=self.company['managedWorkspace']['environment_id']
                or response.get('schema')!='store-config-v1' or response.get('read_only') is not True
                or actor.get('username')!=user['username'] or actor.get('role')!=user['role']
                or store_id not in scope.get('store_ids',[]) or response.get('store_id')!=store_id
                or response.get('catalog_revision')!=directory.get('catalog_revision')
                or response.get('catalog_digest')!=directory.get('catalog_digest')
                or not isinstance(config,dict) or config.get('store_id')!=store_id
                or response.get('config_digest')!=_digest(config)
                or response.get('config_digest')!=next((row.get('config_digest') for row in directory.get('stores',[]) if row.get('id')==store_id),None)):
            raise WorkbenchError('WORKSPACE_DATA_UNAVAILABLE','中央门店配置或授权版本已变化，请重新加载',503)
        metadata={'revision':response['catalog_revision'],'catalogDigest':response['catalog_digest'],
            'configDigest':response['config_digest'],'sourceVersions':response.get('source_versions')}
        self.materials.use_central_config(config,metadata)
        self.central_configs[store_id]=deepcopy(config)
        return config

    def _store_preference(self, user, store_id, db=None):
        ident=_digest(['store-preset-v2',COMPANY_ID,user['tenant_id'],user['username'],store_id])
        if db is None:row=self.core.store.get(STORE_PREF_ENTITY,ident)
        else:
            found=db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
                (STORE_PREF_ENTITY,ident,user['tenant_id'])).fetchone()
            row=json.loads(found['body']) if found else None
        if row and (row.get('storeId')!=store_id or row.get('owner')!=user['username'] or row.get('tenant_id')!=user['tenant_id']):
            raise WorkbenchError('PREFERENCE_SCOPE_INVALID','门店偏好归属未通过核对',409)
        return ident,row

    def _preference_id(self, user):
        return _digest(['workbench-preset-v1', COMPANY_ID, user['tenant_id'], user['username']])

    def _load_selection(self, user, stores, db=None):
        ident = self._preference_id(user)
        if db is None:
            row = self.core.store.get(ENTITY, ident)
        else:
            found = db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
                (ENTITY, ident, user['tenant_id'])).fetchone()
            row = json.loads(found['body']) if found else None
        if row and (row.get('owner') != user['username'] or row.get('tenant_id') != user['tenant_id']
                    or row.get('company_id') != COMPANY_ID):
            raise WorkbenchError('PREFERENCE_SCOPE_INVALID', '门店预设归属无法核对', 409)
        revision = row.get('revision', 0) if row else 0
        if type(revision) is not int or revision < 0:
            raise WorkbenchError('PREFERENCE_INVALID', '门店预设版本无法核对', 409)
        allowed = {store['id'] for store in stores}
        selection = {'storeId': stores[0]['id'] if stores and user.get('role') == 'operator' else '', 'searchPresetId': 'precise',
                     'intentPresetId': 'standard', 'revision': revision, 'applied': None, 'savedAt': None}
        if row and row.get('storeId') in allowed:
            if row.get('searchPresetId') not in SEARCH_IDS or row.get('intentPresetId') not in INTENT_IDS:
                raise WorkbenchError('PREFERENCE_INVALID', '门店预设方案无法核对', 409)
            for key in selection:
                selection[key] = deepcopy(row.get(key, selection[key]))
        if selection['storeId']:
            _, per_store=self._store_preference(user,selection['storeId'],db)
            if per_store:
                for key in ('searchPresetId','intentPresetId','applied','savedAt'):
                    selection[key]=deepcopy(per_store.get(key,selection[key]))
            else:
                selection.update(searchPresetId='precise',intentPresetId='standard',applied=None,savedAt=None)
        return selection

    def _catalog(self, user=None, store_id=None, material_selection=None):
        if user:
            if not store_id:return {'search':[],'intent':[]}
            if (getattr(self.materials,'central',None) or {}).get('storeId')!=store_id:
                raise WorkbenchError('WORKSPACE_DATA_UNAVAILABLE','请先加载当前门店中央配置',503)
            chosen=material_selection if material_selection is not None else self.materials.read_selection(user,store_id)
            search=[{'id':'precise','name':'精准获客','keywords':[]}, {'id':'commute','name':'通勤拓展','keywords':[]}]
            self._bind_material_search(search,chosen,store_id)
            for item in search:
                effective=(self.materials.runtime_search or {}) if store_id=='fy_s_d343f3a378f48e1bab55df4f' else (self.central_configs[store_id].get('runtimeSearch') or {})
                item['excludeTerms']=deepcopy(effective.get('excludeTerms',[]))
                item['acquisitionPolicy']=deepcopy((self.materials.central or {}).get('localApprovedOverride'))
            rule=self._assessment_policy(store_id)
            enabled=rule['supported'] and rule.get('enabled') is True
            reference={**deepcopy(self.materials.central),'source':'central_store_config','runtimeAssessment':deepcopy(rule)}
            intent=[{'id':'standard','name':'标准意向','description':'综合显示当前求租与预算证据，历史评级保留','policyReference':reference,'assessmentEnabled':enabled},
                {'id':'recent','name':'优先近期入住','description':'优先显示近期入住，基础判断仍使用中央已支持执行契约','policyReference':reference,'assessmentEnabled':enabled},
                {'id':'rental-evidence','name':'租房与预算','description':('初始规则需人工校准，预算与收入独立判断；门店价格待核。' if enabled else '执行契约未支持，需要升级判断引擎。'),
                    'policyReference':reference,'assessmentEnabled':enabled,'runtimeAssessment':deepcopy(rule)}]
            return {'search':search,'intent':intent}
        return {'search': [], 'intent': []}

    @staticmethod
    def _bind_material_search(search, chosen, store_id):
        """Pure projection, safe inside the material/preferences transaction."""
        reference = {'id': chosen['materialKey'], 'revision': chosen['revision'],
            'digest': chosen['catalogDigest'], 'version': chosen['materialVersion'],
            'storeId': store_id, 'bindingConfirmed': chosen['currentBindingConfirmed'],
            'profileDigest':chosen.get('profileDigest')}
        for item in search:
            preset = chosen['searchPresets'][item['id']]
            item.update(keywords=list(preset['keywords']), source='confirmed_store_materials',
                libraryReference=deepcopy(reference), sourceBindings=deepcopy(preset['sourceBindings']),
                templateSupplement=[], materialName=chosen['source_material_name'],
                needsReapply=chosen['needsReapply'],automaticProfile=chosen.get('automaticProfile',False),
                profileDigest=chosen.get('profileDigest'),totalEligible=len(preset['keywords']),runLimit=100)

    def _current_preset(self, catalog, selection, applied_at):
        """Project validated current store inputs; never execute a stored old copy.

        The employee's chosen search/intent IDs remain unchanged. This is a
        local read projection, not a cloud edit, material rebinding or an
        implicit start. Admission and request reservation still follow it.
        """
        search = next((row for row in catalog['search'] if row['id'] == selection['searchPresetId']), None)
        intent = next((row for row in catalog['intent'] if row['id'] == selection['intentPresetId']), None)
        if search is None or intent is None:
            raise WorkbenchError('WORKSPACE_DATA_UNAVAILABLE', '正在更新门店配置，请稍后开始', 503)
        if not search['keywords'] or (len(search['keywords']) > 100 and not search.get('automaticProfile')):
            raise WorkbenchError('KEYWORDS_REQUIRED', '这家门店暂没有可用的搜索词，门店配置完成后即可开始', 409)
        reference = deepcopy(search.get('libraryReference') or {})
        return {'selectedKeywords': list(search['keywords']), 'keywordSource': search['source'],
            'excludeTerms':deepcopy(search.get('excludeTerms',[])),
            'libraryReference': reference, 'templateSupplement': deepcopy(search.get('templateSupplement', [])),
            'policyReference': deepcopy(intent['policyReference']), 'intentPreference': intent['id'],
            'appliedAt': applied_at, 'startsCollection': False, 'changesIntentPolicy': False,
            'sourceBindings': deepcopy(search.get('sourceBindings', [])),
            'rentalAssessmentEnabled': intent.get('assessmentEnabled') is True,
            'profileDigest': search.get('profileDigest'), 'automaticProfile': search.get('automaticProfile', False),
            'materialKey': reference.get('id') if search['source'] == 'confirmed_store_materials' else None,
            'centralVersion': deepcopy(self.materials.central)}

    def _bootstrap(self, token='', *, identity=None):
        user, profile, notice = None, None, ''
        if identity is not None:
            user, profile = identity
        elif token:
            try:
                user, profile = self._identity(token)
            except WorkbenchError as error:
                if error.code in ('AUTH_SERVICE_UNAVAILABLE', 'CLOUD_SERVICE_UNAVAILABLE'):
                    raise
                notice = '登录已失效或企业身份暂未确认，请重新登录'
        stores = self._stores(profile) if profile else []
        try:
            selection = self._load_selection(user, stores) if user else {
                'storeId': '', 'searchPresetId': 'precise', 'intentPresetId': 'standard',
                'revision': 0, 'applied': None, 'savedAt': None}
            user = {**user, '_workbench_store_id':selection['storeId']} if user else None
            if user and selection['storeId']:
                self._activate_central_config(user,profile,selection['storeId'])
                applied=selection.get('applied')
                if applied and applied.get('centralVersion')!=self.materials.central:
                    selection['applied']=None
            catalog = self._catalog(user, selection['storeId'])
            materials = self.materials.catalog(user, stores, selection) if user and selection['storeId'] else None
            if materials is not None:
                # The desktop host injects the hash-verified rental factory
                # under its frozen module name; never import a second copy.
                overview_reader = getattr(self.rental_factory, 'rule_overview', None)
                materials['localAssessmentOverview'] = (overview_reader() if callable(overview_reader)
                    else {'source': 'unavailable'})
                # Use the existing public read: private criteria stay behind
                # its manager check; never serialize SERVER ONLY snapshots.
                try:
                    saved_rules = self.rules_factory(self.core,user['tenant_id'],user['username'],self.company).execute('intent_rules_get',{},user)
                    summary = saved_rules.get('summary') or {}
                    overview = {'source':'local_evidence_policy','revision':summary.get('revision'),
                        'digest':summary.get('digest'),'can_manage':summary.get('can_manage') is True,
                        'providerCriteriaSource':'server','providerPromptAvailable':False}
                    if overview['can_manage'] and isinstance(saved_rules.get('policy'),dict):
                        overview['criteria']=deepcopy(saved_rules['policy'].get('criteria',{}))
                    materials['intentPolicyOverview']=overview
                except (ValueError,OSError):
                    materials['intentPolicyOverview']={'source':'unavailable','providerPromptAvailable':False}
        except (OSError, ValueError, KeyError, TypeError) as error:
            if user is None or getattr(error, 'status', None) in (401, 403):
                raise
            # Authentication has already succeeded. Unreadable business data
            # cannot revoke it, or be replaced by writable default preferences.
            message = '已登录；门店资料暂未加载，请重新加载后再应用预设或开始采集'
            return {'session': {'user': {'username': user['username'], 'role': user['role']}},
                'rememberedUsername': self._remembered(), 'stores': stores, 'selection': None,
                'catalog': {'search': [], 'intent': []}, 'materials': None,
                'capabilities': {'presets': False, 'platforms': self.platform_runtime is not None,
                    'customers': self.customer_workbench is not None, 'materials': False,
                    'rentalAssessment': False, 'reason': message},
                'workspaceError': {'code': 'WORKSPACE_DATA_UNAVAILABLE', 'message': message},
                'notice': message}
        result = {'session': {'user': {'username': user['username'], 'role': user['role']}} if user else None,
                  'rememberedUsername': self._remembered(), 'stores': stores,
                  'selection': selection, 'catalog': catalog,
                  'materials': materials,
                  'capabilities': {'presets': bool(user and selection['storeId']),
                      'platforms': self.platform_runtime is not None,
                      'customers': self.customer_workbench is not None, 'materials': bool(user and selection['storeId']),
                      'rentalAssessment': bool(user and selection['storeId']),
                      'reason': '' if user and selection['storeId'] else ('请先明确选择云端已绑定门店分组' if stores else '云端暂无已绑定门店分组，请在原管理后台核对成员门店') if user else '请先登录'},
                  'notice': notice or (profile or {}).get('_workbench_directory_notice','')}
        return result

    def _selected_store(self, user, profile):
        selected = self._load_selection(user, self._stores(profile))['storeId']
        if not selected:
            raise WorkbenchError('STORE_REQUIRED', '请先明确选择云端已绑定门店分组', 403)
        self._activate_central_config(user,profile,selected)
        return selected

    @staticmethod
    def _tone_values_valid(data, *, saved=False):
        def line(value, maximum, required=False):
            return (isinstance(value,str) and len(value)<=maximum and (not required or bool(value.strip()))
                and not any(unicodedata.category(char) in ('Cc','Cf','Cs','Zl','Zp') for char in value))
        templates=data.get('templates',{'employee':'','customer':''})
        if (not isinstance(templates,dict) or set(templates)!={'employee','customer'}
                or any(not isinstance(v,str) or len(v)>1000 or any(unicodedata.category(c) in ('Cf','Cs') or ord(c)<32 and c not in '\n\t\r' for c in v) for v in templates.values())):return False
        focus=data.get('focus')
        return (line(data.get('identity'),80,required=saved) and line(data.get('salutation'),20)
            and data.get('tone') in ('friendly','concise','patient') and isinstance(focus,list)
            and all(isinstance(item,str) and item in ('budget','moveIn','housing') for item in focus)
            and len(focus)==len(set(focus)))

    def _voice_sample_component(self):
        """Load only the reviewed customer component, under the release pins."""
        import importlib.util
        import stat
        import sys
        base=Path(__file__).absolute().parent
        frozen=base/'resources/voice-samples/voice_samples.py'
        path=frozen if frozen.exists() else base/'voice_samples.py'
        try:
            for item in (path,*path.parents):
                info=item.lstat()
                if item.is_symlink() or getattr(info,'st_file_attributes',0)&0x400:
                    raise ValueError('linked component')
            before=path.stat();raw=path.read_bytes();after=path.stat()
            if (not stat.S_ISREG(before.st_mode) or before.st_nlink!=1
                    or (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns)
                    !=(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns)
                    or hashlib.sha256(raw).hexdigest()!=VOICE_SAMPLE_MODULE_SHA):
                raise ValueError('component changed')
            name='fangyu_voice_samples_'+VOICE_SAMPLE_MODULE_SHA[:16]
            module=sys.modules.get(name)
            if module is None:
                module=importlib.util.module_from_spec(importlib.util.spec_from_loader(name,loader=None))
                module.__file__=str(path);sys.modules[name]=module
                try:exec(compile(raw,str(path),'exec'),module.__dict__)
                except BaseException:
                    sys.modules.pop(name,None);raise
            return module,path.parent/'voice_samples_vendor'
        except (OSError,ValueError,TypeError):
            raise WorkbenchError('VOICE_COMPONENT_UNAVAILABLE','语气样本组件尚未完整装入当前版本，请正常更新后重开',503) from None

    def _voice_samples_dispatch(self,action,data,token):
        base={'storeId','accountId','platform'}
        required=base|({'expectedRevision','label','text'} if action=='voice_samples_save'
            else {'sopRole'} if action=='voice_samples_context' else set())
        allowed=required|({'title','sampleId'} if action=='voice_samples_save' else set())
        if (not isinstance(data,dict) or not required<=set(data) or set(data)-allowed
                or not isinstance(data.get('storeId'),str) or not STORE_ID.fullmatch(data['storeId'])
                or not isinstance(data.get('accountId'),str)
                or not re.fullmatch(r'[A-Za-z0-9_-]{1,160}',data['accountId'])
                or data.get('platform') not in ('xiaohongshu','douyin')):
            raise WorkbenchError('INPUT_INVALID','请选择当前门店和发送账号')
        if action=='voice_samples_context' and data.get('sopRole') not in ('employee','customer'):
            raise WorkbenchError('INPUT_INVALID','请选择员工或客户SOP')
        try:
            with self.lock:
                user,profile=self._identity(token)
                stores=self._stores(profile)
                store_id=self._selected_store(user,profile)
                if data['storeId']!=store_id:
                    raise WorkbenchError('STORE_FORBIDDEN','当前门店已变化，请重新读取语气样本',403)
                if action=='voice_samples_save' and (user.get('role')!='admin' or profile.get('role')!='admin'):
                    raise WorkbenchError('VOICE_ADMIN_REQUIRED','只有管理员可以维护账号语气样本',403)
                account=self.core.store.get('accounts',data['accountId'])
                if (not isinstance(account,dict) or account.get('tenant_id')!=user['tenant_id']
                        or account.get('cloud_owner')!=user['username']
                        or account.get('platform')!=data['platform'] or account.get('store_id')!=store_id):
                    raise WorkbenchError('ACCOUNT_FORBIDDEN','发送账号不属于当前员工或门店',403)
                self.core._account_access(user,account)
                module,vendor=self._voice_sample_component()
                scope=module.VoiceScope(user['tenant_id'],store_id,account['id'],account['platform'])
                def authority(db,actor,bound_scope,save):
                    session=db.execute('SELECT user_id FROM sessions WHERE token=? AND expires>?',
                        (hashlib.sha256(token.encode()).hexdigest(),time.time())).fetchone()
                    return (not self.closed and session is not None and session['user_id']==actor['id']
                        and self._load_selection(actor,stores,db)['storeId']==bound_scope.store_id
                        and (not save or profile.get('role')=='admin'))
                library=module.VoiceSampleLibrary(self.core.store,vendor_dir=vendor,authority_check=authority)
                actor={'username':user['username'],'storeId':store_id,'accountId':account['id'],
                    'platform':account['platform']}
                if action=='voice_samples_context':
                    preferences=self._tone_preferences(user,profile,{'storeId':store_id},token,save=False)['preferences']
                    sop=preferences['templates'][data['sopRole']]
                    if not isinstance(sop,str) or not sop.strip():
                        raise WorkbenchError('VOICE_SOP_NOT_CONFIGURED','公司尚未配置这套SOP，请到管理中填写',409)
                    card=library.context(user,scope,sop.strip())
                    return {'voiceContext':{**card,'actor':actor,'sopRole':data['sopRole'],
                        'sopRevision':preferences['revision']}}
                if action=='voice_samples_save':
                    request={'expected_revision':data['expectedRevision'],'label':data['label'],'text':data['text']}
                    if 'title' in data:request['title']=data['title']
                    if 'sampleId' in data:request['sample_id']=data['sampleId']
                    result=library.save(user,scope,request)
                else:result=library.read(user,scope)
                return {'voiceSamples':{**result,'actor':actor,
                    'canSave':user.get('role')=='admin' and profile.get('role')=='admin'}}
        except WorkbenchError:
            raise
        except Exception as error:
            code,status=getattr(error,'code',None),getattr(error,'status',503)
            if isinstance(code,str) and type(status) is int and status in (400,401,403,409,422,503):
                raise WorkbenchError(code,str(error),status) from None
            raise WorkbenchError('VOICE_SAMPLES_UNAVAILABLE','语气样本暂不可读，原SOP和草稿已保留',503) from None

    def _tone_preferences(self, user, profile, data, token, *, save):
        fields={'storeId','expectedRevision','identity','tone','salutation','focus'} if save else {'storeId'}
        if (set(data)-{'templates'}!=fields or not isinstance(data.get('storeId'),str)
                or not STORE_ID.fullmatch(data['storeId'])
                or save and (type(data.get('expectedRevision')) is not int or data['expectedRevision']<0
                    or not self._tone_values_valid(data,saved=True))):
            raise WorkbenchError('INPUT_INVALID','IP口吻参数格式无效，请核对身份、称呼和关注项')
        if save and (user.get('role')!='admin' or profile.get('role')!='admin'):
            raise WorkbenchError('ADMIN_REQUIRED','只有当前企业管理员可以保存IP口吻',403)
        store_id=self._selected_store(user,profile)
        if data['storeId']!=store_id:
            raise WorkbenchError('STORE_FORBIDDEN','当前门店已变化，请重新读取IP口吻',403)
        ident=_digest(['tone-preferences-v1',COMPANY_ID,user['tenant_id'],store_id])
        with self.core.lock,self.core.store.connect() as db:
            db.execute('BEGIN IMMEDIATE' if save else 'BEGIN')
            session=db.execute('SELECT user_id FROM sessions WHERE token=? AND expires>?',
                (hashlib.sha256(token.encode()).hexdigest(),time.time())).fetchone()
            actor=db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
                ('users',user['id'],user['tenant_id'])).fetchone()
            actor=json.loads(actor['body']) if actor else {}
            if (self.closed or not session or session['user_id']!=user['id'] or actor.get('disabled')
                    or actor.get('cloud_bound') is not True or any(actor.get(key)!=user.get(key)
                        for key in ('id','tenant_id','username','role'))):
                raise WorkbenchError('AUTH_REQUIRED','员工会话或权限已变化，请重新登录',401)
            if self._load_selection(user,self._stores(profile),db)['storeId']!=store_id:
                raise WorkbenchError('STORE_FORBIDDEN','当前门店已变化，请重新读取IP口吻',403)
            found=db.execute('SELECT body FROM records WHERE entity=? AND id=?',(TONE_PREF_ENTITY,ident)).fetchone()
            try:row=json.loads(found['body']) if found else None
            except (TypeError,ValueError):
                raise WorkbenchError('PREFERENCE_INVALID','IP口吻记录格式无法核对',409) from None
            if found and (not isinstance(row,dict) or row.get('tenant_id')!=user['tenant_id'] or row.get('company_id')!=COMPANY_ID
                    or row.get('storeId')!=store_id or row.get('id')!=ident
                    or type(row.get('revision')) is not int or row['revision']<1
                    or not self._tone_values_valid(row,saved=True)):
                raise WorkbenchError('PREFERENCE_INVALID','IP口吻记录归属或格式无法核对',409)
            value={key:deepcopy(row[key]) for key in ('revision','identity','tone','salutation','focus')} if row else {
                'revision':0,'identity':'','tone':'friendly','salutation':'你好','focus':['budget','moveIn','housing']}
            value['templates']=deepcopy((row or {}).get('templates',{'employee':'','customer':''}))
            if save:
                if data['expectedRevision']!=value['revision']:
                    raise WorkbenchError('TONE_REVISION_CONFLICT','IP口吻已在其他窗口更新，请重新读取',409)
                previous_templates=deepcopy(value['templates'])
                value={key:deepcopy(data[key]) for key in ('identity','tone','salutation','focus')}
                value['templates']=deepcopy(data.get('templates',previous_templates))
                value['identity']=value['identity'].strip()
                value['salutation']=value['salutation'].strip()
                value['revision']=(row['revision'] if row else 0)+1
                record={**value,'id':ident,'tenant_id':user['tenant_id'],'company_id':COMPANY_ID,
                    'storeId':store_id,'updatedBy':user['username'],'updatedAt':_stamp()}
                db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',
                    (TONE_PREF_ENTITY,ident,user['tenant_id'],json.dumps(record,ensure_ascii=False,allow_nan=False)))
            return {'preferences':{'actor':{'username':user['username'],'storeId':store_id},**value}}

    def _save_selection(self, user, stores, data, *, apply):
        if not stores or data.get('storeId') not in {row['id'] for row in stores}:
            raise WorkbenchError('STORE_FORBIDDEN', '不能使用未分配给当前员工的门店', 403)
        if apply and data.get('storeId') != self._load_selection(user, stores)['storeId']:
            raise WorkbenchError('STORE_FORBIDDEN', '请先切换当前门店再应用预设', 403)
        if apply and (data.get('searchPresetId') not in SEARCH_IDS or data.get('intentPresetId') not in INTENT_IDS):
            raise WorkbenchError('PRESET_INVALID', '请选择有效的搜索和意向预设')
        if 'expectedRevision' in data and (type(data['expectedRevision']) is not int or data['expectedRevision'] < 0):
            raise WorkbenchError('REVISION_INVALID', '预设版本格式无效')
        if apply and 'expectedRevision' not in data:
            raise WorkbenchError('REVISION_REQUIRED', '应用预设前需要当前版本')
        # The legacy policy read owns its own BEGIN IMMEDIATE. Complete it
        # before acquiring the material/preferences transaction; only pure
        # projections and same-connection writes are allowed after this point.
        catalog = self._catalog(user, data['storeId']) if apply else None
        if apply and data.get('intentPresetId')=='rental-evidence' and not next(row for row in catalog['intent'] if row['id']=='rental-evidence')['assessmentEnabled']:
            raise WorkbenchError('CENTRAL_RULE_DRAFT','中央租房与预算规则仍为草稿，尚未启用',409)
        with self.core.lock, self.core.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            current = self._load_selection(user, stores, db)
            expected = data.get('expectedRevision', current['revision'])
            if expected != current['revision']:
                raise WorkbenchError('PRESET_REVISION_CONFLICT', '预设已在其他窗口更新，请重新读取', 409)
            if not apply and current['storeId'] == data['storeId']:
                return
            value = {**current, 'storeId': data['storeId'], 'revision': current['revision'] + 1,
                     'savedAt': _stamp()}
            if apply:
                material_selection = None
                if 'materialKey' in data:
                    material_selection = self.materials.save_selection(user, data['storeId'],
                        data['materialKey'], data.get('keywordIds'), data.get('expectedMaterialRevision'),
                        confirm_binding=data.get('confirmMaterialBinding') is True,
                        expected_catalog_digest=data.get('expectedCatalogDigest'), db=db)
                if material_selection is not None:
                    self._bind_material_search(catalog['search'], material_selection, data['storeId'])
                value.update(searchPresetId=data['searchPresetId'], intentPresetId=data['intentPresetId'])
                value['applied'] = self._current_preset(catalog, value, value['savedAt'])
            else:
                _, saved_store=self._store_preference(user,data['storeId'],db)
                value.update(searchPresetId='precise',intentPresetId='standard',applied=None)
                if saved_store:
                    for key in ('searchPresetId','intentPresetId','applied','savedAt'):
                        value[key]=deepcopy(saved_store.get(key,value[key]))
            record = {**value, 'id': self._preference_id(user), 'tenant_id': user['tenant_id'],
                      'owner': user['username'], 'company_id': COMPANY_ID}
            db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',
                (ENTITY, record['id'], record['tenant_id'], json.dumps(record, ensure_ascii=False, allow_nan=False)))
            if apply:
                store_preference_id,_=self._store_preference(user,data['storeId'],db)
                store_record={**record,'id':store_preference_id}
                db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',
                    (STORE_PREF_ENTITY,store_preference_id,user['tenant_id'],json.dumps(store_record,ensure_ascii=False,allow_nan=False)))

    def _delivery_identity(self, token):
        user,profile=self._identity(token,verification=self.delivery_integrations)
        if profile.get('can_reply') is False:
            raise WorkbenchError('REPLY_FORBIDDEN','当前员工的回复权限已撤销，本批已停止',403)
        selected=self._load_selection(user,self._stores(profile))['storeId']
        if not selected:raise WorkbenchError('STORE_REQUIRED','当前门店授权已撤销',403)
        self._activate_central_config(user,profile,selected,integration=self.delivery_integrations)
        return user,profile

    def _assessment_policy(self, store_id):
        config=self.central_configs.get(store_id) or {}
        profile=self.materials.builtin_search.get(store_id) or {}
        if (store_id=='fy_s_d343f3a378f48e1bab55df4f'
                and config.get('material_key')=='sh_gubei'
                and profile.get('localApprovedOverride') is True):
            # A separate local contract, explicitly approved for this client.
            # The authorized cloud mapping still grants the store scope; its
            # unpublished contract is retained as provenance, never forged.
            policy=deepcopy(profile['acquisitionPolicy'])
            return {'schema':'fangyu-runtime-assessment/1','version':policy['version'],
                'engineVersion':policy['version'],'contractDigest':_digest(policy),
                'sourceDigest':_digest(profile),'bundleRevision':profile['runtime']['revision'],
                'enabled':True,'supported':True,'calibrated':False,
                'localApprovedOverride':policy,'activationSource':'local_human_approved_store_profile',
                'centralContractReference':deepcopy(config.get('runtimeAssessment') or {})}
        rule=deepcopy(config.get('runtimeAssessment') or {})
        rule['supported']=(rule.get('schema')=='fangyu-runtime-assessment/1'
            and rule.get('version')=='2026-10-17.intent-evidence-contract-draft-v4'
            and rule.get('engineVersion')=='2026-10-18.intent-evidence-contract-draft-v4-review2'
            and rule.get('contractDigest')=='a493c0d812cb35cd76f51c23c92942ff75d68c547bde57885bd7bf8cf422dcf2'
            and isinstance(rule.get('sourceDigest'),str) and re.fullmatch('[a-f0-9]{64}',rule['sourceDigest']) is not None
            and bool(rule.get('bundleRevision')))
        if not rule['supported']:rule['status']='requires_engine_update'
        return rule

    def _assessment_for(self, user, store_id, rule_version=None):
        rule=self._assessment_policy(store_id)
        if not rule['supported'] or rule.get('enabled') is not True or (rule_version and rule_version!=rule['engineVersion']):
            raise WorkbenchError('ASSESSMENT_ENGINE_UPDATE_REQUIRED','判断执行契约未支持，需要升级引擎或重新核对历史任务',409)
        return self.rental_factory(self.core,self.company,rule_version=rule['engineVersion'],store_id=store_id)

    def _read_rental_assessments(self, user, store_id, lead_ids):
        rule=self._assessment_policy(store_id)
        if not rule['supported'] or rule.get('enabled') is not True:
            return {lead_id:self._read_rental_assessment(user,store_id,lead_id) for lead_id in lead_ids}
        reader=self._assessment_for(user,store_id)
        bulk=getattr(reader,'read_assessments',None)
        if not callable(bulk):
            return {lead_id:self._read_rental_assessment(user,store_id,lead_id) for lead_id in lead_ids}
        results=bulk(user,lead_ids)
        return {lead_id:self._rental_result(rule,results.get(lead_id)) for lead_id in lead_ids}

    @staticmethod
    def _rental_result(rule,result):
        if result is None:result={'intent_level':'unknown','reason':'当前规则尚未完成这条来源的判断',
            'review_required':True,'rule_version':rule['engineVersion'],'eligibility':'uncertain','store_matches':[],'budget':{},'income_self_report':None}
        return {**result,'contract_digest':rule['contractDigest'],'rule_source_digest':rule['sourceDigest'],
            'bundle_revision':rule['bundleRevision'],'calibrated':False}

    def _read_rental_assessment(self, user, store_id, lead_id):
        rule=self._assessment_policy(store_id)
        if not rule['supported'] or rule.get('enabled') is not True:
            return {'intent_level':'unknown','reason':'requires_engine_update','review_required':True,
                'rule_version':rule.get('version'),'eligibility':'uncertain','store_matches':[],'budget':{},'income_self_report':None}
        result=self._assessment_for(user,store_id).read_assessment(user,lead_id)
        return self._rental_result(rule,result)

    def _assess_imported(self, user, task_id):
        context=self.core.store.get('rental_task_context_v1',task_id)
        if (not context or context.get('tenant_id')!=user['tenant_id'] or context.get('owner')!=user['username'] or context.get('enabled') is not True):return None
        rule=self._assessment_policy(context['store_id'])
        if not rule['supported'] or context.get('rule_version')!=rule.get('engineVersion'):
            return {'status':'requires_engine_update','review_required':True}
        if not context.get('contractDigest'):
            # The unchanged runtime accepts four context fields. Bind the
            # authenticated request reservation to its newly created task here.
            matches=[row for row in self.core.store.list(REQUEST_ENTITY,user['tenant_id'])
                if row.get('owner')==user['username'] and (row.get('job') or {}).get('taskId')==task_id]
            head=matches[0] if matches else (self.core.store.get(REQUEST_ENTITY,_digest(['head',user['tenant_id'],user['username']])) or {})
            policy=head.get('assessmentPolicy') or {}
            matching=(head.get('tenant_id')==user['tenant_id'] and head.get('owner')==user['username']
                and head.get('storeId')==context['store_id'] and policy.get('contractDigest')==rule['contractDigest']
                and policy.get('engineVersion')==context['rule_version']
                and ((head.get('state')=='submitted' and context.get('created_at','')>=head.get('created_at','z'))
                    or (head.get('job') or {}).get('taskId')==task_id))
            if not matching:return {'status':'historical_contract_unverified','review_required':True}
            context={**context,'contractDigest':policy['contractDigest'],'sourceDigest':policy['sourceDigest'],
                'bundleRevision':policy['bundleRevision'],'requestId':head['requestId']}
            self.core.store.put('rental_task_context_v1',context)
        if context.get('contractDigest')!=rule['contractDigest']:
            return {'status':'requires_engine_update','review_required':True}
        return self._assessment_for(user,context['store_id'],context['rule_version']).assess_task(user,task_id)

    def _platform_state(self, user, profile=None, *, platform=None):
        actor = {'username': user['username'], 'storeId': self._load_selection(user, self._stores(profile))['storeId'] if profile else ''}
        if self.platform_runtime is None:
            return {'actor': actor, 'available': False, 'device': {'state': 'unavailable', 'bound': False,
                'message': '当前版本的平台后台尚未就绪'}, 'accounts': [], 'platforms': [],
                'acquisition': {'taskId': '', 'status': 'idle', 'canStart': False,
                                'canPause': False, 'canResume': False}}
        result = dict(self.platform_runtime.snapshot(user,platform=platform)
                      if platform is not None else self.platform_runtime.snapshot(user))
        result.pop('rawWorkspace', None)
        selection = self._load_selection(user, self._stores(profile)) if profile else {}
        summary_reader = getattr(self.customer_workbench, 'acquisition_summary', None)
        if callable(summary_reader) and actor['storeId']:
            acquisition = dict(result.get('acquisition') or {})
            task_id = acquisition.get('taskId')
            if task_id:
                current = (summary_reader(user, actor['storeId'], task_id,platform=platform)
                           if platform is not None else summary_reader(user, actor['storeId'], task_id))
                acquisition['recent'] = current['recent']
                acquisition['summary'] = current['summary']
                acquisition['counts'] = {**(acquisition.get('counts') or {}), 'analyzed': current['analyzed']}
                result['acquisition'] = acquisition
        result['actor'] = actor
        result['available'] = True
        result.setdefault('capabilities', {})['timeRanges'] = ['最近90天', '最近30天', '最近7天']
        from core.acquisition_sources import capabilities as source_capabilities
        result['capabilities']['acquisitionSources']={key:source_capabilities(key)
            for key in self.company.get('platforms',[]) if key in ('xiaohongshu','douyin')}
        head = self.core.store.get(REQUEST_ENTITY, _digest(['head', user['tenant_id'], user['username']]))
        if platform is not None and head and (head.get('storeId')!=actor['storeId']
                or (head.get('conditions') or {}).get('platform')!=platform):
            head=None
        head = self._reconcile_request(user,head)
        if head and head.get('tenant_id') == user['tenant_id'] and head.get('owner') == user['username']:
            result['lastRequest'] = {key: deepcopy(head[key]) for key in
                ('requestId', 'storeId', 'state', 'conditions', 'job', 'code', 'message','keywordBatch','batchOffset','batchEnd','totalEligible','profileDigest') if key in head}
        return result

    def _reconcile_request(self,user,head):
        """CAS one named task's private launch receipt; never search latest/start."""
        if (not head or head.get('state') not in ('submitted','unconfirmed')
                or head.get('tenant_id')!=user['tenant_id'] or head.get('owner')!=user['username']
                or head.get('storeId')!=user.get('_workbench_store_id')):return head
        task_id=(head.get('job') or {}).get('taskId')
        if not isinstance(task_id,str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,160}',task_id):return head
        from core.acquisition_receipts import ENTITY as RECEIPTS,matches_receipt
        request_id=_digest([user['tenant_id'],user['username'],head.get('requestId')])
        head_id=_digest(['head',user['tenant_id'],user['username']])
        with self.core.lock,self.core.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            def read(entity,ident):
                row=db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
                    (entity,ident,user['tenant_id'])).fetchone()
                return json.loads(row['body']) if row else None
            fresh_head=read(REQUEST_ENTITY,head_id);record=read(REQUEST_ENTITY,request_id)
            if (not fresh_head or _digest(fresh_head)!=_digest(head) or not record
                    or record.get('state') not in ('submitted','unconfirmed')
                    or record.get('owner')!=user['username'] or record.get('tenant_id')!=user['tenant_id']
                    or record.get('signature')!=head.get('signature') or record.get('job')!=head.get('job')):return fresh_head or head
            task=read('tasks',task_id);receipt=read(RECEIPTS,task_id)
            if (record.get('requestBinding') or {}).get('schema')=='workbench-acquisition-source-binding/1':
                from core.acquisition_sources import matches_source_receipt
                if not matches_source_receipt(receipt,record,task):return head
            elif not matches_receipt(receipt,record,task):return head
            status=task.get('status') or 'submitted'
            job={'taskId':task_id,'status':status,'accepted':True,
                 'message':'已核对原任务已受理，当前进度以原任务为准'}
            accepted={**record,'state':'accepted','job':job,'code':'',
                'message':job['message'],'reconciled_at':_stamp()}
            updated_head={**accepted,'id':head_id}
            for value in (accepted,updated_head):
                db.execute('UPDATE records SET body=? WHERE entity=? AND id=? AND tenant_id=?',
                    (json.dumps(value,ensure_ascii=False,allow_nan=False),REQUEST_ENTITY,value['id'],user['tenant_id']))
            return updated_head

    def _request_record(self, user, request_id):
        ident = _digest([user['tenant_id'], user['username'], request_id])
        value = self.core.store.get(REQUEST_ENTITY, ident)
        if value and (value.get('tenant_id') != user['tenant_id'] or value.get('owner') != user['username']):
            raise WorkbenchError('REQUEST_SCOPE_INVALID', '操作回执归属无法核对', 409)
        return ident, value

    def _save_request(self, user, record):
        head = {**record, 'id': _digest(['head', user['tenant_id'], user['username']])}
        with self.core.lock,self.core.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            if record.get('state')=='rejected' and record.get('cursorId'):
                found=db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
                    ('ui_keyword_cursor_v1',record['cursorId'],user['tenant_id'])).fetchone()
                cursor=json.loads(found['body']) if found else None
                if cursor and cursor.get('requestId')==record['requestId']:
                    cursor['offset']=record['batchOffset'];cursor['requestId']=None
                    db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',
                        ('ui_keyword_cursor_v1',cursor['id'],user['tenant_id'],json.dumps(cursor,ensure_ascii=False)))
            for value in (record,head):
                db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',
                    (REQUEST_ENTITY,value['id'],user['tenant_id'],json.dumps(value,ensure_ascii=False,allow_nan=False)))

    def _reserve_request(self,user,record,applied,preset,platform,*,source=False):
        words=applied['selectedKeywords']
        ident=_digest(['keyword-cursor-v1',user['tenant_id'],user['username'],record['storeId'],platform,preset,
            applied.get('profileDigest') or _digest(applied.get('libraryReference'))])
        with self.core.lock,self.core.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            previous=db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
                (REQUEST_ENTITY,record['id'],user['tenant_id'])).fetchone()
            if previous:
                old=json.loads(previous['body'])
                if old.get('signature')!=record.get('signature'):
                    raise WorkbenchError('REQUEST_CONFLICT','同一操作编号的条件已经变化',409)
                raise WorkbenchError('REQUEST_UNCONFIRMED','原请求已预约；请核对原任务，不会重复启动',409)
            prior_head=db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
                (REQUEST_ENTITY,_digest(['head',user['tenant_id'],user['username']]),user['tenant_id'])).fetchone()
            if prior_head and json.loads(prior_head['body']).get('state') in ('submitted','unconfirmed'):
                raise WorkbenchError('REQUEST_UNCONFIRMED','上次请求尚未核实，不会预约下一段词',409)
            if source:
                record={**record,'keywordBatch':[],'batchOffset':0,'batchEnd':0,'totalEligible':0,
                    'profileDigest':applied.get('profileDigest')}
                head={**record,'id':_digest(['head',user['tenant_id'],user['username']])}
                for value in (record,head):
                    db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',
                        (REQUEST_ENTITY,value['id'],user['tenant_id'],json.dumps(value,ensure_ascii=False,allow_nan=False)))
                return record
            found=db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
                ('ui_keyword_cursor_v1',ident,user['tenant_id'])).fetchone()
            cursor=json.loads(found['body']) if found else {}
            offset=cursor.get('offset',0)
            if type(offset) is not int or not 0<=offset<len(words):offset=0
            end=min(offset+100,len(words))
            record={**record,'keywordBatch':words[offset:end],'batchOffset':offset,'batchEnd':end,
                'totalEligible':len(words),'profileDigest':applied.get('profileDigest'),'cursorId':ident}
            cursor={'id':ident,'tenant_id':user['tenant_id'],'owner':user['username'],'storeId':record['storeId'],
                'platform':platform,'profileDigest':applied.get('profileDigest'),'offset':0 if end==len(words) else end,
                'requestId':record['requestId']}
            head={**record,'id':_digest(['head',user['tenant_id'],user['username']])}
            for entity,value in (('ui_keyword_cursor_v1',cursor),(REQUEST_ENTITY,record),(REQUEST_ENTITY,head)):
                db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',
                    (entity,value['id'],user['tenant_id'],json.dumps(value,ensure_ascii=False,allow_nan=False)))
        return record

    @staticmethod
    def _public_platform_job(value):
        if not isinstance(value, dict):
            raise WorkbenchError('PLATFORM_RESPONSE_INVALID', '平台回执格式需核对', 503)
        raw = value.get('result', value)
        if not isinstance(raw, dict):
            return {}
        allowed = ('id', 'jobId', 'accountId', 'taskId', 'status', 'state', 'message',
                   'phase', 'qrUrl', 'accepted', 'maxBatches','revision','reviewRequired',
                   'reviewReason','verificationWindowOpen','canConfirmReview','scan','alreadyAccepted')
        public = {key: deepcopy(raw[key]) for key in allowed if key in raw}
        for key in ('windowOpen', 'persistentBrowser','pageLoaded'):
            if type(raw.get(key)) is bool:
                public[key] = raw[key]
        for key in ('platformLoginConfirmed','bindingVerified','collectionAuthorized','autoResume'):
            if type(raw.get(key)) is bool:public[key]=raw[key]
        if type(raw.get('errorCode')) is str and raw['errorCode'] in ('LOGIN_WINDOW_PROCESS_FAILED','VERIFICATION_WINDOW_FAILED'):
            public['errorCode'] = raw['errorCode']
        if raw.get('windowEvidence') in ('visible_owned_child_window','owned_child_not_visible'):public['windowEvidence']=raw['windowEvidence']
        return public

    def _platform_dispatch(self, action, data, token):
        fields = {'platform_snapshot': {'platform'}, 'platform_prepare': {'existingOnly'},
            'account_delete':{'storeId','accountId','platform','expectedNickname','confirmed','requestId'},
            'account_delete_request':{'storeId','requestId'},
            'account_metadata_read':{'accountId','platform'},
            'account_metadata_save':{'accountId','platform','name','expectedMetadataDigest','url'},
            'account_create': {'platform', 'name'}, 'account_connect': {'accountId'}, 'account_check': {'accountId'},
            'account_safety':{'accountId'},'account_review_confirm':{'accountId','revision','confirmed'},
            'account_verification_open':{'accountId'},
            'account_job': {'jobId'}, 'account_cancel': {'jobId'},
            'acquisition_start': {'storeId', 'expectedRevision', 'platform', 'accountId',
                                  'region', 'time', 'requestId','source','commentWindow','execution','previewDigest'},
            'acquisition_source_preview':{'storeId','platform','accountId','source','commentWindow','execution'},
            'source_preset_read':{'storeId','requestId'},
            'source_preset_save':{'storeId','id','expectedVersion','name','platform','accountId','source','commentWindow','requestId'},
            'source_schedule_read':{'storeId','requestId'},
            'source_schedule_save':{'storeId','id','expectedVersion','name','presetId','presetVersion','intervalMinutes','timezone','requestId'},
            'source_execution_enable':{'storeId','id','accountId','presetId','presetVersion','intervalMinutes','confirmed','expectedVersion','requestId'},
            'source_execution_read':{'storeId','requestId'},
            'source_execution_pause':{'storeId','id','expectedVersion'},
            'source_interactions_check':{'storeId','taskId','scan'},
            'acquisition_pause': {'taskId'}, 'acquisition_resume': {'taskId'},
            'acquisition_verification_open':{'taskId'},'acquisition_verification_resume':{'taskId'}}[action]
        if not isinstance(data, dict) or set(data) - fields:
            raise WorkbenchError('INPUT_INVALID', '操作参数格式无效')
        selected_platform=_optional_platform(data) if action=='platform_snapshot' else None
        with self.lock:
            user, profile = self._identity(token)
            if action == 'platform_snapshot':
                return {'platform': self._platform_state(user, profile,platform=selected_platform)}
            self._selected_store(user, profile)
            if self.platform_runtime is None:
                raise WorkbenchError('PLATFORM_UNAVAILABLE', '当前版本的平台后台尚未就绪', 503)
            if action in ('source_execution_enable','source_execution_read','source_execution_pause'):
                store_id=self._selected_store(user,profile)
                if data.get('storeId')!=store_id:raise WorkbenchError('STORE_FORBIDDEN','当前门店已变化，请重新确认',403)
                expected={key:user.get(key) for key in ('id','tenant_id','username','role','cloud_bound')}
                def source_session_grant():
                    # Runtime may hold its original run lock. Do not wait for a
                    # UI action that already holds this lock and wants run_lock.
                    if not self.lock.acquire(blocking=False):
                        raise WorkbenchError('SOURCE_SESSION_BUSY','工作台操作中，本轮已暂停，请确认后继续',409)
                    try:
                        current,current_profile=self._identity(token)
                        if (self.closed or any(current.get(k)!=v for k,v in expected.items())
                                or current.get('_workbench_store_id')!=store_id):
                            raise WorkbenchError('AUTH_REQUIRED','原员工或门店会话已失效，请重新确认',401)
                        return current
                    finally:self.lock.release()
                stores=self._stores(profile)
                def schedule_authority(db,actor,scope,save):
                    session=db.execute('SELECT user_id FROM sessions WHERE token=? AND expires>?',
                        (hashlib.sha256(token.encode()).hexdigest(),time.time())).fetchone()
                    return (not self.closed and session is not None and session['user_id']==actor['id']
                        and self._load_selection(actor,stores,db)['storeId']==scope)
                scheduler=self.platform_runtime.source_scheduler
                if action=='source_execution_enable':value=scheduler.enable(user,dict(data),source_session_grant,schedule_authority)
                elif action=='source_execution_pause':value=scheduler.pause(user,dict(data))
                else:value=scheduler.read(user,dict(data))
                source_session_grant()
                return {('sourceExecutions' if action=='source_execution_read' else 'sourceExecution'):value,
                    'actor':{'username':user['username'],'storeId':store_id}}
            if action in ('acquisition_source_preview','source_preset_read','source_preset_save','source_schedule_read','source_schedule_save'):
                store_id=self._selected_store(user,profile)
                if data.get('storeId')!=store_id:
                    raise WorkbenchError('STORE_FORBIDDEN','当前门店已变化，请重新读取来源配置',403)
                saving=action.endswith('_save')
                if saving and (not isinstance(data.get('requestId'),str)
                        or not re.fullmatch(r'[A-Za-z0-9_-]{16,80}',data['requestId'])):
                    raise WorkbenchError('REQUEST_ID_REQUIRED','请保留本次来源配置操作编号')
                stores=self._stores(profile)
                def source_authority(db,actor,scope,save):
                    session=db.execute('SELECT user_id FROM sessions WHERE token=? AND expires>?',
                        (hashlib.sha256(token.encode()).hexdigest(),time.time())).fetchone()
                    return (not self.closed and session is not None and session['user_id']==actor['id']
                        and self._load_selection(actor,stores,db)['storeId']==scope)
                method={'acquisition_source_preview':'source_preview','source_preset_read':'list_source_presets',
                    'source_preset_save':'save_source_preset','source_schedule_read':'list_source_schedules',
                    'source_schedule_save':'save_source_schedule'}[action]
                fn=getattr(self.platform_runtime,method)
                value=fn(user,dict(data),authority_check=source_authority) if saving else fn(user,dict(data))
                fresh,fresh_profile=self._identity(token)
                if (any(fresh.get(k)!=user.get(k) for k in ('id','tenant_id','username','role','cloud_bound'))
                        or self._selected_store(fresh,fresh_profile)!=store_id):
                    raise WorkbenchError('SOURCE_RESULT_UNCONFIRMED' if saving else 'SOURCE_SCOPE_CHANGED',
                        '当前员工或门店已变化，请保留原操作编号核对',409 if saving else 403)
                result_key='sourcePreview' if action=='acquisition_source_preview' else 'sourcePreset' if saving and 'preset' in action else 'sourceSchedule' if saving else 'sourcePresets' if 'preset' in action else 'sourceSchedules'
                return {result_key:value,'actor':{'username':fresh['username'],'storeId':store_id}}
            if action in ('account_delete','account_delete_request'):
                if set(data)!=fields:raise WorkbenchError('INPUT_INVALID','请保留完整的原账号确认内容与操作编号')
                store_id=self._selected_store(user,profile)
                if data.get('storeId')!=store_id:raise WorkbenchError('STORE_FORBIDDEN','当前门店已变化，账号未移除',403)
                fn=self.platform_runtime.delete_account if action=='account_delete' else self.platform_runtime.account_delete_request
                result=fn(user,{key:value for key,value in data.items() if key!='storeId'})
                try:
                    fresh,fresh_profile=self._identity(token)
                    if (any(fresh.get(k)!=user.get(k) for k in ('id','tenant_id','username','role','cloud_bound')) or self._selected_store(fresh,fresh_profile)!=store_id):
                        raise WorkbenchError('ACCOUNT_SCOPE_FORBIDDEN','当前员工或门店已变化',403)
                except Exception:
                    if action=='account_delete':raise WorkbenchError('ACCOUNT_DELETE_RESULT_UNCONFIRMED','原移除结果需在原账号范围按原编号核对，不会自动再次删除',409) from None
                    raise
                actor={'username':fresh['username'],'storeId':store_id}
                if result.get('accountId'):actor.update(accountId=result['accountId'],platform=result['platform'])
                return {'accountDeletion':result,'actor':actor}
            if action in ('account_metadata_read','account_metadata_save'):
                result=self.platform_runtime.account_metadata(user,data,save=action=='account_metadata_save')
                try:
                    fresh,fresh_profile=self._identity(token)
                    if (any(fresh.get(k)!=user.get(k) for k in ('id','tenant_id','username','role','cloud_bound'))
                            or self._selected_store(fresh,fresh_profile)!=user.get('_workbench_store_id')):
                        raise WorkbenchError('ACCOUNT_SCOPE_FORBIDDEN','当前身份或门店已变化，请重新读取账号资料',403)
                    current=self.platform_runtime.account_metadata(fresh,
                        {key:data[key] for key in ('accountId','platform')})
                    if current['metadataDigest']!=result['metadataDigest']:
                        raise WorkbenchError('ACCOUNT_METADATA_CONFLICT','账号资料已变化，请重新读取',409)
                except Exception:
                    if action=='account_metadata_save':
                        raise WorkbenchError('ACCOUNT_METADATA_RESULT_UNCONFIRMED',
                            '备注可能已保存，最终身份确认未完成；请读取原账号核对，不要自动重复保存',409) from None
                    raise
                return {'accountMetadata':result}
            if action == 'platform_prepare':
                existing_only=data.get('existingOnly',False)
                if type(existing_only) is not bool:
                    raise WorkbenchError('INPUT_INVALID','连接参数格式无效')
                job = self.platform_runtime.prepare(user,existing_only=True) if existing_only else self.platform_runtime.prepare(user)
            elif action == 'account_create':
                platform, name = data.get('platform'), data.get('name', '')
                if platform not in self.company.get('platforms', []):
                    raise WorkbenchError('PLATFORM_NOT_ENABLED', '企业尚未开通此平台', 403)
                if not isinstance(name, str) or len(name.strip()) > 80:
                    raise WorkbenchError('INPUT_INVALID', '请输入80字以内的账号名称')
                job = self.platform_runtime.create_account(user, {'platform': platform, 'name': name.strip()})
            elif action == 'source_interactions_check':
                store_id=self._selected_store(user,profile)
                if data.get('storeId')!=store_id:
                    raise WorkbenchError('STORE_FORBIDDEN','当前门店已变化，请重新核对原互动任务',403)
                ident=data.get('taskId');scan=data.get('scan')
                if (not isinstance(ident,str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,160}',ident)
                        or type(scan) is not int or not 2<=scan<=1000000):
                    raise WorkbenchError('INPUT_INVALID','请选择原互动任务与下一检查轮次')
                job=self.platform_runtime.check_source_interactions(user,{'taskId':ident,'scan':scan})
                try:
                    fresh,fresh_profile=self._identity(token)
                    if (any(fresh.get(k)!=user.get(k) for k in ('id','tenant_id','username','role','cloud_bound'))
                            or self._selected_store(fresh,fresh_profile)!=store_id):
                        raise WorkbenchError('SOURCE_SCOPE_CHANGED','员工或门店范围已变化',403)
                    return {'platform':self._platform_state(fresh,fresh_profile,platform='xiaohongshu'),
                            'job':self._public_platform_job(job)}
                except Exception:
                    failure=WorkbenchError('SOURCE_SCAN_RESULT_UNCONFIRMED',
                        '本轮检查已提交，当前范围尚未核对；请保留原任务与轮次查询，不要重新开始',409)
                    failure.mutation_committed=True
                    raise failure from None
            elif action in ('acquisition_verification_open','acquisition_verification_resume'):
                ident=data.get('taskId')
                if not isinstance(ident,str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,160}',ident):
                    raise WorkbenchError('INPUT_INVALID','请先选择原采集任务')
                method='open_acquisition_verification' if action.endswith('_open') else 'resume_verified_acquisition'
                job=getattr(self.platform_runtime,method)(user,{'taskId':ident})
            elif action in ('account_safety','account_review_confirm','account_verification_open'):
                ident=data.get('accountId')
                if not isinstance(ident,str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,160}',ident):
                    raise WorkbenchError('INPUT_INVALID','请先选择有效的账号')
                method={'account_safety':'read_account_safety','account_review_confirm':'confirm_account_review',
                    'account_verification_open':'open_account_verification'}[action]
                job=getattr(self.platform_runtime,method)(user,dict(data))
            elif action in ('account_connect', 'account_check', 'account_job', 'account_cancel', 'acquisition_pause', 'acquisition_resume'):
                key = 'accountId' if action in ('account_connect', 'account_check') else 'jobId' if action.startswith('account_') else 'taskId'
                ident = data.get(key)
                if not isinstance(ident, str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,160}', ident):
                    raise WorkbenchError('INPUT_INVALID', '请先选择有效的账号或任务')
                method = {'account_connect': 'connect_account', 'account_check': 'check_account', 'account_job': 'account_job',
                    'account_cancel': 'cancel_account', 'acquisition_pause': 'pause_acquisition',
                    'acquisition_resume': 'resume_acquisition'}[action]
                job = getattr(self.platform_runtime, method)(user, {key: ident})
            else:
                stores = self._stores(profile)
                if data.get('storeId') != self._selected_store(user, profile):
                    raise WorkbenchError('STORE_FORBIDDEN', '不能使用未分配给当前员工的门店', 403)
                selection = self._load_selection(user, stores)
                if type(data.get('expectedRevision')) is not int or data['expectedRevision'] != selection['revision']:
                    raise WorkbenchError('PRESET_REVISION_CONFLICT', '门店预设已更新，请重新读取', 409)
                # Current validated central words/policy are loaded on this
                # explicit start. A stale saved projection is not employee work.
                applied = self._current_preset(self._catalog(user, data['storeId']), selection, _stamp())
                platform, account = data.get('platform'), data.get('accountId')
                if platform not in self.company.get('platforms', []):
                    raise WorkbenchError('PLATFORM_NOT_ENABLED', '企业尚未开通此平台', 403)
                if not isinstance(account, str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,160}', account):
                    raise WorkbenchError('ACCOUNT_REQUIRED', '请先选择已连接的平台账号')
                source='source' in data
                if not source and any(key in data for key in ('commentWindow','execution','previewDigest')):
                    raise WorkbenchError('SOURCE_REQUIRED','评论时间窗口须绑定明确来源')
                if ((not source or 'time' in data) and data.get('time') not in ('最近7天', '最近30天', '最近90天')):
                    raise WorkbenchError('TIME_INVALID', '请选择有效的时间范围')
                if not isinstance(data.get('region', ''), str) or len(data.get('region', '')) > 100:
                    raise WorkbenchError('REGION_INVALID', '地区格式无效')
                request_id = data.get('requestId')
                if not isinstance(request_id, str) or not re.fullmatch(r'[A-Za-z0-9_-]{16,80}', request_id):
                    raise WorkbenchError('REQUEST_ID_REQUIRED', '请重新发起本次采集操作')
                source_preview=None;launch_source=None
                if source:
                    values={key:deepcopy(data[key]) for key in ('storeId','platform','accountId','source','commentWindow','execution') if key in data}
                    launch_source=self.platform_runtime.resolve_source_input(user,values)
                    source_preview=self.platform_runtime.source_preview(user,launch_source)
                    if not source_preview.get('canStart'):
                        raise WorkbenchError(source_preview.get('code') or 'SOURCE_NOT_INTEGRATED',
                            source_preview.get('message') or '此来源尚未接通受控读取',422)
                    if data.get('previewDigest')!=source_preview.get('previewDigest'):
                        raise WorkbenchError('SOURCE_PREVIEW_CHANGED','来源条件已变化，请重新解析确认',409)
                ident, prior = self._request_record(user, request_id)
                head = self.core.store.get(REQUEST_ENTITY, _digest(['head', user['tenant_id'], user['username']]))
                head = self._reconcile_request(user,head)
                if prior and prior.get('state') in ('submitted','unconfirmed'):
                    ident,prior=self._request_record(user,request_id)
                if (head and head.get('tenant_id') == user['tenant_id'] and head.get('owner') == user['username']
                        and head.get('state') in ('submitted', 'unconfirmed') and head.get('requestId') != request_id):
                    raise WorkbenchError('REQUEST_UNCONFIRMED', '上次采集结果尚未确认，请先核对当前任务；不会另起重复采集', 409)
                signature = _digest({'data':data,'profileDigest':applied.get('profileDigest'),'libraryReference':applied.get('libraryReference')})
                if prior:
                    if prior.get('signature') != signature:
                        raise WorkbenchError('REQUEST_CONFLICT', '同一操作编号的条件已经变化', 409)
                    if prior.get('state') == 'accepted':
                        return {'platform': self._platform_state(user, profile), 'job': deepcopy(prior['job'])}
                    if prior.get('state') == 'rejected':
                        raise WorkbenchError(prior['code'], prior['message'], prior.get('status', 409))
                    raise WorkbenchError('REQUEST_UNCONFIRMED', '上次操作尚未确认，请先查看任务状态；不会重复发起', 409)
                record = {'id': ident, 'tenant_id': user['tenant_id'], 'owner': user['username'],
                    'requestId': request_id, 'storeId': data['storeId'], 'signature': signature,
                    'conditions': {key: deepcopy(data.get(key, '')) for key in
                        ('storeId', 'platform', 'accountId', 'region', 'time', 'expectedRevision')},
                    'state': 'submitted', 'created_at': _stamp()}
                record['assessmentPolicy']=self._assessment_policy(data['storeId']) if applied.get('rentalAssessmentEnabled') else None
                if source:
                    record['conditions']['source']={key:deepcopy(source_preview[key]) for key in ('kind','sourceCount','sourceDigest','commentWindow')}
                record=self._reserve_request(user,record,applied,selection['searchPresetId'],platform,source=source)
                store=next(row for row in stores if row['id']==data['storeId'])
                # Search area is trusted store context, not a commenter's IP.
                # The original requested display region stays in the idempotency record above.
                payload = {'platform': platform, 'accountId': account, 'region': '', 'storeId':data['storeId'],
                    'city':store.get('city',''),'area':store.get('area',''),
                    'time': 'all' if source else {'最近7天': '7d', '最近3天': '3d', '最近24小时': '24h', '最近30天': '30d', '最近90天': '90d'}[data['time']],
                    'keywords': list(record['keywordBatch']), 'excludes':deepcopy(applied.get('excludeTerms',[])),
                    'dailyLimit':1000,'targetCount':1000,
                    'intentMode': 'all'}
                if applied.get('rentalAssessmentEnabled'):
                    payload['rentalAssessment'] = {'enabled': True, 'storeId': data['storeId'],
                        'ruleVersion': self._assessment_policy(data['storeId'])['engineVersion'],
                        'materialKey': applied.get('materialKey')}
                if source:
                    payload.update({key:deepcopy(launch_source[key]) for key in ('source','commentWindow','execution') if key in launch_source})
                    payload['previewDigest']=data['previewDigest']
                    from core.acquisition_sources import make_source_binding as make_binding
                else:from core.acquisition_receipts import make_binding
                record={**record,'launchConditions':deepcopy(payload),'requestBinding':make_binding(record,payload)}
                self._save_request(user,record)
                payload['requestBinding']=deepcopy(record['requestBinding'])
                try:
                    job = self._public_platform_job(self.platform_runtime.start_acquisition(user, payload))
                except Exception as error:
                    rejected = getattr(error, 'mutation_committed', None) is False and isinstance(getattr(error, 'code', None), str)
                    uncertain = {**record, 'state': 'rejected' if rejected else 'unconfirmed',
                        'code': getattr(error, 'code', 'PLATFORM_ACTION_FAILED'),
                        'status': getattr(error, 'status', 409),
                        'message': str(error) if rejected else '本次未取得成功回执，请先核对任务状态'}
                    task_id = getattr(error, 'task_id', '')
                    if isinstance(task_id, str) and re.fullmatch(r'[A-Za-z0-9_-]{1,160}', task_id):
                        uncertain['job'] = {'taskId': task_id, 'status': 'unconfirmed'}
                    self._save_request(user, uncertain)
                    if not rejected:
                        raise WorkbenchError('REQUEST_UNCONFIRMED', '采集结果尚未确认，请先核对当前任务；不会自动重复发起', 409) from None
                    raise
                self._save_request(user, {**record, 'state': 'accepted', 'job': deepcopy(job)})
            return {'platform': self._platform_state(user, profile,platform='xiaohongshu') if action in ('acquisition_verification_open','acquisition_verification_resume') else self._platform_state(user, profile), 'job': self._public_platform_job(job)}

    def _interaction_dispatch(self,action,data,token):
        from core.interaction_inbox import InboxError, REQUEST
        if (not isinstance(data,dict) or not isinstance(data.get('viewId'),str)
                or not REQUEST.fullmatch(data['viewId'])
                or not isinstance(data.get('storeId'),str) or not STORE_ID.fullmatch(data['storeId'])
                or not isinstance(data.get('accountId'),str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,160}',data['accountId'])
                or data.get('platform')!='xiaohongshu' or 'xiaohongshu' not in self.company.get('platforms',[])):
            raise WorkbenchError('INPUT_INVALID','请选择当前门店、小红书账号和当前互动页面')
        save=action=='interaction_inbox_state_save'
        with self.lock:
            user,profile=self._identity(token)
            stores=self._stores(profile)
            store_id=self._selected_store(user,profile)
            if store_id!=data['storeId']:
                raise WorkbenchError('STORE_FORBIDDEN','当前门店已变化，请回到原门店核对互动记录',403)
            account=self.core.store.get('accounts',data['accountId']) or {}
            if (account.get('tenant_id')!=user['tenant_id'] or account.get('cloud_owner')!=user['username']
                    or account.get('store_id')!=store_id or account.get('platform')!='xiaohongshu'):
                raise WorkbenchError('ACCOUNT_FORBIDDEN','互动账号不属于当前员工或门店',403)
            self.core._account_access(user,account)
            account_binding={k:account.get(k) for k in ('id','tenant_id','cloud_owner','store_id','platform','platform_uid')}
            def authority(db,actor,scope,writing):
                session=db.execute('SELECT user_id FROM sessions WHERE token=? AND expires>?',
                    (hashlib.sha256(token.encode()).hexdigest(),time.time())).fetchone()
                return (not self.closed and session is not None and session['user_id']==actor['id']
                    and self._load_selection(actor,stores,db)['storeId']==scope['store_id'])
            request={k:deepcopy(v) for k,v in data.items() if k!='viewId'}
        try:
            answer=self.core.interaction_inbox(user,store_id,action,request,authority_check=authority)
        except InboxError as error:
            raise WorkbenchError(error.code,str(error),error.status) from None
        try:
            with self.lock:
                fresh,fresh_profile=self._identity(token)
                current=self.core.store.get('accounts',data['accountId']) or {}
                if (self.closed or any(fresh.get(k)!=user.get(k) for k in ('id','tenant_id','username','role','cloud_bound'))
                        or self._selected_store(fresh,fresh_profile)!=store_id
                        or any(current.get(k)!=v for k,v in account_binding.items())):
                    raise ValueError('scope changed')
        except Exception:
            error=WorkbenchError('INTERACTION_RESULT_UNCONFIRMED' if save else 'INTERACTION_SCOPE_CHANGED',
                '当前员工、门店或账号已变化；原结果没有交给当前页面，请回原范围查询原操作',409)
            if save:error.mutation_committed=True
            raise error from None
        answer['context']={'viewId':data['viewId'],'storeId':store_id,'accountId':data['accountId'],
            'platform':'xiaohongshu','actorId':user['id'],'scopeKey':answer['scopeKey']}
        return {'interactionInbox':answer}

    def _customer_dispatch(self, action, data, token):
        if action in PUBLIC_CONTACT_ACTIONS:
            return self._public_contact_dispatch(action,data,token)
        if action in OUTCOME_ACTIONS:
            return self._customer_outcome_dispatch(action,data,token)
        if action in ('customer_intent_read','customer_intent_correct','customer_intent_cancel'):
            return self._customer_intent_dispatch(action,data,token)
        fields = {'customers': {'query', 'filter', 'sort', 'sortDirection', 'page', 'pageSize','audience','platform','intent','acquiredDate','leaseGroup'},
            'keyword_effect_read': {'storeId','dateFrom','dateTo','platform'},
            'customer_detail': {'id','platform'},
            'customer_export': {'query', 'filter', 'sort', 'sortDirection', 'selectedIds','platform','intent','acquiredDate','leaseGroup'},
            'customer_memo_export':{'storeId','id','platform'},
            'customer_handoff_read':{'storeId','id','requestId'},
            'customer_handoff_save':{'storeId','id','expectedVersion','sourceDigest','note','nextStep','requestId'}}[action]
        if not isinstance(data, dict) or set(data) - fields:
            raise WorkbenchError('INPUT_INVALID', '客户查询参数无效')
        selected_platform=_optional_platform(data)
        with self.lock:
            user, profile = self._identity(token)
            if self.customer_workbench is None:
                raise WorkbenchError('CUSTOMERS_UNAVAILABLE', '客户功能尚未装入当前后台，请正常重开已验证的工作台版本', 503)
            stores = self._stores(profile)
            if not stores or not self._load_selection(user,stores)['storeId']:
                if action == 'customers' and user.get('role') == 'admin':
                    return {'customers':{'actor':{'username':user['username'],'storeId':''},
                        'scope':'employee-local-history','items':[],'stats':{'total':0,'high':0,'replied':0,'handoff':0},
                        'total':0,'page':1,'pageSize':20,'pages':0,
                        'scopeNotice':profile.get('_workbench_directory_notice') or '请先选择已授权门店分组'}}
                raise WorkbenchError('STORE_REQUIRED', '请先选择已核实门店分组', 403)
            store_id = self._selected_store(user, profile)
            actor = dict(user)
            # This permission is not persisted by legacy Integrations. Use the
            # fresh, trusted enterprise profile on every export.
            if 'can_export' in profile:
                actor['can_export'] = profile['can_export']
            if action == 'keyword_effect_read':
                if data.get('storeId')!=store_id:
                    raise WorkbenchError('STORE_FORBIDDEN','当前门店已变化，请重新读取词效',403)
                if self.keyword_effect_workbench is None:
                    raise WorkbenchError('KEYWORD_UNAVAILABLE','词效组件尚未装入当前版本',503)
                result={'keywordEffect':self.keyword_effect_workbench.read(actor,store_id,data)}
                fresh,fresh_profile=self._identity(token)
                if (any(fresh.get(k)!=user.get(k) for k in ('id','tenant_id','username','role','cloud_bound'))
                        or fresh_profile.get('role')!=profile.get('role')
                        or self._selected_store(fresh,fresh_profile)!=store_id):
                    raise WorkbenchError('KEYWORD_SCOPE_CHANGED','身份或门店权限已变化，请重新读取词效',403)
                return result
            if action in ('customer_handoff_read','customer_handoff_save','customer_memo_export'):
                if data.get('storeId')!=store_id:
                    raise WorkbenchError('STORE_FORBIDDEN','当前门店已变化，请重新读取客户备忘',403)
                if user.get('role')!='admin' or profile.get('role')!='admin':
                    raise WorkbenchError('MEMO_ADMIN_REQUIRED','客户备忘仅限管理员本人使用',403)
                result=({'file':self.customer_workbench.memo_export(actor,store_id,data)}
                    if action=='customer_memo_export' else {'handoff':self.customer_workbench.handoff(
                        actor,store_id,data,save=action=='customer_handoff_save')})
                try:
                    fresh,fresh_profile=self._identity(token)
                    if (any(fresh.get(k)!=user.get(k) for k in ('id','tenant_id','username','role','cloud_bound'))
                            or fresh_profile.get('role')!='admin'
                            or self._selected_store(fresh,fresh_profile)!=store_id):
                        raise WorkbenchError('MEMO_SCOPE_CHANGED','当前身份或门店已变化，请重新读取备忘',403)
                    if action=='customer_memo_export' and (fresh.get('can_export') is False
                            or fresh_profile.get('can_export') is False):
                        raise WorkbenchError('EXPORT_FORBIDDEN','当前账号没有导出权限',403)
                except Exception:
                    if action=='customer_handoff_save':
                        raise WorkbenchError('MEMO_RESULT_UNCONFIRMED',
                            '备忘保存后的身份确认未完成，请保留输入；重新登录后查询原操作，不要重复保存',409) from None
                    raise
                return result
            if action == 'customers':
                return {'customers': self.customer_workbench.list(actor, store_id, data)}
            if action == 'customer_detail':
                if not {'id'}.issubset(data) or set(data)-{'id','platform'}:
                    raise WorkbenchError('INPUT_INVALID', '请选择有效客户')
                return {'customer': self.customer_workbench.detail(actor, store_id, data['id'],platform=selected_platform)}
            return {'file': self.customer_workbench.export(actor, store_id, data)}

    def _public_contact_dispatch(self,action,data,token):
        invoked=False;committed=False;write=action!='customer_public_contact_read'
        try:
            with self.lock:
                user,profile=self._identity(token);store_id=self._selected_store(user,profile)
                factory=self.public_contacts_factory
                if factory is None or self.customer_workbench is None:
                    raise WorkbenchError('PUBLIC_CONTACT_UNAVAILABLE','原文联系方式核对组件尚未装入',503)
                service=factory(self.core,self.customer_workbench)
                method={'customer_public_contact_read':service.read,'customer_public_contact_save':service.save,
                        'customer_public_contact_cancel':service.cancel}[action]
                invoked=True;result=method(user,store_id,data);committed=write
                fresh,fresh_profile=self._identity(token)
                if (any(fresh.get(k)!=user.get(k) for k in ('id','tenant_id','username','role','cloud_bound'))
                        or self._selected_store(fresh,fresh_profile)!=store_id):
                    raise WorkbenchError('PUBLIC_CONTACT_SCOPE_CHANGED','当前员工或门店已变化，请回原范围核对',403)
                # Re-evaluate original customer/source access before exposing any
                # contact clue; a late handoff or permission change is closed.
                check=service.read(fresh,store_id,{k:data[k] for k in ('storeId','customerId','platform')})
                if check['sourceDigest']!=result['sourceDigest']:
                    raise WorkbenchError('PUBLIC_CONTACT_SOURCE_CHANGED','原评论或权限已变化，请重新核对',409)
                return {'publicContacts':result}
        except Exception as error:
            uncertain=committed or (invoked and write and not hasattr(error,'mutation_committed'))
            failure=WorkbenchError('PUBLIC_CONTACT_RESULT_UNCONFIRMED' if uncertain else getattr(error,'code','PUBLIC_CONTACT_UNAVAILABLE'),
                '结果待核对，请回原员工和门店查询原操作；不要重复登记' if uncertain else str(error) if hasattr(error,'code') else '原文核对暂不可用',
                409 if uncertain else getattr(error,'status',503))
            failure.mutation_committed=True if committed else getattr(error,'mutation_committed',None if uncertain else False)
            raise failure from None

    def _customer_outcome_dispatch(self,action,data,token):
        invoked=False;committed=False;write=action in ('customer_outcome_save','customer_outcome_cancel')
        try:
            with self.lock:
                user,profile=self._identity(token);store_id=self._selected_store(user,profile)
                factory=getattr(self,'outcomes_factory',None)
                if factory is None or self.customer_workbench is None:
                    raise WorkbenchError('OUTCOME_UNAVAILABLE','客户结果组件尚未装入当前版本',503)
                service=factory(self.core,self.customer_workbench)
                method={'customer_outcome_read':service.read,'customer_outcome_save':service.save,
                    'customer_outcome_cancel':service.cancel,'customer_outcome_report':service.report}[action]
                invoked=True;result=method(user,store_id,data);committed=write
                fresh,fresh_profile=self._identity(token)
                if (any(fresh.get(k)!=user.get(k) for k in ('id','tenant_id','username','role','cloud_bound'))
                        or self._selected_store(fresh,fresh_profile)!=store_id):
                    raise WorkbenchError('OUTCOME_SCOPE_CHANGED','当前员工或门店已变化，请回原范围核对',403)
                if write:
                    service.read(fresh,store_id,{k:data[k] for k in ('storeId','customerId','platform')})
                return {'customerOutcomes':result}
        except Exception as error:
            uncertain=committed or (invoked and write and not hasattr(error,'mutation_committed'))
            failure=WorkbenchError('OUTCOME_RESULT_UNCONFIRMED' if uncertain else getattr(error,'code','OUTCOME_UNAVAILABLE'),
                '结果待核对，请回原员工和门店查询原操作；不要重复登记' if uncertain else str(error) if hasattr(error,'code') else '客户结果暂不可用，请保留输入',
                409 if uncertain else getattr(error,'status',503))
            failure.mutation_committed=True if committed else getattr(error,'mutation_committed',None if uncertain else False)
            raise failure from None

    def _customer_intent_dispatch(self,action,data,token):
        from assistant.intent_correction import IntentCorrectionError
        committed=False;invoked=False
        try:
            with self.lock:
                user,profile=self._identity(token)
                store_id=self._selected_store(user,profile)
                factory=getattr(self,'customer_intent_factory',None)
                if self.customer_workbench is None or factory is None:
                    raise WorkbenchError('CUSTOMERS_UNAVAILABLE','客户功能尚未装入当前后台',503)
                service=factory(self.core,self.customer_workbench,self.company)
                method={'customer_intent_correct':service.correct,'customer_intent_read':service.read,'customer_intent_cancel':service.cancel}[action]
                invoked=True
                result=method(user,store_id,data)
                committed=action in ('customer_intent_correct','customer_intent_cancel')
                fresh,fresh_profile=self._identity(token)
                if (any(fresh.get(k)!=user.get(k) for k in ('id','tenant_id','username','role','cloud_bound'))
                        or self._selected_store(fresh,fresh_profile)!=store_id):
                    raise WorkbenchError('INTENT_SCOPE_CHANGED','当前身份或门店已变化，请重新核对',403)
                return {'intentCorrection':result}
        except Exception as error:
            known=isinstance(error,(IntentCorrectionError,WorkbenchError)) or hasattr(error,'code')
            uncertain=committed or (invoked and action in ('customer_intent_correct','customer_intent_cancel') and not hasattr(error,'mutation_committed'))
            failure=WorkbenchError('INTENT_RESULT_UNCONFIRMED' if uncertain else getattr(error,'code','INTENT_READ_FAILED'),
                '原操作已处理，请回到原账号和门店查询原结果' if committed else str(error) if known else '人工判断暂不可用，请保留输入',
                409 if committed else getattr(error,'status',503))
            failure.mutation_committed=True if committed else getattr(error,'mutation_committed',None if uncertain else False)
            raise failure from None

    def _rule_bundle_dispatch(self, action, data, token):
        """Narrow same-origin bridge; the cloud token never enters the page."""
        with self.lock:
            user,profile=self._identity(token)
            if user.get('role')!='admin' or profile.get('role')!='admin':
                raise WorkbenchError('RULE_BUNDLE_ADMIN_REQUIRED','规则文件仅限真实企业管理员',403)
            fields=set(RULE_BUNDLE_FIELDS[action])
            status_lookup=action=='rule_bundle_import_status' and isinstance(data,dict) and set(data) in ({'uploadId'},{'requestId'})
            if not isinstance(data,dict) or (not status_lookup and set(data)!=fields):
                raise WorkbenchError('INPUT_INVALID','规则文件操作参数无效')
            for key in ('uploadId','requestId','revision','expectedRevision'):
                if key in data and (not isinstance(data[key],str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,160}',data[key])):
                    raise WorkbenchError('INPUT_INVALID','规则文件编号格式无效')
            for key in ('digest','previewDigest'):
                if key in data and (not isinstance(data[key],str) or not re.fullmatch(r'[a-f0-9]{64}',data[key])):
                    raise WorkbenchError('INPUT_INVALID','规则文件摘要格式无效')
            if 'index' in data and (type(data['index']) is not int or not 0<=data['index']<86):
                raise WorkbenchError('INPUT_INVALID','规则文件分片编号无效')
            if action=='rule_bundle_import_begin':
                size,count=data['bytes'],data['chunkCount']
                if (type(size) is not int or not 0<size<=8388608 or type(count) is not int
                        or count!=(size+98303)//98304 or not 1<=count<=86):
                    raise WorkbenchError('INPUT_INVALID','只接受不超过8MiB的JSON规则文件')
            if action=='rule_bundle_import_chunk':
                encoded=data['dataBase64']
                if not isinstance(encoded,str) or not 0<len(encoded)<=131072:
                    raise WorkbenchError('INPUT_INVALID','规则文件分片大小无效')
                try:
                    raw=base64.b64decode(encoded,validate=True)
                except (binascii.Error,ValueError):
                    raise WorkbenchError('INPUT_INVALID','规则文件分片编码无效') from None
                if not 0<len(raw)<=98304:
                    raise WorkbenchError('INPUT_INVALID','规则文件分片大小无效')
            try:
                result=self.integrations._cloud(self.integrations._read(user['tenant_id']),user,action,**data)
            except Exception as error:
                status=getattr(error,'http_status',getattr(error,'status',None))
                if status in (401,403):
                    raise WorkbenchError('RULE_BUNDLE_ADMIN_REQUIRED','管理员会话已失效或权限已撤销',status) from None
                # Mutations are never retried. Unknown upload state is resolved
                # only through the explicit status action and existing uploadId.
                if action.startswith('rule_bundle_import_') and action!='rule_bundle_import_status':
                    raise WorkbenchError('RULE_BUNDLE_RESULT_UNCONFIRMED',
                        '规则文件操作结果未知；请核对导入状态，不会自动重试或再次应用',503) from None
                raise WorkbenchError('RULE_BUNDLE_UNAVAILABLE','规则文件状态暂不可读，请手动重新核对',503) from None
            allowed=('revision','digest','bytes','chunkCount','summary','index','dataBase64',
                'uploadId','requestId','state','previewDigest','warnings','receivedIndices','receivedCount','expectedRevision')
            if not isinstance(result,dict):
                raise WorkbenchError('RULE_BUNDLE_UNAVAILABLE','规则文件回执格式无效',503)
            return {'ruleBundle':{key:deepcopy(result[key]) for key in allowed if key in result}}

    @staticmethod
    def _public_ai_profile(value):
        config = value.get('config', value) if isinstance(value, dict) else None
        if (not isinstance(config, dict) or type(config.get('enabled')) is not bool
                or type(config.get('configured')) is not bool
                or config.get('provider') not in ('deepseek', 'openai')
                or type(config.get('revision')) is not int or config['revision'] < 0
                or any(not isinstance(config.get(key), str) or not 0 < len(config[key]) <= 180
                       for key in ('model', 'rules_version'))):
            raise WorkbenchError('AI_PROFILE_INVALID', '企业 AI 配置回执无法核对', 503)
        return {key: deepcopy(config[key]) for key in
                ('enabled', 'configured', 'provider', 'model', 'revision', 'rules_version')}

    def _business_rules_result(self, action, data, token, user, profile, store_id):
        # Read the pinned company presentation only. No policy publication,
        # model probe, customer scan or credential access belongs here.
        import types
        base = self.project_root / 'work/ui-native-r57'
        admin = user.get('role') == 'admin' and profile.get('role') == 'admin'
        allowed = {row['id'] for row in self._stores(profile)}
        try:
            if self.company.get('id') != COMPANY_ID:
                raise PermissionError('这份资料不属于当前企业。')
            source_path = base / 'business_rules.py'
            if source_path.is_symlink():
                raise ValueError('获客规则资料需要更新，请正常更新后重开。')
            source = source_path.read_bytes()
            if hashlib.sha256(source).hexdigest() != '5f247b1349149ea0b5cd857fb25a39b400de2ca71c816f6001d405af51f9333f':
                raise ValueError('获客规则资料需要更新，请正常更新后重开。')
            helper = types.ModuleType('fangyu_annual_business_rules')
            helper.__file__ = str(source_path)
            exec(compile(source, str(source_path), 'exec'), helper.__dict__)
            dataset = helper.load_data(base / 'business_rules_data.json', '3b776e23788f953ea8fb4e205cdaeed81a89dd659a61fb2733da2d590d08a973')
            approved_path=base/'approved_intent_policy.json'
            approved_raw=approved_path.read_bytes()
            if approved_path.is_symlink() or hashlib.sha256(approved_raw).hexdigest()!='0fd99bd0fc7142eb7e478bda1fcdff045167dc8f2e77755ddc7fcf8c78f6f6f9':
                raise ValueError('已确认规则完整性需要核对。')
            approved=json.loads(approved_raw.decode('utf-8'))
            provider_verified=False
            try:
                current_config=self.integrations._cloud(self.integrations._read(user['tenant_id']),user,
                    'ai_config_read' if admin else 'ai_profile').get('config',{})
                criteria=approved['criteria']
                criteria_hash=hashlib.sha256(json.dumps(criteria,ensure_ascii=False,separators=(',',':')).encode('utf-8')).hexdigest()[:12]
                provider_verified=(current_config.get('rules_version')==
                    'fangyu-approved-20261019-v1|apartment-rental-20261019-approved-v1|p'+criteria_hash
                    and (not admin or current_config.get('intent_policy')==criteria))
            except IntegrationError:
                pass
            catalog=self._catalog(user,store_id)
            selection=self._load_selection(user,self._stores(profile))
            search=next((row for row in catalog['search'] if row['id']==selection['searchPresetId']),None)
            document = helper.project(dataset, allowed, store_id, admin=admin,active_policy=approved,
                provider_verified=provider_verified,active_search={'keywords':list((search or {}).get('keywords',[])),
                    'name':(search or {}).get('name','本店默认词库'),'batchSize':100})
            if store_id=='fy_s_d343f3a378f48e1bab55df4f':
                policy=document['activePolicy']
                policy.update(title='古北店1—12个月获客规则',allStores=False,providerVerified=False,
                    statusText='古北店专用 · 1—12个月 · 本机判断 · 人工回复')
                for level in policy['levels']:
                    for key in ('text','example','action'):
                        level[key]=level.get(key,'').replace('年租','租住').replace('可以签一年','可租1—12个月')
                    if level.get('code')=='high':
                        level.update(text='当前独立求租并提出具体条件，或在明确出租的具体房源下询问价格、房型、设施、付款、能否看房等；不因短句缺少预算、入住日或租期降级。',
                            example='具体出租帖下的“问价”“还有吗”“有地暖吗”可属于该房询盘；普通租房建议或租售不明帖子不能仅凭这些短句判高。',
                            action='先核对本人需求和原帖语境，再由本人决定回复；意向不等于已匹配古北房源。')
                for exclusion in policy['exclusions']:
                    if exclusion['title'].startswith('游客和临时住宿'):
                        exclusion.update(exclude='仅旅游游玩，没有找房或租住需求。',
                            keep='明确求租1—12个月均保留；少于1个月或超过12个月另列待人工核实，不承诺可签。',
                            example='旅游、探亲或装修需要住两个月，应保留；只讨论餐饮景点不算求租。')
                policy['annualGuide']=[{'situation':'租期范围','handle':'1—12个月都收，按1—3个月、4—11个月、12个月分组；未说明和其他租期另列。'},
                    {'situation':'付款周期','handle':'押付、预付和总预算不作为租期；冲突交人工确认。'},
                    {'situation':'门店适配','handle':'意向和适配独立。现行价格、房源、做饭、噪声、网络、宠物及逐房设施待核。'}]
                policy['contactRule']='只采集和整理，回复由本人手动操作；明确拒绝联系的客户不主动联系。'
                policy['checks']=['核对原评论和当前需求','区分求租、代找与供房推广','按明确租期分组，不用付款周期代替','区分意向和门店适配','人工核对后自行回复']
                policy['followUpOrder']='优先具体看房或签约动作，再处理具体房源咨询；信息不足先补条件。'
                words=list((search or {}).get('keywords',[]))
                selected=next(s for s in document['stores'] if s['name']==document['selectedStoreName'])
                selected.update(terms=[{'word':w,'group':document['groups'][0],'origin':'古北店资料与本次授权','pendingSource':False,'statusText':'检索词，需求另行判断'} for w in words],
                    counts={group:len(words) if group==document['groups'][0] else 0 for group in document['groups']},totalCount=len(words),pendingTermCount=0)
                document.update(title='古北店1—12个月获客规则',stores=[selected],annualOnly=False,
                    annualOnlyAppliedToProvider=False,fiveLevelsLiveVerified=False,currentFiveLevelsVerified=False,
                    currentNote='古北店本机专属规则已启用；公司云端旧规则保留，其他门店不变。',
                    proposalNote='本次启用范围仅古北店，不代表已修改全公司云端提示词。',
                    scopedTermCount=len(words),scopedStoreCount=1,pendingTermCount=0,canExportMeetingPpt=False,
                    verifiedSnapshot='本页展示古北店已接入的专用规则与本次选定词库；没有发起新的模型调用。',
                    reviewStatusNote='古北店1—12个月规则用于新的本店分析；其他店和既有评级保持原样，真实新分析结果另行核验。',
                    followUpOrder=policy['followUpOrder'],contactRule=policy['contactRule'],
                    simpleChecklist=list(policy['checks']),annualGuide=list(policy['annualGuide']),
                    currentFiveLevels=[{'level':row['level'],'text':row['text']} for row in policy['levels']])
            actor = {'username':user['username'], 'storeId':store_id}
            result = ({'file': helper.exported_file(document, data.get('format','html'),
                       base / 'business_rules_meeting.pptx', 'fe5225ae5a8255bc59e9865323902c87f7caf331c79206cb5b6f3d963d49870c')}
                      if action == 'ai_rules_export' else
                      {'actor':actor, 'businessReview':document})
        except PermissionError as error:
            raise WorkbenchError('BUSINESS_RULES_FORBIDDEN', str(error), 403) from None
        except Exception:
            raise WorkbenchError('BUSINESS_RULES_UNAVAILABLE',
                '获客规则资料尚未完整装入当前版本，请正常更新后重开。', 503) from None
        current, fresh = self._identity(token)
        if (any(current.get(k) != user.get(k) for k in ('id','tenant_id','username','role'))
                or fresh.get('role') != profile.get('role')
                or self._selected_store(current, fresh) != store_id
                or {row['id'] for row in self._stores(fresh)} != allowed):
            raise WorkbenchError('AUTH_REQUIRED', '员工或门店权限已变化，请重新读取。', 403)
        return result

    def _ai_rules_dispatch(self, action, data, token):
        fields = ({'storeId', 'policy', 'expected_revision', 'idempotency_key'}
                  if action == 'ai_local_rules_save' else
                  {'storeId','view'} if action == 'ai_rules_read' and isinstance(data,dict) and 'view' in data else
                  {'storeId','format'} if action == 'ai_rules_export' and isinstance(data,dict) and 'format' in data else {'storeId'})
        if (isinstance(data,dict) and
                (('view' in data and data['view'] != 'business')
                 or ('format' in data and data['format'] not in ('html','pptx')))):
            raise WorkbenchError('INPUT_INVALID', '请选择业务规则或会议演示。')
        if (not isinstance(data, dict) or set(data) != fields
                or not isinstance(data.get('storeId'), str) or not STORE_ID.fullmatch(data['storeId'])):
            raise WorkbenchError('INPUT_INVALID', 'AI 规则操作参数无效')
        with self.lock:
            user, profile = self._identity(token)
            store_id = self._selected_store(user, profile)
            if data['storeId'] != store_id:
                raise WorkbenchError('STORE_FORBIDDEN', '当前门店已变化，请重新读取规则', 403)
            actor = {'username': user['username'], 'storeId': store_id}
            if action == 'ai_readiness_read':
                result = {'actor': actor, 'scope': 'configuration_read_only',
                    'configurationStatus': 'unknown', 'providerSuccess': 'unknown',
                    'providerRequestsStarted': False, 'realCallPerformed': False,
                    'checkedAt': _stamp(), 'profile': None, 'publishedPolicy': None,
                    'notice': '仅读取企业配置；未请求模型，真实调用和费用回执尚未验证。'}
                try:
                    # Deliberately no connectivity_check field: true invokes a
                    # provider probe in the original cloud implementation.
                    raw = self.integrations._cloud(self.integrations._read(user['tenant_id']), user, 'ai_profile')
                    result['profile'] = self._public_ai_profile(raw)
                    from assistant.ai_workflow import published_policy_metadata
                    result['publishedPolicy'] = published_policy_metadata(raw.get('config', raw))
                    config = result['profile']
                    result['configurationStatus'] = ('disabled' if not config['enabled'] else
                        'configured' if config['configured'] else 'not_configured')
                except Exception as error:
                    if getattr(error, 'http_status', getattr(error, 'status', None)) in (401, 403):
                        raise WorkbenchError('AUTH_REQUIRED', '企业 AI 配置读取权限已变化', 403) from None
                    result.update(profile=None, publishedPolicy=None,
                        notice='企业配置暂不可读；配置与真实调用状态均未知，未请求模型。')
                current, fresh = self._identity(token)
                if (any(current.get(k) != user.get(k) for k in ('id', 'tenant_id', 'username', 'role'))
                        or self._selected_store(current, fresh) != store_id):
                    raise WorkbenchError('AUTH_REQUIRED', '员工或门店范围已变化，请重新读取', 403)
                return {'readiness': result}
            admin = user.get('role') == 'admin' and profile.get('role') == 'admin'
            if action in ('ai_local_rules_save', 'ai_rules_export') and not admin:
                raise WorkbenchError('ADMIN_REQUIRED', '规则编辑和导出仅限当前企业管理员', 403)
            if action == 'ai_rules_export' or (action == 'ai_rules_read' and data.get('view') == 'business'):
                return self._business_rules_result(action, data, token, user, profile, store_id)
            manager = self.rules_factory(self.core, user['tenant_id'], user['username'], self.company)
            if action == 'ai_local_rules_save':
                try:
                    saved = manager.execute('intent_rules_save', {k: deepcopy(data[k]) for k in
                        ('policy', 'expected_revision', 'idempotency_key')}, user)
                except Exception as error:
                    if isinstance(error, ValueError):
                        code = getattr(error, 'code', 'INTENT_RULES_INVALID')
                        status = 409 if code == 'INTENT_RULES_REVISION_CONFLICT' else 403 if code == 'INTENT_RULES_FORBIDDEN' else 400
                        raise WorkbenchError(code, str(error), status) from None
                    raise
                return {'actor': actor, 'localPolicy': saved, 'providerPolicyChanged': False}
            local = manager.execute('intent_rules_get', {}, user)
            can_manage = admin and (local.get('summary') or {}).get('can_manage') is True
            # Preserve the existing private-rule boundary even when a trusted
            # operator can manage via another server-side product surface.
            if not can_manage:
                local = {'summary': deepcopy(local.get('summary') or {})}
            from core.intent_policy import normalize_policy
            from assistant.company_intent_policy import safe_projection
            cloud_config, grade, published = None, {'source': 'cloud_ai_config.intent_policy',
                'available': False, 'criteria': None, 'revision': None, 'rulesVersion': None}, {
                'source': 'cloud_published_company_policy', 'status': 'unknown', 'summary': None, 'can_publish': False}
            try:
                raw = self.integrations._cloud(self.integrations._read(user['tenant_id']), user,
                    'ai_config_read' if admin else 'ai_profile')
                cloud_config = self._public_ai_profile(raw)
                grade.update(revision=cloud_config['revision'], rulesVersion=cloud_config['rules_version'])
                if admin and isinstance(raw.get('config', raw).get('intent_policy'), dict):
                    grade.update(available=True, criteria=normalize_policy({
                        'criteria': raw.get('config', raw)['intent_policy']})['criteria'])
            except Exception as error:
                if getattr(error, 'http_status', getattr(error, 'status', None)) in (401, 403):
                    raise WorkbenchError('AUTH_REQUIRED', '企业 AI 配置读取权限已变化', 403) from None
            try:
                raw_policy = self.integrations._cloud(self.integrations._read(user['tenant_id']), user, 'intent_policy_read')
                if not isinstance(raw_policy, dict) or type(raw_policy.get('can_publish')) is not bool or 'summary' not in raw_policy:
                    raise ValueError('Invalid public policy response')
                published.update(status='read', summary=(None if raw_policy['summary'] is None else safe_projection(raw_policy['summary'])),
                    can_publish=admin and raw_policy['can_publish'])
                if admin and isinstance(raw_policy.get('policy'), dict):
                    published['policy'] = normalize_policy(raw_policy['policy'])
            except Exception as error:
                if getattr(error, 'http_status', getattr(error, 'status', None)) in (401, 403):
                    raise WorkbenchError('AUTH_REQUIRED', '公司规则读取权限已变化', 403) from None
                published = {'source': 'cloud_published_company_policy', 'status': 'unknown', 'summary': None, 'can_publish': False}
            catalog = self._catalog(user, store_id)
            overview_reader = getattr(self.rental_factory, 'rule_overview', None)
            rules = {'actor': actor, 'storeId': store_id, 'canManage': can_manage,
                'search': deepcopy(catalog['search']), 'centralVersion': deepcopy(self.materials.central),
                'searchScope': {'source': 'current_store_material_catalog',
                    'activeTaskKeywordsIncluded': False,
                    'notice': '此处为当前门店词库方案；实际执行词以采集任务的关键词批次记录为准。词命中不证明本人求租。'},
                'sourceArtifacts': deepcopy(self.materials.package.get('sourceArtifacts', [])),
                'localAssessmentOverview': overview_reader() if callable(overview_reader) else {'source': 'unavailable'},
                'localPolicy': local, 'providerGradeCriteria': grade, 'providerPolicy': published,
                'providerPrompt': {'source': 'cloud_server_contract', 'available': False,
                    'rulesVersion': cloud_config['rules_version'] if cloud_config else None},
                'localPolicyExecution': {'criteriaTextUsedByLocalEvaluator': False,
                    'criteriaTextSentToProvider': False,
                    'criteriaEditingEffect': 'reference_text_and_policy_revision_only',
                    'evidenceValidation': 'fixed_engine_contract',
                    'propertyFacts': 'post_model_property_match',
                    'notice': '本机五级文字作为规则记录保存；固定证据引擎不解释这些文字。公寓资料用于返回后的资料匹配。改变模型分级需发布云标准。'},
                'usage': {'localCriteriaSentToProvider': False, 'providerRequestsStarted': False,
                    'realCallPerformed': False, 'providerSuccess': 'unknown',
                    'localPolicyScope': 'tenant_owner_post_model_validation',
                    'notice': '本机规则只校验模型返回；云分级标准和已发布公司规则才参与模型提示词。'}}
            current, fresh = self._identity(token)
            if (any(current.get(k) != user.get(k) for k in ('id', 'tenant_id', 'username', 'role'))
                    or self._selected_store(current, fresh) != store_id):
                raise WorkbenchError('AUTH_REQUIRED', '员工或门店范围已变化，请重新读取', 403)
            if action == 'ai_rules_export':
                encoded = json.dumps({'schema': 'fangyu-ai-rules-export/1', 'readOnly': True,
                    'exportedAt': _stamp(), 'rules': rules}, ensure_ascii=False, sort_keys=True,
                    separators=(',', ':'), allow_nan=False).encode('utf-8')
                return {'file': {'filename': 'fangyu-ai-rules-' + store_id + '.json',
                    'mime': 'application/json', 'contentBase64': base64.b64encode(encoded).decode('ascii')},
                    'rulesDigest': _digest(rules)}
            return {'rules': rules}

    @staticmethod
    def _content_component():
        import importlib.util
        import stat
        import sys
        base=Path(__file__).absolute().parent
        frozen=base/'resources/content-workbench'
        directory=frozen if frozen.exists() else base
        path=directory/'content_extension_loader.py'
        try:
            for item in (path,*path.parents):
                info=item.lstat()
                if item.is_symlink() or getattr(info,'st_file_attributes',0)&0x400:
                    raise ValueError('linked component')
            before=path.stat();raw=path.read_bytes();after=path.stat()
            if (not stat.S_ISREG(before.st_mode) or before.st_nlink!=1
                    or (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns)
                    !=(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns)
                    or hashlib.sha256(raw).hexdigest()!=CONTENT_EXTENSION_LOADER_SHA):
                raise ValueError('component changed')
            name='fangyu_content_extension_loader_'+CONTENT_EXTENSION_LOADER_SHA[:16]
            module=sys.modules.get(name)
            if module is None:
                module=importlib.util.module_from_spec(importlib.util.spec_from_loader(name,loader=None))
                module.__file__=str(path);sys.modules[name]=module
                try:exec(compile(raw,str(path),'exec'),module.__dict__)
                except BaseException:
                    sys.modules.pop(name,None);raise
            return module.load_extension(directory,CONTENT_EXTENSION_PINS)
        except (OSError,ValueError,TypeError):
            raise WorkbenchError('CONTENT_COMPONENT_UNAVAILABLE','内容运营组件尚未完整装入当前版本，请正常更新后重开',503) from None

    @staticmethod
    def _content_gateway_class():
        import sys
        import types
        base = Path(__file__).absolute().parent
        directory = base/'resources/content-gateway' if (base/'resources/content-gateway').exists() else base/'content_gateway'
        loader = sys.modules.get('fangyu_content_extension_loader_'+CONTENT_EXTENSION_LOADER_SHA[:16])
        if loader is None:
            raise WorkbenchError('CONTENT_GATEWAY_UNAVAILABLE','企业内容服务组件未装入，请正常更新后重开',503)
        guard = loader._ClosureRead(directory)
        name = 'fangyu_content_gateway_' + hashlib.sha256((str(directory)+str(CONTENT_GATEWAY_PINS)).encode()).hexdigest()[:20]
        try:
            sources = {key: guard.read(key, pin) for key, pin in CONTENT_GATEWAY_PINS.items()}
            module = sys.modules.get(name)
            if module is None:
                module = types.ModuleType(name)
                module.__file__ = str(directory/'gateway_adapter.py')
                exec(compile(sources['gateway_adapter.py'],module.__file__,'exec'),module.__dict__)
                guard.audit()
                sys.modules[name] = module
            return module.ContentGatewayAdapter
        except Exception:
            raise WorkbenchError('CONTENT_GATEWAY_UNAVAILABLE','企业内容服务组件完整性需要核对，请正常更新后重开',503) from None
        finally:
            guard.close()

    def _content_gateway_context(self, user, token, store_id, account_id, platform):
        # Identity reads use the original enterprise session; selected account
        # and scope are never supplied by an arbitrary model/endpoint UI field.
        with self.lock:
            current, fresh = self._identity(token)
            stores = self._stores(fresh)
            if (any(current.get(k)!=user.get(k) for k in ('id','tenant_id','username','role'))
                    or self._load_selection(current,stores)['storeId']!=store_id):
                raise WorkbenchError('CONTENT_FORBIDDEN','员工或门店已变化，请重新读取内容任务',403)
            account = self.core.store.get('accounts',account_id)
            if (not account or account.get('cloud_owner')!=user['username'] or account.get('store_id')!=store_id
                    or account.get('platform')!=platform or account.get('tenant_id')!=user['tenant_id']):
                raise WorkbenchError('ACCOUNT_FORBIDDEN','内容账号归属已变化',403)
        config = self.integrations._read(user['tenant_id'])
        raw = self.integrations._cloud(config,user,'ai_profile')
        profile = self._public_ai_profile(raw)
        capability = raw.get('content_generation_capability')
        unavailable = {'available':False,'status':'service_not_enabled',
                       'message':'企业内容生成服务尚未启用；资料、草稿和历史仍可正常使用。'}
        if not isinstance(capability,dict) or capability.get('contract')!='fangyu-content-capability-v1':
            return None, unavailable
        if (type(capability.get('enabled')) is not bool or type(capability.get('available')) is not bool
                or capability.get('selected_account_verified') is not False
                or capability.get('read_only') is not True
                or capability.get('generation_scope_check_required') is not True
                or capability.get('supported_platforms')!=['xiaohongshu']
                or capability.get('config_revision')!=profile['revision']
                or capability.get('rules_version')!=profile['rules_version']):
            raise WorkbenchError('CONTENT_GATEWAY_PROFILE_INVALID','企业内容服务状态无法核对，尚未生成内容',503)
        if not capability['enabled'] or not capability['available']:
            reason = capability.get('reason')
            if reason in ('tenant_mapping_missing','tenant_mapping_mismatch'):
                unavailable.update(status='tenant_mapping_required',message='企业内容服务的租户映射尚未核实，请联系管理员；任务尚未生成。')
            elif not profile['enabled'] or not profile['configured']:
                unavailable.update(status='ai_not_configured',message='企业 AI 尚未配置并启用；资料与草稿已保留。')
            return None, unavailable
        if (capability.get('tenant_id')!=user['tenant_id'] or capability.get('tenant_mapping_verified') is not True
                or type(capability.get('policy_revision')) is not int or capability['policy_revision']<1):
            return None, {'available':False,'status':'tenant_mapping_required','message':'企业内容服务与本机租户映射不一致，已停止生成，请联系管理员核对。'}
        directory=fresh.get('_central_directory') or {}
        if (capability.get('store_scope_verified') is not True
                or capability.get('store_scope_type')!=('company' if user['role']=='admin' else 'store')
                or type(capability.get('store_scope_count')) is not int
                or capability['store_scope_count']!=len(stores) or not stores
                or capability.get('central_catalog_revision')!=directory.get('catalog_revision')
                or capability.get('central_catalog_digest')!=directory.get('catalog_digest')
                or not isinstance(capability.get('central_grant_revision'),str)
                or not re.fullmatch(r'[a-f0-9]{64}',capability['central_grant_revision'])
                or capability['central_grant_revision']!=(directory.get('scope') or {}).get('grant_revision')):
            return None, {'available':False,'status':'store_scope_required',
                'message':'企业内容服务的门店授权或资料版本尚未核对，请保留任务后重新读取；尚未生成内容。'}
        if platform not in capability['supported_platforms']:
            return None, {'available':False,'status':'platform_registration_required','message':'抖音内容账号的企业登记尚未接通，当前可保存资料和草稿。'}
        if not profile['enabled'] or not profile['configured']:
            return None, unavailable
        # The login's remembered device ID is NOT the platform executor ID.
        # Read the original bound executor vault; never enroll another device.
        current_config = self.integrations._read(user['tenant_id'])
        cloud = current_config.get('cloud',{})
        service = getattr(self.platform_runtime,'service',None)
        saved = service.vault.read() if service is not None else None
        device = (saved or {}).get('device') or {}
        device_id = device.get('id')
        if (not saved or saved.get('state')!='bound' or device.get('owner')!=user['username']
                or not isinstance(device_id,str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,160}',device_id)
                or cloud.get('environment_id')!=self.company['managedWorkspace']['environment_id']):
            return None, {'available':False,'status':'device_binding_required','message':'当前企业设备绑定尚未核实，请保留任务并检查企业连接。'}
        context = dict(environment_id=cloud['environment_id'],company_id=self.company['id'],
            tenant_id=user['tenant_id'],store_id=store_id,account_id=account_id,platform=platform,
            actor=user['username'],device_id=device_id,expected_revision=profile['revision'],
            expected_rules_version=profile['rules_version'])
        return context, {'available':True,'status':'enterprise_gateway_ready',
            'message':'使用企业 AI 生成候选；账号登记、服务额度与预算会在执行前再次核对，采用前仍需人工审核。',
            'selectedAccountVerified':False}

    def _content_enterprise_adapter(self, user, token, store_id, account_id, platform):
        try:
            context, info = self._content_gateway_context(user,token,store_id,account_id,platform)
        except WorkbenchError as error:
            if error.status in (401,403):raise
            return None, {'available':False,'status':'service_unavailable','message':'企业内容服务状态暂无法核对；本地资料和草稿仍可使用，请稍后手动核对。'}
        except Exception:
            return None, {'available':False,'status':'service_unavailable','message':'企业内容服务尚未就绪；当前可保存资料和草稿，尚未调用模型。'}
        if context is None:
            return None, info
        adapter_class = self._content_gateway_class()
        owner = self
        class BoundGateway:
            requires_context = True
            def __init__(self):
                self.bound = None
                self.gateway = adapter_class(transport=self.transport,trusted_context=self.current_context)
            def fresh_context(self):
                current, _ = owner._content_gateway_context(user,token,store_id,account_id,platform)
                if current is None:
                    raise WorkbenchError('CONTENT_MODEL_UNAVAILABLE','企业内容服务尚未就绪，原任务已保留',503)
                return current
            def prepare_context(self, envelope):
                current = self.fresh_context()
                if envelope['scope']!={k:current[k] for k in ('tenant_id','store_id','account_id','platform','company_id','actor')}:
                    raise WorkbenchError('CONTENT_FORBIDDEN','内容任务所属范围已变化',403)
                self.bound = deepcopy(current)
                return deepcopy(current)
            def restore_context(self, original):
                if not isinstance(original,dict):
                    raise WorkbenchError('CONTENT_RECONCILE_CONTEXT_REQUIRED','缺少原内容服务范围，请保留原任务',409)
                self.bound = deepcopy(original)
            def current_context(self):
                current = self.fresh_context()
                if self.bound is None or current!=self.bound:
                    raise WorkbenchError('CONTENT_SOURCE_CHANGED','原企业配置或范围已变化，请保留原任务核对',409)
                return current
            def transport(self, payload):
                operation = payload.get('operation')
                if operation not in ('content_generate','content_generate_status'):
                    raise WorkbenchError('CONTENT_ACTION_FORBIDDEN','内容服务操作未开放',403)
                # Existing transport handles session refresh, fixed deployment
                # endpoint and company/environment verification. No new client,
                # key or provider path is introduced, and errors never prove
                # non-execution without a bound server receipt.
                try:
                    result = owner.integrations._cloud(owner.integrations._read(user['tenant_id']),user,operation,
                        **{k:deepcopy(v) for k,v in payload.items() if k not in ('operation','environment_id')})
                except IntegrationError as error:
                    retained=getattr(error,'content_gateway_response',None)
                    if retained is None:raise
                    return deepcopy(retained)
                return {'status':200,'data':result}
            def __call__(self,envelope):return self.gateway(envelope)
            def status(self,envelope):return self.gateway.status(envelope)
        return BoundGateway(), info

    def _publication_host(self):
        with self.lock:
            if self._content_publication_host is None:
                if self._content_publication_factory is not None:
                    self._content_publication_host=self._content_publication_factory(self)
                else:
                    import importlib
                    component=self._content_component()
                    prefix=component.__module__.rsplit('.',1)[0]
                    authority=importlib.import_module(prefix+'.publication_authority_host')
                    owned=importlib.import_module(prefix+'.owned_publication_host')
                    port=importlib.import_module(prefix+'.publishing_port')
                    policy=importlib.import_module(prefix+'.publication_policy')
                    self._content_publication_host=authority.NativePublicationHost(self,port_module=port,owned_host_module=owned,
                        wire_policy=policy.WIRE_POLICY,adapter_digest='ae23f2252b8580af3cc6ba86c510dea829401471ab0b107fb9c4a1d2e120ec90',stage_dir=self.data_dir/'publication-stage')
            return self._content_publication_host

    def _knowledge_file_preview(self,data,token):
        fields={'storeId','accountId','platform','filename','dataBase64'}
        if not isinstance(data,dict) or set(data)!=fields:
            raise WorkbenchError('INPUT_INVALID','请选择当前账号的资料文件')
        base={k:data[k] for k in ('storeId','accountId','platform')}
        with self.lock:
            actor,_=self._identity(token)
            identity=tuple(actor.get(k) for k in ('id','tenant_id','username','role'))
        before=self._content_dispatch('content_workspace_read',base,token)
        parser=getattr(self,'knowledge_file_preview_factory',None)
        if parser is None:raise WorkbenchError('KNOWLEDGE_PARSER_UNAVAILABLE','文件导入组件尚未装入当前版本',503)
        try:preview=parser(data['filename'],data['dataBase64'])
        except Exception as error:
            failure=WorkbenchError(getattr(error,'code','KNOWLEDGE_FILE_INVALID'),str(error) if hasattr(error,'code') else '资料文件暂时无法读取',getattr(error,'status',400))
            failure.mutation_committed=False;raise failure from None
        after=self._content_dispatch('content_workspace_read',base,token)
        with self.lock:
            actor,_=self._identity(token)
            current_identity=tuple(actor.get(k) for k in ('id','tenant_id','username','role'))
        if identity!=current_identity or before['workspace']['actor']!=after['workspace']['actor']:
            raise WorkbenchError('CONTENT_FORBIDDEN','当前账号或门店已变化，请重新预览',403)
        after['result']={'filePreview':preview};return after

    def _shared_store_context(self, db, user, scope, directory):
        """Read original sources in the caller's authorized Store transaction."""
        store_id=scope.store_id
        ident=_digest(['tone-preferences-v1',COMPANY_ID,user['tenant_id'],store_id])
        found=db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
            (TONE_PREF_ENTITY,ident,user['tenant_id'])).fetchone()
        try: tone=json.loads(found['body']) if found else None
        except (ValueError,TypeError):
            raise WorkbenchError('CONTENT_SOURCE_CHANGED','门店口吻记录需要核对，请回管理面板检查',409) from None
        if tone is not None and (not isinstance(tone,dict) or tone.get('id')!=ident
                or tone.get('company_id')!=COMPANY_ID or tone.get('tenant_id')!=user['tenant_id']
                or tone.get('storeId')!=store_id or type(tone.get('revision')) is not int
                or tone['revision']<1 or not self._tone_values_valid(tone,saved=True)):
            raise WorkbenchError('CONTENT_SOURCE_CHANGED','门店口吻归属或版本需要核对',409)
        refs=[]
        def add(key,title,role,version,body,source_refs):
            if not body.strip(): return
            value={'id':key,'title':title,'role':role,'version':version,'text':body,
                'sourceRefs':deepcopy(source_refs),'kind':'hypothesis',
                'sourceLabel':'当前门店管理资料 · '+title+' · 待本人核实'}
            value['digest']=_digest(value)
            value['summary']=' '.join(body.split())[:180]
            refs.append(value)
        if tone:
            labels={'friendly':'亲切自然','concise':'简洁直接','patient':'耐心解释'}
            focus={'budget':'预算','moveIn':'入住时间','housing':'房型需求'}
            body='表达参考，不是已核实身份、房源或价格。\n身份称呼：'+tone['identity']+'\n语气：'+labels[tone['tone']]+'\n打招呼：'+tone['salutation']+'\n关注：'+'、'.join(focus[k] for k in tone['focus'])
            add('tone','门店口吻','style',tone['revision'],body,[])
            for key,title in (('employee','员工管理SOP'),('customer','客户沟通SOP')):
                template=tone.get('templates',{}).get(key,'')
                if template.strip():
                    add('sop-'+key,title,'style',tone['revision'],
                        '话术与流程样例，仅供表达参考；其中身份、设施、承诺和价格均需另行核实。\n'+template,[])
        with self.materials.lock:
            central=deepcopy(getattr(self.materials,'central',None))
            if (not central or central.get('storeId')!=store_id
                    or central.get('revision')!=directory.get('catalog_revision')
                    or central.get('catalogDigest')!=directory.get('catalog_digest')
                    or central.get('configDigest')!=next((r.get('config_digest')
                        for r in directory.get('stores',[]) if r.get('id')==store_id),None)):
                raise WorkbenchError('CONTENT_SOURCE_CHANGED','门店资料范围已变化，请重新预览本店资料',409)
            material=deepcopy(self.materials.materials.get(central.get('materialKey')))
            package_version=self.materials.package['version']
        if not isinstance(material,dict):
            raise WorkbenchError('CONTENT_SOURCE_CHANGED','当前门店资料尚未核对',409)
        lines=['历史门店资料摘要，供查证使用；不代表当前房源、设施或现价。',
            '资料名称：'+str(material.get('name','')),'城市：'+str(material.get('city','')),
            '区域：'+str(material.get('district',''))]
        for item in material.get('publicFactsSummary',[]):
            if not isinstance(item,dict) or not isinstance(item.get('field'),str) or not isinstance(item.get('value'),str):
                raise WorkbenchError('CONTENT_SOURCE_CHANGED','门店资料摘要需要核对',409)
            lines.append(item['field']+'：'+item['value']+'（待本人核实）')
        version={'catalogRevision':central['revision'],'configDigest':central['configDigest'],
            'materialVersion':package_version,'sourceVersions':central.get('sourceVersions')}
        add('store-material','门店已有资料','source_assertion',version,'\n'.join(lines),material.get('sourceRefs',[]))
        return {'readOnly':True,'references':refs,'factsVerified':False,'currentPricesVerified':False}

    def _content_dispatch(self,action,data,token):
        if action=='content_knowledge_file_preview':return self._knowledge_file_preview(data,token)
        model_dispatch={'entered':False}
        if (not isinstance(data,dict) or not isinstance(data.get('storeId'),str)
                or not STORE_ID.fullmatch(data['storeId'])
                or not isinstance(data.get('accountId'),str)
                or not re.fullmatch(r'[A-Za-z0-9_-]{1,160}',data['accountId'])
                or data.get('platform') not in ('xiaohongshu','douyin')):
            raise WorkbenchError('INPUT_INVALID','请选择当前门店、平台和内容账号')
        try:
            with self.lock:
                user,profile=self._identity(token)
                stores=self._stores(profile)
                store_id=self._selected_store(user,profile)
                if data['storeId']!=store_id:
                    raise WorkbenchError('STORE_FORBIDDEN','当前门店已变化，请重新读取内容资料',403)
                account=self.core.store.get('accounts',data['accountId'])
                if (not isinstance(account,dict) or account.get('tenant_id')!=user['tenant_id']
                        or account.get('cloud_owner')!=user['username']
                        or account.get('platform')!=data['platform'] or account.get('store_id')!=store_id):
                    raise WorkbenchError('ACCOUNT_FORBIDDEN','内容账号不属于当前员工或门店',403)
                self.core._account_access(user,account)
                component=self._content_component()
                authority_state={'stores':stores,'directory':profile.get('_central_directory') or {},'error':None}
                def authority(db,actor,scope,save):
                    if authority_state['error'] is not None:
                        raise authority_state['error']
                    session=db.execute('SELECT user_id FROM sessions WHERE token=? AND expires>?',
                        (hashlib.sha256(token.encode()).hexdigest(),time.time())).fetchone()
                    return (not self.closed and session is not None and session['user_id']==actor['id']
                        and self._load_selection(actor,authority_state['stores'],db)['storeId']==scope.store_id)
                request={k:deepcopy(v) for k,v in data.items() if k!='storeId'}
            adapter=self._content_model_adapter
            gateway_info=None
            if adapter is None:
                cache_key=(user['id'],hashlib.sha256(token.encode()).hexdigest(),store_id,data['accountId'],data['platform'])
                # Drafts, audits and local reads must not add a model-profile
                # network dependency. The methods panel explicitly checks once;
                # every run/status still obtains fresh trusted context below.
                if action in ('content_methods_read','content_task_run','content_task_reconcile'):
                    adapter,gateway_info=self._content_enterprise_adapter(user,token,store_id,data['accountId'],data['platform'])
                    gateway_info={**gateway_info,'checkedAt':datetime.now(timezone.utc).isoformat()}
                    with self.lock:
                        cache=getattr(self,'_content_gateway_capabilities',{})
                        if len(cache)>=100:cache.clear()
                        cache[cache_key]=deepcopy(gateway_info)
                        self._content_gateway_capabilities=cache
                else:
                    with self.lock:
                        gateway_info=deepcopy(getattr(self,'_content_gateway_capabilities',{}).get(cache_key))
                    if gateway_info is None:
                        gateway_info={'available':False,'status':'service_not_checked',
                            'message':'打开生成方法面板即可核对企业内容服务；资料和草稿可直接编辑。'}
            def invoke_host(envelope, status=False):
                model_dispatch['entered']=True
                try:
                    return adapter.status(envelope) if status else adapter(envelope)
                finally:
                    # The provider/status wait is outside both global locks and
                    # the Store transaction. Refresh central authority before
                    # installing any result; failures reach the transaction.
                    try:
                        with self.lock:
                            current,fresh=self._identity(token)
                            current_stores=self._stores(fresh)
                            if (self.closed or any(current.get(k)!=user.get(k)
                                    for k in ('id','tenant_id','username','role'))
                                    or store_id not in {row['id'] for row in current_stores}
                                    or self._load_selection(current,current_stores)['storeId']!=store_id):
                                raise WorkbenchError('CONTENT_FORBIDDEN','员工或门店权限已变化，生成结果未写入；请核对原请求',403)
                            authority_state['stores']=current_stores
                            authority_state['directory']=fresh.get('_central_directory') or {}
                    except WorkbenchError as error:
                        authority_state['error']=error
                    except Exception:
                        authority_state['error']=WorkbenchError('AUTH_SERVICE_UNAVAILABLE',
                            '生成后的企业权限尚未核对，已保留原请求，请稍后核对',503)
            def host_model(envelope):return invoke_host(envelope)
            if callable(getattr(adapter,'status',None)):
                host_model.status=lambda envelope:invoke_host(envelope,status=True)
            for name in ('prepare_context','restore_context','requires_context'):
                if hasattr(adapter,name):setattr(host_model,name,getattr(adapter,name))
            publication_port=getattr(self,'_content_publish_port',None)
            if publication_port is None and action.startswith('content_publish_'):
                publication_port=self._publication_host().for_token(token)
            if publication_port is not None:
                owner=self
                raw_publication_port=publication_port
                class ScopedPublishPort:
                    def preflight(self,envelope):return raw_publication_port.preflight(envelope)
                    def _call(self,method,*args):
                        model_dispatch['entered']=True
                        try:return getattr(raw_publication_port,method)(*args)
                        finally:
                            try:
                                with owner.lock:
                                    current,fresh=owner._identity(token)
                                    current_stores=owner._stores(fresh)
                                    if (owner.closed or any(current.get(k)!=user.get(k) for k in ('id','tenant_id','username','role'))
                                            or store_id not in {row['id'] for row in current_stores}
                                            or owner._load_selection(current,current_stores)['storeId']!=store_id):
                                        raise WorkbenchError('CONTENT_FORBIDDEN','员工或门店权限已变化；请核对原发布记录',403)
                                    authority_state['stores']=current_stores
                            except WorkbenchError as error:authority_state['error']=error
                            except Exception:authority_state['error']=WorkbenchError('AUTH_SERVICE_UNAVAILABLE','发布后的企业权限尚未核对，原请求已保留',503)
                    def dispatch(self,*args):return self._call('dispatch',*args)
                    def status(self,*args):return self._call('status',*args)
                    def settled(self,envelope):return raw_publication_port.settled(envelope)
                publication_port=ScopedPublishPort()
            workbench=component(self.core.store,model_adapter=host_model if callable(adapter) else None,publish_port=publication_port)
            workbench.store_context_provider=lambda db,scope:self._shared_store_context(db,user,scope,authority_state['directory'])
            # The component first commits its original request key, then calls
            # the host model outside the Store transaction and this global lock.
            # The same authority callback is rechecked before installing output.
            if action in ('content_task_run','content_task_reconcile','content_publish_confirm','content_publish_reconcile'):
                answer=workbench.execute(action,user,store_id,request,authority_check=authority)
            else:
                with self.lock:
                    answer=workbench.execute(action,user,store_id,request,authority_check=authority)
            if gateway_info is not None and isinstance(answer.get('workspace'),dict):
                workspace=answer['workspace']
                workspace['contentGateway']=deepcopy(gateway_info)
                available=gateway_info.get('available') is True
                workspace['capabilities'].update(canGenerate=available,generationStatus=gateway_info['status'],note=gateway_info['message'])
                workspace['workflowCapabilities'].update(canRunTasks=available,canReconcileTasks=available)
            return answer
        except WorkbenchError as error:
            if action in ('content_task_run','content_task_reconcile','content_publish_confirm','content_publish_reconcile') and model_dispatch['entered']:
                error.mutation_committed=True
            raise
        except Exception as error:
            code,status=getattr(error,'code',None),getattr(error,'status',None)
            if isinstance(code,str) and type(status) is int and status in (400,401,403,404,409,413,422,503):
                failure=WorkbenchError(code,str(error),status)
                if action in ('content_task_run','content_task_reconcile','content_publish_confirm','content_publish_reconcile'):
                    if model_dispatch['entered']:
                        failure.mutation_committed=True
                    elif code=='CONTENT_MODEL_UNAVAILABLE' or action in ('content_publish_confirm','content_publish_reconcile'):
                        failure.mutation_committed=False
                raise failure from None
            failure=WorkbenchError('CONTENT_UNAVAILABLE','内容操作尚未确认，请保留原稿并核对原操作结果',503)
            if action in ('content_task_run','content_task_reconcile','content_publish_confirm','content_publish_reconcile') and model_dispatch['entered']:
                failure.mutation_committed=True
            raise failure from None

    def dispatch(self, action, data, token=''):
        if self.closed:
            raise WorkbenchError('BACKEND_CLOSED', '工作台已关闭', 503)
        media=getattr(self,'media_workbench',None)
        if media is not None and action in media.actions:
            return media.dispatch(action,data,token)
        if action in DM_ACTIONS:
            try:
                with self.lock:
                    user,profile=self._identity(token)
                    store_id=self._selected_store(user,profile)
                    if not isinstance(data,dict) or data.get('storeId')!=store_id:
                        raise WorkbenchError('STORE_FORBIDDEN','当前门店已变化，请重新读取',403)
                    if self.dm_workbench is None:raise WorkbenchError('DM_UNAVAILABLE','私信组件尚未装入本版本',503)
                    return {'dmWorkspace':self.dm_workbench.execute(action,user,store_id,data,lambda:self._delivery_identity(token))}
            except WorkbenchError:raise
            except Exception as error:
                code,status=getattr(error,'code',None),getattr(error,'status',400)
                if isinstance(code,str) and type(status) is int and status in (400,401,403,404,409,422,503):raise WorkbenchError(code,str(error),status) from None
                raise WorkbenchError('DM_UNAVAILABLE','私信操作暂不可用；请核对原请求结果，草稿保持',503) from None
        if action in INTERACTION_ACTIONS:
            return self._interaction_dispatch(action,data,token)
        if action in AI_RULE_ACTIONS:
            return self._ai_rules_dispatch(action, data, token)
        if action in VOICE_SAMPLE_ACTIONS:
            return self._voice_samples_dispatch(action,data,token)
        if action in CONTENT_ACTIONS:
            return self._content_dispatch(action,data,token)
        remote = getattr(self,'remote_management',None)
        if remote is not None and action in remote.actions:
            try:
                return remote.dispatch(action,data,token)
            except remote.error_type as error:
                raise WorkbenchError(error.code,str(error),error.status) from None
            except Exception as error:
                status = getattr(error,'http_status',getattr(error,'status',503))
                if status not in (400,401,403,409):status=503
                raise WorkbenchError('REMOTE_RESULT_UNCONFIRMED',
                    '远程操作回执尚未确认，请保留原编号核对；不会自动重试',status) from None
        if action in RULE_BUNDLE_FIELDS:
            return self._rule_bundle_dispatch(action,data,token)
        if action in REPLY_ACTIONS or action in DELIVERY_ACTIONS:
            try:
                with self.lock:
                    user, profile = self._identity(token)
                    stores = self._stores(profile)
                    if not isinstance(data,dict) or not isinstance(data.get('storeId'),str):
                        raise WorkbenchError('INPUT_INVALID','回复门店参数无效')
                    store_id = self._selected_store(user, profile)
                    if data['storeId'] != store_id:
                        raise WorkbenchError('STORE_FORBIDDEN','当前门店已变化，请重新读取',403)
                    if self.reply_workbench is None:
                        raise WorkbenchError('REPLIES_UNAVAILABLE','回复草稿功能尚未装入当前后台，请正常重开已验证的版本',503)
                    if action in DELIVERY_ACTIONS:
                        return {'delivery':self.reply_delivery.execute(action,user,store_id,data,
                            lambda:self._delivery_identity(token))}
                    return {'replyWorkspace':self.reply_workbench.execute(action,user,store_id,data)}
            except WorkbenchError:
                raise
            except Exception as error:
                code, status = getattr(error,'code',None),getattr(error,'status',400)
                if isinstance(code,str) and type(status) is int and status in (400,401,403,404,409,422,503):
                    raise WorkbenchError(code,str(error),status) from None
                raise WorkbenchError('REPLIES_UNAVAILABLE','回复资料暂不可读，请重新核对原评论',503) from None
        if action in CUSTOMER_ACTIONS:
            try:
                return self._customer_dispatch(action, data, token)
            except WorkbenchError:
                raise
            except Exception as error:
                code, status = getattr(error, 'code', None), getattr(error, 'status', 400)
                if isinstance(code, str) and type(status) is int and status in (400, 401, 403, 404, 409, 422, 429, 503):
                    raise WorkbenchError(code, str(error), status) from None
                raise WorkbenchError('CUSTOMERS_UNAVAILABLE', '客户资料暂不可读，请稍后重新加载', 503) from None
        if action in PLATFORM_ACTIONS:
            try:
                return self._platform_dispatch(action, data, token)
            except WorkbenchError:
                raise
            except Exception as error:
                code = getattr(error, 'code', None)
                status = getattr(error, 'status', 400)
                if isinstance(code, str) and type(status) is int and status in (400, 401, 403, 409, 422, 429, 503):
                    failure=WorkbenchError(code, str(error), status)
                    if type(getattr(error,'mutation_committed',None)) is bool:
                        failure.mutation_committed=error.mutation_committed
                    raise failure from None
                failure=WorkbenchError('PLATFORM_ACTION_FAILED', '平台操作未取得确认，请查看当前状态后再处理', 503)
                if type(getattr(error,'mutation_committed',None)) is bool:
                    failure.mutation_committed=error.mutation_committed
                raise failure from None
        if action not in ACTIONS:
            raise WorkbenchError('ACTION_FORBIDDEN', '当前批次未开放此操作', 403)
        allowed = {'bootstrap': set(), 'login': {'username', 'password', 'rememberUsername'},
                   'logout': set(), 'select_store': {'storeId', 'expectedRevision'},
                   'apply_preset': {'storeId', 'searchPresetId', 'intentPresetId', 'expectedRevision',
                       'materialKey', 'keywordIds', 'expectedMaterialRevision', 'expectedCatalogDigest',
                       'confirmMaterialBinding'},
                   'refresh_assessments': {'storeId', 'expectedRevision'},
                   'tone_preferences_read': {'storeId'},
                   'tone_preferences_save': {'storeId','expectedRevision','identity','tone','salutation','focus','templates'}}[action]
        if not isinstance(data, dict) or set(data) - allowed:
            raise WorkbenchError('INPUT_INVALID', '操作参数格式无效')
        with self.lock:
            try:
                if action == 'bootstrap':
                    return self._bootstrap(token)
                if action == 'login':
                    name, password = data.get('username'), data.get('password')
                    if (not isinstance(name, str) or not 0 < len(name.strip()) <= 80
                            or not isinstance(password, str) or not 0 < len(password) <= 256
                            or type(data.get('rememberUsername', False)) is not bool):
                        raise WorkbenchError('LOGIN_INPUT_INVALID', '请输入员工用户名和密码')
                    entered = self.integrations.enter({'username': name.strip(), 'password': password}, employee_only=False)
                    try:
                        identity = self._identity(entered['token'])
                    except Exception:
                        self.core.handle('logout', {'token': entered['token']})
                        raise
                    self._remember(name.strip() if data.get('rememberUsername') else '')
                    return {**self._bootstrap(identity=identity), 'token': entered['token'],
                            'cookie_max_age': entered.get('cookie_max_age')}
                if action == 'logout':
                    if self._content_publication_host is not None:
                        self._content_publication_host.close()
                        self._content_publication_host=None
                    user = self.core.session(token)
                    cloud_unconfirmed = False
                    try:
                        if user and user.get('cloud_bound'):
                            self.integrations.handle('cloud_logout', {}, user)
                    except IntegrationError:
                        cloud_unconfirmed = True
                    finally:
                        self.core.handle('logout', {'token': token})
                    result = self._bootstrap()
                    if cloud_unconfirmed:
                        result['notice'] = '已退出本机；云端退出回执暂未确认，不会自动重试'
                    return result
                user, profile = self._identity(token)
                stores = self._stores(profile)
                if action in ('tone_preferences_read','tone_preferences_save'):
                    return self._tone_preferences(user,profile,data,token,save=action=='tone_preferences_save')
                if action == 'refresh_assessments':
                    if data.get('storeId') not in {row['id'] for row in stores}:
                        raise WorkbenchError('STORE_FORBIDDEN', '不能评估未分配的门店', 403)
                    current = self._load_selection(user, stores)
                    if type(data.get('expectedRevision')) is not int or data['expectedRevision'] != current['revision']:
                        raise WorkbenchError('PRESET_REVISION_CONFLICT', '预设已变化，请重新读取', 409)
                    if not (current.get('applied') or {}).get('rentalAssessmentEnabled'):
                        raise WorkbenchError('RULES_NOT_APPLIED', '请先应用租房与预算规则', 409)
                    summary = self._assessment_for(user, data['storeId']).assess_visible(user)
                    return {**self._bootstrap(identity=(user, profile)), 'assessment': summary}
                if action == 'apply_preset':
                    self._selected_store(user,profile)
                self._save_selection(user, stores, data, apply=action == 'apply_preset')
                result = self._bootstrap(identity=(user, profile))
                if action == 'apply_preset' and ((result.get('selection') or {}).get('applied') or {}).get('rentalAssessmentEnabled'):
                    # The selection is already committed. A grading failure is
                    # reported separately; retrying grading never repeats collection.
                    try:
                        result['assessment'] = self._assessment_for(user, data['storeId']).assess_visible(user)
                    except Exception:
                        result['assessment'] = {'status': 'retry_required', 'message': '预设已保存；现有客户判断未完成，可单独重新评估'}
                return result
            except EmployeeLoginRequired:
                raise WorkbenchError('EMPLOYEE_ONLY', '请使用企业员工账号登录；管理员请使用管理后台', 403) from None
            except IntegrationError as error:
                if isinstance(error, _CloudServiceUnavailable):
                    raise WorkbenchError(error.code, str(error), error.status) from None
                if getattr(error, 'http_status', None) in (401, 403):
                    raise WorkbenchError('AUTH_REQUIRED', '账号或企业会话无效，请核对后重新登录', 401) from None
                raise WorkbenchError('AUTH_SERVICE_UNAVAILABLE',
                                     '企业登录服务暂不可用，已保留本机状态，请稍后手动重试', 503) from None
            except WorkbenchError:
                raise
            except Exception as error:
                if isinstance(getattr(error, 'code', None), str) and getattr(error, 'status', None) in (400,401,403,409,422,503):
                    raise WorkbenchError(error.code, str(error), error.status) from None
                raise
