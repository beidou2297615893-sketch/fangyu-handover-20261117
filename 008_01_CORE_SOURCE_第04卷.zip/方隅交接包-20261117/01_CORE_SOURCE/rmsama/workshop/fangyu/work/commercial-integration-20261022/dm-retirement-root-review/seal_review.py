from pathlib import Path
from datetime import datetime, timezone
import hashlib, json
C=Path(__file__).resolve().parent
A=C.parent/'dm-f79-retirement-candidate'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(A/'FINAL-RECEIPT.json')=='e650ab25e09967fb068acc18465cd8ee53a64cd906b8859f1aa99d85f02c646c'
assert sha(A/'SEALED.json')=='19a6c409d57eeaaa301b281bf8b11657e18ee1f957d81001dcb160e9496ca56c'
assert sha(A/'SOURCE-PINS.json')=='f8cda5b056e23393c300422d339503d79f2f6ceb1ef7fab56822fac238b68848'
for row in json.loads((A/'SOURCE-PINS.json').read_text('utf-8'))['files']:
    assert sha(A/'final-source'/row['path'])==row['after']['sha256']
    assert sha(A/'qa-only-project'/row['path'])==row['after']['sha256']
out=C/'factory-bc7d6a5274714827823e595986b1e26d'
r=json.loads((out/'RESULTS.json').read_text('utf-8'))
f=json.loads((out/'FINAL.json').read_text('utf-8'))
green=json.loads((out/'RETIREMENT-GREEN.json').read_text('utf-8'))
assert r['status']=='PASS_REPRESENTATIVE' and len(r['checks'])==5
assert r['httpRequests']==85 and r['realPlatformModelCalls']==0
assert not r['findings'] and not f['blocked'] and f['allOwnServersClosed']
for key in ('unknownDraftByteUnchanged','unknownQueueByteUnchanged','claimByteUnchanged','zeroRedispatchAfterUnknown','lowerInterfaceSameContract','noSourceHoldsChanged'):
    assert green[key]
evidence=[]
for path in [C/'prepare.py',C/'INPUTS.json',C/'test_retirement_factory.py',
             out/'RESULTS.json',out/'FINAL.json',out/'RETIREMENT-GREEN.json',
             out/'RETIREMENT-NEGATIVES.json',out/'UNKNOWN-ACCOUNT-DELETE.json',C/'seal_review.py']:
    evidence.append({'path':str(path.relative_to(C)),'sha256':sha(path),'bytes':path.stat().st_size})
receipt={'status':'PASS_RETIRED_SOURCE_FIX_NOT_RELEASE_OR_PLATFORM_ACCEPTANCE',
         'createdUtc':datetime.now(timezone.utc).isoformat(),
         'authorFinalSha256':sha(A/'FINAL-RECEIPT.json'),'authorSealSha256':sha(A/'SEALED.json'),
         'sourceFiles':2,'actualIndependentOriginalFactoryGroups':5,'actualIndependentHttpRequests':85,
         'originalKeyReopenAndDeleteReadOnlyRecovery':True,'unknownDraftQueueAndClaimBytesUnchanged':True,
         'anotherAccountStillHitsOriginalCustomerClaim':True,
         'realPlatformOrModelCalls':0,'allOwnServersClosed':True,
         'productionAccess':False,'canonicalOrInstalledFilesWritten':False,
         'uiEvidence':'Author actual full-index fit 15 checks referenced; root did not rerun UI in this review',
         'limits':['Synthetic loopback transport is not real platform DM acceptance',
                   'Final combined source, UI, freeze and install remain'], 'evidence':evidence}
assert not (C/'FINAL-RECEIPT.json').exists()
(C/'FINAL-RECEIPT.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),'utf-8')
(C/'SEALED.json').write_text(json.dumps({'finalReceiptSha256':sha(C/'FINAL-RECEIPT.json'),'evidence':evidence},indent=2),'utf-8')
print(json.dumps({'status':receipt['status'],'finalSha256':sha(C/'FINAL-RECEIPT.json'),'sealSha256':sha(C/'SEALED.json')}))
