"""Actual pinned Native factory/Core/Store/HTTP; only enterprise I/O is synthetic."""
from pathlib import Path
from copy import deepcopy
import hashlib,http.client,importlib.util,json,os,sys,threading,time
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;B=W.parent;P=B.parents[1]
from final_inputs import load_verified
ROOT_PINS,F,S,STAGED,R=load_verified()
RED=False
pin=ROOT_PINS['manifestSha256']
def load(name,path):
 m=importlib.util.module_from_spec(importlib.util.spec_from_loader(name,loader=None));m.__file__=str(path);sys.modules[name]=m;exec(compile(path.read_bytes(),str(path),'exec'),m.__dict__);return m
blocked=[]
def audit(event,args):
 if event in ('subprocess.Popen','os.system','os.startfile','os.posix_spawn'):blocked.append(event);raise RuntimeError('No process')
 if event in ('socket.connect','socket.bind') and (not isinstance(args[1],tuple) or args[1][0] not in ('127.0.0.1','::1')):blocked.append(event);raise RuntimeError('No external socket')
 if event=='socket.getaddrinfo' and args[0] not in ('127.0.0.1','::1','localhost',None):blocked.append(event);raise RuntimeError('No external DNS')
 if event=='sqlite3.connect' and not Path(args[0]).resolve().is_relative_to(W):blocked.append(event);raise RuntimeError('No outside DB')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  path=Path(os.fsdecode(args[0])).absolute();mode,flags=args[1] or '',args[2] or 0
  if (any(c in str(mode) for c in 'wax+') or isinstance(flags,int) and flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC)) and not path.is_relative_to(W):blocked.append(event);raise RuntimeError('No outside write')
sys.addaudithook(audit)
original=load('context_cloud_fixture',P/'work/acquisition-core-repair-20261018/gui-fixture/base_fixture.py')
cloud=original.CloudStandin(json.loads((P/'work/central-store-config/compiled-fixture.json').read_text('utf-8-sig')))
company=json.loads((S/'work/app/company.json').read_text('utf-8-sig'))
def transport(*a,**kw):
 value=cloud(*a,**kw)
 if isinstance(value,dict) and 'environment_id' in value:value['environment_id']=company['managedWorkspace']['environment_id']
 return value
integration=load('integrations',R/'resources/platform-runtime/vendor-src/integrations.py');integration.request_json=transport
host=load('context_actual_native_host',R/'ui_native_host.py');_,files=host.verify_release(R,pin);host.verify_backend_dependencies(R,files,S)
backend=host.create_backend(R,files,project_root=S,data_dir=W/('data-'+str(time.time_ns())),company=company)
server=host.StaticServer(R,files,backend=backend,cookie_name='context_fixture_session');worker=threading.Thread(target=server.serve_forever,daemon=True);worker.start()
origin='http://127.0.0.1:'+str(server.server_port);headers={};results=[];calls=[]
def req(method,path,data=None,expected=200,extra=None):
 c=http.client.HTTPConnection('127.0.0.1',server.server_port,timeout=30);c.request(method,path,json.dumps(data,ensure_ascii=False).encode() if data is not None else None,headers if extra is None else extra);r=c.getresponse();raw=r.read();head=dict(r.getheaders());status=r.status;c.close();value=json.loads(raw) if raw.startswith(b'{') else {'text':raw.decode('utf-8')};assert status==expected,(status,expected,value);return value,head
def call(action,data,expected=200):
 calls.append({'action':action,'expected':expected});return req('POST','/api/workbench',{'action':action,'data':data},expected)[0]
try:
 boot,_=req('GET','/api/workbench/bootstrap');headers.update({'Content-Type':'application/json','Origin':origin,'X-Fangyu-CSRF':boot['csrfToken']})
 logged,head=req('POST','/api/workbench',{'action':'login','data':{'username':'fixture-admin','password':original.PASSWORD}});headers.update(Cookie=head['Set-Cookie'].split(';',1)[0]);headers['X-Fangyu-CSRF']=logged['csrfToken'];token=headers['Cookie'].split('=',1)[1];user=backend.core.session(token);store=cloud.first_store
 if logged['selection']['storeId']!=store:call('select_store',{'storeId':store,'expectedRevision':logged['selection']['revision']})
 account=dict(id='shared-context-a',tenant_id=user['tenant_id'],cloud_owner=user['username'],store_id=store,platform='xiaohongshu',status='disconnected',name='合成内容账号')
 backend.core.store.put('accounts',account);base=dict(storeId=store,accountId=account['id'],platform='xiaohongshu')
 def rows():
  with backend.core.store.connect() as db:return [tuple(r) for r in db.execute('SELECT entity,id,tenant_id,body FROM records ORDER BY entity,id')]
 initial=call('content_workspace_read',base);before=rows()
 if RED:
  value=call('content_store_context_read',base,403)
  assert rows()==before
  (W/'RED-RESULTS.json').write_text(json.dumps({'baseline':'exact v72','missingAction':True,'response':value,'storeUnchanged':True,'realModelCalls':0},ensure_ascii=False,indent=2),'utf-8')
  print('RED: exact v72 has no shared-store reference path; original Store unchanged')
 else:
  preview=call('content_store_context_read',base)
  assert rows()==before and preview['result']['storeContext']['readOnly'] is True
  refs=preview['result']['storeContext']['references'];assert any(v['id']=='store-material' for v in refs)
  results.append('Actual Native factory/HTTP: readonly current-store reference preview changes no Store records')
  (W/'PREVIEW.json').write_text(json.dumps(preview,ensure_ascii=False,indent=2),'utf-8')
  def workspace():return call('content_workspace_read',base)['workspace']
  serial=[0]
  def write(name,extra,expected=200,key=None):
   serial[0]+=1
   return call(name,{**base,'expectedRevision':workspace()['revision'],'requestId':key or 'context-request-'+str(serial[0]).zfill(6),**extra},expected)
  tone=call('tone_preferences_read',{'storeId':store})['preferences']
  def save_tone(version,employee):
   return call('tone_preferences_save',{'storeId':store,'expectedRevision':version,'identity':'合成门店顾问','tone':'friendly','salutation':'您好','focus':['budget','housing'],'templates':{'employee':employee,'customer':'先确认需求，再核对当前房源；示例价格不可承诺。'}})['preferences']
  tone=save_tone(tone['revision'],'先核对本人职责，合成月价999元仅为话术示例。')
  before=rows();preview=call('content_store_context_read',base);assert rows()==before
  refs=preview['result']['storeContext']['references'];assert {v['id'] for v in refs}=={'tone','sop-employee','sop-customer','store-material'}
  assert all(v['kind']=='hypothesis' for v in refs) and preview['result']['storeContext']['currentPricesVerified'] is False
  selected=[{'id':v['id'],'digest':v['digest']} for v in refs]
  no_refs=write('content_task_prepare',{'methodId':'writing','query':'无门店引用的独立任务'})['result']['task'];assert not no_refs.get('storeReferences')
  before=rows();write('content_task_prepare',{'methodId':'writing','query':'伪造引用','storeReferences':[{'id':'sop-employee','digest':'0'*64}]},409);assert rows()==before
  write('content_task_prepare',{'methodId':'writing','query':'注入引用','storeReferences':[{'id':selected[0]['id'],'digest':selected[0]['digest'],'text':'伪造内容'}]},409);assert rows()==before
  data={**base,'expectedRevision':workspace()['revision'],'requestId':'context-original-prepare','methodId':'writing','query':'采用本店表达参考','storeReferences':selected}
  prepared=call('content_task_prepare',data);task=prepared['result']['task'];task_id=task['id']
  frozen=next(t for t in prepared['workspace']['workflow']['tasks'] if t['id']==task_id)
  assert len(task['storeReferences'])==4 and task['storeReferenceConfirmation']['username']==user['username']
  assert frozen['input']['evidence'] and all(e['kind']=='hypothesis' for e in frozen['input']['evidence'])
  assert any('999元' in e['text'] for e in frozen['input']['evidence']) and prepared['workspace']['workflow']['documents']==[]
  results.append('Explicit selection only: server resolves id/digest against original sources in same transaction; task records sources/versions/digests/confirmer; no second knowledge library; all references are non-fact evidence')
  dispatches=[];status_checks=[]
  output={'summary':'合成回执，仅验证离线流程','facts':[],'hypotheses':['资料和话术需本人核实'],'artifact':{'title':'合成草稿','body':'请先核对当前门店资料。','tags':[]}}
  def adapter(envelope):
   dispatches.append(deepcopy(envelope));return {'state':'succeeded','requestId':envelope['requestId'],'output':deepcopy(output)}
  backend._content_model_adapter=adapter
  tone=save_tone(tone['revision'],'员工SOP已在管理面板修改，需要重新确认。')
  before=rows();old=write('content_task_run',{'taskId':task_id},409);assert old.get('error',{}).get('code')=='CONTENT_SOURCE_CHANGED' and rows()==before and not dispatches,old
  replay=call('content_task_prepare',data);assert replay['replayed'] and replay['result']['task']['id']==task_id
  assert replay['result']['task']['storeReferences']==task['storeReferences']
  call('content_task_prepare',{**data,'storeReferences':[]},409)
  results.append('Original SOP change blocks old prepared task before any dispatch; original prepare request replays frozen task and changed payload cannot reuse its key')
  refs=call('content_store_context_read',base)['result']['storeContext']['references'];selected=[{'id':v['id'],'digest':v['digest']} for v in refs]
  prepared=write('content_task_prepare',{'methodId':'writing','query':'本人重新确认后的草稿','storeReferences':selected});task=prepared['result']['task']
  # Existing gateway wire accepts the unchanged original envelope/input shape.
  def invalid_fact(envelope):
   dispatches.append(deepcopy(envelope));bad=deepcopy(output);e=envelope['input']['evidence'][0];bad['facts']=[{'evidenceId':e['evidenceId'],'quote':e['text']}];return {'state':'succeeded','requestId':envelope['requestId'],'output':bad}
  backend._content_model_adapter=invalid_fact
  bad=write('content_task_run',{'taskId':task['id']});assert bad['result']['task']['state']=='completed_invalid'
  assert bad['workspace']['workflow']['documents']==[] and not bad['workspace']['drafts']
  results.append('Original method validator rejects claiming style/SOP/historical material as verified fact; no candidate draft installed')
  def unknown(envelope):dispatches.append(deepcopy(envelope));raise TimeoutError('synthetic external response lost')
  def status(envelope):status_checks.append(deepcopy(envelope));return {'state':'succeeded','requestId':envelope['requestId'],'output':deepcopy(output)}
  unknown.status=status;backend._content_model_adapter=unknown
  prepared=write('content_task_prepare',{'methodId':'writing','query':'待核对原请求','storeReferences':selected});unknown_task=prepared['result']['task']
  run=write('content_task_run',{'taskId':unknown_task['id']},key='context-original-unknown');assert run['result']['task']['state']=='unknown'
  original_run_id=run['result']['task']['runId'];original_input=dispatches[-1]['inputDigest'];count=len(dispatches)
  tone=save_tone(tone['revision'],'第三版员工SOP，未知任务不能因此改键重派。')
  original_read=workspace();found=next(t for t in original_read['workflow']['tasks'] if t['id']==unknown_task['id']);assert found['state']=='unknown' and found['runRequestId']=='context-original-unknown'
  reconciled=write('content_task_reconcile',{'taskId':unknown_task['id']},key='context-original-unknown')
  assert reconciled['result']['task']['state']=='needs_revalidation' and len(dispatches)==count and len(status_checks)==1
  assert status_checks[0]['requestId']==original_run_id and status_checks[0]['inputDigest']==original_input
  assert reconciled['result']['task']['runRequestId']=='context-original-unknown' and reconciled['result']['task']['retryAllowed'] is False
  write('content_task_apply',{'taskId':unknown_task['id']},409)
  write('content_task_run',{'taskId':unknown_task['id']},409)
  results.append('Unknown dispatch retains original task/request/input snapshot across SOP change; original-key status only, returned result becomes stale and cannot apply or redispatch')
  # Fresh confirmation can use the existing local generation/acceptance path.
  refs=call('content_store_context_read',base)['result']['storeContext']['references'];selected=[{'id':v['id'],'digest':v['digest']} for v in refs]
  backend._content_model_adapter=adapter
  prepared=write('content_task_prepare',{'methodId':'writing','query':'重新选择当前资料','storeReferences':selected});good_task=prepared['result']['task']
  generated=write('content_task_run',{'taskId':good_task['id']});assert generated['result']['task']['state']=='succeeded'
  applied=write('content_task_apply',{'taskId':good_task['id']});assert len(applied['workspace']['drafts'])==1
  assert applied['workspace']['workflow']['documents']==[]
  results.append('Explicit refreshed references traverse original Native -> same Store task -> original method/output validator -> human apply; all model replies synthetic, no real model or platform')
  other_store=next(r['id'] for r in cloud.manifest['stores'] if r['id']!=store)
  call('content_store_context_read',{**base,'storeId':other_store},403)
  backend.core.store.put('accounts',{**account,'cloud_owner':'different-employee'})
  call('content_store_context_read',base,403);backend.core.store.put('accounts',account)
  results.append('Cross-store and foreign employee account cannot preview shared references')
  # Actual HTTP concurrency: a blocked synthetic reply does not hold the Store
  # write transaction or API lock; switching store revokes commit authority.
  entered=threading.Event();release=threading.Event();responses=[]
  def waiting(envelope):
   dispatches.append(deepcopy(envelope));entered.set();assert release.wait(15);return {'state':'succeeded','requestId':envelope['requestId'],'output':deepcopy(output)}
  waiting.status=status;backend._content_model_adapter=waiting
  prepared=write('content_task_prepare',{'methodId':'writing','query':'并发门店切换守卫','storeReferences':selected});concurrent_task=prepared['result']['task']
  payload={**base,'taskId':concurrent_task['id'],'expectedRevision':workspace()['revision'],'requestId':'context-concurrent-original'}
  thread=threading.Thread(target=lambda:responses.append(call('content_task_run',payload,403)));thread.start();assert entered.wait(10)
  switched=call('select_store',{'storeId':other_store});release.set();thread.join(15);assert not thread.is_alive() and responses
  call('select_store',{'storeId':store});read=workspace();pending=next(t for t in read['workflow']['tasks'] if t['id']==concurrent_task['id']);assert pending['state']=='running' and pending['runRequestId']=='context-concurrent-original'
  count=len(dispatches);recovered=write('content_task_reconcile',{'taskId':concurrent_task['id']},key='context-concurrent-original');assert len(dispatches)==count and recovered['result']['task']['runRequestId']=='context-concurrent-original'
  results.append('Concurrent actual HTTP store switch succeeds while reply waits; revoked scope cannot install reply; original running key survives and original-key reconciliation does not redispatch')
  # Normal adapter gateway protocol sees exactly the original input contract.
  envelope=dispatches[-1]
  gateway=load('context_actual_gateway',R/'resources/content-gateway/gateway_adapter.py')
  assert set(envelope['input'])=={'query','instructions','persona','topic','draft','evidence','artifacts'}
  wire=[];trusted={**envelope['scope'],'environment_id':company['managedWorkspace']['environment_id'],'device_id':'synthetic-content-device','expected_revision':1,'expected_rules_version':'synthetic-current-rules'}
  gateway_adapter=gateway.ContentGatewayAdapter(transport=lambda value:wire.append(deepcopy(value)),trusted_context=lambda:deepcopy(trusted))
  assert gateway_adapter(envelope)['state']=='unknown' and len(wire)==1
  assert json.loads(wire[0]['input_json'])==envelope['input'] and wire[0]['input_digest']==envelope['inputDigest']
  results.append('Original pinned public ContentGatewayAdapter accepts exact unchanged input/envelope and trusted scope; synthetic transport captures original wire, no cloud/model call')
  (W/'LAST-ENVELOPE.json').write_text(json.dumps(envelope,ensure_ascii=False,indent=2),'utf-8')
  (W/'UI-FIXTURE.json').write_text(json.dumps({'workspace':workspace(),'preview':call('content_store_context_read',base),'base':base},ensure_ascii=False,indent=2),'utf-8')
  # Existing source-document integrity guard continues to cover mixed inputs.
  doc=write('content_knowledge_import',{'document':{'title':'合成知识原文','text':'房源情况以本次核实为准。','kind':'fact','sourceLabel':'合成本人记录'}})['result']['document']
  prepared=write('content_task_prepare',{'methodId':'writing','query':'混用知识原文与门店口吻','evidenceIds':[doc['chunks'][0]['id']],'storeReferences':selected});mixed=prepared['result']['task']
  saved_workspace=workspace();entity='content_workspace_v1'
  with backend.core.store.connect() as db:
   record=db.execute('SELECT id,body FROM records WHERE entity=? AND tenant_id=?',(entity,user['tenant_id'])).fetchone();raw=json.loads(record['body']);original_record=deepcopy(raw)
   next(v for v in raw['workflow']['documents'] if v['id']==doc['id'])['text']='被改写的未核原文'
   db.execute('UPDATE records SET body=? WHERE entity=? AND id=?',(json.dumps(raw,ensure_ascii=False),entity,record['id']))
  count=len(dispatches);write('content_task_run',{'taskId':mixed['id']},409);assert len(dispatches)==count
  backend.core.store.put(entity,original_record)
  results.append('Existing immutable knowledge integrity remains active in tasks mixing selected store references; changed source bytes block dispatch and original records can be restored in fixture')
  # Source budget is checked as a whole; no silent truncation of originals.
  original_config=deepcopy(cloud.configs[store]);manifest_row=next(v for v in cloud.manifest['stores'] if v['id']==store);original_manifest_row=deepcopy(manifest_row)
  def change_material(value):
   config=cloud.configs[store];package=config['package'];package['materials'][0]['publicFactsSummary']=[{'field':'合成资料摘要','value':value,'verified':False}]
   package['digest']=original.digest({k:v for k,v in package.items() if k!='digest'});manifest_row['config_digest']=original.digest(config)
  change_material('待核'*40000);before=rows();call('content_store_context_read',base,409);assert rows()==before
  cloud.configs[store]=deepcopy(original_config);manifest_row.clear();manifest_row.update(original_manifest_row)
  results.append('Actual Native HTTP rejects oversized original source projection with no Store mutation; no source truncation or silent partial reference')
  prepared=write('content_task_prepare',{'methodId':'writing','query':'回执期间中央门店资料变化','storeReferences':selected});central_task=prepared['result']['task']
  def central_change(envelope):
   dispatches.append(deepcopy(envelope));change_material('更新后的合成门店摘要，需重新确认。');return {'state':'succeeded','requestId':envelope['requestId'],'output':deepcopy(output)}
  backend._content_model_adapter=central_change
  changed=write('content_task_run',{'taskId':central_task['id']});assert changed['result']['task']['state']=='needs_revalidation'
  assert changed['result']['task']['errorCode']=='CONTENT_SOURCE_CHANGED'
  cloud.configs[store]=deepcopy(original_config);manifest_row.clear();manifest_row.update(original_manifest_row)
  results.append('Central material config digest changes while synthetic reply waits: refreshed original directory invalidates old source snapshot and retains candidate as stale')
  backend._content_model_adapter=adapter
  legacy_run=write('content_task_run',{'taskId':no_refs['id']});assert legacy_run['result']['task']['state']=='succeeded' and not legacy_run['result']['task'].get('storeReferences')
  legacy_applied=write('content_task_apply',{'taskId':no_refs['id']});assert legacy_applied['result']['appliedRefs']['draftIds']
  (W/'LEGACY-CONTENT-RESULTS.json').write_text(json.dumps({'status':'PASS','groups':2,'trace':['Original no-reference task input contract executes without any injected store/SOP source','Original human apply persists local draft under original task/key; model receipt synthetic only'],'actualFinalFactory':True,'realModelCalls':0,'realPlatformCalls':0},ensure_ascii=False,indent=2),'utf-8')
  with backend.core.store.connect() as db:db.execute('UPDATE sessions SET expires=0 WHERE token=?',(hashlib.sha256(token.encode()).hexdigest(),))
  call('content_store_context_read',base,401)
  results.append('Expired current employee session cannot preview original store references')
  assert not blocked
  (W/'HTTP-PASS.json').write_text(json.dumps({'passed':len(results),'syntheticAdapterCalls':len(dispatches),'syntheticStatusChecks':len(status_checks),'realModelCalls':0,'realPlatformCalls':0,'results':results},ensure_ascii=False,indent=2),'utf-8')
finally:
 server.shutdown();server.server_close();backend.close()
 if not RED:(W/'HTTP-RESULTS.json').write_text(json.dumps({'passed':len(results),'results':results,'calls':calls,'blocked':blocked,'realModelCalls':0,'realPlatformCalls':0},ensure_ascii=False,indent=2),'utf-8');print('PASS',len(results))
