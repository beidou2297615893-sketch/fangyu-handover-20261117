"""Persistent single-batch scheduling and account mode leases.

No platform operation is implemented here: every tick reuses Core._run and its
identity, quota, entitlement and adapter guards. State lives in the same Store.
"""
import calendar
import ctypes
import json
import hashlib
import os
import threading
import time
from datetime import date, datetime
from uuid import uuid4


ACTIVE = ('queued', 'running', 'waiting')


def stamp(epoch=None):
    return datetime.fromtimestamp(time.time() if epoch is None else epoch).isoformat(timespec='seconds')


def process_alive(pid):
    try:
        pid = int(pid)
        if pid <= 0:
            return False
        if pid == os.getpid():
            return True
        if os.name == 'nt':
            try:
                kernel = ctypes.WinDLL('kernel32', use_last_error=True)
                kernel.OpenProcess.restype = ctypes.c_void_p
                handle = kernel.OpenProcess(0x100000, False, pid)  # SYNCHRONIZE only
                if not handle:
                    # Access denied or an unknown failure cannot prove death.
                    if ctypes.get_last_error() != 87:  # ERROR_INVALID_PARAMETER
                        return True
                    # Error 87 alone is insufficient: confirm absence from a
                    # successful complete PID list. Bound retries and memory.
                    for capacity in (1024, 2048, 4096, 8192, 16384, 32768, 65536):
                        pids = (ctypes.c_ulong * capacity)()
                        needed = ctypes.c_ulong()
                        if not kernel.K32EnumProcesses(pids, ctypes.sizeof(pids), ctypes.byref(needed)):
                            return True
                        if needed.value < ctypes.sizeof(pids):
                            return pid in pids[:needed.value // ctypes.sizeof(ctypes.c_ulong)]
                    return True  # Even the bounded final buffer may be truncated.
                try:
                    # Only a signaled process object proves exit. WAIT_FAILED
                    # and any unexpected result preserve the existing lease.
                    return kernel.WaitForSingleObject(ctypes.c_void_p(handle), 0) != 0
                finally:
                    kernel.CloseHandle(ctypes.c_void_p(handle))
            except (OSError, AttributeError, ValueError, TypeError):
                return True
        os.kill(pid, 0)
        return True
    except PermissionError:
        return True
    except (OSError, ValueError, TypeError):
        return False


def normalize_continuous_task(task):
    if task.get('continuous_enabled') is not True:
        return
    if task.get('scope') not in ('comments', 'search_comments'):
        raise ValueError('持续采集支持关键词评论或指定帖子评论')
    task['city'] = str(task.get('city') or '').strip()
    task['area'] = str(task.get('area') or '').strip()
    if not task['city']:
        raise ValueError('持续采集必须填写目标城市')
    if len(task['city'])>80 or len(task['area'])>80:
        raise ValueError('城市和区域各最多80个字符')
    task.setdefault('comment_date_range', '3months')
    if task['comment_date_range'] not in ('3months', '6months', '12months', 'custom'):
        raise ValueError('评论时间范围必须为近3、6、12个月或自定义')
    if task['comment_date_range'] == 'custom':
        values = []
        for key in ('comment_date_from', 'comment_date_to'):
            value = str(task.get(key) or '')
            try:
                date.fromisoformat(value)
            except ValueError:
                raise ValueError('自定义评论日期必须为 YYYY-MM-DD') from None
            values.append(value)
        if values[0] > values[1]:
            raise ValueError('评论时间起不能晚于时间止')
    # Search seeds identify posts, not the words every commenter must repeat.
    task['comment_keyword_mode'] = 'all'
    task['unknown_policy'] = 'keep'


def comment_window(task, today=None):
    today = today or date.today()
    if task.get('comment_date_range', '3months') == 'custom':
        return task['comment_date_from'], task['comment_date_to']
    months = int(task.get('comment_date_range', '3months').replace('months', ''))
    offset = today.year * 12 + today.month - 1 - months
    year, month = divmod(offset, 12)
    month += 1
    first = date(year, month, min(today.day, calendar.monthrange(year, month)[1]))
    return first.isoformat(), today.isoformat()


def filter_comment(item, task):
    """Keep uncertain metadata, and never treat IP location as city demand."""
    first, last = comment_window(task)
    value = str(item.get('published_at') or '')[:10]
    try:
        date.fromisoformat(value)
    except ValueError:
        value = ''
    item['comment_date_evidence'] = {'from': first, 'to': last, 'value': value,
                                     'status': 'verified' if value else 'pending'}
    if value and not first <= value <= last:
        return 'date'
    city, area = task['city'], task.get('area', '')
    # Only explicit location fields supplied by a semantic/verified source are
    # definitive. CLI region on XHS is ip_location, not the desired rental city.
    semantic = str(item.get('semantic_city') or item.get('location_city') or '').strip()
    semantic_area = str(item.get('semantic_area') or item.get('location_area') or '').strip()
    ip = str(item.get('ip_location') or (item.get('region') if task.get('platform') == 'xiaohongshu' else '') or '')
    area_match = ('not_selected' if not area else 'unknown' if not semantic_area else
                  'matched' if area in semantic_area or semantic_area in area else 'different')
    same_city = bool(semantic and (city in semantic or semantic in city))
    item['location_evidence'] = {'target_city': city, 'target_area': area,
        'semantic_city': semantic, 'semantic_area': semantic_area, 'ip_location': ip,
        'area_match': area_match,
        'status': 'verified' if semantic and (not area or semantic_area) else 'pending'}
    if same_city and area_match == 'different':
        item['location_evidence']['area_note'] = '同城其他区域；仍保留为公寓租房线索'
    if ip:
        item['ip_location'] = ip
    if semantic and not same_city:
        return 'city'
    pending = []
    if not value:
        pending.append('评论日期未知')
    if not semantic:
        pending.append('需求城市待核实（IP属地不能确认需求城市）')
    if area and not semantic_area:
        pending.append('需求区域待核实')
    if pending:
        previous = str(item.get('filter_review_reason') or '')
        item.update(filter_review_reason='；'.join(filter(None, [previous, *pending])),
                    verification_status='pending', stage='待核实')
    return ''


class AccountModeLeases:
    """Cross-process atomic lease; no same-account collection/reply overlap."""
    def __init__(self, store, runtime_id):
        self.store, self.runtime_id = store, runtime_id

    def get(self, account_id, tenant):
        record = self.store.get('account_modes', account_id)
        return record if record and record.get('tenant_id') == tenant else None

    @staticmethod
    def _publication_rows(db,account_id,tenant):
        for record in db.execute('SELECT body FROM records WHERE entity=? AND tenant_id=?',('content_publication_attempt_v1',tenant)):
            row=json.loads(record['body'])
            if row.get('scope',{}).get('account_id')!=account_id:continue
            body={k:v for k,v in row.items() if k!='recordDigest'}
            stamp_hash=hashlib.sha256(json.dumps(body,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
            if row.get('tenant_id')!=tenant or row['scope'].get('tenant_id')!=tenant or row.get('recordDigest')!=stamp_hash:
                raise ValueError('原发布记录尚未通过核对，账号保持暂停')
            yield row

    @classmethod
    def _publication_finished(cls,db,account_id,tenant,owner):
        if not isinstance(owner,str) or not owner.startswith('publication:'):return False
        intent=owner[len('publication:'):]
        return any(row.get('id')==intent and row.get('state') in ('published','not_sent')
                   for row in cls._publication_rows(db,account_id,tenant))

    def acquire(self, account_id, tenant, mode, owner):
        if mode not in ('collection', 'replies', 'publishing') or not owner:
            raise ValueError('账号运行模式或归属无效')
        with self.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            row = db.execute('SELECT body FROM records WHERE entity=? AND id=?',
                             ('account_modes', account_id)).fetchone()
            old = json.loads(row['body']) if row else {}
            if old and old.get('tenant_id') != tenant:
                raise ValueError('账号模式不属于当前企业')
            account_row=db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',('accounts',account_id,tenant)).fetchone()
            account=json.loads(account_row['body']) if account_row else {}
            if account.get('platform_uid'):
                key=hashlib.sha256(json.dumps(['fangyu-content-publication-v1',tenant,account.get('platform'),account['platform_uid']],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
                slot_row=db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',('content_publication_slot_v1',key,tenant)).fetchone()
                if slot_row:
                    slot=json.loads(slot_row['body']);body={k:v for k,v in slot.items() if k!='recordDigest'}
                    expected=hashlib.sha256(json.dumps(body,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
                    if slot.get('recordDigest')!=expected:raise ValueError('原发布账号占用尚未通过核对')
                    if slot.get('state')=='reserved':
                        attempt=next((row for row in self._publication_rows(db,account_id,tenant) if row.get('id')==slot.get('intentId')),None)
                        if not (attempt and attempt.get('state')=='dispatching' and mode=='publishing' and owner=='publication:'+attempt['id']):
                            raise ValueError('原发布账号占用待核对，当前账号保持暂停')
            # Pending original publication is a durable business fact, not a PID
            # lease. It guards all three modes even if account_modes was idle or
            # its former process exited. Only its first dispatch may enter.
            for pending in self._publication_rows(db,account_id,tenant):
                if pending.get('state') in ('dispatching','unknown') and not (
                        mode=='publishing' and pending['state']=='dispatching' and owner=='publication:'+pending['id']):
                    raise ValueError('原发布结果待核对，当前账号暂不能采集、回复或再次发布')
            old_publication=old.get('status')=='active' and old.get('mode')=='publishing'
            publication_finished=old_publication and self._publication_finished(db,account_id,tenant,old.get('owner'))
            if old_publication and not publication_finished and not (
                    old.get('owner')==owner and mode=='publishing' and old.get('runtime_id')==self.runtime_id):
                raise ValueError('原发布结果待核对，当前账号保持暂停')
            same = (old.get('owner') == owner and old.get('mode') == mode
                    and old.get('runtime_id') == self.runtime_id)
            if old.get('status') == 'active' and not same and not publication_finished and process_alive(old.get('pid')):
                raise ValueError('该账号正在采集评论' if old.get('mode') == 'collection' else '该账号正在发布作品，请等待当前操作结束' if old.get('mode') == 'publishing' else '该账号正在执行回复，请先暂停并等待当前操作结束')
            record = {'id': account_id, 'tenant_id': tenant, 'mode': mode,
                'owner': owner, 'status': 'active', 'runtime_id': self.runtime_id,
                'pid': os.getpid(), 'updated_at': stamp()}
            db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',
                ('account_modes', account_id, tenant, json.dumps(record, ensure_ascii=False)))
        return record

    def release(self, account_id, tenant, owner):
        with self.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            row = db.execute('SELECT body FROM records WHERE entity=? AND id=?',
                             ('account_modes', account_id)).fetchone()
            record = json.loads(row['body']) if row else None
            if not record or (record.get('tenant_id'), record.get('owner')) != (tenant, owner):
                return False
            if record.get('mode')=='publishing':
                if not self._publication_finished(db,account_id,tenant,owner):return False
            elif record.get('runtime_id')!=self.runtime_id:return False
            record.update(status='idle', updated_at=stamp())
            db.execute('UPDATE records SET body=? WHERE entity=? AND id=?',
                (json.dumps(record, ensure_ascii=False), 'account_modes', account_id))
        return True

    def release_paused_collection(self,account_id,tenant,task_id):
        """Release another process's idle collection only after atomic recheck."""
        with self.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            row=db.execute('SELECT body FROM records WHERE entity=? AND id=?',('continuous_tasks',task_id)).fetchone()
            job=json.loads(row['body']) if row else {}
            if job.get('tenant_id')!=tenant or job.get('status')!='paused' or job.get('inflight'):
                return False
            row=db.execute('SELECT body FROM records WHERE entity=? AND id=?',('account_modes',account_id)).fetchone()
            mode=json.loads(row['body']) if row else {}
            if mode.get('tenant_id')!=tenant or mode.get('mode')!='collection' or mode.get('owner')!='continuous:'+task_id:
                return False
            mode.update(status='idle',updated_at=stamp())
            db.execute('UPDATE records SET body=? WHERE entity=? AND id=?',(json.dumps(mode,ensure_ascii=False),'account_modes',account_id))
            return True


class ContinuousCollector:
    batch_interval = 40
    exhausted_interval = 1800

    def __init__(self, core,*,defer_startup_recovery=False):
        self.core = core
        self.runtime_id = uuid4().hex
        self.leases = AccountModeLeases(core.store, self.runtime_id)
        self.autostart = not defer_startup_recovery
        self._stop = threading.Event()
        self._wake = threading.Event()
        self._thread = None
        self._tick_lock = threading.Lock()
        # Nonces in Store are only CAS coordinates. These sealed RAM objects
        # carry the original accepted App session and never survive a restart.
        self._app_generations = {}
        self._app_claims = {}
        if not defer_startup_recovery:
            for job in core.store.list('continuous_tasks'):
                if job.get('status') in ACTIVE and not process_alive(job.get('pid')):
                    job.update(status='interrupted', inflight=False, next_run_at=None,
                        last_error='', message='程序退出，采集断点已保留；请明确继续采集', updated_at=stamp())
                    core.store.put('continuous_tasks', job)

    def status(self, task):
        job = self.core.store.get('continuous_tasks', task['id'])
        # Earlier releases persisted the in-flight pause text after the request
        # had finished. Present the known user-pause message from actual state;
        # preserve errors and caller-specific pause reasons.
        if (job and job.get('status') == 'paused' and
                job.get('message') == '已暂停；当前请求结束后保留断点'):
            job = {**job, 'message': ('正在暂停，等待当前读取结束' if job.get('inflight')
                                    else '已暂停，断点已保存')}
        return job or {'id': task['id'], 'tenant_id': task['tenant_id'], 'status': 'idle',
                       'inflight': False, 'batches': 0, 'read': 0, 'imported': 0, 'duplicates': 0}

    def is_active(self, ident):
        job = self.core.store.get('continuous_tasks', ident)
        return bool(job and (job.get('status') in ACTIVE or job.get('inflight')))

    def start(self, task, user, resume=False):
        with self.core.lock:
            old = self.status(task)
            runtime = self.core.adapters.xhs_page_runtime
            pending = runtime is not None and runtime.has_pending_batch(task['id'])
            if old.get('inflight') or task['id'] in self.core.running or task['id'] in self.core.sequences or pending:
                raise ValueError('任务本批仍在执行，请等待结束')
            if old.get('status') in ACTIVE:
                return self.result(task)
            if old.get('status') in ('paused', 'interrupted', 'blocked') and not resume:
                raise ValueError('任务已有保留断点，请明确继续采集')
            if not task.get('account_id') or task.get('account_removed'):
                raise ValueError('请先选择执行账号')
            generation = None
            if task.get('platform') == 'xiaohongshu' and runtime is not None:
                from assistant.xhs_app_context import mint_continuous_generation
                generation = mint_continuous_generation(self, user, task, resume)
            generation_id = generation.ident if generation is not None else uuid4().hex
            self.leases.acquire(task['account_id'], task['tenant_id'], 'collection', 'continuous:'+task['id'])
            job = {**old, 'id': task['id'], 'tenant_id': task['tenant_id'],
                'operator_id': user['id'], 'account_id': task['account_id'], 'status': 'queued',
                'inflight': False, 'next_run_epoch': time.time(), 'next_run_at': stamp(),
                'runtime_id': self.runtime_id, 'generation_id': generation_id, 'claim_id': None,
                'control_nonce': uuid4().hex,
                'pid': os.getpid(), 'last_error': '',
                'message': '已加入持续采集，按断点读取下一批', 'updated_at': stamp()}
            if (self.core.deployment_config.get('runtime') or {}).get('platform_qa_device_id'):
                job['qa_batch_start']=int(old.get('batches') or 0)
            task['status'] = 'ready'
            task.pop('pause_reason',None)
            previous = self._app_generations.get(task['id'])
            try:
                with self.core.store.connect() as db:
                    db.execute('BEGIN IMMEDIATE')
                    row = db.execute('SELECT body FROM records WHERE entity=? AND id=?',
                                     ('continuous_tasks', task['id'])).fetchone()
                    latest = json.loads(row['body']) if row else {}
                    if latest.get('inflight') or latest.get('status') in ACTIVE:
                        raise ValueError('任务本批仍在执行，请等待结束')
                    # Repeated pause may keep status and old claim unchanged.
                    # This control nonce is only optimistic DB coordination,
                    # never worker authority or an execution generation.
                    if (latest and (not self._same_attempt(latest, old)
                            or latest.get('control_nonce') != old.get('control_nonce')
                            or (latest.get('status'), latest.get('inflight')) != (old.get('status'), old.get('inflight')))
                            or not latest and old.get('status') != 'idle'):
                        raise ValueError('原采集控制状态已变化，请重新确认继续')
                    row = db.execute('SELECT body FROM records WHERE entity=? AND id=?',
                                     ('tasks', task['id'])).fetchone()
                    fresh_task = json.loads(row['body']) if row else None
                    if not fresh_task or fresh_task.get('tenant_id') != task['tenant_id']:
                        raise ValueError('原采集任务已失效')
                    normalize_continuous_task(fresh_task)
                    if generation is not None:
                        generation.check(admitted=False)
                        self._app_generations[task['id']] = generation
                    else:
                        self._app_generations.pop(task['id'], None)
                    task = {**fresh_task, 'status': 'ready'}
                    task.pop('pause_reason', None)
                    for entity, record in (('tasks', task), ('continuous_tasks', job)):
                        db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',
                            (entity, record['id'], record['tenant_id'], json.dumps(record, ensure_ascii=False)))
            except BaseException:
                if previous is None:
                    self._app_generations.pop(task['id'], None)
                else:
                    self._app_generations[task['id']] = previous
                self.leases.release(task['account_id'], task['tenant_id'], 'continuous:'+task['id'])
                raise
        if self.autostart:
            self.start_scheduler()
        else:
            self._stop.clear()
        self._wake.set()
        return self.result(task)

    def pause(self, task, reason='user_continuous', message='已暂停；当前请求结束后保留断点', only_active=False):
        with self.core.lock:
            self._app_generations.pop(task['id'], None)
            # Another process can claim the task between API read and pause.
            # Refresh and preserve its inflight flag in one SQLite transaction.
            with self.core.store.connect() as db:
                db.execute('BEGIN IMMEDIATE')
                row=db.execute('SELECT body FROM records WHERE entity=? AND id=?',('tasks',task['id'])).fetchone()
                task=json.loads(row['body']) if row else task
                row=db.execute('SELECT body FROM records WHERE entity=? AND id=?',('continuous_tasks',task['id'])).fetchone()
                job=json.loads(row['body']) if row else self.status(task)
                # Cloud hold/revocation may race the worker finishing with an
                # explicit platform error. Never replace that terminal state.
                skip=bool(only_active and job.get('status') not in ACTIVE)
                if not skip:
                    job.update(status='paused', next_run_at=None, next_run_epoch=None,
                               message=message, updated_at=stamp(), control_nonce=uuid4().hex)
                    if task.get('status')!='paused' or task.get('pause_reason') in ('user_continuous','user_reply_switch'):
                        task['pause_reason']=reason
                    task.update(status='paused', last_message=job['message'])
                    for entity,record in (('tasks',task),('continuous_tasks',job)):
                        db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',
                            (entity,record['id'],record['tenant_id'],json.dumps(record,ensure_ascii=False)))
            runtime=self.core.adapters.xhs_page_runtime
            owned_pending=runtime is not None and runtime.has_pending_batch(task['id'])
            if owned_pending:
                # The first-search worker has not yet entered a continuous batch.
                # Signal its exact scope; only that owner confirms Job cleanup.
                self.core.adapters.cancel(task['id'])
            if not skip and not job.get('inflight') and not owned_pending:
                with self.core.store.connect() as db:
                    db.execute('BEGIN IMMEDIATE')
                    self._release_matching_lease(db, job)
        if not skip:self._wake.set()
        return self.result(task)

    def result(self, task):
        task = self.core.store.get('tasks', task['id']) or task
        return {'status': self.status(task)['status'], 'task': task, 'continuous': self.status(task)}

    def start_scheduler(self):
        with self.core.lock:
            if self._thread and self._thread.is_alive():
                return
            self._stop.clear()
            self._thread = threading.Thread(target=self._loop, name='continuous-collector', daemon=True)
            self._thread.start()

    def close(self, wait=False):
        self._stop.set()
        self._wake.set()
        if wait and self._thread:
            self._thread.join(timeout=5)
        with self.core.lock:
            self._app_generations.clear()
            for job in self.core.store.list('continuous_tasks'):
                if job.get('runtime_id') != self.runtime_id or job.get('status') not in ACTIVE:
                    continue
                if job.get('inflight'):
                    with self.core.store.connect() as db:
                        db.execute('BEGIN IMMEDIATE')
                        current = self._matched_job(db, job)
                        if current is not None:
                            if current.get('status') in ACTIVE:
                                current.update(status='interrupted', next_run_at=None, next_run_epoch=None,
                                    message='采集已停止，断点保留；重新打开后请继续', updated_at=stamp(),
                                    control_nonce=uuid4().hex)
                                self._write_job(db, current)
                            else:
                                self._retire_terminal(db, current)
                    self.core.adapters.cancel(job['id'])
                else:
                    self._finish(job, 'interrupted', '采集已停止，断点保留；重新打开后请继续')

    def revoke_executor(self, executor):
        """Stop notifications retire only this exact bound executor's RAM facts."""
        with self.core.lock:
            for ident, generation in list(self._app_generations.items()):
                if generation.session.executor is executor:
                    self._app_generations.pop(ident, None)
            runtime = self.core.adapters.xhs_page_runtime
            cancel = []
            if runtime is not None:
                with runtime.lock:
                    for ident, scope in list(runtime.jobs.items()):
                        if getattr(getattr(scope.app_context, 'session', None), 'executor', None) is executor:
                            if scope.finished and not scope.result_released:
                                scope.user_cancelled = True
                            else:
                                entry = runtime.entries.get(scope.root)
                                if entry is not None and entry.batch_scope is scope:
                                    cancel.append(scope)
                for scope in cancel:
                    runtime.close_account(scope.root, expected_scope=scope)

    def _loop(self):
        while not self._stop.is_set():
            try:
                self.tick()
            except Exception:
                # A damaged task must not kill the host's scheduler. Each claimed
                # task records its error below; retry polling performs no request.
                pass
            self._wake.wait(.5)
            self._wake.clear()

    def tick(self, epoch=None):
        """At most one ready batch. Public for deterministic offline tests."""
        if not self._tick_lock.acquire(blocking=False):
            return False
        try:
            return self._tick(time.time() if epoch is None else epoch)
        finally:
            self._tick_lock.release()

    def _tick(self, epoch):
        jobs = sorted((job for job in self.core.store.list('continuous_tasks')
            if job.get('status') in ACTIVE and job.get('runtime_id') == self.runtime_id
            and not job.get('inflight') and float(job.get('next_run_epoch') or 0) <= epoch),
            key=lambda job: (float(job.get('next_run_epoch') or 0), job['id']))
        if not jobs:
            return False
        job = jobs[0]
        task = self.core.store.get('tasks', job['id'])
        user = self.core.store.get('users', job.get('operator_id'))
        if not task:
            self._finish(job, 'blocked', '采集任务已不存在')
            return True
        if not user or user.get('disabled'):
            self._finish(job, 'blocked', '操作员工已停用，请重新确认')
            return True
        with self.core.lock:
            latest = self.core.store.get('continuous_tasks', job['id'])
            if not self._same_attempt(latest, job):
                return True
            if latest.get('status') not in ACTIVE or task.get('status') == 'paused':
                self._finish(latest, 'paused', '任务已暂停')
                return True
            runtime=self.core.deployment_config.get('runtime') or {}
            if (isinstance(runtime,dict) and runtime.get('portable_employee_release') is True
                    and not self.core._employee_release_allowed()):
                self.pause(task,'employee_lease_expired','云端采集许可已过期；断点已保留，请重新确认后继续',only_active=True)
                return True
            if (self.core.deployment_config.get('runtime') or {}).get('platform_qa_device_id'):
                limit=self.core._qa_continuous_batch_limit()
                if limit and int(latest.get('batches') or 0)-int(latest.get('qa_batch_start') or 0)>=limit:
                    self.pause(task,'qa_trial_limit','本次验证已暂停，可继续')
                    return True
            # Continuous collection is cursor-driven. Legacy import quotas are
            # not a stopping condition; 2000/5000 daily counts are notices only.
            current = datetime.now().strftime('%H:%M')
            start, end = task.get('time_start', '00:00'), task.get('time_end', '23:59')
            if not (start <= current <= end if start <= end else current >= start or current <= end):
                self._waiting(job, epoch+60, '等待任务运行时段', 'outside_hours')
                return True
            try:
                claimed=self._claim(job)
            except Exception as exc:
                self._finish(job, 'blocked', str(exc))
                return True
            if not claimed:
                return True
            job,task=claimed
            before = self._checkpoint(task)
            try:
                self.leases.acquire(task['account_id'], task['tenant_id'], 'collection', 'continuous:'+task['id'])
            except ValueError as exc:
                self._finish(job, 'blocked', str(exc))
                return True
        result = None
        error = ''
        claim = self._app_claims.get(job['id'])
        try:
            if claim is not None:
                from assistant.xhs_app_context import continuous_claim_call
                with continuous_claim_call(claim) as execution_guard:
                    result = self.core._run({'id': task['id']}, self.core._public(user), task['tenant_id'],
                        continuous_owner=task['id'], execution_guard=execution_guard)
            else:
                result = self.core._run({'id': task['id']}, self.core._public(user), task['tenant_id'], continuous_owner=task['id'])
        except Exception as exc:
            error = str(exc)
        try:
            with self.core.lock:
                current = self.core.store.get('continuous_tasks', job['id'])
                if not self._same_attempt(current, job):
                    return True
                task = self.core.store.get('tasks', job['id'])
                if current.get('status') in ('paused', 'interrupted') or self._stop.is_set():
                    self._finish(current, current.get('status') if current.get('status') in ('paused', 'interrupted') else 'interrupted', '采集已暂停，断点保留')
                    return True
                if claim is not None:
                    try:
                        claim.check()
                    except Exception as exc:
                        error = str(exc)
                if error or not result or result.get('status') == 'blocked':
                    self._finish(current, 'blocked', error or (result or {}).get('message', '采集异常'))
                    return True
                batch = task.get('last_batch') or {}
                for key in ('read', 'imported', 'duplicates', 'filtered'):
                    current[key] = int(current.get(key, 0)) + int(batch.get(key, 0))
                current['batches'] = int(current.get('batches', 0)) + 1
                current['last_batch'] = batch
                current['last_error'] = ''
                self._milestones(current,task)
                if (self.core.deployment_config.get('runtime') or {}).get('platform_qa_device_id'):
                    limit=self.core._qa_continuous_batch_limit()
                    if limit and int(current['batches'])-int(current.get('qa_batch_start') or 0)>=limit:
                        self._finish(current, 'paused', '本次验证已暂停，可继续', pause_reason='qa_trial_limit')
                        return True
                if result.get('exhausted'):
                    self._waiting(current, max(epoch,time.time())+self.exhausted_interval, '本轮评论已读完，30分钟后检查增量', 'range_exhausted')
                elif self._checkpoint(task) == before and not result.get('imported'):
                    self._finish(current, 'blocked', '分页断点未前进，已暂停以避免重复请求')
                else:
                    self._waiting(current, max(epoch,time.time())+self.batch_interval, '本批完成，等待下一批', 'batch_interval')
        finally:
            # No capability check here: old cleanup removes only its own RAM
            # claim, even when pause/session changes have retired the generation.
            with self.core.lock:
                if claim is not None and self._app_claims.get(job['id']) is claim:
                    self._app_claims.pop(job['id'], None)
        return True

    def _claim(self,candidate):
        with self.core.lock:
            previous = self._app_claims.get(candidate['id'])
            try:
                return self._claim_locked(candidate)
            except BaseException:
                if previous is None:
                    self._app_claims.pop(candidate['id'], None)
                else:
                    self._app_claims[candidate['id']] = previous
                raise

    def _claim_locked(self, candidate):
        with self.core.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            row=db.execute('SELECT body FROM records WHERE entity=? AND id=?',('continuous_tasks',candidate['id'])).fetchone()
            job=json.loads(row['body']) if row else {}
            row=db.execute('SELECT body FROM records WHERE entity=? AND id=?',('tasks',candidate['id'])).fetchone()
            task=json.loads(row['body']) if row else {}
            if (job.get('status') not in ACTIVE or job.get('inflight')
                    or job.get('runtime_id')!=self.runtime_id or not self._same_attempt(job, candidate)
                    or not task or task.get('status')=='paused'
                    or task['id'] in self.core.running or task['id'] in self.core.sequences
                    or self.core.adapters.xhs_page_runtime is not None
                        and self.core.adapters.xhs_page_runtime.has_pending_batch(task['id'])):
                return None
            claim = None
            if task.get('platform') == 'xiaohongshu' and self.core.adapters.xhs_page_runtime is not None:
                from assistant.xhs_app_context import mint_continuous_claim
                generation = self._app_generations.get(task['id'])
                if generation is None or generation.ident != job.get('generation_id'):
                    raise ValueError('持续采集的原设备会话已失效，请明确继续')
                claim = mint_continuous_claim(generation)
            if task.get('exhausted'):
                task['last_scan_checkpoint']={key:task.get(key) for key in ('pipeline','next_cursor','next_page')}
                task.update(exhausted=False,next_cursor='',next_page=1)
                task.pop('pipeline',None)
                db.execute('UPDATE records SET body=? WHERE entity=? AND id=?',
                    (json.dumps(task,ensure_ascii=False),'tasks',task['id']))
            job.update(status='running',inflight=True,claim_id=claim.ident if claim is not None else uuid4().hex,
                       updated_at=stamp(),message='正在读取一批评论')
            db.execute('UPDATE records SET body=? WHERE entity=? AND id=?',
                (json.dumps(job,ensure_ascii=False),'continuous_tasks',job['id']))
            if claim is not None:
                self._app_claims[task['id']] = claim
            return job,task

    def _milestones(self,job,task):
        today=date.today().isoformat()
        rows=[row for row in self.core.store.list('leads',task['tenant_id'])
              if row.get('task_id')==task['id'] and str(row.get('created_at','')).startswith(today)]
        count=len(rows)
        entries=list(job.get('daily_milestones') or [])
        known={(entry.get('date'),entry.get('count')) for entry in entries}
        for threshold in (2000,5000):
            if count>=threshold and (today,threshold) not in known:
                entries.append({'date':today,'count':threshold,'reached_at':stamp(),'informational':True})
        job.update(daily_imported=count,daily_milestones=entries)

    @staticmethod
    def _checkpoint(task):
        return json.dumps({key: task.get(key) for key in ('pipeline', 'next_cursor', 'next_page', 'exhausted')}, sort_keys=True)

    def _waiting(self, job, epoch, message, reason):
        with self.core.lock, self.core.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            current = self._matched_job(db, job)
            if current is None:
                return False
            if current.get('status') not in ACTIVE:
                self._retire_terminal(db, current)
                return False
            if (current.get('status'), current.get('inflight')) != (job.get('status'), job.get('inflight')):
                return False
            task = self.core.store.get('tasks', job['id']) or {}
            if task.get('platform') == 'xiaohongshu' and self.core.adapters.xhs_page_runtime is not None:
                try:
                    generation = self._app_generations.get(job['id'])
                    if generation is None or generation.ident != job.get('generation_id'):
                        raise ValueError('持续采集的原设备会话已失效，请明确继续')
                    generation.check()
                except Exception as exc:
                    current.update(status='blocked', last_error=str(exc), message=str(exc))
                    self._retire_terminal(db, current)
                    return False
            job.update(status='waiting', inflight=False, next_run_epoch=epoch,
                       next_run_at=stamp(epoch), message=message, wait_reason=reason, updated_at=stamp())
            self._write_job(db, job)
        return True

    def _finish(self, job, status, message, *, pause_reason=None):
        with self.core.lock, self.core.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            current = self._matched_job(db, job)
            if current is None:
                return False
            if current.get('status') not in ACTIVE:
                return self._retire_terminal(db, current)
            if (current.get('status'), current.get('inflight')) != (job.get('status'), job.get('inflight')):
                return False
            runtime = self.core.adapters.xhs_page_runtime
            if (job['id'] in self.core.running or runtime is not None
                    and runtime.has_pending_batch(job['id'])):
                return False
            job.update(status=status, inflight=False, next_run_at=None, next_run_epoch=None,
                last_error=message if status == 'blocked' else '', message=message, updated_at=stamp())
            if status == 'interrupted' or pause_reason is not None:
                job['control_nonce'] = uuid4().hex
            self._write_job(db, job)
            if pause_reason is not None:
                row = db.execute('SELECT body FROM records WHERE entity=? AND id=?',
                                 ('tasks', job['id'])).fetchone()
                task = json.loads(row['body']) if row else None
                if task is not None:
                    task.update(status='paused', pause_reason=pause_reason, last_message=message)
                    db.execute('UPDATE records SET body=? WHERE entity=? AND id=?',
                        (json.dumps(task, ensure_ascii=False), 'tasks', task['id']))
            self._release_matching_lease(db, job)
            generation = self._app_generations.get(job['id'])
            if generation is not None and generation.ident == job.get('generation_id'):
                self._app_generations.pop(job['id'], None)
        return True

    def _retire_terminal(self, db, current):
        # Another process may pause inside our read-to-write gap. Its exact
        # terminal state/message wins; only this old claim's physical completion
        # permits inflight/lease retirement. Permission loss never gates cleanup.
        runtime = self.core.adapters.xhs_page_runtime
        if (current['id'] in self.core.running or runtime is not None
                and runtime.has_pending_batch(current['id'])):
            return False
        current.update(inflight=False, next_run_at=None, next_run_epoch=None)
        self._write_job(db, current)
        self._release_matching_lease(db, current)
        generation = self._app_generations.get(current['id'])
        if generation is not None and generation.ident == current.get('generation_id'):
            self._app_generations.pop(current['id'], None)
        return True

    @staticmethod
    def _same_attempt(current, candidate):
        fields = ('id', 'tenant_id', 'runtime_id', 'generation_id', 'claim_id')
        return bool(current and all(current.get(key) == candidate.get(key) for key in fields))

    def _matched_job(self, db, candidate):
        row = db.execute('SELECT body FROM records WHERE entity=? AND id=?',
                         ('continuous_tasks', candidate['id'])).fetchone()
        current = json.loads(row['body']) if row else None
        return current if self._same_attempt(current, candidate) else None

    @staticmethod
    def _write_job(db, job):
        db.execute('UPDATE records SET body=? WHERE entity=? AND id=?',
                   (json.dumps(job, ensure_ascii=False), 'continuous_tasks', job['id']))

    def _release_matching_lease(self, db, job):
        runtime = self.core.adapters.xhs_page_runtime
        if (self._matched_job(db, job) is None or job.get('inflight')
                or job['id'] in self.core.running or runtime is not None
                    and runtime.has_pending_batch(job['id'])):
            return False
        row = db.execute('SELECT body FROM records WHERE entity=? AND id=?',
                         ('account_modes', job.get('account_id'))).fetchone()
        mode = json.loads(row['body']) if row else {}
        if ((mode.get('tenant_id'), mode.get('owner'), mode.get('mode'), mode.get('runtime_id'))
                != (job['tenant_id'], 'continuous:'+job['id'], 'collection', job.get('runtime_id'))):
            return False
        mode.update(status='idle', updated_at=stamp())
        db.execute('UPDATE records SET body=? WHERE entity=? AND id=?',
                   (json.dumps(mode, ensure_ascii=False), 'account_modes', job['account_id']))
        return True
