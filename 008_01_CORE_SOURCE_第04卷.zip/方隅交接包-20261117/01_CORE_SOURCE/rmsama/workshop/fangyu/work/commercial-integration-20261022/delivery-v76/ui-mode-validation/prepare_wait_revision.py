from pathlib import Path
import hashlib, json
W = Path(__file__).resolve().parent
R = W / 'wait-for-readonly-snapshot'
assert not R.exists()
R.mkdir()
for name in ('serve_ui.py',):
    (R/name).write_bytes((W/name).read_bytes().replace(b'P=W.parents[3];S=',b'P=W.parents[4];S='))
raw = (W/'test_mode_ui.cjs').read_bytes()
text = raw.decode('utf-8')
old = "await frame.locator('[data-task-status=\"paused\"]').waitFor();"
new = old + "\n await frame.getByText('该账号正在执行回复，请先暂停并等待当前操作结束',{exact:true}).first().waitFor({state:'visible',timeout:15000});"
assert text.count(old)==1
text = text.replace(old,new)
old = "})().catch(e=>{fs.writeFileSync"
new = "})().catch(async e=>{if(browser){const p=browser.contexts()[0]?.pages()[0];if(p){await p.screenshot({path:path.join(W,'failure.png'),fullPage:true}).catch(()=>{});const f=p.frames().find(x=>x.url().includes('/canvas.html'));if(f)fs.writeFileSync(path.join(W,'failure-body.txt'),await f.locator('body').innerText().catch(()=>''));}}fs.writeFileSync"
assert text.count(old)==1
text=text.replace(old,new)
(R/'test_mode_ui.cjs').write_text(text,encoding='utf-8')
(R/'PREPARATION.json').write_text(json.dumps({'reason':'Wait for original asynchronous scoped read-only snapshot, not just initial paused draft paint; no product changes','originalTestSha256':hashlib.sha256(raw).hexdigest(),'revisionSha256':hashlib.sha256((R/'test_mode_ui.cjs').read_bytes()).hexdigest(),'oldRedRetained':True},indent=2),encoding='utf-8')
print(str(R))
