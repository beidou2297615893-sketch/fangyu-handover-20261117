from pathlib import Path
import hashlib,json,shutil,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=W.parents[2];S=P/'work/parallel-integration-20261018/final-integration/stage-02/project';F=S.parents[1]/'candidate-unified-v77'
Q=W/'qa-only-project';O=W/'source-candidate';Q.mkdir(exist_ok=True)
read=lambda p:json.loads(p.read_text('utf-8-sig'))
pins=read(F/'UNIFIED-PINS.json')['files'];copied=[]
for row in pins:
 rel=row['path']
 if rel.startswith(('work/ui-native-r57/releases/','work/ui-native-r57/candidates/','work/ui-native-r57/run_candidate.')):continue
 if 'state' in Path(rel).parts and not rel.endswith('state/production-workspace.json'):continue
 src=S/rel
 if not src.is_file():continue
 assert Path(rel).suffix.lower() not in ('.db','.sqlite','.sqlite3'),rel
 body=src.read_bytes();assert hashlib.sha256(body).hexdigest()==row['sha256'],rel
 dest=Q/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(body);copied.append(rel)
for src in O.rglob('*'):
 if src.is_file():
  dest=Q/src.relative_to(O);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(src.read_bytes())
# The stage source discovery may copy these licensed notices; copy only notices,
# not a Python installation, environment, customer files or runtime state.
site=P/'work/desktop-python/Lib/site-packages'
for pattern in ['pywebview-*.dist-info/licenses/LICENSE','pythonnet-*.dist-info/licenses/LICENSE','clr_loader-*.dist-info/licenses/LICENSE','bottle-*.dist-info/licenses/LICENSE']:
 for src in site.glob(pattern):
  dst=Q/'work/desktop-python/Lib/site-packages'/src.relative_to(site);dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(src.read_bytes())
(W/'QA-SOURCE-INPUTS.json').write_text(json.dumps({'label':'dm-product-integration-qa-only','project':str(Q),'sourceBaseline':str(S),'baseFinalPins':str(F/'UNIFIED-PINS.json'),'canonicalSourceFilesCopied':len(copied),'noDatabaseOrCustomerSessionCopied':True,'noFormalFreezeInstallPromotion':True,'stageOnlyForOwnOriginalFactoryTests':True},ensure_ascii=False,indent=2),'utf-8')
print(str(Q))
