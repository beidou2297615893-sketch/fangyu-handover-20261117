from pathlib import Path
import hashlib, json
D=Path(__file__).resolve().parent
T=D.parent/'next-release-integration-preflight/standard-tools-v77'
B=T/'standard-held-clean-v77'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
build=json.loads((B/'BUILD.json').read_text('utf-8'))
assert build['files']==3951 and build['installerSha256']=='a8220d69b0f77b063d79fa8d7eaa2abe39f7abed59397df31d792a016ff4d2e3'
paths=['BUILD.json','STAGE.json','FILE-MANIFEST.json','standard_entry.py','installer.protected.py',
 'payload/project/SHIPPED-PINS.json','payload/project/HELD-STANDARD-MANIFEST.json',
 'dist/FangyuWorkbench/FangyuWorkbench.exe',build['portableZip'],build['installer']]
pins={rel:{'sha256':sha(B/rel),'bytes':(B/rel).stat().st_size} for rel in paths}
assert pins[build['portableZip']]['sha256']==build['portableSha256']
assert pins[build['installer']]['sha256']==build['installerSha256']
out={'status':'FIXED_V77_STANDARD_BUILD_INPUTS_FOR_INDEPENDENT_REVIEW_NOT_DELIVERY_APPROVAL',
 'rootFinalPinsSha256':sha(D/'FINAL-PINS.json'),'rootFinalPins':json.loads((D/'FINAL-PINS.json').read_text('utf-8')),
 'package':str(B),'builderSha256':sha(T/'build_clean_next.py'),'toolingSha256':sha(T/'TOOLING.json'),
 'pins':pins,'codeAndArchivesStoppedWriting':True,'nativeStarted':False,'productionAccess':False,
 'realPlatformOrModelCalls':0,'publicOutputCopied':False,'independentPackageReviewPending':True}
target=D/'BUILD-FIXED-PINS.json';assert not target.exists()
target.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':out['status'],'descriptorSha256':sha(target),'installerSha256':build['installerSha256'],'files':build['files']}))
