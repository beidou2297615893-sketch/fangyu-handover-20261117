"""Preserve old chronology and publish current, evidence-bound root handoff."""
from pathlib import Path
from datetime import datetime, timezone, timedelta
import hashlib
import json
import shutil

P = Path('C:/积木软件工坊/项目/方隅公寓客户版')
W = P / 'work/commercial-integration-20261022'
D = W / 'delivery-v82'
now = datetime.now(timezone.utc)
stamp = now.strftime('%Y%m%dT%H%M%SZ')
local = now.astimezone(timezone(timedelta(hours=8))).strftime('%Y-%m-%d %H:%M')
target = W / 'HANDOFF-THREE-IN-ONE-LATEST.md'
archive = W / 'handoff-history' / ('HANDOFF-BEFORE-F82-FINAL-' + stamp + '.md')
archive.parent.mkdir(parents=True, exist_ok=True)
assert not archive.exists()
shutil.copy2(target, archive)
old_sha = hashlib.sha256(archive.read_bytes()).hexdigest()
install = json.loads((D / 'INSTALLATION-FINAL.json').read_text('utf-8-sig'))
delivery = json.loads((D / 'STANDARD-DISTRIBUTION-DELIVERY.json').read_text('utf-8-sig'))
snapshot = W / 'status-visibility/CURRENT-STATUS-20261023T103032Z.json'
status = json.loads(snapshot.read_text('utf-8-sig'))
assert install['candidate'] == 'candidate-unified-v82'
assert install['allSevenBusinessDigestsUnchanged'] is True
assert delivery['sha256'] == '90ae659a9bab079c50b45ec68b341ab2cc72e134aac32d6f12aedd8be5a5b488'
assert status['counts']['leads'] == 1888 and status['counts']['accounts'] == 3
text = f'''# 方隅三合一总控：当前交接

更新：{local} 北京时间。完整主目标 ACTIVE，尚未完成商业验收。本轮真实交付进展：F82已合入正式源、装到本机下一启动入口、完成独立编译安装包并本地交付；本人当前旧窗口未被关闭。原完整长交接逐字存于 `{archive.relative_to(W).as_posix()}`（SHA256 {old_sha}），其旧实时状态不再采用。

## 完整目标与保护边界

方隅原工作台、自动发帖、灵絮移植全部业务合入一个产品，原 THREE-IN-ONE-SCOPE.md 和18个原始ID仍有效。最新版逐项对账见 `full-scope-f82-reconciliation/revision-2/全量范围简表.md` 与 `完整范围对账.json`（文件名以该目录实际清单为准），FINAL 9dc3eb96c857ba68607aca1a387bf2ce0003d929604e2952be6b1d78e6330be8，SEALED 91193b1923fe22a29a9ffbb7cc3e2e477208ede38c110d8df036f02d46024c0e。保留43来源、8业务族及所有原需求，不把329角色目录当真实多角色编排。

沿用已认可新增三图和浅色蓝绿公寓画风；古北1—12个月按租期分组，其他12店隔离。普通Windows电脑不要求独显、本地大模型或新付费。账号、客户、人工更正、回复、任务、断点及unknown原key均保护，禁止旧备份覆盖现DB。

用户已授权全部并行。root独占正式S/F/N/outputs，agents只写各自W目录；不建工作树，不接管其他客户。本人Esc已停止Native电脑点击，之后只做自有隔离headless/CLR/源码验证，不操作或关闭本人原生窗口、浏览器、会话。禁止真实评论/私信/点赞/发布、绕过验证码人脸、新付费密钥权限或模型下载；本人依赖保留准确断点后继续其他工程。automation10已08:00删除，不重建；gpt-6.1-sol切换已一次成功，不重复切换、自发消息或使用重置券。

P=C:/积木软件工坊/项目/方隅公寓客户版
F=P/work/parallel-integration-20261018/final-integration
S=F/stage-02/project（正式源已CAS合入F82）
N=P/work/ui-native-r57（原桌面入口，下次启动F82）
W=P/work/commercial-integration-20261022
PY=P/work/desktop-python/Scripts/python.exe
NODE=C:/Users/rmsama/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe
Documents/ChatGPT/自动获客系统不是正式源，不改其他客户实例。

## 当前运行与最新用户反馈

用户问“真的在运行吗、不能可视化、除了等能做什么”。18:30只读快照 `status-visibility/CURRENT-STATUS-20261023T103032Z.json`：原63055界面服务HTTP200 stable、release ui-r57-20261023T054104Z-893b8383（F79旧窗口）。数据库3账号、1888评论、40任务（5ready/35paused，无running）、1794AI分析、1465租住判断、4回复记录。30暂停原collection_error、5未分类；本地账号ready不证明平台自然登录。不要把开发在做说成实采正在跑。

root已简明告知真实状态、新版已装而旧窗仍在；用户可保存草稿、正常关旧工作台，从原桌面快捷方式重开后选择采集账号；没有要求重装、迁移或反复扫码。原窗口是否实际重开尚未验证。open_in_codex打开进展MD返回queued，不可说本人已看到。当前快照不是持续监控。

之前只读暂停分类在 `acquisition-live-status-readonly`：35暂停多为10/17—19旧登录文本，6个461 requires_auth=false不证明登录失效，只有4个历史明确auth/captcha；不盲目重试或强制登录。原任务unknown保留，新批可单独选当前账号。

## F82已完成安装与数据保护

正式固定 F/candidate-unified-v82：release {install['release']}，3856源文件、538资源。
UNIFIED 36a601743288689d6cff3159337ee4f548d1ee0d05366a28a83dd683a326f500
STAGED 58581f4644aaf17bea481dd45d6ef19713bf6bdf97a303ffd790be940bb7c958
RELEASE d563f95ffe26cfef9c3d0034a17a84b0b730fa02ed32ccb86f10cfd3d4d20160
N/run_workbench.py {install['launcherSha256']}
N/FROZEN.json {install['frozenSha256']}
binding {install['bindingSha256']} 未改。

唯一安装回执 `delivery-v82/INSTALLATION-FINAL.json` SHA aea29dc53636aa8ce69de480bd9a67c80e40fb36f38103ab147d24faddd88665。root先完整SQLite一致性备份25,530,368字节/quick_check=ok（CURRENT-BUSINESS-BACKUP.json），再做304源文件精确before CAS合并/逐文件备份 source-before。下一入口沿成熟双文件事务/备份，root独立审原作者方案后仅INSTALLATION_REVIEWED false→true；该明确例外前后源均保存，不谎称旧seal仍匹配改后entry。原N --check和--self-test实际exit0，未构造本人窗口。

安装前后七类业务逐行摘要及3账号元数据完全相同：leads1888/replies4/tasks40/ai_cache1794/rental_assessments_v1 1465/unique_leads关联1888/contact_events3。未读会话字段、未恢复旧库。完整备份含现有完整DB，留在本项目，不交入安装包或外部。

此前按稳定平台作者去重1129人≠1888评论；DeepSeek1794可比，1503同/291异，一致83.78%≠准确率。DS高144评论/133人，Codex261/215，Codex侧车覆盖1888含17空正文，没有覆盖软件DS或人工。其他12店原审计见store-intent-f79-audit，当前安装无DB写入，不能据此称已核门店现价库存设施。

## 本轮实际功能及验证

F82新接：访谈本人阶段小结确认；可采用/撤回/版本化的复盘经验和下一任务显式引用；真实query公共摘要检索→待核资料；DM固定命令/typed回执/跨账号防重/unknown同key；原Bridge受控直播观察与原客户分析入库链。保留F81排程、OCR/SAPI预览、受限扫描PDF、DM本地草稿、账号删除/网页/退休原key核对、任务账号分离等原流程。

组合目录 `next-release-f81-expansion-composition/project` 已冻结，不再改；304独立变更精确合版。两个Bridge pending类型并存，直播只接受server注入的精确_bridgeConnId经原conn.ws/sendEval回执；DM generic WS拒绝、HTTP/api/result拒绝typed，不能误禁直播合法原WS。managed script、路由依赖、190审核材料、各自SOURCE根和Review hash已按实际依赖重pin，purpose/scope/grant边界不放宽。vendor app.py仅2行trusted runtime root修复；原普通受限scope仍拒绝，不据路径可达宣称已开放。

实际固定F82验证（均结束，不复跑无变化测试）：
- expansion-f82-joint-regression：原47业务+8账号+11关键词wrapper，6步骤exit0；root RESULT PASS_ACTUAL_BOUND_AGGREGATE。
- expansion-f82-dm-live-joint-review：22组/193HTTP/33真实Node进程（24受控CLI、9Bridge VM），含同客户并发仅1次派发、unknown重开零派发、直播原分析Worker与退休采集账号、5公开规则版本键/无私有政策。FINAL.json 181fd3a7b471742fe4eb16ef1c553c8002cfcfca5c882209eaea770d7f9cd546，SEALED861b75d9d114ca8e43ef8ed61816d5f0966f1d30827f90a9cd4e18fcc1591df6。
- expansion-f82-content-joint-validation：21组/301完整HTTP；原完整index/fit宽1255窄390共37检查，最小14.45px/no pageerrors；长请求时其他查询0.141秒；原HTML回放而非新平台检索。FINAL-RECEIPT 4def961de5e67e6305ba069d380f0f2bb215943d650c57f9e021d9f8f69e5eb3，SEALED a691dcdad5ff7a618fb085b3ab01352018658e9dece7d3d56d6d6a820f6beb46。
- combined-bridge-final-pin-review：36静态+8原Router/Hub本机WS断言通过，FINAL.json 1bcc36b9869ccd4b73aee97581daaadc61f46f21f69609cde1dfca46ecfcf698，SEALED491fe75c19540de4c0d619771a08658ce405e6e0fc87595c9bcb8fb960f46769。
- delivery-v82/AGGREGATE-VALIDATION.json 9e1328ebb395ac3c7b30b95e302a77f440c110574192bb80a76d729f5ab881f8；FINAL-PINS2e5e298e6d8094503320c9c258b54ab7d7ae418f65cd8dabe4099222bb192f8f。
所有上述自有服务/测试进程已关闭，未停止本人63055。平台/真实Native/第二实机证据仍缺，不把CLI合成回执、headless及CLR当平台实采。

## 普通安装包与人用成果

`outputs/三合一交付/方隅工作台安装程序.exe`，{delivery['bytes']}字节，SHA {delivery['sha256']}。root真实CAS替换并备份旧F81安装包及2份说明，见 delivery-v82/STANDARD-DISTRIBUTION-DELIVERY.json；旧INSTALLATION-FINAL普通交付pending仅是当时状态，不修改历史回执。

f82-standard-package-candidate全新编译，不复用旧EXE，3854shipped/4499packagefiles、38许可、640runtimefiles、155stdlibzip、1021PYZ等价。独审 f82-standard-package-independent-review 实际重跑clean7/SFX3+受控编译probe5组35HTTP；FINAL-RECEIPT bc62c902646dd9606661a374a78c5bba3324331d7df472019e096454e90adcae，SEALED4271d17f507d2bed71a9b9a39682d5342e6089aafac9f77b4eaf4f055c413495。公共解析器原响应回放，非新外网；编译账户组件实际scope=None仍component_review_pending，包是受限技术验收，不是商业放行成品。无本机客户/账号/Cookie、无GPU/本地模型要求，第二实体机未验。

用户进展 `outputs/整合进度/工作台整合与客户数据核对.md` 已18:27更新F82，`复盘经验窄窗口验证.png`为实际headless自有资料，root已看并复制；不是本人已安装Native截图。原高意向/差异表 `outputs/评论分析对照/DeepSeek与Codex评论分析对照.xlsx` 保留。给人文件同时给完整文件与文件夹路径，不泄漏内部字段/规则编号。

## 正在继续：先查真实live，不重复启动

1. knowledge_review_4 现续 `multirole-after-f82-candidate`：先核原组件与F82接点，再补真实多角色持久串联；原Store/队列/key、取消/unknown重开/版本失效/隔离，最终审核与发布仍人工。零模型/平台，不建第二套记忆或登录。须先回可行方案；不可只用329目录当完成。
2. schedule_finish_4 现续 `public-article-after-f82-candidate`：复用已核MIT content-pipeline正文路线，用户明确选单一公开来源→限额读取→原URL证据→预览→本人fact/hypothesis→原CAS；无后台扫量、Cookie/图片脚本/私网或新费用，unknown原key零重读。先回接点再实现，仅自有W源候选。热点联想仍待核且非事实。
3. experience_independent_review 正封 `asr-existing-component-feasibility-after-f82`：Qwen/Whisper原脚本/creator-buddy/dbskill/字幕等实际追链，18环境、9相关module均无可用ASR；原run_qwen离线自有音频实际exit3无转写，creator-buddy后端空。1.88GB权重/新依赖不能偷偷下载，剪口播公开上传收费链不用于默认客户录音。原字幕→segments→证据brief→知识preview已通，但明确不是ASR。建议显式服务端ASR，未经授权不新付费/上传音频；完整G05仍缺。

UI两处后继已封、未安装：`ui-copy-density-after-f82-candidate`，仅content-guided删审计说明、public-research域名呈现保完整安全链接；原binder尾完全不变。FINAL5a69f56c8a89d1d146d437ce47ab2f1b0615a91e9162a75357eb7c58e9e1f185，SEALEDc4ed7fc5958f934fd565c55eea910fa49856d1c17c01ea13a66dc383b5237614；SOURCEe3648d371433fe4c848d36398ee69af91cd2ea01b4160a33a7c90a4de4f02884。语法/补丁正逆/10隔离渲染检查通过，仅小视图非完整index/factory，不为两文案再造全冻结包；下次有实质业务一起合。

root暂无live exec，旧root85332/5467/82971等终态。agents真实状态用list_agents，工具句柄以agent更新为准。原字节/seal不可改；反例只改自己的夹具且保留红证据，勿反复重测已绿旧版本。下一步继续上述实质工程，真实平台/本人/第二机保断点。完整goal仍active，不complete，也不是blocked：仍有本地可推进任务。不要只审计或更新报告而不做功能。
'''
assert hashlib.sha256(target.read_bytes()).hexdigest() == old_sha
target.write_text(text, encoding='utf-8')
status_path = P / 'memory/STATUS.md'
status_old = status_path.read_bytes()
status_backup = D / ('MEMORY-STATUS-BEFORE-' + stamp + '.md')
status_backup.write_bytes(status_old)
prefix = f'''# 最新：{local} 方隅三合一F82已装下一入口，原窗口仍旧版

权威接续：work/commercial-integration-20261022/HANDOFF-THREE-IN-ONE-LATEST.md。正式源已F82，本机下次启动F82（ui-r57-20261023T095243Z-1c9a271f）；18:30只读现窗口HTTP200仍F79，无running采集。3账号/1888评论/40任务/1794分析/1465判断/4回复保留，更新前后七类逐行摘要相同，已完整备份，未覆盖旧库或关闭本人窗口。

本轮新增本人阶段小结、可撤回复盘经验、明确公共检索资料、typed私信与受控直播链路；固定源/原入口/完整headless与受控编译包测试通过，不等于真实平台/Native首用。输出307396837B受限技术安装包已真实交付，非商业放行；普通scope=None拒绝仍保留。录音ASR、多角色编排、正文热点、真实发送/发布/直播及第二实机等仍未完成。完整18项主目标active，保原风格与所有业务范围；当前3agent继续各自W候选，不重复已终态任务。

原STATUS全文备份 work/commercial-integration-20261022/delivery-v82/{status_backup.name}。下文是历史记录，不采用其中旧窗口/候选实时结论。

---

'''
status_path.write_bytes(prefix.encode('utf-8') + status_old)
receipt = {'utc': now.isoformat(), 'handoff': str(target),
           'handoffSha256': hashlib.sha256(target.read_bytes()).hexdigest(),
           'historyPath': str(archive), 'historySha256': old_sha,
           'memoryStatusSha256': hashlib.sha256(status_path.read_bytes()).hexdigest(),
           'memoryStatusBackup': str(status_backup),
           'productionOrInstalledSourceChanged': False}
(D / ('HANDOFF-REFRESH-' + stamp + '.json')).write_text(json.dumps(receipt, ensure_ascii=False, indent=2)+'\n', 'utf-8')
print(json.dumps(receipt, ensure_ascii=False))
