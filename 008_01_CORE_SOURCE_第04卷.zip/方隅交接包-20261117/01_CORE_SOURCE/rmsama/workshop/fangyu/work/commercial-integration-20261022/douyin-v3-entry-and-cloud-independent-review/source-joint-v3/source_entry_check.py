"""Relocatable standard Windows entry over the unchanged fixed r57 host.

This independently installed application initializes only its own empty data
directory. It grants no enterprise/device/platform permissions. Existing local
production binding and sessions are never consulted or copied.
"""
from pathlib import Path, PurePosixPath
import argparse, hashlib, http.client, importlib.util, importlib.machinery, json, os, socket, stat, sys
import threading
import time, uuid
sys.dont_write_bytecode = True
RELEASE_ID = 'ui-r57-20261023T095243Z-1c9a271f'
RELEASE_SHA = 'b0ae453152ee7411c6ab68c933c9e267d711371783824b45fa8330de3a964b9f'
CLOSURE_SHA = 'ceb91fcc1294b7950fc1f14e01cf7eee8eb069dcc418f68cbca499cf36abf571'

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def exact(path, expected):
    for item in (path, *path.parents):
        info = item.lstat()
        if item.is_symlink() or getattr(info, 'st_file_attributes', 0) & 1024:
            raise RuntimeError('程序路径不能包含链接或重定向')
    before = path.stat()
    if not stat.S_ISREG(before.st_mode) or before.st_nlink != 1:
        raise RuntimeError('程序文件类型无效')
    raw = path.read_bytes()
    after = path.stat()
    if (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) != (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns) or sha(raw) != expected:
        raise RuntimeError('程序文件校验失败')
    return raw

def output(value, path=None):
    raw = json.dumps(value, ensure_ascii=False, indent=2) + '\n'
    if path:
        with Path(path).open('x', encoding='utf-8') as stream:
            stream.write(raw)
    elif sys.stdout is not None:
        print(raw)

def load_host(root):
    project = root / 'project'
    closure = json.loads(exact(project / 'SHIPPED-PINS.json', CLOSURE_SHA))
    names = set()
    for row in closure['files']:
        relative = PurePosixPath(row['path'])
        if relative.is_absolute() or '..' in relative.parts or ':' in str(relative) or ('\\' in str(relative)) or (str(relative) in names):
            raise RuntimeError('程序清单路径无效')
        names.add(str(relative))
        raw = exact(project / relative, row['sha256'])
        if len(raw) != row['bytes']:
            raise RuntimeError('程序文件长度不匹配')
    actual = set()
    for path in project.rglob('*'):
        info = path.lstat()
        if path.is_symlink() or getattr(info, 'st_file_attributes', 0) & 1024:
            raise RuntimeError('程序目录包含未允许的链接或重定向')
        if '__pycache__' in path.relative_to(project).parts or path.suffix.lower() in ('.pyc', '.pyo'):
            raise RuntimeError('程序目录包含未允许的 Python 缓存代码')
        if path.is_file():
            actual.add(path.relative_to(project).as_posix())
    if actual != names | {'SHIPPED-PINS.json'}:
        raise RuntimeError('程序实际文件集合与完整清单不一致')
    code_pins = {row['path']: row for row in closure['files']}
    original_get_code = importlib.machinery.SourceFileLoader.get_code

    def source_only(loader, fullname):
        path = Path(loader.path).absolute()
        if path.is_relative_to(project):
            relative = path.relative_to(project).as_posix()
            row = code_pins.get(relative)
            if row is None or path.suffix.lower() != '.py':
                raise ImportError('未允许的程序代码来源')
            raw = exact(path, row['sha256'])
            return compile(raw, str(path), 'exec', dont_inherit=True, optimize=0)
        return original_get_code(loader, fullname)
    importlib.machinery.SourceFileLoader.get_code = source_only

    def code_audit(event, args):
        if event == 'open' and isinstance(args[0], (str, bytes, os.PathLike)):
            path = Path(os.fsdecode(args[0])).absolute()
            if path.is_relative_to(project) and path.suffix.lower() in ('.pyc', '.pyo'):
                raise PermissionError('程序不接受缓存字节码')
        if event == 'import' and len(args) > 1 and isinstance(args[1], str):
            path = Path(args[1]).absolute()
            if path.is_relative_to(project) and path.suffix.lower() in ('.pyd', '.dll', '.pyc', '.pyo'):
                row = code_pins.get(path.relative_to(project).as_posix())
                if row is None or path.suffix.lower() in ('.pyc', '.pyo'):
                    raise ImportError('未允许的扩展程序来源')
                exact(path, row['sha256'])
    sys.addaudithook(code_audit)
    release = project / 'work/ui-native-r57/releases' / RELEASE_ID
    raw = exact(release / 'RELEASE.json', RELEASE_SHA)
    manifest = json.loads(raw)
    entry = next((row for row in manifest['files'] if row['path'] == 'ui_native_host.py'))
    module = importlib.util.module_from_spec(importlib.util.spec_from_loader('fangyu_standard_native_host', loader=None))
    module.__file__ = str(release / 'ui_native_host.py')
    sys.modules[module.__name__] = module
    exec(compile(exact(release / 'ui_native_host.py', entry['sha256'].lower()), module.__file__, 'exec'), module.__dict__)
    return (module, project, release, closure)

def short_native_icon(release, state):
    """Keep .NET's legacy Icon file constructor below its path length limit."""
    manifest = json.loads(exact(release / 'RELEASE.json', RELEASE_SHA))
    row = next((item for item in manifest['files'] if item['path'] == 'resources/brand.ico'), None)
    if row is None:
        return
    source = release / 'resources/brand.ico'
    raw = exact(source, row['sha256'].lower())
    target = state / 'window.ico'
    if target.exists():
        exact(target, sha(raw))
    else:
        with target.open('xb') as stream:
            stream.write(raw)
        exact(target, sha(raw))
    if len(str(target)) >= 248:
        raise RuntimeError('Windows 用户资料路径过长，请使用标准用户资料目录')
    import webview
    original = webview.start

    def start(*args, **kwargs):
        if kwargs.get('icon') == str(source):
            kwargs['icon'] = str(target)
        return original(*args, **kwargs)
    webview.start = start

def own_directories():
    local = os.environ.get('LOCALAPPDATA')
    if not local or not Path(local).is_absolute():
        raise RuntimeError('Windows 用户资料目录不可用')
    root = Path(local) / 'FangyuWorkbenchStandard'
    for folder in (root, root / 'data', root / 'state'):
        folder.mkdir(parents=True, exist_ok=True)
        for item in (folder, *folder.parents):
            if item.is_symlink() or getattr(item.lstat(), 'st_file_attributes', 0) & 1024:
                raise RuntimeError('工作资料目录不能重定向')
    return (root / 'data', root / 'state')

def main():
    root = Path(sys.executable).resolve().parent if getattr(sys, 'frozen', False) else Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description='方隅工作台')
    group = parser.add_mutually_exclusive_group()
    group.add_argument('--check', action='store_true')
    group.add_argument('--self-test', action='store_true')
    parser.add_argument('--result-file')
    args = parser.parse_args()
    host, project, release, closure = load_host(root)
    data, state = own_directories()
    if args.check or args.self_test:
        argv = ['--check'] if args.check else ['--self-test']
        code = host.main(release, RELEASE_SHA, state, argv, project_root=project, data_dir=data)
        if code:
            raise RuntimeError('启动检查未通过')
        output({'status': 'PASS', 'releaseId': RELEASE_ID, 'frozen': getattr(sys, 'frozen', False) is True, 'internalStandardCandidate': True, 'commercialDistributionApproved': False, 'action': argv[0], 'closureFilesVerified': len(closure['files'])}, args.result_file)
        return 0
    short_native_icon(release, state)
    return host.main(release, RELEASE_SHA, state, [], project_root=project, data_dir=data)

SOURCE_COMPANY_PATH='C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/candidate-unified-v82/project/work/app/company.json'
import traceback
sys.dont_write_bytecode=True
assert not getattr(sys,'frozen',False)
W=Path(__file__).resolve().parent/'payload'
OUT=W/('source-factory-'+uuid.uuid4().hex);OUT.mkdir()
backend=None;checks=[];passed=False
def audit(event,args):
    if event in ('subprocess.Popen','os.system','os.startfile','os.posix_spawn'):raise RuntimeError('No browser/process')
    if event in ('socket.connect','socket.bind') and (not isinstance(args[1],tuple) or args[1][0] not in ('127.0.0.1','::1')):raise RuntimeError('No external network')
    if event=='socket.getaddrinfo' and args[0] not in ('127.0.0.1','localhost','::1',None):raise RuntimeError('No DNS')
    if event=='sqlite3.connect' and not Path(args[0]).resolve().is_relative_to(OUT):raise RuntimeError('Own DB only')
sys.addaudithook(audit)
try:
    host,project,release,closure=load_host(W)
    _,files=host.verify_release(release,RELEASE_SHA)
    # Fixed original SOURCE/pilot company, not the compiled-only held config.
    company=json.loads(Path(SOURCE_COMPANY_PATH).read_bytes())
    assert (release/'resources/customer-read/review-index.json').is_file()
    backend=host.create_backend(release,files,project_root=project,data_dir=OUT/'data',company=company)
    runtime=backend.platform_runtime;server=runtime.server
    server._configure_bundled();runtime._platform_setup=True
    assert getattr(server,'_customer_read_authority',None) is None
    assert 'fangyu_customer_read_distribution' not in sys.modules
    assert server._runtime_license_usage_scope()=='internal_self_use_read'
    from assistant.douyin_connection_service import _components
    from core.douyin_comments_policy import DouyinCommentsPolicy
    assert len(_components(server))==64
    comment=DouyinCommentsPolicy(server).resolve()
    assert comment and comment['purpose']=='douyin_owned_video_comments'
    checks.append({'group':'normal-source-host-ignores-index-and-preserves-original-internal-purpose',
        'sourcePythonActual':True,'frozenSpoofed':False,'originalPilotCompany':True,
        'indexPresent':True,'hostCreatedCarrier':False,'accountComponentsAndCommentResolve':True})
    item=files['resources/platform-runtime/customer_read_distribution.py']
    name='fangyu_customer_read_distribution'
    module=importlib.util.module_from_spec(importlib.util.spec_from_loader(name,loader=None))
    module.__file__=str(release/item['path']);sys.modules[name]=module
    exec(compile(host.read_public(release/item['path'],item['sha256'],item['size']),module.__file__,'exec'),module.__dict__)
    def document(path):
        row=files[path];return host.read_public(release/row['path'],row['sha256'],row['size'])
    index=files['resources/customer-read/review-index.json']
    carrier=module.load_authority(project,release,host.read_public(release/index['path'],index['sha256'],index['size']),document)
    # Explicit trusted QA misattachment, not a host/API branch or an approval.
    server._customer_read_authority=carrier
    try:
        assert server._runtime_license_usage_scope() is None
        try:_components(server)
        except ValueError as error:assert str(error)=='component_review_pending'
        else:raise AssertionError('Source consumed frozen distribution carrier')
    finally:server._customer_read_authority=None
    assert server._runtime_license_usage_scope()=='internal_self_use_read'
    checks.append({'group':'source-misattached-frozen-carrier-rejected-without-internal-fallback'})
    passed=True
finally:
    if sys.exc_info()[0]:(OUT/'ERROR.json').write_text(json.dumps({'traceback':traceback.format_exc()},ensure_ascii=False,indent=2),'utf-8')
    if backend:backend.close()
    (OUT/'RESULTS.json').write_text(json.dumps({'status':'PASS' if passed else 'RED','groups':checks,
        'actualSourceEntry':True,'nativeWindowOpened':False,'platformRequests':0,
        'scopeGrantInjected':False,'allOwnServicesClosed':True},ensure_ascii=False,indent=2),'utf-8')
    print(json.dumps({'status':'PASS' if passed else 'RED','groups':len(checks),'evidence':str(OUT)},ensure_ascii=False))
