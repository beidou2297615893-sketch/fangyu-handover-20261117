"""Inactive until an exact root-authorized aggregate is explicitly bound."""
from pathlib import Path
import hashlib,json
W=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load_verified():
 p=W/'ACTIVATION.json'
 assert p.is_file(),'WAITING_ROOT_AGGREGATE_NO_TESTS_AUTHORIZED'
 b=json.loads(p.read_text('utf-8'));assert b['status']=='ROOT_AUTHORIZED_AGGREGATE'
 assert sha(b['rootReceiptPath'])==b['rootReceiptSha256'],'Root aggregate receipt changed'
 assert sha(b['stagePath'])==b['stageSha256'],'Root aggregate stage changed'
 stage=json.loads(Path(b['stagePath']).read_text('utf-8-sig'));assert stage==b['stage'] and stage['status']=='STAGED'
 S=Path(b['project']).resolve();R=Path(stage['release']).resolve();assert R.is_relative_to(S) and (S/'work/ui-runtime-r55/src').is_dir()
 assert sha(R/'RELEASE.json')==b['manifestSha256']==stage['manifest_sha256'].lower()
 manifest=json.loads((R/'RELEASE.json').read_text('utf-8'));assert len(manifest['files'])==stage['files']
 pins={'manifestSha256':b['manifestSha256'],'releaseFileCount':stage['files'],'candidate':'root-authorized-aggregate-not-formal-F79','rootReceiptSha256':b['rootReceiptSha256'],'stageSha256':b['stageSha256'],'releaseId':stage['release_id']}
 return pins,S.parent,S,stage,R
