"""Actual Native factory/Store/Adapters/CLI/Bridge; VM is browser only."""
from pathlib import Path
from copy import deepcopy
from types import SimpleNamespace
import hashlib,http.client,importlib.util,json,os,shlex,subprocess,sys,threading,time,traceback,uuid
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=W.parents[2];S=Path('C:\\积木软件工坊\\项目\\方隅公寓客户版\\work\\parallel-integration-20261018\\final-integration\\candidate-unified-v82\\project');BR=S/'work/ui-runtime-r55/work/runtime/douyin-bridge'
stage=json.loads(Path('C:\\积木软件工坊\\项目\\方隅公寓客户版\\work\\parallel-integration-20261018\\final-integration\\candidate-unified-v82\\STAGED.json').read_text('utf-8-sig'));R=Path(stage['release'])
OUT=W/('factory-'+uuid.uuid4().hex);OUT.mkdir();processes=[];groups=[];events=[];cases=[]
save=lambda p,v:p.write_text(json.dumps(v,ensure_ascii=False,indent=2,default=str)+'\n','utf-8')
save(OUT/'QA-STAGE.json',{**stage,'qaOnlyLabel':'qa-local-controlled-page-observer-only'})
def audit(event,args):
 if event=='subprocess.Popen':
  argv=args[1];argv=[v.strip('"') for v in shlex.split(argv,posix=False)] if isinstance(argv,str) else argv
  assert Path(argv[0]).resolve()==BR/'node.exe' and Path(argv[1]).resolve() in (BR/'livestream_admission_cli.mjs',W/'vm_bridge_service.cjs'),argv
  assert Path(args[2]).resolve().is_relative_to(OUT);processes.append(list(argv))
 if event in ('os.system','os.startfile','os.posix_spawn'):raise RuntimeError('No platform/browser process')
 if event in ('socket.connect','socket.bind') and (not isinstance(args[1],tuple) or args[1][0] not in ('127.0.0.1','::1')):raise RuntimeError('Own loopback only')
 if event=='socket.getaddrinfo' and args[0] not in ('127.0.0.1','::1','localhost',None):raise RuntimeError('No external DNS')
 if event=='sqlite3.connect' and not Path(args[0]).resolve().is_relative_to(OUT):raise RuntimeError('Own synthetic Store only')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  target=Path(os.fsdecode(args[0])).absolute();mode,flags=args[1] or '',args[2] or 0
  if (any(c in str(mode) for c in 'wax+') or isinstance(flags,int) and flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC)) and not target.is_relative_to(OUT):raise RuntimeError('Own evidence/data only: '+str(target))
sys.addaudithook(audit)
def load(name,path):
 m=importlib.util.module_from_spec(importlib.util.spec_from_loader(name,loader=None));m.__file__=str(path);sys.modules[name]=m;exec(compile(path.read_bytes(),str(path),'exec'),m.__dict__);return m
fixture=load('live_observer_original_cloud_fixture',P/'work/acquisition-core-repair-20261018/gui-fixture/base_fixture.py');cloud=fixture.CloudStandin(json.loads((P/'work/central-store-config/compiled-fixture.json').read_text('utf-8-sig')))
company=json.loads((S/'work/app/company.json').read_text('utf-8-sig'))
PROFILE={'provider':'deepseek','model':'deepseek-flash','rules_version':'synthetic-live-cloud-v1','revision':1,'enabled':True,'configured':True}
ai_wire=[];ai_mode=['normal']
def transport(url,data,token=''):
 op=data.get('operation')
 if op in ('ai_profile','intent_analyze','ai_attempt_status'):
  ai_wire.append(deepcopy(data));save(OUT/'SYNTHETIC-AI-WIRE.json',ai_wire);v=cloud(url,{'operation':'me'},token)
  if op=='ai_profile':v['config']=deepcopy(PROFILE)
  elif op=='intent_analyze':
   if ai_mode[0]=='unknown':raise OSError('Synthetic lost AI reply; no model exists')
   v.update(rules_version=PROFILE['rules_version'],results=[{'id':c['id'],'status':'graded','level':'high','reason':'原文明确寻找两个月住房','evidence':[c['text']],'region_status':'unknown','content_region':'','key_info':[]} for c in data['comments']])
  else:v.update(request_id=data['request_id'],operation_kind='intent_analyze',read_only=True,retry_allowed=False,billing_verified=False,execution_confirmed=None,reservation_retained=True,result_available=False,state='unknown',requires_revalidation=True)
 else:v=cloud(url,data,token)
 v['environment_id']=company['managedWorkspace']['environment_id'];return v
integration=load('integrations',R/'resources/platform-runtime/vendor-src/integrations.py');integration.request_json=transport
host=load('live_observer_actual_host',R/'ui_native_host.py');_,files=host.verify_release(R,stage['manifest_sha256']);host.verify_backend_dependencies(R,files,S)
class Case:
 def __init__(self,name):
  self.path=OUT/name;self.path.mkdir();self.backend=self.server=self.child=None;self.threads=[];self.errors=[];self.stop=threading.Event();self.requests=[];self.evidence_lock=threading.RLock();self.leases=[];self.headers={};cases.append(self)
  self.backend=host.create_backend(R,files,project_root=S,data_dir=self.path/'data',company=company);self.runtime=self.backend.platform_runtime;self.core=self.backend.core
  self.child=subprocess.Popen([str(BR/'node.exe'),str(W/'vm_bridge_service.cjs'),str(BR),str(self.path)],cwd=self.path,stdout=(self.path/'VM.stdout.log').open('w',encoding='utf-8'),stderr=(self.path/'VM.stderr.log').open('w',encoding='utf-8'),creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
  for _ in range(200):
   if (self.path/'VM-READY.json').exists():break
   if self.child.poll() is not None:raise RuntimeError((self.path/'VM.stderr.log').read_text('utf-8'))
   time.sleep(.02)
  else:raise AssertionError('Original Bridge/VM did not become ready')
  self.ready=json.loads((self.path/'VM-READY.json').read_text('utf-8'));self.start_http();self.login()
  self.account={'id':'live-original-account','tenant_id':self.user['tenant_id'],'cloud_owner':self.user['username'],'store_id':self.store,'platform':'douyin','status':'ready','name':'合成当前账号','platform_uid':self.ready['accountUid'],'conn_id':self.ready['parentConnId']};self.core.store.put('accounts',self.account)
  config=self.core.store.directory/'bridge'/self.user['tenant_id']/'config.json';config.parent.mkdir(parents=True,exist_ok=True);config.write_text(json.dumps({'bridge':{'host':'127.0.0.1','port':self.ready['port'],'token':'synthetic-live-only'}}),'utf-8')
  self.install_device();(self.path/'VM-ENFORCE-LEASE').write_text('synthetic test instrumentation','utf-8')
  t=threading.Thread(target=self.monitor,daemon=True);t.start();self.threads.append(t)
  self.source=self.action('livestream_source_select',{'storeId':self.store,'accountId':self.account['id'],'webRid':'123456','liveConnId':self.ready['connId'],'expectedVersion':0,'requestId':'live-original-source-select-001','confirmed':True})['livestreamSelection']['source']
  assert self.source['version']==1 and self.source['liveConnId']!=self.account['conn_id'] and self.core.store.get('accounts',self.account['id'])==self.account
 def start_http(self):
  self.server=host.StaticServer(R,files,backend=self.backend,cookie_name='live_observer_fixture_session');t=threading.Thread(target=self.server.serve_forever,daemon=True);t.start();self.threads.append(t);self.origin='http://127.0.0.1:'+str(self.server.server_port);self.headers={}
 def req(self,method,path,payload=None,expected=200):
  c=http.client.HTTPConnection('127.0.0.1',self.server.server_port,timeout=45);status=None;value=None
  try:
   c.request(method,path,json.dumps(payload,ensure_ascii=False).encode() if payload is not None else None,self.headers);r=c.getresponse();status=r.status;raw=r.read();h=dict(r.getheaders())
   try:value=json.loads(raw)
   except ValueError:value={'nonJson':raw.decode('utf-8','replace')}
  finally:
   c.close();record=deepcopy(payload)
   if record and record.get('action')=='login':record['data']['password']='synthetic omitted'
   with self.evidence_lock:
    self.requests.append({'method':method,'path':path,'input':record,'status':status,'body':value,'processCount':len(processes)});save(self.path/'HTTP.json',self.requests)
  assert status==expected,(method,path,status,expected,value);return value,h
 def action(self,name,data,expected=200):return self.req('POST','/api/workbench',{'action':name,'data':data},expected)[0]
 def login(self):
  boot,_=self.req('GET','/api/workbench/bootstrap');self.headers.update({'Content-Type':'application/json','Origin':self.origin,'X-Fangyu-CSRF':boot['csrfToken']});logged,h=self.req('POST','/api/workbench',{'action':'login','data':{'username':'fixture-admin','password':fixture.PASSWORD}});self.headers['Cookie']=h['Set-Cookie'].split(';',1)[0];self.headers['X-Fangyu-CSRF']=logged['csrfToken'];self.store=cloud.first_store
  if logged['selection']['storeId']!=self.store:self.action('select_store',{'storeId':self.store,'expectedRevision':logged['selection']['revision']})
  self.user={**self.core.session(self.headers['Cookie'].split('=',1)[1]),'_workbench_store_id':self.store}
 def install_device(self):
  runtime,core=self.runtime,self.core;runtime.server._configure_bundled();runtime._platform_setup=True;core.remote_safety_hold=False;core.employee_release_device_id='live-vm-synthetic-device';core.employee_release_until_monotonic=time.monotonic()+600
  from assistant.business import BusinessExecutor
  from assistant.xhs_app_context import bind_executor_session
  executor=BusinessExecutor(runtime.server,company['managedWorkspace']['environment_id'],company['id'],self.user['username']);runtime.service.executor=executor
  saved={'state':'bound','environment_id':company['managedWorkspace']['environment_id'],'company_id':company['id'],'token':'synthetic-device-token','device':{'id':'live-vm-synthetic-device','owner':self.user['username']}}
  runtime.service.vault=SimpleNamespace(read=lambda:deepcopy(saved));runtime.service.device=deepcopy(saved['device']);runtime.service.state='online'
  class DeviceCloud:
   def call(self,operation,data,credential):return {'claimed':True}
   def close(self):pass
  runtime.service._cloud=lambda:DeviceCloud();executor.account_claim=runtime.service._claim_xhs_account;bind_executor_session(runtime.service,executor,saved)
  class SyntheticOwnedBrowserHandle:
   def poll(self):return None
   def terminate(self):pass
   def wait(self,*a,**kw):return 0
  runtime.server.account_connections.owned[self.account['id']]={'process':SyntheticOwnedBrowserHandle(),'marker':'synthetic-own-handle-not-real-browser'}
  runtime._douyin_observations[runtime._douyin_scope(self.user,self.account)]={'window':runtime._douyin_window(self.account),'binding':runtime._douyin_binding(self.account),'result':{'status':'ready','windowOpen':True}}
 def monitor(self):
  previous=0
  while not self.stop.wait(.003):
   try:
    p=self.path/'VM-WIRE-START.json'
    if not p.exists():continue
    value=json.loads(p.read_text('utf-8'));n=value['sequence']
    if n==previous:continue
    lease=self.core.account_mode_status(self.account['id'],self.user['tenant_id']);assert lease['mode']=='collection' and lease['status']=='active',lease
    foreign=type(self.core.continuous.leases)(self.core.store,'different-runtime-vm')
    try:foreign.acquire(self.account['id'],self.user['tenant_id'],'replies','foreign-reply')
    except ValueError:pass
    else:raise AssertionError('Original lease did not block a foreign reply')
    self.leases.append({'sequence':n,'originalLease':lease,'foreignReplyBlocked':True});save(self.path/'LEASES-AT-SOURCE.json',self.leases);save(self.path/'VM-LEASE-ACK.json',value);previous=n
   except json.JSONDecodeError:continue
   except BaseException:self.errors.append(traceback.format_exc());save(self.path/'MONITOR-ERRORS.json',self.errors);return
 def mode(self,value):save(self.path/'VM-CONTROL.json',{'mode':value})
 def capture(self,key,expected=200,**extra):return self.action('livestream_capture',{'storeId':self.store,'accountId':self.account['id'],'sourceId':self.source['id'],'expectedVersion':self.source['version'],'requestId':key,'timeoutMs':100,'confirmed':True,**extra},expected)
 def query(self,key,expected=200):return self.action('livestream_request_read',{'storeId':self.store,'requestId':key},expected)
 def analyze(self):
  from assistant.ai_worker import AIWorker
  worker=AIWorker(self.runtime.service.executor);worker.step();return worker
 def rows(self):return {e:deepcopy(self.core.store.list(e,self.user['tenant_id'])) for e in ('leads','livestream_capture_requests_v1','livestream_message_observations_v1','livestream_message_conflicts_v1')}
 def stats(self):return json.loads((self.path/'VM-STATS.json').read_text('utf-8'))
 def reopen(self):
  self.server.shutdown();self.server.server_close();self.backend.close();self.backend=host.create_backend(R,files,project_root=S,data_dir=self.path/'data',company=company);self.runtime=self.backend.platform_runtime;self.core=self.backend.core;self.start_http();self.login()
 def close(self):
  self.stop.set()
  if self.server:self.server.shutdown();self.server.server_close()
  if self.backend:self.backend.close()
  if self.child:
   self.mode('stop')
   try:self.child.wait(5)
   except subprocess.TimeoutExpired:self.child.terminate();self.child.wait(5)
  for t in self.threads:t.join(3)
  assert not self.errors,self.errors
  stats=self.stats();assert stats['platformSocketSend']==0 and stats['platformSocketClose']==0 and stats['platformSocketConstructedByFixture']==1 and all(not t.is_alive() for t in self.threads),stats
  save(self.path/'CLOSED.json',{'allThreadsClosed':True,'childExitCode':self.child.returncode,'sourceLeasesChecked':len(self.leases),'stats':stats})
passed=False
try:
 c=Case('normal');before=len(c.leases)
 c.capture('live-no-confirm-original',400,confirmed=False);c.capture('live-upload-proof-original',400,proof={})
 c.core.acquire_account_mode(c.account['id'],c.user['tenant_id'],'replies','old-reply');c.capture('live-reply-mode-before-read',409);c.core.release_account_mode(c.account['id'],c.user['tenant_id'],'old-reply');assert len(c.leases)==before
 windows=c.action('livestream_sources_read',{'storeId':c.store,'accountId':c.account['id'],'refreshWindows':True})['livestreamSources'];assert windows['windows'][0]['accountCheck']=='not_checked' and c.core.store.get('accounts',c.account['id'])==c.account
 n=c.stats()['routeReads'];c.capture('live-stale-source-cas-key',409,expectedVersion=0);assert c.stats()['routeReads']==n
 first=c.capture('live-original-native-key-0001')['livestream'];assert first['state']=='received' and first['counts']['imported']==1,first
 frozen=c.rows();count=c.stats()['routeReads'];assert c.capture('live-original-native-key-0001')['livestream']['replayed'] and c.stats()['routeReads']==count and c.rows()==frozen
 lead=frozen['leads'][0];assert lead.get('task_id'), 'LIVE_ANALYSIS_QUEUE_MISSING: saved live lead has no original task';assert lead['live_source']['observerKind']=='page-websocket' and 'targetId' not in lead['live_source'] and lead['live_source']['original']['roomId']=='456' and lead['live_source']['original']['webRid']=='123456' and 'comment_id' not in lead
 assert lead['live_source']['parentConnId']==c.account['conn_id'] and lead['live_source']['liveConnId']==c.ready['connId'] and c.core.store.get('accounts',c.account['id'])==c.account
 people,_=c.req('GET','/api/workbench/customers?platform=douyin');assert len(people['customers']['items'])==1
 customer=people['customers']['items'][0]['id'];reply=c.action('reply_read',{'storeId':c.store,'customerId':customer,'platform':'douyin'})['replyWorkspace'];assert reply['comments'][0]['canSave'] is False and '直播聊天不是视频评论' in reply['comments'][0]['reason']
 c.mode('conflict');result=c.capture('live-original-conflict-key-002')['livestream'];assert result['counts']['conflicts']==1 and c.core.store.get('leads',lead['id'])==lead
 assert c.core.store.get('tasks',lead['task_id'])['scope']=='livestream_chat'
 job=c.core.store.get('ai_jobs',lead['task_id']);assert job['status']=='pending' and job['pending']==1
 c.analyze();analyzed=c.core.store.get('leads',lead['id']);assert analyzed.get('ai_intent',{}).get('level')=='high',(analyzed,c.core.store.get('ai_jobs',lead['task_id']))
 view=c.query('live-original-native-key-0001')['livestream'];assert view['analysis']['analyzed']==1 and view['counts']['pendingAnalysis']==0,view
 n=len([v for v in ai_wire if v['operation']=='intent_analyze']);assert n==1
 c.analyze();assert len([v for v in ai_wire if v['operation']=='intent_analyze'])==n
 people,_=c.req('GET','/api/workbench/customers?platform=douyin');assert people['customers']['items'][0]['sourceLabel']=='直播聊天原文' and people['customers']['items'][0]['sourceLinkLabel']=='打开直播间' and people['customers']['items'][0]['commentReplyAllowed'] is False
 groups.append({'group':'G1_actual_factory_bridge_vm_original_key_customer_conflict_reply_mode','result':'PASS','sourceReads':c.stats()['routeReads']});c.close()
 for name,mode in [('wrong-mapping','wrong-map'),('bounded-inflate','bomb'),('post-identity','late-account')]:
  c=Case(name);c.mode(mode);key='live-'+name+'-original-unknown';c.capture(key,409);assert not c.rows()['leads'] and c.query(key)['livestream']['state']=='unknown'
  n=c.stats()['routeReads'];assert c.capture(key)['livestream']['state']=='unknown' and c.stats()['routeReads']==n;c.capture(key+'-new',409);assert c.stats()['routeReads']==n
  frozen=c.rows();c.reopen();assert c.query(key)['livestream']['state']=='unknown' and c.rows()==frozen and c.stats()['routeReads']==n
  groups.append({'group':'G_'+name,'result':'PASS','originalUnknownRetained':True,'newKeyReads':0,'reopenQueryReads':0,'leadDelta':0});c.close()
 c=Case('missing-source-time');c.mode('missing-time');result=c.capture('live-missing-source-time-key-001')['livestream'];assert result['state']=='received' and result['counts']['imported']==1
 lead=c.rows()['leads'][0];assert lead['published_at']=='' and lead['live_source']['original']['sourceTimeStatus']=='unknown'
 groups.append({'group':'G5_missing_platform_source_time_stays_unknown','result':'PASS','hostObservedTimeNotUsedAsSourceTime':True});c.close()
 c=Case('original-ai-unknown');c.capture('live-ai-unknown-original-key-001');ai_mode[0]='unknown';before=len([v for v in ai_wire if v['operation']=='intent_analyze']);worker=c.analyze();attempts=deepcopy(c.core.store.list('ai_attempts',c.user['tenant_id']));assert len(attempts)==1 and attempts[0]['state']=='unknown',attempts
 original=attempts[0]['request_id'];worker.retry_after=0;worker.step();assert len([v for v in ai_wire if v['operation']=='intent_analyze'])==before+1 and c.core.store.list('ai_attempts',c.user['tenant_id'])[0]['request_id']==original
 view=c.query('live-ai-unknown-original-key-001')['livestream'];assert view['counts']['pendingAnalysis']==1 and view['taskId'] and view['analysis']['code'],view
 groups.append({'group':'G6_original_AIWorker_LocalAIWorkflow_unknown_same_key_no_redispatch','result':'PASS','intentDispatches':1,'originalAIRequestKey':original,'originalCaptureKey':'live-ai-unknown-original-key-001'});c.close();ai_mode[0]='normal'
 passed=True
finally:
 error=traceback.format_exc() if sys.exc_info()[0] else None
 for c in cases:
  if c.child and c.child.poll() is None:
   try:c.close()
   except BaseException:error=(error or '')+traceback.format_exc()
 save(OUT/'RESULTS.json',{'status':'PASS' if passed and not error else 'RED','groups':groups,'groupCount':len(groups),'httpRequests':sum(len(c.requests) for c in cases),'processes':processes,'error':error,'originalVerifiedFactory':True,'actualOriginalBridgeRouterRegistryClient':True,'browserLayer':'VM + synthetic natural HTTP responses/platform sockets','realBrowserPlatformModelCalls':0,'sourceFilesNotWritten':True,'realSingleOrTenRoomCapacityVerified':False,'stage':stage})
 print(json.dumps({'status':'PASS' if passed and not error else 'RED','groups':len(groups),'httpRequests':sum(len(c.requests) for c in cases),'evidence':str(OUT)}))
