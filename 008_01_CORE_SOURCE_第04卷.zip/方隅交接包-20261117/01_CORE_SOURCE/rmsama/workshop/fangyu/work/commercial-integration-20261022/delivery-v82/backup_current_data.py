"""Consistent current local backup, no restoration or credential parsing."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, sqlite3

D=Path(__file__).resolve().parent
P=D.parents[2]
binding_path=P/'work/ui-native-r57/state/production-workspace.json'
binding=json.loads(binding_path.read_text('utf-8-sig'))
source=Path(binding['data_dir'])/'workspace.sqlite3'
assert source.is_file()
directory=D/'current-business-backup'
assert directory.resolve().is_relative_to(P.resolve()) and not directory.exists()
directory.mkdir()
target=directory/'workspace.sqlite3'
connection=sqlite3.connect(source.as_uri()+'?mode=ro',uri=True,timeout=5)
destination=sqlite3.connect(target)
try:
    connection.execute('PRAGMA query_only=ON')
    connection.backup(destination,pages=256,sleep=0.01)
    assert destination.execute('PRAGMA quick_check').fetchone()[0]=='ok'
finally:
    destination.close()
    connection.close()
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
receipt={'status':'CONSISTENT_CURRENT_SQLITE_BACKUP_VERIFIED_NOT_RESTORED',
    'createdUtc':datetime.now(timezone.utc).isoformat(),'backupPath':str(target),
    'backupSha256':sha(target),'bytes':target.stat().st_size,
    'bindingSha256':sha(binding_path),'sourceOpenedReadOnly':True,
    'sourceModified':False,'automaticRestore':False,
    'scope':'Complete local SQLite backup may include saved account records; contents not parsed or exported',
    'accountProfileDirectories':'Untouched at existing bound data directory'}
(D/'CURRENT-BUSINESS-BACKUP.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps({k:receipt[k] for k in ('status','bytes','sourceModified','automaticRestore')}))
