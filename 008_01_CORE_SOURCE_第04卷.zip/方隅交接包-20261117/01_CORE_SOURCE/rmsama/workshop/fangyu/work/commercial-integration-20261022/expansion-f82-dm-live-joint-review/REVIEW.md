# F82 私信与直播合版运行复核

结论：固定 F82 的原 Native 工厂、Core/Store、Adapters、实际 Popen Node CLI 和原 Bridge 运行复核通过。私信与直播都使用同一份已冻结合版输入完成各自最难链路，没有发现合并引入的阻断。此结论适用于隔离数据和原入口的运行接点；编译程序、本人浏览器和真实平台验收另计。

| 运行链路 | 实际结果 | HTTP | 原 Node 进程 |
| --- | --- | ---: | ---: |
| 私信代表链 | 14 组通过 | 118 | 7（1 个测试 Bridge、6 个原 CLI） |
| 直播原工厂链 | 6 组通过 | 60 | 20（6 个测试 VM Bridge、14 个原 CLI） |
| 直播规则与账号删除 | 2 组通过 | 15 | 6（2 个测试 VM Bridge、4 个原 CLI；由 HTTP processCount 记录核对） |

所有原 CLI 均为固定 F82 Node 可执行文件和固定 typed CLI，确实经过原 Registry/Router/Client。浏览器、平台自然响应、IM、签名及模型只由自有 VM/合成响应代替；没有外网平台或模型请求。

## 最难接点的实际结果

- 私信：原工厂读取、草稿、显式复核和原 Store 可用。原 held 发送配置下，已复核草稿仍被阻断且零 send CLI。正例仅在沿用旧审查的自有数据、内存配置中显式设定测试许可，然后运行原设备会话、原账号 mode、原预算/发送链；没有修改 F82 的许可、合同或公司配置文件。
- 已成功发送的同一稳定客户 UID，另一账号再发被阻断；两账号重叠发往同一 UID 时只一侧取得原子 claim、只产生一个 typed send。旧的 sent 评论记录也继续跨渠道阻止私信，原评论和回复记录未改。
- 首次 unknown 保留原 key、草稿和第二项 pending；相同 key 读取或再开始不重派，不同 key 被拒；关闭并以原 create_backend 重开同一自有 Store 后，原 unknown 仍可核对，新增 CLI 和 transport 均为零。
- 直播：显式确认、来源版本、原账号 mode、原连接与房间校验、解码预算、客户写入、冲突保留、源时间未知都通过原链路。相同采集 key 重读零新来源读取；错误映射、解压超限、后置账号身份变化均保留 unknown，重开或更换 key 不能盲目重派。
- 直播客户进入原任务/AI 队列，由原 AIWorker 和 LocalAIWorkflow 处理。AI 结果未知时原 request key 保留，后续 step 不重复 intent 派发。
- 门店规则快照改动后，原队列返回 AI_CONTEXT_REQUIRED，零新分析派发，原客户和任务保留。直播类型任务不能通过普通任务保存或 run_task 转成搜索采集。
- 删除采集账号后，已采客户、原直播任务和规则快照保留；任务的分析不依赖仍存在的采集账号。原 AIWorker 完成一次合成响应分析，之后客户可见，平台来源读取增量为零。
- 活跃账号 `_components(runtime.server)` 实际通过，revision 为 `f82d6f4b22dcb157beb7a62594e0a05bbe80466653a6e0089c2904d6f88c059c`。
- 同一原 factory 的 `DouyinCommentsPolicy.resolve()` 实际返回 `douyin_owned_video_comments`，revision 为 `b2c93e4518685ebfa335178d36d9773e6b507bc791a810892c00732d8d66157a`。此时原 publicSendHold=true，只读材料闭包能 resolve，没有发起平台请求，也没有扩展主评论页用途。

## 输入与原断言保全

- 进入前及全部运行结束后，两次独立核对 F82 全部 3856 个冻结文件，hash/bytes 全部匹配，538 项 release 与指定 STAGED、UNIFIED、RELEASE manifest SHA 匹配；发生变化的源或资源为零。
- DM 只选择旧独审的原组件、UID、held、成功回执、并发、防重、unknown、重开代表链，未再重复全部旧 25 组。所选原断言 AST 全部保留，另加一条原评论用途 resolver 断言。直播 6 组使用完整原断言，规则/删账号使用作者原有前两组断言。
- 适配仅在本目录切换固定 F82 输入路径、选择原测试组和添加上述只读用途探针，原产品源未修改。详细路径、原测试 SHA、选取行段、原断言数量和差异保存在 HARNESS-ADAPTATION.json 与各 `.diff`。
- 原工厂的两个实际服务均从同一固定 F82 合版创建；浏览器 VM 使用同一 F82 合并 Router。此处没有声称真人同时开多直播间的容量、同账号真人跨渠道并发或发送送达已验证。

## 尚未验证

普通 clean held 安装包的实际编译入口由总控另一独审验收；这次是原源码 Native factory 和实际冻结资源运行。没有打开 Native 本人页面，没有真实 XHS 私信、平台历史、真人 IM 签名/送达、真人直播首用或真实模型质量测试。原许可、held 和 caller 契约仍须按真实使用场景满足。

## 清理

DM、live、live-policy 的 exec session 均 exit 0。所有原后端、HTTP、Node CLI、测试 Bridge/VM 和线程已关闭；各 Case 的 CLOSED 及 DM FINAL 记录保留。另核本目录关联的 Python/Node 进程为零，9 个已记录 Bridge 端口全部拒绝连接。没有遗留平台动作、真实数据连接或本人依赖。

关键证据：F82-INPUTS-VERIFIED.json、F82-INPUTS-AFTER.json、HARNESS-ADAPTATION.json、三个 factory 目录的 RESULTS/HTTP/CLOSED、DM ACTIVE-PURPOSES.json、CLEANUP.json。最终清单见 FINAL.json、EVIDENCE-PINS.json、SEALED.json。
