from pathlib import Path
import ast,hashlib,json
D=Path(__file__).resolve().parent;W=D.parent;Q=D/'frozen-native'
sha=lambda b:hashlib.sha256(b).hexdigest()
assert not Q.exists();Q.mkdir()
root=json.loads((D/'FINAL-PINS.json').read_text('utf-8'))
assert sha((D/'FINAL-PINS.json').read_bytes())=='ee76c8c7de89bad321f871ee7f9f287a2f70eaf64b4c544a2a8b30006fc37b9c'
checks={
 'source-independent.json':(W/'v77-final-source-independent-review/FINAL-RECEIPT.json','381d1e380e7caa187f5e379a23465c5048ece938ad5682e08b4120e11785626e'),
 'source-SEAL.json':(W/'v77-final-source-independent-review/SEALED.json','95187320e51fd5d88841394c82e0a090ae72ce677d4c8ead6de2fbd1707e4bec'),
 'joint-independent.json':(W/'v77-joint-factory-validation/FINAL-RECEIPT.json','79ae7730785622746fa6db1cf652b1a4cdb5757ba9e9a11a1d99c148a749ee90'),
 'joint-SUMMARY.json':(W/'v77-joint-factory-validation/SUMMARY.json','082b336dd56f7ac65567e7cc0218c9dfec84413a9dc832abb227931fc31e9eba'),
 'joint-SEAL.json':(W/'v77-joint-factory-validation/SEAL.json','db4e0b1defb5ac2b8cd07f6b4b06ec88b3bd1819e56aceb8d45332f7502851b8'),
 'standard-independent.json':(W/'v77-standard-package-independent-review/FINAL-RECEIPT.json','24be40ae1364734aa2e7babefc20729fcccd533f14edc994cca76fd5f8041de2'),
 'standard-SEAL.json':(W/'v77-standard-package-independent-review/SEALED.json','19f88da66929ea519520c2dcd9ad59c802583a1c9cfedc13651b75c444b81f12'),
 'guided-functional-independent.json':(W/'guided-method-entry-independent-review/FINAL-RECEIPT.json','a33bcfa669c76606f5643f15036fef652d88dc37e27321a5e9032b44bd1b59d0'),
 'guided-library-independent.json':(W/'guided-library-contract-independent-review/FINAL-RECEIPT.json','4fb6c302bbda90bbe8918bde816052e821707b0d4ed686cddc9a727549f36382'),
 'status-font-independent.json':(W/'acquisition-status-text-size-independent-review/FINAL-RECEIPT.json','6aa6f0ec40293ffa29c24cada30cfa912fab4127a6dd246a3ed2384f0f100141'),
 'mode-original-source-independent.json':(W/'platform-preflight-mode-lease-independent-review/FINAL-RECEIPT.json','aec11172c01f9701dc310d7fde71169195ce9b1c2d85a8bf9b8f2628007583d5'),
 'snapshot-baseline-independent.json':(W/'platform-snapshot-held-analysis-independent-review/FINAL-RECEIPT.json','cd5a344ae8ea9d889f675e071779e1da46e53cff30718cb20ceec6d469d0832c'),
}
evidence={}
for name,(source,pin) in checks.items():
 raw=source.read_bytes();assert sha(raw)==pin,str(source)
 (Q/name).write_bytes(raw);evidence['frozen-native/'+name]=pin
source=json.loads((Q/'source-independent.json').read_text('utf-8'))
joint=json.loads((Q/'joint-SUMMARY.json').read_text('utf-8'))
assert source['finalPins']==root and joint['rootPins']==root
assert source['factory']['groups']==7 and source['factory']['legacyMethodPrepares']==17
assert source['ui']['functionalChecks']==16 and source['ui']['fontChecks']==11
assert joint['counts']['originalBusinessGroupsTotal']==47 and joint['counts']['localModeFactoryGroups']==6 and joint['counts']['guidedVersionFactoryGroups']==3
assert source['realExternalModelPlatformCalls']==joint['realModelPlatformExternalCalls']==0
ui=json.loads((D/'ui-mode-validation/RESULTS.json').read_text('utf-8'))
assert ui['status']=='PASS' and ui['groups']==4 and ui['realPlatformOrModelCalls']==0
raw=(D/'ui-mode-validation/RESULTS.json').read_bytes();(Q/'mode-ui-root.json').write_bytes(raw);evidence['frozen-native/mode-ui-root.json']=sha(raw)
baseline=json.loads((D/'PROTECTED-BUSINESS-BEFORE-INSTALL.json').read_text('utf-8'))
assert baseline['readOnly'] and baseline['accountRecords']==3 and not baseline['productionModified']
summary={
 'status':'TECHNICAL_ACCEPTANCE_ACCOUNT_READ_MODE_GUARD_GUIDED_AND_FONTS_NOT_FULL_COMMERCIAL',
 'rootFinalPins':root,'totalHttpGroups':47,'countedOriginalBusinessGroups':joint['counts'],
 'separateNewGuidedFactoryGroups':7,'separateLegacyMethodHttpPrepares':17,
 'separateGuidedFunctionalUiChecks':16,'separateGuidedFontUiChecks':11,'separateRootModeUiGroups':4,
 'httpRequestsAreNotCountedAsGroups':True,'oldBaselineReceiptsAreReferencesNotNewRuns':True,
 'testExecutionUsesOwnFixturesOnly':True,'testExecutionProductionAccess':False,
 'productionReadOnlyBaseline':{'accountRecords':baseline['accountRecords'],'comments':baseline['protectedTablesAndEntities']['records:leads']['rows']},
 'realModelCalls':0,'realPlatformRequests':0,'realMessagesOrPostsSent':0,
 'nativeFirstStartVerified':False,'ordinaryPackageDefaultNativeOrSecondPhysicalPcVerified':False,
 'localNextLaunchUpdateApproved':True,'limitedInternalPackageTechnicalAcceptance':True,
 'commercialDistributionApproved':False,'completeThreeInOneGoalAchieved':False,
 'continuedEngineeringRequired':True,
 'limits':['Natural cloud grants and real platform/model execution not tested by these fixtures.',
  'Content generation release switches and publishing holds remain unchanged.',
  'Private messaging/live operations/full scheduled publishing and remaining media capabilities still have engineering gaps.',
  'Do not restore old business snapshots over current records; update program entry only.'],
}
raw=(json.dumps(summary,ensure_ascii=False,indent=2)+'\n').encode();(Q/'SUMMARY.json').write_bytes(raw);evidence['frozen-native/SUMMARY.json']=sha(raw)
spec={'release_id':root['releaseId'],'unified_sha':root['unifiedPinsSha256'],'files':root['unifiedFileCount'],
 'release_sha':root['manifestSha256'],'candidate_launcher_sha':root['launcherSha256'],'recovery_checkpoint':True,
 'evidence':evidence,'delivery':'delivery-v77','http_groups':47,'staged_sha':root['stagedSha256']}
entry=D/'install_verified_entry.py';before=entry.read_bytes();assert sha(before)=='8fc4e44b27064f9f8c9a04017731de9dbc69894b09af00aeccf0a9e0fe0ebdf4'
text=before.decode('utf-8');tree=ast.parse(text)
node=next(n for n in tree.body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='ACCEPTED')
reviewed=next(n for n in tree.body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='INSTALLATION_REVIEWED')
assert ast.literal_eval(node.value)=={} and ast.literal_eval(reviewed.value) is False
lines=text.splitlines(keepends=True);lines[node.lineno-1:node.end_lineno]=['ACCEPTED = '+repr({'candidate-unified-v77':spec})+'\n'];text=''.join(lines);after=ast.parse(text)
functions=lambda t:{n.name:ast.dump(n,include_attributes=False) for n in t.body if isinstance(n,ast.FunctionDef)}
assert functions(tree)==functions(after)
(D/'ENTRY-EMPTY-DRAFT.py').write_bytes(before);entry.write_text(text,encoding='utf-8')
out={'status':'FILLED_FIXED77_ALLOWLIST_INSTALLATION_STILL_DISABLED','entrySha256':sha(entry.read_bytes()),
 'summarySha256':evidence['frozen-native/SUMMARY.json'],'evidence':evidence,'functionsUnchanged':True,
 'installationReviewed':False,'canonicalWritten':False,'commercialGoalComplete':False}
(D/'ENTRY-FILLED.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in out.items() if k!='evidence'}))
