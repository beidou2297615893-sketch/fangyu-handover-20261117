from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
D=Path(__file__).resolve().parent;W=D.parent;H=D/'frozen-native'
read=lambda p:json.loads(p.read_text('utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pins=read(D/'FINAL-PINS.json')
counts={}
for name,count in [('RESULTS-candidate-unified-v72.json',14),('FROZEN-NATIVE-HTTP-RESULTS-candidate-unified-v72.json',11),('GATEWAY-HTTP-RESULTS.json',7)]:
    r=read(H/name);assert r['status'].startswith('PASS')
    found=len(r['checks']) if isinstance(r['checks'],list) else r['checks'];assert found==count
    counts[name]=found
I=W/'v72-final-independent-validation';ind=read(I/'FINAL-VALIDATION.json')
assert ind['status']=='PASS_V72_FINAL_FROZEN_INDEPENDENT_VALIDATION'
assert ind['knowledgeActualFactoryHTTP']==4 and ind['publicationActualFactoryHTTP']==5 and ind['originalCoreLeaseRebuild']==6 and ind['actualNativeCacheRegression']==6
for key in ('unifiedPinsSha256','stagedSha256','manifestSha256','releaseId','unifiedFileCount','releaseFileCount'):
    assert ind['finalPins'][key]==pins[key]
M=W/'v72-media-outcomes-frozen';media=read(M/'SUMMARY.json')
assert media['status']=='PASS_ACTUAL_UNIFIED_V72_MEDIA8_OUTCOMES6'
S=W/'v72-schedule-frozen-validation';sched=read(S/'VALIDATION.json')
assert sched['status']=='PASS_ACTUAL_V72_SCHEDULE_15_AND_CONNECTION_3' and sched['nativeHTTPChecksNewlyRun']==15 and sched['connectionPreconditionChecksNewlyRun']==3
assert sched['chromiumChecksNewlyRun']==0 and sched['chromiumChecksReferencedFromIdenticalV71Modules']==5
copies={'CLOSURE-RESULTS.json':I/'CLOSURE-RESULTS.json','INDEPENDENT-FINAL-VALIDATION.json':I/'FINAL-VALIDATION.json',
    'MEDIA-OUTCOMES-SUMMARY.json':M/'SUMMARY.json','SOURCE-SCHEDULER-FINAL.json':S/'VALIDATION.json',
    'SOURCE-SCHEDULER-PRECONDITION.json':S/'ENABLE-PRECONDITION-RESULTS.json','SOURCE-SCHEDULER-UI-REFERENCE.json':S/'UI-REFERENCE.json',
    'NATIVE-CACHE-RESULTS.json':I/'NATIVE-CACHE-RESULTS.json','UNCHANGED-WEB-DOM-REFERENCE.json':I/'DOM-REFERENCE.json'}
for name,origin in copies.items():
    target=H/name;assert not target.exists() or target.read_bytes()==origin.read_bytes();target.write_bytes(origin.read_bytes())
closure=read(H/'CLOSURE-RESULTS.json');assert closure['status']=='PASS' and closure['unifiedFiles']==3152 and closure['releaseFiles']==196
evidence={name:sha(H/name) for name in (*counts,*copies)}
report={'status':'PASS_UNIFIED_V72_70_HTTP_AND_PINNED_SOURCE_GUARD','timestampUtc':datetime.now(timezone.utc).isoformat(),
    'candidate':pins['candidate'],'release':pins['releaseId'],'unifiedPinsSha':pins['unifiedPinsSha256'],'stagedSha':pins['stagedSha256'],'releaseManifestSha':pins['manifestSha256'],'unifiedFiles':3152,'releaseFiles':196,
    'totalHttpGroups':70,'httpGroups':{'originalContent':14,'originalSource':11,'gateway':7,'media':8,'customerOutcomes':6,'knowledge':4,'publication':5,'sourceScheduler':15},
    'additionalNewlyRun':{'publicationRestart':6,'nativeSourceCacheRegression':6,'scheduleConnectionPreconditions':3},
    'unchangedFrontendEvidence':'All web bytes match v71; original knowledge DOM4, app readiness DOM9 and Chromium schedule5 are inherited, not newly rerun for v72.',
    'evidenceSha256':evidence,'realModelCalls':0,'realPlatformRequests':0,'productionAccess':False,'actualV72NativeCUA':False,'canonicalInstalled':False,
    'limits':['Network/platform/provider responses in tests are synthetic; no real acquisition, messages, models or posts were dispatched.','Publication protocol and cloud new-feature activation remain closed.','Actual canonical install/Native startup and post-start protected customer data comparison are separate steps.','The independently built ordinary-PC standard package is derived and has separate pins, QA and approval status.','Media native Windows save dialog remains unverified.','Source import integrity is not an OS sandbox.']}
dest=H/'SUMMARY.json';assert not dest.exists();dest.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps({'status':report['status'],'summarySha256':sha(dest),'totalHttpGroups':70,'evidenceCount':len(evidence)}))
