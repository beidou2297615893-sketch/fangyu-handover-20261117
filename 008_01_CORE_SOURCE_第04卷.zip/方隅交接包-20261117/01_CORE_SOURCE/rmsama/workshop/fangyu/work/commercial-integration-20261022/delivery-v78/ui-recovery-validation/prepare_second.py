from pathlib import Path
import shutil
W=Path(__file__).resolve().parent;dest=W/'missing-applied-preset-fixture';assert not dest.exists();dest.mkdir()
for name in ('INITIAL-PROJECTION.json','UI-NATIVE-RESULTS.json','UI-SERVER-CLOSED.json','serve_ui.py'):
    p=W/name
    if p.exists():shutil.copy2(p,dest/name)
stop=W/'STOP-UI-SERVER'
if stop.exists():stop.unlink()
