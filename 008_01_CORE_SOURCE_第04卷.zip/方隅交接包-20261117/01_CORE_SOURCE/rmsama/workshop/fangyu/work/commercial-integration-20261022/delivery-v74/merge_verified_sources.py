from pathlib import Path
import hashlib,json,os
W=Path(__file__).resolve().parents[1];D=Path(__file__).resolve().parent
S=W.parent/'parallel-integration-20261018/final-integration/stage-02/project'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
checks={
 W/'scoped-prompt-version-qa-resolution/FINAL-RECEIPT.json':'489f91cc28b3ddf07987f02715425c7e0b3da742451669060cac3e9364d61163',
 W/'scoped-prompt-version-qa-resolution/source-revision-3/MERGE-SOURCE-PINS.json':'51072e624eba266332638953b860072b55538c045694a4874e4287e1d629489c',
 W/'pdf-text-import-factory-validation/FINAL-RECEIPT.json':'aefe9c6b234fbe34808a00edbae9ce6b982d318c01978591b235ef573ef9e769',
 W/'pdf-text-import-factory-validation/MERGE-MANIFEST.json':'4b5624a7653327e1ed2565c7a88d0edb25c4b422acd53b9cf7f9e89fdb020dea',
}
for p,h in checks.items():assert sha(p.read_bytes())==h,str(p)
assert not (D/'MERGE.json').exists(),'Merge already recorded'
rows={}
def add(rel,before,after,source,origin):
    raw=source.read_bytes();assert sha(raw)==after,(rel,'candidate pin')
    assert rel not in rows,(rel,'unresolved path conflict')
    rows[rel]={'path':rel,'beforeSha256':before,'afterSha256':after,'source':str(source),'origin':origin,'raw':raw}
scope=W/'scoped-prompt-version-qa-resolution/source-revision-3'
for r in json.loads((scope/'MERGE-SOURCE-PINS.json').read_text('utf-8'))['files']:
    add(r['path'],r['beforeSha256'],r['afterSha256'],scope/'project'/r['path'],'scoped-six')
pdf=W/'pdf-text-import-factory-validation'
for r in json.loads((pdf/'MERGE-MANIFEST.json').read_text('utf-8'))['files']:
    add(r['path'],r['baseSha256'],r['sha256'],pdf/'merge-source'/r['path'],'pdf-66')
notice=W/'analysis-version-visibility-candidate/revision-3'
for r in json.loads((notice/'PATCH-MANIFEST.json').read_text('utf-8'))['files']:
    rel=r['path'];raw=(notice/'candidate'/rel).read_bytes();assert sha(raw)==r['after']
    if rel in rows:
        assert rel=='work/ui-native-r57/customer_workbench.py'
        # Keep the full notice source, with ONLY the two dependency pin updates.
        for old,new in [('C41399CD7369C3A8B1791552A161C7CBC2AB52369945A0762F3D38484BAF6871','B1D3BB0EF5D6D2DA8BEB5D385B42D237F6FB9054A9F9792AC03A8E57BBC0A0DA'),('4D79BBB3B1D3D270DBDB9DDBE42F1DFE41C49366479DA691A1F672D20D5EECB9','AE113729F4FB940DCB28E68678C6C4338C992652E04BC2F5AE902B90A638F9D2')]:
            assert raw.count(old.encode())==1;raw=raw.replace(old.encode(),new.encode())
        assert rows[rel]['beforeSha256']==r['before']
        rows[rel].update(raw=raw,afterSha256=sha(raw),origin='notice-python-plus-only-two-scoped-pins',source=str(notice/'candidate'/rel))
    else:add(rel,r['before'],r['after'],notice/'candidate'/rel,'notice-revision3')
assert len(rows)==74,len(rows)
# CAS all inputs before the first source write, preserving every prior byte.
for rel,r in rows.items():
    target=S/rel
    assert not target.is_symlink()
    if r['beforeSha256'] is None:assert not target.exists(),(rel,'new path occupied')
    else:assert sha(target.read_bytes())==r['beforeSha256'],(rel,'source changed')
for rel,r in rows.items():
    if r['beforeSha256'] is not None:
        backup=D/'source-before'/rel;backup.parent.mkdir(parents=True,exist_ok=True);assert not backup.exists();backup.write_bytes((S/rel).read_bytes())
changed=[]
try:
    for rel,r in rows.items():
        target=S/rel;target.parent.mkdir(parents=True,exist_ok=True)
        temp=target.with_name(target.name+'.v74-merge-tmp');assert not temp.exists()
        temp.write_bytes(r['raw']);os.replace(temp,target);changed.append(rel)
    for rel,r in rows.items():assert sha((S/rel).read_bytes())==r['afterSha256']
except BaseException:
    for rel in reversed(changed):
        target=S/rel
        if rows[rel]['beforeSha256'] is None:target.unlink()
        else:target.write_bytes((D/'source-before'/rel).read_bytes())
    raise
out={'status':'SOURCE_MERGED_NOT_INSTALLED','files':[{k:v for k,v in r.items() if k!='raw'} for r in rows.values()],
     'fileCount':len(rows),'sourceOnly':True,'canonicalModified':False,'productionModified':False,
     'independentFinalSourceAndPackageAcceptanceStillRequired':True}
(D/'MERGE.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in out.items() if k!='files'}))
