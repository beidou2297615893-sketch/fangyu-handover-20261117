from pathlib import Path
from datetime import datetime, timezone, timedelta
import hashlib
import json

W = Path('C:/积木软件工坊/项目/方隅公寓客户版/work/commercial-integration-20261022')
D = W / 'delivery-v82'
U = W / 'ui-copy-density-after-f82-candidate'
F = Path('C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/candidate-unified-v82/project')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(U / 'FINAL-RECEIPT.json') == '5a69f56c8a89d1d146d437ce47ab2f1b0615a91e9162a75357eb7c58e9e1f185'
assert sha(U / 'SEALED.json') == 'c4ed7fc5958f934fd565c55eea910fa49856d1c17c01ea13a66dc383b5237614'
receipt = json.loads((U / 'FINAL-RECEIPT.json').read_text('utf-8'))
checks = []
for row in receipt['sourceFiles']:
    original = F / row['path']
    candidate = U / 'source-candidate' / row['path']
    assert sha(original) == row['beforeSha256']
    assert sha(candidate) == row['afterSha256']
    if candidate.name == 'public-research.mjs':
        old = original.read_text('utf-8').split('export function bindPublicResearch', 1)[1]
        new = candidate.read_text('utf-8').split('export function bindPublicResearch', 1)[1]
        assert old == new
        assert 'target="_blank" rel="noopener noreferrer"' in candidate.read_text('utf-8')
    checks.append({'path': row['path'], 'exactBeforeAndAfterPins': True})
now = datetime.now(timezone.utc)
review = {'utc': now.isoformat(), 'checks': checks,
          'actualPublic390ScreenshotViewed': True,
          'review': 'Accept source-only changes for next substantive combined release; no backend or binder change.',
          'fullIndexOrInstalledNativeValidated': False,
          'installedOrFrozenChanged': False}
(D / 'UI-FOLLOWUP-ROOT-REVIEW.json').write_text(json.dumps(review, ensure_ascii=False, indent=2)+'\n', 'utf-8')
target = W / 'HANDOFF-THREE-IN-ONE-LATEST.md'
old = target.read_text('utf-8')
local = now.astimezone(timezone(timedelta(hours=8))).strftime('%H:%M')
addition = f'''
## {local} 续接状态，以本条取代上文ASR agent正在封存的描述

最新list_agents真实返回3个子agent均running：knowledge_review_4正在三步多角色编排候选；schedule_finish_4正在明确用户选择的微信公众号正文候选；experience_independent_review已完成ASR核对，现转只读 customer-distribution-readiness-after-f82。

G10已确认原任务artifactIds允许校验过的candidate产物作为链内依赖，不要求人工apply；后继可一次明确“开始协作”有界最多3个原task_run，unknown/失败/取消立即停，最终人工审核采用/发送合同不变。该功能尚在候选，不称已安装。G12原MIT组件只支持微信js_content，候选诚实限定https://mp.weixin.qq.com/s，无伪微信UA/会话/图片或脚本；通用正文和热点联想仍未全部完成。

ASR核对唯一 FINAL0aa49987821d9c7371273a448ccfe5ad2ca4a20962d39e7731f2e00ea5220a8a、SEALED0b2d9d71d2a5e6d74cfc1bd937914a23ecfd7629a821353134bbf5c385788c4f，4类原组件逐一查明，无合格引擎且禁止本轮下载/新付费，完整ASR仍缺；字幕preview通过不能冒充转写。

新experience任务重点查普通受限包无法连接的真正分发缺口，先读原_runtime_license_usage_scope/RuntimeLicensePolicy、各purpose材料和原作者许可，绝不注入internal/QA、翻approved或去掉hold。先提出合法最小分发审查接点，再决定后继工程；禁止生产和真实平台操作。root没有为此改任一原权限。

root已实际看两处UI候选窄图，并核最终seal/前后源SHA与原public binder尾部逐字同，适合下次实质业务合版；delivery-v82/UI-FOLLOWUP-ROOT-REVIEW.json。未再freeze/安装/重跑整套测试。当前用户窗口、数据及正式F82保持。
'''
target.write_text(old + addition, 'utf-8')
print(json.dumps({'handoffSha256': sha(target), 'uiReviewSha256': sha(D / 'UI-FOLLOWUP-ROOT-REVIEW.json'),
                  'productionOrInstalledSourceChanged': False}, ensure_ascii=False))
