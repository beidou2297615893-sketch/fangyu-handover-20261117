"""Verify the installed next-launch entry without restarting the current app."""
from pathlib import Path
from datetime import datetime,timezone
import ctypes
from ctypes import wintypes
import hashlib,http.client,json,subprocess,sys
D=Path(__file__).resolve().parent;P=D.parents[2]
N=P/'work/ui-native-r57';C=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v73'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(N/'run_workbench.py')=='64f6129e337016f1eb87a7200563fd9cf390b4615d54118b95f9e9d66d48d102'
k=ctypes.WinDLL('kernel32',use_last_error=True)
k.OpenProcess.argtypes=(wintypes.DWORD,wintypes.BOOL,wintypes.DWORD);k.OpenProcess.restype=wintypes.HANDLE
k.GetProcessTimes.argtypes=(wintypes.HANDLE,ctypes.POINTER(wintypes.FILETIME),ctypes.POINTER(wintypes.FILETIME),ctypes.POINTER(wintypes.FILETIME),ctypes.POINTER(wintypes.FILETIME));k.GetProcessTimes.restype=wintypes.BOOL
k.GetExitCodeProcess.argtypes=(wintypes.HANDLE,ctypes.POINTER(wintypes.DWORD));k.GetExitCodeProcess.restype=wintypes.BOOL
k.CloseHandle.argtypes=(wintypes.HANDLE,);k.CloseHandle.restype=wintypes.BOOL
def processes():
    out={}
    for pid in (19036,66168):
        handle=k.OpenProcess(0x1000,False,pid)
        if not handle:raise ctypes.WinError(ctypes.get_last_error())
        try:
            creation,exit,kernel,user=(wintypes.FILETIME() for _ in range(4));code=wintypes.DWORD()
            if not k.GetProcessTimes(handle,ctypes.byref(creation),ctypes.byref(exit),ctypes.byref(kernel),ctypes.byref(user)):raise ctypes.WinError(ctypes.get_last_error())
            if not k.GetExitCodeProcess(handle,ctypes.byref(code)):raise ctypes.WinError(ctypes.get_last_error())
            assert code.value==259
            out[str(pid)]={'creationFiletime':(creation.dwHighDateTime<<32)|creation.dwLowDateTime,'stillActive':True}
        finally:k.CloseHandle(handle)
    return out
before=processes();checks={}
for flag,name in (('--check','CHECK'),('--self-test','SELF-TEST')):
    result=subprocess.run([sys.executable,'-E','-X','utf8',str(N/'run_workbench.py'),flag],capture_output=True,timeout=60,creationflags=subprocess.CREATE_NO_WINDOW)
    assert result.returncode==0,result.stderr.decode('utf-8',errors='replace')
    answer=json.loads(result.stdout.decode('utf-8'))
    assert answer['status']=='PASS' and answer['business_app_imported'] is False and answer['native_windows_opened']==0
    if flag=='--check':assert answer['release_id']=='ui-r57-20261022T221409Z-61609cff' and answer['files']==198
    else:assert answer['checks']==130 and answer['public_urls']==118
    dest=D/('ACTUAL-NEXT-LAUNCH-'+name+'.json');assert not dest.exists();dest.write_text(json.dumps(answer,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    checks[flag]={'exitCode':0,'evidenceSha256':sha(dest),'businessAppImported':False,'nativeWindowsOpened':0}
after=processes();assert after==before
http=http.client.HTTPConnection('127.0.0.1',57610,timeout=10)
http.request('GET','/');response=http.getresponse();body=response.read();assert response.status==200 and b'workspace-frame' in body;http.close()
manifest=json.loads((C/'UNIFIED-PINS.json').read_text('utf-8'));expected={row['path'] for row in manifest['files']}
actual={p.relative_to(C/'project').as_posix() for p in (C/'project').rglob('*') if p.is_file()}
assert actual==expected and len(actual)==3156
for row in manifest['files']:assert sha(C/'project'/row['path'])==row['sha256']
result={'status':'PASS_ACTUAL_CANONICAL_V73_NEXT_LAUNCH_WITH_RUNNING_V72_PRESERVED',
        'capturedAtUtc':datetime.now(timezone.utc).isoformat(),
        'nextLaunchRelease':'ui-r57-20261022T221409Z-61609cff',
        'actualStillRunningRelease':'ui-r57-20261022T210347Z-c8457008',
        'runningProcessCreationTimesUnchanged':before,'oldRunningHttpStill200':True,
        'canonicalLauncherSha256':sha(N/'run_workbench.py'),'canonicalFrozenSha256':sha(N/'FROZEN.json'),
        'checks':checks,'frozenSourceExact3156AndAllHashesPreserved':True,
        'newNativeWindowOpened':False,'runningApplicationRestarted':False,
        'platformOrEmployeeLoginPerformed':False,'realSendsOrPaidModelCalls':0}
dest=D/'ACTUAL-NEXT-LAUNCH-VERIFICATION.json';assert not dest.exists();dest.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result))
