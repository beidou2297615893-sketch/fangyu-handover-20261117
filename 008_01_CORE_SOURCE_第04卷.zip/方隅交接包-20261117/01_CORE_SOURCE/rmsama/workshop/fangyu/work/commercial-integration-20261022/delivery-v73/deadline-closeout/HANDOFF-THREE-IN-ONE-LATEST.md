# 方隅三合一总控：当前交接

更新：2026-10-22T23:03:08.808937+00:00。完整用户目标尚未完成，不标 complete。截止北京时间2026-10-23 08:00（UTC00:00），届时删除 automation-10 并准确交接。已获全部并行授权；仍 live 的任务不重复启动，只有真实终态/句柄缺失才续接。

## 目标、边界、入口

把方隅原工作台、自动发帖、灵絮移植的全部业务合入一个产品，沿用本人批准的三张新增功能样图与浅色蓝绿公寓画风。保留原客户、账号、断点和13店边界。完整范围 THREE-IN-ONE-SCOPE.md，不以映射数或按钮数代替全量完成。

P=C:/积木软件工坊/项目/方隅公寓客户版。
F=P/work/parallel-integration-20261018/final-integration。
S=F/stage-02/project（仅root可写）。N=P/work/ui-native-r57（实际入口与运行状态）。
W=P/work/commercial-integration-20261022。Python=P/work/desktop-python/Scripts/python.exe。
旧Documents/ChatGPT/自动获客系统不是当前源码，不改它或其他客户/核心实例。

禁止真实评论/私信/发布、验证码绕过、新付费调用/密钥/权限、GPU模型下载。本人依赖保断点继续其他项。当前无CUA/usage_limits工具，不绕桌面限制；headless仅开发测试。最新真实额度未知，03:36 BJT剩85%只是历史。模型条件分支早已成功切本聊天gpt-6.1-sol；MODEL-SWITCH-RECEIPT.json，绝不重切/自发消息/用重置券。get_goal旧blocked与用户继续授权不一致，现有工具不能恢复active，不错误标complete。

## 实际运行与下一启动必须分开

**当前仍真实运行v72**：外层PID19036、Native子PID66168，创建FILETIME分别134371771451836177/134371771452336024，端口57610/57611。原真实Native登录页、字体/6图/铺满曾实测。当前窗口不关闭、不重启，不新开production profile。business_connected只表示本地后台已构造，不表示员工或平台已登录。

**N下一启动已安装v73**，原双文件CAS/备份/异常回退机制不变；额外核完整v72与v65回退闭包，24份固定验收证据。源preparer静态独审 v73-entry-independent-review/FINAL-RECEIPT.json SHA bda4e6b584a6da24a17aed936e7022ad5497c24a9eff1bf4056797df3bb9bcfa。root使用普通Python -E -X utf8，未-O。

- N/run_workbench.py SHA64f6129e337016f1eb87a7200563fd9cf390b4615d54118b95f9e9d66d48d102。
- N/FROZEN.json SHA8d2f1967a1c7cb9230c5db73c3940e36db113d77308743060fa29b1825cb414a。
- 实际N --check198资源、--self-test130项/118URL通过，无业务构造/新Native；原两个PID创建时间相同、旧HTTP200。F73全3156文件集合及摘要仍精确。delivery-v73/ACTUAL-NEXT-LAUNCH-VERIFICATION.json。
- 原件在delivery-v73/next-launch-prepared/candidate-unified-v73/canonical-entry-before。不是断电原子双文件事务，不声称最新73已实际打开Native。用户关闭重开后加载新增。

## 数据保全

最新delivery-v73/PROTECTED-BUSINESS-BEFORE-INSTALL.json和AFTER-INSTALL.json：1888评论/1129客户/40任务，原leads/replies/tasks/ai_cache/rental_assessments、unique_leads/contact_events与备份逐行完全相同，binding14cf53964f5d44d123e989805ea741669ab3f05054e730ddcb299a0aac51a9cb不变。无生产恢复/迁移/覆盖AI。全部任务/评论古北，其他12店未套古北新规则。94条无AI字段已另只读审计，见下方口径，不能把需复核与未分析混说。

业务一致备份：recovery-before-next-release/20261022T174553Z，scoped-business.sqlite3 SHA d91954340064dbd12b5862589d33db42b39cb3cac73a9142169ae6ec291a09ce；ZIP2918ddbca0ba6586610e3ea517351358489233c0f420e06e176b162abbe58bec，2655779B。只业务，不含凭据/会话/私有配置，不冒充全环境恢复包。

## v73固定源与实际验收

delivery-v73/FINAL-PINS.json：candidate-unified-v73；release ui-r57-20261022T221409Z-61609cff；3156源/198资源。
UNIFIED c0a72be807965903a5cbb9dfee9ba6549a6157ccf622fd7df86a9ef1397a167b。
STAGED460d884a1e5c520a51961cfacb025d1737da3998b3e94abadd098356b1806dd4。
RELEASE84b52d6434d0a1685f13cdd8cc78f3540bfc0a8af7b83bf8530a4cf744fbf1aa。
candidate launcher4b7e77b0a4f227a14c1ca649c9fe9c6fa1bed698bd62ed927e215d4d9529023f。

在v72已有人工纠错/刷新、互动待办、词效、41份/17方法、CPU剪辑、人工结果、文档导入、获客定期检查等基础上，新增：
1. 共享门店SOP/口吻/资料：只读预览、默认不勾选、原来源版本/摘要重验，全部hypothesis，不把旧价格/样例升事实，unknown只查原key。
2. 明确自愿联系方式：原可见评论+原author_key，逐条本人确认/拒绝/撤销；无第二客户库、不自动留资/加意向/发送；撤回旧确认失效，metadata历史不泄露旧号码，可当前权限/CAS撤销。

两候选均另agent独审，原contact8误识别红已在revision修；只接受717b570a3952855d6d0d10a97f33157d5eec2108b00d473838832bf2ebaf3265，不合旧d571红。root三方合保shared，唯一webbackend长行冲突以完整逆证明两个read token插入。两MERGE及before在delivery-v73。

- 联合实F73 SEAL79c41349da5568927f1947c78b465d6656a70d9237b96d4eb07811197fe04c33，FINAL96e9a808231105a8989c2f3191a7d281d310c455a920f57501168df7adeed034。47HTTP=shared13+旧内容2+contact9+结果4+知识4+调度15，另连接3/cache6，shared Chromium5/contact DOM10/宽窄Chromium4，14正58负；3156/198/13vendor/newCLI全闭包。真实平台/模型0。
- root验收摘要delivery-v73/frozen-native/SUMMARY.json SHA cb40e2fb9ed4e2b3f65f13c8f9cc6c936913e353b735649274dc9456306f3ca7，23证据+SUMMARY。
- **唯一有效源独审** v73-final-independent-review/SOURCE-FINAL-RECEIPT.json SHA54360fa8cfd5f8257a6fc574a972c004f540fd597ce2be546f8fe58ced1f5165。含新鲜整树门、3134保护文件、cache3、原工厂调度5、UI5，四安全函数逐字v72。
- 390首红是夹具漏原fit iframe/CSS；只修自有夹具，真实outer390/inner459/scale.85无横溢、主文可视14.45px，1255亦过。fixture-red保留，产品73未改，不称CUA或本人图审。
- root直跑F73候选check/self-test曾在其state产生两未列lifecycle诊断（22:18，PID23596/30508已exit）。已逐字转存delivery-v73/candidate-entry-runtime-diagnostics，所有3156 pinned文件/manifest未改，fresh全树恢复。CANDIDATE-DIAGNOSTICS-RECOVERY.json。旧source回执a0aefb...3998已INVALID，禁止引用。今后只跑N实际入口检查，N/state在F外；不能再直接跑F候选launcher制造诊断。

## 普通电脑包：新安装器已完成独审并交付

原review-5/standard-held-clean-v73仍封定不改：3799包文件/3154shipped/1609inner；app EXE3bc35d9c1e0033880567cf5c00769bbefed2017be0fd3b5bd4964449325be4d1。ZIP5147dfdf36818760f0d311d73930f69c48744b22ff59c304a26635ea052579cb（269904095B），原setupa0fbb507保留作证据。原包独审dbbcd6855e76d2641c8bcf89e2a820a1e57ed7abf61031defd71fe3d3a609b22，原final d4d9120608b97183aafd3c572a91b66f30f0071fb098f6b80fdf3d96bc0b45f6。

最终交付改用**新派生installer外壳**：修正精简包WebView2初始说明；每个同名shortcut仅当既有TargetPath精确匹配当前实例才允许更新，异目标/未知/叶子重解析保留，mutex只协调新helper。无全局杀进程、无用户目录实际安装。原15函数AST和非shortcut extract/非单label main精确不变，目录swap、数据、runtime、备份和替换失败恢复不改。它不是启动健康失败或断电自动恢复。

- 新source SHA5f9b4d7ab00b6348d07d15a241ad804cf593ec137d576e5a3ce67476df01dca9。
- 新SFX SHA38d3fcc329f44a38045cc1e9865d2a5312464c58fa918a3555e5a7c110ad4eb8，281270881B；shell7b0b354c273ca7bebb94659b7a89194b3aecb7a65f97120abb767c50b7d02301，裸shell不可分发。嵌同一5147原ZIP，3799成员精确相同。
- 安装原compiled升级9组、临时WSH8组、新实际SFX --verify-payload/--self-test-install均绿；3799解包逐文件匹配，冲突保原LNK+安装程序+原失败说明，同target重试成功。第一条WSH UTF8 -File编码夹具红已保留，按原UTF16 EncodedCommand重跑绿。无真实用户Desktop/菜单/registry/Native动作。
- 作者final final-installer-upgrade-audit/FINAL-RECEIPT.json SHA1a353acaa7c179e228a6b50b5c0de905a168d8c9bb161d641449735ced5aeca2；独审installer-successor-independent-review/FINAL-RECEIPT.json SHA3842ce722300543b9896e4e40e4f47c6bd3a6ea03f3e909f6e1a9b12157344ca。root又独核CodeType和同ZIP，ROOT-INSTALLER-DELIVERY-APPROVAL.json SHA98524e9c9277d64445acf3fffed7779f72eefcc6cc99c5cc6a2d48f9fd318638。
- **已复制** outputs/三合一交付/普通电脑内测版/方隅工作台_受限内测安装包.exe，新SHA38d3…4eb8；旧v72 SHA344f…ae2e7及旧说明可逆归档outputs/三合一交付/历史内测版/上次保留。delivery-v73/CLEAN-OUTPUT-DELIVERY.json SHAea5dc2ad3333ae234134432f0086b2ebc06e64c05803b192d8119fa46a2f6334。
- held/发送hold/非商发保持，无QA/SAMPLE/固定身份、原客户/会话/凭据。无需用户Python/GPU/本地模型，但须既有WebView2/.NET，媒体工具不捆绑。新73标准包没有新Native首窗，第二实体机/真实员工及平台未验，前版兼容证据不能替代。

## 最终门店、AI口径与人用文档

final-store-intent-audit/SEAL.json SHA6c94974d323e7d874a2ff77f548377c1055e457947f4432ba6830c98a92f3fbd；FINAL-RECEIPT1985d97f799de99b5fdc9261e1ac297cb62e74b301fd10a21aac507128ada6b9。古北1—12月纯分组/任务规则/请求缓存与payload链已核，13店四输入同既有来源，其他12店不附古北。现价、库存、设施和真实新在线模型质量未核。

1888全有Codex侧车复核；1794历史DeepSeek=1425不相关+201信息不足+168已分级(144高/23中/1低)。57证据待核在201内；94无AI并非复核漏比，其中17无正文，9精确关联同一unknown原attempt，不能重建重发。其余历史原因不足以证明。133仅原作者纯分组下同快照AI候选高作者，不是实时授权UI/已核客户数。全部1794历史行无新scoped_prompt_version，未重评不冒称已全更新。

原默认帖子30天、可7/90，历史任务条件保留；当前历史40任务32七天/8三十天。1888行缺可解析原帖日期，因此不能据历史行承诺平台帖子时限已真实完整执行。

root另只读核持久任务城市：34个上海任务关联全部1888条评论；6个旧空城市任务均0评论。因此现有1888条不受task_analysis_rules缺城市边界影响。没有为旧空任务擅自补城市或附规则，也未恢复/新分析。

原全量范围对账final-full-scope-reconciliation：18行/五维矩阵，完整范围JSON61bcb4fa28b785acef594a142913472df072cad815edadb2aa7b8f407e3bfac1；43映射、378目录均非全部可执行。人用报告当前交付核对.md已重写明确next73/当前72、生成关闭vs旧意向AI保留、真实工程缺口；今日需求旧1878误数改1888，并标为阶段历史。普通电脑说明随新SFX同步，不把旧首启冒充73。原文均留delivery-v73/human-documents-before-final。

07:00 BJT最终只读健康核对：FINAL-DELIVERY-HEALTH.json SHA1b5f858f3737c9f12c847ce96a6438d12576974040e51a6a7bfd059edef8bc46，19036/66168原创建时间同、HTTP200、下一入口pin同，全部7类保护行与pre/post/backup完全一致。PROTECTED-BUSINESS-AFTER-OUTPUT-COPY.json SHAd4cb718de42796241e9aabb365087ee74e96e8ff935d2152b8dfc147769d2c71。未新Native/重启/付费/发送/生产写。

## 当前live与最后一小时（不重复派工）

- installer_finish_4安装审计与派生外壳、knowledge_review_4门店审计与installer独审均已封存停写；不能重复构建/安装。
- schedule_finish_4最终outputs独审已封存停写：final-full-scope-reconciliation/DOC-DELIVERY-FINAL-REVIEW.json SHA5548d517d43aad43a0742890c8d61ccb8f42840bcb2bca218f12d6f95374d6b1；三个人用文档、新旧EXE和实际复制回执一致，原14条问题已实质落实，0阻断，未改outputs。
- **scoped-prompt-version-candidate已封存停写**：SEALED.json SHAd51c6e8996c6f4133c1f682463ea26a379cfbfdb415697958f955b476950bcc2；CHANGES.patch cc2e15167d8fc49800216dc460aa220b9235786c8eddc5dee4791d27a19b1a3d，4旧文件11hunks，byte replay4/4，原公开Core/Store runtime/vendor各13绿。只读/旧调用/自动pending不新增重评，显式本地版本确认才例外；9合成unknown原批只查原key，拆批/换序不新派发。**尚未合并，不改S/F73/N/outputs，未新冻结/HTTP/UI，不能算客户已可用**。
- F73**新结果原本会保存**GUBEI_ANALYSIS_VERSION/local scoped_prompt_version；问题限旧重评两处比较。候选改core.intent_policy状态helper、ai_workflow显式确认+replace_existing、原business runtime/vendor维护合同，不另开Native客户入口或放宽标准版维护权限。公开helper不等于本人已看到UI，也不等于云已实证执行；无task归档保持不套古北。
- 07:25续接三项live，勿重复：installer_finish_4独占scoped-prompt-version-independent-review做上述4文件独审；schedule_finish_4独占scoped-prompt-version-factory-validation尝试复用真实原工厂/HTTP测试，若固定manifest不准候选则报缺口，不伪造PASS；knowledge_review_4独占pdf-text-import-candidate优先查已有和pypdf官方BSD纯Python路线，准备普通文字PDF的原导入预览/确认/保存候选，非OCR/扫描/ASR，不改全局环境或73。全部07:45前收束、模型/真实平台0；只候选，不许把未整冻结/未客户UI/未标准包验证写成已实现。
- factory作者07:28实证：自有副本原F73 verify_release/read_public/依赖/create_backend通过；只换4候选而沿用原manifest时read_public准确拒绝，未构造候选Core/HTTP。BASELINE-FACTORY.json与CANDIDATE-FACTORY.json保留。root已允许仅在其自有目录用原freeze_ui --stage生成明确新label/manifest的qa-local-prompt-contract-only候选，不能假装F73或交付74，不改权限/4文件以外产品源码；若07:43前能验代表性factory/HTTP就做，07:45收束。
- root只在本项目收尾；08:00 BJT删automation-10并准确交接，不标未完成goal complete。若新候选不能完整核验，不匆忙替换已验交付。实际用量工具缺失仍不猜剩余额度，模型切换分支已结束。

## 真正尚缺与已关闭事项

私信收发/监听/批量队列、直播/主动互动、真实作品发布协议及相应中央服务、内容矩阵到期执行、真实热点/联想/完整查询归因、多轮角色执行、PDF/OCR/录音/ASR/TTS/生成式媒体仍有工程缺口。文档目前DOCX/PPTX/TXT/MD；CPU视频已有素材+提供字幕，不冒充生成。内容生产生成开关固定关闭，线上云代码已部署/回读但没有新付费生成质量验证。不是这些全部只等扫码。

实际云final2/tree744ec24509d6602618543d6c760130de1d7b45a0acc05be89aa09592a03c5a02（5616文件），CONTENT_RELEASE_ENABLED/LEGACY_AI_EXTENSIONS_ENABLED=false；真实发布4云文件未部署。新CLI EXE1db77116ebedc24a379f1ad868b0d03ac313554ba0aac898242af4dd672f8084/tree3b4e6af322a03d5bb0195dc505758acc898ec05dcb0db06a44b600026098bd17已完整核，但新实平台未验。不要用源安装、模拟接口或旧界面证据冒充这些。

完整先前历史已逐字归档 handoff-history/HANDOFF-BEFORE-V73-NEXT-LAUNCH.md（不是删除）；更早源包/失败/backup不动。
