from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
D=Path(__file__).resolve().parent;W=D.parent;P=D.parents[2]
F=P/'work/parallel-integration-20261018/final-integration';S=F/'stage-02/project'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
INDEPENDENT_SHA='4fe84e1974b04c3068a3f181c88cf0b72d24f38cb9bcf8aa0313e3205126edbe'
BACKEND_FINAL_SHA='2537a8e04f217b1a6e037ffac7fefd5e8b8ea9f76a2b6b762eabfa9e70364b21'
BACKEND_SEAL_SHA='8fe9d6cd04586e6a0ad72fdced7764b852bc0330c755d7b53f3fbfdb5a7a96eb'
assert INDEPENDENT_SHA and BACKEND_FINAL_SHA and BACKEND_SEAL_SHA,'Await final source review and sealed backend; do not merge moving drafts'
accepted=[
 ('acquisition-account-recovery-candidate','283f695d8890bcc77d4b25c8ca95081ab3eafe57db44bbb113d6f1ce3d288953','0d843179131a9cbd7f77865262223895e9d89bea21429a6475e85c0c55e5f1d5','source-candidate'),
 ('account-entry-ux-candidate','3b51cab8fb8aa8a120390a5a5536e398a2334d78ff5beb3c590e5fd099ebdee1','7a51a6cd92cb89f8826a53507e995a29817b668af783132c458a48143f429dbb','overlay'),
 ('account-management-backend-candidate',BACKEND_FINAL_SHA,BACKEND_SEAL_SHA,'overlay')]
review=W/'account-recovery-independent-review/SOURCE-FINAL-RECEIPT.json';assert sha(review)==INDEPENDENT_SHA
original=F/'candidate-unified-v77/INPUT-SNAPSHOT.json';snapshot=json.loads(original.read_text('utf-8'))['files']
for relative,expected in snapshot.items():assert sha(S/relative)==expected,('Baseline source changed',relative)
planned={}
for name,receipt_pin,seal_pin,folder in accepted:
    C=W/name;assert sha(C/'FINAL-RECEIPT.json')==receipt_pin and sha(C/'SEALED.json')==seal_pin
    manifest=json.loads((C/'SOURCE-FILES.json').read_text('utf-8'))
    entries=manifest if isinstance(manifest,list) else manifest['files']
    for row in entries:
        relative=row['path'];path=Path(relative)
        assert not path.is_absolute() and '..' not in path.parts and ':' not in relative
        expected=row.get('afterSha256') or row.get('sha256');raw=(C/folder/relative).read_bytes();assert hashlib.sha256(raw).hexdigest()==expected
        before=row.get('beforeSha256');target=S/relative
        assert target.is_file() and sha(target)==before,('Base mismatch',relative)
        assert relative not in planned,('Overlapping sources require explicit hunk merge',relative)
        planned[relative]={'raw':raw,'before':before,'after':expected,'author':name}
assert len(planned)==12,('Expected reviewed 3+3+6 sources',len(planned))
backup=D/'source-before';assert not backup.exists()
for relative,item in planned.items():
    target=S/relative;save=backup/relative;save.parent.mkdir(parents=True,exist_ok=True);save.write_bytes(target.read_bytes())
    target.write_bytes(item['raw']);assert sha(target)==item['after']
receipt={'capturedAt':datetime.now(timezone.utc).isoformat(),'status':'MERGED_SOURCE_ONLY_NOT_INSTALLED','independentReviewSha256':INDEPENDENT_SHA,'files':[{k:v for k,v in item.items() if k!='raw'}|{'path':relative} for relative,item in planned.items()],'originalManifestRowsVerified':len(snapshot),'productionAccess':False,'currentRunningRelease':'F77 immutable candidate remains unchanged','newOtherModulesIncluded':False}
(D/'MERGE-SOURCE.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),'utf-8');print(json.dumps({'status':receipt['status'],'files':len(planned),'receiptSha256':sha(D/'MERGE-SOURCE.json')}))
