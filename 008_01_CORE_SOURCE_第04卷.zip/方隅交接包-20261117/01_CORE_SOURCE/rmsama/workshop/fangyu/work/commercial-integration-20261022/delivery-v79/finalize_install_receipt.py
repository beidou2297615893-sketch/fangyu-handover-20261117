from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
D=Path(__file__).resolve().parent;P=D.parents[2];N=P/'work/ui-native-r57';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pins=json.loads((D/'FINAL-PINS.json').read_text('utf-8'));diag=json.loads((D/'ACTUAL-ENTRY-DIAGNOSTICS.json').read_text('utf-8'));business=json.loads((D/'PROTECTED-BUSINESS-AFTER-INSTALL.json').read_text('utf-8'))
assert business['sameAsBeforeInstall'] and all(c['exitCode']==0 for c in diag['checks'])
assert sha(N/'run_workbench.py')==diag['launcherSha256']=='c02988a90de374b150ca240dc55b656d6ac9c1c27566a009c06b9b9f5d7d85a4'
assert sha(N/'FROZEN.json')==diag['frozenSha256']=='8161593e7059809069c44578fb789c61cc12bd88e3515d7304a0914f5c48b534'
assert sha(N/'state/production-workspace.json')==diag['bindingSha256']=='14cf53964f5d44d123e989805ea741669ab3f05054e730ddcb299a0aac51a9cb'
evidence={name:sha(D/name) for name in ['FINAL-PINS.json','ROOT-ENTRY-APPROVAL.json','ACTUAL-ENTRY-DIAGNOSTICS.json','PROTECTED-BUSINESS-BEFORE-INSTALL.json','PROTECTED-BUSINESS-AFTER-INSTALL.json','frozen-native/SUMMARY.json']}
out={'status':'NEXT_LAUNCH_INSTALLED_AND_DIAGNOSED_DATA_UNCHANGED','recordedAtUtc':datetime.now(timezone.utc).isoformat(),'releaseId':pins['releaseId'],'canonicalLauncherSha256':diag['launcherSha256'],'canonicalFrozenSha256':diag['frozenSha256'],'bindingSha256':diag['bindingSha256'],'evidence':evidence,'accountRecords':business['accountRecords'],'commentRecords':business['protectedTablesAndEntities']['records:leads']['rows'],'originalAuthorsUnchanged':1129,'taskRecords':business['protectedTablesAndEntities']['records:tasks']['rows'],'allSevenProtectedBusinessDigestsAndAccountMetadataUnchanged':True,'oldBackupRestoredOverCurrentData':False,'platformCredentialsOrSessionsRead':False,'realPlatformOrModelRequests':0,'realAccountDeletions':0,'forcedWindowRestart':False,'actualHumanNativeFirstStartVerified':False,'publicCompiledPackageUpdatedThisRound':False,'fullGoalComplete':False,'commercialAcceptance':False}
(D/'INSTALLATION-FINAL.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),'utf-8')
section='''

## 2026-10-23 13:50 BJT 急修79实际下一启动安装，等待本人重开实采

用户当前最高优先级：账号旁能直接打开所选小红书网页，本人登录/删除账号；客户与任务按门店共享、账号仅执行身份；恢复新选账号获客。用户质疑不可视化，已连续给明确实情与实际QA截图，未把后台测试说成真实采集。

F78完整页面实际发现旧keywordPage wrapper先stopImmediatePropagation后因旧canStart=false返回，吞掉新账号fresh事件；F78保留三次红证据，不安装。missing applied preset为此前夹具错误另存，未改产品。F79仅在wrapper严格freshCapture成功时透传给原acquire.bind，保unknown、running、scope、勾选和刷新后二次签名核验。canonical S已合前12源和此第13源；F79实际由F78闭包+精确1行原freeze_unified生成。源码3308/资源274，相对F78只1源+镜像+3生成物，其他3303规范化文件字节原样。未混入DM/G11/媒体/query候选。

F79 pins：root3719840ea39dfe4874fe800f48fe9b58a92987649bd524a39b8074816b6efd64；unified fa71e0e3cda87f55708ef00fcdfef348fb1ddeb91911d44950f599080644ad83；staged a1b2fa3cda00875f336f7ef84bf1175e41cbd9d56750b9066ee7e13be2af4af7；release ui-r57-20261023T054104Z-893b8383；manifest09868b5fad6708ef257decf0b4c3892211c2216ee0b02edd83a7d3ed5716e370。D79/FINAL-PINS.json明确来源。

独审source/完整closure/真实release keywordPage组合11绿 FINAL2aafeda1e983f0a3dda73705bb1402811cf19c2424283260f2aa983fea7d23ba，SEALED76b3bc1aa13711a8735c60eef74fe8945bca061680bc67d6ec17fb725737537e。实际原factory账号8组/30HTTP FINALe28128ccb817ec02dec8c6660e4bb76a6a401ead5333d48c158369c5cbaa5216；联合原47业务+连接3+原key2+mode6+guided3 FINAL8b2fc1eae25b67125a19dfa8ca4e0693828913cb38ce3ac7f5a81208141f6ebe。root D79/ui-recovery-validation完整index/fit+原Native factory界面8绿：新账号fresh确认/未勾选0start、1255/390有效字14.45、打开网页精确ID失败可见、取消删除0/本人确认合成delete1、旧task cursor/owner/store保留且新账号仍可fresh。UI原records_changed诊断如实保留，DELETE-INVARIANTS精确核定仅合成账号删除+任务解绑+删除回执/audit，其他账号原样，非生产。真实浏览器登录/平台采集未测。

filled entry独审 FINAL769559bd1451c83b93aeb6e085e2d8a2f9c3203a009fd9cbf680e325a1c51228/SEALED8815dcc9a75413044c057ed47379508e2ab3f4c899ee14df9497d82cec37f0dc，固定entry01a261ca6b30c2bf2076ac0b5a622484fd81b1989dcd19361014cc7db2420ed1，SUMMARY6b3f7b32ed8320150ad047130a892e9a3397985e90f6209163fedd32a9ce1129。root原check28155 exit0核3308+旧回滚闭包/CAS，不重跑冒充独审。root仅INSTALLATION_REVIEWED单bool变更批准为1ccce0f6ebb4cfad9bf5fca382769ee7707eac669f58fc231b0c836f09d4b1c7，原ack installer exec39801已exit0。N79 launcher c02988a90de374b150ca240dc55b656d6ac9c1c27566a009c06b9b9f5d7d85a4，FROZEN8161593e7059809069c44578fb789c61cc12bd88e3515d7304a0914f5c48b534，binding14cf…a9cb原样。备份delivery-v79/next-launch-prepared/candidate-unified-v79/canonical-entry-before。原N --check/--self-test实际exit0，274资源/134checks通过，不冒充本人Native首开。

05:43:09Z/05:49:31Z原数据库只读前后全7类业务及账号非秘密元数据digest完全一致：3账号、1888评论、1129原作者、40任务、4reply、1794AI、1465rental_assessments、1888unique_leads、3contact_events。未读会话凭据、未恢复旧DB覆盖、未删除真实账号、未发消息/平台/模型调用。最后只读62748已不存在，未擅自再启或关闭人用窗口。已明确通知本人从原桌面重开并选账号自己开始，仍未收到79真人首开/真实获客回执；不能承诺平台验证码已解决。

本机下一启动79，公开受限SFX仍77，本轮未重编/分发；完整goal继续active，不能标complete。高意向与DeepSeek/Codex对照已交outputs/评论分析对照/DeepSeek与Codex评论分析对照.xlsx（215去重Codex高参考，软件仍DeepSeek/人工未替换）。账号删除/任务共享不等于完整文件库UI已完；真实采集速度、平台本人核验、DM/排程/媒体/词效后继缺口继续按上文待办。所有这轮agent与root exec已终态，不重复原实验；root CUse被本人Esc后始终只做自有headless QA，无真人窗口输入。D79/INSTALLATION-FINAL.json为精确最终索引。
'''
with (D.parent/'HANDOFF-THREE-IN-ONE-LATEST.md').open('a',encoding='utf-8') as f:f.write(section)
status=P/'memory/STATUS.md'
with status.open('a',encoding='utf-8') as f:f.write('\n\n## 2026-10-23 13:50 账号切换与获客入口急修已装下一启动79\n\n新增所选账号打开网页登录、本人确认删除账号而保留客户评论任务；允许已独立就绪的新账号新建执行，旧账号断点不转移。完整界面发现并修复keyword wrapper吞点击，F78红保留未装，F79界面8+独立组合11+原47业务与账号8 factory绿。原CAS备份安装79及N check/selftest通过；3账号、1888评论、1129客户、40任务等7类digest与账号metadata安装前后原样。本人须重开原快捷方式自行开始，真实平台/验证码/79真人首开未验；无真实删除或消息。公开分发包仍77，三合一完整goal active。详情work/commercial-integration-20261022/delivery-v79/INSTALLATION-FINAL.json及主HANDOFF。\n')
print(json.dumps({'status':out['status'],'receiptSha256':sha(D/'INSTALLATION-FINAL.json'),'accountRecords':out['accountRecords'],'commentRecords':out['commentRecords'],'fullGoalComplete':False}))
