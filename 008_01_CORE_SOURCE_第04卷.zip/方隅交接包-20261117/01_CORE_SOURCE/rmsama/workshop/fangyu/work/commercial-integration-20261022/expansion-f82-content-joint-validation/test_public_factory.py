"""Original Native/Core/Store HTTP, fixed provider/parser, one captured public response.

No external search in this harness. No model/platform/device grant injection.
"""
from pathlib import Path
from copy import deepcopy
from http.server import ThreadingHTTPServer
import hashlib,http.client,importlib.util,json,os,shlex,sys,threading,time,traceback,uuid
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=W.parents[2];S=W/'qa-only-project'
stage=json.loads((W/'QA-STAGE.json').read_text('utf-8'));R=Path(stage['release'])
OUT=W/('factory-'+uuid.uuid4().hex);OUT.mkdir();events=[];calls=[];checks=[];server=None;backend=None;threads=[];mode=['normal'];late=[None];passed=False
save=lambda name,value:(OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2,default=str)+'\n','utf-8')
raw_response=(W/'DDGS-RAW-RESPONSE.html').read_bytes();assert hashlib.sha256(raw_response).hexdigest()=='7f893a44a98c4220b0d9d896c008945f573d5ad8afbbfc48979ac9894f9372c0'
def audit(event,args):
 if event in ('subprocess.Popen','os.system','os.startfile','os.posix_spawn'):raise RuntimeError('No process or browser')
 if event in ('socket.connect','socket.bind') and (not isinstance(args[1],tuple) or args[1][0] not in ('127.0.0.1','::1')):raise RuntimeError('Loopback only')
 if event=='socket.getaddrinfo' and args[0] not in ('127.0.0.1','::1','localhost',None):raise RuntimeError('No external DNS')
 if event=='sqlite3.connect' and not Path(args[0]).absolute().is_relative_to(OUT):raise RuntimeError('Own Store only')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  p=Path(os.fsdecode(args[0])).absolute();mode_,flags=args[1] or '',args[2] or 0
  if (any(c in str(mode_) for c in 'wax+') or isinstance(flags,int) and flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC)) and not p.is_relative_to(OUT):raise RuntimeError('Own data/evidence writes only: '+str(p))
sys.addaudithook(audit)
def load(name,path):
 m=importlib.util.module_from_spec(importlib.util.spec_from_loader(name,loader=None));m.__file__=str(path);sys.modules[name]=m;exec(compile(path.read_bytes(),str(path),'exec'),m.__dict__);return m
fixture=load('public_research_cloud_fixture',P/'work/acquisition-core-repair-20261018/gui-fixture/base_fixture.py')
cloud=fixture.CloudStandin(json.loads((P/'work/central-store-config/compiled-fixture.json').read_text('utf-8-sig')))
company=json.loads((S/'work/app/company.json').read_text('utf-8-sig'))
def transport(*a,**kw):
 value=cloud(*a,**kw);value['environment_id']=company['managedWorkspace']['environment_id'];return value
integration=load('integrations',R/'resources/platform-runtime/vendor-src/integrations.py');integration.request_json=transport
host=load('public_research_native_host',R/'ui_native_host.py');_,files=host.verify_release(R,stage['manifest_sha256']);host.verify_backend_dependencies(R,files,S)
backend=host.create_backend(R,files,project_root=S,data_dir=OUT/'data',company=company);core=backend.core
component=backend._content_component();provider=sys.modules[component.__module__.rsplit('.',1)[0]+'.public_search_provider'];original_search=provider.search
def traced_search(*a,**kw):
 try:return original_search(*a,**kw)
 except Exception:
  save('PROVIDER-ERROR.json',{'traceback':traceback.format_exc()});raise
provider.search=traced_search
headers={};user=None;store=None;account=None
def source(method,url,payload):
 assert method=='POST' and url=='https://html.duckduckgo.com/html/' and set(payload)=={'q','b','l'}
 assert not backend.lock._is_owned(),'Network under global backend lock'
 # Prove a separate original Store writer can reserve a transaction right here.
 with core.store.connect() as db:db.execute('BEGIN IMMEDIATE');db.execute('ROLLBACK')
 calls.append({'method':method,'url':url,'query':payload['q'],'transport':'fixed-public-response-replay-no-external','writeTransactionFree':True});save('PROVIDER-CALLS.json',calls)
 if late[0]:late[0]()
 if mode[0]=='lost':raise ConnectionError('Synthetic response lost')
 if mode[0]=='controls':return 200,raw_response.replace('古北'.encode(),('古\u200b北').encode())
 return 200,raw_response
backend._public_search_response_transport=source
def start():
 global server,origin,headers
 server=host.StaticServer(R,files,backend=backend,cookie_name='public_research_fixture_session');t=threading.Thread(target=server.serve_forever,daemon=True);t.start();threads.append(t);origin='http://127.0.0.1:'+str(server.server_port);headers={}
def req(method,path,payload=None,expected=200):
 c=http.client.HTTPConnection('127.0.0.1',server.server_port,timeout=30);status=None;value=None
 try:
  c.request(method,path,json.dumps(payload,ensure_ascii=False).encode() if payload is not None else None,headers);r=c.getresponse();status=r.status;head=dict(r.getheaders());raw=r.read()
  try:value=json.loads(raw)
  except ValueError:value={'nonJson':raw.decode('utf-8','replace')}
 finally:
  c.close();logged=deepcopy(payload)
  if logged and logged.get('action')=='login':logged['data']['password']='synthetic omitted'
  events.append({'method':method,'path':path,'payload':logged,'status':status,'body':value,'providerCalls':len(calls)});save('HTTP.json',events)
 assert status==expected,(method,path,status,expected,value)
 return value,head
def action(name,data,expected=200):return req('POST','/api/workbench',{'action':name,'data':data},expected)[0]
def login():
 global user,store
 boot,_=req('GET','/api/workbench/bootstrap');headers.update({'Content-Type':'application/json','Origin':origin,'X-Fangyu-CSRF':boot['csrfToken']})
 logged,h=req('POST','/api/workbench',{'action':'login','data':{'username':'fixture-admin','password':fixture.PASSWORD}});headers['Cookie']=h['Set-Cookie'].split(';',1)[0];headers['X-Fangyu-CSRF']=logged['csrfToken'];store=cloud.first_store
 if logged['selection']['storeId']!=store:action('select_store',{'storeId':store,'expectedRevision':logged['selection']['revision']})
 user=core.session(headers['Cookie'].split('=',1)[1])
def base(**extra):return {'storeId':store,'accountId':account['id'],'platform':'xiaohongshu',**extra}
def read(**extra):return action('content_workspace_read',base(**extra))
def revision():return read()['workspace']['revision']
def search(key,query='上海 古北 服务式公寓',expected=200,**extra):return action('content_public_research_preview',base(query=query,confirmedPublicQuery=True,expectedRevision=revision(),requestId=key,**extra),expected)
def documents():return read()['workspace'].get('workflow',{}).get('documents',[])
try:
 start();login();account={'id':'public-research-synthetic-account','tenant_id':user['tenant_id'],'cloud_owner':user['username'],'store_id':store,'platform':'xiaohongshu','name':'公开资料合成账号','status':'ready','platform_uid':'synthetic-public-reference-only'};core.store.put('accounts',account)
 action('content_public_research_preview',base(query='上海 古北 服务式公寓',confirmedPublicQuery=False,expectedRevision=0,requestId='public-no-confirm'),400)
 action('content_public_research_preview',base(query='上海 古北 服务式公寓',confirmedPublicQuery=True,url='http://127.0.0.1/private',expectedRevision=0,requestId='public-no-url'),400)
 action('content_public_research_preview',base(query='上海 古北 服务式公寓',confirmedPublicQuery=True,expectedRevision=1,requestId='public-stale-version'),409)
 foreign={**account,'id':'public-foreign-owner','cloud_owner':'another-synthetic-employee'};core.store.put('accounts',foreign)
 action('content_public_research_preview',base(accountId=foreign['id'],query='公开词',confirmedPublicQuery=True,expectedRevision=0,requestId='public-wrong-owner'),403)
 action('content_public_research_preview',base(storeId='other-store',query='公开词',confirmedPublicQuery=True,expectedRevision=0,requestId='public-wrong-store'),403)
 assert not calls and not documents();checks.append({'group':'confirmation-input-owner-store-CAS-before-external','result':'PASS'})
 rev=revision();payload=base(query='上海 古北 服务式公寓',confirmedPublicQuery=True,expectedRevision=rev,requestId='public-source-first')
 answer=action('content_public_research_preview',payload);snapshot=answer['result']['publicResearch'];assert snapshot['state']=='received' and len(snapshot['results'])==5 and not documents();assert len(calls)==1
 again=action('content_public_research_preview',payload);assert again['replayed'] and len(calls)==1
 action('content_public_research_preview',{**payload,'query':'另一公开检索词'},409);assert len(calls)==1
 chosen=snapshot['results'][0]
 imp=base(searchId=snapshot['id'],searchDigest=snapshot['digest'],resultRefs=[{'id':chosen['id'],'digest':chosen['digest']}],expectedRevision=revision(),requestId='public-import-first')
 action('content_public_research_import',{**imp,'searchDigest':'0'*64},409)
 action('content_public_research_import',{**imp,'title':'client forged title'},400);assert not documents()
 imported=action('content_public_research_import',imp);doc=documents()[0];assert doc['kind']=='hypothesis' and doc['verificationStatus']=='source_assertion_unverified' and doc['requiresExplicitReference'] is True and '原文未抓取' in doc['sourceLabel']
 assert snapshot['query']=='上海 古北 服务式公寓' and 'retrievedAt' in snapshot and snapshot['retrievedAt'] not in doc['text']
 assert action('content_public_research_import',imp)['replayed'] and len(documents())==1
 evidence=action('content_knowledge_search',base(query='古北',limit=5))['result']['evidence'];assert evidence and all(e['kind']=='hypothesis' for e in evidence)
 prepared=action('content_task_prepare',base(methodId='research',query='古北服务式公寓参考',evidenceIds=[evidence[0]['evidenceId']],expectedRevision=revision(),requestId='public-explicit-task'))['result']['task'];assert prepared['evidenceIds']==[evidence[0]['evidenceId']]
 default=action('content_task_prepare',base(methodId='research',query='古北服务式公寓参考',expectedRevision=revision(),requestId='public-default-task'))['result']['task'];assert default['evidenceIds']==[]
 checks.append({'group':'preview-select-original-knowledge-explicit-reference','result':'PASS','documents':1,'modelDispatches':0})
 second=search('public-second-query','上海 古北 服务式公寓 参考')['result']['publicResearch'];same=next(r for r in second['results'] if r['url']==chosen['url'] and r['snippet']==chosen['snippet'])
 reuse=action('content_public_research_import',base(searchId=second['id'],searchDigest=second['digest'],resultRefs=[{'id':same['id'],'digest':same['digest']}],expectedRevision=revision(),requestId='public-reuse-source'))
 assert reuse['result']['documents'][0]['alreadyImported'] and len(documents())==1
 checks.append({'group':'same-source-snippet-cross-query-document-reuse','result':'PASS'})
 mode[0]='lost';unknown_payload=base(query='公开回执丢失样本',confirmedPublicQuery=True,expectedRevision=revision(),requestId='public-original-unknown')
 lost=action('content_public_research_preview',unknown_payload);assert lost['result']['publicResearch']['state']=='unknown';count=len(calls)
 assert action('content_public_research_preview',unknown_payload)['replayed'];assert len(calls)==count
 known=read(requestId='public-original-unknown');assert known['receipt']['found'] and known['receipt']['state']=='unknown';assert len(calls)==count
 mode[0]='normal'
 retry=search('public-explicit-new-key','公开回执丢失样本');assert retry['result']['publicResearch']['state']=='received' and len(calls)==count+1
 assert read(requestId='public-original-unknown')['receipt']['state']=='unknown';assert len(calls)==count+1
 mode[0]='lost';search('public-third-explicit-key','公开回执丢失样本');count=len(calls)
 rate=search('public-rate-limited','公开回执丢失样本',409);assert rate['error']['code']=='PUBLIC_SEARCH_COOLDOWN' and len(calls)==count
 # Self-owned fixture clock: only active snapshot timestamps are seeded older.
 # Original archived receipt bytes are left intact, not a product time bypass.
 from datetime import datetime,timezone,timedelta
 with core.store.connect() as db:
  db.execute('BEGIN IMMEDIATE');record=db.execute('SELECT id,body FROM records WHERE entity=?',('content_workspace_v1',)).fetchone();body=json.loads(record['body'])
  for snapshot_ in body['workflow']['publicResearch']:
   if snapshot_['query']=='公开回执丢失样本':
    snapshot_['createdAt']=(datetime.now(timezone.utc)-timedelta(seconds=601)).isoformat();snapshot_.pop('digest');snapshot_['digest']=hashlib.sha256(json.dumps(snapshot_,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
  db.execute('UPDATE records SET body=? WHERE entity=? AND id=?',(json.dumps(body,ensure_ascii=False),'content_workspace_v1',record['id']))
 mode[0]='normal';assert search('public-after-cooldown','公开回执丢失样本')['result']['publicResearch']['state']=='received';assert len(calls)==count+1;count=len(calls)
 def concurrent():
  late[0]=None
  raced=search('public-competing-key','公开并发测试',409);assert raced['error']['code']=='PUBLIC_SEARCH_IN_PROGRESS'
 late[0]=concurrent;assert search('public-in-flight-key','公开并发测试')['result']['publicResearch']['state']=='received';assert len(calls)==count+1;count=len(calls)
 checks.append({'group':'explicit-new-key-bounded-retry-inflight-block-cooldown-expiry','result':'PASS','cooldownFixture':'own Store active snapshot timestamps only; original archived receipts retained','sameKeyExternalCalls':0})
 server.shutdown();server.server_close();backend.close();backend=host.create_backend(R,files,project_root=S,data_dir=OUT/'data',company=company);core=backend.core;backend._public_search_response_transport=source;start();login()
 reread=read(requestId='public-original-unknown');assert reread['receipt']['state']=='unknown' and len(calls)==count and len(documents())==1
 checks.append({'group':'unknown-original-key-reopen-zero-redispatch','result':'PASS'})
 mode[0]='controls';restricted=search('public-controls-view','上海 古北 公开摘要')['result']['publicResearch'];assert restricted['restrictedView']
 assert all(not any(__import__('unicodedata').category(c) in ('Cf','Cs') for c in r['title']+r['snippet']) for r in restricted['results']);checks.append({'group':'hidden-characters-explicit-restricted-review-view','result':'PASS'})
 mode[0]='normal';saved=deepcopy(core.store.get('users',user['id']))
 def revoke():core.store.put('users',{**saved,'disabled':True})
 late[0]=revoke;count=len(calls);search('public-late-revocation','另一组公开词',403);late[0]=None;core.store.put('users',saved);assert len(calls)==count+1 and len(documents())==1
 checks.append({'group':'late-permission-revocation-no-result-install','result':'PASS'})
 # Independent lost HTTP acknowledgement, not just provider failure.
 mode[0]='normal';ack_payload=base(query='独审公开回执丢失',confirmedPublicQuery=True,expectedRevision=revision(),requestId='independent-http-lost-ack')
 before=len(calls);c=http.client.HTTPConnection('127.0.0.1',server.server_port,timeout=10)
 c.request('POST','/api/workbench',json.dumps({'action':'content_public_research_preview','data':ack_payload},ensure_ascii=False).encode(),headers);c.close()
 for _ in range(200):
  ack=read(requestId='independent-http-lost-ack')
  if ack.get('receipt',{}).get('state')=='succeeded':break
  time.sleep(.02)
 assert ack['receipt']['state']=='succeeded' and len(calls)==before+1
 assert action('content_public_research_preview',ack_payload)['replayed'] and len(calls)==before+1
 checks.append({'group':'independent-lost-http-ack-cached-original-key','result':'PASS','newSearchesOnReplay':0})
 # Real second CloudStandin actor/session: cannot borrow admin source or key.
 admin_headers=deepcopy(headers);admin_user=deepcopy(user);admin_store=store;before=len(calls)
 headers={};boot,_=req('GET','/api/workbench/bootstrap');headers.update({'Content-Type':'application/json','Origin':origin,'X-Fangyu-CSRF':boot['csrfToken']})
 op_logged,h=req('POST','/api/workbench',{'action':'login','data':{'username':'fixture-operator','password':fixture.PASSWORD}});headers['Cookie']=h['Set-Cookie'].split(';',1)[0];headers['X-Fangyu-CSRF']=op_logged['csrfToken']
 if op_logged['selection']['storeId']!=store:action('select_store',{'storeId':store,'expectedRevision':op_logged['selection']['revision']})
 op_user=core.session(headers['Cookie'].split('=',1)[1])
 action('content_workspace_read',base(requestId='independent-http-lost-ack'),403)
 action('content_public_research_preview',base(query='独审公开词',confirmedPublicQuery=True,expectedRevision=0,requestId='independent-wrong-actor'),403)
 action('content_public_research_read',base(storeId=cloud.manifest['stores'][1]['id']),403)
 assert len(calls)==before
 op_account={**account,'id':'independent-operator-owned-account','cloud_owner':op_user['username']};core.store.put('accounts',op_account)
 op_answer=action('content_public_research_preview',base(accountId=op_account['id'],query='独审员工公开参考',confirmedPublicQuery=True,expectedRevision=0,requestId='independent-operator-source'))
 assert op_answer['result']['publicResearch']['state']=='received' and len(calls)==before+1
 headers=admin_headers;user=admin_user;store=admin_store
 action('content_public_research_read',base(accountId=op_account['id']),403)
 checks.append({'group':'independent-two-real-fixture-sessions-owner-store-receipt-isolation','result':'PASS'})
 # Bound active snapshots at 30 while keeping original archived request receipts.
 # Fixture-only old clock/list seeding, never a product/public API mutation.
 from datetime import datetime,timezone,timedelta
 with core.store.connect() as db:
  db.execute('BEGIN IMMEDIATE');candidates=db.execute('SELECT id,body FROM records WHERE entity=?',('content_workspace_v1',)).fetchall();record=next(r for r in candidates if json.loads(r['body']).get('scope',{}).get('account_id')==account['id'])
  body=json.loads(record['body']);items=body['workflow']['publicResearch'];expired=next(r for r in items if r['requestId']=='public-original-unknown');expired_id=expired['id']
  for r in items:
   r['createdAt']=(datetime.now(timezone.utc)-timedelta(seconds=601)).isoformat();r.pop('digest');r['digest']=hashlib.sha256(json.dumps(r,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
  # Place the real archived unknown first so the original eviction picks it.
  items.remove(expired);items.insert(0,expired)
  while len(items)<30:
   r=deepcopy(items[-1]);r.pop('digest');r['id']=hashlib.sha256(('independent-aged-fixture-'+str(len(items))).encode()).hexdigest();r['requestId']='independent-aged-fixture-'+str(len(items));r['query']='独审缓存填充'+str(len(items));r['digest']=hashlib.sha256(json.dumps(r,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest();items.append(r)
  db.execute('UPDATE records SET body=? WHERE entity=? AND id=?',(json.dumps(body,ensure_ascii=False),'content_workspace_v1',record['id']))
 before=len(calls);cache=search('independent-cache-after-limit','独审缓存新公开词');assert len(calls)==before+1
 active=read()['workspace']['workflow']['publicResearch'];assert len(active)==30 and expired_id not in {r['id'] for r in active}
 assert read(requestId='public-original-unknown')['receipt']['state']=='unknown' and len(calls)==before+1
 assert action('content_public_research_preview',unknown_payload)['replayed'] and len(calls)==before+1
 checks.append({'group':'independent-active-cache-eviction-retains-original-unknown-archived-receipt','result':'PASS','fixtureSeed':'own Store old clock and bounded active list only'})
 passed=True
finally:
 if sys.exc_info()[0]:save('ERROR.json',{'traceback':traceback.format_exc()})
 if server:server.shutdown();server.server_close()
 if backend:backend.close()
 for t in threads:t.join(3)
 save('RESULTS.json',{'status':'PASS' if passed else 'RED','groups':checks,'groupCount':len(checks),'httpRequests':len(events),'providerResponseReplays':len(calls),'externalSearchRequestsThisHarness':0,'earlierStandaloneRealPublicSearchRequests':1,'realPlatformModelCalls':0,'sourceResponseSha256':hashlib.sha256(raw_response).hexdigest(),'allOwnServicesClosed':all(not t.is_alive() for t in threads),'stage':stage,'noFakeStoreOrCore':True})
 print(json.dumps({'status':'PASS' if passed else 'RED','groups':len(checks),'http':len(events),'evidence':str(OUT)},ensure_ascii=False))
