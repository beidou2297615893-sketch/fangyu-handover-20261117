const fs=require('fs'),path=require('path'),assert=require('assert');
const {chromium}=require('C:/Users/rmsama/.codex/skills/xhs-note-creator/node_modules/playwright-core');
const W=__dirname,info=JSON.parse(fs.readFileSync(path.join(W,'UI-SERVER.json'),'utf8'));
const checks=[],errors=[],external=[],actions=[];let browser;
(async()=>{
 browser=await chromium.launch({executablePath:'C:/Users/rmsama/AppData/Local/ms-playwright/chromium_headless_shell-1234/chrome-headless-shell-win64/chrome-headless-shell.exe',headless:true});
 const context=await browser.newContext({viewport:{width:1255,height:950},deviceScaleFactor:1});
 await context.route('**/*',route=>{const url=route.request().url();if(url.startsWith(info.origin+'/')||url.startsWith('data:')||url.startsWith('about:'))return route.continue();external.push(url);return route.abort();});
 await context.addCookies([{name:info.cookieName,value:info.cookieValue,url:info.origin,httpOnly:true,sameSite:'Strict'}]);
 const page=await context.newPage();page.on('pageerror',e=>errors.push(e.message));page.on('request',r=>{if(r.url().includes('/api/')&&r.method()==='POST'){let data;try{data=r.postDataJSON();}catch{}actions.push(data?.action||'unknown');}});
 await page.goto(info.origin+'/#acquire');
 await page.waitForFunction(()=>document.body.dataset.page==='acquire');
 const frame=page.frames().find(f=>f.url().includes('/canvas.html'));assert(frame,'Original fit iframe required');
 await frame.locator('[data-page-acquire]').waitFor();
 await frame.locator('[data-task-status="paused"]').waitFor();
 await frame.getByText('该账号正在执行回复，请先暂停并等待当前操作结束',{exact:true}).first().waitFor({state:'visible',timeout:15000});
 assert((await frame.locator('[data-task-status="paused"]').innerText()).includes('该账号正在执行回复，请先暂停并等待当前操作结束'));
 assert(!await frame.locator('#modal').isVisible(),'No unsolicited login or CAPTCHA modal');
 checks.push({name:'Actual F76 Native GET and original full app show persisted local account-mode pause without login modal',controlledPersistedTask:true});
 for(const width of [1255,390]){
  await page.setViewportSize({width,height:950});await page.waitForTimeout(300);
  const outer=await page.evaluate(()=>({width:innerWidth,scroll:document.documentElement.scrollWidth,scale:Number(document.body.dataset.scale)}));
  const inner=await frame.evaluate(()=>({width:innerWidth,scroll:document.documentElement.scrollWidth,messageVisible:!!document.querySelector('[data-task-status="paused"]'),font:parseFloat(getComputedStyle(document.querySelector('.acquire-status-copy span')).fontSize)}));
  assert(outer.scroll<=width+1&&inner.scroll<=inner.width+1,JSON.stringify({outer,inner}));
  assert(inner.font*outer.scale>=14,JSON.stringify({outer,inner}));
  await page.screenshot({path:path.join(W,`local-mode-${width}.png`),fullPage:true});
  checks.push({name:'Original full fit layout '+width,outer,inner,effectiveTextPixels:inner.font*outer.scale});
 }
 await frame.locator('[data-nav="accounts"]').click();await frame.waitForFunction(()=>document.body.dataset.page==='accounts');
 await frame.getByText('合成平台账号0',{exact:true}).first().waitFor();
 assert((await frame.locator('body').innerText()).includes('合成平台账号1'));
 checks.push({name:'Read-only account navigation still displays both scoped XHS account nicknames'});
 assert.deepEqual(errors,[]);assert.deepEqual(external,[]);
 assert(!actions.some(x=>['acquisition_start','acquisition_resume','account_create','account_connect','reply_send','publication_submit','intent_analyze'].includes(x)));
 fs.writeFileSync(path.join(W,'RESULTS.json'),JSON.stringify({status:'PASS',groups:checks.length,checks,pageErrors:errors,externalRequests:external,actions,actualF76FullNativeFactoryAndOriginalFitShell:true,controlledPersistedTaskFixture:true,headlessDevelopmentOnly:true,realPlatformOrModelCalls:0},null,2));
 console.log(JSON.stringify({status:'PASS',groups:checks.length}));
})().catch(async e=>{if(browser){const p=browser.contexts()[0]?.pages()[0];if(p){await p.screenshot({path:path.join(W,'failure.png'),fullPage:true}).catch(()=>{});const f=p.frames().find(x=>x.url().includes('/canvas.html'));if(f)fs.writeFileSync(path.join(W,'failure-body.txt'),await f.locator('body').innerText().catch(()=>''));}}fs.writeFileSync(path.join(W,'FAILURE.json'),JSON.stringify({error:e.stack,checks,errors,external,actions},null,2));throw e;}).finally(async()=>{await browser?.close();fs.writeFileSync(path.join(W,'STOP-UI-SERVER'),'owned fixture done');});
