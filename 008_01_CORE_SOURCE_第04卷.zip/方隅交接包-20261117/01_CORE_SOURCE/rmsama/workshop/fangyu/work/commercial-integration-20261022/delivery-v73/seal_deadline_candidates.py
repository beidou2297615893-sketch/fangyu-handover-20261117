"""Record reviewed candidate evidence without merging either candidate."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import sys

W = Path(__file__).resolve().parents[1]
if sys.argv[1:] != ['--workers-confirmed-terminal']:
    raise RuntimeError('Confirm actual collaboration worker terminal states first')
pins = {
    'scoped-prompt-version-candidate/SEALED.json': 'd51c6e8996c6f4133c1f682463ea26a379cfbfdb415697958f955b476950bcc2',
    'scoped-prompt-version-candidate/CHANGES.patch': 'cc2e15167d8fc49800216dc460aa220b9235786c8eddc5dee4791d27a19b1a3d',
    'scoped-prompt-version-independent-review/FINAL-RECEIPT.json': '7c2a1a43fa2aee6c9667e4f0009fb1216fc3b9a3c9aef25b78648c9e899a49a7',
    'scoped-prompt-version-factory-validation/FINAL-RECEIPT.json': '8967e45dd0061830e185756ac0c74d08424c3f0af18b89e01e1366d689e18c79',
    'scoped-prompt-version-factory-validation/revision-2/FINAL-RECEIPT.json': 'c38afeffb208ad78352faf6c4fc2d6af62ab709e57e9d1f253e88144e8c3fae9',
    'scoped-prompt-version-factory-validation/revision-2/FIFTH-FILE.patch': '4509895d7dfe0400efbdaa43c8c9c61d6943139e4ffa769b36911f798e2334ef',
    'pdf-text-import-candidate/SEALED.json': '2497cc0daeb546a2f48e78e1d867f9566adbef56012ece470734806c9723c847',
    'pdf-text-import-independent-review/FINAL-RECEIPT.json': '9d8e8615429c44fd8c5f98d7c9ddd9aef77de0a2f8cfc92c0c9537c4634d0cf9',
    'pdf-text-import-candidate/revision-2/SEALED.json': '80b2efdba25d1ac848f318ec25ed915541979abe6bae2749a542e511cee29957',
    'pdf-text-import-candidate/revision-2/FINAL-RECEIPT.json': 'f004317abbd1d29323f5a124e86497f8a8f9ee76e268f9c8881ce8f6ee38e10f',
    'pdf-text-import-candidate/revision-2/REVISION-2.patch': '29ec828a53c468ce91b7ceda85ffa2ca3de176cb0dcc4033d6fecea3c772c694',
    'pdf-text-import-independent-review/revision-2-review/FINAL-RECEIPT.json': '3a85767729cd77141518c707a330aa768d1b78958b1ff85f356909998486a03b',
}
for relative, expected in pins.items():
    path = W / relative
    if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
        raise RuntimeError('Candidate evidence changed: ' + relative)
summary = '''- **本地提示词版本候选**：原F73新分析本就保存版本，缺口仅历史重评eligibility误把同云规则版认作全当前。4文件11hunks、原作者公开Core/Store runtime/vendor各13绿；独审7组另跑通过。旧调用/只读/自动pending不因本地差异新收费，显式本人版本确认才可例外，原人工与CAS/权限/unknown合同不改。无task范围、标准客户权限和UI入口不扩。
- **实际工厂分层**：四文件沿旧manifest被拒；合法新QA stage通过manifest后仍被CustomerWorkbench两个固定摘要拒。revision-2仅第五文件两个hash精确同步，其他AST不改；原verify_release/read_public/依赖/create_backend通过，原合成员工HTTP登录200、默认Native维护403/held/派发0/无attempt。QA快照194资源（自有目录不含4个site-package许可输入），不是交付73的198资源，不是交付74。
- **正向开发QA未决红必须优先调查**：走原构造守卫和合成绑定后，读版本、旧请求零派发、显式一次与同版重放部分通过；之后unknown变批得到200，夹具未保存完整业务body和精确dispatch/status数组。持久unknown摘要映射old，另一validated映射unknown+different，根因与精确增量/费用预留变化均未证实。不能据HTTP200判安全或绕过；不能用较低层33组绿覆盖此红。下次只在自有合成QA保完整回执/计数/输入与缓存关联后解释，不触生产原9条unknown，也不新键重发。用户页/真实模型/完整冻结和安装均未完成，故未合入。
- **文字PDF候选**：官方pypdf6.21.2纯Python/BSD-3-Clause，wheel1d44d1a3a200f25062adff0085b02040e4646431ac2ccac22e42679e91466084，原3改+63新增、66完整源码精确重放。原公开preview12解析+8旧格式+4同fixture DOM通过；不做OCR或ASR，原owner/store与确认保存链源码不改，但未实际Store/HTTP验新格式。
- **PDF红→最小修订**：旧2ee870/32f414只是过期合成PDF fileSha证据，已INVALID，正确parent2497cc也曾被独审发现FileAttachment/EF附件未拒合同红，保原9d8e861回执和固定67813样本。revision-2仅pdf_text_import.py与原wrapper SHA两处改动（其余64同）；先检查完整对象图再解码，明确附件直接/间接Name拒绝。原样本8变体get_data前0调用，12+8+4复过；独审另跑原复例+两变体与中文对照，有限PASS3a857677。只用v2 source/receipt，不抹旧红。不代表任意PDF全程零解码或完整恶意PDF安全证明。
- **PDF仍未合入**：需独立真实freeze资源闭包、原工厂/同owner-store HTTP预览及确认保存、unknown同key、标准compiled导入与缓存守卫、真实用户文件；OS资源硬限制与完整上游安全核验尚未做。当前73和281MB内测包仍只支持DOCX/PPTX/TXT/MD，不能称已支持PDF。'''
result = {
    'status': 'FINAL_UNMERGED_CANDIDATES_WITH_LAYERED_EVIDENCE_AND_RETAINED_RED_CASES',
    'capturedAtUtc': datetime.now(timezone.utc).isoformat(),
    'allOwnedWorkersTerminal': True,
    'workerNames': ['installer_finish_4', 'knowledge_review_4', 'schedule_finish_4'],
    'productionCandidatesMerged': False,
    'currentInstalledNextLaunch': 'candidate-unified-v73',
    'currentRunningVersion': 'v72',
    'goalComplete': False,
    'pinnedEvidence': {str(W / path): value for path, value in pins.items()},
    'technicalSummary': summary,
}
target = W / 'DEADLINE-CANDIDATES.json'
if target.exists():
    raise RuntimeError('Preserve earlier final candidate handoff')
target.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'status': result['status'], 'receiptSha256': hashlib.sha256(target.read_bytes()).hexdigest()}, ensure_ascii=False))
