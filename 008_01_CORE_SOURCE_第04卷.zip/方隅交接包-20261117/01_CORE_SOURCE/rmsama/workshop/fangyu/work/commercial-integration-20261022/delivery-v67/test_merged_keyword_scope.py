"""Actual merged S modules; local manifest factories + original synthetic Store.
No release path sys.path, production DB, platform, provider or child process.
"""
from pathlib import Path
from copy import deepcopy
import ast,hashlib,http.client,importlib.util,json,os,sys,tempfile,textwrap,threading,time,uuid
from urllib.parse import urlencode
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent;W=D.parent;P=W.parents[1]
S=P/'work/parallel-integration-20261018/final-integration/stage-02/project';N=S/'work/ui-native-r57';R=S/'work/ui-runtime-r55/src'
files_to_pin=['workbench_backend.py','ui_native_host.py','freeze_ui.py','keyword_effect_workbench.py','customer_workbench.py','customer_intent_workbench.py','content_workflow.py','workflow_methods.py']
sha=lambda raw:hashlib.sha256(raw).hexdigest()
before={n:sha((N/n).read_bytes()) for n in files_to_pin};blocked=[];trace=[]
def fence(event,args):
 if event in ('socket.connect','socket.bind') and (not isinstance(args[1],tuple) or args[1][0]!='127.0.0.1'):blocked.append(event);raise RuntimeError('External socket forbidden')
 if event=='socket.getaddrinfo' and args[0] not in ('127.0.0.1',None):blocked.append(event);raise RuntimeError('External DNS forbidden')
 if event in ('subprocess.Popen','os.system','os.startfile','os.posix_spawn'):blocked.append(event);raise RuntimeError('No child process')
 if event=='sqlite3.connect' and not Path(args[0]).resolve().is_relative_to(D):blocked.append(event);raise RuntimeError('No real DB')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  p=Path(os.fsdecode(args[0])).absolute();mode,flags=args[1] or '',args[2] or 0
  writing=any(c in str(mode) for c in 'wax+') or isinstance(flags,int) and bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC))
  if writing and not p.is_relative_to(D):blocked.append('write:'+p.name);raise RuntimeError('No writes outside own fixture')
sys.addaudithook(fence)
sys.path[:0]=[str(R),str(N)] # Original source paths only. No synthetic release.
from core.engine import Core
from assistant.customer_list import _person
from assistant.ai_workflow import effective_intent
from core.interaction_inbox import digest as event_digest

def load_actual(name,path):
 m=importlib.util.module_from_spec(importlib.util.spec_from_loader(name,loader=None));m.__file__=str(path);sys.modules[name]=m;exec(compile(path.read_bytes(),str(path),'exec'),m.__dict__);return m
native=load_actual('keyword_scope_merged_native',N/'workbench_backend.py')
for name in files_to_pin:compile((N/name).read_bytes(),str(N/name),'exec')
assert {'keyword_effect_read','customer_intent_read','customer_intent_correct','customer_intent_cancel'}<=native.CUSTOMER_ACTIONS
assert len(native.INTERACTION_ACTIONS)==3
assert native.CONTENT_EXTENSION_PINS['content_workflow.py']==before['content_workflow.py']
assert native.CONTENT_EXTENSION_PINS['workflow_methods.py']==before['workflow_methods.py']
trace.append('Actual merged S syntax/action unions and v3 source pins remain exact')

with tempfile.TemporaryDirectory(dir=D,prefix='keyword-merged-') as temp:
 root=Path(temp)/'minimal-release';root.mkdir();(root/'web').mkdir();(root/'resources').mkdir()
 for name in ['ui_native_host.py','customer_workbench.py','customer_intent_workbench.py','keyword_effect_workbench.py']:(root/name).write_bytes((N/name).read_bytes())
 for name in ['index.html','app.mjs','styles.css']:(root/'web'/name).write_text('synthetic closure only',encoding='utf-8')
 entries=[dict(path=p.relative_to(root).as_posix(),size=p.stat().st_size,sha256=sha(p.read_bytes())) for p in sorted(root.rglob('*')) if p.is_file()]
 manifest=dict(schema='fangyu_native_ui_release_v1',company_id='fangyu-apartment-client',files=entries)
 raw=json.dumps(manifest,ensure_ascii=False).encode();(root/'RELEASE.json').write_bytes(raw)
 path_before=list(sys.path);modules_before=set(sys.modules)
 host={'__name__':'merged_keyword_local_launcher','__file__':str(root/'ui_native_host.py')}
 exec(compile((root/'ui_native_host.py').read_bytes(),host['__file__'],'exec'),host)
 _,verified=host['verify_release'](root,sha(raw))
 intent_factory=host['load_customer_intent_factory'](root,verified)
 keyword_factory=host['_keyword_effect_factory'](root,verified)
 # Execute the exact existing customer-factory branch of actual create_backend.
 # This avoids fabricating an alternate import path or pretending this minimum
 # closure is a full installed release/dependency environment.
 ht=(N/'ui_native_host.py').read_text(encoding='utf-8')
 customer_branch=ht[ht.index("    customer_entry = files.get('customer_workbench.py')"):ht.index('    intent_factory=load_customer_intent_factory(root,files)')]
 local={**host,'root':root,'files':verified,'extra':{}}
 exec(compile(textwrap.dedent(customer_branch),'actual create_backend customer factory branch','exec'),local)
 customer_factory=local['extra']['customer_factory']
 assert list(sys.path)==path_before and str(root) not in sys.path
 assert not any(n.startswith(('fangyu_keyword_effect_','fangyu_customer_intent_workbench_')) for n in set(sys.modules)-modules_before)
 trace.append('Actual exec-loaded host manifest/read_public -> customer factory branch + two new local factories, no release sys.path or helper module cache')
 # Three classes loaded from the exact manifest bytes, including old-customer
 # projection; damaged resources cannot execute in the new local factories.
 for name,factory_name in [('customer_intent_workbench.py','load_customer_intent_factory'),('keyword_effect_workbench.py','_keyword_effect_factory')]:
  original=(root/name).read_bytes();(root/name).write_bytes(original+b'\n# damaged\n')
  try:host[factory_name](root,verified)
  except host['UIHostError']:pass
  else:raise AssertionError('Damaged helper was accepted')
  (root/name).write_bytes(original)
 trace.append('Both new helper factory closures reject corrupted bytes before execution')
 core=Core(Path(temp)/'data',R/'resources',defer_startup_recovery=True)
 company=dict(id='fangyu-apartment-client',name='Synthetic merged rules',edition='customer',personalMode=False,authMode='managed',platforms=['xiaohongshu','douyin'],managedWorkspace={'environment_id':'merged-keyword-fixture','endpoint':'https://example.invalid'})
 tenant='cloud-'+sha(b'merged-keyword-fixture\nfangyu-apartment-client')[:24];uid=sha((tenant+'\nalice').encode())
 user=dict(id=uid,tenant_id=tenant,username='alice',role='operator',cloud_bound=True,disabled=False)
 core.store.put('users',user);core.store.put('tenants',dict(id=tenant,tenant_id=tenant,name='Synthetic'))
 for aid,store in [('account-a','gubei'),('account-b','gubei'),('account-c','other')]:
  core.store.put('accounts',dict(id=aid,tenant_id=tenant,cloud_owner='alice',store_id=store,platform='xiaohongshu',platform_uid='uid-'+aid))
  core.store.put('tasks',dict(id='task-'+aid,tenant_id=tenant,cloud_owner='alice',account_id=aid,store_id=store,platform='xiaohongshu'))
 leads=[]
 for i,aid in enumerate(['account-a','account-b','account-c']):
  row=dict(id='lead-'+str(i),tenant_id=tenant,cloud_owner='alice',task_id='task-'+aid,platform='xiaohongshu',store_id='other' if i==2 else 'gubei',
      author_id='same-person',comment_id='comment-'+str(i),author='合成客户',text='需要古北两个月公寓 '+str(i),source_id='comment:comment-'+str(i),source_keyword='古北短租',
      note_url='https://www.xiaohongshu.com/explore/0123456789abcdef01234567',created_at='2026-10-23T00:00:00Z',ai_intent={'status':'graded','level':'low','reason':'old synthetic AI'})
  core.store.put('leads',row);leads.append(row)
 customers=customer_factory(core,company,S);keywords=keyword_factory(core,customers)
 backend=native.WorkbenchBackend.__new__(native.WorkbenchBackend);backend.closed=False;backend.lock=threading.RLock();backend.core=core;backend.company=company
 backend.customer_workbench=customers;backend.customer_intent_factory=intent_factory;backend.keyword_effect_workbench=keywords;backend.remote_management=None
 profile={'role':'operator','_workbench_stores':[{'id':'gubei'}]}
 backend._identity=lambda token:(core.store.get('users',uid),profile) if token=='synthetic-token' else (_ for _ in ()).throw(native.WorkbenchError('AUTH_REQUIRED','Synthetic employee required',401))
 backend._activate_central_config=lambda actor,p,store,**kw:{'store_id':store}
 with core.store.connect() as db:db.execute('INSERT INTO sessions VALUES(?,?,?)',(sha(b'synthetic-token'),uid,time.time()+3600))
 server=host['StaticServer'](root,verified,backend=backend,cookie_name='keyword_merged_fixture');thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
 origin='http://127.0.0.1:'+str(server.server_port);headers={'Content-Type':'application/json','Origin':origin,'X-Fangyu-CSRF':server.csrf_token,'Cookie':'keyword_merged_fixture=synthetic-token'}
 def action(name,data,status=200,override=None):
  conn=http.client.HTTPConnection('127.0.0.1',server.server_port,timeout=10)
  if name=='customers':conn.request('GET','/api/workbench/customers?'+urlencode(data),headers=override or headers)
  else:conn.request('POST','/api/workbench',json.dumps({'action':name,'data':data}).encode(),override or headers)
  res=conn.getresponse();body=res.read();found=res.status;conn.close();out=json.loads(body) if body.startswith(b'{') else {'text':'blocked'}
  assert found==status,(name,found,status,out);return out
 try:
  query=dict(query='',filter='all',sort='time',page=1,pageSize=20,platform='xiaohongshu')
  listing=action('customers',query)['customers'];assert listing['total']==1
  person=_person(leads[0])[0];scope=dict(storeId='gubei',customerId=person,leadId='lead-0',platform='xiaohongshu')
  current=action('customer_intent_read',scope)['intentCorrection']
  payload={**scope,'requestId':'merged-correction-1','expectedVersion':current['version'],'sourceDigest':current['sourceDigest'],'status':'graded','level':'high','reason':'本人核对明确两个月需求'}
  changed=action('customer_intent_correct',payload)['intentCorrection'];assert changed['currentIntent']['level']=='high' and changed['aiIntent']['level']=='low'
  assert action('customer_intent_correct',payload)['intentCorrection']['receipt']==changed['receipt']
  assert 'manual_intent' not in core.store.get('leads','lead-1');assert core.store.get('leads','lead-2')==leads[2]
  assert effective_intent(core.store.get('leads','lead-0'))['level']=='high'
  trace.append('Actual S HTTP customer read -> original Business/AIWorkflow single-comment correction -> same Store replay; same-customer other account and other store unchanged')
  def snapshot():
   with core.store.connect() as db:return [tuple(r) for r in db.execute('SELECT * FROM records ORDER BY entity,id')]
  old=snapshot();report=action('keyword_effect_read',dict(storeId='gubei',dateFrom='2026-10-23',dateTo='2026-10-23',platform='xiaohongshu'))['keywordEffect']
  assert report['total']['commentsSeen']==2 and report['total']['uniqueCustomers']==1
  assert report['total']['manuallyReviewedComments']==1 and report['total']['aiAnalyzedComments']==2
  assert report['groups'][0]['keyword']=='古北短租' and snapshot()==old
  trace.append('Actual S HTTP keyword report reads current manual/AI judgments, comments/customers separate, original Store is byte-unchanged by report')
  # Original immutable event provenance and current account/session authority.
  es=dict(tenant_id=tenant,owner='alice',store_id='gubei',account_id='account-a',platform='xiaohongshu',platform_uid='uid-account-a',task_id='own-task')
  core.store.put('tasks',dict(id='own-task',tenant_id=tenant,cloud_owner='alice',store_id='gubei',account_id='account-a',platform='xiaohongshu',source_kind='own_interactions'))
  core.store.put('source_item_evidence_v1',dict(id='own-page',tenant_id=tenant,scope=es))
  event=dict(type='mentions',event_id='notice-1',author_id='same-person',author='合成通知客户',text=leads[0]['text'],text_source='explicit_comment',
      raw={'comment_info':{'id':'comment-0','content':leads[0]['text'],'user_info':{'user_id':'same-person'}},'note_info':{'note_id':'0123456789abcdef01234567'}})
  eid=event_digest([tenant,'alice','account-a','xiaohongshu','mentions','notice-1'])
  original_event=dict(id=eid,tenant_id=tenant,scope=es,page_evidence_id='own-page',event=event,observed_at='2026-10-23T00:01:00Z')
  core.store.put('acquisition_interaction_events_v1',original_event)
  inboxbase=dict(storeId='gubei',accountId='account-a',platform='xiaohongshu',viewId='merged-view-12345678')
  inbox=action('interaction_inbox_read',inboxbase)['interactionInbox'];assert inbox['stats']['totalEvents']==1
  item=inbox['items'][0];request={**inboxbase,'eventId':eid,'requestId':'merged-inbox-12345678','expectedVersion':item['version'],'eventDigest':item['eventDigest'],'state':'ignored'}
  saved=action('interaction_inbox_state_save',request)['interactionInbox'];assert saved['item']['state']=='ignored'
  assert action('interaction_inbox_state_save',request)['interactionInbox']['replayed']
  assert core.store.get('acquisition_interaction_events_v1',eid)==original_event
  trace.append('Actual S HTTP preserved inbox/Core implementation: original event -> CAS ignore -> original-key replay; event bytes unchanged')
  action('keyword_effect_read',dict(storeId='gubei',dateFrom='2026-10-23',dateTo='2026-10-23'),403,{**headers,'X-Fangyu-CSRF':'bad'})
  profile['_workbench_stores']=[{'id':'other'}]
  action('keyword_effect_read',dict(storeId='gubei',dateFrom='2026-10-23',dateTo='2026-10-23'),403)
  action('customer_intent_read',scope,403)
  action('interaction_inbox_read',inboxbase,403)
  profile['_workbench_stores']=[{'id':'gubei'}]
  trace.append('CSRF and actual selected-store changes reject all three new business paths')
  content=native.WorkbenchBackend._content_component()(core.store)
  answer=content.execute('content_methods_read',user,'gubei',dict(accountId='account-a',platform='xiaohongshu'),lambda *a:True)
  assert len(answer['result']['methods'])==17
  assert not blocked and str(root) not in sys.path
  trace.append('Actual current v3 host-pinned content closure still loads and exposes 17 methods; no model or platform calls')
 finally:server.shutdown();server.server_close();thread.join(3)
after={n:sha((N/n).read_bytes()) for n in files_to_pin};assert before==after
result=dict(status='PASS_ACTUAL_S_MERGED_KEYWORD_NARROW',checks=len(trace),trace=trace,files=after,sourceUnchangedDuringValidation=True,
    releaseAddedToSysPath=False,productionAccess=False,realModelCalls=0,realPlatformRequests=0,blocked=blocked)
(D/'KEYWORD-ACTUAL-S-VALIDATION.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(result,ensure_ascii=False))
