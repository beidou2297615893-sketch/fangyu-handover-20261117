from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
D=Path(__file__).resolve().parent;W=D.parent;P=D.parents[2];N=P/'work/ui-native-r57'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before=json.loads((D/'PROTECTED-BUSINESS-BEFORE-INSTALL.json').read_text('utf-8'))
after=json.loads((D/'PROTECTED-BUSINESS-AFTER-INSTALL.json').read_text('utf-8'))
diag=json.loads((D/'ACTUAL-ENTRY-DIAGNOSTICS.json').read_text('utf-8'))
assert after['sameAsBeforeInstall'] and after['status']=='PASS_CURRENT_BUSINESS_AND_ACCOUNT_METADATA_UNCHANGED'
assert diag['status']=='PASS_INSTALLED_ORIGINAL_CANONICAL_DIAGNOSTICS_NOT_NATIVE_FIRST_START'
assert sha(N/'run_workbench.py')==diag['launcherSha256']=='7776e1250fbd32c369310e3d4a7bc344cec8525041705fbdfa1af00ad2721617'
assert sha(N/'FROZEN.json')==diag['frozenSha256']=='d5a28494dfe903baabe3488a78f5793bbbd2b23eceb8b288a4cbc10dd3ba9b18'
assert sha(N/'state/production-workspace.json')==diag['bindingSha256']==before['bindingSha256']
approval=json.loads((W/'f82-next-entry-candidate/ROOT-ENTRY-APPROVAL.json').read_text('utf-8'))
assert approval['onlyReviewedBooleanChanged'] and approval['afterSha256']=='718060bdf41efa5fa7ca30876d773014437efe1632a976056585931083604a08'
evidence=[]
for name in ('FINAL-PINS.json','AGGREGATE-VALIDATION.json','NEXT-ENTRY-ROOT-REVIEW.json',
             'ACTUAL-ENTRY-DIAGNOSTICS.json','ACTUAL-ENTRY-CHECK.json','ACTUAL-ENTRY-SELF-TEST.json',
             'PROTECTED-BUSINESS-BEFORE-INSTALL.json','PROTECTED-BUSINESS-AFTER-INSTALL.json','SOURCE-MERGE-APPLIED.json','CURRENT-BUSINESS-BACKUP.json'):
    evidence.append({'path':name,'sha256':sha(D/name),'bytes':(D/name).stat().st_size})
receipt={'status':'INSTALLED_F82_NEXT_LAUNCH_AND_ACTUAL_ORIGINAL_ENTRY_DIAGNOSTICS_PASS',
    'createdUtc':datetime.now(timezone.utc).isoformat(),'candidate':'candidate-unified-v82',
    'release':'ui-r57-20261023T095243Z-1c9a271f','sourceFiles':3856,'resources':538,
    'launcherSha256':diag['launcherSha256'],'frozenSha256':diag['frozenSha256'],'bindingSha256':diag['bindingSha256'],
    'accountRecords':after['accountRecords'],'allSevenBusinessDigestsUnchanged':after['sameAsBeforeInstall'],
    'businessCounts':{key:value['rows'] for key,value in after['protectedTablesAndEntities'].items()},
    'sourceBackup':'source-before','entryBackup':str(W/'f82-next-entry-candidate/next-launch-prepared/candidate-unified-v82/canonical-entry-before'),
    'oldWindowNotStoppedOrReplaced':True,'nativeHumanFirstOpenVerified':False,
    'realPlatformCollectionOrMessagingVerified':False,'scannedPdfIncluded':True,
    'ordinaryCleanDistributionDeliveryPending':True,'realPlatformOrModelCalls':0,
    'fullGoalComplete':False,'evidence':evidence}
target=D/'INSTALLATION-FINAL.json';assert not target.exists();target.write_text(json.dumps(receipt,ensure_ascii=False,indent=2),'utf-8')
print(json.dumps({'status':receipt['status'],'finalSha256':sha(target),'counts':receipt['businessCounts'],'accounts':receipt['accountRecords']}))
