from pathlib import Path
import datetime, hashlib, json, shutil

D = Path(__file__).resolve().parent
P = D.parents[2]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
pins = json.loads((D / 'BUILD-FIXED-PINS.json').read_text('utf-8'))
source = Path(pins['package']) / 'FangyuWorkbenchSetup-standard-held-clean-v77.exe'
expected = 'a8220d69b0f77b063d79fa8d7eaa2abe39f7abed59397df31d792a016ff4d2e3'
assert sha(source) == expected
review = D.parent / 'v77-standard-package-independent-review/FINAL-RECEIPT.json'
assert sha(review) == '24be40ae1364734aa2e7babefc20729fcccd533f14edc994cca76fd5f8041de2'
diagnostics = json.loads((D / 'ACTUAL-ENTRY-DIAGNOSTICS.json').read_text('utf-8'))
assert diagnostics['launcherSha256'] == '52c4db8cddb64802121c1a77d25f86149ba321f7427a45f46a4758d577e3fe3f'
business = json.loads((D / 'PROTECTED-BUSINESS-AFTER-INSTALL.json').read_text('utf-8'))
assert business['sameAsBeforeInstall'] is True
out = P / 'outputs/三合一交付'
package = out / '普通电脑内测版/方隅工作台_受限内测安装包.exe'
report = out / '当前交付核对.md'
instructions = out / '普通电脑内测版/安装与当前能力.txt'
assert sha(package) == '38d3fcc329f44a38045cc1e9865d2a5312464c58fa918a3555e5a7c110ad4eb8'
assert sha(report) == '41074542e83b43a9431777a54c1c824f6c6253e9c5c9c819fcb253c957727fca'
archive = out / '历史内测版/账号读取修复前保留'
root = P.resolve()
for path in (out, package, report, instructions, archive):
    resolved = path.resolve()
    assert resolved.is_relative_to(root) and not path.is_symlink()
assert not archive.exists()
archive.mkdir(parents=True)
backups = []
for path in (package, report, instructions):
    target = archive / path.name
    shutil.copy2(path, target)
    assert sha(target) == sha(path)
    backups.append({'source': str(path), 'backup': str(target), 'sha256': sha(target)})
temporary = package.with_suffix('.verified-next')
assert not temporary.exists()
shutil.copy2(source, temporary)
assert sha(temporary) == expected
temporary.replace(package)

report_text = '''# 当前交付核对

更新到10月23日中午。**账号与客户列表读取故障已修复，原电脑的下一次启动入口已更新。关闭当前工作台后，从原桌面“方隅工作台”快捷方式重开即可加载。** 当前旧窗口没有被强制关闭；尚未取得本人重开后的界面确认。

本次更新前后逐项核对，2个小红书账号、1个抖音账号、1,888条评论、1,129位按原作者归并的客户记录、40个任务和4条原回复均保留，原业务内容与账号绑定没有变化。没有用旧备份覆盖现有数据。客户记录不代表每位都有明确租房意向或可以主动联系。

## 本次已经接入

- **账号与获客**：修复列表读取失败；关键词搜索保留在“获客”，指定笔记、博主主页和我的互动放在左侧独立的“多样化获客”。显示当前任务账号与下一次采集账号。同一账号被其他流程占用时，在首次读取前检查并显示原因；原任务和断点继续保留。
- **客户与回复**：客户人工更正保留原AI判断，折叠、连续加载、跨页选择和表格下载已验证。发送账号可明确选择，回复仍由本人核对。
- **内容运营**：保留人设、栏目、选题、资料、草稿、规则检查、人工审核和内容包。新增分步定位访谈、保存版本、专家方法查找与人工采用；专家结论先作为待核对草案，不能直接替代门店事实。自动内容生成服务尚未开启。
- **资料与视频**：支持Word、PPT、文字PDF、纯文字和Markdown的文字预览与确认保存。已有视频素材加提供字幕的剪辑、播放和下载已核验，外置视频工具需另行配套。自动转写、配音及生成式媒体仍需补齐。
- **经营结果**：可人工登记联系、预约、到访、签约、回款和费用，保留撤销历史；没有利润依据时不把结果写成ROI。

古北店保留1—12个月规则和租期分组；其他12家店的规则输入没有复制古北新规则。默认帖子最近30天，可选择7天或90天，历史任务保留原条件。定期检查须本人确认账号、门店和频率，只在工作台当前会话运行，重开后需重新确认。

1,888条评论均保留Codex复核记录。其中1,794条有历史DeepSeek结果，1,503条标签相同、291条不同；83.78%是一致率，不是准确率。历史AI高意向为144条评论，并非144位已确认客户。未整批覆盖历史判断或重新收费分析。

## 当前交付范围

同级“普通电脑内测版”安装包现已同步本次修复及新增内容功能，约286MB。仅供受限内测；原电脑已更新入口，无需用它重装。包内不含本电脑的客户数据、平台登录会话或凭据。

本次源码、业务接口、宽窄窗口、安装包完整性、自检及自有目录解包检查通过。它们不代替本人当前界面、第二台普通电脑、自然取得的企业权限或真实平台验收。普通电脑无需独立显卡、另装Python或本地大模型，需要可用的WebView2与.NET环境。

**三合一完整商业版本仍未全部完成。** 私信收发与批量队列、直播、真实作品发布、内容定时及多账号执行、平台联想词与外部效果取数，以及转写、配音和生成式媒体仍有工程缺口。新增来源、分页、账号身份、验证后恢复和内容生成质量还需要真实业务核验，不能统一写成只等扫码。

没有代本人发送真实评论、私信或作品。需要扫码、人脸或验证码时保留断点，不反复请求。夜间自动监控已按约定结束，本次属于继续开发。
'''
instructions_text = '''方隅工作台：普通电脑受限内测版

本安装包约286MB，已包含账号列表读取修复、独立“多样化获客”入口，以及内容定位访谈和专家方法选择。完整业务与真实平台尚未全部验收，不作为完整商业成品发布。

原电脑已经更新下一次启动入口，关闭旧窗口后，从原桌面“方隅工作台”快捷方式重开即可；无需用本包重装。原账号、客户、回复和任务已核对保留。当前尚未取得本人重开后的界面确认。

电脑条件
64位Windows 10或11，需要可用的WebView2与.NET桌面环境。无需另装Python、不要求独立显卡、不捆绑本地大模型。缺少运行环境时会提示，不会自动下载。

安装与核对
优先在独立测试电脑使用。本包不含原电脑的客户名单、平台登录会话或凭据，首次使用需自己的企业员工账号与门店权限。已有客户实例不要直接覆盖；安装器区分客户程序目录，同名快捷方式指向其他程序或无法确认时会保留原快捷方式。

本轮通过包完整性、启动自检及自有目录解包检查，未完成本轮桌面首开、第二台实体电脑或真实员工和平台全流程验收。

内容运营支持资料、草稿、分步定位访谈、专家方法查找、人工采用、规则检查与内容包。自动内容生成服务尚未开启，原客户意向分析保持原方式。资料导入支持Word、PPT、文字PDF、纯文字与Markdown；扫描件识别和录音转写未完成。

视频功能使用已有素材与提供字幕，需要另行配套已核验的视频工具。缺少工具会提示不可用；不包含自动配音与AI视频生成。

内测包真实平台采集、自动发送和作品发布保持关闭。私信、直播、多账号定时执行等完整能力仍需补齐。不会自动回复、发私信或发布作品；本人扫码、人脸或验证码依赖保留断点。
'''
report.write_text(report_text, encoding='utf-8')
instructions.write_text(instructions_text, encoding='utf-8')
receipt = {'status': 'LIMITED_INTERNAL_DELIVERY_UPDATED_NOT_COMMERCIAL_ACCEPTANCE',
           'updatedAtUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'backups': backups, 'packageSha256': sha(package), 'packageBytes': package.stat().st_size,
           'reportSha256': sha(report), 'instructionsSha256': sha(instructions),
           'nativeWindowStarted': False, 'productionDataRestoredOrOverwritten': False,
           'fullGoalComplete': False, 'platformOrModelRequests': 0}
(D / 'PUBLIC-INTERNAL-DELIVERY.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(receipt, ensure_ascii=False))
