from pathlib import Path
import json,hashlib
W=Path(__file__).resolve().parent
R=W/'bound-readonly-snapshot'
assert not R.exists()
R.mkdir()
source=(W/'wait-for-readonly-snapshot/serve_ui.py').read_text('utf-8')
anchor="user=backend.core.session(cookie.split('=',1)[1]);user['_workbench_store_id']=store"
setup="""
 # Explicit synthetic read-only QA device context. No production grant or session.
 from types import SimpleNamespace
 from copy import deepcopy
 runtime=backend.platform_runtime;runtime.server._configure_bundled();runtime._platform_setup=True
 runtime.core.remote_safety_hold=False;runtime.core.employee_release_device_id='ui-readonly-qa-device';runtime.core.employee_release_until_monotonic=time.monotonic()+600
 saved={'state':'bound','environment_id':company['managedWorkspace']['environment_id'],'company_id':company['id'],'token':'synthetic-ui-token','device':{'id':'ui-readonly-qa-device','owner':user['username']}}
 runtime.service.vault=SimpleNamespace(read=lambda:deepcopy(saved));runtime.service.device=deepcopy(saved['device']);runtime.service.state='online'
"""
assert source.count(anchor)==1
source=source.replace(anchor,anchor+setup)
(R/'serve_ui.py').write_text(source,encoding='utf-8')
(R/'test_mode_ui.cjs').write_bytes((W/'wait-for-readonly-snapshot/test_mode_ui.cjs').read_bytes())
(R/'PREPARATION.json').write_text(json.dumps({'reason':'Previous original snapshot correctly prioritized unbound-device status; use explicit synthetic bound read-only QA context to exercise local-mode message. No product change.','syntheticBoundDeviceFixture':True,'naturalCloudGrant':False,'oldRedRetained':True,'derivedServerSha256':hashlib.sha256((R/'serve_ui.py').read_bytes()).hexdigest()},indent=2),encoding='utf-8')
print(str(R))
