# 独立审查范围

只读已封抖音六源、固定 shared-read-lease-qa-v3 七源，以及根云五源和 held ZIP。所有运行与输出在本目录；不改任何作者 sealed、根组合、安装版、本人数据、真实云或账号。

云源码及 ZIP 独审见 CLOUD-STATIC-AND-ZIP.json：五个变更与精确原 readback 相符，原 employeeRelease/commandHeld 字节保留，snapshot/readonly routes 字节不变；ZIP 的 5617 个实际成员均独立读出核大小与 SHA。新租约默认关闭，只由真实版本/协议/公司及原认证 owner/device 产生，不能授权远程命令或发送。

额外四组原 createService 测试见 CLOUD-EXTRA-RESULTS.json，只做十个请求：省略构造器配置保持关闭；请求自己声称的 owner/device 不替代认证设备；超过45秒后的 readonly snapshot 不续租、不更新 last_seen、不改变命令状态；远程账号连接和状态命令仍拒绝。没有重复作者43请求的全套测试，没有加载 SDK 或凭据，也未部署。

抖音代表链使用真实原 Native HTTP account_check 入口、原 Runtime/check_account、账号目的、Bridge/Node CLI 和完整 userscript 的自有 VM；随后调用正常 outer start/原 worker。新评论逐页模型分析留给根最终组合一次验收，本轮明确使用一条旧自有合成评论经原 importer 准备为已分析，验证去重跳过，不会调用模型。

首轮 minimal 的 STORE_REQUIRED 是测试未经过原 select_store 的正确拒绝，保留红证据；minimal2 通过原选门店动作再检查账号，不伪造 profile 或 observation，产品输入未变。

最终是否可合与未验范围以 FINAL-RECEIPT.json 为准。源码/sys.frozen 代表不等于实际主 EXE、Native WebView、本人自然登录、真实平台速度、部署云和第二台普通电脑验收。
