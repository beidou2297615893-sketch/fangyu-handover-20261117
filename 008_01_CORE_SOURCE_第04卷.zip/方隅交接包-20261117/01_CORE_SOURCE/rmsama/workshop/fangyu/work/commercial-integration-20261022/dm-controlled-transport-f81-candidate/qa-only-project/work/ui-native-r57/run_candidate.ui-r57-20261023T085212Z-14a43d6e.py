"""Fixed 方隅 UI release entry; no business App import."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import stat
import sys
sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
RELEASE = ROOT / 'releases/ui-r57-20261023T085212Z-14a43d6e'
MANIFEST_SHA256 = '04CF910F8AF3FE0C36C14ED7B57CF34D442FF471D8742C4CCEAB7B759665DFC8'
HOST_SHA256 = 'EC0D091DAAAAA64937F4483C4910C7DDAE6F6BD880B28C238E0B54400ED5F9AB'
LIFECYCLE_SHA256 = '2CD9EA245367B6D66E23D87642EA329E244A620D426B3A43D53EEEE4A2C20688'
_LIFECYCLE = None

def record(stage, error=None):
    try:
        if _LIFECYCLE is not None:
            _LIFECYCLE.record(stage, error=error)
    except Exception:
        pass

def diagnostics():
    global _LIFECYCLE
    if not LIFECYCLE_SHA256:
        return
    try:
        path = RELEASE / 'lifecycle_log.py'
        raw = pinned(path, LIFECYCLE_SHA256)
        name = 'fangyu_ui_lifecycle_log_' + hashlib.sha256(str(path.resolve()).encode()).hexdigest()[:16]
        child = sys.modules.get(name)
        if child is None:
            child = importlib.util.module_from_spec(importlib.util.spec_from_loader(name, loader=None))
            child.__file__ = str(path)
            sys.modules[name] = child
            exec(compile(raw, str(path), 'exec'), child.__dict__)
        _LIFECYCLE = child.LifecycleLog(ROOT / 'state', RELEASE.name)
        child.install_hooks(_LIFECYCLE)
    except Exception:
        _LIFECYCLE = None

def pinned(path, expected):
    for item in (path, *path.parents):
        info = item.lstat()
        if item.is_symlink() or getattr(info, 'st_file_attributes', 0) & 0x400:
            raise RuntimeError('界面启动路径不能是链接。')
    before = path.stat()
    if not stat.S_ISREG(before.st_mode) or before.st_nlink != 1:
        raise RuntimeError('界面启动文件无效。')
    raw = path.read_bytes()
    after = path.stat()
    if ((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns)
            != (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns)
            or hashlib.sha256(raw).hexdigest().upper() != expected):
        raise RuntimeError('界面版本校验失败，请恢复已固化版本。')
    return raw

def main():
    diagnostics()
    record('launcher_start')
    module = None
    try:
        pinned(RELEASE / 'RELEASE.json', MANIFEST_SHA256)
        record('manifest_verified')
        source = pinned(RELEASE / 'ui_native_host.py', HOST_SHA256)
        record('host_import_started')
        module = importlib.util.module_from_spec(importlib.util.spec_from_loader('fangyu_native_ui_host', loader=None))
        module.__file__ = str(RELEASE / 'ui_native_host.py')
        sys.modules[module.__name__] = module
        exec(compile(source, module.__file__, 'exec'), module.__dict__)
        record('host_imported')
        record('host_main_start')
        result = module.main(RELEASE, MANIFEST_SHA256, ROOT / 'state', project_root=ROOT.parent.parent)
        record('launcher_exit')
        return result
    except Exception as error:
        record('launcher_failed', error)
        if any(arg in sys.argv for arg in ('--check', '--self-test')):
            raise
        if module is not None and callable(getattr(module, 'notify_error', None)):
            module.notify_error(error)
            return 1
        raise

if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception as error:
        if any(arg in sys.argv for arg in ('--check', '--self-test')):
            print(json.dumps({'status': 'FAIL', 'error_type': type(error).__name__, 'message': '启动检查未通过，请查看启动记录。'}, ensure_ascii=False))
        elif os.name == 'nt':
            import ctypes
            ctypes.windll.user32.MessageBoxW(None, '界面未能启动，请查看本版本的启动状态。', '方隅工作台 · 打开提示', 0x10)
        raise SystemExit(1)
