const fs=require('fs'),path=require('path'),assert=require('assert');
const {chromium}=require('C:/Users/rmsama/.codex/skills/xhs-note-creator/node_modules/playwright-core');
const W=__dirname,info=JSON.parse(fs.readFileSync(path.join(W,'UI-SERVER.json'),'utf8'));
const browserPath='C:/Users/rmsama/AppData/Local/ms-playwright/chromium_headless_shell-1234/chrome-headless-shell-win64/chrome-headless-shell.exe';
const checks=[],requests=[],errors=[],external=[];let browser;
function record(name,data={}){checks.push({name,...data});fs.writeFileSync(path.join(W,'CHROMIUM-PROGRESS.json'),JSON.stringify({checks,requests,errors,external},null,2));}
(async()=>{
 browser=await chromium.launch({executablePath:browserPath,headless:true});
 const context=await browser.newContext({viewport:{width:1255,height:950},deviceScaleFactor:1});
 await context.route('**/*',route=>{const url=route.request().url();if(url.startsWith(info.origin+'/')||url.startsWith('data:')||url.startsWith('about:'))return route.continue();external.push(url);return route.abort();});
 await context.addCookies([{name:info.cookieName,value:info.cookieValue,url:info.origin,httpOnly:true,sameSite:'Strict'}]);
 const page=await context.newPage();page.on('pageerror',e=>errors.push(e.message));page.on('request',r=>{if(r.url().includes('/api/')){let body;try{body=r.postDataJSON();if(body?.data?.password)body.data.password='synthetic password omitted';}catch{}requests.push({method:r.method(),url:r.url(),body});}});
 await page.goto(info.origin+'/#diversified');
 await page.waitForFunction(()=>document.body.dataset.page==='diversified');
 const frame=page.frames().find(f=>f.url().includes('/canvas.html'));assert(frame,'Original outer fit iframe required');
 await frame.locator('[data-page-diversified]').waitFor();
 const nav=await frame.locator('.side-nav [data-nav]').evaluateAll(nodes=>nodes.map(n=>({page:n.dataset.nav,text:n.textContent.trim(),current:n.getAttribute('aria-current')})));
 assert.equal(nav[nav.findIndex(n=>n.page==='acquire')+1].page,'diversified');assert.equal(nav.find(n=>n.page==='diversified').current,'page');
 assert.equal(await frame.locator('h1').first().innerText(),'多样化获客');assert((await frame.title()).includes('多样化获客'));
 record('Original full app/fit iframe bootstraps authenticated Native session and distinct nav/title/hash/body route',{nav});
 await frame.locator('[data-diverse-kind="profiles"]').click();
 await frame.locator('#as-account option[value="diverse-fixture-account-0"]').waitFor({state:'attached'});
 assert.deepEqual(await frame.locator('[data-as-kind]').evaluateAll(n=>n.map(x=>x.dataset.asKind)),['note_links','profiles','own_interactions']);
 assert.equal(await frame.locator('#as-account option').count(),3);
 await frame.locator('#as-account').selectOption('diverse-fixture-account-0');
 await frame.locator('#as-links').fill('https://www.xiaohongshu.com/user/profile/0123456789abcdef01234567');
 await frame.locator('[data-as-preview]').click();await frame.waitForFunction(()=>!document.querySelector('#modal .modal-confirm')?.disabled);
 await frame.locator('#modal .modal-confirm').click();await frame.locator('#modal').waitFor({state:'hidden'});
 assert.equal(await frame.locator('.da-next h2').innerText(),'博主主页');assert((await frame.locator('.da-next').innerText()).includes('合成平台账号0'));
 record('Original Native source preview and modal explicit apply select profile/account draft; no collection on apply');
 await frame.locator('[data-nav="acquire"]').click();
 await frame.locator('[data-keyword-account]').waitFor();assert((await frame.locator('.da-keyword-source').innerText()).includes('合成平台账号0'));
 await frame.locator('[data-keyword-account]').click();assert.deepEqual(await frame.locator('[data-as-kind]').evaluateAll(n=>n.map(x=>x.dataset.asKind)),['keywords']);
 await frame.locator('#as-account').selectOption('diverse-fixture-account-1');await frame.locator('#modal .modal-confirm').click();await frame.locator('#modal').waitFor({state:'hidden'});
 assert((await frame.locator('.da-keyword-source').innerText()).includes('合成平台账号1'));
 record('Keyword route retains visible current/next account names and original account modal constrained to keywords; only explicit Apply changes draft account');
 await frame.locator('[data-nav="diversified"]').click();assert.equal(await frame.locator('.da-next h2').innerText(),'尚未选择');
 assert(await frame.locator('[data-diverse-start]').isDisabled());
 record('Return navigation does not silently restore profile or use old task source; separate explicit source selection required');
 const beforePoll=requests.filter(r=>r.url.includes('/api/workbench/platform')).length;
 await page.waitForTimeout(3900);assert(requests.filter(r=>r.url.includes('/api/workbench/platform')).length>beforePoll);
 record('Diversified route joins original scoped read polling without starting a task');
 for(const width of [1255,390]){
  await page.setViewportSize({width,height:950});await page.waitForTimeout(250);
  const outer=await page.evaluate(()=>({width:innerWidth,scroll:document.documentElement.scrollWidth,frameWidth:document.querySelector('iframe').getBoundingClientRect().width,scale:Number(document.body.dataset.scale)}));
  const inner=await frame.evaluate(()=>({width:innerWidth,scroll:document.documentElement.scrollWidth,bodyWidth:document.body.getBoundingClientRect().width,headingFont:parseFloat(getComputedStyle(document.querySelector('.da-choices h2')).fontSize),copyFont:parseFloat(getComputedStyle(document.querySelector('.da-kind-grid span')).fontSize),cards:[...document.querySelectorAll('[data-diverse-kind]')].map(n=>({width:n.getBoundingClientRect().width,right:n.getBoundingClientRect().right})),active:document.body.dataset.page}));
  assert(outer.scroll<=width+1,JSON.stringify({outer,inner}));assert(inner.scroll<=inner.width+1,JSON.stringify({outer,inner}));assert(inner.copyFont*outer.scale>=14,JSON.stringify({outer,inner}));
  await page.screenshot({path:path.join(W,`diversified-${width}.png`),fullPage:true});record('Real headless original fit/layout width '+width,{outer,inner,effectiveCopyPixels:inner.copyFont*outer.scale});
 }
 await page.setViewportSize({width:1255,height:950});
 // Exercise new page bindings with controlled UI-only ready states. These calls never reach Native/platform.
 const bindings=await frame.evaluate(async()=>{
  const mod=await import('/web/pages/diversified-acquisition.mjs'.replace('/web/','/'));
  const actor=JSON.stringify([location.origin,'synthetic-tenant','ui-operator','operator','ui-store','xiaohongshu']);
  const make=()=>({page:'acquire',authEpoch:7,connection:'connected',session:{user:{username:'ui-operator',tenant_id:'synthetic-tenant',role:'operator'}},user:'ui-operator',storeId:'ui-store',store:'合成门店',stores:[{id:'ui-store',name:'合成门店',city:'上海',region:'上海'}],selection:{revision:1,applied:{excludeTerms:[],selectedKeywords:['租房']}},activePlatform:'xiaohongshu',platformAccountSelections:{xiaohongshu:'a'},acquire:{region:'上海',time:'最近30天',sourceSelection:{actor,accountId:'a',source:{kind:'profiles',profiles:['0123456789abcdef01234567']},commentWindow:{mode:'all'},execution:{mode:'once'},previewDigest:'a'.repeat(64),preview:{canStart:true,sourceCount:1}}},platform:{actor:{username:'ui-operator',storeId:'ui-store'},accounts:[{id:'a',name:'合成账号A',platform:'xiaohongshu',status:'ready'},{id:'b',name:'合成账号B',platform:'xiaohongshu',status:'ready'}],platforms:[{id:'xiaohongshu',enabled:true,accountId:'a'}],capabilities:{timeRanges:['最近30天']},acquisition:{status:'idle',canStart:true,counts:{}}}});
  const host=document.createElement('div');host.id='binding-only-fixture';document.body.append(host);const observations=[];
  function setup(state,module){let modal,calls=[];const ctx={state,actions:{startAcquisition:options=>{calls.push(options);return true;},hasUnconfirmed:()=>false},toast:()=>{},modal:v=>{modal=v;},update:fn=>fn(state),navigate:()=>{}};host.innerHTML=module.render(state);const cleanup=module.bind(host,ctx);return {ctx,calls,modal:()=>modal,cleanup};}
  let s=make(),x=setup(s,mod.keywordPage);assert(s.acquire.sourceSelection.source.kind==='profiles');host.querySelector('[data-acquire-start]').click();assert(x.calls.length===0&&x.modal());x.modal().onConfirm();assert(s.acquire.sourceSelection.source===null&&x.calls.length===1&&x.calls[0].sourceKind==='keywords');x.cleanup?.();observations.push('keyword render does not alter original selected source; explicit confirmation changes to keywords and invokes original start once');
  s=make();x=setup(s,mod.keywordPage);host.querySelector('[data-acquire-start]').click();s.platformAccountSelections.xiaohongshu='b';assert(x.modal().onConfirm()===false&&x.calls.length===0&&s.acquire.sourceSelection.source.kind==='profiles');x.cleanup?.();observations.push('account change while keyword confirmation is open rejects stale confirmation with zero call');
  s=make();s.page='diversified';x=setup(s,mod);assert(host.querySelector('[data-diverse-start]').disabled);x.cleanup?.();observations.push('old profile selection without this-page marker cannot start in diversified route');
  s=make();s.page='diversified';Object.assign(s.acquire.sourceSelection,{selectedFor:'diversified',selectedAuthEpoch:7});x=setup(s,mod);host.querySelector('[data-diverse-start]').click();assert(x.calls.length===0&&x.modal());s.acquisitionAttempt={unconfirmed:true};assert(x.modal().onConfirm()===false&&x.calls.length===0);x.cleanup?.();observations.push('unknown arriving during explicit diversified confirmation prevents start and retains original selection');
  s=make();s.page='diversified';Object.assign(s.acquire.sourceSelection,{selectedFor:'diversified',selectedAuthEpoch:6});x=setup(s,mod);assert(host.querySelector('[data-diverse-start]').disabled);x.cleanup?.();observations.push('expired auth epoch cannot reuse prior explicit source selection');
  host.remove();return observations;
  function assert(value){if(!value)throw new Error('UI binding assertion failed');}
 });record('Controlled Chromium binding guards; synthetic callbacks only',{bindings});
 const empty=await browser.newContext({viewport:{width:1255,height:950}});await empty.route('**/*',r=>r.request().url().startsWith(info.origin+'/')?r.continue():r.abort());const unauth=await empty.newPage();await unauth.goto(info.origin+'/#diversified');await unauth.waitForFunction(()=>document.body.dataset.page==='login');await empty.close();record('Direct diversified hash requires original authenticated session; unauthenticated route returns login');
 assert.equal(requests.filter(r=>['acquisition_start','acquisition_resume','account_connect','account_create'].includes(r.body?.action)).length,0);assert.deepEqual(errors,[]);assert.deepEqual(external,[]);
 fs.writeFileSync(path.join(W,'CHROMIUM-RESULTS.json'),JSON.stringify({status:'PASS',checks,requests,pageErrors:errors,externalRequests:external,actualFullNativeHttpAndOriginalFitShell:true,controlledBindingCasesSeparate:true,realPlatformModelCalls:0,headlessDevelopmentOnly:true},null,2));console.log(JSON.stringify({status:'PASS',groups:checks.length}));
})().catch(e=>{fs.writeFileSync(path.join(W,'CHROMIUM-FAILURE.json'),JSON.stringify({error:e.stack,checks,requests,errors,external},null,2));throw e;}).finally(async()=>{await browser?.close();fs.writeFileSync(path.join(W,'STOP-UI-SERVER'),'owned fixture done');});
