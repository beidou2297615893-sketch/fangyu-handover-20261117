from pathlib import Path
import hashlib,json,sqlite3
W=Path(__file__).resolve().parent;O=W/'factory-3ba5204269af4e8eb2ad2e64746cdae3';dbpath=O/'data/workspace.sqlite3'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();before=sha(dbpath)
with sqlite3.connect(dbpath.as_uri()+'?mode=ro',uri=True) as db:
 db.execute('PRAGMA query_only=ON')
 claims=[json.loads(r[0]) for r in db.execute('SELECT body FROM records WHERE entity=?',('ui_customer_reply_guard_v1',))]
 accounts=[json.loads(r[0]) for r in db.execute('SELECT body FROM records WHERE entity=?',('accounts',))]
assert sha(dbpath)==before
assert len(claims)==1 and claims[0]['state']=='unknown'
e=json.loads((O/'UNKNOWN-ACCOUNT-DELETE.json').read_text('utf-8'))
assert e['deleteStatus']==200 and e['deleteBody']['accountDeletion']['state']=='deleted' and e['requestReadStatus']==403
assert not any(a['id']=='dm-fixture-account-0' for a in accounts)
report={'readOnly':True,'pragmaQueryOnly':True,'databaseShaBeforeAfter':before,'actualOriginalClaimEntity':'ui_customer_reply_guard_v1','durableClaimAfterDelete':claims,'captureLimitation':'Original capture() accidentally included an unused reply_customer_claims_v1 entity. Actual original claim is now read from ui_customer_reply_guard_v1 in query-only SQLite. Cross-account denial before deletion and durable unknown after deletion are proved; exact before/after claim byte equality was not captured and is not claimed.','unknownQueueDraftRequestCommentRowsBeforeAfterEqual':e['allCapturedDmAndCustomerRowsUnchanged'],'noAdditionalHttpOrDispatch':True}
(W/'CLAIM-READONLY-SUPPLEMENT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps({'claimCount':len(claims),'state':claims[0]['state'],'originalClaimUnchangedBytes':'not captured','dbReadOnlyShaStable':True},ensure_ascii=False))
