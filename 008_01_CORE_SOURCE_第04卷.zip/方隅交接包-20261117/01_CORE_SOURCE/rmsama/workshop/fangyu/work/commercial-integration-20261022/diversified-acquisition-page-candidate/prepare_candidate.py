from pathlib import Path
import difflib,hashlib,json,shutil,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=W.parents[2];S=P/'work/parallel-integration-20261018/final-integration/stage-02/project';rel=Path('work/ui-approved-implementation/ui-preview');UI=S/rel
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
names=['app.mjs','pages/acquisition-source.mjs','viewport-layout.mjs','canvas.html']
base={};diff=[]
def edit(name,replacements):
    source=UI/name;raw=source.read_bytes();text=raw.decode('utf-8');nl='\r\n' if b'\r\n' in raw else '\n'
    for old,new in replacements:
        old=old.replace('\n',nl);new=new.replace('\n',nl);assert text.count(old)==1,(name,old);text=text.replace(old,new)
    target=W/'candidate'/rel/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(text.encode('utf-8'))
    base[name]={'beforeSha256':sha(source),'sha256':sha(target),'beforeBytes':len(raw),'bytes':target.stat().st_size,'CRLFPreserved':(b'\r\n' in raw)==(b'\r\n' in target.read_bytes())}
    diff.extend(difflib.unified_diff(raw.decode('utf-8').splitlines(True),text.splitlines(True),fromfile='base/'+str(rel/name),tofile='candidate/'+str(rel/name)))
edit('app.mjs',[
 ("import * as acquire from './pages/acquire.mjs';","import * as acquire from './pages/acquire.mjs';\nimport * as diversifiedAcquisition from './pages/diversified-acquisition.mjs';"),
 ("const pages={acquire,presets,", "const pages={acquire:diversifiedAcquisition.keywordPage,diversified:diversifiedAcquisition,presets,"),
 ("const titles={content:","const titles={diversified:['多样化获客','从指定来源发现真实租房需求'],content:"),
 ("state.page=page;if(location.hash", "if(state.page!==page&&(state.page==='diversified'||page==='diversified'))document.getElementById('modal')?.close();state.page=page;document.title=(titles[page]?.[0]||'员工登录')+' · 方隅工作台';if(location.hash"),
 ("['accounts','acquire','content'].includes(state.page)","['accounts','acquire','diversified','content'].includes(state.page)"),
 ("${navButton('acquire','获客','approved-icon-search.svg')}${navButton('reply'", "${navButton('acquire','获客','approved-icon-search.svg')}${navButton('diversified','多样化获客','icon-message-square-more.svg')}${navButton('reply'")])
# Source changes are kept explicit below, to preserve every original save/receipt path.
edit('pages/acquisition-source.mjs',[
 ("export function renderSourceBar(s,locked=false){", "export function renderSourceBar(s,locked=false){\n  if(s.page==='acquire'){const selected=sourceSelection(s),rows=accounts(s),task=s.platform?.acquisition?.taskScope;const id=s.platformAccountSelections?.[s.activePlatform||'xiaohongshu']||selected?.accountId||s.platform?.platforms?.find(p=>p.id===(s.activePlatform||'xiaohongshu'))?.accountId;const next=rows.find(a=>a.id===id),current=rows.find(a=>a.id===task?.accountId);return `<div class=\"as-source-bar da-keyword-source\"><div><strong>关键词搜索</strong><span class=\"as-account-name\">下次采集账号 <b>${esc(senderName(next))}</b></span>${current?`<span class=\"as-account-name\">当前任务账号 <b>${esc(senderName(current))}</b></span>`:''}</div><div><button type=\"button\" data-keyword-account ${locked?'disabled':''}>选择关键词采集账号</button><button type=\"button\" data-diversified-nav>多样化获客 →</button></div></div>`;}"),
 ("export function bindSourceBar(root,ctx){", "export function bindSourceBar(root,ctx){root.querySelector('[data-keyword-account]')?.addEventListener('click',()=>openAcquisitionSources(ctx,{kinds:['keywords'],initialKind:'keywords',expectedPage:'acquire',selectionContext:{selectedFor:'acquire',selectedAuthEpoch:ctx.state.authEpoch||0}}));root.querySelector('[data-diversified-nav]')?.addEventListener('click',()=>ctx.navigate('diversified'));"),
 ("export function openAcquisitionSources(ctx){", "export function openAcquisitionSources(ctx,options={}){"),
 ("  s.acquisitionSourceUI=u;sourceForms.set(actor,u);", "  const allowed=Array.isArray(options.kinds)?options.kinds.filter(k=>labels[k]&&k!=='preset'):Object.keys(labels).filter(k=>k!=='preset');\n  if(options.initialKind&&allowed.includes(options.initialKind)&&u.kind!==options.initialKind){u.kind=options.initialKind;u.preview=null;u.message='';}\n  if(!allowed.includes(u.kind)&&u.kind!=='preset'){u.kind=allowed[0]||'keywords';u.preview=null;}\n  s.acquisitionSourceUI=u;sourceForms.set(actor,u);"),
 ("const valid=()=>identity(s)===actor&&s.acquisitionSourceUI===u&&Boolean(s.session);", "const expectedEpoch=s.authEpoch||0;\n  const valid=()=>identity(s)===actor&&s.acquisitionSourceUI===u&&Boolean(s.session)&&(s.authEpoch||0)===expectedEpoch&&(!options.expectedPage||s.page===options.expectedPage);"),
 ("state.acquire.sourceSelection={actor,accountId:","state.acquire.sourceSelection={actor,...(options.selectionContext||{}),accountId:"),
 ("Object.entries(labels).filter(([k])=>k!=='preset').map", "Object.entries(labels).filter(([k])=>allowed.includes(k)).map"),
 ("来源已应用，可在获客页明确开始。", "来源已应用，请在当前页面明确开始。")])
edit('viewport-layout.mjs',[("acquire:[1585,992],","acquire:[1585,992],diversified:[1585,992],")])
edit('canvas.html',[("</head>",'<link rel="stylesheet" href="/pages/diversified-acquisition.css"></head>')])
for name in ('pages/diversified-acquisition.mjs','pages/diversified-acquisition.css'):
    target=W/'candidate'/rel/name;base[name]={'beforeSha256':None,'sha256':sha(target),'bytes':target.stat().st_size}
    diff.extend(difflib.unified_diff([],target.read_text('utf-8').splitlines(True),fromfile='/dev/null',tofile='candidate/'+str(rel/name)))
(W/'BASE-AND-CANDIDATE-PINS.json').write_text(json.dumps({'scope':'UI only, original startAcquisition and acquire.mjs unchanged','sourceRoot':str(S),'files':{(rel/name).as_posix():v for name,v in base.items()},'originalAcquireSha256':sha(UI/'pages/acquire.mjs')},ensure_ascii=False,indent=2),'utf-8')
(W/'CHANGES.patch').write_text(''.join(diff),encoding='utf-8',newline='')
print(json.dumps({'status':'CANDIDATE_READY','files':len(base),'originalAcquireSha256':sha(UI/'pages/acquire.mjs')}))
