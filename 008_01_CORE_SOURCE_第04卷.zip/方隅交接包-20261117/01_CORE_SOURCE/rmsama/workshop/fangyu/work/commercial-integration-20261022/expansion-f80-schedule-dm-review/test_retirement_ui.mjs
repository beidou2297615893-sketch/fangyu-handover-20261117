import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';import {createRequire} from 'node:module';
const require=createRequire(import.meta.url),{chromium}=require('C:/Users/rmsama/.codex/skills/xhs-note-creator/node_modules/playwright-core');
const W=path.dirname(fileURLToPath(import.meta.url)),info=JSON.parse(fs.readFileSync(path.join(W,'UI-SERVER.json'),'utf8')),out=info.directory,checks=[],http=[],errors=[],metrics=[];
const browser=await chromium.launch({headless:true,executablePath:'C:/Users/rmsama/AppData/Local/ms-playwright/chromium_headless_shell-1234/chrome-headless-shell-win64/chrome-headless-shell.exe'}),page=await browser.newPage({viewport:{width:1255,height:1100}}),frame=page.frameLocator('#workspace-frame');let passed=false;
const check=(v,label)=>{if(!v)throw Error(label);checks.push(label);};
page.on('pageerror',e=>errors.push(String(e)));await page.route('**/*',r=>new URL(r.request().url()).hostname==='127.0.0.1'?r.continue():r.abort());
page.on('response',async r=>{try{const d=r.request().postDataJSON();if(r.request().method()==='POST'&&d?.action?.startsWith('dm_'))http.push({action:d.action,data:d.data,status:r.status(),body:await r.json()});}catch{}});
// Rehydrate an original pending operation. Actor epochs are fixture UI state,
// not an identity override: the real original login establishes the employee.
await page.addInitScript(data=>{for(let epoch=0;epoch<8;epoch++){const actor=`${epoch}|${data.username}|${data.storeId}|douyin`;localStorage.setItem('fangyu-dm-request-v1:'+actor,JSON.stringify({actor,action:'dm_queue_start',requestId:data.requestId,accountId:data.retiredAccountId}));}},info);
try{
 await page.goto(info.origin);await frame.locator('#login-name').fill(info.username);await frame.locator('#login-pass').fill(info.password);await frame.locator('.login-submit').click();await frame.locator('[data-nav="reply"]').waitFor();
 if(await frame.locator('#work-store-choice').count()){const values=await frame.locator('#work-store-choice').evaluate(e=>[...e.options].map(o=>o.value).filter(Boolean));await frame.locator('#work-store-choice').selectOption(values[0]);await frame.locator('#modal .modal-confirm').click();}
 await frame.locator('[data-switch-platform="douyin"]').click();await frame.locator('[data-nav="reply"]').click();await frame.locator('[data-reply-channel="dm"]').click();
 const warning=frame.locator('.dm-warn');await warning.getByText('账号已从软件移除，原私信结果待核对；只能查询原编号，不会再次发送。',{exact:false}).waitFor();
 check((await warning.textContent()).includes('账号已从软件移除')&&(await warning.textContent()).includes('原私信结果待核对'),'Original render shows retired account and unknown result accurately');
 const button=frame.locator('[data-dm-recover]');check((await button.textContent()).includes('继续核对已移除账号'),'Original pending retains explicit original-result lookup button');
 const retired=frame.locator('[data-dm-retired-result]');check((await retired.textContent()).includes(info.requestId)&&(await retired.textContent()).includes('已移除账号的原结果')&&(await retired.textContent()).includes('独审未知回执原请求'),'Read-only original account card displays original key and original unknown item');
 check(await retired.locator('[data-dm-send-queue],[data-dm-listen],[data-dm-save]').count()===0,'Retired original card has no mutation or execution action');
 check(await frame.locator('[data-dm-account]').isEnabled(),'Retired result does not permanently block another current account');
 const snapshot=()=>http.filter(x=>x.action==='dm_request_read');
 for(let n=0;n<2;n++){const response=page.waitForResponse(r=>{try{return r.request().postDataJSON()?.action==='dm_request_read'}catch{return false}});await button.click();const r=await response;check(r.status()===200,'Repeat original-key lookup accepted '+n);await button.waitFor({state:'visible'});await page.waitForTimeout(100);}
 check(snapshot().length>=3&&snapshot().every(x=>x.data.requestId===info.requestId&&x.data.action==='dm_queue_start'&&!('accountId'in x.data)),'Every lookup keeps same original request and never borrows another account parameter');
 check(snapshot().every(x=>x.body.dmWorkspace?.accountId===info.retiredAccountId&&x.body.dmWorkspace?.accountRemoved===true&&x.body.dmWorkspace?.state==='unknown'),'Every receipt remains bound to the removed original account');
 check(http.every(x=>!['dm_queue_start','dm_listen_start','dm_draft_save','dm_draft_review','dm_queue_prepare'].includes(x.action)),'Opening/recovering never starts listener, generation, draft mutation or send');
 const stored=await page.evaluate(key=>Object.entries(localStorage).filter(([k])=>k.startsWith('fangyu-dm-request-v1:')).map(([k,v])=>({key:k,value:JSON.parse(v)})).filter(x=>x.value.requestId===key),info.requestId);
 check(stored.length>0&&stored.every(x=>x.value.accountId===info.retiredAccountId),'Pending original request persists for later queries');
 check(stored.some(x=>x.key.endsWith(':retired')),'Original key persists separately as a read-only retired query without blocking new draft operations');
 for(const width of [1255,390]){
  await page.setViewportSize({width,height:1000});await warning.scrollIntoViewIfNeeded();
  const outer=await page.evaluate(()=>{let scale=1;for(let e=document.querySelector('#workspace-frame');e;e=e.parentElement){const s=getComputedStyle(e);if(s.transform!=='none'){const m=new DOMMatrix(s.transform);scale*=Math.hypot(m.c,m.d);}const z=parseFloat(s.zoom);if(Number.isFinite(z)&&z>0)scale*=z;}return {scale,width:innerWidth,scroll:document.documentElement.scrollWidth};});
  const inner=await warning.evaluate((e,outerScale)=>{const c=getComputedStyle(e);let scale=outerScale;for(let a=e;a;a=a.parentElement){const s=getComputedStyle(a);if(s.transform!=='none'){const m=new DOMMatrix(s.transform);scale*=Math.hypot(m.c,m.d);}const z=parseFloat(s.zoom);if(Number.isFinite(z)&&z>0)scale*=z;}return {fontPx:parseFloat(c.fontSize),effectivePx:parseFloat(c.fontSize)*scale,width:e.clientWidth,scroll:e.scrollWidth,text:e.textContent,innerWidth,innerScroll:document.documentElement.scrollWidth};},outer.scale);
  metrics.push({width,outer,inner});check(inner.effectivePx>=14&&inner.scroll<=inner.width+1&&outer.scroll<=outer.width+1,'Original fit retired-result text readable without horizontal overflow '+width);
  await page.screenshot({path:path.join(out,'retirement-'+width+'.png')});
 }
 check(errors.length===0,'No Chromium module/runtime errors');passed=true;
}catch(error){fs.writeFileSync(path.join(out,'UI-ERROR.json'),JSON.stringify({error:String(error),checks,http,errors,metrics},null,2));await page.screenshot({path:path.join(out,'UI-ERROR.png')});throw error;}
finally{fs.writeFileSync(path.join(out,'UI-RESULTS.json'),JSON.stringify({status:passed?'PASS':'RED_CAPTURED',checks,http,errors,metrics,actualOriginalIndexFitIframe:true,originalFactoryHttp:true,developmentHeadless:true,realPlatformModelCalls:0},null,2));await browser.close();fs.writeFileSync(info.stop,'stop own fixture');}
console.log(JSON.stringify({status:'PASS',checks:checks.length,directory:out}));
