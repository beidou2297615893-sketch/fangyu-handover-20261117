from pathlib import Path
import hashlib,json,ast
W=Path(__file__).resolve().parent;P=W.parents[2]
F=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v79';S=F/'project';D=W/'final-source';Q=W/'qa-only-project'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text('utf-8-sig'))
pins=read(W/'SOURCE-PINS.json');old=read(W.parent/'dm-product-integration-candidate/SOURCE-PINS.json');oldmap={r['path']:r for r in old['files']}
inverse=[]
def remove(text,needle):
    assert text.count(needle)==1,(needle[:90],text.count(needle));return text.replace(needle,'',1)
def between(text,left,right):
    assert text.count(left)==text.count(right)==1
    start=text.index(left);end=text.index(right,start);return text[:start]+text[end:]
for row in pins['files']:
    rel=row['path'];body=(D/rel).read_bytes();assert sha(D/rel)==row['after']['sha256']
    assert (Q/rel).read_bytes()==body
    if row['change']=='added':
        assert sha(D/rel)==oldmap[rel]['after']['sha256'],rel
        continue
    original=(S/rel).read_bytes();text=body.decode('utf-8');nl='\r\n' if b'\r\n' in original else '\n'
    if rel.endswith('/app.mjs'):
        text=remove(text,'dmAction:(action,data)=>backend.dmAction(action,data),')
    elif rel.endswith('/backend.mjs'):
        text=remove(text,"const DM_ACTIONS=new Set('dm_workspace_read dm_listen_start dm_listen_stop dm_request_read dm_draft_save dm_draft_review dm_queue_prepare dm_queue_start dm_queue_cancel dm_queue_read'.split(' '));"+nl)
        text=remove(text,'DM_ACTIONS.has(action)||')
        text=remove(text,"['dm_workspace_read','dm_request_read','dm_queue_read'].includes(action)||")
        text=remove(text,"dmAction:(action,data)=>{if(!DM_ACTIONS.has(action))throw new WorkbenchError('私信操作无效','INPUT_INVALID');return request(action,data);},")
    elif rel.endswith('/platform_runtime.py'):
        text=between(text,'    def dm_guard(self,user,account_id,*,for_send=False):','    def reply_guard(self,user,account_id):')
    elif rel.endswith('/workbench_backend.py'):
        text=between(text,'DM_ACTIONS = frozenset(','REPLY_ACTIONS = frozenset(')
        text=remove(text,', dm_factory=None')
        text=remove(text,'        self.dm_workbench = (dm_factory(self.core,self.platform_runtime,self.reply_workbench,self.reply_delivery) if dm_factory else None)'+nl)
        text=remove(text,'            if self.dm_workbench is not None:self.dm_workbench.close()'+nl)
        text=between(text,'        if action in DM_ACTIONS:','        if action in INTERACTION_ACTIONS:')
    elif rel.endswith('/ui_native_host.py'):
        old="'reply_delivery.py','dm_workbench.py'))):";assert text.count(old)==1
        text=text.replace(old,"'reply_delivery.py'))):",1)
        old="'reply_delivery.py','dm_workbench.py',";assert text.count(old)==1
        text=text.replace(old,"'reply_delivery.py',",1)
        text=remove(text," | frozenset(('dm_workspace_read','dm_listen_start','dm_listen_stop','dm_request_read','dm_draft_save','dm_draft_review','dm_queue_prepare','dm_queue_start','dm_queue_cancel','dm_queue_read'))")
        text=between(text,"    dm_entry=files.get('dm_workbench.py')","    platform_entry = files.get('resources/platform-runtime/platform_runtime.py')")
    elif rel.endswith('/freeze_ui.py'):
        text=remove(text,"    copy_public(HERE / 'dm_workbench.py', release / 'dm_workbench.py')"+nl)
    elif rel.endswith('/core/engine.py'):
        text=remove(text,"        used+=sum(1 for r in self.store.list('ui_dm_drafts_v1',tenant) if r.get('attempted_by')==user['id'] and r.get('state') in ('sending','sent','unknown') and r.get('attempted_at','').startswith(today))"+nl)
        text=remove(text,"        sent+=sum(1 for r in self.store.list('ui_dm_drafts_v1',tenant) if r.get('account_id')==account['id'] and r.get('state') in ('sending','sent','unknown') and r.get('attempted_at','').startswith(today))"+nl)
    elif rel.endswith('/core/adapters.py'):
        text=remove(text,'        self._dm_calls=threading.local()'+nl)
        text=remove(text,"        guard=getattr(self._dm_calls,'guard',None)"+nl+'        if guard is not None:guard()'+nl)
        text=between(text,'    def direct_messages(self,account,operation,request_id,directory,**kwargs):','    def send(self,platform,lead,text,account_dir):')
    elif rel.endswith('/pages/reply.mjs'):
        assert body==(W.parent/'dm-product-integration-candidate/final-source'/rel).read_bytes()
        # No F78/79 edits ever touched this original reply page. It remains
        # exactly the formerly sealed DM tab composition.
        inverse.append({'path':rel,'oldSealedDmUnchanged':True,'baselineSha256':sha(S/rel)});continue
    else:raise AssertionError(rel)
    assert text.encode('utf-8')==original,rel
    inverse.append({'path':rel,'byteExactInverseTo79':True,'baselineSha256':sha(S/rel)})
protected=['work/ui-approved-implementation/ui-preview/pages/diversified-acquisition.mjs','work/ui-approved-implementation/ui-preview/pages/acquire.mjs','work/ui-approved-implementation/ui-preview/pages/fresh-acquisition-recovery.mjs','work/ui-approved-implementation/ui-preview/pages/accounts.mjs','work/ui-approved-implementation/ui-preview/platform-notice.mjs','work/shared-backend-integration/vendor-src/assistant/service.py','work/shared-backend-integration/vendor-src/assistant/business.py','work/ui-runtime-r55/src/core/store.py','work/ui-runtime-r55/src/core/continuous.py','work/app/company.json','work/ui-native-r57/reply_delivery.py','work/ui-native-r57/reply_workbench.py']
for rel in protected:assert (Q/rel).read_bytes()==(S/rel).read_bytes(),rel
sourceMap={r['path']:r for r in read(F/'UNIFIED-PINS.json')['files']}
stage=read(W/'QA-STAGE-PINS.json')['stage'];release=Path(stage['release']);manifest=read(release/'RELEASE.json');rm={r['path']:r for r in manifest['files']}
assert len(rm)==276 and sha(release/'RELEASE.json')==stage['manifest_sha256'].lower()
assert {p.relative_to(release).as_posix() for p in release.rglob('*') if p.is_file()}==set(rm)|{'RELEASE.json'}
for rel,row in rm.items():assert sha(release/rel)==row['sha256'].lower() and (release/rel).stat().st_size==row['size'],rel
assert (release/'dm_workbench.py').read_bytes()==(D/'work/ui-native-r57/dm_workbench.py').read_bytes()
native=ast.parse((D/'work/ui-native-r57/ui_native_host.py').read_bytes());baseNative=ast.parse((S/'work/ui-native-r57/ui_native_host.py').read_bytes())
functions=lambda t:{n.name:ast.dump(n,include_attributes=False) for n in t.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
a,b=functions(baseNative),functions(native);assert {k for k in a if a[k]!=b[k]}=={'verify_release','create_backend'}
dm=ast.parse((D/'work/ui-runtime-r55/src/core/dm_transport.py').read_bytes());transportPins=ast.literal_eval(next(n.value for n in dm.body if isinstance(n,ast.Assign) and n.targets[0].id=='PINS'))
for rel,pin in transportPins.items():assert sha(Q/'work/ui-runtime-r55/work/runtime/douyin-bridge'/rel)==pin
result={'status':'PASS_F79_HUNK_MERGE_PRESERVES_PRIOR_LIFECYCLE_AND_GUARDS','inverseProof':inverse,'newFiveFilesExactPriorDmSeal':True,'protectedUnchanged':[{'path':r,'sha256':sha(S/r)} for r in protected],'originalNativeCacheAndSourceGuardFunctionsUnchanged':True,'sourceFiles':14,'qaResources':276,'qaReleaseSha256':sha(release/'RELEASE.json'),'transportPins':transportPins,'sourceOnlyTreeContainsNoQaData':True,'closureIsOwnedQaStageNotFormalRelease':True,'noNewPipNpmDependencies':True,'needsNormalFreezeAndStandardClosedSetValidationBeforeDelivery':True,'productionAccess':False}
(W/'PRESERVATION-AND-CLOSURE.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),'utf-8')
print(json.dumps({'status':result['status'],'inverseFiles':len(inverse),'protectedFiles':len(protected),'qaResources':len(rm)}))
