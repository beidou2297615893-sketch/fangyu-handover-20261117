"""Read only persisted task/page metadata; no auth/session/credential table reads."""
from pathlib import Path
import ast,hashlib,json,sqlite3,re
from copy import deepcopy
from datetime import datetime
P=Path('C:/积木软件工坊/项目/方隅公寓客户版');D=Path(__file__).resolve().parent
binding=json.loads((P/'work/ui-native-r57/state/production-workspace.json').read_text('utf-8-sig'))
source=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v74/project/work/shared-backend-integration/platform_runtime.py'
tree=ast.parse(source.read_bytes());runtime=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='PlatformRuntime')
methods=[n for n in runtime.body if isinstance(n,ast.FunctionDef) and n.name in ('_collection_binding','_task_scope')];assert len(methods)==2
probe=ast.Module(body=[ast.ClassDef(name='BindingProbe',bases=[],keywords=[],body=methods,decorator_list=[])],type_ignores=[])
namespace={'hashlib':hashlib,'json':json,'deepcopy':deepcopy,'datetime':datetime,'re':re};exec(compile(ast.fix_missing_locations(probe),'<exact read-only binding methods>','exec'),namespace)
db=sqlite3.connect((Path(binding['data_dir'])/'workspace.sqlite3').as_uri()+'?mode=ro',uri=True);db.execute('PRAGMA query_only=ON');db.execute('BEGIN')
read=lambda entity:[json.loads(r[0]) for r in db.execute('SELECT body FROM records WHERE entity=?',(entity,))]
tasks=[t for t in read('tasks') if t.get('cloud_owner')==binding['owner'] and t.get('platform')=='xiaohongshu']
tasks.sort(key=lambda t:(str(t.get('updated_at','')),str(t.get('created_at',''))),reverse=True)
pages={r['id']:r for r in read('workbench_collection_page_analysis_v1')};jobs={r['id']:r for r in read('ai_jobs')}
out=[]
for i,t in enumerate(tasks):
    row=pages.get(t['id']);job=jobs.get(t['id']) or {}
    if row:
        out.append({'taskOrder':i,'taskStatus':t.get('status'),'pageStatus':row.get('status'),'pageCode':row.get('code'),
          'tenantMatchesTask':row.get('tenant_id')==t.get('tenant_id'),'ownerMatchesTask':row.get('owner')==t.get('cloud_owner'),
          'bindingMatchesCurrentCode':row.get('binding')==namespace['BindingProbe']._collection_binding(t),
          'leadIdsList':isinstance(row.get('lead_ids'),list),'leadIdsCount':len(row['lead_ids']) if isinstance(row.get('lead_ids'),list) else None,
          'jobStatus':job.get('status'),'jobCode':job.get('code'),'jobPending':job.get('pending'),
          'jobIdTenantOwnerMatch':all(row.get(k) and row.get(k)==job.get(k) for k in ('id','tenant_id','owner'))})
db.close()
result={'readOnly':True,'credentialsOrSessionsRead':False,'taskCount':len(tasks),'rows':out,'productionWritten':False}
(D/'LIVE-PAGE-SCOPE-AUDIT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))
