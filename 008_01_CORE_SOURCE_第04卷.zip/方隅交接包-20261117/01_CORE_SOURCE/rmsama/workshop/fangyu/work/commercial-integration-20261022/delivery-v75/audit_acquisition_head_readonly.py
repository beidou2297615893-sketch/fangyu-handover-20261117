from pathlib import Path
import sqlite3,json,hashlib
P=Path('C:/积木软件工坊/项目/方隅公寓客户版');D=Path(__file__).resolve().parent
b=json.loads((P/'work/ui-native-r57/state/production-workspace.json').read_text('utf-8-sig'))
c=sqlite3.connect((Path(b['data_dir'])/'workspace.sqlite3').as_uri()+'?mode=ro',uri=True)
c.execute('PRAGMA query_only=ON');c.execute('BEGIN')
tenants=c.execute("SELECT DISTINCT tenant_id FROM records WHERE entity='leads' AND json_extract(body,'$.cloud_owner')=?",(b['owner'],)).fetchall();assert len(tenants)==1
tenant=tenants[0][0]
digest=hashlib.sha256(json.dumps(['head',tenant,b['owner']],ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
row=c.execute("SELECT json_extract(body,'$.state'),json_extract(body,'$.conditions.platform'),json_extract(body,'$.job.taskId'),json_extract(body,'$.tenant_id')=?,json_extract(body,'$.owner')=? FROM records WHERE entity='ui_workbench_platform_requests_v1' AND id=?",(tenant,b['owner'],digest)).fetchone()
latest=c.execute("SELECT id FROM records WHERE entity='tasks' AND tenant_id=? AND json_extract(body,'$.cloud_owner')=? AND json_extract(body,'$.platform')='xiaohongshu' ORDER BY COALESCE(json_extract(body,'$.updated_at'),json_extract(body,'$.created_at'),'') DESC LIMIT 1",(tenant,b['owner'])).fetchone()
result={'readOnly':True,'headExists':bool(row),'headState':row[0] if row else None,'headPlatform':row[1] if row else None,'headMatchesLatestXhsTask':bool(row and latest and row[2]==latest[0]),'headTenantOwnerMatch':bool(row and row[3] and row[4]),'privateRequestIdsOrTokensExported':False,'productionWritten':False}
c.close();target=D/'LIVE-ACQUISITION-HEAD.json';assert not target.exists();target.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(result))
