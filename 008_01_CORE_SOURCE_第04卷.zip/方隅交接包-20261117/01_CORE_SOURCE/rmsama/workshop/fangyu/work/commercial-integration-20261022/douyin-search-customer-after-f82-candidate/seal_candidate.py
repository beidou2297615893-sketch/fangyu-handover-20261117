"""Seal only a completed fixed own joint run. Never alter product inputs."""
from pathlib import Path
import datetime,hashlib,json,subprocess,sys
T=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_bytes())
save=lambda p,v:p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n','utf-8')
assert not (T/'SEALED.json').exists()
subprocess.run([sys.executable,str(T/'audit_candidate.py')],check=True)
factories=[p for p in (T/'source-joint1/payload').glob('factory-*') if (p/'RESULTS.json').exists()]
passed=[p for p in factories if read(p/'RESULTS.json').get('status')=='PASS']
assert len(passed)==1,[(p.name,read(p/'RESULTS.json').get('status')) for p in factories]
F=passed[0];joint=read(F/'RESULTS.json')
assert joint['allOwnServicesClosed'] is True and joint['platformRequests']==0 and joint['modelRequests']==0
cloud=T/'source-joint1/cloud-joint2/ORIGINAL-CLOUD-BRIDGE-RESULTS.json'
assert read(cloud)['status']=='STOPPED'
planning=T/'source-planning1/payload/factory-27006de681e347768728ee759b8ed69a/RESULTS.json'
assert read(planning)['status']=='PASS' and read(planning)['allOwnServicesClosed'] is True
sources=read(T/'SOURCE-FILES.json')['files']
assert len(sources)==6
for row in sources:assert sha(T/'source-candidate'/row['path'])==row['afterSha256']
all_files=[p for p in (T/'source-candidate').rglob('*') if p.is_file()]
assert len(all_files)==6 and all(p.suffix=='.py' for p in all_files)
artifacts=[T/'SOURCE-FILES.json',T/'CANDIDATE.patch',T/'AST-BOUNDARY-AUDIT.json',
    T/'INTERFACE.md',T/'MERGE-REPIN.md',T/'INNER-CHAIN-RECEIPT.json',
    T/'source-joint1/PROBE-INPUTS.json',T/'source-joint1/SHARED-DEPENDENCY.json',
    T/'source-joint1/probe_entry-joint2.py',F/'RESULTS.json',F/'PROCESSES.json',
    F/'ADMISSION-LOCKS.json',F/'ORIGINAL-ACCOUNT-STATUS-OBSERVATIONS.json',F/'VM-EVIDENCE.json',
    planning,cloud]
artifacts += sorted((T/'material-examples/source-joint1').glob('*.json'))
artifacts += [T/name for name in ('prepare_joint_probe.py','prepare_joint_entry.py','prepare_joint_entry2.py',
    'prepare_probe.py','prepare_entry.py','run_probe.py','audit_candidate.py','search_bridge_fixture.cjs')]
rows=[{'path':p.relative_to(T).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)} for p in artifacts]
report={'schema':'douyin_customer_search_source_candidate_receipt_v1','status':'SEALED_SOURCE_CANDIDATE',
    'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'sourceFiles':6,'sourceFilesSha256':sha(T/'SOURCE-FILES.json'),'patchSha256':sha(T/'CANDIDATE.patch'),
    'base':'Fixed F82 plus sealed predecessor customer-read-purpose eleven-source dependency',
    'jointResults':F.relative_to(T).as_posix()+'/RESULTS.json','jointGroups':joint['groupCount'],
    'actualNodeProcesses':joint['actualNodeProcesses'],
    'testEntry':'source-joint1/probe_entry-joint2.py',
    'testCommand':'run_probe.py source-joint1 source joint2; own original cloud entry source-joint1/cloud-joint2/serve_original_cloud.cjs',
    'reproductionPreparation':'Fresh source-joint<N> only: prepare_joint_probe.py <name>; prepare_joint_entry.py <name>; prepare_joint_entry2.py <name>. Original fixed evidence must never be overwritten.',
    'verification':{'originalHostFactory':True,'actualCloudCreateServiceLoginPairEnrollPoll':True,
        'originalServiceRunnerDeviceSessionAndPrivateReadLease':True,
        'originalAccountStatusCliUidObservation':True,'originalOuterStartAndWorker':True,
        'originalCoreImportPipelineDedupAndAiSkip':True,'unknownOriginalPageNoRedispatch':True,
        'realCliRouterRegistryClientAndCompleteUserscriptOwnVm':True,
        'planningWithoutPlatformLoginOrReadLease':True,'sourceAstBoundary':True,
        'mainCompiledExe':False,'realPlatform':False,'nativeWebView':False,'secondPc':False,
        'realCloudDeployment':False,'realModelOrAiQuality':False},
    'qaDependency':{'interface':'shared-read-lease-qa-v1','status':'Fixed QA dependency only; root uses final sibling source',
        'laterRuntimeV2V3':'Not claimed covered by this fixed product. Final merged button/analysis/compiled acceptance remains root-owned.'},
    'uiLoginCloudBoundary':'Original desktop integration used owned synthetic login/store response; new device lease uses actual original createService via loopback.',
    'reviewMaterials':'Examples outside source-candidate; rederive all per-purpose roots/hashes on final merged actual bytes. No purpose/limits/send grant expansion.',
    'unverified':['Real platform/natural login and reading speed','Native browser loaded bytes',
        'Final compiled commercial package and genuine deployed cloud','Final sibling Runtime button/snapshot/AI hunks','Second ordinary PC'],
    'productionWrites':0,'realPlatformRequests':0,'realModelRequests':0,'publicSendGrant':False,
    'allOwnServicesClosed':True,'artifacts':rows}
save(T/'FINAL-RECEIPT.json',report)
seal={'schema':1,'status':'SEALED_NO_FURTHER_WRITES','finalSha256':sha(T/'FINAL-RECEIPT.json'),
    'sourceFilesSha256':sha(T/'SOURCE-FILES.json'),'patchSha256':sha(T/'CANDIDATE.patch'),
    'sourceFiles':sources,'artifacts':rows,'allOwnServicesClosed':True}
save(T/'SEALED.json',seal)
print(json.dumps({'finalSha256':sha(T/'FINAL-RECEIPT.json'),'sealedSha256':sha(T/'SEALED.json'),
    'sourceFilesSha256':sha(T/'SOURCE-FILES.json'),'patchSha256':sha(T/'CANDIDATE.patch'),
    'groups':joint['groupCount'],'actualNodeProcesses':joint['actualNodeProcesses'],'results':str(F/'RESULTS.json')},ensure_ascii=False))
