from pathlib import Path
from datetime import datetime,timezone
import hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent;W=D.parent;P=D.parents[2]
F=P/'work/parallel-integration-20261018/final-integration';base=F/'candidate-unified-v77'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(base/'UNIFIED-PINS.json')=='cd8c1c9702c8246fbfc5f2b1ff4e1750c8324955d939075391c727199088439b'
accepted=[
 ('acquisition-account-recovery-candidate','283f695d8890bcc77d4b25c8ca95081ab3eafe57db44bbb113d6f1ce3d288953','0d843179131a9cbd7f77865262223895e9d89bea21429a6475e85c0c55e5f1d5','source-candidate'),
 ('account-entry-ux-candidate','3b51cab8fb8aa8a120390a5a5536e398a2334d78ff5beb3c590e5fd099ebdee1','7a51a6cd92cb89f8826a53507e995a29817b668af783132c458a48143f429dbb','overlay'),
 ('account-management-backend-candidate','2537a8e04f217b1a6e037ffac7fefd5e8b8ea9f76a2b6b762eabfa9e70364b21','8fe9d6cd04586e6a0ad72fdced7764b852bc0330c755d7b53f3fbfdb5a7a96eb','overlay')]
S=W/'account-recovery-composed-source/project';assert not S.exists()
pins=json.loads((base/'UNIFIED-PINS.json').read_text('utf-8'))['files']
for entry in pins:
    raw=(base/'project'/entry['path']).read_bytes();assert hashlib.sha256(raw).hexdigest()==entry['sha256']
    target=S/entry['path'];target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
planned={}
for name,final_pin,seal_pin,folder in accepted:
    C=W/name;assert sha(C/'FINAL-RECEIPT.json')==final_pin and sha(C/'SEALED.json')==seal_pin
    manifest=json.loads((C/'SOURCE-FILES.json').read_text('utf-8'));entries=manifest if isinstance(manifest,list) else manifest['files']
    for row in entries:
        relative=row['path'];path=Path(relative);assert not path.is_absolute() and '..' not in path.parts and ':' not in relative
        before=row['beforeSha256'];after=row.get('afterSha256') or row['sha256'];target=S/relative
        assert sha(target)==before and relative not in planned,('Explicit overlap/base review required',relative)
        raw=(C/folder/relative).read_bytes();assert hashlib.sha256(raw).hexdigest()==after;target.write_bytes(raw)
        planned[relative]={'author':name,'beforeSha256':before,'afterSha256':after}
assert len(planned)==12
receipt={'status':'INACTIVE_COMPOSED_SOURCE_FOR_COMBINED_VALIDATION_NOT_INSTALLED','source':str(S),'baselineFilesVerified':len(pins),'files':[{'path':relative,**item} for relative,item in planned.items()],'capturedAt':datetime.now(timezone.utc).isoformat(),'canonicalSourceChanged':False,'nativeEntryChanged':False,'productionAccess':False}
(D/'ASSEMBLY-SOURCE.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),'utf-8')
spec=importlib.util.spec_from_file_location('urgent_original_freezer',F/'freeze_unified.py');builder=importlib.util.module_from_spec(spec);spec.loader.exec_module(builder)
builder.SOURCE=S
sys.argv=[str(F/'freeze_unified.py'),'--candidate','candidate-unified-v78'];builder.main()
