"""Copy the independently sealed clean candidate, never QA or live state."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import shutil

PROJECT = Path('C:/积木软件工坊/项目/方隅公寓客户版')
WORK = PROJECT / 'work/commercial-integration-20261022'
REVIEW = WORK / 'delivery-next-launch/review-4'
OUT = PROJECT / 'outputs/三合一交付/普通电脑内测版'

def sha(path):
    with path.open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()

pins = {
    REVIEW / 'FINAL-RECEIPT.json': '6dc045334d4b56f7d87b8667afade37295deda26439d1ff97d7bc778e1645a72',
    REVIEW / 'FINAL-STANDARD-DISTRIBUTION-HANDOFF.json': '3a88c57f305f99504f37431495e451db49a514788fd3a3d6585285ad826ff15a',
    WORK / 'standard-distribution-independent-review/final-v72/FINAL-RECEIPT.json': 'a5350754d2872f05ee56e192a0b1a0d9446d4d3cce2e2a48ec2507571bd84880',
    REVIEW / 'standard-held-clean-v72/FangyuWorkbenchSetup-standard-held-clean-v72.exe': '344f863c4427e8be90406bc5d3d5173f773db5546fe7be2783015ddb752ae2e7',
}
for path, expected in pins.items():
    if not path.is_file() or sha(path) != expected:
        raise RuntimeError('Sealed delivery evidence changed: ' + path.name)
independent = json.loads((WORK / 'standard-distribution-independent-review/final-v72/FINAL-RECEIPT.json').read_text('utf-8'))
assert independent['blockingFindings'] == []
assert independent['heldRemainsTrue'] is True
assert independent['commercialOrRealPlatformApproval'] is False
assert independent['normalDataFilesAndRecordsUnchanged'] is True
assert independent['sourceUnifiedPinsSha256'] == '1a1c49af3fee70e1270a5fe71e12d24b6a35480814dc16c7a02205ae0d139295'
OUT.mkdir(parents=True, exist_ok=True)
source = REVIEW / 'standard-held-clean-v72/FangyuWorkbenchSetup-standard-held-clean-v72.exe'
target = OUT / '方隅工作台_受限内测安装包.exe'
expected = pins[source]
if target.exists():
    if sha(target) != expected:
        raise RuntimeError('Existing output differs; refusing overwrite')
else:
    shutil.copy2(source, target)
assert sha(target) == expected
guide = '''方隅工作台：普通电脑受限内测版

这份安装包用于独立电脑的安装和界面核对，约281MB。它不是已完成真实平台验收的正式客户包，真实平台采集、自动发送和作品发布保持关闭。

你原电脑上正在打开的方隅工作台已经另行更新，原来的客户、评论、账号和采集断点保留。不要用这个内测包替换正在工作的客户实例，也不用为了本次更新再安装一次。

电脑条件
使用64位Windows 10或11，需要已有可用的WebView2和.NET桌面环境。无需另装Python，不需要独立显卡，也不捆绑本地大模型。缺少WebView2时安装器会提示停止，本包不会自动下载。

如何核对
双击同一文件夹里的安装包，使用默认安装位置。首次进入仍需要自己的企业员工账号和门店权限。没有复制任何测试管理员、客户名单、平台登录会话或原电脑的账号凭据。

已在当前电脑的独立目录核验程序首启、中文字体、图片、窗口布局及正常关闭，并以单独测试数据核验客户查看、表格导出和资料导入。第二台实体电脑、真实企业及平台登录和真实业务流程仍需后续验收。

媒体功能使用已有素材和提供的字幕；本包不捆绑视频处理工具，缺少已核验的外置工具时会提示不可用。不包含自动转写、配音或AI视频生成。

这份包不自动回复客户，不自动发私信，不自动发布作品。需要本人扫码、人脸或验证码时保留断点。
'''
guide_path = OUT / '安装与当前能力.txt'
guide_path.write_text(guide, encoding='utf-8', newline='\n')
receipt = {
    'status': 'PASS_COPIED_SEALED_CLEAN_HELD_INSTALLER_ONLY',
    'createdAt': datetime.now(timezone.utc).isoformat(),
    'source': str(source), 'destination': str(target),
    'bytes': target.stat().st_size, 'sha256': sha(target),
    'guide': str(guide_path), 'guideSha256': sha(guide_path),
    'sealedEvidence': {str(p): h for p, h in pins.items()},
    'qaRunnerCopied': False, 'productionStateCopied': False,
    'installerExecuted': False, 'commercialOrRealPlatformApproval': False,
    'liveCanonicalOrSourceWritten': False,
}
receipt_path = WORK / 'delivery-v72/CLEAN-OUTPUT-DELIVERY.json'
if receipt_path.exists():
    raise RuntimeError('Receipt exists; do not silently replace an earlier sealed handoff')
receipt_path.write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'status': receipt['status'], 'bytes': receipt['bytes'], 'sha256': expected,
                  'outputs': str(OUT), 'receipt': str(receipt_path)}, ensure_ascii=False))
