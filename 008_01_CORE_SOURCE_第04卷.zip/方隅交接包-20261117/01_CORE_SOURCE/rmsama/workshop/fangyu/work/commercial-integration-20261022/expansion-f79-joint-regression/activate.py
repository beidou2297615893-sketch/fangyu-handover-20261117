"""Binding only. Invoke after root publishes actual aggregate fixed pins."""
from pathlib import Path
import argparse,hashlib,json
W=Path(__file__).resolve().parent;parser=argparse.ArgumentParser()
for name in ['project','stage','stage-sha256','manifest-sha256','root-receipt','root-receipt-sha256']:parser.add_argument('--'+name,required=True)
a=parser.parse_args();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert not (W/'ACTIVATION.json').exists(),'Use a new revision for a different bound aggregate'
for pin in [a.stage_sha256,a.manifest_sha256,a.root_receipt_sha256]:assert len(pin)==64 and all(c in '0123456789abcdef' for c in pin.lower())
assert sha(a.stage)==a.stage_sha256.lower() and sha(a.root_receipt)==a.root_receipt_sha256.lower()
S=Path(a.project).resolve();stage=json.loads(Path(a.stage).read_text('utf-8-sig'));R=Path(stage['release']).resolve()
assert stage['status']=='STAGED' and R.is_relative_to(S) and sha(R/'RELEASE.json')==a.manifest_sha256.lower()==stage['manifest_sha256'].lower()
b={'status':'ROOT_AUTHORIZED_AGGREGATE','project':str(S),'stagePath':str(Path(a.stage).resolve()),'stageSha256':a.stage_sha256.lower(),'manifestSha256':a.manifest_sha256.lower(),'rootReceiptPath':str(Path(a.root_receipt).resolve()),'rootReceiptSha256':a.root_receipt_sha256.lower(),'stage':stage}
(W/'ACTIVATION.json').write_text(json.dumps(b,ensure_ascii=False,indent=2)+'\n','utf-8')
source_paths=['work/shared-backend-integration/platform_runtime.py','work/ui-native-r57/ui_native_host.py','work/ui-native-r57/workbench_backend.py','work/ui-runtime-r55/src/core/engine.py','work/ui-runtime-r55/src/assistant/business.py','work/ui-runtime-r55/src/assistant/assistant_service.py']
(W/'DRAFT-PINS.json').write_text(json.dumps({'status':'OBSERVED_ACTUAL_AGGREGATE_ACCOUNT_FIXTURE_INPUTS','rootReceiptSha256':b['rootReceiptSha256'],'files':[{'path':p,'sha256':sha(S/p)} for p in source_paths if (S/p).is_file()]},ensure_ascii=False,indent=2)+'\n','utf-8')
print('Bound actual aggregate. No business test executed.')
