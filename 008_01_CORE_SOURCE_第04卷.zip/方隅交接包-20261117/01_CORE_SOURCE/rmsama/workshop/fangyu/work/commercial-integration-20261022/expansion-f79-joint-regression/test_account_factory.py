from pathlib import Path
from copy import deepcopy
from types import SimpleNamespace
import hashlib,http.client,importlib.util,inspect,json,os,sys,threading,time,uuid
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=W.parents[2]
from final_inputs import load_verified
ROOT_PINS,F,S,stage,R=load_verified()
O=W/('factory-'+uuid.uuid4().hex);O.mkdir();events=[];blocked=[];checks=[];passed=False
def save(name,v):(O/name).write_text(json.dumps(v,ensure_ascii=False,indent=2,default=str),'utf-8')
def audit(event,args):
 if event in ('subprocess.Popen','os.system','os.startfile','os.posix_spawn'):blocked.append(event);raise RuntimeError('No real process/platform')
 if event in ('socket.connect','socket.bind') and (not isinstance(args[1],tuple) or args[1][0] not in ('127.0.0.1','::1')):raise RuntimeError('Loopback only')
 if event=='socket.getaddrinfo' and args[0] not in ('127.0.0.1','::1','localhost',None):raise RuntimeError('No external DNS')
 if event=='sqlite3.connect' and not Path(args[0]).resolve().is_relative_to(O):raise RuntimeError('Own DB only')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  path=Path(os.fsdecode(args[0])).absolute();mode,flags=args[1] or '',args[2] or 0
  if (any(c in mode for c in 'wax+') or isinstance(flags,int) and flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC)) and not path.is_relative_to(O) and path!=W/'LATEST-FACTORY.json':raise RuntimeError('Own output only')
sys.addaudithook(audit)
def load(name,path):
 m=importlib.util.module_from_spec(importlib.util.spec_from_loader(name,loader=None));m.__file__=str(path);sys.modules[name]=m;exec(compile(path.read_bytes(),str(path),'exec'),m.__dict__);return m
fixture=load('account_original_cloud_fixture',P/'work/acquisition-core-repair-20261018/gui-fixture/base_fixture.py');cloud=fixture.CloudStandin(json.loads((P/'work/central-store-config/compiled-fixture.json').read_text('utf-8-sig')));company=json.loads((S/'work/app/company.json').read_text('utf-8-sig'));ENV=company['managedWorkspace']['environment_id']
def transport(*a,**k):v=cloud(*a,**k);v['environment_id']=ENV;return v
integration=load('integrations',R/'resources/platform-runtime/vendor-src/integrations.py');integration.request_json=transport
host=load('account_actual_native_host',R/'ui_native_host.py');host.verify_release(R,stage['manifest_sha256']);files=host.verify_release(R,stage['manifest_sha256'])[1];host.verify_backend_dependencies(R,files,S)
backend=host.create_backend(R,files,project_root=S,data_dir=O/'data',company=company);runtime=backend.platform_runtime
server=host.StaticServer(R,files,backend=backend,cookie_name='owned_account_fixture');worker=threading.Thread(target=server.serve_forever,daemon=True);worker.start();origin='http://127.0.0.1:'+str(server.server_port);headers={}
def request(method,payload=None,expected=200,path=None):
 c=http.client.HTTPConnection('127.0.0.1',server.server_port,timeout=20);c.request(method,path or ('/api/workbench/bootstrap' if method=='GET' else '/api/workbench'),json.dumps(payload,ensure_ascii=False).encode() if payload else None,headers);r=c.getresponse();raw=r.read();h=dict(r.getheaders());status=r.status;c.close()
 try:body=json.loads(raw)
 except ValueError:body={'rawResponseText':raw.decode('utf-8',errors='replace')}
 redacted=deepcopy(payload)
 if redacted and redacted.get('action')=='login':redacted['data']['password']='synthetic omitted'
 events.append({'request':redacted,'status':status,'body':body});save('HTTP.json',events)
 assert status==expected,(status,expected,body);return body,h
def action(name,data,expected=200):
 if name=='platform':return request('GET',expected=expected,path='/api/workbench/platform?platform='+data['platform'])[0]
 if name=='account_job':return request('GET',expected=expected,path='/api/workbench/account-job?jobId='+data['jobId'])[0]
 return request('POST',{'action':name,'data':data},expected)[0]
def rows():
 with backend.core.store.connect() as db:return {(r['entity'],r['id']):r['body'] for r in db.execute('SELECT entity,id,body FROM records')}
def put(entity,row):backend.core.store.put(entity,{**row,'tenant_id':user['tenant_id']})
def account(key,nickname='合成旧账号',status='ready',owner=None,store_id=None):
 a={'id':key,'tenant_id':user['tenant_id'],'cloud_owner':owner or user['username'],'store_id':store_id or store,'platform':'xiaohongshu','status':status,'name':'合成备注','platform_nickname':nickname,'platform_uid':'synthetic-uid-'+key};backend.core.store.put('accounts',a);return a
def deletion(a,key=None,**extra):return {'storeId':store,'accountId':a['id'],'platform':a['platform'],'expectedNickname':str(a.get('platform_nickname') or a.get('name') or '')[:100],'confirmed':True,'requestId':key or uuid.uuid4().hex,**extra}
try:
 boot,_=request('GET');headers.update(Origin=origin,**{'Content-Type':'application/json','X-Fangyu-CSRF':boot['csrfToken']});logged,h=request('POST',{'action':'login','data':{'username':'fixture-admin','password':fixture.PASSWORD}});headers['Cookie']=h['Set-Cookie'].split(';',1)[0];headers['X-Fangyu-CSRF']=logged['csrfToken'];token=headers['Cookie'].split('=',1)[1];store=cloud.first_store
 if logged['selection']['storeId']!=store:action('select_store',{'storeId':store,'expectedRevision':logged['selection']['revision']})
 user={**backend.core.session(token),'_workbench_store_id':store}
 from assistant.business import BusinessExecutor
 from assistant.xhs_app_context import bind_executor_session
 runtime.server._configure_bundled();runtime._platform_setup=True
 runtime.core.remote_safety_hold=False;runtime.core.employee_release_device_id='account-device';runtime.core.employee_release_until_monotonic=time.monotonic()+300
 executor=BusinessExecutor(runtime.server,ENV,company['id'],user['username']);runtime.service.executor=executor
 saved={'state':'bound','environment_id':ENV,'company_id':company['id'],'token':'synthetic-device-token','device':{'id':'account-device','owner':user['username']}}
 runtime.service.vault=SimpleNamespace(read=lambda:deepcopy(saved));runtime.service.device=deepcopy(saved['device']);runtime.service.state='online';bind_executor_session(runtime.service,executor,saved)
 platform_calls=[];runtime.core.adapters._execute=lambda *a,**k:platform_calls.append(1) or (_ for _ in ()).throw(AssertionError('No platform wire allowed'))
 source_paths={'service':inspect.getfile(type(runtime.service)),'business':inspect.getfile(type(executor)),'core':inspect.getfile(type(runtime.core))};save('ACTUAL-SOURCES.json',source_paths)
 assert all(str(S) in source_paths[k] if k=='core' else str(R) in source_paths[k] for k in source_paths)
 old=account('account-old',status='check_required');current=account('account-current','合成当前账号');foreign=account('account-foreign',owner='other-fixture-owner')
 put('tasks',{'id':'task-old','account_id':old['id'],'store_id':store,'platform':'xiaohongshu','cloud_owner':user['username'],'status':'paused','scope':'all','keywords':['合成'],'created_at':'2026-10-20T00:00:00+08:00'})
 snapshot=action('platform',{'platform':'xiaohongshu'})['platform'];byid={a['id']:a for a in snapshot['accounts']}
 assert byid[current['id']]['collectionReady'] is True and byid[old['id']]['collectionReady'] is False and snapshot['acquisition']['canStart'] is False
 assert snapshot['acquisition']['taskStoreId']==store and snapshot['acquisition']['taskPlatform']=='xiaohongshu' and snapshot['acquisition']['accountRemoved'] is False and not platform_calls
 checks.append('Original Native snapshot per-account collection readiness independent of latest old account; old canStart remains false; exact task store/platform projection; zero platform wire')
 witnesses={}
 for entity,key,row in [('leads','comment-1',{'task_id':'task-old','account_id':old['id'],'platform':'xiaohongshu','text':'合成评论保留','manual_intent':'medium','contact_shared':False}),('replies','reply-1',{'lead_id':'comment-1','account_id':old['id'],'status':'draft','text':'合成回复保留'}),('customer_outcome_events_v1','outcome-1',{'leadId':'comment-1','state':'synthetic'}),('customer_handoff_events_v1','handoff-1',{'leadId':'comment-1','note':'合成交接保留'})]:
  put(entity,{'id':key,**row});witnesses[(entity,key)]=backend.core.store.get(entity,key)
 otherfile=O/'data/accounts'/user['tenant_id']/current['id']/'xhs-browser-profile/sentinel.txt';otherfile.parent.mkdir(parents=True);otherfile.write_text('other customer account profile kept','utf-8')
 request_data=deletion(old);base=rows();action('account_delete',{**request_data,'confirmed':False},400);action('account_delete',{**request_data,'expectedNickname':'wrong'},409);action('account_delete',{**request_data,'platform':'douyin'},403);action('account_delete',{**request_data,'storeId':'other-store'},403);action('account_delete',deletion(foreign),403);assert rows()==base
 checks.append('Confirmed false, changed nickname, wrong platform/store/owner all refuse before receipt or deletion; records unchanged')
 calls=[];original_delete=runtime.service.delete_account
 def observed_delete(*args,**kwargs):calls.append({'id':args[0],'expected':kwargs.get('expected_account_digest')});return original_delete(*args,**kwargs)
 runtime.service.delete_account=observed_delete
 result=action('account_delete',request_data);deleted=result['accountDeletion'];assert deleted['state']=='deleted' and deleted['requestId']==request_data['requestId'] and result['actor']['accountId']==old['id'] and len(calls)==1
 assert backend.core.store.get('accounts',old['id']) is None
 task=backend.core.store.get('tasks','task-old');assert task['account_id']=='' and task['account_removed'] is True and task['status']=='paused'
 assert all(backend.core.store.get(*k)==v for k,v in witnesses.items()) and otherfile.read_text('utf-8')=='other customer account profile kept'
 replay=action('account_delete',request_data)['accountDeletion'];looked=action('account_delete_request',{'storeId':store,'requestId':request_data['requestId']})['accountDeletion'];assert replay['state']==looked['state']=='deleted' and len(calls)==1
 action('account_delete',{**request_data,'expectedNickname':'changed'},409)
 snap=action('platform',{'platform':'xiaohongshu'})['platform'];assert snap['acquisition']['accountRemoved'] is True and snap['acquisition']['taskStoreId']==store and snap['acquisition']['taskPlatform']=='xiaohongshu' and snap['acquisition']['taskScope'] is None
 assert next(a for a in snap['accounts'] if a['id']==current['id'])['collectionReady'] is True
 checks.append('Actual service→Business→Core deletion once; customer/comments/replies/outcome/handoff and other account profile byte-equivalent; old task retired; same key/lookup replay no delete; ready new account projected after retirement')
 # Race is inserted at the original Core.handle boundary, after the service
 # and Business accepted the server-generated fixed digest. No fake Core.
 race=account('account-race');original_handle=runtime.core.handle
 def changed_handle(name,data=None,user=None,**kw):
  if name=='account_delete' and data and data.get('id')==race['id']:
   changed=runtime.core.store.get('accounts',race['id']);changed['platform_nickname']='变更后的合成昵称';runtime.core.store.put('accounts',changed)
  return original_handle(name,data,user,**kw)
 runtime.core.handle=changed_handle
 rr=deletion(race);red=action('account_delete',rr,409);runtime.core.handle=original_handle
 assert backend.core.store.get('accounts',race['id']) and '身份或资料已变化' in red['error']['message']
 assert action('account_delete_request',{'storeId':store,'requestId':rr['requestId']})['accountDeletion']['state']=='unknown'
 checks.append('Actual Core atomic digest CAS rejects binding change inserted after service/Business; original mature function reached, account retained, only original unknown receipt query')
 active=account('account-active');put('tasks',{'id':'task-active','account_id':active['id'],'store_id':store,'platform':'xiaohongshu','cloud_owner':user['username'],'status':'paused'})
 runtime.core.running.add('task-active');busy=action('account_delete',deletion(active),409);runtime.core.running.discard('task-active');assert backend.core.store.get('accounts',active['id']) and '正在采集' in busy['error']['message']
 sending=account('account-sending');put('replies',{'id':'reply-sending','account_id':sending['id'],'status':'sending'});busy=action('account_delete',deletion(sending),409);assert backend.core.store.get('accounts',sending['id']) and '正在发送' in busy['error']['message']
 runtime.core.acquire_account_mode(current['id'],user['tenant_id'],'replies','synthetic-mode-owner')
 before_calls=len(calls);action('account_delete',deletion(current),409);assert len(calls)==before_calls;runtime.core.release_account_mode(current['id'],user['tenant_id'],'synthetic-mode-owner')
 checks.append('Original Core active collection/sending guards refuse; original active AccountMode lease blocks destructive call; no guard weakened')
 lost=account('account-lost');lost_input=deletion(lost)
 def lost_return(*args,**kwargs):observed_delete(*args,**kwargs);raise RuntimeError('synthetic acknowledgement lost')
 runtime.service.delete_account=lost_return;action('account_delete',lost_input,409);runtime.service.delete_account=observed_delete;number=len(calls)
 assert backend.core.store.get('accounts',lost['id']) is None and action('account_delete',lost_input)['accountDeletion']['state']=='unknown' and len(calls)==number
 assert action('account_delete_request',{'storeId':store,'requestId':lost_input['requestId']})['accountDeletion']['state']=='unknown'
 assert action('account_delete_request',{'storeId':store,'requestId':uuid.uuid4().hex})['accountDeletion']['state']=='not_started'
 checks.append('Real original deletion committed then synthetic receipt loss remains unknown; same key/query never delete again; absent request not_started has no invented account binding')
 opened=action('account_verification_open',{'accountId':current['id']})['job'];assert opened['accountId']==current['id'] and opened.get('jobId') and opened['windowOpen'] is False
 for _ in range(50):
  result=action('account_job',{'jobId':opened['jobId']})['job']
  if result['status']=='failed':break
  time.sleep(.05)
 assert result['status']=='failed' and result['windowOpen'] is False and result['errorCode']=='VERIFICATION_WINDOW_FAILED' and '未成功打开' in result['message']
 assert not platform_calls and all(backend.core.store.get(*k)==v for k,v in witnesses.items()) and otherfile.read_text('utf-8')=='other customer account profile kept'
 checks.append('Original owned profile open returns bound opening/jobId; actual subprocess boundary refused in QA and original job reports visible failed/not-open, never falsely opened; no platform call')
 server.shutdown();worker.join(3);server.server_close();backend.close()
 backend=host.create_backend(R,files,project_root=S,data_dir=O/'data',company=company);runtime=backend.platform_runtime
 server=host.StaticServer(R,files,backend=backend,cookie_name='owned_account_fixture');worker=threading.Thread(target=server.serve_forever,daemon=True);worker.start();origin='http://127.0.0.1:'+str(server.server_port);headers.clear()
 boot,_=request('GET');headers.update(Origin=origin,**{'Content-Type':'application/json','X-Fangyu-CSRF':boot['csrfToken']});logged,h=request('POST',{'action':'login','data':{'username':'fixture-admin','password':fixture.PASSWORD}});headers['Cookie']=h['Set-Cookie'].split(';',1)[0];headers['X-Fangyu-CSRF']=logged['csrfToken']
 assert action('account_delete_request',{'storeId':store,'requestId':request_data['requestId']})['accountDeletion']['state']=='deleted'
 assert action('account_delete_request',{'storeId':store,'requestId':lost_input['requestId']})['accountDeletion']['state']=='unknown'
 assert action('account_delete',request_data)['accountDeletion']['state']=='deleted' and len(calls)==number
 assert all(backend.core.store.get(*k)==v for k,v in witnesses.items()) and otherfile.read_text('utf-8')=='other customer account profile kept'
 checks.append('Actual factory close/reopen preserves original deleted and unknown receipts; same-key replay needs no new executor and never re-enters delete; comments/history/profile sentinels unchanged')
 passed=True;save('RESULTS.json',{'status':'PASS','checks':checks,'httpRequestsNotGroups':len(events),'realPlatformCalls':0,'realAccountDeletes':0,'syntheticOriginalDeleteCalls':calls,'actualFactorySources':source_paths,'stage':stage,'sourcePins':json.loads((W/'DRAFT-PINS.json').read_text('utf-8'))})
finally:
 server.shutdown();worker.join(3);server.server_close();backend.close();save('FINAL.json',{'status':'PASS' if passed else 'RED_CAPTURED','closed':not worker.is_alive(),'blocked':blocked,'realExternalCalls':0,'checks':checks});(W/'LATEST-FACTORY.json').write_text(json.dumps({'directory':str(O),'status':'PASS' if passed else 'RED_CAPTURED'}),'utf-8')
print(json.dumps({'status':'PASS','checks':len(checks),'httpRequests':len(events),'directory':str(O)},ensure_ascii=False))
