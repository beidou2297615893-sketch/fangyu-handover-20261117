from pathlib import Path
W=Path(__file__).resolve().parent
t=(W/'test_factory_dm.py').read_text('utf-8');prefix=t[:t.index(' for i in range(2):')]
client="S/'work/ui-runtime-r55/work/runtime/douyin-bridge/lib/client/bridge-client.js'"
prefix=prefix.replace(" and not path.is_relative_to(OUT):raise RuntimeError('Own evidence/data only')"," and not path.is_relative_to(OUT) and path!="+client+":raise RuntimeError('Own evidence/data only')")
assert 'path!='+client in prefix
body=''' target=S/'work/ui-runtime-r55/work/runtime/douyin-bridge/lib/client/bridge-client.js';original=target.read_bytes()
 try:
  target.write_bytes(original+b'\\n// own controlled tamper probe\\n')
  try:_components(runtime.server)
  except ValueError as e:assert str(e)=='component_review_pending'
  else:raise AssertionError('Changed original account connection component accepted')
  try:core.adapters.direct_messages({'platform':'douyin','platform_uid':'9007199254740993','conn_id':'synthetic-connection'},'listen','integrity-original-key',OUT/'account',guard=lambda:None,timeout_ms=100)
  except ValueError as e:assert '发生变化' in str(e)
  else:raise AssertionError('Changed pinned CLI dependency accepted')
 finally:target.write_bytes(original)
 assert _components(runtime.server)==component_revision
 assert not wire and len(processes)==1 # only owned fixture host, no DM CLI
 checks.append('Mutated client is refused by both original account _components and original DM pin gate; exact restore recovers same revision, zero CLI/page dispatch')
 save('INTEGRITY-RESULTS.json',{'status':'PASS','checks':checks,'actualOriginalFactory':True,'exactOwnQaClientRestored':True,'canonicalWrites':False,'realPlatformCalls':0});passed=True
'''
(W/'test_connection_integrity.py').write_text(prefix+body+t[t.index('\nfinally:'):],'utf-8')
