"""Actual Native HTTP/Runtime/BusinessExecutor/Core; only cloud/device I/O, clock and platform pages are synthetic."""
from pathlib import Path
from copy import deepcopy
from types import SimpleNamespace
import hashlib,http.client,importlib.util,json,os,sys,tempfile,threading,time
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=W.parents[2]
from final_inputs import load_verified
ROOT_PINS,C,S,STAGED,N=load_verified()
release=N
NOTE='https://www.xiaohongshu.com/explore/0123456789abcdef01234567'
def load(name,path):
 m=importlib.util.module_from_spec(importlib.util.spec_from_loader(name,loader=None));m.__file__=str(path);sys.modules[name]=m;exec(compile(path.read_bytes(),str(path),'exec'),m.__dict__);return m
blocked=[];trace=[];io=[];claims=[]
def audit(event,args):
 if event in ('socket.connect','socket.bind') and (not isinstance(args[1],tuple) or args[1][0] not in ('127.0.0.1','::1')):blocked.append(event);raise RuntimeError('External socket forbidden')
 if event=='socket.getaddrinfo' and args[0] not in ('127.0.0.1','::1','localhost',None):blocked.append(event);raise RuntimeError('External DNS forbidden')
 if event in ('subprocess.Popen','os.system','os.startfile','os.posix_spawn'):blocked.append(event);raise RuntimeError('External process forbidden')
 if event=='sqlite3.connect' and not Path(args[0]).resolve().is_relative_to(W):blocked.append(event);raise RuntimeError('Production DB forbidden')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  path=Path(os.fsdecode(args[0])).absolute();mode,flags=args[1] or '',args[2] or 0
  writes=any(c in str(mode) for c in 'wax+') or isinstance(flags,int) and bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC))
  if writes and not path.is_relative_to(W):blocked.append('write:'+path.name);raise RuntimeError('Only candidate writable')
sys.addaudithook(audit)
original=load('schedule_identity_fixture',P/'work/acquisition-core-repair-20261018/gui-fixture/base_fixture.py')
cloud=original.CloudStandin(json.loads((P/'work/central-store-config/compiled-fixture.json').read_text('utf-8-sig')))
PUBLIC_COMPANY=json.loads((S/'work/app/company.json').read_text('utf-8-sig'))
def frozen_cloud(*args,**kwargs):
 value=cloud(*args,**kwargs)
 if isinstance(value,dict) and 'environment_id' in value:value['environment_id']=PUBLIC_COMPANY['managedWorkspace']['environment_id']
 return value
integration=load('integrations',N/'resources/platform-runtime/vendor-src/integrations.py');integration.request_json=frozen_cloud
host=load('schedule_actual_frozen_host',N/'ui_native_host.py')
manifest,files=host.verify_release(release,ROOT_PINS['manifestSha256'])
host.verify_backend_dependencies(release,files,S)
box=[];pages=[]
def configure_runtime(runtime):
 box.append(runtime)
 runtime.core.deployment_config.update(deepcopy(PUBLIC_COMPANY))
 runtime.core.remote_safety_hold=False;runtime.core.employee_release_device_id='schedule-device';runtime.core.employee_release_until_monotonic=time.monotonic()+600
 # Explicit fixture-only local adapter initialization reuses the actual pinned
 # guarded CLI manifest. It reads F materials and writes only owned adapters;
 # it does not call Runtime.prepare, enrollment, login, heartbeat or a process.
 runtime.server._configure_bundled()
 def transport(platform,args,account_dir,job_id,timeout=35,**kwargs):
  from assistant.xhs_cli_page_worker import validate_args,exact_source_gate
  from urllib.parse import urlencode
  validate_args(args);gate=exact_source_gate(args);command=gate.command;gate('GET','https://edith.xiaohongshu.com'+command.wire_path+'?'+urlencode(command.wire_query))
  io.append({'args':args,'job':job_id});page=pages.pop(0)
  if isinstance(page,Exception):raise page
  return {'ok':True,'schema_version':'1','data':page}
 runtime.core.adapters._execute=transport
 runtime.core.adapters.verify=lambda *a,**k:(_ for _ in ()).throw(AssertionError('Unrelated search forbidden'))
 original_scheduled=runtime.run_scheduled_source_page
 def observe_scheduled(*args,**kwargs):
  try:return original_scheduled(*args,**kwargs)
  except Exception:
   import traceback;traceback.print_exc();raise
 runtime.run_scheduled_source_page=observe_scheduled
 return runtime
company=deepcopy(PUBLIC_COMPANY)
def frozen_backend(directory):
 # This is the actual verified frozen Native factory. There is no replacement
 # Runtime/Core/BusinessExecutor/materials factory and no candidate overlay.
 backend=host.create_backend(release,files,project_root=S,data_dir=directory,company=company)
 assert backend is not None and backend.platform_runtime is not None
 configure_runtime(backend.platform_runtime)
 return backend
with tempfile.TemporaryDirectory(dir=W) as temp:
 backend=frozen_backend(Path(temp)/'data')
 server=host.StaticServer(release,files,backend=backend,cookie_name='schedule_fixture_session');worker=threading.Thread(target=server.serve_forever,daemon=True);worker.start();origin='http://127.0.0.1:'+str(server.server_port)
 def request(method,path,data=None,headers=None):
  conn=http.client.HTTPConnection('127.0.0.1',server.server_port,timeout=20);conn.request(method,path,body=json.dumps(data,ensure_ascii=False).encode() if data is not None else None,headers=headers or {});resp=conn.getresponse();raw=resp.read();found=dict(resp.getheaders());status=resp.status;conn.close();return status,json.loads(raw) if raw and 'json' in found.get('Content-Type','') else {},found
 try:
  _,boot,_=request('GET','/api/workbench/bootstrap');headers={'Content-Type':'application/json','Origin':origin,'X-Fangyu-CSRF':boot['csrfToken']}
  def action(name,data,status=200):
   code,value,found=request('POST','/api/workbench',{'action':name,'data':data},headers);assert code==status,(name,code,value);return value,found
  logged,found=action('login',{'username':'fixture-admin','password':original.PASSWORD});headers.update(Cookie=found['Set-Cookie'].split(';',1)[0]);headers['X-Fangyu-CSRF']=logged['csrfToken'];token=headers['Cookie'].split('=',1)[1];store=cloud.first_store
  if logged['selection']['storeId']!=store:action('select_store',{'storeId':store,'expectedRevision':logged['selection']['revision']})
  user={**backend.core.session(token),'_workbench_store_id':store};runtime=box[0]
  from assistant.business import BusinessExecutor
  from assistant.xhs_app_context import bind_executor_session
  executor=BusinessExecutor(runtime.server,company['managedWorkspace']['environment_id'],company['id'],user['username']);runtime.service.executor=executor
  saved={'state':'bound','environment_id':company['managedWorkspace']['environment_id'],'company_id':company['id'],'token':'synthetic-device-token','device':{'id':'schedule-device','owner':user['username']}}
  runtime.service.vault=SimpleNamespace(read=lambda:deepcopy(saved));runtime.service.device=deepcopy(saved['device']);runtime.service.state='online'
  claim_allowed=[True]
  class DeviceCloud:
   def call(self,operation,data,credential):
    assert operation=='device_account_claim' and credential==saved['token'];claims.append(deepcopy(data));return {'claimed':claim_allowed[0]}
   def close(self):pass
  runtime.service._cloud=lambda:DeviceCloud();executor.account_claim=runtime.service._claim_xhs_account;bind_executor_session(runtime.service,executor,saved)
  account=dict(id='schedule-first',tenant_id=user['tenant_id'],cloud_owner=user['username'],store_id=store,platform='xiaohongshu',status='ready',name='定期检查账号',platform_uid='synthetic-schedule-first');runtime.core.store.put('accounts',account)
  preset,_=action('source_preset_save',dict(storeId=store,name='本人评论检查',platform='xiaohongshu',accountId=account['id'],source={'kind':'own_interactions','types':['mentions'],'baseline':'visible_history'},commentWindow={'mode':'all'},expectedVersion=0,requestId='schedule-preset-000001'))
  preset=preset['sourcePreset'];data=dict(storeId=store,accountId=account['id'],presetId=preset['id'],presetVersion=preset['version'],intervalMinutes=60,confirmed=True,expectedVersion=0,requestId='schedule-enable-000001')
  legacy,_=action('source_schedule_save',dict(storeId=store,name='旧每小时提醒',presetId=preset['id'],presetVersion=preset['version'],intervalMinutes=60,timezone='Asia/Shanghai',expectedVersion=0,requestId='schedule-legacy-000001'))
  before,_=action('source_execution_read',{'storeId':store});assert before['sourceExecutions']['items']==[] and not io
  assert legacy['sourceSchedule']['enabled'] is False
  action('source_execution_enable',{**data,'confirmed':False},400)
  action('source_execution_enable',{**data,'storeId':'other-store'},403)
  trace.append('Legacy reminder remains config-only; execution requires explicit account/store/frequency confirmation')
  enabled,_=action('source_execution_enable',data)
  spec=enabled['sourceExecution'];assert spec['state']=='waiting' and spec['enabled'] and not io
  runtime.core.continuous.close(wait=True) # deterministic manual tick, original loop remains reusable
  runtime.core.continuous._stop.clear()
  clock=spec['nextRunEpoch'];assert runtime.core.continuous.tick(epoch=clock-1) is False and not io
  comment={'id':'schedule-comment-1','content':'请问整租一年租金','create_time':'2026-10-20T10:00:00+00:00','user_info':{'user_id':'schedule-person','nickname':'合成租客'}}
  event={'id':'schedule-event-1','user_info':comment['user_info'],'comment_info':comment,'note_info':{'note_id':'0123456789abcdef01234567','title':'合成出租笔记','xsec_token':'synthetic-access'}}
  pages.append({'message_list':[event],'has_more':True,'cursor':'schedule-cursor-next'})
  assert runtime.core.continuous.tick(epoch=clock) is True
  read,_=action('source_execution_read',{'storeId':store});row=read['sourceExecutions']['items'][0]
  assert row['state']=='waiting' and row['runs']==1 and row['taskId'] and len(io)==1 and claims,(row,io,claims)
  task=runtime.core.store.get('tasks',row['taskId']);assert 'schedule-cursor-next' in json.dumps(task['pipeline'])
  assert len(runtime.core.store.list_task_leads(user['tenant_id'],row['taskId']))==1
  assert runtime.core.continuous.tick(epoch=clock) is False and len(io)==1
  replay,_=action('source_execution_enable',data);assert replay['sourceExecution']['id']==row['id'] and replay['sourceExecution']['runs']==1 and len(io)==1
  trace.append('Actual Native HTTP -> explicit ExecutionSpec -> original Core tick -> Runtime/real sealed DeviceSession/central claim -> one guarded read and saved original cursor; same epoch and original request replay do not dispatch')
  missed=row['nextRunEpoch']+86400;pages.append({'message_list':[],'has_more':True,'cursor':'schedule-cursor-after-sleep'});count=len(io)
  assert runtime.core.continuous.tick(epoch=missed) is True
  coalesced,_=action('source_execution_read',{'storeId':store});row=coalesced['sourceExecutions']['items'][0]
  assert row['runs']==2 and row['nextRunEpoch']==missed+3600 and len(io)==count+1
  assert runtime.core.continuous.tick(epoch=missed) is False and len(io)==count+1
  task=runtime.core.store.get('tasks',row['taskId'])
  trace.append('Sleep/missed intervals coalesce to one original page and schedule next interval from the actual tick; no catch-up burst')
  # A durable original task reference is not permission to replace a lost row.
  with runtime.core.store.connect() as db:
   db.execute('DELETE FROM records WHERE entity=? AND id=?',('tasks',task['id']))
  count=len(io)
  assert runtime.core.continuous.tick(epoch=row['nextRunEpoch']) is True
  missing,_=action('source_execution_read',{'storeId':store})
  missing=missing['sourceExecutions']['items'][0]
  assert len(io)==count and missing['taskId']==task['id'] and missing['state']=='needs_confirmation',missing
  runtime.core.store.put('tasks',task)
  trace.append('Missing original task keeps its original identifier and stops without creating or reading a replacement')
  # Reconfirm the same execution through Native HTTP. The deterministic future
  # clock keeps the actual Core background loop idle until each explicit tick.
  runtime.source_scheduler.clock=lambda:2_000_000_000
  serial=[1]
  def read_execution():
   value,_=action('source_execution_read',{'storeId':store});return next(x for x in value['sourceExecutions']['items'] if x['id']==spec['id'])
  def arm(interval=60):
   latest=read_execution();serial[0]+=1
   request_data={**data,'id':latest['id'],'expectedVersion':latest['version'],'intervalMinutes':interval,'requestId':'schedule-reconfirm-'+str(serial[0]).zfill(6)}
   enabled,_=action('source_execution_enable',request_data)
   runtime.core.continuous.close(wait=True);runtime.core.continuous._stop.clear()
   return enabled['sourceExecution'],request_data
  def blocked_tick(label,prepare,restore=lambda:None):
   runtime.core.store.put('tasks',deepcopy(task));row,request_data=arm();prepare();count=len(io)
   assert runtime.core.continuous.tick(epoch=row['nextRunEpoch']) is True
   held=read_execution();assert len(io)==count and held['id']==spec['id'] and held['taskId']==task['id'] and held['state']=='needs_confirmation',(label,held,io[count:])
   assert runtime.core.store.get('tasks',task['id'])['pipeline']==task['pipeline'],label
   assert runtime.core.continuous.tick(epoch=row['nextRunEpoch']+100000) is False and len(io)==count
   restore();runtime.core.store.put('accounts',deepcopy(account));trace.append(label+' preserves original task/cursor and performs no read or automatic retry')
   return held
  blocked_tick('Human verification',lambda:runtime.core.store.put('accounts',{**account,'requires_review':True}),lambda:runtime.core.store.put('accounts',account))
  blocked_tick('Account identity switch',lambda:runtime.core.store.put('accounts',{**account,'platform_uid':'different-person'}),lambda:runtime.core.store.put('accounts',account))
  blocked_tick('Revoked central account claim',lambda:claim_allowed.__setitem__(0,False),lambda:claim_allowed.__setitem__(0,True))
  blocked_tick('Expired device connection',lambda:setattr(runtime.service,'state','offline'),lambda:setattr(runtime.service,'state','online'))
  row,request_data=arm(interval=30)
  assert row['taskId']==task['id'],'A frequency change must retain the exact original task'
  action('source_execution_enable',{**request_data,'intervalMinutes':60},409)
  action('source_execution_pause',dict(storeId=store,id=row['id'],expectedVersion=row['version']-1),409)
  paused,_=action('source_execution_pause',dict(storeId=store,id=row['id'],expectedVersion=row['version']))
  assert paused['sourceExecution']['state']=='paused' and paused['sourceExecution']['taskId']==task['id']
  count=len(io);assert runtime.core.continuous.tick(epoch=row['nextRunEpoch']+100000) is False and len(io)==count
  trace.append('Explicit pause/CAS and changed-request replay do not dispatch; changing only frequency retains original task')
  # Exercise the actual shared three-mode lease and its durable unknown lock.
  leases=runtime.core.continuous.leases
  leases.acquire(account['id'],user['tenant_id'],'replies','fixture-reply')
  lease_before=deepcopy(leases.get(account['id'],user['tenant_id']))
  blocked_tick('Original reply account lease',lambda:None)
  assert leases.get(account['id'],user['tenant_id'])==lease_before
  assert leases.release(account['id'],user['tenant_id'],'fixture-reply')
  publication=dict(id='schedule-unknown-publication',tenant_id=user['tenant_id'],scope=dict(tenant_id=user['tenant_id'],account_id=account['id']),state='unknown')
  publication['recordDigest']=hashlib.sha256(json.dumps(publication,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
  runtime.core.store.put('content_publication_attempt_v1',publication)
  blocked_tick('Sealed unresolved publication account lock',lambda:None)
  assert runtime.core.store.get('content_publication_attempt_v1',publication['id'])==publication
  with runtime.core.store.connect() as db:db.execute('DELETE FROM records WHERE entity=? AND id=?',('content_publication_attempt_v1',publication['id']))
  runtime.core.store.put('tasks',deepcopy(task));row,request_data=arm();pages.append(RuntimeError('Synthetic external receipt unavailable'));count=len(io)
  assert runtime.core.continuous.tick(epoch=row['nextRunEpoch']) is True
  unknown=read_execution();assert len(io)==count+1 and unknown['state']=='needs_confirmation' and unknown['taskId']==task['id'],unknown
  assert runtime.core.continuous.tick(epoch=row['nextRunEpoch']+100000) is False and len(io)==count+1
  row,request_data=arm();count=len(io)
  assert runtime.core.continuous.tick(epoch=row['nextRunEpoch']) is True
  held=read_execution();assert len(io)==count and held['state']=='needs_confirmation' and held['taskId']==task['id'],held
  trace.append('Unknown external page receipt stops at the original key; explicit reconfirm cannot redispatch its unresolved page')
  # Native App logout/expiry must invalidate its captured RAM grant, even when
  # the device session and persisted execution record are otherwise unchanged.
  runtime.core.store.put('tasks',deepcopy(task));row,request_data=arm();count=len(io)
  with backend.core.store.connect() as db:db.execute('UPDATE sessions SET expires=0 WHERE token=?',(hashlib.sha256(token.encode()).hexdigest(),))
  assert runtime.core.continuous.tick(epoch=row['nextRunEpoch']) is True and len(io)==count
  action('source_execution_read',{'storeId':store},401)
  logged,found=action('login',{'username':'fixture-admin','password':original.PASSWORD});headers.update(Cookie=found['Set-Cookie'].split(';',1)[0]);headers['X-Fangyu-CSRF']=logged['csrfToken'];token=headers['Cookie'].split('=',1)[1]
  assert read_execution()['state']=='needs_confirmation'
  trace.append('Expired original Native App session stops before read; a new login cannot revive its old RAM grant')
  # The hard crash gap is after original Core task_save commits but before its
  # generated task identifier reaches the schedule. It must never mint another.
  crash_account={**account,'id':'schedule-crash','platform_uid':'synthetic-crash'};runtime.core.store.put('accounts',crash_account)
  crash_preset,_=action('source_preset_save',dict(storeId=store,name='创建回执中断验证',platform='xiaohongshu',accountId=crash_account['id'],source={'kind':'own_interactions','types':['mentions'],'baseline':'visible_history'},commentWindow={'mode':'all'},expectedVersion=0,requestId='schedule-crash-preset-000001'))
  crash_data={**data,'accountId':crash_account['id'],'presetId':crash_preset['sourcePreset']['id'],'requestId':'schedule-crash-enable-000001'}
  crash_row,_=action('source_execution_enable',crash_data);crash_row=crash_row['sourceExecution'];runtime.core.continuous.close(wait=True);runtime.core.continuous._stop.clear()
  execute=runtime._execute
  def lost_creation(*args,**kwargs):
   result=execute(*args,**kwargs)
   if args[2]=='task_save':raise RuntimeError('Synthetic interruption after original task commit')
   return result
  runtime._execute=lost_creation;count=len(io)
  try:assert runtime.core.continuous.tick(epoch=crash_row['nextRunEpoch']) is True
  finally:runtime._execute=execute
  crash_read,_=action('source_execution_read',{'storeId':store});crash_held=next(x for x in crash_read['sourceExecutions']['items'] if x['id']==crash_row['id'])
  tasks_before=len(runtime.core.store.list('tasks'))
  action('source_execution_enable',{**crash_data,'id':crash_row['id'],'expectedVersion':crash_held['version'],'requestId':'schedule-crash-enable-000002'},409)
  assert len(io)==count and len(runtime.core.store.list('tasks'))==tasks_before
  trace.append('Interrupted original task-creation acknowledgement retains its creation claim and blocks replacement even after explicit reconfirmation')
  # Reopen the actual Native backend against this isolated Store. No platform
  # preparation, device login or scheduler authority is restored by disk rows.
  row,request_data=arm();count=len(io)
  records=runtime.core.store.list('acquisition_source_execution_v2')
  assert token not in json.dumps(records) and saved['token'] not in json.dumps(records)
  server.shutdown();server.server_close();worker.join(5);backend.close()
  backend=frozen_backend(Path(temp)/'data');runtime=box[-1]
  server=host.StaticServer(release,files,backend=backend,cookie_name='schedule_fixture_session');worker=threading.Thread(target=server.serve_forever,daemon=True);worker.start();origin='http://127.0.0.1:'+str(server.server_port)
  _,boot,_=request('GET','/api/workbench/bootstrap');headers={'Content-Type':'application/json','Origin':origin,'X-Fangyu-CSRF':boot['csrfToken']}
  logged,found=action('login',{'username':'fixture-admin','password':original.PASSWORD});headers.update(Cookie=found['Set-Cookie'].split(';',1)[0]);headers['X-Fangyu-CSRF']=logged['csrfToken']
  reopened=read_execution();assert reopened['state']=='needs_confirmation' and not reopened['enabled'] and reopened['taskId']==task['id']
  assert not runtime.source_scheduler.grants and runtime.core.continuous.tick(epoch=3_000_000_000) is False and len(io)==count
  trace.append('Actual Native close/reopen retains plan/task and requires personal reconfirmation; no token persisted or automatic prepare/login')
  result={'status':'PASS','checks':len(trace),'trace':trace,'blocked':blocked,'realPlatformRequests':0,'realModelCalls':0,'productionDataAccess':False,'originalLease':'Core AccountModeLeases','deviceAuthority':'Actual sealed session and original AssistantService claim path; external response synthetic','frozenCandidate':str(C),'releaseRoot':str(release),'rootPins':ROOT_PINS,'frozenFactory':'verify_release -> verify_backend_dependencies -> actual create_backend','runtimePath':str(Path(sys.modules[backend.platform_runtime.__class__.__module__].__file__)),'coreSource':str(S/'work/ui-runtime-r55/src')}
  (W/'HTTP-RESULTS.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(result,ensure_ascii=False))
 finally:server.shutdown();server.server_close();worker.join(5);backend.close()
