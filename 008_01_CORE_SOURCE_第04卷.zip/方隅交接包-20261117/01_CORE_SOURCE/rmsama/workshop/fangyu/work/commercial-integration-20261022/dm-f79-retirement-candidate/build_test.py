from pathlib import Path
import hashlib,json
W=Path(__file__).resolve().parent;Old=W.parent/'dm-f79-independent-review'
stage=json.loads((W/'QA-STAGE-CURRENT.json').read_text('utf-8'));assert stage['status']=='STAGED' and Path(stage['release']).is_relative_to(W/'qa-only-project')
(W/'INPUTS.json').write_text(json.dumps({'label':'dm-retirement-owned-qa-only-not-formal-freeze','stage':stage,'sourcePins':hashlib.sha256((W/'SOURCE-PINS.json').read_bytes()).hexdigest()},ensure_ascii=False,indent=2)+'\n','utf-8')
s=(Old/'test_independent_factory.py').read_text('utf-8')
s=s.replace("S=W.parent/'dm-f79-candidate'/'qa-only-project'","S=W/'qa-only-project'")
s=s.replace("and not path.is_relative_to(OUT):raise", "and not path.is_relative_to(OUT) and path!=W/'UI-SERVER.json':raise")
s=s.replace("'reply_customer_claims_v1'","'ui_customer_reply_guard_v1'")
original="runtime.server._configure_bundled();runtime._platform_setup=True\n executor=BusinessExecutor"
replacement="runtime.server._configure_bundled();runtime._platform_setup=True\n core.remote_safety_hold=False;core.employee_release_device_id='dm-synthetic-device';core.employee_release_until_monotonic=time.monotonic()+600\n for fixture_config in (runtime.server.company,core.deployment_config):\n  flags=fixture_config['runtime'];flags['public_send_hold']=False;flags['public_reply_hold']=False;flags['public_replies']='enabled';flags.pop('platform_qa_device_id',None)\n executor=BusinessExecutor"
assert s.count(original)==1;s=s.replace(original,replacement)
start=s.index(" if code==200 and body.get('accountDeletion'")
end=s.index(" assert not blocked",start)
new=r'''
 assert code==200 and body['accountDeletion']['state']=='deleted' and rc==200 and rb['dmWorkspace']['state']=='unknown' and rb['dmWorkspace']['accountRemoved'] is True
 assert rb['dmWorkspace']['accountId']==account['id'] and rb['dmWorkspace']['requestId']==key and rb['dmWorkspace']['retiredAccount']['nickname']==account['name']
 checks[-1]['result']='PASS';checks[-1]['retiredLookup']=rb['dmWorkspace'];checks[-1]['originalClaimByteUnchanged']=True
 # Original source-level public DM interface receives the very same real
 # refreshed identity callback as HTTP. It must not gain a send path.
 cookie=headers['Cookie'].split('=',1)[1];payload={'storeId':store,'action':'dm_queue_start','requestId':key};before=len(wire);stable=capture()
 direct=backend.dm_workbench.execute('dm_request_read',user,store,payload,lambda:backend._delivery_identity(cookie))
 assert direct['state']=='unknown' and direct['accountRemoved'] is True and capture()==stable and len(wire)==before
 # A new account must still fail the original customer claim after retirement.
 another=prepare(other,[od]);start(another);again=wait_queue(another['id']);assert again['state']=='blocked' and '该客户正在发送或上次结果待核对' in again['message'] and len(wire)==before
 after_claim=deepcopy(core.store.list('ui_customer_reply_guard_v1',user['tenant_id']))
 assert after_claim==stable['ui_customer_reply_guard_v1']
 # Missing or forged retirement proof is not a fallback authorization.
 negatives=[];entity='workbench_account_deletion_v1';audit=next(x for x in core.store.list(entity,user['tenant_id']) if x['accountId']==account['id']);old_audit=deepcopy(audit)
 def denied(label):
  n=len(wire);code,body,_=request('POST','/api/workbench',{'action':'dm_request_read','data':payload});assert code==403 and len(wire)==n,(label,code,body);negatives.append({'case':label,'status':code,'body':body})
 try:
  core.store.put(entity,{**audit,'state':'unknown'});denied('deletion not confirmed');core.store.put(entity,old_audit)
  core.store.put(entity,{**audit,'inputDigest':'0'*64});denied('forged deleted input digest');core.store.put(entity,old_audit)
  core.store.put(entity,{**audit,'owner':'another-employee'});denied('foreign deletion owner');core.store.put(entity,old_audit)
  core.store.put(entity,{**audit,'storeId':wrong_store});denied('different deletion store');core.store.put(entity,old_audit)
  core_audits=[x for x in core.store.list('audit',user['tenant_id']) if x.get('action')=='account_delete' and x.get('detail',{}).get('id')==account['id']]
  assert core_audits
  for a in core_audits:core.store.put('audit',{**a,'action':'not-account-delete'})
  try:denied('no original Core deletion audit')
  finally:
   for a in core_audits:core.store.put('audit',a)
  original_queue=deepcopy(core.store.get('ui_dm_queues_v1',q['id']));core.store.put('ui_dm_queues_v1',{**original_queue,'owner':'another-employee'})
  try:denied('persistent queue owner changed')
  finally:core.store.put('ui_dm_queues_v1',original_queue)
  reply_permission[0]=False
  try:denied('current permission revoked')
  finally:reply_permission[0]=True
  action('dm_request_read',{**payload,'storeId':wrong_store},403)
  try:
   backend.dm_workbench.execute('dm_request_read',{**user,'username':'forged'},store,payload,lambda:backend._delivery_identity(cookie))
  except Exception as e:assert getattr(e,'status',None)==403;negatives.append({'case':'lower interface forged caller','status':403,'code':getattr(e,'code',None)})
  else:raise AssertionError('Lower retired query accepted another actor')
 finally:core.store.put(entity,old_audit)
 # The last revoked profile has been refreshed back before comparing rows.
 final_lookup=dm('dm_request_read',{'action':'dm_queue_start','requestId':key});assert final_lookup['state']=='unknown' and final_lookup['accountRemoved'] and len(wire)==before
 assert core.store.get('ui_dm_drafts_v1',d1['id'])==frozen_unknown and core.store.get('ui_dm_queues_v1',q['id'])==frozen_queue and core.store.list('ui_customer_reply_guard_v1',user['tenant_id'])==after_claim
 save('RETIREMENT-NEGATIVES.json',negatives)
 save('RETIREMENT-GREEN.json',{'originalRequestKey':key,'lookup':final_lookup,'unknownDraftByteUnchanged':True,'unknownQueueByteUnchanged':True,'claimByteUnchanged':True,'zeroRedispatchAfterUnknown':len(wire)==before,'lowerInterfaceSameContract':True,'crossAccountClaimStillBlocked':again,'negativeCases':negatives,'noSourceHoldsChanged':True})
 checks.append({'group':'G5_retirement_scope_proof_permission_claim','result':'PASS','negativeCases':len(negatives)+1,'retirementReadsZeroWire':True,'unknownRowsClaimByteUnchanged':True})
 if '--serve-ui' in sys.argv:
  stop=OUT/'STOP';save('UI-DATA.json',{'requestId':key,'accountId':account['id'],'storeId':store})
  (W/'UI-SERVER.json').write_text(json.dumps({'origin':origin,'directory':str(OUT),'stop':str(stop),'username':'fixture-admin','password':fixture.PASSWORD,'storeId':store,'retiredAccountId':account['id'],'requestId':key,'accounts':[other['id']]},ensure_ascii=False),'utf-8')
  print('UI_READY '+str(OUT),flush=True)
  until=time.monotonic()+300
  while not stop.exists() and time.monotonic()<until:time.sleep(.1)
  assert stop.exists(),'Own UI timeout'
  save('AFTER-UI.json',{'wire':wire,'exactlyOneSyntheticSend':sum(x['operation']=='send' for x in wire)==1,'unknownDraftByteUnchanged':core.store.get('ui_dm_drafts_v1',d1['id'])==frozen_unknown,'claimByteUnchanged':core.store.list('ui_customer_reply_guard_v1',user['tenant_id'])==after_claim})
'''
s=s[:start]+new+s[end:]
(W/'test_retirement_factory.py').write_text(s,'utf-8')
print(W/'test_retirement_factory.py')
