from pathlib import Path
import ast,difflib,hashlib,json
W=Path(__file__).resolve().parent;C=W.parent/'dm-f79-candidate';P=W.parents[2];F=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v79';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(C/'SEALED.json')=='629459cd38891f60a752678059b270e747f5f7c53430e71412c30017fb29950e'
assert sha(W.parent/'dm-f79-independent-review/FINAL-RECEIPT.json')=='6547452f5e4fc93e770a552722e47cfa3f835af8883c69c521cc67b809c906a8'
rels=['work/ui-native-r57/dm_workbench.py','work/ui-approved-implementation/ui-preview/pages/reply-dm.mjs']
helper=''' def _retired_request_view(self,record,current,user,store,refresh):
  # A retired account grants no execution authority. Recover only the original
  # unknown queue, after the existing actor/store authority and both original
  # deletion receipts agree. Never substitute a current/new account identity.
  fresh,profile=refresh()
  if self.runtime is None:fail('DM_ACCOUNT_FORBIDDEN','原账号移除凭据无法核对',403)
  fresh=self.runtime._principal(fresh)
  if (any(fresh.get(k)!=user.get(k) for k in ('id','tenant_id','username'))
      or profile.get('_workbench_store_id',profile.get('store_id'))!=store
      or fresh.get('_workbench_store_id')!=store):fail('DM_SCOPE_FORBIDDEN','原私信不在当前员工门店范围',403)
  try:require_reply_permission(self.core,fresh)
  except ValueError:fail('DM_PERMISSION_FORBIDDEN','当前员工没有私信处理权限',403)
  self._owned(REQUESTS,record['id'],fresh,store)
  self._owned(QUEUES,current['id'],fresh,store)
  if (record.get('action')!='dm_queue_start' or record.get('requestId')!=current.get('requestId')
      or record.get('result',{}).get('id')!=current['id']
      or any(record.get('result',{}).get(k)!=current.get(k) for k in ('accountId','storeId','platform','snapshotDigest'))
      or record.get('signature')!=digest({'storeId':store,'id':current['id'],'snapshotDigest':current.get('snapshotDigest'),'confirmed':True,'requestId':record.get('requestId')})):
   fail('DM_RETIRED_PROOF_REQUIRED','原私信操作关联不完整，请保留原编号核对',403)
  view=self._queue_view(current)
  if view.get('state')!='unknown' or not current.get('accountId') or self.core.store.get('accounts',current['accountId']) is not None:
   fail('DM_RETIRED_PROOF_REQUIRED','只有已移除账号的原未知私信可只读核对',403)
  attempted=False
  for item in current.get('items',[]):
   snap=item.get('snapshot',{})
   if any(snap.get(k)!=current.get(k) for k in ('accountId','storeId','platform')):fail('DM_RETIRED_PROOF_REQUIRED','原队列账号范围不一致',403)
   if item.get('state') not in ('unknown','sending'):continue
   draft=self._owned(DRAFTS,item.get('draftId'),fresh,store)
   expected=digest([current['requestId'],draft['id'],draft['version']])
   if (draft.get('accountId')!=current['accountId'] or draft.get('state') not in ('unknown','sending')
       or draft.get('reviewSnapshot')!=snap or draft.get('sendRequestId')!=expected or item.get('requestId')!=expected):
    fail('DM_RETIRED_PROOF_REQUIRED','原未知私信与队列编号不一致',403)
   attempted=True
  if not attempted:fail('DM_RETIRED_PROOF_REQUIRED','原队列缺少已登记的未知私信',403)
  deletion=None
  for row in self.core.store.list('workbench_account_deletion_v1',fresh['tenant_id']):
   if any(row.get(k)!=v for k,v in {'tenant_id':fresh['tenant_id'],'ownerId':fresh['id'],'owner':fresh['username'],'storeId':store,'accountId':current['accountId'],'platform':current['platform'],'state':'deleted'}.items()):continue
   request=row.get('requestId');nickname=row.get('nickname')
   if (not isinstance(request,str) or not re.fullmatch(r'[A-Za-z0-9_-]{16,80}',request)
       or not isinstance(nickname,str) or len(nickname)>100 or any(ord(c)<32 for c in nickname)
       or row.get('id')!=self.runtime._deletion_key(fresh,store,request)
       or row.get('inputDigest')!=digest({'accountId':current['accountId'],'platform':current['platform'],'expectedNickname':nickname,'confirmed':True,'requestId':request})
       or not re.fullmatch(r'[a-f0-9]{64}',str(row.get('accountDigest') or ''))
       or not row.get('createdAt') or not row.get('finishedAt')):continue
   if any(a.get('tenant_id')==fresh['tenant_id'] and a.get('actor')==fresh['username'] and a.get('action')=='account_delete' and a.get('detail',{}).get('id')==current['accountId'] for a in self.core.store.list('audit',fresh['tenant_id'])):
    deletion=row;break
  if deletion is None:fail('DM_RETIRED_PROOF_REQUIRED','缺少本人当前门店的原账号移除回执，请保留原编号核对',403)
  view.update(accountRemoved=True,retiredAccount={'id':current['accountId'],'platform':current['platform'],'nickname':deletion['nickname']},message='账号已从软件移除，原私信结果待核对；只能查询原编号，不会再次发送。')
  return view
'''
rows=[];patches=[]
for rel in rels:
 p=C/'final-source'/rel;raw=p.read_bytes();text=raw.decode('utf-8');eol='\r\n' if '\r\n' in text else '\n';text=text.replace('\r\n','\n')
 if rel.endswith('.py'):
  assert text.count(' def execute(self,action,user,store,data,refresh):')==1
  text=text.replace(' def execute(self,action,user,store,data,refresh):',helper+' def execute(self,action,user,store,data,refresh):')
  old="   current=self._owned(entity,value['id'],user,store);self._account(user,store,current['accountId'])\n"
  new="   current=self._owned(entity,value['id'],user,store)\n   if entity==QUEUES and self.core.store.get('accounts',current['accountId']) is None:\n    return self._retired_request_view(record,current,user,store,refresh)\n   self._account(user,store,current['accountId'])\n"
  assert text.count(old)==1;text=text.replace(old,new);ast.parse(text)
 else:
  old="  remember(v,null);v.error=r.state==='unknown'?"
  new="  if(r.accountRemoved===true&&r.state==='unknown'){v.error=r.message||'账号已从软件移除，原私信结果待核对；只能查询原编号，不会再次发送。';v.retiredResult=r;v.retiredRequest=p;try{localStorage.setItem(storage(v.actor)+':retired',JSON.stringify(p));}catch{}remember(v,null);return;}\n  remember(v,null);v.error=r.state==='unknown'?"
  assert text.count(old)==1;text=text.replace(old,new)
  # A later unrelated account read must not erase the retired original result.
  old="v.value=r;v.loaded=true;v.error='';if(!v.dirty)"
  new="v.value=r;v.loaded=true;if(!v.retiredResult)v.error='';if(!v.dirty)"
  assert text.count(old)==1;text=text.replace(old,new)
  old="${v.pending?' <button data-dm-recover>核对原操作结果</button>':''}"
  new="${v.pending||v.retiredRequest?` <button data-dm-recover>${v.pending?'核对原操作结果':'继续核对已移除账号的原结果'}</button>`:''}"
  assert text.count(old)==1;text=text.replace(old,new)
  old="  try{const p=JSON.parse(localStorage.getItem(storage(v.actor))||'null');if(p&&p.actor===v.actor&&typeof p.requestId==='string'&&typeof p.action==='string')v.pending=p;}catch{}"
  new=old+"\n  try{const p=JSON.parse(localStorage.getItem(storage(v.actor)+':retired')||'null');if(p&&p.actor===v.actor&&p.action==='dm_queue_start'&&typeof p.requestId==='string'&&typeof p.accountId==='string')v.retiredRequest=p;}catch{}"
  assert text.count(old)==1;text=text.replace(old,new)
  text=text.replace("if(!v.pending||v.busy)return;const p={...v.pending};", "if(!(v.pending||v.retiredRequest)||v.busy)return;const p={...(v.pending||v.retiredRequest)};")
  text=text.replace("v.pending?.requestId!==p.requestId", "(v.pending||v.retiredRequest)?.requestId!==p.requestId")
  old="if(v.pending)await recover(s,ctx,v);else await load(s,ctx,v);"
  new="if(v.pending||v.retiredRequest&&!v.retiredResult)await recover(s,ctx,v);else await load(s,ctx,v);"
  assert text.count(old)==1;text=text.replace(old,new)
  old=' <div class="dm-workspace"><section class="dm-panel">'
  new=''' ${v.retiredResult?`<section class="dm-panel" data-dm-retired-result><h3>已移除账号的原结果 · 只读核对</h3><p>原发送账号：${esc(v.retiredResult.retiredAccount?.nickname||'原账号')}（已从软件移除）。原操作编号：${esc(v.retiredRequest?.requestId)}。</p><p>${esc(v.retiredResult.message)}</p>${v.retiredResult.items.map(i=>`<p>${esc(i.snapshot.text)} · ${esc(labels[i.state]||i.state)}</p>`).join('')}<p>以下仍是当前所选账号的资料；原结果不会借该账号恢复或重发。</p></section>`:''}
 <div class="dm-workspace"><section class="dm-panel">'''
  assert text.count(old)==1;text=text.replace(old,new)
 after=text.replace('\n',eol).encode('utf-8');dest=W/'final-source'/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(after)
 rows.append({'path':rel,'before':{'sha256':sha(p),'bytes':len(raw)},'after':{'sha256':sha(dest),'bytes':len(after)},'originalEol':repr(eol)})
 patches.extend(difflib.unified_diff(raw.decode().splitlines(True),after.decode().splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
(W/'SOURCE-PINS.json').write_text(json.dumps({'baseDmSeal':sha(C/'SEALED.json'),'baseF79FinalPins':sha(W.parent/'delivery-v79/FINAL-PINS.json'),'files':rows},ensure_ascii=False,indent=2)+'\n','utf-8')
(W/'SOURCE.patch').write_text(''.join(patches),'utf-8',newline='')
# Original factory requires a new honest QA manifest for changed sources.
Q=W/'qa-only-project';m=json.loads((F/'UNIFIED-PINS.json').read_text('utf-8'))['files'];copied=0
for row in m:
 rel=row['path']
 if rel.startswith(('work/ui-native-r57/releases/','work/ui-native-r57/candidates/','work/ui-native-r57/run_candidate.')):continue
 if 'state' in Path(rel).parts and not rel.endswith('state/production-workspace.json'):continue
 assert Path(rel).suffix.lower() not in ('.db','.sqlite','.sqlite3','.pyc')
 src=F/'project'/rel;assert sha(src)==row['sha256'];dest=Q/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(src.read_bytes());copied+=1
for source in (C/'final-source',W/'final-source'):
 for src in source.rglob('*'):
  if src.is_file():dest=Q/src.relative_to(source);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(src.read_bytes())
site=P/'work/desktop-python/Lib/site-packages'
for pattern in ['pywebview-*.dist-info/licenses/LICENSE','pythonnet-*.dist-info/licenses/LICENSE','clr_loader-*.dist-info/licenses/LICENSE','bottle-*.dist-info/licenses/LICENSE']:
 for src in site.glob(pattern):
  dest=Q/'work/desktop-python/Lib/site-packages'/src.relative_to(site);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(src.read_bytes())
(W/'QA-INPUTS.json').write_text(json.dumps({'label':'dm-retirement-owned-qa-only-not-formal-freeze','project':str(Q),'copiedFixedF79SourceFiles':copied,'base14DmFiles':sha(C/'SOURCE-PINS.json'),'ownOverlay':rows,'noDatabaseSessionCopied':True},ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps({'sources':len(rows),'qaSourceCopied':copied,'sourcePins':sha(W/'SOURCE-PINS.json')},ensure_ascii=False))
