from pathlib import Path
import ast,hashlib,json,zipfile
T=Path(__file__).resolve().parent;D=T.parent/'customer-read-cloud-lease-candidate';C=D/'cloud-candidate-final'
B=T.parent/'content-cloud-v3-final2/candidate'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((D/'SOURCE-CANDIDATE.json').read_bytes())
rows=manifest['sourceFiles'];assert len(rows)==5
for row in rows:
    assert sha(C/row['path'])==row['afterSha256'] and (C/row['path']).stat().st_size==row['bytes']
    if row['beforeSha256'] is not None:assert sha(B/row['path'])==row['beforeSha256']
# Verify the exact bounded edits against the actual readback bytes, without
# executing author's construction script or writing its candidate.
expected={row['path']:(B/row['path']).read_bytes() for row in rows if row['beforeSha256'] is not None}
calls=[]
for node in ast.parse((D/'construct_cloud_candidate.py').read_text('utf-8')).body:
    if isinstance(node,ast.Expr) and isinstance(node.value,ast.Call) and isinstance(node.value.func,ast.Name) and node.value.func.id=='change':
        args=[ast.literal_eval(arg) for arg in node.value.args];name,old,new=args[:3];count=args[3] if len(args)==4 else 1
        assert expected[name].count(old.encode())==count
        expected[name]=expected[name].replace(old.encode(),new.encode());calls.append({'file':name,'occurrences':count})
assert all(expected[name]==(C/name).read_bytes() for name in expected)
def between(raw,start,end):return raw.split(start,1)[1].split(end,1)[0]
before=(B/'devices.cjs').read_bytes();after=(C/'devices.cjs').read_bytes()
assert between(before,b' const employeeRelease=d=>{',b' const employeeForDevice')==between(after,b' const employeeRelease=d=>{',b' const employeeForDevice')
assert between(before,b' const commandHeld=',b' const respond=')==between(after,b' const commandHeld=',b' const respond=')
for name in ('device_permission_snapshot.cjs','readonly_routes.cjs','legacy_release.cjs','admin_workbench_policy.cjs'):
    assert (B/name).read_bytes()==(C/name).read_bytes()
archive=D/'customer-read-cloud-held.zip'
assert sha(archive)=='ebd602df4c2bf4d5f8b0f65c7b7d4230e1333b455d88f237dec7fb8bdd6ac3c9'
index=json.loads((D/'CODE-PACKAGE-FILES.json').read_bytes())
with zipfile.ZipFile(archive) as z:
    names=z.namelist();assert len(names)==len(set(names))==len(index)==5617
    assert set(names)=={r['path'] for r in index}
    for row in index:
        raw=z.read(row['path']);assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
    for row in rows:assert z.read(row['path'])==(C/row['path']).read_bytes()
out={'status':'PASS','actualFilesReviewed':rows,'boundedHunks':calls,
    'employeeReleaseAndCommandHeldBytePreserved':True,'snapshotAndReadonlyRoutesUnchanged':True,
    'heldZipSha256':sha(archive),'archiveMembersIndependentlyVerified':len(index),
    'sourceSpecSha256':sha(D/'CUSTOMER-READ-LEASE-SPEC.json'),
    'actualDeployment':False,'liveCredentialsAccessed':False,'sourceWritten':False}
(T/'CLOUD-STATIC-AND-ZIP.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),'utf-8')
print(json.dumps({'status':'PASS','cloudSources':5,'archiveFiles':len(index),'sourceWritten':False}))
