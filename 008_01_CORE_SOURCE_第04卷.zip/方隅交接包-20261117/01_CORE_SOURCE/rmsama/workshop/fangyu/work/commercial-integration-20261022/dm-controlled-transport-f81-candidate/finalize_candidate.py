from pathlib import Path
import ast,datetime,difflib,hashlib,json,re,shutil,subprocess,sys,uuid
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=W.parents[2];F=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v81';S=F/'project';O=W/'source-candidate';Q=W/'qa-only-project'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text('utf-8-sig'))
write=lambda n,v:(W/n).write_text(json.dumps(v,ensure_ascii=False,indent=2),'utf-8')
assert not (W/'SEALED.json').exists(),'Already sealed; never overwrite'
rows=read(W/'SOURCE-FILES.draft.json')['files'];assert len(rows)==10
assert {p.relative_to(O).as_posix() for p in O.rglob('*') if p.is_file()}=={r['path'] for r in rows}
unified=read(F/'UNIFIED-PINS.json')['files'];assert len(unified)==3332
assert {p.relative_to(S).as_posix() for p in S.rglob('*') if p.is_file()}=={r['path'] for r in unified}
for r in unified:assert sha(S/r['path'])==r['sha256'] and (S/r['path']).stat().st_size==r['bytes'],r['path']
patch=[];eol=[]
for r in rows:
 rel=r['path'];p=O/rel;assert sha(p)==r['after']['sha256'] and p.stat().st_size==r['after']['bytes']
 assert sha(Q/rel)==sha(p),rel
 old=(S/rel).read_bytes() if r['before'] else b'';new=p.read_bytes()
 if r['before']:assert hashlib.sha256(old).hexdigest()==r['before']['sha256']
 if b'\r\n' in old:assert new.count(b'\n')==new.count(b'\r\n'),rel
 eol.append({'path':rel,'originalCrLf':b'\r\n' in old,'candidateCrLf':b'\r\n' in new,'retainedOriginalStyle':not old or (b'\r\n' in old)==(b'\r\n' in new)})
 patch.append('diff --git a/'+rel+' b/'+rel+'\n')
 if not old:patch.append('new file mode 100644\n')
 for line in difflib.unified_diff(old.decode('utf-8').splitlines(keepends=True),new.decode('utf-8').splitlines(keepends=True),fromfile='a/'+rel if old else '/dev/null',tofile='b/'+rel,n=3):
  patch.append(line)
  if not line.endswith('\n'):patch.append('\n\\ No newline at end of file\n')
(W/'SOURCE.patch').write_bytes(''.join(patch).encode('utf-8'))
replay=W/('patch-replay-'+uuid.uuid4().hex);replay.mkdir()
for r in rows:
 if r['before']:
  p=replay/r['path'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((S/r['path']).read_bytes())
git=shutil.which('git');assert git
r=subprocess.run([git,'-c','core.autocrlf=false','-c','core.safecrlf=false','apply','--no-index','--whitespace=nowarn',str(W/'SOURCE.patch')],cwd=replay,capture_output=True)
(W/'PATCH-REPLAY-STDERR.txt').write_bytes(r.stderr);assert r.returncode==0,r.stderr.decode('utf-8','replace')
for row in rows:assert sha(replay/row['path'])==row['after']['sha256'],row['path']
write('SOURCE-FILES.json',{'schema':'fangyu-source-only-dm-typed-transport-v1','beforeOrigin':str(S),'unifiedSha256':sha(F/'UNIFIED-PINS.json'),'files':rows,'oldFiles':9,'newFiles':1,'noCanonicalWrites':True,'authorQaAndDataOutsideSourceCandidate':True})
b='work/ui-runtime-r55/work/runtime/douyin-bridge/'
old_user=(S/(b+'scripts/douyin.user.js')).read_text('utf-8');new_user=(O/(b+'scripts/douyin.user.js')).read_text('utf-8')
start='var DM_BRIDGE_CODE = (function () {/*';end='*/}).toString()'
codec=old_user[old_user.index(start)+len(start):old_user.index(end,old_user.index(start))]
assert codec in new_user
start='  var BRIDGE_CODE = (function () {/*';assert old_user[old_user.index(start):]==new_user[new_user.index(start):]
browser=(S/(b+'lib/dm_workbench_browser.js')).read_text('utf-8');fn=browser[browser.index('function installReviewedDM'):].rstrip().removesuffix(';');assert fn in new_user
service='work/shared-backend-integration/vendor-src/assistant/douyin_connection_service.py'
defs=lambda p:[(n.name,ast.dump(n,include_attributes=False)) for n in ast.parse(p.read_bytes()).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))]
assert defs(S/service)==defs(O/service)
protected=['work/ui-native-r57/dm_workbench.py','work/ui-native-r57/ui_native_host.py','work/ui-native-r57/reply_delivery.py','work/ui-native-r57/workbench_backend.py','work/shared-backend-integration/platform_runtime.py','work/ui-runtime-r55/src/core/engine.py','work/ui-runtime-r55/src/core/continuous.py','work/ui-approved-implementation/ui-preview/app.mjs','work/ui-approved-implementation/ui-preview/pages/reply-dm.mjs','work/ui-approved-implementation/ui-preview/pages/diversified-acquisition.mjs','work/ui-runtime-r55/src/core/adapters.py','work/ui-runtime-r55/src/resources/adapters/douyin.json','work/app/company.json']
for rel in protected:assert sha(S/rel)==sha(Q/rel) and not (O/rel).exists(),rel
old_review=read(S/'work/shared-backend-integration/vendor-src/douyin-connection-review.json');new_review=read(O/'work/shared-backend-integration/vendor-src/douyin-connection-review.json')
assert {k:v for k,v in old_review.items() if k!='materials'}=={k:v for k,v in new_review.items() if k!='materials'}
write('PRESERVATION-AND-CLOSURE.json',{'status':'PASS','exactImmutableBaselineFiles':3332,'onlySourceCandidateFiles':len(rows),'unmodifiedFrozenSourceFiles':3332-9,'sourceAddedFiles':1,'originalEol':eol,'gitPatchAppliedAndReplayedExactBytes':True,'originalCodecBodyUnchanged':True,'originalLegacyBridgeApiAndStartupSuffixUnchanged':True,'reviewedBrowserFunctionEmbeddedExactly':True,'activeConnectionAllFunctionAndClassAstUnchanged':True,'activeConnectionReviewOnlyMaterialsChanged':True,'protectedFiles':[{'path':p,'sha256':sha(S/p)} for p in protected],'originalDmOwnerStoreAccountCasUnknownRetirementAndSharedCustomerClaimEntireSourceUnchanged':True,'ordinaryNativeCacheGuardEntireSourceUnchanged':True,'newNodeOrPythonDependencies':[],'sourceCandidateContainsNoFixtureDbOrCredentials':True})
stage=read(W/'QA-STAGE-PINS.json');stage['label']='dm-controlled-transport-f81-owned-qa-only-not-formal-release';write('QA-STAGE-PINS.json',stage)
# Select fixed final evidence, preserving earlier fixture red and intermediate greens.
factory=[];integrity=[];ui=[]
for d in W.glob('factory-*'):
 if (d/'RESULTS.json').exists() and len(read(d/'RESULTS.json').get('checks',[]))==25:factory.append(d)
 if (d/'INTEGRITY-RESULTS.json').exists():integrity.append(d)
 if (d/'UI-RESULTS.json').exists() and read(d/'UI-RESULTS.json')['status']=='PASS':ui.append(d)
factory=sorted(factory,key=lambda d:d.stat().st_mtime)[-1];integrity=sorted(integrity,key=lambda d:d.stat().st_mtime)[-1];ui=sorted(ui,key=lambda d:d.stat().st_mtime)[-1]
fr=read(factory/'RESULTS.json');assert len(fr['checks'])==25 and read(factory/'FINAL.json')['allOwnServersClosed']
ir=read(integrity/'INTEGRITY-RESULTS.json');assert ir['status']=='PASS' and read(integrity/'FINAL.json')['allOwnServersClosed']
ur=read(ui/'UI-RESULTS.json');assert len(ur['checks'])==33 and not ur['errors'] and read(ui/'FINAL.json')['allOwnServersClosed']
typed=read(W/'TYPED-BRIDGE-RESULTS.json');assert typed['status']=='PASS' and len(typed['checks'])==8
metrics=[{'width':m['width'],'minimumEffectiveFontPx':min(v['effectiveFontPx'] for v in m['values'])} for m in ur['metrics']]
write('VALIDATION-SUMMARY.json',{'status':'PASS_SOURCE_CANDIDATE_SYNTHETIC_ONLY','actualOriginalFactoryHttpCliTypedRouterWholeUserscriptAssertions':25,'factoryDirectory':str(factory),'factoryHttpRequests':len(read(factory/'HTTP.json')),'originalAccountIntegrityAssertions':len(ir['checks']),'integrityDirectory':str(integrity),'typedBridgeAssertions':8,'originalFullIndexFitIframeUiAssertions':33,'uiDirectory':str(ui),'widthsAndFonts':metrics,'allOwnServicesStopped':True,'qaOnlyExplicitSendPermission':fr['positiveSendFixtureConfigOnly'],'syntheticSeams':['original CloudStandin identity/device transport','explicit synthetic original employee device/session lease','own fixture config public holds removed and dm_contract_verified true only for positive send cases','VM page fetch/WebSocket/crypto sign responses; no real platform/session','two local userscript CONFIG literals substituted through original supported markers'],'notClaimed':['real platform send/delivery/read','platform history pagination','XHS DM transport','real IM key/cryptographic compatibility','ordinary frozen EXE/installer of this candidate','full combined live+DM review pins and original account/read factory after root merge'],'realPlatformCalls':0,'realModelCalls':0,'realPlatformBrowserOrNativeOpened':False,'localHeadlessChromiumUiValidation':True,'productionAccess':False,'historicalSentCommentFixtureIsSeededRecordNotNewCommentSend':True,'githubReadOnlySourceRefreshSeparate':True,'retainedRed':{'directory':str(W/'factory-5e8e8498999d482aa379714e07501a5f'),'reason':'Synthetic response reused one platform message ID for two successful sends; original conflict guard correctly paused. Fixed only fixture IDs, product bytes unchanged.'},'uiServerClosureNotes':'Headless page closure generated own HTTP connection-abort traces; browser pageerrors remained empty and own services closed.'})
readme='''固定 F81 的私信受控传输源码候选。只合 source-candidate/ 的10文件；不合 qa-only-project、夹具、数据或证据。

原 DMWorkbench/Core/Store/账号归属、collection/replies 原子模式、草稿核对、稳定客户跨账号预留、unknown 原key、退休账号历史、UI均原字节。新增 typed /api/dm/call 与 /api/dm/result，固定 listen/stop/send；固定 HTTP polling connId、非空原本机 token、严格平台UID、原 requestId。旧脚本/错站点/错sourceDigest无回退；typed结果不能由generic /api/result或WS结果解锁。不接受调用者JS、source或history命令。

客户端经原固定NodeCLI、原BridgeClient/Router/Registry到完整userscript，直接调用静态封定的 reviewed DM 实现；旧protobuf body与旧通用Bridge后缀逐字保留。当前正向仅为合成页面、合成签名/身份/IM响应；没有读真人消息/凭据、打开真实平台页面/本人窗口、发送或调用模型；完整界面使用自有本地headless Chromium。

25个原工厂断言、8个typed合同断言、原完整界面33个断言和原账号组件/CLI反篡改代表通过。界面1255/390，最小文字14.45px；仍称已保存会话/本机记录，平台历史false。两账号同时同UID只有一条进入typed命令，另账号成功私信或旧sent评论阻断批量DM。旧评论sent是明确合成历史记录；本轮未发送评论。

默认发送暂停和dm_contract_verified原值未改。Bridge token只用于本机传输，不是应用业务授权；产品入口仍需原权限/租约/逐条与最终确认。新低层接口不替代原业务层预留。

合版必做：live与DM三向合并共享 client/router/registry 后，统一重算 core.dm_transport.PINS、CLI引用、active连接review/service/SOURCE与MERGED-REPIN-REQUIREMENTS.json列出的旧连接/评论用途材料，再正常freeze并跑原账号/读取工厂。不可把本候选10文件直接当作整个合版已经完成用途审核；不改purpose/material_limits/public_send_grant绕过。当前只精确重绑active vendor连接三pin并通过原_components；旧镜像材料列为合版未完成项。

MIT来源固定 Yht20927/douyin-cli commit4073159bea585de6d33a4747a475669440737932；官方匿名API本轮确认MIT/未归档，原LICENSE/Node/ws许可证保留。无新依赖/整包更新/默认token/模型。真实IM密钥签名、真实平台送达/已读、平台历史分页、小红书可商用DM传输、后继普通编译包都未验证；本候选不放开发送或发布。
'''
(W/'REVIEW.md').write_text(readme,'utf-8')
evidence=[W/'SOURCE-FILES.json',W/'SOURCE.patch',W/'PRESERVATION-AND-CLOSURE.json',W/'MERGED-REPIN-REQUIREMENTS.json',W/'UPSTREAM-REFRESH.json',W/'QA-STAGE-PINS.json',W/'VALIDATION-SUMMARY.json',W/'TYPED-BRIDGE-RESULTS.json',factory/'RESULTS.json',factory/'FINAL.json',factory/'HTTP.json',factory/'BRIDGE-FINAL.json',integrity/'INTEGRITY-RESULTS.json',integrity/'FINAL.json',ui/'UI-RESULTS.json',ui/'UI-FINAL.json',ui/'FINAL.json',W/'REVIEW.md']
write('FINAL-RECEIPT.json',{'status':'PASS_CONTROLLED_TRANSPORT_SOURCE_CANDIDATE_ONLY','generatedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseline':str(S),'baselineUnifiedSha256':sha(F/'UNIFIED-PINS.json'),'sourceOnlyDirectory':str(O),'sourceFiles':10,'sourceManifestSha256':sha(W/'SOURCE-FILES.json'),'patchSha256':sha(W/'SOURCE.patch'),'actualOriginalFactoryAssertions':25,'actualTypedBridgeAssertions':8,'actualOriginalFullIndexUiAssertions':33,'actualOriginalIntegrityAssertions':len(ir['checks']),'evidence':[{'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size} for p in evidence],'allOwnServicesStopped':True,'realPlatformOrModelCalls':0,'canonicalWrites':False,'installed':False,'mergedLiveDmRepinAndIndependentReviewRequired':True,'notValidated':read(W/'VALIDATION-SUMMARY.json')['notClaimed']})
files=[*evidence,W/'FINAL-RECEIPT.json',*[O/r['path'] for r in rows]]
write('SEALED.json',{'status':'SEALED_STOP_WRITING','finalReceiptSha256':sha(W/'FINAL-RECEIPT.json'),'sourceManifestSha256':sha(W/'SOURCE-FILES.json'),'patchSha256':sha(W/'SOURCE.patch'),'files':[{'path':str(p.relative_to(W)),'sha256':sha(p),'bytes':p.stat().st_size} for p in files]})
print(json.dumps({'FINAL':sha(W/'FINAL-RECEIPT.json'),'SEALED':sha(W/'SEALED.json'),'SOURCE':sha(W/'SOURCE-FILES.json'),'PATCH':sha(W/'SOURCE.patch'),'factory':str(factory),'ui':str(ui)},ensure_ascii=False))
