from pathlib import Path
import ast,hashlib,json
D=Path(__file__).resolve().parent;W=D.parent;sha=lambda b:hashlib.sha256(b).hexdigest()
review=W/'v75-canonical-entry-independent-review/FINAL-RECEIPT.json'
assert sha(review.read_bytes())=='7042c975b96c2dab2740c21d857e4970aa1a232d8b3e54ee41a668355b78e225'
receipt=json.loads(review.read_text('utf-8'));assert receipt['rootMayEnableOnlyReviewedBooleanForSamePins'] is True
entry=D/'install_verified_entry.py';raw=entry.read_bytes();assert sha(raw)=='bff2a7df875119f61fe820e90b96ee652e7f5af0cab559238ea711cf8326cb2e'
needle=b'INSTALLATION_REVIEWED = False';assert raw.count(needle)==1
new=raw.replace(needle,b'INSTALLATION_REVIEWED = True')
oldtree,newtree=ast.parse(raw.decode()),ast.parse(new.decode());changes=[]
for a,b in zip(oldtree.body,newtree.body):
 if ast.dump(a,include_attributes=False)!=ast.dump(b,include_attributes=False):changes.append(a)
assert len(changes)==1 and isinstance(changes[0],ast.Assign) and changes[0].targets[0].id=='INSTALLATION_REVIEWED'
(D/'ENTRY-BEFORE-ROOT-APPROVAL.py').write_bytes(raw);entry.write_bytes(new)
out={'status':'ROOT_APPROVED_ONLY_EXISTING_DEVICE_ACCOUNT_CUSTOMER_READ_RECOVERY_NEXT_LAUNCH',
 'reviewSha256':sha(review.read_bytes()),'beforeSha256':sha(raw),'afterSha256':sha(new),'onlyReviewedBooleanChanged':True,
 'preexistingConcurrencyRedRetained':True,'fullConcurrencyAccepted':False,'commercialOrPublicDistributionApproved':False,
 'canonicalWrittenByThisScript':False}
(D/'ROOT-ENTRY-APPROVAL.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out))
