from pathlib import Path
import ast,hashlib,json
W=Path(__file__).resolve().parents[1]
S=W.parents[1]/'work/parallel-integration-20261018/final-integration/stage-02/project'
N=S/'work/ui-native-r57';K=W/'keyword-effect-candidate';D=W/'delivery-v67';B=D/'keyword-before';B.mkdir(exist_ok=True)
def sha(raw):return hashlib.sha256(raw).hexdigest()
assert sha((K/'keyword-effect.patch').read_bytes())=='6edfb67df1ecdd066a803d0f90b9824a528dd0f13b75ca96d9e51446225c0dd3'
module=(K/'candidate/work/ui-native-r57/keyword_effect_workbench.py').read_bytes()
assert sha(module)=='ba4785c7379aadc8ee93bc6bbb62f6cdd4eaaeb7a76fb9379b568fb51284419d'
expected={'workbench_backend.py':'b11974587a9c91a7ae9b3afbfbd51b739d898358ab5aa6416bc0c6733a2ce2ef',
'ui_native_host.py':'d96298bf289780cf2067941e089884fdf179f0f31cd58234852536308513ae0b',
'freeze_ui.py':'a678fe28872cd1fe065f303cf3026abaa1624b26a45baad66aa77ab2ec085b38'}
inputs={name:(N/name).read_bytes() for name in expected}
assert {name:sha(raw) for name,raw in inputs.items()}==expected
assert not (N/'keyword_effect_workbench.py').exists()
for name,raw in inputs.items():
 assert not (B/name).exists(),'Backup already exists; inspect instead of reapplying'
 (B/name).write_bytes(raw)
(B/'keyword_effect_workbench.absent.json').write_text('{"absent":true}',encoding='utf-8')
tree=ast.parse((K/'prepare_native.py').read_bytes())
pairs={ast.literal_eval(n.value.args[0]):ast.literal_eval(n.value.args[1]) for n in tree.body
 if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name) and n.value.func.id=='change'}
changes=[];outputs={}
for name,raw in inputs.items():
 newline='\r\n' if b'\r\n' in raw else '\n';original=raw.decode().replace('\r\n','\n');value=original;applied=[]
 for index,(old,new) in enumerate(pairs[name]):
  source_old,source_new=old,new;adaptation=None
  if name=='workbench_backend.py' and index==0:
   old="'customer_intent_cancel'})";new="'customer_intent_cancel','keyword_effect_read'})";adaptation='Union keyword action with existing three correction actions'
  if name=='ui_native_host.py' and index==2:
   old="    for extra in ('customer_intent_workbench.py',";new="    for extra in ('customer_intent_workbench.py','keyword_effect_workbench.py',";adaptation='Preserve existing intent helper in extra-file closure'
  assert value.count(old)==1,(name,index,old[:90],value.count(old))
  value=value.replace(old,new,1);applied.append((old,new))
  changes.append(dict(file=name,candidateChangeIndex=index,candidateOldSha256=sha(source_old.encode()),candidateNewSha256=sha(source_new.encode()),actualOldSha256=sha(old.encode()),actualNewSha256=sha(new.encode()),adaptation=adaptation))
 check=value
 for old,new in reversed(applied):
  assert check.count(new)==1,(name,'reverse count',new[:80]);check=check.replace(new,old,1)
 assert check==original,'Prior overlay bytes not preserved'
 output=value.replace('\n',newline).encode();compile(output,str(N/name),'exec');outputs[name]=output
compile(module,str(N/'keyword_effect_workbench.py'),'exec')
for name,raw in outputs.items():
 assert (N/name).read_bytes()==inputs[name],'Source changed while holding lock'
 (N/name).write_bytes(raw)
(N/'keyword_effect_workbench.py').write_bytes(module)
record=dict(status='KEYWORD_EFFECT_REVIEWED_MERGE_STAGE_ONLY',source=str(S),productionModified=False,
    sealedPatchSha256=sha((K/'keyword-effect.patch').read_bytes()),preservedPriorOverlaysByReverseReconstruction=True,
    preserved=['v3 full method pins','interaction inbox actions/dispatch','manual intent actions/factory/dispatch/host helper/freezer'],
    files=[dict(path='work/ui-native-r57/'+name,before=sha(inputs[name]) if name in inputs else None,after=sha(raw)) for name,raw in {**outputs,'keyword_effect_workbench.py':module}.items()],changes=changes)
(D/'KEYWORD-EFFECT-MERGE.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(record,ensure_ascii=False))
