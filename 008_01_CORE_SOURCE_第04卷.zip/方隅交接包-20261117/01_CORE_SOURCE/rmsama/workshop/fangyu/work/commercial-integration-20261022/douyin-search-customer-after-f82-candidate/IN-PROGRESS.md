# 抖音客户只读关键词用途

仅在本目录构造后继候选；精确依赖已经封定的 customer-read-purpose-after-f82-candidate。普通关键词单页搜索沿原 PlatformReadService、DouyinSearchPolicy、owned_search、Adapters 与 Node Bridge，不使用账号连接或评论用途冒充搜索许可。

计划只修改共享 carrier 独立搜索 registry/limits/materials 与 canonical 搜索 policy 的受信 customer 分支。旧 internal review、所有读写/租户/门店/员工/设备/停止/自然登录守卫保留。真实平台、Native 浏览器、生产数据、自动回复均不执行。

代表链：原 create_backend → 原 cloud bind/DPAPI/DeviceSession → 原产品 HTTP → 原搜索 typed call → 实际 Node CLI/Router/Registry/Client/完整 userscript → 仅自有页面 VM。当前未完成，不能作正式分发或真实平台验收。
