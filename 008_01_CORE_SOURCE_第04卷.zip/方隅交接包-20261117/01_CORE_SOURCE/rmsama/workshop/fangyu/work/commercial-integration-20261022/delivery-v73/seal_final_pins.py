from pathlib import Path
import hashlib,json
D=Path(__file__).resolve().parent;P=D.parents[2]
C=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v73'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(C/'UNIFIED-PINS.json')=='c0a72be807965903a5cbb9dfee9ba6549a6157ccf622fd7df86a9ef1397a167b'
staged=json.loads((C/'STAGED.json').read_text('utf-8'))
release=Path(staged['release']);assert release.resolve().is_relative_to((C/'project').resolve())
manifest=json.loads((release/'RELEASE.json').read_text('utf-8'))
assert staged['files']==len(manifest['files'])==198
assert len(json.loads((C/'UNIFIED-PINS.json').read_text('utf-8'))['files'])==3156
assert sha(release/'RELEASE.json')==staged['manifest_sha256'].lower()
assert sha(Path(staged['launcher']))==staged['launcher_sha256'].lower()
pins={'rootExplicitFinalPins':True,'candidate':C.name,
      'unifiedPinsSha256':sha(C/'UNIFIED-PINS.json'),'stagedSha256':sha(C/'STAGED.json'),
      'manifestSha256':sha(release/'RELEASE.json'),'releaseId':staged['release_id'],
      'unifiedFileCount':3156,'releaseFileCount':198,'launcherSha256':sha(Path(staged['launcher']))}
out=D/'FINAL-PINS.json';assert not out.exists();out.write_text(json.dumps(pins,indent=2)+'\n',encoding='utf-8')
print(json.dumps(pins))
