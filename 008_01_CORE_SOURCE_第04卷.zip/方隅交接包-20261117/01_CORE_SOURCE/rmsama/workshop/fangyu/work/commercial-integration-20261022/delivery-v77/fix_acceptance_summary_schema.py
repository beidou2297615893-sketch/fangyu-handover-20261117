from pathlib import Path
import ast,hashlib,json,shutil
D=Path(__file__).resolve().parent;Q=D/'frozen-native';R=D/'entry-schema-red'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
entry=D/'install_verified_entry.py';summary=Q/'SUMMARY.json'
assert sha(entry)=='c80b77134208bebfb1862994a2328b19c09c76f1fe9e718f46a278d13c288de9'
assert sha(summary)=='dd7c50e0f25692c4641aeab1a1606253d9930e9db46134df8d454f404484c53c'
assert not R.exists();R.mkdir()
for path in (entry,summary,D/'ENTRY-FILLED.json'):shutil.copyfile(path,R/path.name)
data=json.loads(summary.read_text('utf-8'));assert data['testExecutionProductionAccess'] is False and 'productionAccess' not in data
data['productionAccess']=False
data['productionAccessFieldScope']='Compatibility alias for isolated test execution only; real production baseline was separately read-only and is explicitly recorded above.'
summary.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
text=entry.read_text('utf-8');before=ast.parse(text)
node=next(n for n in before.body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='ACCEPTED')
accepted=ast.literal_eval(node.value);assert set(accepted)=={'candidate-unified-v77'}
accepted['candidate-unified-v77']['evidence']['frozen-native/SUMMARY.json']=sha(summary)
lines=text.splitlines(keepends=True);lines[node.lineno-1:node.end_lineno]=['ACCEPTED = '+repr(accepted)+'\n'];text=''.join(lines)
after=ast.parse(text)
functions=lambda t:{n.name:ast.dump(n,include_attributes=False) for n in t.body if isinstance(n,ast.FunctionDef)}
assert functions(before)==functions(after)
entry.write_text(text,encoding='utf-8')
filled=json.loads((D/'ENTRY-FILLED.json').read_text('utf-8'))
filled.update(entrySha256=sha(entry),summarySha256=sha(summary))
filled['evidence']['frozen-native/SUMMARY.json']=sha(summary)
filled['schemaCompatibilityFix']='Restored original installer acceptance productionAccess test-only field; no function, guard, test or product change.'
(D/'ENTRY-FILLED.json').write_text(json.dumps(filled,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
out={'status':'SUMMARY_SCHEMA_COMPATIBILITY_CORRECTED_INSTALLATION_STILL_DISABLED','entrySha256':sha(entry),'summarySha256':sha(summary),'redRetained':True,'allInstallerFunctionsUnchanged':True,'canonicalOrProductWritten':False}
(D/'SUMMARY-SCHEMA-CORRECTION.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8');print(json.dumps(out))
