from pathlib import Path
import difflib,hashlib,json,shutil
C=Path(__file__).resolve().parent;W=C.parent;P=C.parents[2]
F=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v82';S=F/'project'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
pins={'STAGED.json':'58581f4644aaf17bea481dd45d6ef19713bf6bdf97a303ffd790be940bb7c958','UNIFIED-PINS.json':'36a601743288689d6cff3159337ee4f548d1ee0d05366a28a83dd683a326f500'}
for name,want in pins.items():assert sha(F/name)==want
root=W/'next-release-f81-expansion-composition/FROZEN-INPUTS.json';assert sha(root)=='ea024e9a6742b81f62510a25f6c47c9bd48dcea70bc57c0481dfe6ee09ba636e'
stage=json.loads((F/'STAGED.json').read_text('utf-8-sig'));R=Path(stage['release']);assert R.is_relative_to(S)
assert sha(R/'RELEASE.json')=='d563f95ffe26cfef9c3d0034a17a84b0b730fa02ed32ccb86f10cfd3d4d20160'
unified=json.loads((F/'UNIFIED-PINS.json').read_text('utf-8-sig'));assert len(unified['files'])==3856
for row in unified['files']:assert (S/row['path']).stat().st_size==row['bytes'] and sha(S/row['path'])==row['sha256']
for name in pins:shutil.copyfile(F/name,C/('F82-'+name))
shutil.copyfile(root,C/'ROOT-FROZEN-INPUTS.json')
rows=[];diff=[]
def adapt(origin,name,replacements=()):
 p=W/origin;before=p.read_bytes();text=before.decode('utf-8-sig')
 for old,new in replacements:
  assert old in text,(name,old);text=text.replace(old,new)
 (C/name).write_text(text,'utf-8')
 rows.append({'origin':str(p),'path':name,'beforeSha256':sha(p),'afterSha256':sha(C/name)})
 diff.extend(difflib.unified_diff(before.decode('utf-8-sig').splitlines(True),text.splitlines(True),fromfile='original/'+name,tofile='adapted/'+name))
stageexpr='json.loads((W/\'F82-STAGED.json\').read_text(\'utf-8-sig\'))'
adapt('guided-manual-f81-independent-review/test_independent_factory.py','test_manual_factory.py',[("S=A/'project'",'S=Path('+repr(str(S))+')'),("json.loads((A/'BACKEND-STAGE.json').read_text('utf-8'))",stageexpr)])
adapt('content-experience-f81-independent-review/test_experience_factory.py','test_experience_factory.py',[("S=Path(json.loads((W/'BASELINE.json').read_text('utf-8'))['manualProject']) if RED else W/'project'",'S=Path('+repr(str(S))+')'),("json.loads((W/('BASELINE-STAGE.json' if RED else 'BACKEND-STAGE.json')).read_text('utf-8'))",stageexpr)])
public=W/'expansion-f82-public-joint-regression'
for name in ['run_against_final.py','test_public_factory.py','test_dependency_guard.py','serve_ui.py','test_ui_minimal.mjs','DDGS-RAW-RESPONSE.html','DDGS-PUBLIC-SAMPLE.json']:
 shutil.copyfile(public/name,C/name);rows.append({'origin':str(public/name),'path':name,'beforeSha256':sha(public/name),'afterSha256':sha(C/name),'byteEqual':True})
adapt('content-experience-f81-independent-review/serve_experience_ui.py','serve_content_ui.py',[("S=W/'project'",'S=Path('+repr(str(S))+')'),("json.loads((W/'BACKEND-STAGE.json').read_text('utf-8'))",stageexpr)])
release=json.loads((R/'RELEASE.json').read_text('utf-8-sig'))
(C/'ADAPTATION.patch').write_text(''.join(diff),'utf-8')
(C/'INPUT-GATE.json').write_text(json.dumps({'status':'PINNED_READ_ONLY_F82','project':str(S),'stagePath':str(F/'STAGED.json'),'stageSha256':pins['STAGED.json'],'unifiedSha256':pins['UNIFIED-PINS.json'],'releaseManifestSha256':sha(R/'RELEASE.json'),'sourceFilesVerified':3856,'resources':538,'rootReceiptSha256':sha(root),'fixtureCopies':rows,'assertionsChanged':False,'writesFormalProject':False},ensure_ascii=False,indent=2),'utf-8')
print(json.dumps({'gate':'PASS','project':str(S),'release':str(R),'fixtures':len(rows)}))
