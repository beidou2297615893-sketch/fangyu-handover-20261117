"""A private task lifetime over the original two independently reviewed reads.

No public task field creates this scope. Core still owns leases, pipeline,
filtering, import, stable-source deduplication and subsequent AI queues.
"""
from contextlib import contextmanager
from copy import deepcopy
import hashlib
import json
import threading
import time
from . import CoreError
from .douyin_comments_policy import _digest
from .platform_reads import PlatformReadService

_LOCAL=threading.local()
_ENTITY='douyin_customer_task_read_pages_v1'
_TASK_FIELDS=('id','tenant_id','cloud_owner','store_id','account_id','platform','scope',
    'keywords','daily_limit','target_count','search_pages','comment_depth','source_ref',
    'strategy_source','created_at','continuous_enabled')
_ACCOUNT_FIELDS=('id','tenant_id','cloud_owner','store_id','platform','platform_uid','conn_id','status')
_ACTOR=('id','tenant_id','username','role','cloud_bound','disabled')
NOTICE='本次只读范围为每个关键词的搜索首屏及每个视频的主评论第一页；后续页保持断点，不自动重试未知结果。'


def current(adapters):
    scope=getattr(_LOCAL,'scope',None)
    return scope if type(scope) is _TaskReadScope and scope.core.adapters is adapters else None


def customer_task_action(executor,action,data,user):
    """Avoid XHS's global hold only for this separately checked Douyin task.

    This local admission is not first-search verification. The original typed
    read checks the live UID before and after the actual page request.
    """
    if action not in ('task_save','task_run','task_resume'):return False
    try:
        server=executor.server
        if server._customer_distribution_purpose('douyin_owned_keyword_search_page') is None:return False
        if server._customer_distribution_purpose('douyin_owned_video_comments') is None:return False
        if server._douyin_search_policy.resolve() is None or server._douyin_comments_policy.resolve() is None:return False
        task=data if action=='task_save' else executor.core._get('tasks',data.get('task_id'),executor.tenant)
        if task.get('platform')!='douyin':return False
        if action!='task_save':executor.core._task_access(user,task,executor.tenant)
        from assistant.douyin_connection_service import _binding
        actor,owner,session,device,account,stored=_binding(server.assistant_service,task.get('account_id'))
        executor.core._account_access(user,account);server._platform_execution_guard('douyin')
        return owner is executor and actor['id']==user['id'] and account.get('platform')=='douyin'
    except (ValueError,RuntimeError,OSError,KeyError,TypeError):return False


class _TaskReadScope:
    def __init__(self,executor,user,task):
        self.executor,self.server,self.core=executor,executor.server,executor.core
        self.user=deepcopy(user);self.task_id=task['id'];self.thread=threading.get_ident()
        self.task_digest=_digest({key:task.get(key) for key in _TASK_FIELDS})
        self.active=True
        self.search=self.server._douyin_search_policy
        self.comments=self.server._douyin_comments_policy
        from assistant.douyin_connection_service import _binding
        actor,owner,session,device,account,stored=_binding(self.server.assistant_service,task['account_id'])
        if any(actor.get(key)!=user.get(key) for key in ('id','tenant_id','username','role','cloud_bound')):
            raise CoreError('采集员工身份与原设备不一致')
        self.session,self.device,self.account_id=session,device,account['id']
        self.actor=_digest({key:actor.get(key) for key in _ACTOR})
        self.account=_digest({key:account.get(key) for key in _ACCOUNT_FIELDS})
        self.reads=PlatformReadService(self.core,executor.tenant,executor.owner,
            device_id=device,execution_guard=self.server._platform_execution_guard,
            douyin_comments_policy=self.comments,douyin_search_policy=self.search)
        self.check()

    def check(self,*,dispatch=False):
        from assistant.douyin_connection_service import _binding
        if not self.active or self.thread!=threading.get_ident():raise CoreError('原采集读取范围已结束')
        actor,owner,session,device,account,stored=_binding(self.server.assistant_service,self.account_id)
        task=self.core._get('tasks',self.task_id,self.executor.tenant)
        self.core._task_access(actor,task,self.executor.tenant);self.core._account_access(actor,account)
        self.server._platform_execution_guard('douyin')
        mode=self.core.account_mode_status(account['id'],self.executor.tenant)
        if (owner is not self.executor or session is not self.session or device!=self.device
                or self.server.assistant_service.executor is not self.executor
                or _digest({key:actor.get(key) for key in _ACTOR})!=self.actor
                or _digest({key:account.get(key) for key in _ACCOUNT_FIELDS})!=self.account
                or _digest({key:task.get(key) for key in _TASK_FIELDS})!=self.task_digest
                or task.get('platform')!='douyin' or task.get('scope') not in ('search','search_comments','comments')
                or task.get('status')=='paused' or task.get('account_removed')
                or mode.get('mode')!='collection' or mode.get('status')!='active'
                or mode.get('owner')!='batch:'+self.task_id
                or mode.get('runtime_id')!=self.core.continuous.leases.runtime_id
                or self.server._customer_distribution_purpose('douyin_owned_keyword_search_page') is None
                or self.search.resolve() is None or self.comments.resolve() is None
                or self.server._customer_distribution_purpose('douyin_owned_video_comments') is None
                or dispatch and self.task_id not in self.core.running):
            raise CoreError('原采集任务、账号、设备、门店或只读用途已变化；断点保留')
        return actor,account

    def _record(self,db,ident):
        row=db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
            (_ENTITY,ident,self.executor.tenant)).fetchone()
        return json.loads(row['body']) if row else None

    def read(self,operation,query):
        actor,account=self.check(dispatch=True)
        if operation not in ('search','comments') or query.get('id')!=self.task_id:
            raise CoreError('本次只读操作不属于原采集任务')
        if (query.get('next_page',1)!=1 or query.get('next_cursor') not in ('',None,'0')
                or operation=='search' and (type(query.get('keywords')) is not list
                    or len(query['keywords'])!=1 or type(query['keywords'][0]) is not str
                    or not 1<=len(query['keywords'][0])<=200
                    or any(ord(c)<32 or ord(c)==127 for c in query['keywords'][0]))):
            raise CoreError('本次只读用途仅开放搜索首屏和主评论第一页；其余断点已保留')
        child=deepcopy(query)
        child.update(id='',daily_limit=min(20,int(query.get('daily_limit',20))),next_page=1,
            next_cursor='',comment_depth='main',max_pages=1)
        if child['daily_limit']<1:raise CoreError('单次读取数量无效')
        inputs=[operation,child.get('keywords') if operation=='search' else child.get('note_url'),
            0,child['daily_limit']]
        binding={'task':self.task_id,'task_digest':self.task_digest,'account':self.account,
            'actor':self.actor,'device':self.device,'inputs':inputs}
        ident=hashlib.sha256(json.dumps(binding,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
        child['id']='dyt-'+ident[:32]
        policy=self.search if operation=='search' else self.comments
        revision=policy.resolve()['revision']
        with self.core.lock,self.core.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            old=self._record(db,ident)
            if old is not None:
                if (old.get('binding')!=binding or old.get('cloud_owner')!=self.executor.owner
                        or old.get('revision')!=revision or old.get('state')!='completed'):
                    raise CoreError('原只读结果尚未确认或用途已变化；请核对原任务，未重新请求平台')
                # A known successful read may finish its original Core import
                # after restart. Re-authorize first; never replay an unknown.
                query['_page_info']=deepcopy(old['page'])
                return deepcopy(old['rows'])
            record={'id':ident,'tenant_id':self.executor.tenant,'cloud_owner':self.executor.owner,
                'binding':binding,'revision':revision,'state':'started','created_at':time.time()}
            db.execute('INSERT INTO records VALUES(?,?,?,?)',(_ENTITY,ident,self.executor.tenant,
                json.dumps(record,ensure_ascii=False)))
        entry={'account_id':account['id'],'cancelled':False,'fingerprint':_digest(inputs),
            'operation_id':child['id'],'running':True,
            'origin':self.reads._origin(actor,account,_digest(inputs),operation)}
        self.reads._operations[ident]=entry
        try:
            if operation=='search':
                from .douyin_owned_search import owned_search
                with owned_search(self.reads,entry,actor,account,child,policy):
                    rows=self.core.adapters.search('douyin',child)
            else:
                from .douyin_owned_comments import owned_comments
                with owned_comments(self.reads,entry,actor,account,child,policy):
                    rows=self.core.adapters.comments('douyin',child)
            self.check(dispatch=True)
            if (type(rows) is not list or len(rows)>child['daily_limit']
                    or len(json.dumps(rows,ensure_ascii=False).encode())>1048576
                    or policy.resolve() is None or policy.resolve()['revision']!=revision):
                raise CoreError('原只读页数量、材料或归属尚未核实；未导入')
            page=deepcopy(child.get('_page_info',{}));page['bounded']=True
            with self.core.lock,self.core.store.connect() as db:
                db.execute('BEGIN IMMEDIATE');current_record=self._record(db,ident)
                if current_record!=record:raise CoreError('原只读回执已变化；未确认本次结果')
                record.update(state='completed',rows=rows,page=page,completed_at=time.time())
                db.execute('UPDATE records SET body=? WHERE entity=? AND id=? AND tenant_id=?',
                    (json.dumps(record,ensure_ascii=False),_ENTITY,ident,self.executor.tenant))
            query['_page_info']=page
            return rows
        finally:
            entry['running']=False


@contextmanager
def collection_scope(executor,user,task):
    server=executor.server
    if (task.get('platform')!='douyin'
            or server._customer_distribution_purpose('douyin_owned_keyword_search_page') is None):
        yield None
        return
    if getattr(_LOCAL,'scope',None) is not None:raise CoreError('原只读采集范围尚未结束')
    scope=_TaskReadScope(executor,user,task);_LOCAL.scope=scope
    try:yield scope
    finally:scope.active=False;_LOCAL.scope=None
