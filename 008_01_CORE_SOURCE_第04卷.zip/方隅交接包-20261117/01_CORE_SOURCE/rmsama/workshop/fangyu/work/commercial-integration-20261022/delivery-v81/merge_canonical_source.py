from pathlib import Path
import hashlib,json,os,sys,uuid
D=Path(__file__).resolve().parent;W=D.parent;P=D.parents[2]
F=P/'work/parallel-integration-20261018/final-integration'
S=F/'stage-02/project';B=F/'candidate-unified-v80/project';N=F/'candidate-unified-v81/project'
sha=lambda b:hashlib.sha256(b).hexdigest()
composition=json.loads((W/'scanned-pdf-f80-integration/COMPOSITION.json').read_text('utf-8'))
paths=sorted(r['path'] for r in composition['files'])
rows=[]
for relative in paths:
    p=S/relative;old=p.read_bytes() if p.exists() else None
    base=(B/relative).read_bytes() if (B/relative).exists() else None
    assert old==base, 'Concurrent canonical source difference: '+relative
    for q in (p,*p.parents):
        if q.exists():assert not q.is_symlink() and not getattr(q.lstat(),'st_file_attributes',0)&0x400
    new=(N/relative).read_bytes()
    rows.append({'path':relative,'beforeSha256':sha(old) if old is not None else None,
                 'afterSha256':sha(new),'existed':old is not None})
if '--apply' not in sys.argv:
    target=D/'SOURCE-MERGE-PREPARED.json';assert not target.exists()
    target.write_text(json.dumps({'status':'PREPARED_NOT_WRITTEN','sourcePaths':len(rows),'rows':rows,'installedRuntimeWritten':False},indent=2),'utf-8')
    print(json.dumps({'status':'PREPARED_ONLY','sourcePaths':len(rows)}));raise SystemExit
expected=json.loads((D/'SOURCE-MERGE-PREPARED.json').read_text('utf-8'));assert expected['rows']==rows
backup=D/'source-before';assert not backup.exists();backup.mkdir()
for row in rows:
    p=S/row['path']
    if row['existed']:
        q=backup/row['path'];q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(p.read_bytes())
for row in rows:
    p=S/row['path'];p.parent.mkdir(parents=True,exist_ok=True)
    assert (sha(p.read_bytes()) if p.exists() else None)==row['beforeSha256']
    tmp=p.with_name(p.name+'.source-'+uuid.uuid4().hex+'.tmp')
    raw=(N/row['path']).read_bytes();assert sha(raw)==row['afterSha256']
    with tmp.open('xb') as stream:stream.write(raw)
    os.replace(tmp,p)
assert all(sha((S/r['path']).read_bytes())==r['afterSha256'] for r in rows)
(D/'SOURCE-MERGE-APPLIED.json').write_text(json.dumps({'status':'CANONICAL_SOURCE_INCREMENTALLY_MERGED_WITH_EXACT_BACKUPS','rows':rows,'installedRuntimeWritten':False,'productionDataAccess':False},indent=2),'utf-8')
print(json.dumps({'status':'SOURCE_MERGED_INSTALLED_RUNTIME_UNCHANGED','sourcePaths':len(rows)}))
