from pathlib import Path
import ast,hashlib,json
W=Path(__file__).resolve().parent;B=W.parent;Old=B/'expansion-f79-joint-regression';C=B/'scanned-pdf-f79-candidate';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rows=[]
for name in ['final_inputs.py','activate.py','run_regression.py','test_shared_context_final_http.py','test_contacts_final_http.py','test_knowledge_final_http.py','test_schedule_final_http.py','test_account_factory.py','test_keyword_composition.cjs']:
 src=Old/name;dst=W/name;assert not dst.exists();dst.write_bytes(src.read_bytes());rows.append({'path':name,'before':sha(src),'after':sha(dst),'adaptation':'byte-identical; only new ACTIVATION selects actual F81'})
src=C/'serve_ui.py';before=src.read_text('utf-8');old="W=Path(__file__).resolve().parent;P=W.parents[2];stage=json.loads((W/'QA-STAGE.json').read_text('utf-8'));S=W/'project';R=Path(stage['release']);out="
new="W=Path(__file__).resolve().parent;P=W.parents[2]\nfrom final_inputs import load_verified\nROOT_PINS,F,S,stage,R=load_verified()\nout="
assert before.count(old)==1;after=before.replace(old,new);(W/'serve_scan_ui.py').write_text(after,'utf-8');ast.parse(after);rows.append({'path':'serve_scan_ui.py','before':sha(src),'after':sha(W/'serve_scan_ui.py'),'adaptation':'one project/stage header; original factory, permission and UI setup unchanged'})
(W/'test_scan_ui.mjs').write_bytes((C/'test_ui.mjs').read_bytes());rows.append({'path':'test_scan_ui.mjs','before':sha(C/'test_ui.mjs'),'after':sha(W/'test_scan_ui.mjs'),'adaptation':'byte-identical original16 full index/fit checks'})
assert sha(C/'SEALED.json')=='6229ce0a482fd92c89d496e09df1a517ee02074de617c29487db139c36ab5ba7'
sample=json.loads((C/'SAMPLE-INPUTS.json').read_text('utf-8'));samples=[]
for name in ['扫描一页.pdf','扫描两页.pdf','附件扫描.pdf']:
 p=C/'samples'/name;r=next(x for x in sample['files'] if x['path']==name);assert sha(p)==r['sha256'];dst=W/'samples'/name;dst.parent.mkdir(exist_ok=True);dst.write_bytes(p.read_bytes());samples.append({'path':name,'sha256':sha(dst),'bytes':dst.stat().st_size})
(W/'SAMPLE-INPUT-PINS.json').write_text(json.dumps(samples,ensure_ascii=False,indent=2)+'\n','utf-8')
# This checker preserves the original verify/read_public/backend dependency
# chain; replacements below are fixed F81 input names/counts only.
s=(Old/'verify_f80_closure.py').read_text('utf-8').replace("'ad24e091a0a2be1fe1e30b9ea75fb20709e05d49e6b49f9b4a3b63298e62757f'","'306fde02917f0f52bd0788069c56a802fbeb1a6ae428209533ea056c6e7a368c'").replace("root['fileCount']==3328","root['sourceFiles']==3332").replace("root['resourceCount']==282","root['resources']==284").replace('PASS_F80_ACTUAL_COMPLETE_CLOSURE','PASS_F81_ACTUAL_COMPLETE_CLOSURE')
(W/'verify_f81_closure.py').write_text(s,'utf-8')
(W/'PREPARATION.json').write_text(json.dumps({'status':'PREPARED_NEW_F81_FIXED_INPUT_RUN','fixtureFiles':rows,'samples':samples,'formalFrozenResourcesWillNotBeModified':True,'authorResourceTamperFactoryGroupNotCopied':True},ensure_ascii=False,indent=2)+'\n','utf-8');print(json.dumps({'copiedFixtureFiles':len(rows),'samplesShaVerified':3,'assertionsChanged':False}))
