from pathlib import Path
from datetime import datetime,timezone
import ctypes,hashlib,json
from ctypes import wintypes
D=Path(__file__).resolve().parent;P=D.parents[2]
N=P/'work/ui-native-r57'
pins=json.loads((D/'FINAL-PINS.json').read_text('utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(N/'run_workbench.py')=='ee6c06f25c9cacd5927bd3c90f6246da184150aee101f59db19e222d4eea8797'
assert sha(N/'FROZEN.json')=='9da70aed55d22c33b1e76ebb2362defcaaf61a7f25feea64e3542919ab929160'
assert sha(N/'state/production-workspace.json')=='14cf53964f5d44d123e989805ea741669ab3f05054e730ddcb299a0aac51a9cb'
matches=[]
for p in (N/'state/launches').glob('*.json'):
    v=json.loads(p.read_text('utf-8-sig'))
    if v.get('release_id')==pins['releaseId'] and v.get('stage')=='native_ready':matches.append((p,v))
assert matches
path,status=max(matches,key=lambda x:x[0].stat().st_mtime_ns)
assert status['pid']==66168 and status['renderer']=='edgechromium' and status['business_connected'] is True
dom=status['dom'];assert dom['page']=='login' and dom['ready_state']=='complete' and dom['font_status']=='loaded'
assert dom['primary_present'] and dom['app_children']>0
assert dom['images']=={'total':6,'pending':0,'failed':0}
assert dom['fit']['covers_viewport'] and dom['viewport']['scroll_width']<=dom['viewport']['width']+1
k=ctypes.WinDLL('kernel32',use_last_error=True)
k.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD];k.OpenProcess.restype=wintypes.HANDLE
k.GetExitCodeProcess.argtypes=[wintypes.HANDLE,ctypes.POINTER(wintypes.DWORD)];k.GetExitCodeProcess.restype=wintypes.BOOL
k.CloseHandle.argtypes=[wintypes.HANDLE];k.CloseHandle.restype=wintypes.BOOL
for pid in (19036,66168):
    handle=k.OpenProcess(0x1000,False,pid);assert handle,('Process is no longer alive',pid)
    try:
        code=wintypes.DWORD();assert k.GetExitCodeProcess(handle,ctypes.byref(code)) and code.value==259,pid
    finally:k.CloseHandle(handle)
after=json.loads((D/'PROTECTED-BUSINESS-AFTER-INSTALL.json').read_text('utf-8'))
assert after['status']=='PASS_PROTECTED_BUSINESS_UNCHANGED' and after['sameAsBeforeInstall']
assert all(r['sameAsVerifiedBackup'] for r in after['protectedTablesAndEntities'].values())
target=D/'ACTUAL-CANONICAL-NATIVE-STATUS.json';assert not target.exists();target.write_bytes(path.read_bytes())
result={'status':'PASS_ACTUAL_INSTALLED_V72_NATIVE_AND_PROTECTED_CUSTOMERS','verifiedAtUtc':datetime.now(timezone.utc).isoformat(),'candidate':pins['candidate'],'releaseId':pins['releaseId'],
    'launcherPid':19036,'actualNativePid':66168,'parentChildRelationshipObserved':True,'bothProcessesStillAlive':True,'stablePort':status['port'],'developmentPort':status['development_port'],
    'canonicalLauncherSha256':sha(N/'run_workbench.py'),'canonicalFrozenSha256':sha(N/'FROZEN.json'),'bindingSha256':sha(N/'state/production-workspace.json'),
    'canonicalCheck':'PASS actual --check; 196 resources and pywebview6.2.1; no business construction during check',
    'canonicalStaticSelfTest':'PASS actual --self-test; 129 checks over117 public URLs, no Native window or business construction during self-test',
    'actualNative':{'renderer':status['renderer'],'page':'login','fontLoaded':True,'allSixImagesLoaded':True,'viewport':dom['viewport'],'fitCoversViewport':True,'localBusinessBackendConstructed':True},
    'protectedBusinessAfterStart':{'comments':1888,'uniqueCustomers':1129,'tasks':40,'originalRowsSameAsBeforeAndBackup':True,'accountBindingUnchanged':True},
    'evidenceSha256':{'nativeStatus':sha(target),'afterInstallBusiness':sha(D/'PROTECTED-BUSINESS-AFTER-INSTALL.json'),'frozenAcceptance':sha(D/'frozen-native/SUMMARY.json')},
    'limits':['Login-page DOM was checked by the original Native WebView2 probe; this is not a new CUA/human visual review.','Employee sign-in and real platform account acquisition/replies/posts were not performed.','No automatic collection or real sending was triggered.','This is an installed integration checkpoint; the full three-in-one scope still has explicitly recorded unfinished capabilities.']}
(D/'ACTUAL-CANONICAL-STARTUP.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps({'status':result['status'],'release':pins['releaseId'],'nativePid':66168,'comments':1888,'uniqueCustomers':1129,'tasks':40}))
