"""Real original factory/HTTP/guards/Adapters/Popen/NodeCLI, synthetic Bridge only."""
from pathlib import Path
from copy import deepcopy
from types import SimpleNamespace
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
import hashlib,http.client,importlib.util,json,os,re,shlex,sys,threading,time,uuid
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=W.parents[2];S=W/'qa-only-project'
stage_paths=sorted((S/'work/ui-native-r57/candidates').glob('*.json'));stage=json.loads(stage_paths[-1].read_text('utf-8-sig'));R=Path(stage['release'])
OUT=W/('factory-'+uuid.uuid4().hex);OUT.mkdir();events=[];wire=[];blocked=[];processes=[];checks=[];reply_permission=[True]
save=lambda name,v:(OUT/name).write_text(json.dumps(v,ensure_ascii=False,indent=2,default=str),'utf-8')
def audit(event,args):
 if event=='subprocess.Popen':
  argv=args[1];argv=[v.strip('"') for v in shlex.split(argv,posix=False)] if isinstance(argv,str) else argv
  assert Path(argv[0]).resolve()==S/'work/ui-runtime-r55/work/runtime/douyin-bridge/node.exe',argv
  assert Path(argv[1]).resolve()==S/'work/ui-runtime-r55/work/runtime/douyin-bridge/dm_workbench_cli.js',argv
  assert Path(args[2]).resolve().is_relative_to(OUT),args;processes.append(list(argv))
 elif event in ('os.system','os.startfile','os.posix_spawn'):blocked.append(event);raise RuntimeError('Only fixed internal CLI process')
 if event in ('socket.connect','socket.bind') and (not isinstance(args[1],tuple) or args[1][0] not in ('127.0.0.1','::1')):blocked.append(event);raise RuntimeError('Loopback only')
 if event=='socket.getaddrinfo' and args[0] not in ('127.0.0.1','::1','localhost',None):raise RuntimeError('No external DNS')
 if event=='sqlite3.connect' and not Path(args[0]).resolve().is_relative_to(OUT):raise RuntimeError('Own DB only')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  path=Path(os.fsdecode(args[0])).absolute();mode,flags=args[1] or '',args[2] or 0
  if (any(c in str(mode) for c in 'wax+') or isinstance(flags,int) and flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC)) and not path.is_relative_to(OUT):raise RuntimeError('Own evidence/data only')
sys.addaudithook(audit)
def load(name,path):
 m=importlib.util.module_from_spec(importlib.util.spec_from_loader(name,loader=None));m.__file__=str(path);sys.modules[name]=m;exec(compile(path.read_bytes(),str(path),'exec'),m.__dict__);return m
fixture=load('dm_original_identity_fixture',P/'work/acquisition-core-repair-20261018/gui-fixture/base_fixture.py');cloud=fixture.CloudStandin(json.loads((P/'work/central-store-config/compiled-fixture.json').read_text('utf-8-sig')));company=json.loads((S/'work/app/company.json').read_text('utf-8-sig'))
def transport(*a,**k):
 value=cloud(*a,**k);value['environment_id']=company['managedWorkspace']['environment_id'];value['user']['can_reply']=reply_permission[0];return value
integration=load('integrations',R/'resources/platform-runtime/vendor-src/integrations.py');integration.request_json=transport
host=load('dm_actual_native_host',R/'ui_native_host.py');_,files=host.verify_release(R,stage['manifest_sha256']);host.verify_backend_dependencies(R,files,S)
backend=host.create_backend(R,files,project_root=S,data_dir=OUT/'data',company=company);runtime=backend.platform_runtime;core=backend.core
runtime.server._configure_bundled();runtime._platform_setup=True
core.remote_safety_hold=False;core.employee_release_device_id='dm-synthetic-device';core.employee_release_until_monotonic=time.monotonic()+600
accounts={};send_state=['sent'];bridge_calls=[];slow_listen=[False];listen_corrupt=[False];late_revoke=[False];stop_received=threading.Event()
class Bridge(BaseHTTPRequestHandler):
 def log_message(self,*a):pass
 def do_POST(self):
  data=json.loads(self.rfile.read(int(self.headers['Content-Length'])));expr=data['expression'];bridge_calls.append({'connId':data.get('connId'),'expressionKind':'install' if expr.startswith('(function installReviewedDM') else expr.split('(...')[0]})
  if expr.startswith('(function installReviewedDM'):value='fangyu-dm-bounded-v1'
  else:
   operation=expr.split('(...')[0].rsplit('.',1)[1];args=json.loads(expr.split('(...',1)[1][:-1]);account=next(a for a in accounts.values() if a['conn_id']==data['connId']);assert args[0]==account['platform_uid'] if operation!='stop' else True
   mode=core.account_mode_status(account['id'],user['tenant_id']);assert mode['status']=='active' and mode['mode']==('replies' if operation=='send' else 'collection'),mode
   foreign=type(core.continuous.leases)(core.store,'foreign-dm-review')
   try:foreign.acquire(account['id'],user['tenant_id'],'publishing','foreign-publication')
   except ValueError:pass
   else:raise AssertionError('Original atomic mode lease bypassed')
   wire.append({'operation':operation,'args':args,'connection':data['connId'],'mode':mode,'foreignModeBlocked':True})
   if operation=='listen':
    if slow_listen[0]:stop_received.wait(3)
    uid,request,timeout=args;messages=[]
    for i in range(8):
     recipient=str(9007199254741001+i%4);messages.append({'message_id':str(9223372036854700001+i),'conversation_id':f'0:1:{uid}:{recipient}','sender_uid':recipient,'recipient_uid':uid,'text':'仅合成入站私信 '+str(i),'direction':'inbound','observed_at':'2026-10-23T04:40:00+00:00','platform_sent_at':None})
    value={'contract':'fangyu-dm-bounded-v1','state':'received','account_uid':uid,'request_id':request,'messages':messages,'history_available':False}
    if listen_corrupt[0]:value['state']='unknown'
    if late_revoke[0]:reply_permission[0]=False
   elif operation=='send':
    uid,recipient,text,request=args;value={'contract':'fangyu-dm-bounded-v1','state':send_state[0],'request_id':request,'account_uid':uid,'recipient_uid':recipient}
    if send_state[0]=='sent':value.update(message_id='9223372036854775807',conversation_id=f'0:1:{uid}:{recipient}',client_message_id=request)
   else:stop_received.set();value={'contract':'fangyu-dm-bounded-v1','state':'stopped','request_id':args[0]}
  raw=json.dumps({'ok':True,'value':value,'connection':data.get('connId')}).encode()
  try:
   self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
  except (BrokenPipeError,ConnectionResetError):pass
bridge=ThreadingHTTPServer(('127.0.0.1',0),Bridge);bt=threading.Thread(target=bridge.serve_forever,daemon=True);bt.start()
server=host.StaticServer(R,files,backend=backend,cookie_name='dm_fixture_session');st=threading.Thread(target=server.serve_forever,daemon=True);st.start();origin='http://127.0.0.1:'+str(server.server_port);headers={};passed=False
def request(method,path,payload=None):
 c=http.client.HTTPConnection('127.0.0.1',server.server_port,timeout=30);c.request(method,path,json.dumps(payload,ensure_ascii=False).encode() if payload else None,headers);r=c.getresponse();raw=r.read();status=r.status;found=dict(r.getheaders());c.close();value=json.loads(raw);log=deepcopy(payload)
 if log and log.get('action')=='login':log['data']['password']='synthetic omitted'
 events.append({'method':method,'path':path,'payload':log,'status':status,'body':value});save('HTTP.json',events);return status,value,found
def action(name,data,expected=200):
 code,body,h=request('POST','/api/workbench',{'action':name,'data':data});assert code==expected,(name,code,body);return body,h
serial=0
def dm(name,data,expected=200):return action(name,{'storeId':store,**data},expected)[0].get('dmWorkspace')
def mutate(name,data,expected=200,key=None):
 global serial
 serial+=1;return dm(name,{**data,'requestId':key or 'dm-fixture-operation-'+str(serial).zfill(6)},expected)
def read(account,**data):return dm('dm_workspace_read',{'accountId':account['id'],**data})
def wait_queue(ident):
 for _ in range(300):
  row=dm('dm_queue_read',{'id':ident})
  if row['state'] not in ('prepared','running'):return row
  time.sleep(.03)
 raise AssertionError('Queue did not settle')
def draft(account,conv,text):
 d=mutate('dm_draft_save',{'accountId':account['id'],'expectedVersion':0,'target':{'conversationId':conv['id']},'text':text})
 return mutate('dm_draft_review',{'accountId':account['id'],'id':d['id'],'expectedVersion':d['version'],'confirmed':True})
def prepare(account,ds):return mutate('dm_queue_prepare',{'accountId':account['id'],'drafts':[{'id':d['id'],'version':d['version']} for d in ds]})
def start(q,key=None):return mutate('dm_queue_start',{'id':q['id'],'snapshotDigest':q['snapshotDigest'],'confirmed':True},key=key)
try:
 _,boot,_=request('GET','/api/workbench/bootstrap');headers.update({'Content-Type':'application/json','Origin':origin,'X-Fangyu-CSRF':boot['csrfToken']});_,logged,h=request('POST','/api/workbench',{'action':'login','data':{'username':'fixture-admin','password':fixture.PASSWORD}});headers['Cookie']=h['Set-Cookie'].split(';',1)[0];headers['X-Fangyu-CSRF']=logged['csrfToken'];store=cloud.first_store
 if logged['selection']['storeId']!=store:action('select_store',{'storeId':store,'expectedRevision':logged['selection']['revision']})
 user={**core.session(headers['Cookie'].split('=',1)[1]),'_workbench_store_id':store}
 from assistant.business import BusinessExecutor
 from assistant.xhs_app_context import bind_executor_session
 executor=BusinessExecutor(runtime.server,company['managedWorkspace']['environment_id'],company['id'],user['username']);runtime.service.executor=executor
 saved={'state':'bound','environment_id':company['managedWorkspace']['environment_id'],'company_id':company['id'],'token':'synthetic-device-token','device':{'id':'dm-synthetic-device','owner':user['username']}}
 runtime.service.vault=SimpleNamespace(read=lambda:deepcopy(saved));runtime.service.device=deepcopy(saved['device']);runtime.service.state='online'
 class DeviceCloud:
  def call(self,operation,data,credential):return {'claimed':True}
  def close(self):pass
 runtime.service._cloud=lambda:DeviceCloud();executor.account_claim=runtime.service._claim_xhs_account;bind_executor_session(runtime.service,executor,saved)
 for i in range(2):
  a={'id':'dm-fixture-account-'+str(i),'tenant_id':user['tenant_id'],'cloud_owner':user['username'],'store_id':store,'platform':'douyin','status':'ready','name':'合成私信账号','platform_uid':str(9007199254740993+i),'conn_id':'dm-synthetic-connection-'+str(i)};accounts[a['id']]=a;core.store.put('accounts',a)
 account=list(accounts.values())[0];other=list(accounts.values())[1]
 config=core.store.directory/'bridge'/user['tenant_id']/'config.json';config.parent.mkdir(parents=True,exist_ok=True);config.write_text(json.dumps({'bridge':{'host':'127.0.0.1','port':bridge.server_port,'token':'synthetic-only'}}),'utf-8')
 assert read(account)['conversations']['total']==0 and not wire;checks.append('Original factory read is empty and starts zero CLI/platform calls')
 listener=mutate('dm_listen_start',{'accountId':account['id'],'confirmed':True,'timeoutMs':100})
 for _ in range(200):
  value=read(account)
  if value['listeners'][-1]['state'] not in ('listening',):break
  time.sleep(.03)
 assert value['conversations']['total']==4,(value,wire,processes)
 convs=value['conversations']['items'];assert len(wire)==1 and wire[0]['operation']=='listen';checks.append('Actual original adapter/Popen/new NodeCLI reads one bounded synthetic Bridge batch into original Store with four stable conversations')
 page=read(account,limit=2);next_page=read(account,limit=2,cursor=page['conversations']['cursor']);assert len(page['conversations']['items'])==len(next_page['conversations']['items'])==2 and not set(v['id'] for v in page['conversations']['items'])&set(v['id'] for v in next_page['conversations']['items']);checks.append('Real HTTP conversation pagination retains stable identities and no overlap')
 detail=read(account,conversationId=convs[0]['id']);assert detail['messages']['total']==2 and detail['messages']['items'][0]['senderUid']==convs[0]['recipientUid'] and detail['capabilities']['historyAvailable'] is False
 before=len(wire);unreviewed=mutate('dm_draft_save',{'accountId':account['id'],'expectedVersion':0,'target':{'conversationId':convs[3]['id']},'text':'未明确核对不会发送'})
 mutate('dm_draft_review',{'accountId':account['id'],'id':unreviewed['id'],'expectedVersion':1,'confirmed':False},400)
 mutate('dm_queue_prepare',{'accountId':account['id'],'drafts':[{'id':unreviewed['id'],'version':1}]},409)
 assert len(wire)==before;checks.append('Saving alone, missing individual confirmation and unreviewed batch preparation all produce zero sends')
 mp=read(account,conversationId=convs[0]['id'],limit=1);mp2=read(account,conversationId=convs[0]['id'],limit=1,messageCursor=mp['messages']['cursor']);assert mp['messages']['total']==2 and mp['messages']['items'][0]['id']!=mp2['messages']['items'][0]['id'];checks.append('Actual HTTP saved-message cursor pages preserve stable message IDs without claiming platform history')
 from assistant.customer_list import _person
 task={'id':'dm-comment-source-task','tenant_id':user['tenant_id'],'cloud_owner':user['username'],'store_id':store,'platform':'douyin','account_id':account['id'],'status':'completed'};core.store.put('tasks',task)
 lead={'id':'dm-original-comment-source','tenant_id':user['tenant_id'],'cloud_owner':user['username'],'store_id':store,'task_id':task['id'],'platform':'douyin','author_id':'9007199254741111','comment_id':'dm-source-comment','text':'仅合成原评论，保留来源并由本人另核私信','note_url':'https://www.douyin.com/video/1234567890123456789','created_at':'2026-10-23T04:40:00Z'};core.store.put('leads',lead)
 digest_lead=lambda r:hashlib.sha256(json.dumps(r,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
 target_comment={'customerId':_person(lead)[0],'leadId':lead['id'],'sourceDigest':digest_lead(lead)}
 original_draft=mutate('dm_draft_save',{'accountId':account['id'],'expectedVersion':0,'target':target_comment,'text':'来自原评论的独立私信草稿'})
 assert original_draft['source']['kind']=='customer' and original_draft['source']['recipientUid']==lead['author_id']
 changed={**lead,'text':'原评论已变化，旧核对不可采用'};core.store.put('leads',changed);before=len(wire)
 mutate('dm_draft_review',{'accountId':account['id'],'id':original_draft['id'],'expectedVersion':1,'confirmed':True},409)
 assert len(wire)==before and core.store.get('leads',lead['id'])==changed and core.store.get('ui_dm_drafts_v1',original_draft['id'])['state']=='draft'
 checks.append('Real original customer/detail scope resolves explicit Douyin comment to stable UID; source-digest change rejects old review without creating or mutating customers/comments')
 xhs={**account,'id':'dm-unavailable-xhs-account','platform':'xiaohongshu','platform_uid':'synthetic-xhs-stable-id','conn_id':''};core.store.put('accounts',xhs)
 xt={**task,'id':'dm-xhs-source-task','account_id':xhs['id'],'platform':'xiaohongshu'};xl={**lead,'id':'dm-xhs-source-lead','task_id':xt['id'],'platform':'xiaohongshu','author_id':'abcdef1234567890abcdef12'};core.store.put('tasks',xt);core.store.put('leads',xl)
 xd=mutate('dm_draft_save',{'accountId':xhs['id'],'expectedVersion':0,'target':{'customerId':_person(xl)[0],'leadId':xl['id'],'sourceDigest':digest_lead(xl)},'text':'小红书未接通，仍可保存草稿'})
 assert xd['state']=='draft' and not read(xhs)['capabilities']['canSend'] and not read(xhs)['capabilities']['canListen'] and len(wire)==before;checks.append('Unimplemented XHS Windows transport remains explicitly unavailable while current visible comment draft can be saved, with zero CLI')
 d=draft(account,convs[0],'仅合成单条私信');q=prepare(account,[d]);before=len(wire);start(q);blocked_q=wait_queue(q['id']);assert len(wire)==before and blocked_q['state']=='blocked';checks.append('Original held public-send guard refuses a reviewed DM with zero CLI send; draft retained')
 # Explicit synthetic-only normal permission configuration, not a production
 # grant, test seam, runtime function replacement or permission bypass.
 for config_value in (runtime.server.company,core.deployment_config):
  flags=config_value['runtime'];flags['public_send_hold']=False;flags['public_reply_hold']=False;flags['public_replies']='enabled';flags.pop('platform_qa_device_id',None)
 # The original device session correctly rejects a changed config binding.
 # Bind a fresh original synthetic session to this explicitly changed fixture.
 executor=BusinessExecutor(runtime.server,company['managedWorkspace']['environment_id'],company['id'],user['username']);runtime.service.executor=executor
 executor.account_claim=runtime.service._claim_xhs_account;bind_executor_session(runtime.service,executor,saved)
 manifest_path=core.store.directory/'adapters/douyin.json';manifest=json.loads(manifest_path.read_text('utf-8'));manifest['dm_contract_verified']=True;manifest_path.write_text(json.dumps(manifest),'utf-8')
 q=prepare(account,[d]);start(q);sent=wait_queue(q['id']);assert sent['state']=='completed' and sent['items'][0]['state']=='sent',sent;assert wire[-1]['args'][0]==account['platform_uid'] and wire[-1]['operation']=='send';checks.append('Explicit own-fixture permit traverses unchanged device/held gates and original mode lease to actual CLI; stable server ID receipt means sent, never read')
 sent_history=read(account,conversationId=convs[0]['id'])['messages'];assert sent_history['total']==3 and sent_history['items'][0]['direction']=='outbound' and sent_history['items'][0]['platformMessageId']=='9223372036854775807' and sent_history['items'][0]['platformSentAt'] is None;checks.append('Only strict sent receipt appends an outgoing conversation message with stable server ID, original request key and no invented platform time/delivery/read status')
 send_state[0]='unknown';d1=draft(account,convs[1],'仅合成未知私信');d2=draft(account,convs[2],'不应继续发送');q=prepare(account,[d1,d2]);before=len(wire);key='dm-fixture-original-unknown-key';start(q,key);unknown=wait_queue(q['id']);assert unknown['state']=='unknown' and len(wire)==before+1 and unknown['items'][1]['state']=='pending',unknown
 old_unknown=deepcopy(core.store.get('ui_dm_drafts_v1',d1['id']));again=start(q,key);assert again['state']=='unknown' and len(wire)==before+1
 mutate('dm_queue_start',{'id':q['id'],'snapshotDigest':q['snapshotDigest'],'confirmed':True},409,key='dm-other-key-must-not-retry')
 recovery=dm('dm_request_read',{'action':'dm_queue_start','requestId':key});assert recovery['state']=='unknown' and core.store.get('ui_dm_drafts_v1',d1['id'])==old_unknown;checks.append('First unknown stops selected queue; original key reopens current unknown, different key cannot send; old unknown bytes preserved')
 # Same recipient via another owned account is blocked by the preserved shared
 # atomic customer reservation, not a nickname heuristic or second lock table.
 mutate('dm_listen_start',{'accountId':other['id'],'confirmed':True,'timeoutMs':100})
 for _ in range(200):
  value=read(other)
  if value['listeners'][-1]['state']!='listening':break
  time.sleep(.03)
 target=next(c for c in value['conversations']['items'] if c['recipientUid']==convs[1]['recipientUid']);db=draft(other,target,'不应跨账号重发');qb=prepare(other,[db]);before=len(wire);start(qb);refused=wait_queue(qb['id']);assert refused['state']=='blocked' and len(wire)==before and core.store.get('ui_dm_drafts_v1',d1['id'])==old_unknown;checks.append('Another account targeting the same stable UID is blocked by original atomic customer claim before any CLI send')
 before=len(wire);foreign={**account,'id':'dm-foreign-owner-account','platform_uid':'123456789','cloud_owner':'different-employee'};core.store.put('accounts',foreign);dm('dm_workspace_read',{'accountId':foreign['id']},403)
 other_store=next(x['id'] for x in cloud.manifest['stores'] if x['id']!=store);action('dm_workspace_read',{'storeId':other_store,'accountId':account['id']},403)
 reply_permission[0]=False;dm('dm_workspace_read',{'accountId':account['id']},403);reply_permission[0]=True;read(account);assert len(wire)==before;checks.append('Original refreshed actor/can_reply and explicit owner/store boundaries refuse foreign requests with zero wire')
 third={**account,'id':'dm-fixture-account-2','platform_uid':'9007199254740995','conn_id':'dm-synthetic-connection-2'};accounts[third['id']]=third;core.store.put('accounts',third)
 mutate('dm_listen_start',{'accountId':third['id'],'confirmed':True,'timeoutMs':100})
 for _ in range(200):
  value=read(third)
  if value['listeners'][-1]['state']!='listening':break
  time.sleep(.03)
 dc=draft(third,value['conversations']['items'][0],'合成旧核对');qc=prepare(third,[dc]);mutate('dm_draft_save',{'accountId':third['id'],'id':dc['id'],'expectedVersion':dc['version'],'target':{'conversationId':value['conversations']['items'][0]['id']},'text':'合成编辑后新正文'});before=len(wire);start(qc);cas_refused=wait_queue(qc['id']);assert cas_refused['state']=='blocked' and len(wire)==before;checks.append('Edited draft CAS invalidates frozen queue before original CLI, leaving the new draft intact')
 dc=mutate('dm_draft_review',{'accountId':third['id'],'id':dc['id'],'expectedVersion':2,'confirmed':True})
 # Exercise the actual public DM path with the original employee budget plus
 # existing comment records; no quota implementation is replaced.
 tenant_before=deepcopy(core.store.get('tenants',user['tenant_id']));tenant_limited=deepcopy(tenant_before);rules=deepcopy(core._company(user['tenant_id']));rules.setdefault('defaultRules',{})['employeeDailyReplyLimit']=3;tenant_limited['business_rules']=rules;core.store.put('tenants',tenant_limited)
 from core.engine import now
 old_reply={'id':'dm-quota-existing-comment','tenant_id':user['tenant_id'],'status':'sent','attempted_by':user['id'],'account_id':third['id'],'attempted_at':now()};core.store.put('replies',old_reply)
 qquota=prepare(third,[dc]);before=len(wire);start(qquota);quota_refused=wait_queue(qquota['id']);assert quota_refused['state']=='blocked' and '限额' in quota_refused['message'] and len(wire)==before,quota_refused
 assert core.store.get('replies',old_reply['id'])==old_reply;core.store.put('tenants',tenant_before);checks.append('Actual public send counts prior DM sent/unknown plus original comment in one unchanged employee daily budget, refuses before CLI and retains original comment')
 qmode=prepare(third,[dc]);core.acquire_account_mode(third['id'],user['tenant_id'],'replies','other-existing-reply-owner');lease=deepcopy(core.account_mode_status(third['id'],user['tenant_id']));before=len(wire);start(qmode);assert wait_queue(qmode['id'])['state']=='blocked' and len(wire)==before and core.account_mode_status(third['id'],user['tenant_id'])==lease;core.release_account_mode(third['id'],user['tenant_id'],'other-existing-reply-owner');checks.append('Existing original reply lease blocks private-message preflight with zero CLI and retains exact foreign owner')
 qpub=prepare(third,[dc]);publication={'id':'dm-existing-unknown-publication','tenant_id':user['tenant_id'],'scope':{'tenant_id':user['tenant_id'],'account_id':third['id']},'state':'unknown','requestId':'dm-original-publication-key'};publication['recordDigest']=hashlib.sha256(json.dumps(publication,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest();core.store.put('content_publication_attempt_v1',publication);before=len(wire);start(qpub);assert wait_queue(qpub['id'])['state']=='blocked' and len(wire)==before and core.store.get('content_publication_attempt_v1',publication['id'])==publication;checks.append('Original durable unknown publication stops DM before any CLI and its original key/body remains unchanged')
 # Explicit stop owns only the one listener, terminates its original CLI waiter,
 # then sends the exact fixed local close through the unchanged serial channel.
 slow_listen[0]=True;stop_received.clear();before=len(wire);ls=mutate('dm_listen_start',{'accountId':other['id'],'confirmed':True,'timeoutMs':20000})
 for _ in range(200):
  if len(wire)>before:break
  time.sleep(.02)
 started=time.monotonic();stopped=dm('dm_listen_stop',{'id':ls['id']});assert stopped['state']=='stopped' and time.monotonic()-started<3 and stop_received.is_set(),stopped;slow_listen[0]=False;checks.append('Actual original process cancel + same-account mode + Node CLI stop receives exact stop receipt without waiting 20 seconds or touching foreign jobs')
 before_messages=deepcopy(core.store.list('ui_dm_messages_v1',user['tenant_id']));listen_corrupt[0]=True
 bad=mutate('dm_listen_start',{'accountId':other['id'],'confirmed':True,'timeoutMs':100})
 for _ in range(200):
  if bad['id'] not in backend.dm_workbench.workers:break
  time.sleep(.02)
 assert read(other)['listeners'][-1]['state']=='blocked' and core.store.list('ui_dm_messages_v1',user['tenant_id'])==before_messages;listen_corrupt[0]=False;checks.append('Non-received listen receipt never imports messages or overwrites existing stable history')
 late_revoke[0]=True;late=mutate('dm_listen_start',{'accountId':other['id'],'confirmed':True,'timeoutMs':100})
 for _ in range(200):
  if late['id'] not in backend.dm_workbench.workers:break
  time.sleep(.02)
 reply_permission[0]=True;late_revoke[0]=False
 assert read(other)['listeners'][-1]['state']=='blocked' and core.store.list('ui_dm_messages_v1',user['tenant_id'])==before_messages;checks.append('Original refreshed can_reply revoked during receipt rejects late listener import before Store commit')
 # F79 integration: preserve account lifecycle safety alongside DM workers.
 def deletion(a,key):return {'storeId':store,'accountId':a['id'],'platform':a['platform'],'expectedNickname':a.get('platform_nickname') or a.get('name',''),'confirmed':True,'requestId':key}
 slow_listen[0]=True;stop_received.clear();before=len(wire)
 active_listener=mutate('dm_listen_start',{'accountId':other['id'],'confirmed':True,'timeoutMs':20000})
 for _ in range(200):
  if len(wire)>before:break
  time.sleep(.02)
 assert len(wire)>before and core.account_mode_status(other['id'],user['tenant_id'])['status']=='active'
 account_before=deepcopy(core.store.get('accounts',other['id']));key='dm-f79-delete-active-listener'
 response,_=action('account_delete',deletion(other,key),409)
 assert response['error']['code']=='ACCOUNT_BUSY' and core.store.get('accounts',other['id'])==account_before
 assert action('account_delete_request',{'storeId':store,'requestId':key})[0]['accountDeletion']['state']=='not_started'
 assert core.store.get('ui_dm_drafts_v1',d1['id'])==old_unknown
 dm('dm_listen_stop',{'id':active_listener['id']});slow_listen[0]=False
 checks.append('F79 original account deletion rejects active real DM listener atomic lease before service/receipt; account and original unknown unchanged, explicit own stop releases')
 retired={**other,'id':'dm-f79-retirable-account','platform_uid':'9007199254741555','conn_id':'dm-f79-retirable-connection','name':'合成可移除账号'}
 core.store.put('accounts',retired)
 oldtask={'id':'dm-f79-retained-task','tenant_id':user['tenant_id'],'cloud_owner':user['username'],'store_id':store,'platform':'douyin','account_id':retired['id'],'status':'paused','cursor':{'page':7},'created_at':'2026-10-23T00:00:00Z'}
 core.store.put('tasks',oldtask)
 retained={'id':'dm-f79-retained-comment','tenant_id':user['tenant_id'],'cloud_owner':user['username'],'store_id':store,'platform':'douyin','task_id':oldtask['id'],'author_id':'9007199254741666','text':'仅合成客户评论，账号移除后保留'}
 core.store.put('leads',retained)
 before_dm={entity:deepcopy(core.store.list(entity,user['tenant_id'])) for entity in ['ui_dm_conversations_v1','ui_dm_messages_v1','ui_dm_drafts_v1','ui_dm_queues_v1']}
 before_wire=len(wire);key='dm-f79-delete-idle-retirable';data=deletion(retired,key)
 action('account_delete',{**data,'confirmed':False},400)
 action('account_delete',{**data,'expectedNickname':'另一个昵称'},409)
 assert core.store.get('accounts',retired['id'])==retired and len(wire)==before_wire
 checks.append('F79 deletion explicit confirmation and exact current nickname CAS remain enforced with DM component loaded; no extra wire')
 result,_=action('account_delete',data)
 assert result['accountDeletion']['state']=='deleted' and core.store.get('accounts',retired['id']) is None
 retained_task=core.store.get('tasks',oldtask['id'])
 assert retained_task['account_id']=='' and retained_task['account_removed'] is True and retained_task['cursor']==oldtask['cursor'] and retained_task['cloud_owner']==oldtask['cloud_owner'] and retained_task['store_id']==store
 assert core.store.get('leads',retained['id'])==retained and all(core.store.list(entity,user['tenant_id'])==rows for entity,rows in before_dm.items()) and len(wire)==before_wire
 assert action('account_delete',data)[0]['accountDeletion']['state']=='deleted'
 assert action('account_delete_request',{'storeId':store,'requestId':key})[0]['accountDeletion']['state']=='deleted'
 assert core.store.get('ui_dm_drafts_v1',d1['id'])==old_unknown
 checks.append('F79 original service/Business/Core idle account deletion retires only old task binding, retains cursor/customer and all DM records; same original delete key replays without wire')
 dm('dm_workspace_read',{'accountId':retired['id']},403)
 assert read(other)['accountId']==other['id'] and core.store.get('accounts',other['id'])==account_before
 checks.append('Deleted account cannot regain DM scope; another exact owner/store account retains its original workspace and identity')
 assert core.store.get('ui_dm_drafts_v1',d1['id'])==old_unknown
 assert all(v['foreignModeBlocked'] for v in wire) and all((core.account_mode_status(a['id'],user['tenant_id']) or {}).get('status')=='idle' for a in accounts.values())
 assert not blocked;save('RESULTS.json',{'status':'PASS_HARDEST_DM_FACTORY_REAL_CLI_SYNTHETIC_BRIDGE','checks':checks,'stage':stage,'actualFactoryCoreStoreHttpAdaptersPopenNodeCli':True,'originalModeAndScopeGuardsNotReplaced':True,'originalDeviceSessionWithExplicitSyntheticLease':True,'positiveSendFixtureConfigOnly':{'publicSendHold':False,'dmContractVerified':True,'realSendDestination':'own loopback Bridge simulator only'},'realPlatformModelCalls':0,'productionAccess':False,'wire':wire,'processCount':len(processes),'oldUnknownByteIdentical':True,'historyNotClaimed':True});passed=True
finally:
 server.shutdown();st.join(3);server.server_close();backend.close();bridge.shutdown();bt.join(3);bridge.server_close();save('FINAL.json',{'status':'PASS' if passed else 'RED_CAPTURED','checks':checks,'blocked':blocked,'wire':wire,'processes':processes,'allOwnServersClosed':not st.is_alive() and not bt.is_alive()});print(str(OUT),flush=True)
