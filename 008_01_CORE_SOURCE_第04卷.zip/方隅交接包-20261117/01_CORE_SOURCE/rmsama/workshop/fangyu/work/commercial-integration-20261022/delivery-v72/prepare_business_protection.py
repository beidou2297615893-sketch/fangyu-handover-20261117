from pathlib import Path
import hashlib,json
D=Path(__file__).resolve().parent;W=D.parent
source=W/'delivery-v71'
for name in ('capture_business_readonly.py','PROTECTED-BUSINESS-BEFORE-INSTALL.json'):
    target=D/name;assert not target.exists();target.write_bytes((source/name).read_bytes())
report={'status':'INHERITED_UNCHANGED_PREINSTALL_BUSINESS_SNAPSHOT','source':str(source/'PROTECTED-BUSINESS-BEFORE-INSTALL.json'),'sourceSha256':hashlib.sha256((source/'PROTECTED-BUSINESS-BEFORE-INSTALL.json').read_bytes()).hexdigest(),'originalTimestampRetained':True,'installed':False,'next':'After the actual v72 install/start, the copied read-only script freshly compares protected production rows against this snapshot and the verified business backup. No production restore or mutation.'}
(D/'BUSINESS-PROTECTION-CHAIN.json').write_text(json.dumps(report,indent=2)+'\n','utf-8')
print(report['status'])
