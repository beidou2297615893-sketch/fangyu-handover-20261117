from pathlib import Path
import difflib,hashlib,json
C=Path(__file__).resolve().parent;P=C.parents[2];relative='work/ui-approved-implementation/ui-preview/backend.mjs';base=(P/'work/parallel-integration-20261018/final-integration/candidate-unified-v79/project'/relative).read_bytes();incoming=(C.parent/'media-f79-candidate/source-candidate'/relative).read_bytes();current=(C/'project'/relative).read_bytes();sha=lambda raw:hashlib.sha256(raw).hexdigest()
ops=[op for op in difflib.SequenceMatcher(None,base,incoming,autojunk=False).get_opcodes() if op[0]!='equal'];assert len(ops)==2 and all(op[0]=='insert' for op in ops)
expected=[b'ervices_status media_ocr_preview media_speech_preview media_speech_cancel media_speech_save media_speech_read media_s',b"'media_services_status','media_ocr_preview','media_speech_preview','media_speech_cancel','media_speech_read',"]
result=current;inserts=[]
for op,wanted in zip(ops,expected):
 _,start,end,other_start,other_end=op;addition=incoming[other_start:other_end];assert addition==wanted
 for width in (100,64,32,16):
  anchor=base[start-width:end+width]
  if result.count(anchor)==1:break
 else:raise AssertionError('Media insertion context is not unique')
 replacement=base[start-width:start]+addition+base[end:end+width];result=result.replace(anchor,replacement);inserts.append(addition)
check=result
for addition in reversed(inserts):check=check.replace(addition,b'',1)
assert check==current
target=C/'resolutions/media'/relative;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(result)
(C/'MEDIA-BACKEND-RESOLUTION.json').write_text(json.dumps({'status':'EXACT_MEDIA_ACTION_AND_READ_CLASSIFICATION_INSERTS_ONLY','compositionBeforeSha256':sha(current),'compositionAfterSha256':sha(result),'allDmScheduleAndF79OtherBytesPreserved':True,'insertedBytes':[len(s) for s in inserts]},indent=2),'utf-8');print('Resolved exact two media whitelist insertions preserving other modules')
