from pathlib import Path
import hashlib,json
W=Path(__file__).resolve().parent;D=W.parent;original=D.parent/'delivery-v77/ui-mode-validation/serve_ui.py'
text=original.read_text('utf-8').replace('candidate-unified-v77/project','candidate-unified-v78/project')
start=text.index(" for i,platform in enumerate(('xiaohongshu','xiaohongshu','douyin')):")
end=text.index('\n readiness=',start)
seed=''' for i,platform in enumerate(('xiaohongshu','xiaohongshu','douyin')):
  record={'id':'diverse-fixture-account-'+str(i),'tenant_id':user['tenant_id'],'cloud_owner':user['username'],'store_id':store,'platform':platform,'name':'合成平台账号'+str(i),'status':'ready','platform_uid':'fixture-uid-'+str(i)}
  if i==0:record['identity_recovery_pending']=True
  backend.core.store.put('accounts',record)
  if platform=='xiaohongshu':(backend.core.store.directory/'accounts'/user['tenant_id']/record['id']/'xhs-browser-profile').mkdir(parents=True,exist_ok=True)
 task={'id':'diverse-fixture-old-task','tenant_id':user['tenant_id'],'cloud_owner':user['username'],'store_id':store,'platform':'xiaohongshu','account_id':'diverse-fixture-account-0','name':'合成原关键词任务','status':'paused','scope':'search_comments','keywords':['租房'],'excludes':[],'city':'上海','region':'','comment_keyword_mode':'all','unknown_policy':'exclude','continuous_enabled':False,'created_at':'2026-10-23T00:00:00Z','cursor':{'page':3,'cursor':'original-ui-cursor'},'pause_reason':'collection_error','last_message':'原账号状态待核，原断点保留'}
 backend.core.store.put('tasks',task)
 request_id='original-ui-accepted-request'
 request_record={'id':backend._request_record(user,request_id)[0],'tenant_id':user['tenant_id'],'owner':user['username'],'requestId':request_id,'storeId':store,'state':'accepted','conditions':{'storeId':store,'platform':'xiaohongshu','accountId':'diverse-fixture-account-0'},'job':{'taskId':task['id'],'accountId':'diverse-fixture-account-0'}}
 backend._save_request(user,request_record)
 preset_user,preset_profile=backend._identity(cookie.split('=',1)[1])
 preset_selection=backend._load_selection(preset_user,backend._stores(preset_profile))
 code,applied,_=request('POST','/api/workbench',{'action':'apply_preset','data':{'storeId':store,'searchPresetId':'precise','intentPresetId':'standard','expectedRevision':preset_selection['revision']}},headers)
 assert code==200 and applied['selection']['applied']['selectedKeywords'],applied
 before=records();dump('UI-ORIGINAL-RECORDS.json',before)
'''
text=text[:start]+seed+text[end:]
text=text.replace("assert not readiness[0],readiness","assert readiness[0]=='recovery_pending',readiness")
text=text.replace(" print('READY '+origin,flush=True)"," debug_user,debug_profile=backend._identity(cookie.split('=',1)[1])\n dump('INITIAL-PROJECTION.json',{'platform':backend._platform_state(debug_user,debug_profile,platform='xiaohongshu'),'selection':backend._load_selection(debug_user,backend._stores(debug_profile)),'loggedSelection':logged.get('selection')})\n print('READY '+origin,flush=True)")
text=text.replace("'actualF77Stage':True,'controlledPersistedPauseReasonFixture':True","'actualF78Stage':True,'originalAccountReadinessBlockedFixture':True")
text=text.replace("while not (W/'STOP-UI-SERVER').exists():time.sleep(.2)","deadline=time.monotonic()+240\n while not (W/'STOP-UI-SERVER').exists() and time.monotonic()<deadline:time.sleep(.2)")
(W/'serve_ui.py').write_text(text,'utf-8')
(W/'PREPARATION.json').write_text(json.dumps({'originalHarnessSha256':hashlib.sha256(original.read_bytes()).hexdigest(),'originalF78Factory':True,'newAccountReadyOldAccountRecoveryPending':True,'syntheticIdentityOnly':True,'productMethodsOverridden':False,'productionAccess':False},indent=2),'utf-8')
print('Prepared original F78 factory full UI harness')
