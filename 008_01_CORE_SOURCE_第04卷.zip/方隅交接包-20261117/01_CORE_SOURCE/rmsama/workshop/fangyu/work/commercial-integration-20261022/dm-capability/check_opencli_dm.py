from pathlib import Path
import json,urllib.request
from datetime import datetime,timezone
W=Path(__file__).parent
urls={
 'main_tree':'https://api.github.com/repos/jackwener/OpenCLI/git/trees/main?recursive=1',
 'dm_pr_search':'https://api.github.com/search/issues?q=repo%3Ajackwener%2FOpenCLI+dm-list',
}
out={'checked_at':datetime.now(timezone.utc).isoformat(),'note':'Indexed search result mentioned DM at PR2554, but direct API returned unrelated arxiv title. Reject that search association.','checks':{}}
for key,url in urls.items():
    try:
        req=urllib.request.Request(url,headers={'User-Agent':'fangyu-source-review','Accept':'application/vnd.github+json'})
        with urllib.request.urlopen(req,timeout=20) as r:v=json.load(r)
        if key=='main_tree':
            safe={'sha':v.get('sha'),'truncated':v.get('truncated'),'paths':[x['path'] for x in v.get('tree',[]) if x['path'].startswith('clis/xiaohongshu/') and ('dm' in x['path'] or 'notification' in x['path'])]}
        else:safe=[{k:x.get(k) for k in ('html_url','number','title','state','updated_at')} for x in v.get('items',[])[:10]]
        out['checks'][key]={'source':url,'status':'read','metadata':safe}
    except Exception as e:out['checks'][key]={'source':url,'status':'unverified','error_type':type(e).__name__}
(W/'OPENCLI-DM-SOURCE-CHECK.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),'utf-8')
print(json.dumps(out,ensure_ascii=False))
