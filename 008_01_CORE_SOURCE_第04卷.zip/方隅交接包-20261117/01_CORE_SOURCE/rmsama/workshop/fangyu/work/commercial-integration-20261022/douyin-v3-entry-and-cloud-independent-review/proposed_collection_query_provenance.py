"""Host-requested keyword evidence appended in the original page transaction.

This records the original adapter call's requested term, not platform ranking,
raw response counts, a credential, or proof that every returned note is relevant.
Legacy checkpoints without this evidence stay unknown; raw comment labels never
create it. Originals and their AI/manual judgments are not rewritten.
"""
from copy import deepcopy
from datetime import datetime, timezone
import json
import re

from .collection_observations import comment_identity, digest

ENTITY = 'lead_query_observations_v1'
SCOPE = ('tenant_id', 'cloud_owner', 'store_id', 'account_id', 'id', 'platform')
SEARCH_KEYS = frozenset(('schema', 'scope', 'keyword', 'keyword_digest', 'keywords_digest',
                         'keyword_index', 'page', 'note_ids', 'requested_at', 'digest'))
RECORD_KEYS = frozenset(('schema', 'id', 'tenant_id', 'owner', 'store_id', 'account_id',
    'task_id', 'platform', 'lead_id', 'source_id', 'comment_id', 'note_id',
    'original_task_id', 'original_text_sha256', 'keyword', 'search',
    'first_seen_at', 'last_seen_at', 'attribution', 'digest'))


def scope(task):
    return {key: task.get(key) for key in SCOPE}


def note_id(value, platform):
    return comment_identity({'platform': platform, 'comment_id': 'query',
        'source_id': 'comment:query', 'note_url': value, 'text': ''}, platform)[1]


def _keyword(value):
    return (type(value) is str and 0 < len(value) <= 200 and value == value.strip()
            and not re.search(r'[\x00-\x1f\x7f]|https?://|xsec_|cookie|password|secret|api[_-]?key|Bearer', value, re.I))


def _stamp(value):
    try:
        result = datetime.fromisoformat(value.replace('Z', '+00:00'))
        return result if result.utcoffset() is not None else None
    except (AttributeError, TypeError, ValueError):
        return None


def valid_search(value, task=None):
    if (type(value) is not dict or set(value) != SEARCH_KEYS or value['schema'] != 'host-keyword-query/1'
            or type(value['scope']) is not dict or set(value['scope']) != set(SCOPE)
            or value['scope'].get('platform') not in ('xiaohongshu', 'douyin')
            or any(type(value['scope'][key]) is not str or not value['scope'][key]
                   for key in SCOPE)
            or not _keyword(value['keyword']) or value['keyword_digest'] != digest(value['keyword'])
            or not re.fullmatch(r'[0-9a-f]{64}', str(value['keywords_digest']))
            or type(value['keyword_index']) is not int or not 0 <= value['keyword_index'] < 10000
            or type(value['page']) is not int or not 1 <= value['page'] <= 100000
            or type(value['note_ids']) is not list or len(value['note_ids']) > 2000
            or any(type(v) is not str or not re.fullmatch(r'[A-Za-z0-9]{1,160}', v) for v in value['note_ids'])
            or len(set(value['note_ids'])) != len(value['note_ids'])
            or _stamp(value['requested_at']) is None
            or value['digest'] != digest({k: v for k, v in value.items() if k != 'digest'})):
        return False
    if task is not None:
        words = task.get('keywords')
        index = value['keyword_index']
        if (value['scope'] != scope(task) or type(words) is not list or index >= len(words)
                or words[index] != value['keyword'] or digest(words) != value['keywords_digest']):
            return False
    return True


def make_search(task, keyword_index, page, notes):
    """Called only after the original adapter.search returns successfully."""
    words = task.get('keywords')
    if (task.get('platform') not in ('xiaohongshu', 'douyin') or task.get('source_ref')
            or task.get('scope') != 'search_comments' or type(words) is not list
            or type(keyword_index) is not int or not 0 <= keyword_index < len(words)
            or not _keyword(words[keyword_index])):
        return None
    try:
        ids = sorted({note_id(item['url'], task['platform']) for item in notes})
    except (KeyError, TypeError, ValueError):
        return None
    value = {'schema': 'host-keyword-query/1', 'scope': scope(task),
        'keyword': words[keyword_index], 'keyword_digest': digest(words[keyword_index]),
        'keywords_digest': digest(words), 'keyword_index': keyword_index, 'page': page,
        'note_ids': ids, 'requested_at': datetime.now(timezone.utc).isoformat()}
    value['digest'] = digest(value)
    return value if valid_search(value, task) else None


def page_context(task, search, url):
    if not valid_search(search, task):
        return None
    try:
        ident = note_id(url, task['platform'])
    except ValueError:
        return None
    if ident not in search['note_ids']:
        return None
    value = {'schema': 'host-keyword-page/1', 'search': deepcopy(search), 'note_id': ident}
    value['digest'] = digest(value)
    return value


def validate_page(value, task):
    if value is None:
        return None
    if (type(value) is not dict or set(value) != {'schema', 'search', 'note_id', 'digest'}
            or value['schema'] != 'host-keyword-page/1' or not valid_search(value['search'], task)
            or value['note_id'] not in value['search']['note_ids']
            or value['digest'] != digest({k: v for k, v in value.items() if k != 'digest'})
            or type(task.get('pipeline')) is not dict
            or task['pipeline'].get('query_provenance') != value['search']):
        raise ValueError('检索词与原采集断点无法核对，已保留原页')
    return value


def commit(db, context, task, lead, stamp):
    if context is None:
        return
    search = context['search']
    comment, note, text = comment_identity(lead, task['platform'])
    if note != context['note_id']:
        raise ValueError('检索词出处与原评论帖子不一致，未确认下一页')
    ident = digest([task['tenant_id'], task['cloud_owner'], task['id'], lead['id'], search['keyword_digest']])
    found = db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
                       (ENTITY, ident, task['tenant_id'])).fetchone()
    previous = json.loads(found['body']) if found else None
    if previous is not None:
        if not valid_observation(previous, task, lead):
            raise ValueError('原检索词出处记录待核，未覆盖原记录')
        value = deepcopy(previous)
        value['last_seen_at'] = stamp
    else:
        value = {'schema': 'lead-keyword-observation/1', 'id': ident, 'tenant_id': task['tenant_id'],
            'owner': task['cloud_owner'], 'store_id': task['store_id'], 'account_id': task['account_id'],
            'task_id': task['id'], 'platform': task['platform'], 'lead_id': lead['id'],
            'source_id': lead['source_id'], 'comment_id': comment, 'note_id': note,
            'original_task_id': lead.get('task_id'), 'original_text_sha256': digest(text),
            'keyword': search['keyword'], 'search': deepcopy(search),
            'first_seen_at': stamp, 'last_seen_at': stamp, 'attribution': 'host_requested_query'}
    value['digest'] = digest({k: v for k, v in value.items() if k != 'digest'})
    db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',
               (ENTITY, ident, task['tenant_id'], json.dumps(value, ensure_ascii=False)))


def valid_observation(value, task, lead, *, historical_account_id=None):
    if type(value) is not dict or set(value) != RECORD_KEYS:
        return False
    if historical_account_id is not None:
        # Read-only metrics may validate the fixed original scope only after
        # their caller proved an original deletion + internal observation.
        # Ingest/commit callers keep the default strict current-task contract.
        if (task.get('account_removed') is not True or task.get('account_id') != ''
                or type(historical_account_id) is not str or not historical_account_id
                or value.get('account_id') != historical_account_id):
            return False
        task = {**task, 'account_id': historical_account_id}
    try:
        comment, note, text = comment_identity(lead, task['platform'])
        s = value['search']
        expected = digest([task['tenant_id'], task['cloud_owner'], task['id'], lead['id'], digest(value['keyword'])])
        return (value['schema'] == 'lead-keyword-observation/1' and value['id'] == expected
            and valid_search(s) and s['scope'] == scope(task)
            and value['keyword'] == s['keyword'] and note in s['note_ids']
            and value['tenant_id'] == task['tenant_id'] and value['owner'] == task['cloud_owner']
            and value['store_id'] == task['store_id'] and value['account_id'] == task['account_id']
            and value['task_id'] == task['id'] and value['platform'] == task['platform']
            and value['lead_id'] == lead['id'] and value['source_id'] == lead['source_id']
            and value['comment_id'] == comment and value['note_id'] == note
            and value['original_task_id'] == lead.get('task_id') and value['original_text_sha256'] == digest(text)
            and value['attribution'] == 'host_requested_query' and _stamp(value['first_seen_at']) is not None
            and _stamp(value['last_seen_at']) is not None
            and value['digest'] == digest({k: v for k, v in value.items() if k != 'digest'}))
    except (KeyError, TypeError, ValueError):
        return False
