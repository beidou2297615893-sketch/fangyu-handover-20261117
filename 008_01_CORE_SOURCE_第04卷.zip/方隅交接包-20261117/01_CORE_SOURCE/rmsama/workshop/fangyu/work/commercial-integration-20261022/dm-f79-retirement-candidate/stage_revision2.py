from pathlib import Path
import json,subprocess,sys
W=Path(__file__).resolve().parent;Q=W/'qa-only-project'
p=subprocess.run([sys.executable,'-B',str(Q/'work/ui-native-r57/freeze_ui.py'),'--stage'],cwd=Q,capture_output=True)
(W/'QA-STAGE-REVISION2-STDOUT.txt').write_bytes(p.stdout);(W/'QA-STAGE-REVISION2-STDERR.txt').write_bytes(p.stderr);assert p.returncode==0,p.stderr.decode('utf-8','replace')
stage=json.loads(p.stdout.decode('utf-8-sig'));assert stage['status']=='STAGED' and Path(stage['release']).is_relative_to(Q)
(W/'QA-STAGE-CURRENT.json').write_text(json.dumps(stage,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps({'release':stage['release_id'],'manifest':stage['manifest_sha256'],'resources':stage['files']}))
