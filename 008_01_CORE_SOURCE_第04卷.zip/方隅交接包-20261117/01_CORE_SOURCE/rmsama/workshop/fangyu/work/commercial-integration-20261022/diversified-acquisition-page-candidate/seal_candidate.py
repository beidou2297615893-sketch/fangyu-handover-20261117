from pathlib import Path
import hashlib,json
W=Path(__file__).resolve().parent;P=W.parents[2];F=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v74/project';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pins=json.loads((W/'BASE-AND-CANDIDATE-PINS.json').read_text('utf-8'));items=pins['files']
for rel,v in items.items():
    assert sha(W/'candidate'/rel)==sha(W/'project'/rel)==v['sha256']
    if v['beforeSha256'] is not None:assert sha(F/rel)==v['beforeSha256'] and v['CRLFPreserved'] is True
app='work/ui-approved-implementation/ui-preview/app.mjs';acq='work/ui-approved-implementation/ui-preview/pages/acquire.mjs'
before=(F/app).read_bytes();after=(W/'candidate'/app).read_bytes();start=b'async function startAcquisition(){';end=b'function ownedUnconfirmedTask'
assert before[before.index(start):before.index(end)]==after[after.index(start):after.index(end)]
assert sha(F/acq)==sha(W/'project'/acq)==pins['originalAcquireSha256']
assert 'sourceSelection:null' not in (W/'candidate/work/ui-approved-implementation/ui-preview/pages/diversified-acquisition.mjs').read_text('utf-8')
main=json.loads((W/'CHROMIUM-RESULTS.json').read_text('utf-8'));secondary=json.loads((W/'CHROMIUM-SECONDARY-RESULTS.json').read_text('utf-8'))
assert main['status']==secondary['status']=='PASS' and len(main['checks'])==9 and len(secondary['checks'])==2
assert not main['pageErrors'] and not main['externalRequests'] and not secondary['errors']
for folder in (W/'main-ui-native-evidence',W):
    native=json.loads((folder/'UI-NATIVE-RESULTS.json').read_text('utf-8'));closed=json.loads((folder/'UI-SERVER-CLOSED.json').read_text('utf-8'))
    assert native['status']=='PASS' and native['allRecordsByteIdentical'] and native['taskAndAccountRowsUnchanged'] and closed['closed'] and not closed['blocked']
    assert not any(op in ('intent_analyze','ai_attempt_status','device_account_claim') for op in native['syntheticTransportOperations'])
cleanup=json.loads((W/'PROCESS-CLEANUP.json').read_text('utf-8'));assert not cleanup['ownPythonNodeProcesses']
# Every original frozen input except the explicit four replacements stays exact.
unified=json.loads((F.parent/'UNIFIED-PINS.json').read_text('utf-8'));checked=0
for row in unified['files']:
    p=W/'project'/row['path'];expected=items.get(row['path'],{}).get('sha256',row['sha256']);assert sha(p)==expected,row['path'];checked+=1
stage=json.loads((W/'STAGE.json').read_text('utf-8-sig'))
report={'status':'SEALED_DIVERSIFIED_ACQUISITION_UI_CANDIDATE','base':'Exact F74 source UI, same as S at capture; snapshot and fresh candidates not overlaid','files':items,'filesCount':6,'newRoute':'diversified',
 'originalStartAcquisitionBytesUnchanged':True,'originalAcquireFileBytesUnchanged':True,'originalFrozenSourceInputsChecked':checked,'allOtherOriginalInputsExact':True,
 'behavior':['Independent navigation immediately below 获客; full route/title/hash/body/data-current/fit viewport/read polling/auth handling','Keyword page retains current and next account names and original account selector modal limited to keywords; Apply explicitly changes only next draft','Diversified offers note_links/profiles/own_interactions through original source preview, account selection, modal confirmation and existing backend','Page navigation never changes source/account or starts collection; current task/source/account/cursor is shown independently from next confirmed choice','Keyword start confirmation explicitly selects source:null before original start; cannot secretly run last profile source','Diversified start requires this-page explicit selection marker/current auth epoch/exact account/supported preview and a final confirmation','Unknown/pending request, store/person/platform/account/epoch changes and delayed preview cannot bypass original request-key authority','Fresh UI helper is optional composition only: actual state passed unmodified; sourceKind/fresh options remain original actions. Full combined fresh candidate integration still belongs to root'],
 'actualValidation':{'originalVerifyReleaseReadPublicDependencyGuardCreateBackend':True,'originalIndexFitIframeCanvasAppFullStack':True,'nativeOwnedSyntheticEmployeeLogin':True,'nativeSourcePreviewAndExplicitProfileApply':True,'nativeKeywordsOnlyAccountChoiceAndDraftAccountChange':True,'nativeOriginalTaskAccountStoreRecordBodiesByteIdentical':True,'mainChromiumGroups':9,'secondaryChromiumGroups':2,'controlledUiOnlyBindingCases':5,'widths':[1255,390],'outerScrollWidths':[1255,390],'innerWidths':[1476,459],'innerScrollWidths':[1476,459],'computedBodyFontPx':18,'physicalBodyFontPx':15.3,'unauthenticatedDirectHashRejectedToLogin':True,'noActualAcquisitionStartOrResumePosted':True,'noAccountCreateOrConnectPosted':True},
 'privateStage':{'release':stage['release'],'releaseId':stage['release_id'],'manifestSha256':stage['manifest_sha256'],'resources':stage['files'],'notFrozenF74orF75':True,'notDistribution':True},
 'evidence':{name:sha(W/name) for name in ('CHANGES.patch','BASE-AND-CANDIDATE-PINS.json','CHROMIUM-RESULTS.json','CHROMIUM-SECONDARY-RESULTS.json','UI-NATIVE-RESULTS.json','main-ui-native-evidence/UI-NATIVE-RESULTS.json','PROCESS-CLEANUP.json','diversified-1255.png','diversified-390.png','keyword-accounts-1255.png','keyword-account-modal-390.png','diversified-bottom-1255.png')},
 'limits':['Development headless Chromium with owned synthetic identities/data only; original production Native window not touched and no user visual approval claimed.','Positive start callback guards are controlled Chromium UI states. No real collection/provider/model/platform call or successful actual task start is claimed.','Private UI stage is based on F74 backend; source-only fresh recovery and held-analysis snapshot candidates remain separate for root three-way integration and final frozen verification.','No new customer database, second runner or backend permission change. No S/F/N/outputs/production modifications.','Initial fixture option-visibility timeout is retained; fixed by waiting for option attachment, no product change. Initial admin synthetic fixture empty selection corrected through original select_store before account seeding.'],
 'realExternalCalls':0,'realPlatformModelCalls':0,'productionAccess':False,'allOwnServersAndBrowsersClosed':True,'writeStopped':True}
(W/'FINAL-RECEIPT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8')
(W/'HANDOFF.md').write_text('多样化获客页面候选已封。左侧“获客”下增加独立入口；指定笔记、博主主页与我的互动继续使用原来源核对、账号与确认流程。关键词页仍显示当前/下次采集账号，并能用原账号窗口明确选用关键词采集账号。切页仅显示草稿与原任务，不开始采集，不替换原账号或断点。\n\n完整原Native工厂、原fit外壳与完整app的11组真实开发无头Chromium检查通过，1255与390宽度无横向溢出，正文实际约15.3像素。来源核对、账号应用和迟到回执均使用自有合成数据；账号与任务记录前后逐字不变。\n\n原开始函数与整个原获客模块未改。另一个“保留旧批新开一轮”候选只预留组合接口，需root三方合并后验证，不把本候选当成真实平台采集或用户界面已认可。\n','utf-8')
members=[]
for p in sorted(W.rglob('*')):
    if p.is_file() and not p.is_relative_to(W/'project') and p.name!='SEALED.json':members.append({'path':p.relative_to(W).as_posix(),'sha256':sha(p),'bytes':p.stat().st_size})
(W/'SEALED.json').write_text(json.dumps({'status':'SEALED_READ_ONLY','finalReceiptSha256':sha(W/'FINAL-RECEIPT.json'),'sourceFiles':items,'qaStageManifestSha256':stage['manifest_sha256'],'files':members,'writeStopped':True},ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps({'receiptSha256':sha(W/'FINAL-RECEIPT.json'),'sealSha256':sha(W/'SEALED.json'),'patchSha256':sha(W/'CHANGES.patch'),'files':{k:v['sha256'] for k,v in items.items()}},ensure_ascii=False))
