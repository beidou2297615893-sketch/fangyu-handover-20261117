from pathlib import Path
import datetime, hashlib, json

D = Path(__file__).resolve().parent
P = D.parents[2]
N = P / 'work/ui-native-r57'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
diag = json.loads((D / 'ACTUAL-ENTRY-DIAGNOSTICS.json').read_text('utf-8'))
business = json.loads((D / 'PROTECTED-BUSINESS-AFTER-INSTALL.json').read_text('utf-8'))
delivery = json.loads((D / 'PUBLIC-INTERNAL-DELIVERY.json').read_text('utf-8'))
assert business['sameAsBeforeInstall'] is True
assert sha(N / 'run_workbench.py') == diag['launcherSha256']
assert sha(N / 'FROZEN.json') == diag['frozenSha256']
assert sha(N / 'state/production-workspace.json') == diag['bindingSha256']
package = P / 'outputs/三合一交付/普通电脑内测版/方隅工作台_受限内测安装包.exe'
assert sha(package) == delivery['packageSha256']
evidence = {name: sha(D / name) for name in (
    'ROOT-ENTRY-APPROVAL.json', 'ACTUAL-ENTRY-DIAGNOSTICS.json',
    'PROTECTED-BUSINESS-BEFORE-INSTALL.json', 'PROTECTED-BUSINESS-AFTER-INSTALL.json',
    'PUBLIC-INTERNAL-DELIVERY.json')}
out = {'status': 'NEXT_LAUNCH_INSTALLED_AND_DIAGNOSED_DATA_UNCHANGED',
       'recordedAtUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
       'releaseId': 'ui-r57-20261023T040139Z-6793c840',
       'canonicalLauncherSha256': diag['launcherSha256'], 'canonicalFrozenSha256': diag['frozenSha256'],
       'bindingSha256': diag['bindingSha256'], 'evidence': evidence,
       'accountRecords': 3, 'commentRecords': 1888, 'originalAuthors': 1129,
       'taskRecords': 40, 'originalReplies': 4,
       'allSevenProtectedBusinessDigestsAndAccountMetadataUnchanged': True,
       'oldBackupRestoredOverCurrentData': False, 'platformCredentialsOrSessionsRead': False,
       'realPlatformOrModelRequests': 0, 'forcedWindowRestart': False,
       'actualCurrentHumanNativeReleaseVerifiedAs77': False,
       'userReopenQuestionAlreadyPendingDoNotRepeat': True,
       'publicLimitedInternalPackageSha256': delivery['packageSha256'],
       'allAgentsCompletedThisRound': True, 'allRootExecsCompletedThisRound': True,
       'fullGoalComplete': False, 'commercialAcceptance': False}
(D / 'INSTALLATION-FINAL.json').write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding='utf-8')
section = '''

## 2026-10-23 12:20 BJT 下一启动77实际安装完成，数据未恢复覆盖

最终入口独审9a4e8db4cfb9b135872bc9524cc023c745769d77a2a7cd4bc762a34a77a2657c真正执行原check通过（全部F77+65/72/73/74/75/76闭包/14证据/CAS）。root仅INSTALLATION_REVIEWED单布尔变更，入口0034bec93c615e89a67b4b0e6011941d92c8f893500d46df1caed979deb8f8ef；原安装器9909…d0f6及备份/失败回滚不变。原 --candidate candidate-unified-v77 --install --ack-recovery-checkpoint 已exit0，session90158结束。原75入口备份在delivery-v77/next-launch-prepared/candidate-unified-v77/canonical-entry-before，不再重复安装。

当前N下一启动77：launcher52c4db8cddb64802121c1a77d25f86149ba321f7427a45f46a4758d577e3fe3f；FROZEN745f1aa1d7e75bc38fecc29ab133d635dffb68c36072e3ac0cb406e7a8958544；binding14cf53964f5d44d123e989805ea741669ab3f05054e730ddcb299a0aac51a9cb原样。实际原N --check通过274资源，--self-test通过134checks/122publicURL，未开Native、未import业务、无平台或模型调用。D77/ACTUAL-ENTRY-DIAGNOSTICS封存，不把诊断当真人首开。

D77安装前04:08:46Z/安装后04:18:10Z只读对比：3账号非秘密元数据、1888评论/40tasks/4reply/1794AI/1465rental_assessments/1888unique_leads/3contact_events及全部原7类行digest完全相同；原1129author归并数保留。未读凭据会话，未用旧备份覆盖现有DB。PROTECTED-BUSINESS-AFTER-INSTALL sameAsBeforeInstall=true。账号不是删除，是旧AI_CONTEXT_REQUIRED409导致整快照读取崩溃；修复进入next77。

public受限内测包现已从旧73更新77：SFXa8220d69b0f77b063d79fa8d7eaa2abe39f7abed59397df31d792a016ff4d2e3/285864885B。旧73exe38d3fcc329f44a38045cc1e9865d2a5312464c58fa918a3555e5a7c110ad4eb8与报告/readme逐字节备份在outputs/三合一交付/历史内测版/账号读取修复前保留。新报告bcf22cdb07c179846e01bc88452c408ffef7a560c01b9e36ac9a84230f835b5b；readme484b139dddc59fdec4b350a207ca0ab46a10362136d61c7171f98847340c8486。报告明确受限、原电脑无需重装、自动内容生成及内测真实平台开关仍关闭，未暗示完整商业发布。

12:17BJT只读CIM仍旧74 parent5500/child2936，创建10:15:58；没有强制关闭/重启本人窗口。本人重开原快捷方式问答仍pending，不重复问；未取得77实际Native界面或真人账号恢复确认。三个原agent本轮全部completed，无live子任务/exec；需要后续新工程时followup原agent，不重复启动同任务。未恢复已删automation10、未重做已完成model切换。完整goal仍active，私信/直播/真实发布/多账号调度/关键词研究/生成媒体等真实工程缺口保持，不标complete。下一步优先本人重开后的实际版本与账号/获客状态；不盲目触平台/付费分析、不把隔离UI验收冒充真实平台。D77/INSTALLATION-FINAL.json索引本轮安装、数据和交付证据。
'''
handoff = D.parent / 'HANDOFF-THREE-IN-ONE-LATEST.md'
with handoff.open('a', encoding='utf-8') as stream:
    stream.write(section)
status = P / 'memory/STATUS.md'
with status.open('a', encoding='utf-8') as stream:
    stream.write('''

## 2026-10-23 12:20 账号显示恢复已装下一启动77

实际按原CAS备份安装77，原入口check(274资源)/self-test(134checks)通过；增加定位访谈与329许可专家方法检索、修复首次读取前账号模式预约、保留75账号快照恢复与独立多样化入口。安装前后3账号元数据/1888评论/1129作者/40任务/4回复及原7类业务digest一致，未恢复旧DB覆盖、未读凭据会话。旧74本人窗口仍保留，已请求重开原桌面快捷方式，77真实Native和平台未验，问答仍pending不重复询问。

受限普通电脑包同步77约286MB，旧73包/说明逐字节归档；技术验收不等同完整商业验收。所有本轮agent/exec结束，完整goal仍active，私信/直播/真实发布/多账号调度/关键词研究/生成媒体等工程缺口未缩减。精确新旧pins及证据见work/commercial-integration-20261022/delivery-v77/INSTALLATION-FINAL.json和HANDOFF-THREE-IN-ONE-LATEST.md。未发送真实评论/私信/作品、未新付费、未重启本人窗口。
''')
print(json.dumps({'status': out['status'], 'installationReceiptSha256': sha(D / 'INSTALLATION-FINAL.json'),
                  'accountRecords': 3, 'commentRecords': 1888, 'fullGoalComplete': False}))
