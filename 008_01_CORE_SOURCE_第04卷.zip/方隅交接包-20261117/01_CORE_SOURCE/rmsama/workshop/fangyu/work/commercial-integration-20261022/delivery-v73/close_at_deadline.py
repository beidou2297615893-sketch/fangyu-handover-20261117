"""After the authorized deadline and monitor deletion, record an accurate handoff."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

P = Path('C:/积木软件工坊/项目/方隅公寓客户版')
W = P / 'work/commercial-integration-20261022'
D = W / 'delivery-v73'
now = datetime.now(timezone.utc)
if now < datetime(2026, 10, 23, 0, 0, tzinfo=timezone.utc):
    raise RuntimeError('The authorized deadline has not arrived')
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
delete_path = W / 'DEADLINE-AUTOMATION-DELETE-RECEIPT.json'
delete = json.loads(delete_path.read_text('utf-8'))
if delete['automationId'] != 'automation-10' or delete['toolReportedSuccess'] is not True:
    raise RuntimeError('Official automation deletion has not succeeded')
candidate_path = W / 'DEADLINE-CANDIDATES.json'
candidates = json.loads(candidate_path.read_text('utf-8'))
if candidates['productionCandidatesMerged'] is not False or candidates['allOwnedWorkersTerminal'] is not True:
    raise RuntimeError('The final worker or delivery state has not been checked')
for path, expected in candidates['pinnedEvidence'].items():
    if sha(Path(path)) != expected:
        raise RuntimeError('Final evidence changed: ' + Path(path).name)
health = D / 'DEADLINE-HEALTH.json'
if sha(health) != '6ba7708228bd52d3e53a184351d19e909ae9716304c590787fecb08f9952aaf8':
    raise RuntimeError('Final preservation evidence changed')
package = P / 'outputs/三合一交付/普通电脑内测版/方隅工作台_受限内测安装包.exe'
if sha(package) != '38d3fcc329f44a38045cc1e9865d2a5312464c58fa918a3555e5a7c110ad4eb8':
    raise RuntimeError('Delivered installer changed')

archive = D / 'deadline-closeout'
if archive.exists():
    raise RuntimeError('Preserve earlier deadline closeout')
archive.mkdir()
handoff = W / 'HANDOFF-THREE-IN-ONE-LATEST.md'
report = P / 'outputs/三合一交付/当前交付核对.md'
status = P / 'memory/STATUS.md'
session = P / 'memory/sessions/2026-10-23-三合一更新与普通电脑内测.md'
original_hashes = {}
for path in (handoff, report, status, session):
    original_hashes[str(path)] = sha(path)
    (archive / path.name).write_bytes(path.read_bytes())

text = handoff.read_text('utf-8')
start = text.index('## 当前live与最后一小时（不重复派工）')
end = text.index('## 真正尚缺与已关闭事项', start)
closing = '''## 08:00 BJT 到点交接：本次监控已结束

已按用户截止时间通过官方automation_update(mode=delete,id=automation-10)删除本监控。完整目标尚未达成，未调用update_goal complete。旧get_goal blocked不能由现有工具恢复active；不能把该旧标签当成工作未发生，也不能伪称已完成。模型切换分支早已结束，不重切、不自发消息、不兑换额度。当前额度工具缺失，未知就是未知。

所有本轮自有agent/测试进程已收束，无新的后台工作留待自动执行。原用户窗口72的PID19036/66168保留，下一启动73与已交付普通电脑受限内测SFX38d3…4eb8均不改；两个末期候选均未合入、未安装，不伪称本人已可用。

07:52最终只读DEADLINE-HEALTH.json SHA6ba7708228bd52d3e53a184351d19e909ae9716304c590787fecb08f9952aaf8：原PID创建时间同、HTTP200、N下一入口pin同、F73精确3156全文件集合与所有hash同、原7类业务逐行同备份和pre/post/07:00。原1888评论/1129作者/40任务/4回复与绑定保留；无真实发送、新付费、账号操作、生产恢复或数据改写。

末期候选和精确证据见DEADLINE-CANDIDATES.json（root固定pins），概述：

''' + candidates['technicalSummary'] + '''

下一次继续必须从这些候选的**实际未完成项**开始，重新查live句柄，不能重复安装73或抹掉任何红证据。源合同绿、原工厂/默认维护拒绝、正向开发QA、客户UI、正式包与真实平台证据分别保留。两个作者原窗口全量范围仍按THREE-IN-ONE-SCOPE和18行范围对账，不能用源码目录数量替代完整接入。

'''
text = text[:start] + closing + text[end:]
stamp_start = text.index('更新：')
stamp_end = text.index('。', stamp_start)
text = text[:stamp_start] + '更新：' + now.isoformat() + text[stamp_end:]
handoff.write_text(text, encoding='utf-8')

report_addition = '''

## 本次夜间核验交接

已到约定早上8点，本次自动监控已删除。原工作窗口继续保留，本轮新增功能下次重开后加载；原客户、账号和断点未变。原电脑不必安装普通电脑内测包。

另已准备“历史分析是否使用本店最新规则”和“文字PDF导入”的源码候选，尚未合入当前软件；部分验证仍有未决项，不能当作已可用功能。完整三合一尚未完成，以上工程缺口和真实验收项继续保留。本轮没有替本人发送评论、私信或作品，也没有重新收费分析历史客户。
'''
with report.open('a', encoding='utf-8') as stream:
    stream.write(report_addition)
memory_addition = '''

## 2026-10-23 08:00 到点交接

按用户硬截止删除automation-10，所有本轮自有任务已收束；不标完整goal complete。实际窗口仍72，next73和已交付SFX38d3…4eb8保持。07:52最终全3156源/入口/实际进程与HTTP/7类业务保护核验通过，1888评论/1129作者/40任务保留。末期本地提示词版本与文字PDF都只候选未合入，真实未验证和红例完整保留；具体新旧pins、工厂/正向QA边界及下一步在work/commercial-integration-20261022/DEADLINE-CANDIDATES.json和HANDOFF-THREE-IN-ONE-LATEST.md。用户回来后继续须先查实际句柄和上述交接，不重复安装/模型切换、不自动启动平台请求或付费分析。
'''
for path in (status, session):
    with path.open('a', encoding='utf-8') as stream:
        stream.write(memory_addition)
result = {
    'status': 'CLOSED_AUTHORIZED_NIGHT_MONITOR_AT_DEADLINE_WITH_GOAL_UNFINISHED',
    'atUtc': now.isoformat(), 'automationId': 'automation-10',
    'officialDeleteReceiptSha256': sha(delete_path),
    'candidateHandoffSha256': sha(candidate_path), 'deadlineHealthSha256': sha(health),
    'beforeDocuments': original_hashes,
    'afterDocuments': {str(path): sha(path) for path in (handoff, report, status, session)},
    'productionOrOriginalProcessesModified': False, 'fullGoalComplete': False,
    'ownBackgroundWorkContinues': False,
}
receipt = D / 'DEADLINE-CLOSEOUT.json'
receipt.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'status': result['status'], 'receiptSha256': sha(receipt)}, ensure_ascii=False))
