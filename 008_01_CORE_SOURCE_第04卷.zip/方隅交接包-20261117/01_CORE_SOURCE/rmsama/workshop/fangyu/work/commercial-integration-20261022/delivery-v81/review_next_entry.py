from pathlib import Path
from datetime import datetime,timezone
import ast,hashlib,json,subprocess,sys
D=Path(__file__).resolve().parent;W=D.parent;P=D.parents[2];E=W/'f81-next-entry-candidate';N=P/'work/ui-native-r57'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(E/'FINAL-RECEIPT.json')=='889289caa69d39f2f4c2643f9eb343b4f2c9f10bd8d6ac0e8564d3e1084eae8b'
assert sha(E/'SEALED.json')=='df5a6f55096a537fd00c95c8dee8b1c6c22c825022a08227968727d0d1ac8a7f'
entry=E/'install_verified_entry.py'
assert sha(entry)=='5cbd743144e33de461b6be833063544a97916c5ae453c975397a4f5db1d8b57f'
old=(W/'f80-next-entry-candidate/install_verified_entry.py').read_bytes();new=entry.read_bytes()
def funcs(raw):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(raw).body if isinstance(n,ast.FunctionDef)}
a,b=funcs(old),funcs(new)
assert a.keys()==b.keys() and {name for name in a if a[name]!=b[name]}=={'check','main'}
assert a['install']==b['install']
expected={'run_workbench.py':'b507cc91fb378662a72a5e4b538fd855b0e65e8b404d1a3747760751a967e9cb',
          'FROZEN.json':'4b44027f451b9efe7b727ed097564ce38c1d4957d60e0e6731570576820f2245',
          'state/production-workspace.json':'14cf53964f5d44d123e989805ea741669ab3f05054e730ddcb299a0aac51a9cb'}
assert all(sha(N/name)==pin for name,pin in expected.items())
process=subprocess.run([sys.executable,'-I','-B',str(entry),'--candidate','candidate-unified-v81','--check'],capture_output=True,encoding='utf-8',errors='replace',timeout=180)
assert process.returncode==0,(process.stdout,process.stderr)
result=json.loads(process.stdout);assert result['status']=='CHECK_ONLY' and result['writes']==0 and not result['restart'] and result['verifiedFiles']==3332
assert all(sha(N/name)==pin for name,pin in expected.items())
receipt={'status':'PASS_F81_NEXT_ENTRY_INDEPENDENT_REVIEW','createdUtc':datetime.now(timezone.utc).isoformat(),
    'approvedForNextLaunchOnly':True,'actualReadOnlyCheckPassed':True,'actualN80CasPinsVerified':True,
    'originalInstallTransactionAndCasBackupRollbackUnchanged':True,'reviewedEntrySha256':sha(entry),
    'reviewedAuthorReceiptSha256':sha(E/'FINAL-RECEIPT.json'),'reviewedAuthorSealSha256':sha(E/'SEALED.json'),
    'rootFinalPinsSha256':sha(D/'FINAL-PINS.json'),'rootAggregateValidationSha256':sha(D/'AGGREGATE-VALIDATION.json'),
    'actualCheck':result,'originalMethodsIdenticalExceptTwoInspectedLocalPreparationFunctions':True,
    'inspectedDifferences':['Exact F81 fixed source and local evidence allowlist','Current N80 compare-and-swap pins','Extra full F80 rollback closure','Own prepared validation/evidence paths'],
    'productionDataRead':False,'nativeWritten':False,'windowStoppedOrRestarted':False,
    'platformOrModelCalls':0,'ordinaryPackageOrHumanPlatformAcceptance':False,'fullGoalComplete':False}
target=D/'NEXT-ENTRY-ROOT-REVIEW.json';assert not target.exists();target.write_text(json.dumps(receipt,ensure_ascii=False,indent=2),'utf-8')
print(json.dumps({'status':receipt['status'],'rootReviewSha256':sha(target)}))
