from pathlib import Path
import sqlite3,json
P=Path('C:/积木软件工坊/项目/方隅公寓客户版');D=Path(__file__).resolve().parent
b=json.loads((P/'work/ui-native-r57/state/production-workspace.json').read_text('utf-8-sig'))
c=sqlite3.connect((Path(b['data_dir'])/'workspace.sqlite3').as_uri()+'?mode=ro',uri=True);c.execute('PRAGMA query_only=ON');c.execute('BEGIN')
rows=c.execute("SELECT json_extract(body,'$.state'),COUNT(*) FROM records WHERE entity='content_publication_attempt_v1' AND tenant_id IN (SELECT DISTINCT tenant_id FROM records WHERE entity='accounts' AND json_extract(body,'$.cloud_owner')=?) GROUP BY json_extract(body,'$.state')",(b['owner'],)).fetchall()
c.close();out={'readOnly':True,'publicationAttemptCount':sum(v for _,v in rows),'states':dict(rows),'productionWritten':False,'credentialsOrSessionsRead':False,'currentObservedOverlap':any(s in ('unknown','dispatching') and n for s,n in rows),'notAGuaranteeForFutureRuns':True}
target=D/'PUBLICATION-OVERLAP-AUDIT.json';assert not target.exists();target.write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(out))
