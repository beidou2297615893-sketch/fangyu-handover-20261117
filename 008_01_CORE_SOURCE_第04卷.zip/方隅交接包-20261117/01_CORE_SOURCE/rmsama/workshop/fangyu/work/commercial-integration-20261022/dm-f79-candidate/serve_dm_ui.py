"""Real original factory/HTTP/guards/Adapters/Popen/NodeCLI, synthetic Bridge only."""
from pathlib import Path
from copy import deepcopy
from types import SimpleNamespace
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
import hashlib,http.client,importlib.util,json,os,re,shlex,sys,threading,time,uuid
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=W.parents[2];S=W/'qa-only-project'
stage_paths=sorted((S/'work/ui-native-r57/candidates').glob('*.json'));stage=json.loads(stage_paths[-1].read_text('utf-8-sig'));R=Path(stage['release'])
OUT=W/('factory-'+uuid.uuid4().hex);OUT.mkdir();events=[];wire=[];blocked=[];processes=[];checks=[];reply_permission=[True]
save=lambda name,v:(OUT/name).write_text(json.dumps(v,ensure_ascii=False,indent=2,default=str),'utf-8')
def audit(event,args):
 if event=='subprocess.Popen':
  argv=args[1];argv=[v.strip('"') for v in shlex.split(argv,posix=False)] if isinstance(argv,str) else argv
  assert Path(argv[0]).resolve()==S/'work/ui-runtime-r55/work/runtime/douyin-bridge/node.exe',argv
  assert Path(argv[1]).resolve()==S/'work/ui-runtime-r55/work/runtime/douyin-bridge/dm_workbench_cli.js',argv
  assert Path(args[2]).resolve().is_relative_to(OUT),args;processes.append(list(argv))
 elif event in ('os.system','os.startfile','os.posix_spawn'):blocked.append(event);raise RuntimeError('Only fixed internal CLI process')
 if event in ('socket.connect','socket.bind') and (not isinstance(args[1],tuple) or args[1][0] not in ('127.0.0.1','::1')):blocked.append(event);raise RuntimeError('Loopback only')
 if event=='socket.getaddrinfo' and args[0] not in ('127.0.0.1','::1','localhost',None):raise RuntimeError('No external DNS')
 if event=='sqlite3.connect' and not Path(args[0]).resolve().is_relative_to(OUT):raise RuntimeError('Own DB only')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  path=Path(os.fsdecode(args[0])).absolute();mode,flags=args[1] or '',args[2] or 0
  if (any(c in str(mode) for c in 'wax+') or isinstance(flags,int) and flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC)) and not path.is_relative_to(OUT) and path!=W/'UI-SERVER.json':raise RuntimeError('Own evidence/data only')
sys.addaudithook(audit)
def load(name,path):
 m=importlib.util.module_from_spec(importlib.util.spec_from_loader(name,loader=None));m.__file__=str(path);sys.modules[name]=m;exec(compile(path.read_bytes(),str(path),'exec'),m.__dict__);return m
fixture=load('dm_original_identity_fixture',P/'work/acquisition-core-repair-20261018/gui-fixture/base_fixture.py');cloud=fixture.CloudStandin(json.loads((P/'work/central-store-config/compiled-fixture.json').read_text('utf-8-sig')));company=json.loads((S/'work/app/company.json').read_text('utf-8-sig'))
def transport(*a,**k):
 value=cloud(*a,**k);value['environment_id']=company['managedWorkspace']['environment_id'];value['user']['can_reply']=reply_permission[0];return value
integration=load('integrations',R/'resources/platform-runtime/vendor-src/integrations.py');integration.request_json=transport
host=load('dm_actual_native_host',R/'ui_native_host.py');_,files=host.verify_release(R,stage['manifest_sha256']);host.verify_backend_dependencies(R,files,S)
backend=host.create_backend(R,files,project_root=S,data_dir=OUT/'data',company=company);runtime=backend.platform_runtime;core=backend.core
runtime.server._configure_bundled();runtime._platform_setup=True
core.remote_safety_hold=False;core.employee_release_device_id='dm-synthetic-device';core.employee_release_until_monotonic=time.monotonic()+600
accounts={};send_state=['sent'];bridge_calls=[];slow_listen=[False];stop_received=threading.Event()
class Bridge(BaseHTTPRequestHandler):
 def log_message(self,*a):pass
 def do_POST(self):
  data=json.loads(self.rfile.read(int(self.headers['Content-Length'])));expr=data['expression'];bridge_calls.append({'connId':data.get('connId'),'expressionKind':'install' if expr.startswith('(function installReviewedDM') else expr.split('(...')[0]})
  if expr.startswith('(function installReviewedDM'):value='fangyu-dm-bounded-v1'
  else:
   operation=expr.split('(...')[0].rsplit('.',1)[1];args=json.loads(expr.split('(...',1)[1][:-1]);account=next(a for a in accounts.values() if a['conn_id']==data['connId']);assert args[0]==account['platform_uid'] if operation!='stop' else True
   mode=core.account_mode_status(account['id'],user['tenant_id']);assert mode['status']=='active' and mode['mode']==('replies' if operation=='send' else 'collection'),mode
   foreign=type(core.continuous.leases)(core.store,'foreign-dm-review')
   try:foreign.acquire(account['id'],user['tenant_id'],'publishing','foreign-publication')
   except ValueError:pass
   else:raise AssertionError('Original atomic mode lease bypassed')
   wire.append({'operation':operation,'args':args,'connection':data['connId'],'mode':mode,'foreignModeBlocked':True})
   if operation=='listen':
    if slow_listen[0]:stop_received.wait(3)
    uid,request,timeout=args;messages=[]
    for i in range(8):
     recipient=str(9007199254741001+i%4);messages.append({'message_id':str(9223372036854700001+i),'conversation_id':f'0:1:{uid}:{recipient}','sender_uid':recipient,'recipient_uid':uid,'text':'仅合成入站私信 '+str(i),'direction':'inbound','observed_at':'2026-10-23T04:40:00+00:00','platform_sent_at':None})
    value={'contract':'fangyu-dm-bounded-v1','state':'received','account_uid':uid,'request_id':request,'messages':messages,'history_available':False}
   elif operation=='send':
    uid,recipient,text,request=args;value={'contract':'fangyu-dm-bounded-v1','state':send_state[0],'request_id':request,'account_uid':uid,'recipient_uid':recipient}
    if send_state[0]=='sent':value.update(message_id='9223372036854775807',conversation_id=f'0:1:{uid}:{recipient}',client_message_id=request)
   else:stop_received.set();value={'contract':'fangyu-dm-bounded-v1','state':'stopped','request_id':args[0]}
  raw=json.dumps({'ok':True,'value':value,'connection':data.get('connId')}).encode();self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(raw)));self.end_headers()
  try:self.wfile.write(raw)
  except (BrokenPipeError,ConnectionResetError):pass
bridge=ThreadingHTTPServer(('127.0.0.1',0),Bridge);bt=threading.Thread(target=bridge.serve_forever,daemon=True);bt.start()
server=host.StaticServer(R,files,backend=backend,cookie_name='dm_fixture_session');st=threading.Thread(target=server.serve_forever,daemon=True);st.start();origin='http://127.0.0.1:'+str(server.server_port);headers={};passed=False
def request(method,path,payload=None):
 c=http.client.HTTPConnection('127.0.0.1',server.server_port,timeout=30);c.request(method,path,json.dumps(payload,ensure_ascii=False).encode() if payload else None,headers);r=c.getresponse();raw=r.read();status=r.status;found=dict(r.getheaders());c.close();value=json.loads(raw);log=deepcopy(payload)
 if log and log.get('action')=='login':log['data']['password']='synthetic omitted'
 events.append({'method':method,'path':path,'payload':log,'status':status,'body':value});save('HTTP.json',events);return status,value,found
def action(name,data,expected=200):
 code,body,h=request('POST','/api/workbench',{'action':name,'data':data});assert code==expected,(name,code,body);return body,h
serial=0
def dm(name,data,expected=200):return action(name,{'storeId':store,**data},expected)[0].get('dmWorkspace')
def mutate(name,data,expected=200,key=None):
 global serial
 serial+=1;return dm(name,{**data,'requestId':key or 'dm-fixture-operation-'+str(serial).zfill(6)},expected)
def read(account,**data):return dm('dm_workspace_read',{'accountId':account['id'],**data})
def wait_queue(ident):
 for _ in range(300):
  row=dm('dm_queue_read',{'id':ident})
  if row['state'] not in ('prepared','running'):return row
  time.sleep(.03)
 raise AssertionError('Queue did not settle')
def draft(account,conv,text):
 d=mutate('dm_draft_save',{'accountId':account['id'],'expectedVersion':0,'target':{'conversationId':conv['id']},'text':text})
 return mutate('dm_draft_review',{'accountId':account['id'],'id':d['id'],'expectedVersion':d['version'],'confirmed':True})
def prepare(account,ds):return mutate('dm_queue_prepare',{'accountId':account['id'],'drafts':[{'id':d['id'],'version':d['version']} for d in ds]})
def start(q,key=None):return mutate('dm_queue_start',{'id':q['id'],'snapshotDigest':q['snapshotDigest'],'confirmed':True},key=key)
try:
 _,boot,_=request('GET','/api/workbench/bootstrap');headers.update({'Content-Type':'application/json','Origin':origin,'X-Fangyu-CSRF':boot['csrfToken']});_,logged,h=request('POST','/api/workbench',{'action':'login','data':{'username':'fixture-admin','password':fixture.PASSWORD}});headers['Cookie']=h['Set-Cookie'].split(';',1)[0];headers['X-Fangyu-CSRF']=logged['csrfToken'];store=cloud.first_store
 if logged['selection']['storeId']!=store:action('select_store',{'storeId':store,'expectedRevision':logged['selection']['revision']})
 user={**core.session(headers['Cookie'].split('=',1)[1]),'_workbench_store_id':store}
 from assistant.business import BusinessExecutor
 from assistant.xhs_app_context import bind_executor_session
 executor=BusinessExecutor(runtime.server,company['managedWorkspace']['environment_id'],company['id'],user['username']);runtime.service.executor=executor
 saved={'state':'bound','environment_id':company['managedWorkspace']['environment_id'],'company_id':company['id'],'token':'synthetic-device-token','device':{'id':'dm-synthetic-device','owner':user['username']}}
 runtime.service.vault=SimpleNamespace(read=lambda:deepcopy(saved));runtime.service.device=deepcopy(saved['device']);runtime.service.state='online'
 class DeviceCloud:
  def call(self,operation,data,credential):return {'claimed':True}
  def close(self):pass
 runtime.service._cloud=lambda:DeviceCloud();executor.account_claim=runtime.service._claim_xhs_account;bind_executor_session(runtime.service,executor,saved)
 for i in range(2):
  a={'id':'dm-fixture-account-'+str(i),'tenant_id':user['tenant_id'],'cloud_owner':user['username'],'store_id':store,'platform':'douyin','status':'ready','name':'合成私信账号','platform_uid':str(9007199254740993+i),'conn_id':'dm-synthetic-connection-'+str(i)};accounts[a['id']]=a;core.store.put('accounts',a)
 account=list(accounts.values())[0];other=list(accounts.values())[1]
 config=core.store.directory/'bridge'/user['tenant_id']/'config.json';config.parent.mkdir(parents=True,exist_ok=True);config.write_text(json.dumps({'bridge':{'host':'127.0.0.1','port':bridge.server_port,'token':'synthetic-only'}}),'utf-8')
 # Explicit own synthetic positive permission, same as the factory suite.
 for config_value in (runtime.server.company,core.deployment_config):
  flags=config_value['runtime'];flags['public_send_hold']=False;flags['public_reply_hold']=False;flags['public_replies']='enabled';flags.pop('platform_qa_device_id',None)
 executor=BusinessExecutor(runtime.server,company['managedWorkspace']['environment_id'],company['id'],user['username']);runtime.service.executor=executor
 executor.account_claim=runtime.service._claim_xhs_account;bind_executor_session(runtime.service,executor,saved)
 manifest_path=core.store.directory/'adapters/douyin.json';manifest=json.loads(manifest_path.read_text('utf-8'));manifest['dm_contract_verified']=True;manifest_path.write_text(json.dumps(manifest),'utf-8')
 mutate('dm_listen_start',{'accountId':account['id'],'confirmed':True,'timeoutMs':100})
 for _ in range(200):
  value=read(account)
  if value['listeners'][-1]['state']!='listening':break
  time.sleep(.03)
 assert value['conversations']['total']==4,value
 stop=OUT/'STOP';info={'origin':origin,'username':'fixture-admin','password':fixture.PASSWORD,'directory':str(OUT),'stop':str(stop),'stage':stage,'accounts':list(accounts),'syntheticOnly':True,'actualNodeCliSyntheticBridge':True}
 (W/'UI-SERVER.json').write_text(json.dumps(info,ensure_ascii=False,indent=2),'utf-8');print(origin,flush=True)
 deadline=time.monotonic()+900
 while not stop.exists() and time.monotonic()<deadline:time.sleep(.2)
 save('UI-FINAL.json',{'wire':wire,'processes':processes,'realPlatformModelCalls':0,'productionAccess':False,'native':False});passed=True
finally:
 server.shutdown();st.join(3);server.server_close();backend.close();bridge.shutdown();bt.join(3);bridge.server_close();save('FINAL.json',{'status':'PASS' if passed else 'RED_CAPTURED','allOwnServersClosed':not st.is_alive() and not bt.is_alive()});print(str(OUT),flush=True)
