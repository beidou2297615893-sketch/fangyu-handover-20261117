from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
W=Path(__file__).resolve().parent;P=W.parents[2];F=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v80';S=F/'project'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text('utf-8-sig'))
assert sha(F/'STAGED.json')=='1bbce34364b8a8769131bebf1ea1a2edfe83b25a6861756bd72a95923bd895e1'
assert sha(F/'UNIFIED-PINS.json')=='ad24e091a0a2be1fe1e30b9ea75fb20709e05d49e6b49f9b4a3b63298e62757f'
stage=read(F/'STAGED.json');R=Path(stage['release']);assert sha(R/'RELEASE.json')=='1cfeda2e8ca9f372b75bb1dc4e21d5792bc84aa63857b1cd4fc2e4f04d93e120'
pins=read(F/'UNIFIED-PINS.json')['files'];assert len(pins)==3328
assert {p.relative_to(S).as_posix() for p in S.rglob('*') if p.is_file()}=={r['path'] for r in pins}
for r in pins:assert sha(S/r['path'])==r['sha256'],r['path']
manifest=read(R/'RELEASE.json')['files'];assert len(manifest)==282
assert {p.relative_to(R).as_posix() for p in R.rglob('*') if p.is_file()}=={r['path'] for r in manifest}|{'RELEASE.json'}
for r in manifest:assert sha(R/r['path'])==r['sha256'].lower() and (R/r['path']).stat().st_size==r['size'],r['path']
(W/'QA-INPUTS.json').write_text(json.dumps({'label':'independent-f80-g11-dm-frozen-source-only-own-fixtures','project':str(S),'stage':stage,'sourceRoot':str(F)},ensure_ascii=False,indent=2),'utf-8')
copied=[]
for directory,names in [('content-schedule-f79-candidate',['test_factory_schedule.py','serve_schedule_ui.py','test_schedule_ui.mjs']),('dm-f79-retirement-candidate',['test_retirement_factory.py','test_retirement_ui.mjs'])]:
 for name in names:
  src=W.parent/directory/name;body=src.read_text('utf-8')
  if name=='test_retirement_factory.py':
   old="S=W/'qa-only-project'\nstage=json.loads((W/'INPUTS.json').read_text('utf-8'))['stage']"
   new="S=Path(json.loads((W/'QA-INPUTS.json').read_text('utf-8'))['project'])\nstage=json.loads((W/'QA-INPUTS.json').read_text('utf-8'))['stage']"
   assert body.count(old)==1;body=body.replace(old,new,1)
  (W/name).write_text(body,'utf-8')
  copied.append({'original':str(src),'originalSha256':sha(src),'adapted':name,'adaptedSha256':sha(W/name),'change':'Only project/stage inputs' if name=='test_retirement_factory.py' else 'None; exact decoded code and assertions'})
(W/'PREPARE.json').write_text(json.dumps({'status':'PASS_FIXED_F80_INPUTS_BEFORE_EXECUTION','createdUtc':datetime.now(timezone.utc).isoformat(),'sourceFiles':3328,'resources':282,'stageSha256':sha(F/'STAGED.json'),'unifiedSha256':sha(F/'UNIFIED-PINS.json'),'manifestSha256':sha(R/'RELEASE.json'),'frozenInputsSha256':sha(W.parent/'expansion-f79-final-integration/FROZEN-INPUTS.json'),'copiedTests':copied,'productionAccess':False,'noSourcesCopiedOrWritten':True},ensure_ascii=False,indent=2),'utf-8')
print('F80 exact 3328 source / 282 resource closure verified; own fixture-only tests prepared')
