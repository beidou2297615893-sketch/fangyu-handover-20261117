from pathlib import Path
import hashlib,json,subprocess,sys
W=Path(__file__).resolve().parent;Q=W/'qa-only-project'
if '--read-existing' in sys.argv:
    data=(W/'QA-STAGE-STDOUT.json').read_bytes()
else:
    p=subprocess.run([sys.executable,'-B',str(Q/'work/ui-native-r57/freeze_ui.py'),'--stage'],cwd=Q,capture_output=True)
    (W/'QA-STAGE-STDOUT.json').write_bytes(p.stdout);(W/'QA-STAGE-STDERR.txt').write_bytes(p.stderr)
    assert p.returncode==0,p.stderr.decode('utf-8','replace')
    data=p.stdout
try: text=data.decode('utf-8-sig')
except UnicodeDecodeError: text=data.decode('cp936')
stage=json.loads(text);assert stage['status']=='STAGED' and Path(stage['release']).is_relative_to(Q)
(W/'QA-STAGE-PINS.json').write_text(json.dumps({'label':'dm-f79-owned-qa-only-not-formal-freeze','stage':stage,'releaseManifestSha256':hashlib.sha256((Path(stage['release'])/'RELEASE.json').read_bytes()).hexdigest(),'noCanonicalFreezeInstall':True},ensure_ascii=False,indent=2),'utf-8')
print(json.dumps({'release':stage['release_id'],'resources':stage['files'],'sourceFiles':stage['source_files']}))
