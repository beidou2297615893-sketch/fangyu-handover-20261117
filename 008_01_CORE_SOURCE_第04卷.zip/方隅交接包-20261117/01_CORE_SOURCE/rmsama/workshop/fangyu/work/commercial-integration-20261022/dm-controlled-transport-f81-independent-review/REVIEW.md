独立审查通过，范围仅为固定 F81 上 10 源的 typed 私信接点候选；未安装、未真实发送。

输入 FINAL/SEALED/SOURCE/patch SHA 均与委派一致。3332 个 F81 源全部核验，3323 个未改源逐字一致，新增 1 源；原 DMWorkbench、Core、Store、Adapters、账号归属、稳定平台 UID 跨账号预留、原子模式、草稿核对、unknown/退休历史及全部现有 UI 保持原字节。active connection review 仅 materials/pin 变化，purpose、scope、material_limits、public_send_grant=false 保留；连接 service 全部 class/function AST 不变。原 DM protobuf body、通用 Bridge 启动后缀及封定 browser function 精确保留。独立 git apply 重放 10 源逐字匹配。

独立新数据目录、原 freezer/verify/create_backend→原 Core/Store/权限/租约→原 Popen→原固定 Node CLI→真实原 Router/Registry/Client/完整 userscript→仅自有 VM 页面/身份/IM/签名。25 组工厂断言通过，12 个实际 Node 子进程中 1 个是自己的 Bridge host，11 个是原 CLI，11 次 typed 命令。默认 hold 拒绝发送；正向仅在明确改动的自有合成配置中启用，正式 hold 与 dm_contract_verified 未动。稳定 UID 的跨账号成功/同时批量竞争、旧 sent 评论跨渠道阻断通过。unknown 同原 key、不同 key 拒绝、原 create_backend 重开均零新增进程/零重派，原 unknown 字节保持。

独立真实 typed Bridge 10 组通过：固定 listen/stop/send，空/错 token、错 conn/UID/泛型 result、expression/source/history 拒绝；uint64 与原 client request ID 保留。额外探针拒旧脚本、错 source digest、WS 连接、live/外站、过期连接；generic WS result 不能解 typed pending；Node CLI 拒绝 claimed-sent 但原 request ID 错配的回执。独立原工厂反篡改 2 组通过：自己的 QA client 改字节时 active _components 与 DM pin gate 均拒绝，恢复原字节后组件 revision 一致，零 DM CLI。

没有重复运行作者 33 项 UI；UI 源逐字未变，本轮原工厂 HTTP 的 read/draft/review/prepare/start/request read 路径和状态真实验证。作者 1255/390 UI33 仅引用为作者证据，不能写作本次重跑。首次独审 patch 夹具漏了 Git 行尾配置，8 个文件仅 LF/CRLF 不同；保留红字节后用明确 byte-preserving no-index 配置重放逐字通过，未改产品。

所有 own Python/Node/HTTP 已退出，Windows 进程只读核对剩余 0，两个 own Bridge 端口连接拒绝。未改作者 sealed、正式源/数据/输出；未读真人会话或消息，无真人浏览器/Native/真实平台/模型调用。

合版仍有 MERGED-REPIN-REQUIREMENTS 所列 10 个引用文件（含本候选已改者）需要按最终 live+DM 三向合并后的真实字节重算和用途核验；不得靠修改 purpose/material_limits/public_send_grant 绕过。原连接/评论工厂与编译验收必须在 root 最终合版完成。本独审不证明全部用途闭包、真实 IM 签名或送达、小红书 DM、平台历史或后继普通编译包可用，不放开产品默认发送。
