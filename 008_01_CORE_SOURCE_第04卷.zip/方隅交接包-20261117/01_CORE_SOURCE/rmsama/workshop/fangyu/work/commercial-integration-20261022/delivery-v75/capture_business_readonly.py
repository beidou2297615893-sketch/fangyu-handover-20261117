"""Record current business/account metadata digests; never roll back user edits."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,sqlite3,sys
P=Path('C:/积木软件工坊/项目/方隅公寓客户版');D=Path(__file__).resolve().parent
phase=sys.argv[1];assert phase in {'before-install','after-install'}
sha=lambda b:hashlib.sha256(b).hexdigest()
binding_path=P/'work/ui-native-r57/state/production-workspace.json'
binding=json.loads(binding_path.read_text('utf-8-sig'))
c=sqlite3.connect((Path(binding['data_dir'])/'workspace.sqlite3').as_uri()+'?mode=ro',uri=True)
c.execute('PRAGMA query_only=ON');c.execute('BEGIN')
tenants=c.execute("SELECT DISTINCT tenant_id FROM records WHERE entity='leads' AND json_extract(body,'$.cloud_owner')=?",(binding['owner'],)).fetchall();assert len(tenants)==1
tenant=tenants[0][0];rows={}
for entity in ('leads','replies','tasks','ai_cache','rental_assessments_v1'):
 rows['records:'+entity]=c.execute('SELECT entity,id,tenant_id,body FROM records WHERE tenant_id=? AND entity=? ORDER BY entity,id,tenant_id',(tenant,entity)).fetchall()
rows['unique_leads']=c.execute('SELECT * FROM unique_leads WHERE tenant_id=? ORDER BY tenant_id,platform,source_id,lead_id',(tenant,)).fetchall()
rows['contact_events']=c.execute('SELECT * FROM contact_events WHERE tenant_id=? AND cloud_owner=? ORDER BY sequence',(tenant,binding['owner'])).fetchall()
# Read nonsecret metadata only; account sessions/credentials are not copied or parsed.
metadata=c.execute("SELECT id,json_extract(body,'$.platform'),json_extract(body,'$.store_id'),json_extract(body,'$.status'),json_extract(body,'$.name'),json_extract(body,'$.platform_uid') FROM records WHERE entity='accounts' AND tenant_id=? AND json_extract(body,'$.cloud_owner')=? ORDER BY id",(tenant,binding['owner'])).fetchall()
c.close()
summary={name:{'rows':len(value),'sha256':sha(json.dumps(value,ensure_ascii=False,separators=(',',':')).encode())} for name,value in rows.items()}
result={'capturedAtUtc':datetime.now(timezone.utc).isoformat(),'phase':phase,'protectedTablesAndEntities':summary,
 'accountRecords':len(metadata),'accountMetadataSha256':sha(json.dumps(metadata,ensure_ascii=False,separators=(',',':')).encode()),
 'bindingSha256':sha(binding_path.read_bytes()),'readOnly':True,'productionModified':False,'snapshotRestored':False,'credentialsOrSessionsRead':False}
if phase=='after-install':
 before=json.loads((D/'PROTECTED-BUSINESS-BEFORE-INSTALL.json').read_text('utf-8'))
 result['sameAsBeforeInstall']=all(before[k]==result[k] for k in ('protectedTablesAndEntities','accountRecords','accountMetadataSha256','bindingSha256'))
 result['status']='PASS_CURRENT_BUSINESS_AND_ACCOUNT_METADATA_UNCHANGED' if result['sameAsBeforeInstall'] else 'CURRENT_USER_DATA_CHANGED_REVIEW_NO_AUTOMATIC_RESTORE'
else:result['status']='CURRENT_READ_ONLY_BASELINE_NOT_RESTORE_POINT'
target=D/('PROTECTED-BUSINESS-'+phase.upper()+'.json');assert not target.exists();target.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k not in ('protectedTablesAndEntities','accountMetadataSha256','bindingSha256')}))
