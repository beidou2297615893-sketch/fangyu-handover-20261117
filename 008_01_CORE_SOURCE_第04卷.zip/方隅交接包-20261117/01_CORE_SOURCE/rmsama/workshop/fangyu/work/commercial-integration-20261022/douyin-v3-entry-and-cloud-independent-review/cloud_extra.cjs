'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),fs=require('node:fs'),crypto=require('node:crypto');
const D=__dirname,ROOT=path.join(D,'../customer-read-cloud-lease-candidate/cloud-candidate-final');
const {createService}=require(path.join(ROOT,'service.cjs')),policy=require(path.join(ROOT,'customer_read_release.cjs'));
const {releaseState}=require(path.join(ROOT,'release.cjs'));
global.fetch=()=>{throw Error('No external network');};
const checks=[];let requests=0,readOnlyStateReads=0;
function fixture(enabled){
 let state=null,now=1792760000000;
 const store={transaction:async fn=>{const out=await fn(structuredClone(state));state=out.state;return out.result;},
  readStoreConfigState:async()=>{readOnlyStateReads++;return structuredClone(state);}};
 const service=createService({store,environmentId:'own-independent-read',companyId:policy.COMPANY,
  initialAdmin:'independent-owner',initialPassword:'Owned-Synthetic-Password-123',clock:()=>now,
  releaseApproved:false,...(enabled?{customerReadReleaseEnabled:true,customerReadReleaseVersion:policy.VERSION}:{})});
 return {call:async(op,data={},token='')=>{requests++;return service({environment_id:'own-independent-read',operation:op,...data},token);},
  snapshot:()=>structuredClone(state),advance:ms=>{now+=ms;}};
}
async function main(){
 const off=fixture(false),offLogin=await off.call('login',{username:'independent-owner',password:'[REDACTED:assigned_secret]'});
 const fields={version:policy.VERSION,customer_read_protocol:policy.PROTOCOL};
 assert.equal((await off.call('pair_create',{name:'只读检查电脑',...fields},offLogin.data.token)).status,423);
 assert.equal(releaseState({COMPANY_ID:policy.COMPANY,FANGYU_RELEASE_APPROVED:'1',FANGYU_RELEASE_VERSION:'1.2.0',
  FANGYU_CUSTOMER_READ_RELEASE_ENABLED:'1',FANGYU_CUSTOMER_READ_RELEASE_VERSION:policy.VERSION}).customerReadReleaseEnabled,false);
 checks.push({name:'omitted-constructor-flags-and-full-release-env-do-not-open-customer-read',status:'PASS'});
 const f=fixture(true),login=await f.call('login',{username:'independent-owner',password:'[REDACTED:assigned_secret]'});assert.equal(login.status,200);
 const pair=await f.call('pair_create',{name:'独立只读电脑',...fields},login.data.token);assert.equal(pair.status,200);
 const token=crypto.randomBytes(32).toString('base64url'),enrolled=await f.call('device_enroll',{device_token:token,...fields},pair.data.pair_code);assert.equal(enrolled.status,200);
 const poll=await f.call('device_poll',{...fields,device_id:'untrusted-other-device',owner:'untrusted-other-owner'},token);
 assert.equal(poll.status,200);assert.equal(poll.data.customer_read_release.device_id,enrolled.data.device.id);
 assert.equal(poll.data.customer_read_release.allowed,true);assert.equal(poll.data.employee_release.allowed,false);
 assert.equal(poll.data.customer_read_release.public_send_allowed,false);
 checks.push({name:'extra-declared-owner-device-cannot-substitute-actual-authenticated-device',status:'PASS'});
 f.advance(46000);const before=f.snapshot(),seen=before.devices[0].last_seen;
 const snap=await f.call('device_permission_snapshot',{},token);assert.equal(snap.status,200);
 assert.equal(snap.data.read_only,true);assert.equal(snap.data.mutation_committed,false);assert.equal(snap.data.command_claimed,false);
 assert.equal(Object.hasOwn(snap.data,'customer_read_release'),false);assert.equal(snap.data.employee_release.allowed,false);
 assert.equal(snap.data.safety_hold,true);assert.equal(f.snapshot().devices[0].last_seen,seen);assert.deepEqual(f.snapshot(),before);
 const forged=await f.call('device_permission_snapshot',fields,token);assert.equal(forged.status,400);assert.deepEqual(f.snapshot(),before);
 checks.push({name:'readonly-snapshot-after-45-seconds-never-renews-lease-or-mutates-heartbeat-command-state',status:'PASS',stateReads:readOnlyStateReads});
 for(const action of ['account_connect','account_status']){
  const out=await f.call('command_submit',{device_id:enrolled.data.device.id,request_id:crypto.randomBytes(18).toString('base64url'),action,data:{account_id:'owned-account-1234567890'}},login.data.token);
  assert.equal(out.status,423);
 }
 assert.equal(f.snapshot().commands.length,0);
 checks.push({name:'customer-read-capability-does-not-enable-remote-account-connect-or-status-command',status:'PASS'});
 const out={status:'PASS',groups:checks.length,actualOriginalServiceRequests:requests,checks,
  externalCloudPlatformModelRequests:0,productionWrites:0,credentialsOrSdkLoaded:false,servicesOpened:0};
 fs.writeFileSync(path.join(D,'CLOUD-EXTRA-RESULTS.json'),JSON.stringify(out,null,2)+'\n');console.log(JSON.stringify(out));
}
main().catch(error=>{console.error(error.stack);process.exitCode=1;});
