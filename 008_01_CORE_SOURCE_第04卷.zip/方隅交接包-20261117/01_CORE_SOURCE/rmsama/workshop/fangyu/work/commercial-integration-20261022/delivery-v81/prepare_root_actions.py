from pathlib import Path
C=Path(__file__).resolve().parent;W=C.parent
review=(W/'delivery-v80/review_next_entry.py').read_text('utf-8')
pairs=[
 ('f80-next-entry-candidate','f81-next-entry-candidate'),
 ('223c25f4ac07a55285b0be1da8818a200e2ef10f87eea157eb65f2b79a5f1463','889289caa69d39f2f4c2643f9eb343b4f2c9f10bd8d6ac0e8564d3e1084eae8b'),
 ('6a6245bbd3037b9ffc7541cd81372991262dc1cf58fcec24ceaa753ecf7f1552','df5a6f55096a537fd00c95c8dee8b1c6c22c825022a08227968727d0d1ac8a7f'),
 ('f4bca2468bbffff2c1929eca22b6a5dc11dd6140300590c40a5ca92f5f186eb8','5cbd743144e33de461b6be833063544a97916c5ae453c975397a4f5db1d8b57f'),
 ("delivery-v79/install_verified_entry.py","f80-next-entry-candidate/install_verified_entry.py"),
 ("{'check','prepare','main'}","{'check','main'}"),
 ('c02988a90de374b150ca240dc55b656d6ac9c1c27566a009c06b9b9f5d7d85a4','b507cc91fb378662a72a5e4b538fd855b0e65e8b404d1a3747760751a967e9cb'),
 ('8161593e7059809069c44578fb789c61cc12bd88e3515d7304a0914f5c48b534','4b44027f451b9efe7b727ed097564ce38c1d4957d60e0e6731570576820f2245'),
 ('candidate-unified-v80','candidate-unified-v81'),
 ("result['verifiedFiles']==3328","result['verifiedFiles']==3332"),
 ('PASS_F80_NEXT_ENTRY_INDEPENDENT_REVIEW','PASS_F81_NEXT_ENTRY_INDEPENDENT_REVIEW'),
 ('actualN79CasPinsVerified','actualN80CasPinsVerified'),
 ('originalMethodsIdenticalExceptThreeInspectedLocalPreparationFunctions','originalMethodsIdenticalExceptTwoInspectedLocalPreparationFunctions'),
 ('Exact F80 fixed source','Exact F81 fixed source'),
 ('Current N79 compare-and-swap pins','Current N80 compare-and-swap pins'),
 ('Extra full F79 rollback closure','Extra full F80 rollback closure'),
]
for before,after in pairs:
    assert before in review,before
    review=review.replace(before,after)
target=C/'review_next_entry.py';assert not target.exists();target.write_text(review,'utf-8')
source=(W/'delivery-v80/merge_canonical_source.py').read_text('utf-8')
source=source.replace('candidate-unified-v80','candidate-unified-v81').replace('candidate-unified-v79','candidate-unified-v80')
anchor="W/'expansion-f79-final-integration/COMPOSITION.json'";assert source.count(anchor)==1
source=source.replace(anchor,"W/'scanned-pdf-f80-integration/COMPOSITION.json'")
anchor="paths=sorted({r['path'] for x in composition['components'] for r in x['files']})";assert source.count(anchor)==1
source=source.replace(anchor,"paths=sorted(r['path'] for r in composition['files'])")
(C/'merge_canonical_source.py').write_text(source,'utf-8')
(C/'capture_business_readonly.py').write_bytes((W/'delivery-v80/capture_business_readonly.py').read_bytes())
print('Prepared source7 CAS/backups and independent next-entry review; runtime not written.')
