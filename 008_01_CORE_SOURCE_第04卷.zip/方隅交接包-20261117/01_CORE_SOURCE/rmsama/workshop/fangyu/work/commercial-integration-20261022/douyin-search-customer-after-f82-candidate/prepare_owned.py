from pathlib import Path
import ast,shutil
W=Path(__file__).resolve().parent;PRE=W.parent/'customer-read-purpose-after-f82-candidate'
t=(PRE/'prepare_probe.py').read_text('utf-8')
t=t.replace("SOURCE = W / 'source-candidate'", "SOURCE = W / 'source-candidate'\nPRE_SOURCE = W.parent / 'customer-read-purpose-after-f82-candidate/source-candidate'")
t=t.replace("for source in SOURCE.rglob('*.py'):\n    rel = source.relative_to(SOURCE); target = PROJECT/rel\n    target.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(source,target)","""for overlay in (PRE_SOURCE,SOURCE):
    for source in overlay.rglob('*.py'):
        rel = source.relative_to(overlay); target = PROJECT/rel
        target.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(source,target)
""")
t=t.replace("shutil.copy2(SOURCE/source, R/dest)","shutil.copy2(PROJECT/source, R/dest)")
needle="# SOURCE mirrors continue"
assert t.count(needle)==1
t=t.replace(needle,"""shutil.copy2(PROJECT/'work/shared-backend-integration/vendor-src/assistant/business.py',
    R/'resources/platform-runtime/vendor-src/assistant/business.py')

"""+needle)
needle="save(R/'resources/customer-read/review-index.json',index)"
assert t.count(needle)==1
t=t.replace(needle,"""purpose='douyin_owned_keyword_search_page'
limits={'first_page_only':True,'max_items':20,'offset':0,'search':True,'comments':False,
    'reply':False,'dm':False,'platform_identity_before_after':True,'real_platform_verified':False,
    'production_approval':False,'distribution_approval':False}
materials={}
for path in sorted(vendor.rglob('*.py')):add('vendor',path.relative_to(vendor).as_posix(),'source')
for name in ('core/douyin_comments_policy.py','core/douyin_search_policy.py','core/douyin_owned_search.py',
        'core/douyin_owned_comments.py','core/douyin_customer_tasks.py','core/platform_reads.py',
        'core/runtime_license_policy.py','core/adapters.py','core/engine.py','core/pipeline.py',
        'core/store.py','core/continuous.py','assistant/product_workspace.py','assistant/business.py','bridge.py'):
    add('source',name,'source')
for name in ('ui_native_host.py','resources/platform-runtime/platform_runtime.py',
        'resources/platform-runtime/customer_read_distribution.py'):add('release',name,'source')
for path in sorted(runtime.rglob('*')):
    if path.is_file():add('douyin_runtime',path.relative_to(runtime).as_posix(),
        'license' if path.name in ('LICENSE','NODE-LICENSE.txt') else 'dependency')
search_evidence={**evidence,'schema':'douyin_customer_search_license_source_evidence_v1',
    'purpose':purpose,'scope_limits':limits,
    'upstream_reference':'Yht20927/douyin-cli; retained original MIT notice and fixed local search.js',
    'task_consumer':'Original Business task_run -> original Core pipeline/import; bounded private typed read scope only',
    'unverified':['Native browser process and natural login','real platform data/read rate','second ordinary PC'],
    'engineering_runtime_verification':'Own original factory and actual CLI/Router/userscript VM evidence tracked outside release; no real platform claim.'}
save(R/'resources/customer-read/douyin-search-evidence.json',search_evidence)
add('release','resources/customer-read/douyin-search-evidence.json','review_evidence')
review={'schema':'fangyu_customer_read_purpose_review_v1','scope':'customer_distribution_read',
    'purpose':purpose,'company_binding':binding,'limits':limits,'materials':list(materials.values()),
    'distribution_basis':{'reviewer_ref':'Codex bounded original MIT/source and ordinary-task consumer review',
        'reviewed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'license':'MIT',
        'license_material':{'root':'douyin_runtime','path':'LICENSE'},'permission':'scoped_customer_read_only',
        'evidence_material':{'root':'release','path':'resources/customer-read/douyin-search-evidence.json'}},
    'evidence':{'review_layer':'license_and_source','real_platform_verified':False,
        'native_loaded_bytes_verified':False,'public_send_grant':False}}
path='resources/customer-read/'+purpose+'.json';save(R/path,review)
index['reviews'].append({'purpose':purpose,'path':path,'bytes':(R/path).stat().st_size,'sha256':sha(R/path)})
"""+needle)
ast.parse(t);(W/'prepare_probe.py').write_text(t,'utf-8')
for name in ('build_probe.py','prepare_entry.py','source_entry_check.py.in'):
    shutil.copy2(PRE/name,W/name)
print('Own preparation scripts reuse mature F82 builder and predecessor overlays')
