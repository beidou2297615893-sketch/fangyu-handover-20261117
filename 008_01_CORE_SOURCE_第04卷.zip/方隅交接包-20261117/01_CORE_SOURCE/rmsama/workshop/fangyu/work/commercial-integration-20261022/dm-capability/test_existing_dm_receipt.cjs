'use strict';
// No CLI startup, browser connection, real transport, credentials or DB.
const assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const P='C:/积木软件工坊/项目/方隅公寓客户版';
const source=path.join(P,'work/parallel-integration-20261018/final-integration/stage-02/project/work/ui-runtime-r55/work/runtime/douyin-bridge/lib/commands/dm.js');
const cmdDM=require(source);
global.fetch=async()=>{throw Error('real_network_forbidden')};
const cases=[
 ['explicit server message receipt',{status_code:0,body:{send_message_body:{status:0,server_message_id:'100000000000001',check_code:0}}},true],
 ['HTTP-shaped empty output',{},false],
 ['missing message id',{status_code:0,body:{send_message_body:{status:0}}},false],
 ['rejected platform status',{status_code:1,body:{send_message_body:{status:0,server_message_id:'1001'}}},false],
 ['rejected send status',{status_code:0,body:{send_message_body:{status:1,server_message_id:'1001'}}},false],
 ['platform check denial',{status_code:0,body:{send_message_body:{status:0,server_message_id:'1001',check_code:1}}},false],
 ['invalid zero message id',{status_code:0,body:{send_message_body:{status:0,server_message_id:'0'}}},false],
];
(async()=>{
 const results=[];
 for(const [name,receipt,success] of cases){
  const calls=[];
  const ctx={audit:{startOperation(){},endOperation(){}},loggedCall:async(kind,args,expression)=>{
   calls.push(kind);return kind==='dm.createConversation'?{conversation_id:'synthetic-conv',conversation_short_id:'1',ticket:'synthetic-ticket'}:receipt;
  }};
  let value,error;
  try{value=await cmdDM(ctx,['send','100000000000001','合成验证，不会对外发送']);}catch(e){error=e;}
  assert.equal(Boolean(value),success,name);
  assert.deepEqual(calls,['dm.createConversation','dm.send'],name+' no retry');
  if(success)assert.equal(value.message_id,'100000000000001');else assert.match(error.message,/禁止自动重试/);
  results.push({name,passed:true,bridge_calls_simulated:calls.length,real_send:false});
 }
 const report={status:'PASS',tests:results.length,results,source,source_sha256:crypto.createHash('sha256').update(fs.readFileSync(source)).digest('hex'),
  real_network_calls:0,real_platform_requests:0,real_sends:0,product_or_database_modified:false,platform_delivery_proven:false};
 fs.writeFileSync(path.join(__dirname,'DM-RECEIPT-TESTS.json'),JSON.stringify(report,null,2));
 console.log(JSON.stringify({status:report.status,tests:report.tests,real_sends:0,platform_delivery_proven:false}));
})().catch(e=>{console.error(e.message);process.exitCode=1;});
