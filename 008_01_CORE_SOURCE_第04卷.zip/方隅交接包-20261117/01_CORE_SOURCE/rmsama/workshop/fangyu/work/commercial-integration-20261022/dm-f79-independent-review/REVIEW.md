DM-F79 独立审查：保留红灯

实际补验 4 组、73 次 HTTP；默认 held、员工/门店隔离、原 key 防重、跨账号同稳定 UID 原占位、评论来源 CAS、监听与删除互斥均通过。原 Native 工厂真实关闭重开后，未知结果仍可按原 key 读取且零派发。

P2：账号删除后原私信结果无法查询。`dm_workbench.py:298` 在持久原请求/队列已通过 employee/store scope 后，仍要求原账号存在。真实原 `account_delete` 返回 deleted；随后的同 key `dm_request_read` 返回 403 DM_ACCOUNT_FORBIDDEN。原 DM/请求/队列/评论记录均未变；只发生一次合成 send，没有证据表明重复发送或跨账号防重失效。默认发布/回复 hold 未放开，因此不是当前运行版可自然触发的外发漏洞。

建议在明确持久删除审计及原 employee/store 授权仍有效时，为原请求提供只读退休投影；禁止借新账号查询、重发、换 key 或解除客户占位。执行分支和现有账号删除 CAS/租约保持原样。

范围：14 源逐 SHA、原 factory/read_public/缓存守卫最小差异已核。未重跑作者 24 factory/33 UI/21 VM，不将其计入独审。本次未新增 Chromium 测试；UI 仅静态审查转义、actor/generation、原 key 及历史声明。真实抖音线协议、自然设备授权、真实发送/历史与普通电脑实机仍未验。

证据捕获限制：最初捕获函数误列未用的 reply_customer_claims_v1。补充报告从只读 SQLite 的真实 ui_customer_reply_guard_v1 证明删除后 unknown 仍在；未捕获该 claim 精确前后字节，不宣称逐字未变。跨账号阻断由实际 HTTP 证明。

夹具修正：最初检查器错误要求 create_backend/verify_release 完全不变；后仅允许确切 pinned DM 模块装载及两处资源白名单。另修正公司配置中不存在 public_reply_hold 字段的检查；真实 public_send_hold=true 与 F79 原字节一致。未修改被审源码。

所有自有服务/工厂已关闭，生产/平台/模型动作 0。审查源与运行版未改。
