"""Real original factory/HTTP/guards/Adapters/Popen/NodeCLI, synthetic Bridge only."""
from pathlib import Path
from copy import deepcopy
from types import SimpleNamespace
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
import hashlib,http.client,importlib.util,json,os,re,shlex,sys,threading,time,uuid
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=W.parents[2];S=W.parent/'dm-f79-retirement-candidate/qa-only-project'
stage=json.loads((W/'INPUTS.json').read_text('utf-8'))['stage'];R=Path(stage['release'])
OUT=W/('factory-'+uuid.uuid4().hex);OUT.mkdir();events=[];wire=[];blocked=[];processes=[];checks=[];findings=[];reply_permission=[True]
save=lambda name,v:(OUT/name).write_text(json.dumps(v,ensure_ascii=False,indent=2,default=str),'utf-8')
def audit(event,args):
 if event=='subprocess.Popen':
  argv=args[1];argv=[v.strip('"') for v in shlex.split(argv,posix=False)] if isinstance(argv,str) else argv
  assert Path(argv[0]).resolve()==S/'work/ui-runtime-r55/work/runtime/douyin-bridge/node.exe',argv
  assert Path(argv[1]).resolve()==S/'work/ui-runtime-r55/work/runtime/douyin-bridge/dm_workbench_cli.js',argv
  assert Path(args[2]).resolve().is_relative_to(OUT),args;processes.append(list(argv))
 elif event in ('os.system','os.startfile','os.posix_spawn'):blocked.append(event);raise RuntimeError('Only fixed internal CLI process')
 if event in ('socket.connect','socket.bind') and (not isinstance(args[1],tuple) or args[1][0] not in ('127.0.0.1','::1')):blocked.append(event);raise RuntimeError('Loopback only')
 if event=='socket.getaddrinfo' and args[0] not in ('127.0.0.1','::1','localhost',None):raise RuntimeError('No external DNS')
 if event=='sqlite3.connect' and not Path(args[0]).resolve().is_relative_to(OUT):raise RuntimeError('Own DB only')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  path=Path(os.fsdecode(args[0])).absolute();mode,flags=args[1] or '',args[2] or 0
  if (any(c in str(mode) for c in 'wax+') or isinstance(flags,int) and flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC)) and not path.is_relative_to(OUT) and path!=W/'UI-SERVER.json':raise RuntimeError('Own evidence/data only')
sys.addaudithook(audit)
def load(name,path):
 m=importlib.util.module_from_spec(importlib.util.spec_from_loader(name,loader=None));m.__file__=str(path);sys.modules[name]=m;exec(compile(path.read_bytes(),str(path),'exec'),m.__dict__);return m
fixture=load('dm_original_identity_fixture',P/'work/acquisition-core-repair-20261018/gui-fixture/base_fixture.py');cloud=fixture.CloudStandin(json.loads((P/'work/central-store-config/compiled-fixture.json').read_text('utf-8-sig')));company=json.loads((S/'work/app/company.json').read_text('utf-8-sig'))
def transport(*a,**k):
 value=cloud(*a,**k);value['environment_id']=company['managedWorkspace']['environment_id'];value['user']['can_reply']=reply_permission[0];return value
integration=load('integrations',R/'resources/platform-runtime/vendor-src/integrations.py');integration.request_json=transport
host=load('dm_actual_native_host',R/'ui_native_host.py');_,files=host.verify_release(R,stage['manifest_sha256']);host.verify_backend_dependencies(R,files,S)
backend=host.create_backend(R,files,project_root=S,data_dir=OUT/'data',company=company);runtime=backend.platform_runtime;core=backend.core
runtime.server._configure_bundled();runtime._platform_setup=True
core.remote_safety_hold=False;core.employee_release_device_id='dm-synthetic-device';core.employee_release_until_monotonic=time.monotonic()+600
accounts={};send_state=['sent'];bridge_calls=[];slow_listen=[False];listen_corrupt=[False];late_revoke=[False];stop_received=threading.Event()
class Bridge(BaseHTTPRequestHandler):
 def log_message(self,*a):pass
 def do_POST(self):
  data=json.loads(self.rfile.read(int(self.headers['Content-Length'])));expr=data['expression'];bridge_calls.append({'connId':data.get('connId'),'expressionKind':'install' if expr.startswith('(function installReviewedDM') else expr.split('(...')[0]})
  if expr.startswith('(function installReviewedDM'):value='fangyu-dm-bounded-v1'
  else:
   operation=expr.split('(...')[0].rsplit('.',1)[1];args=json.loads(expr.split('(...',1)[1][:-1]);account=next(a for a in accounts.values() if a['conn_id']==data['connId']);assert args[0]==account['platform_uid'] if operation!='stop' else True
   mode=core.account_mode_status(account['id'],user['tenant_id']);assert mode['status']=='active' and mode['mode']==('replies' if operation=='send' else 'collection'),mode
   foreign=type(core.continuous.leases)(core.store,'foreign-dm-review')
   try:foreign.acquire(account['id'],user['tenant_id'],'publishing','foreign-publication')
   except ValueError:pass
   else:raise AssertionError('Original atomic mode lease bypassed')
   wire.append({'operation':operation,'args':args,'connection':data['connId'],'mode':mode,'foreignModeBlocked':True})
   if operation=='listen':
    if slow_listen[0]:stop_received.wait(3)
    uid,request,timeout=args;messages=[]
    for i in range(8):
     recipient=str(9007199254741001+i%4);messages.append({'message_id':str(9223372036854700001+i),'conversation_id':f'0:1:{uid}:{recipient}','sender_uid':recipient,'recipient_uid':uid,'text':'仅合成入站私信 '+str(i),'direction':'inbound','observed_at':'2026-10-23T04:40:00+00:00','platform_sent_at':None})
    value={'contract':'fangyu-dm-bounded-v1','state':'received','account_uid':uid,'request_id':request,'messages':messages,'history_available':False}
    if listen_corrupt[0]:value['state']='unknown'
    if late_revoke[0]:reply_permission[0]=False
   elif operation=='send':
    uid,recipient,text,request=args;value={'contract':'fangyu-dm-bounded-v1','state':send_state[0],'request_id':request,'account_uid':uid,'recipient_uid':recipient}
    if send_state[0]=='sent':value.update(message_id='9223372036854775807',conversation_id=f'0:1:{uid}:{recipient}',client_message_id=request)
   else:stop_received.set();value={'contract':'fangyu-dm-bounded-v1','state':'stopped','request_id':args[0]}
  raw=json.dumps({'ok':True,'value':value,'connection':data.get('connId')}).encode()
  try:
   self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
  except (BrokenPipeError,ConnectionResetError):pass
bridge=ThreadingHTTPServer(('127.0.0.1',0),Bridge);bt=threading.Thread(target=bridge.serve_forever,daemon=True);bt.start()
server=host.StaticServer(R,files,backend=backend,cookie_name='dm_fixture_session');st=threading.Thread(target=server.serve_forever,daemon=True);st.start();origin='http://127.0.0.1:'+str(server.server_port);headers={};passed=False
def request(method,path,payload=None):
 c=http.client.HTTPConnection('127.0.0.1',server.server_port,timeout=30);c.request(method,path,json.dumps(payload,ensure_ascii=False).encode() if payload else None,headers);r=c.getresponse();raw=r.read();status=r.status;found=dict(r.getheaders());c.close();value=json.loads(raw);log=deepcopy(payload)
 if log and log.get('action')=='login':log['data']['password']='synthetic omitted'
 events.append({'method':method,'path':path,'payload':log,'status':status,'body':value});save('HTTP.json',events);return status,value,found
def action(name,data,expected=200):
 code,body,h=request('POST','/api/workbench',{'action':name,'data':data});assert code==expected,(name,code,body);return body,h
serial=0
def dm(name,data,expected=200):return action(name,{'storeId':store,**data},expected)[0].get('dmWorkspace')
def mutate(name,data,expected=200,key=None):
 global serial
 serial+=1;return dm(name,{**data,'requestId':key or 'dm-fixture-operation-'+str(serial).zfill(6)},expected)
def read(account,**data):return dm('dm_workspace_read',{'accountId':account['id'],**data})
def wait_queue(ident):
 for _ in range(300):
  row=dm('dm_queue_read',{'id':ident})
  if row['state'] not in ('prepared','running'):return row
  time.sleep(.03)
 raise AssertionError('Queue did not settle')
def draft(account,conv,text):
 d=mutate('dm_draft_save',{'accountId':account['id'],'expectedVersion':0,'target':{'conversationId':conv['id']},'text':text})
 return mutate('dm_draft_review',{'accountId':account['id'],'id':d['id'],'expectedVersion':d['version'],'confirmed':True})
def prepare(account,ds):return mutate('dm_queue_prepare',{'accountId':account['id'],'drafts':[{'id':d['id'],'version':d['version']} for d in ds]})
def start(q,key=None):return mutate('dm_queue_start',{'id':q['id'],'snapshotDigest':q['snapshotDigest'],'confirmed':True},key=key)
try:
 _,boot,_=request('GET','/api/workbench/bootstrap');headers.update({'Content-Type':'application/json','Origin':origin,'X-Fangyu-CSRF':boot['csrfToken']});_,logged,h=request('POST','/api/workbench',{'action':'login','data':{'username':'fixture-admin','password':fixture.PASSWORD}});headers['Cookie']=h['Set-Cookie'].split(';',1)[0];headers['X-Fangyu-CSRF']=logged['csrfToken'];store=cloud.first_store
 if logged['selection']['storeId']!=store:action('select_store',{'storeId':store,'expectedRevision':logged['selection']['revision']})
 user={**core.session(headers['Cookie'].split('=',1)[1]),'_workbench_store_id':store}
 from assistant.business import BusinessExecutor
 from assistant.xhs_app_context import bind_executor_session
 executor=BusinessExecutor(runtime.server,company['managedWorkspace']['environment_id'],company['id'],user['username']);runtime.service.executor=executor
 saved={'state':'bound','environment_id':company['managedWorkspace']['environment_id'],'company_id':company['id'],'token':'synthetic-device-token','device':{'id':'dm-synthetic-device','owner':user['username']}}
 runtime.service.vault=SimpleNamespace(read=lambda:deepcopy(saved));runtime.service.device=deepcopy(saved['device']);runtime.service.state='online'
 class DeviceCloud:
  def call(self,operation,data,credential):return {'claimed':True}
  def close(self):pass
 runtime.service._cloud=lambda:DeviceCloud();executor.account_claim=runtime.service._claim_xhs_account;bind_executor_session(runtime.service,executor,saved)
 for i in range(2):
  a={'id':'dm-fixture-account-'+str(i),'tenant_id':user['tenant_id'],'cloud_owner':user['username'],'store_id':store,'platform':'douyin','status':'ready','name':'合成私信账号','platform_uid':str(9007199254740993+i),'conn_id':'dm-synthetic-connection-'+str(i)};accounts[a['id']]=a;core.store.put('accounts',a)
 account=list(accounts.values())[0];other=list(accounts.values())[1]
 config=core.store.directory/'bridge'/user['tenant_id']/'config.json';config.parent.mkdir(parents=True,exist_ok=True);config.write_text(json.dumps({'bridge':{'host':'127.0.0.1','port':bridge.server_port,'token':'synthetic-only'}}),'utf-8')

 def settle_listener(a):
  for _ in range(250):
   value=read(a)
   if value['listeners'] and value['listeners'][-1]['state']!='listening':return value
   time.sleep(.02)
  raise AssertionError('listener did not settle')
 def deletion(a,key):return {'storeId':store,'accountId':a['id'],'platform':a['platform'],'expectedNickname':a.get('platform_nickname') or a.get('name',''),'confirmed':True,'requestId':key}
 def capture():
  return {name:deepcopy(core.store.list(name,user['tenant_id'])) for name in ['ui_dm_conversations_v1','ui_dm_messages_v1','ui_dm_drafts_v1','ui_dm_queues_v1','ui_dm_requests_v1','leads','replies','ui_customer_reply_guard_v1']}
 assert read(account)['conversations']['total']==0 and not wire
 mutate('dm_listen_start',{'accountId':account['id'],'confirmed':True,'timeoutMs':100})
 convs=settle_listener(account)['conversations']['items'];assert len(convs)==4 and len(wire)==1
 d=draft(account,convs[0],'独审合成默认hold草稿');q=prepare(account,[d]);before=len(wire);start(q);held=wait_queue(q['id'])
 assert held['state']=='blocked' and len(wire)==before
 foreign={**account,'id':'review-foreign-owner','cloud_owner':'different-employee','platform_uid':'9007199254741777'};core.store.put('accounts',foreign)
 dm('dm_workspace_read',{'accountId':foreign['id']},403)
 wrong_store=next(s['id'] for s in cloud.manifest['stores'] if s['id']!=store)
 action('dm_workspace_read',{'accountId':account['id'],'storeId':wrong_store},403)
 reply_permission[0]=False;dm('dm_workspace_read',{'accountId':account['id']},403);reply_permission[0]=True
 detail=read(account,conversationId=convs[0]['id']);assert detail['capabilities']['historyAvailable'] is False and detail['messages']['total']==2 and len(wire)==before
 checks.append({'group':'G1_default_hold_scope_saved_history','result':'PASS','held':held,'wireDeltaSend':0,'ownerStorePermissionRejected':True,'savedHistoryOnly':True})
 save('PROGRESS.json',{'checks':checks,'findings':findings})

 # Only temporary configuration in our own factory is enabled for an original
 # device/executor lease and the loopback Bridge. Never changes sealed inputs.
 for config_value in (runtime.server.company,core.deployment_config):
  flags=config_value['runtime'];flags['public_send_hold']=False;flags['public_reply_hold']=False;flags['public_replies']='enabled';flags.pop('platform_qa_device_id',None)
 executor=BusinessExecutor(runtime.server,company['managedWorkspace']['environment_id'],company['id'],user['username']);runtime.service.executor=executor
 executor.account_claim=runtime.service._claim_xhs_account;bind_executor_session(runtime.service,executor,saved)
 manifest_path=core.store.directory/'adapters/douyin.json';manifest=json.loads(manifest_path.read_text('utf-8'));manifest['dm_contract_verified']=True;manifest_path.write_text(json.dumps(manifest),'utf-8')
 send_state[0]='unknown';d1=draft(account,convs[1],'独审未知回执原请求');d2=draft(account,convs[2],'独审后续不得发送');q=prepare(account,[d1,d2]);key='review-fixed-original-unknown-key';before=len(wire);start(q,key);unknown=wait_queue(q['id'])
 assert unknown['state']=='unknown' and unknown['items'][1]['state']=='pending' and len(wire)==before+1
 frozen_unknown=deepcopy(core.store.get('ui_dm_drafts_v1',d1['id']));frozen_queue=deepcopy(core.store.get('ui_dm_queues_v1',q['id']));wire_unknown=len(wire)
 assert start(q,key)['state']=='unknown';mutate('dm_queue_start',{'id':q['id'],'snapshotDigest':q['snapshotDigest'],'confirmed':True},409,key='review-new-key-cannot-retry')
 assert dm('dm_request_read',{'action':'dm_queue_start','requestId':key})['state']=='unknown'
 mutate('dm_listen_start',{'accountId':other['id'],'confirmed':True,'timeoutMs':100});other_convs=settle_listener(other)['conversations']['items']
 target=next(c for c in other_convs if c['recipientUid']==convs[1]['recipientUid']);od=draft(other,target,'独审跨账号同客户不得重发');oq=prepare(other,[od]);before=len(wire);start(oq);cross=wait_queue(oq['id'])
 assert cross['state']=='blocked' and len(wire)==before and core.store.get('ui_dm_drafts_v1',d1['id'])==frozen_unknown
 checks.append({'group':'G2_unknown_original_key_cross_account_claim','result':'PASS','originalKey':key,'oneSendOnly':sum(x['operation']=='send' for x in wire)==1,'secondItemPending':True,'originalUnknownUnchanged':True,'crossAccountQueue':cross})
 save('PROGRESS.json',{'checks':checks,'findings':findings})

 from assistant.customer_list import _person
 task={'id':'review-original-comment-task','tenant_id':user['tenant_id'],'cloud_owner':user['username'],'store_id':store,'platform':'douyin','account_id':other['id'],'status':'completed','cursor':{'page':7}}
 lead={'id':'review-original-comment','tenant_id':user['tenant_id'],'cloud_owner':user['username'],'store_id':store,'task_id':task['id'],'platform':'douyin','author_id':'9007199254741888','comment_id':'review-comment-stable-id','text':'原始合成评论','note_url':'https://www.douyin.com/video/1234567890123456789','created_at':'2026-10-23T04:40:00Z'}
 core.store.put('tasks',task);core.store.put('leads',lead)
 digest=lambda r:hashlib.sha256(json.dumps(r,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
 cd=mutate('dm_draft_save',{'accountId':other['id'],'expectedVersion':0,'target':{'customerId':_person(lead)[0],'leadId':lead['id'],'sourceDigest':digest(lead)},'text':'独审原评论私信草稿'})
 assert cd['source']['recipientUid']==lead['author_id']
 revised={**lead,'text':'合成原评论已修改'};core.store.put('leads',revised);before=len(wire)
 mutate('dm_draft_review',{'accountId':other['id'],'id':cd['id'],'expectedVersion':cd['version'],'confirmed':True},409)
 assert core.store.get('leads',lead['id'])==revised and core.store.get('tasks',task['id'])==task and len(wire)==before
 slow_listen[0]=True;stop_received.clear();before=len(wire);ls=mutate('dm_listen_start',{'accountId':other['id'],'confirmed':True,'timeoutMs':20000})
 for _ in range(250):
  if len(wire)>before:break
  time.sleep(.02)
 assert len(wire)>before
 old_account=deepcopy(core.store.get('accounts',other['id']));payload=deletion(other,'review-delete-active-listener')
 denied,_=action('account_delete',payload,409);assert denied['error']['code']=='ACCOUNT_BUSY' and core.store.get('accounts',other['id'])==old_account
 assert action('account_delete_request',{'storeId':store,'requestId':payload['requestId']})[0]['accountDeletion']['state']=='not_started'
 stopped=dm('dm_listen_stop',{'id':ls['id']});slow_listen[0]=False;assert stopped['state']=='stopped'
 assert core.store.get('leads',lead['id'])==revised and core.store.get('tasks',task['id'])==task and core.store.get('ui_dm_drafts_v1',d1['id'])==frozen_unknown
 checks.append({'group':'G3_comment_source_CAS_listener_delete_mutex','result':'PASS','originalCommentStableIdPreserved':True,'sourceChangeRejected':True,'activeListenerDeleteRejected':True,'explicitStop':stopped})
 save('PROGRESS.json',{'checks':checks,'findings':findings})

 # Close the actual first factory and start another through the same original
 # verified constructor. Old data, no copied author state, no __new__/sys.path.
 server.shutdown();st.join(3);server.server_close();backend.close()
 backend=host.create_backend(R,files,project_root=S,data_dir=OUT/'data',company=company);runtime=backend.platform_runtime;core=backend.core
 server=host.StaticServer(R,files,backend=backend,cookie_name='dm_fixture_session');st=threading.Thread(target=server.serve_forever,daemon=True);st.start();origin='http://127.0.0.1:'+str(server.server_port);headers={}
 _,boot,_=request('GET','/api/workbench/bootstrap');headers.update({'Content-Type':'application/json','Origin':origin,'X-Fangyu-CSRF':boot['csrfToken']})
 _,logged,h=request('POST','/api/workbench',{'action':'login','data':{'username':'fixture-admin','password':fixture.PASSWORD}});headers['Cookie']=h['Set-Cookie'].split(';',1)[0];headers['X-Fangyu-CSRF']=logged['csrfToken']
 if logged['selection']['storeId']!=store:action('select_store',{'storeId':store,'expectedRevision':logged['selection']['revision']})
 user={**core.session(headers['Cookie'].split('=',1)[1]),'_workbench_store_id':store}
 before=len(wire);recovered=dm('dm_request_read',{'action':'dm_queue_start','requestId':key});assert recovered['state']=='unknown' and len(wire)==before and core.store.get('ui_dm_drafts_v1',d1['id'])==frozen_unknown and core.store.get('ui_dm_queues_v1',q['id'])==frozen_queue
 checks.append({'group':'G4_actual_factory_reopen_unknown_then_account_delete','reopenOriginalKey':'PASS','reopenWireDelta':0})
 # Test original public account deletion, recording status rather than assuming
 # a lock policy. The account is synthetic; no platform deletion takes place.
 runtime.server._configure_bundled();runtime._platform_setup=True
 core.remote_safety_hold=False;core.employee_release_device_id='dm-synthetic-device';core.employee_release_until_monotonic=time.monotonic()+600
 for fixture_config in (runtime.server.company,core.deployment_config):
  flags=fixture_config['runtime'];flags['public_send_hold']=False;flags['public_reply_hold']=False;flags['public_replies']='enabled';flags.pop('platform_qa_device_id',None)
 executor=BusinessExecutor(runtime.server,company['managedWorkspace']['environment_id'],company['id'],user['username']);runtime.service.executor=executor
 runtime.service.vault=SimpleNamespace(read=lambda:deepcopy(saved));runtime.service.device=deepcopy(saved['device']);runtime.service.state='online';runtime.service._cloud=lambda:DeviceCloud()
 executor.account_claim=runtime.service._claim_xhs_account;bind_executor_session(runtime.service,executor,saved)
 before_rows=capture();before=len(wire);delete_payload=deletion(account,'review-delete-durable-unknown');code,body,_=request('POST','/api/workbench',{'action':'account_delete','data':delete_payload})
 assert len(wire)==before
 rc,rb,_=request('POST','/api/workbench',{'action':'dm_request_read','data':{'storeId':store,'action':'dm_queue_start','requestId':key}})
 after_rows=capture();assert before_rows==after_rows and core.store.get('ui_dm_drafts_v1',d1['id'])==frozen_unknown
 deletion_evidence={'deleteStatus':code,'deleteBody':body,'requestReadStatus':rc,'requestReadBody':rb,'originalRequestKey':key,'wireDelta':len(wire)-before,'allCapturedDmAndCustomerRowsUnchanged':before_rows==after_rows,'beforeRows':before_rows,'afterRows':after_rows}
 save('UNKNOWN-ACCOUNT-DELETE.json',deletion_evidence)

 assert code==200 and body['accountDeletion']['state']=='deleted' and rc==200 and rb['dmWorkspace']['state']=='unknown' and rb['dmWorkspace']['accountRemoved'] is True
 assert rb['dmWorkspace']['accountId']==account['id'] and rb['dmWorkspace']['requestId']==key and rb['dmWorkspace']['retiredAccount']['nickname']==account['name']
 checks[-1]['result']='PASS';checks[-1]['retiredLookup']=rb['dmWorkspace'];checks[-1]['originalClaimByteUnchanged']=True
 # Original source-level public DM interface receives the very same real
 # refreshed identity callback as HTTP. It must not gain a send path.
 cookie=headers['Cookie'].split('=',1)[1];payload={'storeId':store,'action':'dm_queue_start','requestId':key};before=len(wire);stable=capture()
 direct=backend.dm_workbench.execute('dm_request_read',user,store,payload,lambda:backend._delivery_identity(cookie))
 assert direct['state']=='unknown' and direct['accountRemoved'] is True and capture()==stable and len(wire)==before
 # A new account must still fail the original customer claim after retirement.
 another=prepare(other,[od]);start(another);again=wait_queue(another['id']);assert again['state']=='blocked' and '该客户正在发送或上次结果待核对' in again['message'] and len(wire)==before
 after_claim=deepcopy(core.store.list('ui_customer_reply_guard_v1',user['tenant_id']))
 assert after_claim==stable['ui_customer_reply_guard_v1']
 # Missing or forged retirement proof is not a fallback authorization.
 negatives=[];entity='workbench_account_deletion_v1';audit=next(x for x in core.store.list(entity,user['tenant_id']) if x['accountId']==account['id']);old_audit=deepcopy(audit)
 def denied(label):
  n=len(wire);code,body,_=request('POST','/api/workbench',{'action':'dm_request_read','data':payload});assert code==403 and len(wire)==n,(label,code,body);negatives.append({'case':label,'status':code,'body':body})
 try:
  core.store.put(entity,{**audit,'state':'unknown'});denied('deletion not confirmed');core.store.put(entity,old_audit)
  core.store.put(entity,{**audit,'inputDigest':'0'*64});denied('forged deleted input digest');core.store.put(entity,old_audit)
  core.store.put(entity,{**audit,'owner':'another-employee'});denied('foreign deletion owner');core.store.put(entity,old_audit)
  core.store.put(entity,{**audit,'storeId':wrong_store});denied('different deletion store');core.store.put(entity,old_audit)
  core_audits=[x for x in core.store.list('audit',user['tenant_id']) if x.get('action')=='account_delete' and x.get('detail',{}).get('id')==account['id']]
  assert core_audits
  for a in core_audits:core.store.put('audit',{**a,'action':'not-account-delete'})
  try:denied('no original Core deletion audit')
  finally:
   for a in core_audits:core.store.put('audit',a)
  original_queue=deepcopy(core.store.get('ui_dm_queues_v1',q['id']));core.store.put('ui_dm_queues_v1',{**original_queue,'owner':'another-employee'})
  try:denied('persistent queue owner changed')
  finally:core.store.put('ui_dm_queues_v1',original_queue)
  reply_permission[0]=False
  try:denied('current permission revoked')
  finally:reply_permission[0]=True
  action('dm_request_read',{**payload,'storeId':wrong_store},403)
  try:
   backend.dm_workbench.execute('dm_request_read',{**user,'username':'forged'},store,payload,lambda:backend._delivery_identity(cookie))
  except Exception as e:assert getattr(e,'status',None)==403;negatives.append({'case':'lower interface forged caller','status':403,'code':getattr(e,'code',None)})
  else:raise AssertionError('Lower retired query accepted another actor')
 finally:core.store.put(entity,old_audit)
 # The last revoked profile has been refreshed back before comparing rows.
 final_lookup=dm('dm_request_read',{'action':'dm_queue_start','requestId':key});assert final_lookup['state']=='unknown' and final_lookup['accountRemoved'] and len(wire)==before
 assert core.store.get('ui_dm_drafts_v1',d1['id'])==frozen_unknown and core.store.get('ui_dm_queues_v1',q['id'])==frozen_queue and core.store.list('ui_customer_reply_guard_v1',user['tenant_id'])==after_claim
 save('RETIREMENT-NEGATIVES.json',negatives)
 save('RETIREMENT-GREEN.json',{'originalRequestKey':key,'lookup':final_lookup,'unknownDraftByteUnchanged':True,'unknownQueueByteUnchanged':True,'claimByteUnchanged':True,'zeroRedispatchAfterUnknown':len(wire)==before,'lowerInterfaceSameContract':True,'crossAccountClaimStillBlocked':again,'negativeCases':negatives,'noSourceHoldsChanged':True})
 checks.append({'group':'G5_retirement_scope_proof_permission_claim','result':'PASS','negativeCases':len(negatives)+1,'retirementReadsZeroWire':True,'unknownRowsClaimByteUnchanged':True})
 if '--serve-ui' in sys.argv:
  stop=OUT/'STOP';save('UI-DATA.json',{'requestId':key,'accountId':account['id'],'storeId':store})
  (W/'UI-SERVER.json').write_text(json.dumps({'origin':origin,'directory':str(OUT),'stop':str(stop),'username':'fixture-admin','password':fixture.PASSWORD,'storeId':store,'retiredAccountId':account['id'],'requestId':key,'accounts':[other['id']]},ensure_ascii=False),'utf-8')
  print('UI_READY '+str(OUT),flush=True)
  until=time.monotonic()+300
  while not stop.exists() and time.monotonic()<until:time.sleep(.1)
  assert stop.exists(),'Own UI timeout'
  save('AFTER-UI.json',{'wire':wire,'exactlyOneSyntheticSend':sum(x['operation']=='send' for x in wire)==1,'unknownDraftByteUnchanged':core.store.get('ui_dm_drafts_v1',d1['id'])==frozen_unknown,'claimByteUnchanged':core.store.list('ui_customer_reply_guard_v1',user['tenant_id'])==after_claim})
 assert not blocked
 save('RESULTS.json',{'status':'RED_PRODUCT_GAP' if findings else 'PASS_REPRESENTATIVE','checks':checks,'findings':findings,'factory':'original verify_release + verify_backend_dependencies + read_public + create_backend','explicitQAOnly':True,'realPlatformModelCalls':0,'positiveSendDestination':'owned loopback Bridge only','defaultSourceHoldsUnchanged':True,'allWire':wire,'httpRequests':len(events)})
 passed=True
except BaseException:
 import traceback
 save('EXCEPTION.json',{'traceback':traceback.format_exc(),'checks':checks,'findings':findings,'wire':wire,'httpRequests':len(events)})
 raise
finally:
 try:server.shutdown();st.join(3);server.server_close()
 finally:
  try:backend.close()
  finally:bridge.shutdown();bt.join(3);bridge.server_close()
 save('FINAL.json',{'status':('RED_PRODUCT_GAP' if findings else 'PASS_REPRESENTATIVE') if passed else 'RED_FIXTURE_OR_PRODUCT_EXCEPTION','checks':checks,'findings':findings,'blocked':blocked,'wire':wire,'processes':processes,'allOwnServersClosed':not st.is_alive() and not bt.is_alive()})
 print(str(OUT),flush=True)
