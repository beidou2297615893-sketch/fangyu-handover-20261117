from pathlib import Path
from datetime import datetime,timezone
import ast,hashlib,json
W=Path(__file__).resolve().parent;P=W.parents[2];F=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v80';S=F/'project'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text('utf-8-sig'))
write=lambda n,v:(W/n).write_text(json.dumps(v,ensure_ascii=False,indent=2),'utf-8')
before=read(W/'PREPARE.json');stage=read(F/'STAGED.json');R=Path(stage['release'])
assert sha(F/'STAGED.json')==before['stageSha256']=='1bbce34364b8a8769131bebf1ea1a2edfe83b25a6861756bd72a95923bd895e1'
assert sha(F/'UNIFIED-PINS.json')==before['unifiedSha256']=='ad24e091a0a2be1fe1e30b9ea75fb20709e05d49e6b49f9b4a3b63298e62757f'
assert sha(R/'RELEASE.json')==before['manifestSha256']=='1cfeda2e8ca9f372b75bb1dc4e21d5792bc84aa63857b1cd4fc2e4f04d93e120'
assert sha(W.parent/'expansion-f79-final-integration/FROZEN-INPUTS.json')==before['frozenInputsSha256']=='d4c5bdcd4463d995bf4db213aad7965f89379fe09571d83ef5ac91507ad9f504'
pins=read(F/'UNIFIED-PINS.json')['files'];resources=read(R/'RELEASE.json')['files'];assert len(pins)==3328 and len(resources)==282
assert {p.relative_to(S).as_posix() for p in S.rglob('*') if p.is_file()}=={r['path'] for r in pins}
for row in pins:assert sha(S/row['path'])==row['sha256'],row['path']
assert {p.relative_to(R).as_posix() for p in R.rglob('*') if p.is_file()}=={r['path'] for r in resources}|{'RELEASE.json'}
for row in resources:assert sha(R/row['path'])==row['sha256'].lower() and (R/row['path']).stat().st_size==row['size'],row['path']
for row in before['copiedTests']:
 assert sha(Path(row['original']))==row['originalSha256'] and sha(W/row['adapted'])==row['adaptedSha256']
 original=Path(row['original']).read_text('utf-8');copied=(W/row['adapted']).read_text('utf-8')
 if row['adapted']=='test_retirement_factory.py':
  old="S=W/'qa-only-project'\nstage=json.loads((W/'INPUTS.json').read_text('utf-8'))['stage']"
  new="S=Path(json.loads((W/'QA-INPUTS.json').read_text('utf-8'))['project'])\nstage=json.loads((W/'QA-INPUTS.json').read_text('utf-8'))['stage']"
  assert original.replace(old,new,1)==copied
 else:assert original==copied
dirs={};summaries={}
for case in ('safety','reopen','contention','recover-claim'):
 found=list(W.glob('factory-'+case+'-*'));assert len(found)==1;d=found[0];dirs['schedule-'+case]=d
 result=read(d/'RESULTS.json');final=read(d/'FINAL.json')
 assert result['status']==final['status']=='PASS' and final['allOwnServersClosed'] and not final['blocked']
 assert result['stage']['manifest_sha256'].lower()==before['manifestSha256'] and result['stage']['release']==stage['release']
 summaries[case]={'status':'PASS','checks':result['checks'],'httpRequests':final['httpRequests'],'syntheticClicks':result['syntheticClicks']}
dm_info=read(W/'DM-UI-SERVER.json');dm=Path(dm_info['directory']);dirs['dm']=dm
df=read(dm/'RESULTS.json');dd=read(dm/'FINAL.json');du=read(dm/'UI-RESULTS.json');da=read(dm/'AFTER-UI.json')
assert df['status']==dd['status']=='PASS_REPRESENTATIVE' and len(df['checks'])==5 and not df['findings'] and not dd['blocked'] and dd['allOwnServersClosed']
assert du['status']=='PASS' and len(du['checks'])==15 and not du['errors'] and len(du['metrics'])==2
assert da['exactlyOneSyntheticSend'] and da['unknownDraftByteUnchanged'] and da['claimByteUnchanged']
for row in df['checks']:assert row['result']=='PASS'
ui_info=read(W/'UI-SERVER.json');ui=Path(ui_info['directory']);dirs['schedule-ui']=ui
su=read(ui/'UI-RESULTS.json');sf=read(ui/'FINAL.json')
assert su['status']=='PASS' and len(su['results'])==13 and not su['errors'] and len(su['layout'])==2
assert sf['status']=='STOPPED_OWN_HTTP_FIXTURE' and sf['modelEvents']==[] and not sf['nativeWindow'] and not sf['productionAccess']
assert all(row['effectiveMinFont']>=14.4 for row in su['layout'])
assert all(row['inner']['effectivePx']>=14 for row in du['metrics'])
evidence=[]
def pin(p):return {'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size}
for directory in dirs.values():
 for p in directory.rglob('*'):
  if p.is_file() and p.suffix.lower() in ('.json','.png'):
   evidence.append(pin(p))
write('EVIDENCE.json',{'status':'FIXED_OWN_SYNTHETIC_EVIDENCE','files':evidence})
write('CLOSURE-RESULTS.json',{'status':'PASS','project':str(S),'release':stage['release_id'],'sourceFiles':3328,'resources':282,'exactFileSetBeforeAndAfter':True,'allSourceAndResourceSha256BeforeAndAfter':True,'originalAssertionsUnchanged':True,'adaptations':'DM only original project/stage input assignments; all others exact decoded script contents; no author project/state copied','scheduleCases':summaries,'dmGroups':5,'dmFactoryHttpRequests':df['httpRequests'],'dmUiChecks':15,'scheduleUiChecks':13,'dmUnknownClaimAndDraftUnchangedAfterUi':True,'scheduleUiNoModelEvents':True,'scheduleMinimumEffectivePx':min(r['effectiveMinFont'] for r in su['layout']),'dmMinimumEffectivePx':min(r['inner']['effectivePx'] for r in du['metrics']),'allOwnServicesClosed':True,'productionAccess':False,'mediaAuthorTestsNotCountedAsThisIndependentReview':True})
(W/'REVIEW.md').write_text('F80冻结合版G11/私信代表回归通过，未安装、未改源。真实固定3328源码和282资源的完整文件集合及逐SHA在执行前后均一致；所有测试直接读F80冻结源，无作者project/state复制。G11原factory脚本和13项UI断言原样；DM仅两行project/stage输入适配，5组工厂/15项UI原断言全部保留。\n\nG11代表4组：safety保原unknown intent/key并禁止换key重派；reopen保持久计划与原编号、撤回RAM授权和切店授权；contention原账号模式互斥与未知发布阻回复；recover-claim保原prepared intent/key、旧worker迟到不能覆盖新审批。50/100压力矩阵未重跑。\n\nDM实际原verify/read_public/依赖/create_backend/Core/Store/HTTP+受控NodeCLI+自有loopback Bridge五组绿：默认hold/当前owner店权限；unknown原key单次传输及跨账号原customer claim；原评论来源CAS/监听删除互斥/显式停止；原factory真实关闭重开及账号删除后原请求查询；退休proof与当前权限负例。完整index/fit/iframe真实headless Chromium双宽1255/390共15项绿，原unknown只读卡无发送入口，重复查原编号零重派，另一账号不继承原请求。\n\nG11完整index/fit双宽13项绿：打开不建计划、固定本人稿件版本/账号/时间、确认后才arm、默认原publication hold准确显示、暂停和换账号不移植草稿或启动，字号/横向溢出均保原阈值。所有自有服务均关闭。\n\n边界：G11正向使用明确自有OwnedPublishPort及合成grant/session，DM正向仅自有临时fixture设备/适配器许可和loopback Bridge；封源及正式hold未变，不能当真实平台发布/私信已通。XHS DM传输/平台历史分页仍无已验证正式能力；无Native窗口/生产profile/真实平台/模型/付费。未验证普通编译包/第二电脑/真实账号；未重跑旧全量或媒体作者矩阵，不把媒体自测记作本次独审。\n','utf-8')
support=['PREPARE.json','QA-INPUTS.json','DM-UI-SERVER.json','UI-SERVER.json','CLOSURE-RESULTS.json','EVIDENCE.json','REVIEW.md','prepare_validation.py','seal_review.py','test_factory_schedule.py','serve_schedule_ui.py','test_schedule_ui.mjs','test_retirement_factory.py','test_retirement_ui.mjs']
write('FINAL-RECEIPT.json',{'status':'PASS_F80_FROZEN_SCHEDULE_DM_REPRESENTATIVE_INTEGRATION_NOT_REAL_PLATFORM_ACCEPTANCE','createdUtc':datetime.now(timezone.utc).isoformat(),'frozenInputsSha256':before['frozenInputsSha256'],'stageSha256':before['stageSha256'],'unifiedPinsSha256':before['unifiedSha256'],'releaseManifestSha256':before['manifestSha256'],'sourceFiles':3328,'resourceFiles':282,'sourceAndReleaseBeforeAfterExact':True,'g11FactoryRepresentativeCases':4,'g11FactoryCases':['safety','reopen','contention','recover-claim'],'g11FullIndexUiChecks':13,'dmFactoryGroups':5,'dmFactoryHttpRequests':df['httpRequests'],'dmFullIndexUiChecks':15,'uiWidths':[1255,390],'scopeAndAtomicLeaseOriginalKeyClaimAssertionsPreserved':True,'allOwnServicesClosed':True,'realPlatformModelPaidCalls':0,'nativeWindowOrProductionProfileStarted':False,'productionAccess':False,'canonicalFrozenOrInstalledWritten':False,'mediaAuthorTestsCountedAsIndependent':False,'schedulePositiveSyntheticPortGrant':True,'dmPositiveLoopbackBridgeAndTemporaryOwnFixtureGrant':True,'commercialGoalComplete':False,'notValidated':['Real platform publication or DM; XHS transport/history still unavailable','Final ordinary compiled package/second physical computer','50/100 stress and old unrelated full matrices','Native GUI and production scope'], 'evidence':[pin(W/n) for n in support]})
write('SEALED.json',{'status':'SEALED_STOP_WRITING','finalReceiptSha256':sha(W/'FINAL-RECEIPT.json'),'evidenceIndexSha256':sha(W/'EVIDENCE.json'),'closureSha256':sha(W/'CLOSURE-RESULTS.json'),'stageSha256':before['stageSha256'],'unifiedPinsSha256':before['unifiedSha256']})
print(json.dumps({'final':sha(W/'FINAL-RECEIPT.json'),'sealed':sha(W/'SEALED.json'),'closure':sha(W/'CLOSURE-RESULTS.json'),'evidence':sha(W/'EVIDENCE.json'),'g11FactoryCases':4,'g11Ui':13,'dmFactoryGroups':5,'dmUi':15,'dmHttp':df['httpRequests']}))
