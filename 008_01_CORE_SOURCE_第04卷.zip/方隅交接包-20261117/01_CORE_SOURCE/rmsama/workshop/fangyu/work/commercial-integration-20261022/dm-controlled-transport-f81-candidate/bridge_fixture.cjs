'use strict';
// QA ONLY: real Router/Registry/Client and whole userscript; synthetic page,
// identity response, IM protobuf response, signing and WebSocket transport.
const fs=require('fs'),path=require('path'),http=require('http'),vm=require('vm'),crypto=require('crypto');
const ROOT=path.join(__dirname,'qa-only-project/work/ui-runtime-r55/work/runtime/douyin-bridge');
const {Router}=require(path.join(ROOT,'lib/server/router')),{ConnectionRegistry}=require(path.join(ROOT,'lib/server/registry')),{WebSocketHub}=require(path.join(ROOT,'lib/server/ws-hub'));
const SELF='9007199254740993',MID='9223372036854775807',TOKEN='owned-synthetic-dm-token-000000000';
function request(port,url,data,token=TOKEN){return new Promise((resolve,reject)=>{const raw=data===undefined?null:JSON.stringify(data);const req=http.request({host:'127.0.0.1',port,path:url,method:raw?'POST':'GET',headers:{Authorization:'Bearer '+token,...(raw?{'Content-Type':'application/json','Content-Length':Buffer.byteLength(raw)}:{})}},res=>{let text='';res.on('data',c=>text+=c);res.on('end',()=>{try{resolve({status:res.statusCode,value:JSON.parse(text)})}catch(e){reject(e)}});});req.on('error',reject);if(raw)req.write(raw);req.end();});}
const varint=v=>{let n=BigInt(v),r=[];do{let b=Number(n&127n);n>>=7n;r.push(b|(n?128:0));}while(n);return Buffer.from(r);};
const vint=(n,v)=>Buffer.concat([varint(n*8),varint(v)]),blob=(n,b)=>{b=Buffer.from(b);return Buffer.concat([varint(n*8+2),varint(b.length),b]);},str=(n,v)=>blob(n,Buffer.from(v));
const createResponse=(self,peer)=>blob(6,blob(609,blob(1,Buffer.concat([str(1,`0:1:${self}:${peer}`),vint(2,'9007199254741015'),vint(3,1),str(4,'synthetic-ticket'),vint(7,2),vint(8,1)]))));
const sendResponse=(requestId,unknown,messageId=MID)=>blob(6,blob(100,Buffer.concat([vint(1,messageId),vint(3,0),str(4,unknown?'wrong-receipt-original-key':requestId),vint(5,0)])));
const push=(self,i)=>{const peer=String(9007199254741001n+BigInt(i%4));return Buffer.concat([str(7,'pb'),blob(8,blob(6,blob(500,blob(5,Buffer.concat([str(1,`0:1:${self}:${peer}`),vint(2,1),vint(3,String(9223372036854700001n+BigInt(i))),vint(4,'9007199254741007'),vint(6,7),vint(7,peer),str(8,JSON.stringify({text:'仅合成入站私信 '+i}))])))))]);};
async function startFixture({admissionPort=null,output=null}={}){
 const registry=new ConnectionRegistry(),hub=new WebSocketHub({registry}),router=new Router({registry,wsHub:hub,strictConnections:true,allowedSite:'douyin.com',token:TOKEN});
 const browsers=[],wire=[],commands=[],httpPaths=[],sentIds=new Map();let port;
 const server=http.createServer(async(req,res)=>{try{
  httpPaths.push(req.url.split('?')[0]);
  if(req.url.startsWith('/fixture/')){
   if(req.headers.authorization!=='Bearer '+TOKEN){res.writeHead(403);return res.end('{}');}
   let raw='';for await(const c of req)raw+=c;const body=raw?JSON.parse(raw):{};
   let result;
   if(req.url==='/fixture/create')result=await createBrowser(body.uid,body.options||{});
   else if(req.url==='/fixture/log')result={wire,commands,httpPaths,browsers:browsers.map(b=>({uid:b.uid,connId:b.connId,staticEvals:b.staticEvals,sockets:b.sockets.map(s=>({closed:s.closed})),options:b.options}))};
   else if(req.url==='/fixture/options'){Object.assign(browsers.find(b=>b.uid===body.uid).options,body.options);result={ok:true};}
   else if(req.url==='/fixture/shutdown'){result={ok:true};setTimeout(()=>close(),20);}
   else throw Error('Unknown owned fixture route');
   res.writeHead(200,{'Content-Type':'application/json'});return res.end(JSON.stringify(result));
  }
  return await router.handle(req,res);
 }catch(e){res.writeHead(500,{'Content-Type':'application/json'});res.end(JSON.stringify({error:String(e)}));}});
 await new Promise(r=>server.listen(0,'127.0.0.1',r));port=server.address().port;
 async function createBrowser(uid=SELF,options={}){
  const browser={uid,options,sockets:[],timers:new Set(),requests:new Set(),staticEvals:0,current:null,closed:false};browsers.push(browser);
  const later=(fn,ms)=>{const t=setTimeout(()=>{browser.timers.delete(t);if(!browser.closed)fn();},ms);browser.timers.add(t);return t;};
  class WS{constructor(url){if(!url.startsWith('wss://frontier-im.douyin.com/ws/v2?'))throw Error('No other page socket');this.closed=false;browser.sockets.push(this);later(()=>this.onopen?.(),1);for(let i=0;i<8;i++)later(()=>{if(!this.closed){const b=push(uid,i);this.onmessage?.({data:b.buffer.slice(b.byteOffset,b.byteOffset+b.length)});}},10+i);}close(){this.closed=true;this.onclose?.();}}
  const context={console:{log(){},warn(){}},TextEncoder,TextDecoder,Uint8Array,ArrayBuffer,URLSearchParams,URL,BigInt,JSON,Map,Set,Date,Promise,setTimeout:later,clearTimeout,WebSocket:WS,screen:{width:1255,height:1100},navigator:{userAgent:'OWNED-SYNTHETIC-DM',language:'zh-CN',platform:'Win32'},location:{href:'https://www.douyin.com/',hostname:'www.douyin.com',protocol:'https:'},document:{title:'Owned synthetic page',cookie:''},history:{pushState(){},replaceState(){}},addEventListener(){},atob:v=>Buffer.from(v,'base64').toString('binary'),btoa:v=>Buffer.from(v,'binary').toString('base64'),crypto:{getRandomValues:a=>crypto.webcrypto.getRandomValues(a),subtle:{importKey:async()=>({synthetic:true}),sign:async()=>Uint8Array.of(1,2,3).buffer}},localStorage:{getItem:key=>key==='web_protect'?JSON.stringify({ticket:'synthetic',ts_sign:'synthetic',client_cert:'synthetic'}):key==='s_sdk_crypt_sdk'?JSON.stringify({ec_privateKey:'01'}):key==='d_device_id'?'9007199254740997':null}};
  context.fetch=async(url,init)=>{
   const command=browser.current;if(!command)throw Error('No typed command admitted');wire.push({uid,operation:command.operation,url,method:init?.method||'GET'});
   if(url.startsWith('/aweme/'))return {ok:true,text:async()=>`{"status_code":0,"user_uid":${browser.options.wrongUid||uid},"id":${browser.options.wrongUid||uid}}`};
   let bytes;if(url==='https://imapi.douyin.com/v2/conversation/create')bytes=createResponse(uid,command.recipient);else if(url==='https://imapi.douyin.com/v1/message/send'){if(browser.options.delaySendMs)await new Promise(r=>setTimeout(r,browser.options.delaySendMs));if(!sentIds.has(command.requestId))sentIds.set(command.requestId,String(BigInt(MID)-BigInt(sentIds.size)));bytes=sendResponse(command.requestId,browser.options.unknown,sentIds.get(command.requestId));}else throw Error('Unknown network URL blocked');
   return {ok:true,arrayBuffer:async()=>bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.length)};
  };
  context.window=context;context.unsafeWindow=context;vm.createContext(context);
  context.eval=source=>{browser.staticEvals++;if(browser.staticEvals>2)throw Error('DM attempted generic eval');return vm.runInContext(source,context);};
  context.GM_xmlhttpRequest=options=>{
   const u=new URL(options.url);if(u.hostname!=='127.0.0.1'||Number(u.port)!==port)throw Error('Fixture permits only its Bridge');
   let data=options.data;
   if(u.pathname==='/api/dm/result'&&browser.options.corrupt){const body=JSON.parse(data);if(body.value?.state==='received')body.value.state='unknown';data=JSON.stringify(body);}
   const req=http.request({host:'127.0.0.1',port,path:u.pathname+u.search,method:options.method||'GET',headers:options.headers},res=>{let text='';res.on('data',c=>text+=c);res.on('end',async()=>{
    try{
     const msg=JSON.parse(text);
     if(msg.type==='fangyu-dm'){
      browser.current=msg.command;commands.push({...msg.command,id:msg.id});
      if(admissionPort){const ack=await request(admissionPort,'/admit',msg.command);if(ack.status!==200)throw Error('Original Core mode check failed');Object.assign(browser.options,ack.value);}
     }
     options.onload?.({status:res.statusCode,responseText:text});
    }catch(e){options.onerror?.(e);}
   });});
   browser.requests.add(req);req.on('close',()=>browser.requests.delete(req));req.on('error',e=>{if(!browser.closed)options.onerror?.(e);});if(data)req.write(data);req.end();
  };
  let text=fs.readFileSync(path.join(ROOT,'scripts/douyin.user.js'),'utf8');
  text=text.replace("server: 'http://127.0.0.1:19432'","server: 'http://127.0.0.1:"+port+"'").replace("token: '',","token: '"+TOKEN+"',");
  // Only the two documented local config literals differ in this fixture.
  vm.runInContext(text,context,{filename:'ACTUAL-fixed-douyin.user.js'});
  for(let i=0;i<100;i++){const c=registry.getAll('douyin.com').find(c=>!browsers.some(b=>b!==browser&&b.connId===c.id));if(c){browser.connId=c.id;return {uid,connId:c.id};}await new Promise(r=>setTimeout(r,10));}
  throw Error('Actual userscript did not register');
 }
 async function close(){for(const b of browsers){b.closed=true;for(const t of b.timers)clearTimeout(t);for(const req of b.requests)req.destroy();for(const s of b.sockets)s.close();}for(const p of router._pending.values()){clearTimeout(p.timer);p.reject?.();}for(const ws of router._pollWaiters.values())for(const w of ws){clearTimeout(w.timer);w.res.end('{}');}server.closeAllConnections();await new Promise(r=>server.close(r));if(output)fs.writeFileSync(path.join(output,'BRIDGE-FINAL.json'),JSON.stringify({wire,commands,httpPaths,realPlatformNetwork:0},null,2));}
 return {port,registry,router,createBrowser,close,wire,commands,httpPaths,browsers};
}
module.exports={startFixture,request,TOKEN};
if(require.main===module){startFixture({admissionPort:Number(process.argv[2])||null,output:process.argv[3]||null}).then(f=>{fs.writeFileSync(path.join(process.argv[3],'BRIDGE-READY.json'),JSON.stringify({port:f.port,token:TOKEN}));}).catch(e=>{console.error(e);process.exitCode=1;});}
