from pathlib import Path
import ast,datetime,hashlib,json,runpy,sys,io,contextlib
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=W.parents[2];A=W.parent/'dm-controlled-transport-f81-candidate';F=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v81';S=F/'project';Q=W/'qa-only-project'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,v):(W/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n','utf-8')
author_pins={'FINAL-RECEIPT.json':'efb21b4ce81c4fd76e00584327fb42122d1880f56adb09ad028688925de4bad3','SEALED.json':'0c6bf5886b1aaa4cce52d48db94f55a26f33834ec709e2e93d8fbcc8912e7c28','SOURCE-FILES.json':'9050d3818b4d557e843d47d1ad4dc84afcc512dfe484a8c8b521069a60c8765f','SOURCE.patch':'349cc3a402056a739d53be7ec0f3879668d1bd21aef649bee9cda5e5592015c4'}
for p,h in author_pins.items():assert sha(A/p)==h,(p,'changed')
assert sha(F/'UNIFIED-PINS.json')=='306fde02917f0f52bd0788069c56a802fbeb1a6ae428209533ea056c6e7a368c'
pins=json.loads((F/'UNIFIED-PINS.json').read_text('utf-8'))['files'];assert len(pins)==3332
assert {p.relative_to(S).as_posix() for p in S.rglob('*') if p.is_file()}=={r['path'] for r in pins}
for r in pins:
 src=S/r['path'];assert sha(src)==r['sha256'] and src.stat().st_size==r['bytes'];assert src.suffix not in ('.sqlite','.sqlite3','.db','.pyc')
 dest=Q/r['path'];dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(src.read_bytes())
rows=json.loads((A/'SOURCE-FILES.json').read_text('utf-8'))['files'];assert len(rows)==10
assert {p.relative_to(A/'source-candidate').as_posix() for p in (A/'source-candidate').rglob('*') if p.is_file()}=={r['path'] for r in rows}
for r in rows:
 p=r['path'];src=A/'source-candidate'/p;assert sha(src)==r['after']['sha256'] and src.stat().st_size==r['after']['bytes']
 if r['before']:assert sha(S/p)==r['before']['sha256'] and (S/p).stat().st_size==r['before']['bytes']
 else:assert not (S/p).exists()
 dest=Q/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(src.read_bytes())
changed={r['path'] for r in rows};untouched=[]
for r in pins:
 if r['path'] not in changed:assert sha(Q/r['path'])==r['sha256'];untouched.append(r['path'])
assert len(untouched)==3323
protected=['work/ui-native-r57/dm_workbench.py','work/ui-native-r57/ui_native_host.py','work/ui-native-r57/reply_delivery.py','work/ui-native-r57/workbench_backend.py','work/shared-backend-integration/platform_runtime.py','work/ui-runtime-r55/src/core/engine.py','work/ui-runtime-r55/src/core/continuous.py','work/ui-approved-implementation/ui-preview/app.mjs','work/ui-approved-implementation/ui-preview/pages/reply-dm.mjs','work/ui-approved-implementation/ui-preview/pages/diversified-acquisition.mjs','work/ui-runtime-r55/src/core/adapters.py','work/ui-runtime-r55/src/resources/adapters/douyin.json','work/app/company.json']
assert all(p in untouched for p in protected)
old=json.loads((S/'work/shared-backend-integration/vendor-src/douyin-connection-review.json').read_text('utf-8'));new=json.loads((Q/'work/shared-backend-integration/vendor-src/douyin-connection-review.json').read_text('utf-8'))
assert {k:v for k,v in old.items() if k!='materials'}=={k:v for k,v in new.items() if k!='materials'}
assert new['material_limits']['public_send_grant'] is False
service='work/shared-backend-integration/vendor-src/assistant/douyin_connection_service.py'
defs=lambda p:[(n.name,ast.dump(n,include_attributes=False)) for n in ast.parse(p.read_bytes()).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))]
assert defs(S/service)==defs(Q/service)
b='work/ui-runtime-r55/work/runtime/douyin-bridge/'
uold=(S/(b+'scripts/douyin.user.js')).read_text('utf-8');unew=(Q/(b+'scripts/douyin.user.js')).read_text('utf-8')
start='var DM_BRIDGE_CODE = (function () {/*';end='*/}).toString()';codec=uold[uold.index(start)+len(start):uold.index(end,uold.index(start))];assert codec in unew
start='  var BRIDGE_CODE = (function () {/*';assert uold[uold.index(start):]==unew[unew.index(start):]
browser=(S/(b+'lib/dm_workbench_browser.js')).read_text('utf-8');fn=browser[browser.index('function installReviewedDM'):].rstrip().removesuffix(';');assert fn in unew
for pattern in ['pywebview-*.dist-info/licenses/LICENSE','pythonnet-*.dist-info/licenses/LICENSE','clr_loader-*.dist-info/licenses/LICENSE','bottle-*.dist-info/licenses/LICENSE']:
 site=P/'work/desktop-python/Lib/site-packages';src,=site.glob(pattern);dest=Q/'work/desktop-python/Lib/site-packages'/src.relative_to(site);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(src.read_bytes())
for name in ('test_factory_dm.py','test_typed_bridge.cjs','bridge_fixture.cjs','test_connection_integrity.py'):(W/name).write_bytes((A/name).read_bytes())
save('SOURCE-REVIEW.json',{'status':'PASS','authorPinned':author_pins,'baselineFiles':3332,'onlyOverlaySourceFiles':10,'untouchedF81Files':3323,'allProtectedBytesSame':[{ 'path':p,'sha256':sha(Q/p)} for p in protected],'oldUiAllBytesUnchanged':True,'connectionServiceAllClassFunctionAstUnchanged':True,'reviewNonMaterialFieldsExactUnchanged':True,'publicSendGrantFalse':True,'legacyDmCodecAndBridgeSuffixUnchanged':True,'fixedBrowserFunctionEmbeddedExactly':True,'existingDmBusinessOwnershipStoreCasUnknownStableUidClaimsUnchanged':True,'rootLiveDmRepinStillRequired':json.loads((A/'MERGED-REPIN-REQUIREMENTS.json').read_text('utf-8')),'noRealCredentialsCopied':True})
ns=runpy.run_path(str(Q/'work/ui-native-r57/freeze_ui.py'),run_name='dm_independent_original_freezer');ns['main'].__globals__['VENV']=P/'work/desktop-python';sys.argv=[str(Q/'work/ui-native-r57/freeze_ui.py'),'--stage'];output=io.StringIO()
with contextlib.redirect_stdout(output):assert ns['main']()==0
stage=json.loads(output.getvalue());save('QA-STAGE-PINS.json',{'status':'OWN_QA_ONLY','stage':stage});print(json.dumps({'status':'OWN_QA_READY','resources':stage['files'],'sourceFiles':3332,'overlay':10,'release':stage['release_id']},ensure_ascii=True))
