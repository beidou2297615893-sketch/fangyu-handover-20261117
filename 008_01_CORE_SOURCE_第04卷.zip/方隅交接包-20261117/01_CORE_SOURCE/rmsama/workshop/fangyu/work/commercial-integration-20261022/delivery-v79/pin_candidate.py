from pathlib import Path
import hashlib,json
D=Path(__file__).resolve().parent;P=D.parents[2];C=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v79'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
u=json.loads((C/'UNIFIED-PINS.json').read_text('utf-8'));s=json.loads((C/'STAGED.json').read_text('utf-8'));R=Path(s['release'])
print(json.dumps(s,ensure_ascii=False)[:300])
pins={'rootExplicitFinalPins':True,'candidate':C.name,'unifiedPinsSha256':sha(C/'UNIFIED-PINS.json'),'stagedSha256':sha(C/'STAGED.json'),'manifestSha256':s['manifest_sha256'],'releaseId':s['release_id'],'unifiedFileCount':len(u['files']),'releaseFileCount':274,'launcherSha256':sha(C/('project/work/ui-native-r57/run_candidate.'+s['release_id']+'.py'))}
assert not (D/'FINAL-PINS.json').exists();(D/'FINAL-PINS.json').write_text(json.dumps(pins,ensure_ascii=False,indent=2),'utf-8');print('FINAL-PINS SHA '+sha(D/'FINAL-PINS.json'))
