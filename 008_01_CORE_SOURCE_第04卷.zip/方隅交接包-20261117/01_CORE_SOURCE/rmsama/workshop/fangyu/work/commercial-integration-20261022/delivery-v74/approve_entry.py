from pathlib import Path
import hashlib,json,ast
D=Path(__file__).resolve().parent;W=D.parent
sha=lambda raw:hashlib.sha256(raw).hexdigest()
review=W/'v74-canonical-entry-independent-review/FINAL-RECEIPT.json'
assert sha(review.read_bytes())=='9a8a23ba0cdf9014a33a15b5f761d6bdc965552b927df2ecb1a2a24532cb2e59'
p=D/'install_verified_entry.py';before=p.read_bytes()
assert sha(before)=='9472a64139c505dd4a94dde49961db5f0df7a58ffbdcea726362f91c288ce9ad'
needle=b'INSTALLATION_REVIEWED = False';assert before.count(needle)==1
after=before.replace(needle,b'INSTALLATION_REVIEWED = True')
old=ast.parse(before);new=ast.parse(after)
for tree in (old,new):
    for n in tree.body:
        if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='INSTALLATION_REVIEWED':n.value=ast.Constant(value=False)
assert ast.dump(old)==ast.dump(new),'Only installation-reviewed flag may change'
(D/'ENTRY-BEFORE-ROOT-APPROVAL.py').write_bytes(before)
p.write_bytes(after)
out={'status':'ROOT_APPROVED_EXACT_REVIEWED_ENTRY','beforeSha256':sha(before),'afterSha256':sha(after),'independentReceiptSHA256':sha(review.read_bytes()),'onlyReviewedBooleanChanged':True,'canonicalWritten':False}
(D/'ROOT-ENTRY-APPROVAL.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps(out))
