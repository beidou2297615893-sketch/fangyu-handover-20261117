from pathlib import Path
import hashlib, json
C=Path(__file__).resolve().parent;W=C.parent
A=W/'media-f79-pathguard-candidate'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(A/'FINAL-RECEIPT.json')=='86ad9c1882b8c8b74b743d4b6df70e9588b40171dbcdaf159a66b7a8b3552698'
assert sha(A/'SEALED.json')=='dcf7d52576cb039318b2b28e71adf8184b4a8d4280cb77c7edf4cfda000de029'
frozen=json.loads((W/'expansion-f79-final-integration/FROZEN-INPUTS.json').read_text('utf-8'))
S=Path(frozen['project']);stage_path=Path(frozen['stagePath'])
assert sha(stage_path)==frozen['stageSha256']
assert sha(S.parent/'UNIFIED-PINS.json')==frozen['unifiedPinsSha256']
stage=json.loads(stage_path.read_text('utf-8'))
for name in ('QA-STAGE.json','QA-STAGED.json'):
    (C/name).write_text(json.dumps(stage,ensure_ascii=False,indent=2),'utf-8')
adaptations=[]
for name in ('test_factory_boundaries.py','test_path_guards.py'):
    text=(A/name).read_text('utf-8');anchor="S=W/'project'"
    assert text.count(anchor)==1
    text=text.replace(anchor,'S=Path('+repr(str(S))+')')
    (C/name).write_text(text,'utf-8')
    adaptations.append({'test':name,'authorSha256':sha(A/name),'adaptation':'Source project and own output/stage paths only'})
Q=W/'query-attribution-f79-retirement-candidate'
text=(Q/'test_retirement_factory.py').read_text('utf-8');anchor="S = C / 'project'"
assert text.count(anchor)==1
text=text.replace(anchor,'S = Path('+repr(str(S))+')')
(C/'test_query_retirement.py').write_text(text,'utf-8')
adaptations.append({'test':'test_query_retirement.py','authorSha256':sha(Q/'test_retirement_factory.py'),'adaptation':'Source project and own output/stage paths only'})
(C/'INPUTS.json').write_text(json.dumps({'status':'ACTIVATED_ONLY_FOR_ACTUAL_F80_PRIVATE_VALIDATION',
    'frozen':frozen,'adaptations':adaptations,'productionAccess':False,'platformOrModelCalls':0},ensure_ascii=False,indent=2),'utf-8')
print(json.dumps({'status':'PREPARED_FIXED_F80_FACTORY_TESTS','manifest':frozen['manifestSha256'],'tests':len(adaptations)}))
