"""Fix the root-reviewed v72 allowlist into the already behavior-tested entry installer."""
from pathlib import Path
import ast,hashlib,json
D=Path(__file__).resolve().parent;W=D.parent
source=W/'delivery-next-launch/review-4/install_next_launch.v71.REVIEWED.py'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(source)=='8011abeb96bddf0536cec69c94d2f9744f53473b8fed2fdf0dac37c7397887ab'
raw=source.read_text('utf-8');tree=ast.parse(raw)
pins=json.loads((D/'FINAL-PINS.json').read_text('utf-8'));summary=json.loads((D/'frozen-native/SUMMARY.json').read_text('utf-8'))
assert sha(D/'frozen-native/SUMMARY.json')=='ef8cd7512fb31215b96f3aa383a435ca03d01be550e45b47415a4a55bb84aec3'
assert summary['totalHttpGroups']==70 and not summary['realModelCalls'] and not summary['productionAccess']
evidence={'frozen-native/'+name:sha(D/'frozen-native'/name) for name in (*summary['evidenceSha256'],'SUMMARY.json')}
spec={'release_id':pins['releaseId'],'unified_sha':pins['unifiedPinsSha256'],'files':pins['unifiedFileCount'],
    'release_sha':pins['manifestSha256'],'candidate_launcher_sha':pins['launcherSha256'],
    'recovery_checkpoint':True,'evidence':evidence,'delivery':'delivery-v72','http_groups':70,'staged_sha':pins['stagedSha256']}
lines=raw.splitlines(keepends=True)
changes=[]
for n in tree.body:
    if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='ACCEPTED' for t in n.targets):
        changes.append((n.lineno-1,n.end_lineno,'ACCEPTED = '+repr({pins['candidate']:spec})+'\n'))
    if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='INSTALLATION_REVIEWED' for t in n.targets):
        changes.append((n.lineno-1,n.end_lineno,'INSTALLATION_REVIEWED = True  # Root reviewed exact v72 pins and the original 17-case CAS acceptance.\n'))
assert len(changes)==2
for start,end,value in sorted(changes,reverse=True):lines[start:end]=[value]
text=''.join(lines)
old="expected = P / 'work/commercial-integration-20261022/delivery-next-launch/review-4'"
new="expected = P / 'work/commercial-integration-20261022/delivery-v72'"
assert text.count(old)==1;text=text.replace(old,new)
compile(text,'install_verified_entry.py','exec')
# Every installer function remains byte-for-byte identical except the explicit
# location assertion inside main; the existing CAS/backup/rollback is unchanged.
original_functions={n.name:ast.dump(n,include_attributes=False) for n in tree.body if isinstance(n,ast.FunctionDef)}
new_functions={n.name:ast.dump(n,include_attributes=False) for n in ast.parse(text).body if isinstance(n,ast.FunctionDef)}
assert all(original_functions[k]==new_functions[k] for k in original_functions if k!='main')
dest=D/'install_verified_entry.py';assert not dest.exists();dest.write_text(text,'utf-8',newline='\n')
report={'status':'ROOT_REVIEWED_EXACT_V72_INSTALLER_PREPARED','sourceScriptSha256':sha(source),'scriptSha256':sha(dest),'candidate':pins['candidate'],'fixedEvidenceCount':len(evidence),'allInstallerFunctionsExceptMainLocationUnchanged':True,'canonicalInstallPerformed':False,'approvalBasis':'Existing user authorization to finish integration, install the reviewed update and validate the actual desktop; no repeated approval required.','remainingScope':'This is an integration recovery checkpoint with new platform features closed or unverified; not a full commercial completion claim.'}
(D/'INSTALLER-REVIEW.json').write_text(json.dumps(report,indent=2)+'\n','utf-8')
print(json.dumps(report))
