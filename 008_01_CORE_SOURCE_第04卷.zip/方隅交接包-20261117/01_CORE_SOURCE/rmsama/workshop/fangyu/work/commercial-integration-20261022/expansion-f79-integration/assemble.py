from pathlib import Path
import argparse,hashlib,json,subprocess
C=Path(__file__).resolve().parent;W=C.parent;P=C.parents[2];F=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v79';S=C/'project';sha=lambda b:hashlib.sha256(b).hexdigest()
components={
 'dm':{'directory':'dm-f79-candidate','final':'3eec74a0b654856fa4342ecc78f0328264b3ec38aea92ffa8304a455e4a8a612','seal':'629459cd38891f60a752678059b270e747f5f7c53430e71412c30017fb29950e','manifest':'SOURCE-PINS.json','manifestSha':'3150c508129df1d69d7386f2ba5974ffe0483f3278f15f732a3cd2974ccdbbde','folder':'final-source'},
 'schedule':{'directory':'content-schedule-f79-candidate','final':'9673ffa9e1fa480565551c40a0371c18c100f4badd4b199af4424178883b8703','seal':'2b2c197680634b1b1e857f8a55adb7d23d2ab1c411991ecf2d9ed3710c428707','manifest':'SOURCE-FILES.json','manifestSha':'4ad932340fab3e39f77cde18ff05849486a3e84ce3e68564c49c8092d3604812','folder':'overlay'},
 'media':{'directory':'media-f79-candidate','final':'5ac9faa51d7132557f62aabe9e93d11f10b806a3204c0d060dd67f44a74bbdc4','seal':'0cbae483b2daa2d623c782ec4166af1c7418be007ca1bfb22915565dccf2e46b','manifest':'SOURCE-FILES.json','manifestSha':'62418cd5c18f70b38d51c9bb7085bda95394bfc42b6b0986b6446623b48ee0f1','folder':'source-candidate'},
 'query':{'directory':'query-attribution-f79-retirement-candidate','final':'aef3bec1f929356be297f125a0caae4012d3444fc4759af78e395ae546170d69','seal':'3c0bfe2af3743ef0f692348e5626a746a88181962063942a28e77e4f0e7fdeb0','manifest':'SOURCE-FILES.json','manifestSha':'83c7e97762310ea0f66e4cc2b14ece3571f9d0a2bba2535352a2f46cd293791d','folder':'source-candidate'},
}
args=argparse.ArgumentParser();args.add_argument('component',choices=['init',*components]);option=args.parse_args();history=C/'COMPOSITION.json'
pins=json.loads((F/'UNIFIED-PINS.json').read_text('utf-8'))['files'];assert sha((F/'UNIFIED-PINS.json').read_bytes())=='fa71e0e3cda87f55708ef00fcdfef348fb1ddeb91911d44950f599080644ad83'
if option.component=='init':
 assert not S.exists()
 for row in pins:
  raw=(F/'project'/row['path']).read_bytes();assert sha(raw)==row['sha256'];target=S/row['path'];target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
 history.write_text(json.dumps({'baselineCandidate':'candidate-unified-v79','baselineFilesVerified':len(pins),'components':[],'productionAccess':False,'canonicalWritten':False},indent=2),'utf-8');print('Initialized exact F79 independent composition');raise SystemExit
state=json.loads(history.read_text('utf-8'));assert option.component not in [r['component'] for r in state['components']]
config=components[option.component];source=W/config['directory']
for name,pin in [('FINAL-RECEIPT.json',config['final']),('SEALED.json',config['seal']),(config['manifest'],config['manifestSha'])]:assert sha((source/name).read_bytes())==pin,name
manifest=json.loads((source/config['manifest']).read_text('utf-8'));rows=manifest if isinstance(manifest,list) else manifest['files'];planned=[];conflicts=[]
for row in rows:
 relative=row['path'];path=Path(relative);assert not path.is_absolute() and '..' not in path.parts and ':' not in relative
 before=row.get('beforeSha256') or (row.get('before') or {}).get('sha256');after=row.get('afterSha256') or row.get('sha256') or (row.get('after') or {}).get('sha256');base=F/'project'/relative;target=S/relative;incoming=source/config['folder']/relative
 assert (sha(base.read_bytes()) if base.exists() else None)==before,relative;raw=incoming.read_bytes();assert sha(raw)==after,relative
 previous=sha(target.read_bytes()) if target.exists() else None;method='exact source apply'
 if previous not in (None,before,after):
  result=subprocess.run(['git','merge-file','-p',str(target),str(base),str(incoming)],capture_output=True)
  if result.returncode:
   output=C/'conflicts'/option.component/relative;output.parent.mkdir(parents=True,exist_ok=True);output.write_bytes(result.stdout);resolution=C/'resolutions'/option.component/relative
   if not resolution.is_file():conflicts.append(relative);continue
   raw=resolution.read_bytes();method='root inspected explicit resolution'
  else:raw=result.stdout;method='git three-way hunk merge'
 elif previous is None:assert before is None,relative
 planned.append({'path':relative,'beforeCompositionSha256':previous,'sourceAfterSha256':after,'afterCompositionSha256':sha(raw),'method':method,'raw':raw})
if conflicts:
 (C/('CONFLICTS-'+option.component+'.json')).write_text(json.dumps({'status':'REQUIRES_ROOT_HUNK_REVIEW_NO_SOURCE_WRITES','paths':conflicts},indent=2),'utf-8');print(json.dumps({'status':'CONFLICTS_NO_WRITES','paths':conflicts}));raise SystemExit(2)
for row in planned:
 target=S/row['path'];target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(row['raw'])
state['components'].append({'component':option.component,'sourceFinalSha256':config['final'],'files':[{k:v for k,v in row.items() if k!='raw'} for row in planned]});history.write_text(json.dumps(state,indent=2),'utf-8');print(json.dumps({'status':'COMPOSED_NOT_FROZEN_OR_INSTALLED','component':option.component,'files':len(planned)}))
