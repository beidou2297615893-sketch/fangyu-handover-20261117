from pathlib import Path
import hashlib,json,sys,urllib.request,datetime
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=W.parents[2]
F=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v81';S=F/'project';Q=W/'qa-only-project';O=W/'source-candidate'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(F/'UNIFIED-PINS.json')=='306fde02917f0f52bd0788069c56a802fbeb1a6ae428209533ea056c6e7a368c'
rows=json.loads((F/'UNIFIED-PINS.json').read_text('utf-8-sig'))['files'];assert len(rows)==3332
assert {p.relative_to(S).as_posix() for p in S.rglob('*') if p.is_file()}=={r['path'] for r in rows}
for row in rows:
 p=S/row['path'];assert sha(p)==row['sha256'] and p.stat().st_size==row['bytes'],row['path']
 rel=row['path']
 if rel.startswith(('work/ui-native-r57/releases/','work/ui-native-r57/candidates/','work/ui-native-r57/run_candidate.')):continue
 if 'state' in Path(rel).parts and not rel.endswith('state/production-workspace.json'):continue
 assert p.suffix.lower() not in ('.db','.sqlite','.sqlite3','.pyc'),rel
 d=Q/rel;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(p.read_bytes())
site=P/'work/desktop-python/Lib/site-packages'
for pattern in ['pywebview-*.dist-info/licenses/LICENSE','pythonnet-*.dist-info/licenses/LICENSE','clr_loader-*.dist-info/licenses/LICENSE','bottle-*.dist-info/licenses/LICENSE']:
 for p in site.glob(pattern):
  d=Q/'work/desktop-python/Lib/site-packages'/p.relative_to(site);d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(p.read_bytes())
info={'checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'route':'Agent Reach dev/GitHub gh; unauthenticated official API fallback','ghResult':'No authenticated gh; no login/token added','pinnedCommit':'4073159bea585de6d33a4747a475669440737932','sources':[]}
for url in ['https://api.github.com/repos/Yht20927/douyin-cli','https://api.github.com/repos/Yht20927/douyin-cli/commits/4073159bea585de6d33a4747a475669440737932']:
 try:
  req=urllib.request.Request(url,headers={'User-Agent':'Fangyu-local-source-audit','Accept':'application/vnd.github+json'})
  with urllib.request.urlopen(req,timeout=15) as r: v=json.load(r)
  info['sources'].append({'url':url,'status':'read','metadata':{k:v[k] for k in ['full_name','archived','pushed_at','updated_at','license','sha'] if k in v},'commit':v.get('commit',{}) if 'commits/' in url else None})
 except Exception as e:info['sources'].append({'url':url,'status':'unavailable','error':str(e)})
(W/'UPSTREAM-REFRESH.json').write_text(json.dumps(info,ensure_ascii=False,indent=2),'utf-8')
(W/'BASELINE.json').write_text(json.dumps({'baseline':str(S),'unifiedSha256':sha(F/'UNIFIED-PINS.json'),'sourceFiles':len(rows),'verifiedAllOriginalBytes':True,'scope':'Only owned source candidate and QA project; no original data copied'},ensure_ascii=False,indent=2),'utf-8')
print(json.dumps({'verified':len(rows),'github':[s['status'] for s in info['sources']]}))
