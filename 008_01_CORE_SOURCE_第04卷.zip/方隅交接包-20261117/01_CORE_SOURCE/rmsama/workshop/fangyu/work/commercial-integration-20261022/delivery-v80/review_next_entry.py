from pathlib import Path
from datetime import datetime,timezone
import ast,hashlib,json,subprocess,sys
D=Path(__file__).resolve().parent;W=D.parent;P=D.parents[2];E=W/'f80-next-entry-candidate';N=P/'work/ui-native-r57'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(E/'FINAL-RECEIPT.json')=='223c25f4ac07a55285b0be1da8818a200e2ef10f87eea157eb65f2b79a5f1463'
assert sha(E/'SEALED.json')=='6a6245bbd3037b9ffc7541cd81372991262dc1cf58fcec24ceaa753ecf7f1552'
entry=E/'install_verified_entry.py'
assert sha(entry)=='f4bca2468bbffff2c1929eca22b6a5dc11dd6140300590c40a5ca92f5f186eb8'
old=(W/'delivery-v79/install_verified_entry.py').read_bytes();new=entry.read_bytes()
def funcs(raw):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(raw).body if isinstance(n,ast.FunctionDef)}
a,b=funcs(old),funcs(new)
assert a.keys()==b.keys() and {name for name in a if a[name]!=b[name]}=={'check','prepare','main'}
assert a['install']==b['install']
expected={'run_workbench.py':'c02988a90de374b150ca240dc55b656d6ac9c1c27566a009c06b9b9f5d7d85a4',
          'FROZEN.json':'8161593e7059809069c44578fb789c61cc12bd88e3515d7304a0914f5c48b534',
          'state/production-workspace.json':'14cf53964f5d44d123e989805ea741669ab3f05054e730ddcb299a0aac51a9cb'}
assert all(sha(N/name)==pin for name,pin in expected.items())
process=subprocess.run([sys.executable,'-I','-B',str(entry),'--candidate','candidate-unified-v80','--check'],capture_output=True,encoding='utf-8',errors='replace',timeout=180)
assert process.returncode==0,(process.stdout,process.stderr)
result=json.loads(process.stdout);assert result['status']=='CHECK_ONLY' and result['writes']==0 and not result['restart'] and result['verifiedFiles']==3328
assert all(sha(N/name)==pin for name,pin in expected.items())
receipt={'status':'PASS_F80_NEXT_ENTRY_INDEPENDENT_REVIEW','createdUtc':datetime.now(timezone.utc).isoformat(),
    'approvedForNextLaunchOnly':True,'actualReadOnlyCheckPassed':True,'actualN79CasPinsVerified':True,
    'originalInstallTransactionAndCasBackupRollbackUnchanged':True,'reviewedEntrySha256':sha(entry),
    'reviewedAuthorReceiptSha256':sha(E/'FINAL-RECEIPT.json'),'reviewedAuthorSealSha256':sha(E/'SEALED.json'),
    'rootFinalPinsSha256':sha(D/'FINAL-PINS.json'),'rootAggregateValidationSha256':sha(D/'AGGREGATE-VALIDATION.json'),
    'actualCheck':result,'originalMethodsIdenticalExceptThreeInspectedLocalPreparationFunctions':True,
    'inspectedDifferences':['Exact F80 fixed source and local evidence allowlist','Current N79 compare-and-swap pins','Extra full F79 rollback closure','Own prepared validation/evidence paths'],
    'productionDataRead':False,'nativeWritten':False,'windowStoppedOrRestarted':False,
    'platformOrModelCalls':0,'ordinaryPackageOrHumanPlatformAcceptance':False,'fullGoalComplete':False}
target=D/'NEXT-ENTRY-ROOT-REVIEW.json';assert not target.exists();target.write_text(json.dumps(receipt,ensure_ascii=False,indent=2),'utf-8')
print(json.dumps({'status':receipt['status'],'rootReviewSha256':sha(target)}))
