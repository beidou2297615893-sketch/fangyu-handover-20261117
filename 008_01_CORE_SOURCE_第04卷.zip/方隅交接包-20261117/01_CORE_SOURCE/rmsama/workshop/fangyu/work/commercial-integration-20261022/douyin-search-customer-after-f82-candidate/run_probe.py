from pathlib import Path
import os,subprocess,sys
W=Path(__file__).resolve().parent;P=W.parents[2];B=W/sys.argv[1]
mode=sys.argv[2] if len(sys.argv)>2 else 'source'
suffix=('-'+sys.argv[3]) if len(sys.argv)>3 else ''
assert B.parent==W and mode in ('source','compiled')
env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONIOENCODING':'utf-8'}
for key,name in [('TEMP','qa-temp'),('TMP','qa-temp'),('APPDATA','qa-appdata'),('LOCALAPPDATA','qa-localappdata')]:
    path=B/name;path.mkdir(exist_ok=True);env[key]=str(path)
argv=([str(P/'work/desktop-python/Scripts/python.exe'),'-X','utf8','-B',str(B/('probe_entry'+suffix+'.py'))]
    if mode=='source' else [str(B/'dist/FangyuWorkbench/FangyuWorkbench.exe')])
with (B/('RUN-'+mode+suffix+'.log')).open('x',encoding='utf-8') as log:
    result=subprocess.run(argv,cwd=B,env=env,stdout=log,stderr=subprocess.STDOUT,
        creationflags=subprocess.CREATE_NO_WINDOW,timeout=1800)
print('Exit',result.returncode)
print((B/('RUN-'+mode+suffix+'.log')).read_text('utf-8')[-4500:])
