from pathlib import Path
import argparse,ast,hashlib,json
D=Path(__file__).resolve().parent;W=D.parent;Q=D/'frozen-native';sha=lambda b:hashlib.sha256(b).hexdigest()
p=argparse.ArgumentParser();p.add_argument('--source-final',required=True);p.add_argument('--source-seal',required=True);p.add_argument('--joint-final',required=True);p.add_argument('--joint-seal',required=True);args=p.parse_args()
assert not Q.exists();Q.mkdir()
root=json.loads((D/'FINAL-PINS.json').read_text('utf-8'));rootsha=sha((D/'FINAL-PINS.json').read_bytes());assert rootsha=='3719840ea39dfe4874fe800f48fe9b58a92987649bd524a39b8074816b6efd64'
checks={
 'source-independent.json':(W/'v79-final-source-independent-review/FINAL-RECEIPT.json',args.source_final),
 'source-SEAL.json':(W/'v79-final-source-independent-review/SEALED.json',args.source_seal),
 'joint-independent.json':(W/'v79-joint-factory-validation/FINAL-RECEIPT.json',args.joint_final),
 'joint-SEAL.json':(W/'v79-joint-factory-validation/SEAL.json',args.joint_seal),
 'account-independent.json':(W/'v79-account-backend-factory/FINAL-RECEIPT.json','e28128ccb817ec02dec8c6660e4bb76a6a401ead5333d48c158369c5cbaa5216'),
 'account-SEALED.json':(W/'v79-account-backend-factory/SEALED.json','fd2f56a0ec15fb1f2d729b9a119febe0379a13603dbc961195fb7c8d612e4761'),
}
evidence={}
def copy(name,source,pin=None):
 raw=source.read_bytes();digest=sha(raw)
 if pin:assert digest==pin,str(source)
 (Q/name).write_bytes(raw);evidence['frozen-native/'+name]=digest
for name,(source,pin) in checks.items():copy(name,source,pin)
source=json.loads((Q/'source-independent.json').read_text('utf-8'));assert source['status'].startswith('PASS') and source['pins']==root
joint=json.loads((W/'v79-joint-factory-validation/SUMMARY.json').read_text('utf-8'));assert joint['rootPins']==root and joint['counts']['originalBusinessGroupsTotal']==47 and joint['realModelPlatformExternalCalls']==0 and joint['allOwnServersClosed']
copy('joint-SUMMARY.json',W/'v79-joint-factory-validation/SUMMARY.json')
ui=json.loads((D/'ui-recovery-validation/RESULTS.json').read_text('utf-8'));assert ui['status']=='PASS' and ui['groups']==8 and ui['realPlatformOrModelCalls']==0 and ui['realAccountDeletion']==0
invariants=json.loads((D/'ui-recovery-validation/DELETE-INVARIANTS.json').read_text('utf-8'));assert invariants['status']=='PASS_EXPECTED_SYNTHETIC_ACCOUNT_DELETION_ONLY'
closed=json.loads((D/'ui-recovery-validation/UI-SERVER-CLOSED.json').read_text('utf-8'));assert closed['closed']
copy('account-full-ui.json',D/'ui-recovery-validation/RESULTS.json');copy('synthetic-delete-invariants.json',D/'ui-recovery-validation/DELETE-INVARIANTS.json');copy('ui-server-closed.json',D/'ui-recovery-validation/UI-SERVER-CLOSED.json')
baseline=json.loads((D/'PROTECTED-BUSINESS-BEFORE-INSTALL.json').read_text('utf-8'));assert baseline['readOnly'] and not baseline['productionModified']
summary={'status':'TECHNICAL_ACCEPTANCE_ACCOUNT_SWITCH_RECOVERY_NOT_FULL_COMMERCIAL','rootFinalPins':root,'totalHttpGroups':47,'countedOriginalBusinessGroups':joint['counts'],'separateAccountFactoryGroups':8,'separateAccountFactoryHttpRequests':30,'separateRootFullUiChecks':8,'httpRequestsAreNotCountedAsGroups':True,'oldBaselineReceiptsAreReferencesNotNewRuns':True,'testExecutionUsesOwnFixturesOnly':True,'testExecutionProductionAccess':False,'productionAccess':False,'productionReadOnlyBaseline':{'accountRecords':baseline['accountRecords'],'comments':baseline['protectedTablesAndEntities']['records:leads']['rows']},'realModelCalls':0,'realPlatformRequests':0,'realMessagesOrPostsSent':0,'realAccountDeletions':0,'nativeFirstStartVerified':False,'ordinaryPackageDefaultNativeOrSecondPhysicalPcVerified':False,'localNextLaunchUpdateApproved':True,'commercialDistributionApproved':False,'completeThreeInOneGoalAchieved':False,'continuedEngineeringRequired':True,'limits':['Full browser interaction uses original application factory and own synthetic accounts; external browser child failure is verified but real platform login has not been driven.','Natural cloud grants, CAPTCHA, real acquisition speed and platform return are not claimed verified.','Public compiled distribution remains previous release; this updates local next-launch entry only.','Private messaging/media/scheduled-publishing candidates are not included.','Old F78 full-UI red is retained; F79 corrects the keyword wrapper event interception.']}
(Q/'SUMMARY.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n','utf-8');evidence['frozen-native/SUMMARY.json']=sha((Q/'SUMMARY.json').read_bytes())
spec={'release_id':root['releaseId'],'unified_sha':root['unifiedPinsSha256'].lower(),'files':root['unifiedFileCount'],'release_sha':root['manifestSha256'].lower(),'candidate_launcher_sha':root['launcherSha256'].lower(),'recovery_checkpoint':True,'evidence':evidence,'delivery':'delivery-v79','http_groups':47,'staged_sha':root['stagedSha256'].lower()}
entry=D/'install_verified_entry.py';before=entry.read_bytes();assert sha(before)=='84f073179307a3c5207908c25bcc93fed96580c5c4f8619ea82ad7d2c805a32a';text=before.decode('utf-8');tree=ast.parse(text)
node=next(n for n in tree.body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='ACCEPTED');assert ast.literal_eval(node.value)=={}
lines=text.splitlines(keepends=True);lines[node.lineno-1:node.end_lineno]=['ACCEPTED = '+repr({'candidate-unified-v79':spec})+'\n'];text=''.join(lines)
functions=lambda t:{n.name:ast.dump(n,include_attributes=False) for n in t.body if isinstance(n,ast.FunctionDef)};assert functions(tree)==functions(ast.parse(text))
(D/'ENTRY-EMPTY-DRAFT.py').write_bytes(before);entry.write_text(text,'utf-8');out={'status':'FILLED_FIXED79_INSTALLATION_STILL_DISABLED','entrySha256':sha(entry.read_bytes()),'summarySha256':evidence['frozen-native/SUMMARY.json'],'evidence':evidence,'functionsUnchanged':True,'installationReviewed':False,'canonicalWritten':False,'commercialGoalComplete':False};(D/'ENTRY-FILLED.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),'utf-8');print(json.dumps({k:v for k,v in out.items() if k!='evidence'}))
