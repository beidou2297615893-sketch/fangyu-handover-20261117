from pathlib import Path
import datetime,hashlib,json,subprocess
C=Path(__file__).resolve().parent
def read(p):return json.loads(Path(p).read_text('utf-8-sig'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(name,v):(C/name).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n','utf-8')
assert not (C/'SEALED.json').exists()
gate=read(C/'INPUT-GATE.json');S=Path(gate['project']);F=S.parent;stage=read(F/'STAGED.json');R=Path(stage['release'])
assert sha(F/'STAGED.json')==gate['stageSha256'] and sha(F/'UNIFIED-PINS.json')==gate['unifiedSha256'] and sha(R/'RELEASE.json')==gate['releaseManifestSha256']
unified=read(F/'UNIFIED-PINS.json');release=read(R/'RELEASE.json')
for row in unified['files']:
 p=S/row['path'];assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256']
for row in release['files']:
 p=R/row['path'];assert p.stat().st_size==row['size'] and sha(p)==row['sha256'].lower()
assert len(unified['files'])==3856 and len(release['files'])==538
put('FINAL-CLOSURE.json',{'status':'PASS','sourceFilesReverifiedAfterTests':3856,'releaseResourceFilesReverifiedAfterTests':538,'projectReadOnly':str(S),'stageSha256':sha(F/'STAGED.json'),'unifiedSha256':sha(F/'UNIFIED-PINS.json'),'releaseManifestSha256':sha(R/'RELEASE.json'),'launcherExecuted':False,'sourceCacheTamperNegativeRunOnFormalResources':False})
dirs=['independent-factory-99c99783ef3147e0bb257e26c91901be','experience-factory-3204c1f5a2a245419f1247ad4c78f366','factory-25b1bd9812d84b50a8be574d50f42d20','factory-c91dbf8ece074f0ab3b86da3b2068743']
reports=[read(C/n/'RESULTS.json') for n in dirs];assert all(v['status']=='PASS' for v in reports)
assert all(v['stage']['manifest_sha256'].lower()==gate['releaseManifestSha256'] for v in reports)
http=[len(read(C/n/'HTTP.json')) for n in dirs];assert http==[120,98,76,7]
groups=[len(v.get('checks',v.get('groups',[]))) for v in reports];assert groups==[5,5,10,1]
ui='ui-http-68aa912ee262495e83203fdc2f66a087';u=read(C/ui/'UI-CONTENT-JOINT.json');assert u['status']=='PASS' and len(u['checks'])==37 and not u['errors']
closed=read(C/ui/'FINAL.json');assert closed['threadClosed'] and closed['realExternalSearchCalls']==0 and closed['realModelPlatformCalls']==0
assert len(closed['publicProviderReplays'])==1
concurrency=read(C/dirs[-1]/'CONCURRENT-HTTP.json');assert concurrency['providerResponseStillInFlight'] and concurrency['workspaceReadSeconds']<1
ps="@(Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^(python|pythonw|node|chrome-headless-shell|chrome)\\.exe$' -and $_.CommandLine -like '*expansion-f82-content-joint-validation*' -and $_.CommandLine -notlike '*seal.py*' } | Select-Object ProcessId,Name,CommandLine) | ConvertTo-Json -Depth 3 -Compress"
p=subprocess.run(['powershell','-NoProfile','-Command',ps],capture_output=True,text=True,check=True);live=json.loads(p.stdout.strip() or '[]');assert not live,live
put('CLEANUP.json',{'ownProcessMatches':live,'sessionsTerminal':{'21835':0,'77041':0,'80922':0,'8107':0,'87680':1,'30723':0,'27025':0},'redSessionReason':'first new UI harness omitted original experience details-open click; red and screenshot retained','originalUserWindowTouched':False,'selfOwnedServersClosed':True})
receipt={'schema':'F82-content-joint-factory-ui-validation-v1','status':'PASS_SCOPED_CONTENT_CHAIN','sealedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'inputs':gate,'finalClosureSha256':sha(C/'FINAL-CLOSURE.json'),
 'actualLayers':['original pinned ui_native_host.verify_release','original verify_backend_dependencies','original create_backend','Core/Store/Runtime with original synthetic employee fixture','original public provider and pinned DDGS parser with one previously captured HTML response','development headless Chromium original full index/fit/iframe/render/bind'],
 'factory':{'groups':sum(groups),'groupsByArea':dict(zip(['manual','experience','publicResearch','publicInFlightRead'],groups)),'httpLoggedWithBusinessResponses':sum(http),'httpByArea':dict(zip(['manual','experience','publicResearch','publicInFlightRead'],http)),'additionalRawPostIntentionallyClosedBeforeAck':1,'countNote':'301 is complete logged HTTP request/response records; one deliberately disconnected raw POST is separately counted, not treated as a test group','directories':dirs,'publicResponseReplaysByArea':{'publicFactory':reports[2]['providerResponseReplays'],'concurrency':1,'cleanUI':1},'additionalExternalPublicQueries':0,'originalHtmlPagesFetched':0},
 'ui':{'checks':37,'evidence':ui,'widths':[1255,390],'minimumEffectiveVisibleTextPx':min(v['element']['effectiveFont'] for v in u['metrics']),'screenshotFiles':u['screenshots'],'waitingScreenshot':'public-waiting.png','cleanScreenshotsNoXssProbe':True,'imagesActuallyViewed':['manual-summary-1255.png','experience-reference-390.png','public-research-390.png'],'zeroModuleRuntimeErrors':True},
 'specificConclusions':['Manual summary requires explicit checked person confirmation; no model call, no AI artifact/persona creation; old versions/CAS and original unknown key preserved','Experience candidate/adoption/withdrawal are explicit and versioned; original plans remain executed=false; only selected reference enters original task as hypothesis','No-guided-session pointer tab transitions work across five existing tabs at both widths without creating content or querying public sources','Public read uses exact pinned parser on original captured sample; imports only selected IDs/digests as hypothesis requiring explicit task reference; unknown and lost acknowledgement preserve original request key','Public preview does not hold global Native api_lock: original-key workspace read returned while provider response still in flight'],
 'publicConcurrentReadSeconds':concurrency['workspaceReadSeconds'],'publicConcurrentReceiptState':concurrency['originalReceiptState'],
 'preservedRedAndExpectedLogs':{'ui-http-215936128b6e412b8c1d174b1f0b42f1':'self-owned combined harness forgot original experience details-open click; no product change; new own run uses mature click then same assertions','public-factory.log':'ConnectionAbortedError10053 is expected from test_public_factory.py intentional raw c.close before HTTP acknowledgement; cached succeeded receipt and zero-redispatch assertion passed; no product error suppressed'},
 'limits':{'realModels':0,'realPlatformCalls':0,'newPublicSearches':0,'nativeWindowsOpened':0,'realUserDataAccess':False,'formalProjectResourcesTampered':False,'freezeOrInstall':False,'ordinaryComputerExecution':False,'livestream':'author live25 is separate candidate evidence; this content validation makes no new platform or Native live claim'},
 'cleanupSha256':sha(C/'CLEANUP.json')}
put('FINAL-RECEIPT.json',receipt)
text='F82内容联合验收通过。原工厂21组，301条完整HTTP记录，另1次主动断开回执的POST单列；完整index/fit宽窄UI37项。\n\n手动小结、经验引用及撤回、公共研究原parser回放、无访谈会话切页均已实跑；公共读取在原查询等待中约%.3f秒返回。所有公网搜索、原文抓取、真实模型和平台调用均为0。\n\n首次UI夹具未展开原折叠区的红保留，后继只修自有夹具；断HTTP回执负例的10053服务日志为预期。全部自有服务已关。F82源码3856/资源538在测试后逐文件摘要与大小复核不变，未启动原生窗口、安装或修改正式资源。\n'%concurrency['workspaceReadSeconds']
(C/'SUMMARY.md').write_text(text,'utf-8')
files=[]
for n in dirs+[ui,'ui-http-215936128b6e412b8c1d174b1f0b42f1']:
 for p in sorted((C/n).rglob('*')):
  if p.is_file():files.append({'path':p.relative_to(C).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)})
for p in sorted(C.iterdir()):
 if p.is_file() and p.name not in ('EVIDENCE-PINS.json','SEALED.json'):files.append({'path':p.name,'bytes':p.stat().st_size,'sha256':sha(p)})
put('EVIDENCE-PINS.json',{'schema':'F82-content-validation-evidence-v1','files':files,'fileCount':len(files),'onlyOwnSyntheticData':True})
put('SEALED.json',{'schema':'F82-content-validation-seal-v1','finalReceiptSha256':sha(C/'FINAL-RECEIPT.json'),'summarySha256':sha(C/'SUMMARY.md'),'evidencePinsSha256':sha(C/'EVIDENCE-PINS.json'),'stageSha256':gate['stageSha256'],'sourceUnmodified':True,'allOwnServicesClosed':True,'noFurtherWrites':True})
print(json.dumps({n:sha(C/n) for n in ['FINAL-RECEIPT.json','SUMMARY.md','SEALED.json']},ensure_ascii=False))
