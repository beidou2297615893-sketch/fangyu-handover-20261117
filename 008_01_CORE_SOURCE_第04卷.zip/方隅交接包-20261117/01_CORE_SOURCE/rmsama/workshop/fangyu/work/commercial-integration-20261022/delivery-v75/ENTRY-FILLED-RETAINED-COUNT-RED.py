"""Next-launch review draft. Default CHECK; no app/service/process actions.

Derived from delivery-v66's fixed allowlist and original CAS/backup installer.
No final version or hash is guessed. ACCEPTED is empty and installation is
code-disabled until root approves the final immutable release and evidence.
--prepare, once pinned, writes only within this work directory.
"""
from pathlib import Path, PurePosixPath
import argparse
import hashlib
import importlib.util
import json
import re
import stat
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
P = Path('C:/积木软件工坊/项目/方隅公寓客户版')
F = P / 'work/parallel-integration-20261018/final-integration'
N = P / 'work/ui-native-r57'
GENERIC = P / 'work/parallel-integration-20261018/integration/entry/install_canonical_delegation.py'
GENERIC_SHA = '9909f60d16ad3eaed54b9f97ea0d275ad38510c679ba651ce05af44d920ed0f6'
BINDING_SHA = '14cf53964f5d44d123e989805ea741669ab3f05054e730ddcb299a0aac51a9cb'
OLD_LAUNCHER_SHA = 'ae5afe6372c00c63c36d85c25ffe1cf5c2e9139b26dc6383210e0b8d109b1518'
OLD_FROZEN_SHA = 'f0a3079ce651227ce4a9f3dd764db83927d90c2b3e3e119e9aada3db36b9584c'

# New versions require a newly reviewed allowlist entry, including their own
# frozen evidence. A CLI argument cannot substitute a directory or trust hash.
ACCEPTED = {'candidate-unified-v75': {'release_id': 'ui-r57-20261023T024648Z-ca2e7385', 'unified_sha': 'b8168fdab20627f3daf96ac18b82a99071ed8f9ff9363b73decca990cc5ef0fc', 'files': 3288, 'release_sha': 'f279f70e14451a0e8c0304911bfc771ce3e30a1cd7984dd8abb5e9dbbb6a12e6', 'candidate_launcher_sha': 'efea841c6f713e2597e09215b9b6c8f05b6a203d2776fd24a8540c224c42e533', 'recovery_checkpoint': True, 'evidence': {'frozen-native/source-independent.json': '7753387fbb469efecbeb08611db00302aebfca1de5a189980f0abe7074fc8014', 'frozen-native/source-SEAL.json': '3cbc0bc55b70db80a1598334003322745dbe2f6949b7e6f470ec07ce3579ce5b', 'frozen-native/snapshot-independent.json': 'cd5a344ae8ea9d889f675e071779e1da46e53cff30718cb20ceec6d469d0832c', 'frozen-native/fresh-author.json': 'cd304ec6a171b70bc5eee4d2ca0f5b08287c99dd9a57cefb936b7a6992e6e3f9', 'frozen-native/navigation-author.json': '1acfdcc8171b0d3c8ceecd6d66076437fb9ff949566f3bbbae7cc98299549927', 'frozen-native/standard-independent.json': '862d04740674c26e33ccd59bf3fcf13437ab9636ce65347dad2994339c4f9af4', 'frozen-native/standard-SEAL.json': 'fc6a1d4b1884f9e9108cd3b79c844c6d56f9e0cae2659d1619a158bb768974fb', 'frozen-native/existing-lease-red74.json': '093b96e09fffccd69f720369b2981d6ddcadeaf3a372700d492e73b4d5c8d1ad', 'frozen-native/existing-lease-red75.json': '4c0ac6cff7561890bb0118653a2aa732ebd4c71a1365c04f316252ec52583b55', 'frozen-native/SUMMARY.json': '2c126bd2e4616539b2b81b79566dce30b451962aa92fa52542961641fdf95f90'}, 'delivery': 'delivery-v75', 'http_groups': 13, 'staged_sha': '480be1d3a59f7ea5aa7e8011535cca190108cfd432f3de7764de6460ab512e4a'}}
INSTALLATION_REVIEWED = False  # Fixed final75 acceptance still required.
V65_ROLLBACK_FILES = 2777

V65_UNIFIED_SHA = 'c6bc35bc5e2b44c437bf9b8262897d33faF4A5A5c7c1b5f859be130589735268'.lower()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def exact(path, expected):
    for item in (path, *path.parents):
        info = item.lstat()
        if item.is_symlink() or getattr(info, 'st_file_attributes', 0) & 0x400:
            raise RuntimeError('Links are not accepted: ' + path.name)
    before = path.stat()
    if not stat.S_ISREG(before.st_mode) or before.st_nlink != 1:
        raise RuntimeError('Expected a regular single-link file: ' + path.name)
    raw = path.read_bytes()
    after = path.stat()
    if (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) != (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns):
        raise RuntimeError('File changed while reading: ' + path.name)
    if sha(raw) != expected.lower():
        raise RuntimeError('Pinned bytes changed: ' + path.name)
    return raw


def read_json(raw):
    return json.loads(raw.decode('utf-8-sig'))


def closure(base, expected, count=None):
    pins = read_json(exact(base / 'UNIFIED-PINS.json', expected))
    if count is not None and len(pins['files']) != count:
        raise RuntimeError('Unexpected closure file count')
    seen = set()
    for row in pins['files']:
        rel = PurePosixPath(row['path'])
        if rel.is_absolute() or '..' in rel.parts or ':' in str(rel) or '\\' in str(rel) or str(rel) in seen:
            raise RuntimeError('Invalid closure member')
        seen.add(str(rel))
        raw = exact(base / 'project' / rel, row['sha256'])
        if len(raw) != row['bytes']:
            raise RuntimeError('Closure size mismatch')
    return len(seen)


def load_installer():
    raw = exact(GENERIC, GENERIC_SHA)
    module = importlib.util.module_from_spec(importlib.util.spec_from_loader('reviewed_entry_installer', loader=None))
    module.__file__ = str(GENERIC)
    exec(compile(raw, str(GENERIC), 'exec', optimize=0), module.__dict__)
    return module



def reviewed_spec(candidate):
    if not isinstance(candidate, str) or not re.fullmatch(r'candidate-unified-v[0-9]+', candidate) or candidate not in ACCEPTED:
        raise RuntimeError('Candidate needs a reviewed fixed-pin entry')
    spec = ACCEPTED[candidate]
    fields = {'release_id', 'unified_sha', 'files', 'release_sha', 'candidate_launcher_sha',
              'recovery_checkpoint', 'evidence', 'delivery', 'http_groups', 'staged_sha'}
    if not isinstance(spec, dict) or set(spec) != fields:
        raise RuntimeError('Reviewed candidate schema is incomplete')
    if not re.fullmatch(r'ui-r57-[0-9]{8}T[0-9]{6}Z-[a-f0-9]{8}', spec['release_id']):
        raise RuntimeError('Reviewed release identifier is invalid')
    if not re.fullmatch(r'delivery-v[0-9]+', spec['delivery']):
        raise RuntimeError('Reviewed evidence folder is invalid')
    for key in ('unified_sha', 'release_sha', 'candidate_launcher_sha', 'staged_sha'):
        if not isinstance(spec[key], str) or not re.fullmatch(r'[a-f0-9]{64}', spec[key]):
            raise RuntimeError('A fixed reviewed SHA256 is required')
    if type(spec['files']) is not int or spec['files'] < 1 or type(spec['http_groups']) is not int or spec['http_groups'] < 32:
        raise RuntimeError('Reviewed closure and evidence counts are invalid')
    if type(spec['recovery_checkpoint']) is not bool or not isinstance(spec['evidence'], dict):
        raise RuntimeError('Reviewed evidence schema is invalid')
    if len(spec['evidence']) < 5 or 'frozen-native/SUMMARY.json' not in spec['evidence']:
        raise RuntimeError('Reviewed frozen acceptance evidence is incomplete')
    for key, pin in spec['evidence'].items():
        rel = PurePosixPath(key)
        if rel.is_absolute() or '..' in rel.parts or ':' in key or '\\' in key or rel.parts[0] != 'frozen-native' or rel.suffix != '.json':
            raise RuntimeError('Reviewed evidence member is invalid')
        if not isinstance(pin, str) or not re.fullmatch(r'[a-f0-9]{64}', pin):
            raise RuntimeError('Reviewed evidence SHA256 is required')
    return spec


def check(candidate, allow_current_new=False):
    if candidate not in ACCEPTED:
        raise RuntimeError('Candidate needs a reviewed fixed-pin entry')
    spec = reviewed_spec(candidate)
    evidence_root = P / 'work/commercial-integration-20261022' / spec['delivery']
    base = F / candidate
    count = closure(base, spec['unified_sha'], spec['files'])
    # Preserve an actually intact v65 rollback, including its older guarded CLI.
    closure(F / 'candidate-unified-v65', V65_UNIFIED_SHA, V65_ROLLBACK_FILES)
    closure(F / 'candidate-unified-v72', '1a1c49af3fee70e1270a5fe71e12d24b6a35480814dc16c7a02205ae0d139295', 3152)
    closure(F / 'candidate-unified-v73', 'c0a72be807965903a5cbb9dfee9ba6549a6157ccf622fd7df86a9ef1397a167b', 3156)
    closure(F / 'candidate-unified-v74', '22e8969074ee54babe2d28619d95944bac78d4ae5f2085ed41541f0d833ccae7', 3282)
    exact(GENERIC, GENERIC_SHA)
    for rel, pin in spec['evidence'].items():
        exact(evidence_root / rel, pin)
    summary = read_json(exact(evidence_root / 'frozen-native/SUMMARY.json', spec['evidence']['frozen-native/SUMMARY.json']))
    if summary['totalHttpGroups'] != spec['http_groups'] or summary['realModelCalls'] or summary['realPlatformRequests'] or summary['productionAccess']:
        raise RuntimeError('Acceptance evidence is not the isolated frozen run')
    exact(N / 'state/production-workspace.json', BINDING_SHA)
    exact(base / 'project/work/ui-native-r57/state/production-workspace.json', BINDING_SHA)
    staged = read_json(exact(base / 'STAGED.json', spec['staged_sha']))
    release = base / 'project/work/ui-native-r57/releases' / spec['release_id']
    if staged['release_id'] != spec['release_id'] or Path(staged['release']) != release or staged['manifest_sha256'].lower() != spec['release_sha']:
        raise RuntimeError('Release descriptor does not match this candidate')
    exact(release / 'RELEASE.json', spec['release_sha'])
    if not allow_current_new:
        exact(N / 'run_workbench.py', OLD_LAUNCHER_SHA)
        exact(N / 'FROZEN.json', OLD_FROZEN_SHA)
    return spec, base, staged, release, count


def write_same_or_new(path, raw):
    # Used only for local draft preparation; never silently replaces a draft.
    for item in path.parents:
        if item.is_symlink() or getattr(item.lstat(), 'st_file_attributes', 0) & 0x400:
            raise RuntimeError('Draft parent cannot be a link')
    if path.exists():
        exact(path, sha(raw))
    else:
        with path.open('xb') as stream:
            stream.write(raw)


def prepare(candidate):
    spec, base, staged, release, count = check(candidate)
    folder = HERE / 'next-launch-prepared' / candidate
    for item in (folder, *folder.parents):
        if item.exists() and (item.is_symlink() or getattr(item.lstat(), 'st_file_attributes', 0) & 0x400):
            raise RuntimeError('Preparation path cannot be a link')
    folder.mkdir(parents=True, exist_ok=True)
    source = base / 'project/work/ui-native-r57' / ('run_candidate.' + spec['release_id'] + '.py')
    body = exact(source, spec['candidate_launcher_sha']).decode('utf-8')
    needle = "RELEASE = ROOT / 'releases/" + spec['release_id'] + "'"
    replacement = "PROJECT_ROOT = ROOT.parent.parent / 'work/parallel-integration-20261018/final-integration/" + candidate + "/project'\nRELEASE = PROJECT_ROOT / 'work/ui-native-r57/releases/" + spec['release_id'] + "'\nBINDING_SHA256 = '" + BINDING_SHA.upper() + "'"
    if body.count(needle) != 1 or body.count('project_root=ROOT.parent.parent') != 1:
        raise RuntimeError('Launcher template changed; review required')
    body = body.replace(needle, replacement).replace('project_root=ROOT.parent.parent', 'project_root=PROJECT_ROOT')
    needle = "        pinned(RELEASE / 'RELEASE.json', MANIFEST_SHA256)"
    if body.count(needle) != 1:
        raise RuntimeError('Launcher manifest check changed')
    body = body.replace(needle, "        pinned(ROOT / 'state/production-workspace.json', BINDING_SHA256)\n        pinned(PROJECT_ROOT / 'work/ui-native-r57/state/production-workspace.json', BINDING_SHA256)\n" + needle)
    compile(body, 'reviewed_next_launch.py', 'exec')
    raw = body.encode('utf-8')
    draft = folder / 'launcher.py.DRAFT'
    independent = N / ('run_delegated_candidate.' + spec['release_id'] + '.py')
    write_same_or_new(draft, raw)
    plan = {
        'status': 'PREPARED_NOT_INSTALLED', 'release_id': spec['release_id'],
        'release': str(release), 'manifest_sha256': staged['manifest_sha256'],
        'launcher': str(independent), 'launcher_sha256': sha(raw).upper(),
        'expected_previous_launcher_sha256': OLD_LAUNCHER_SHA.upper(),
        'expected_previous_frozen_sha256': OLD_FROZEN_SHA.upper(),
        'runtime_project_root': str(base / 'project'), 'installation_state_root': str(N / 'state'),
        'workspace_binding_sha256': BINDING_SHA.upper(), 'full_closure_files_verified': count,
        'full_closure_manifest_sha256': spec['unified_sha'].upper(),
        'validation': str(P / 'work/commercial-integration-20261022' / spec['delivery'] / 'frozen-native/SUMMARY.json'),
        'recovery_checkpoint': spec['recovery_checkpoint'], 'installed': False,
        'production_cloud_activation': False, 'production_data_migration': False,
        'scope': 'Reviewed next-launch entry only; preserve live data, sessions, v65 rollback, and old CLI.',
    }
    write_same_or_new(folder / 'CANONICAL-DELEGATION-PREPARED.json', (json.dumps(plan, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
    return folder, plan, raw


def install(candidate, recovery_ack):
    if INSTALLATION_REVIEWED is not True:
        raise RuntimeError('Installation is disabled in this review draft; root must approve final pins and this switch first')
    reviewed_spec(candidate)
    if ACCEPTED[candidate]['recovery_checkpoint'] and not recovery_ack:
        raise RuntimeError('This candidate is a recovery checkpoint; explicit acknowledgement is required')
    folder, plan, raw = prepare(candidate)
    # This is the first permitted write outside the delivery folder. It happens
    # only after --install, fixed acceptance checks, and explicit checkpoint ack.
    write_same_or_new(Path(plan['launcher']), raw)
    module = load_installer()
    module.HERE, module.P, module.NATIVE, module.OUT = folder, P, N, F / candidate
    previous = sys.argv
    try:
        sys.argv = [str(GENERIC), '--install']
        module.main()  # original exclusive backup + two-file CAS + failure rollback
    finally:
        sys.argv = previous


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--candidate', required=True)
    actions = parser.add_mutually_exclusive_group()
    actions.add_argument('--check', action='store_true')
    actions.add_argument('--prepare', action='store_true')
    actions.add_argument('--install', action='store_true')
    parser.add_argument('--ack-recovery-checkpoint', action='store_true')
    args = parser.parse_args()
    expected = P / 'work/commercial-integration-20261022/delivery-v75'
    if HERE != expected:
        raise RuntimeError('Keep this reviewed draft in its project delivery folder')
    if args.install:
        install(args.candidate, args.ack_recovery_checkpoint)
    elif args.prepare:
        folder, _, _ = prepare(args.candidate)
        print(json.dumps({'status': 'PREPARED_NOT_INSTALLED', 'folder': str(folder), 'restart': False}, ensure_ascii=False))
    else:
        _, _, _, _, count = check(args.candidate)
        print(json.dumps({'status': 'CHECK_ONLY', 'candidate': args.candidate, 'verifiedFiles': count, 'writes': 0, 'restart': False}))


if __name__ == '__main__':
    main()
