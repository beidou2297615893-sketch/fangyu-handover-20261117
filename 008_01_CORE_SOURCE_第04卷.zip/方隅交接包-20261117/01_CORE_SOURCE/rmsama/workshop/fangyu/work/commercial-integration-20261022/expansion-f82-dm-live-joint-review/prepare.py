from pathlib import Path
import ast,hashlib,json,difflib
W=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/commercial-integration-20261022')
OUT=W/'expansion-f82-dm-live-joint-review'
F=W.parent/'parallel-integration-20261018/final-integration/candidate-unified-v82'
S=F/'project'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text('utf-8-sig'))
expected={'STAGED.json':'58581f4644aaf17bea481dd45d6ef19713bf6bdf97a303ffd790be940bb7c958',
          'UNIFIED-PINS.json':'36a601743288689d6cff3159337ee4f548d1ee0d05366a28a83dd683a326f500'}
assert all(sha(F/n)==v for n,v in expected.items())
frozen=W/'next-release-f81-expansion-composition/FROZEN-INPUTS.json'
assert sha(frozen)=='ea024e9a6742b81f62510a25f6c47c9bd48dcea70bc57c0481dfe6ee09ba636e'
pins=read(F/'UNIFIED-PINS.json');stage=read(F/'STAGED.json');R=Path(stage['release'])
assert len(pins['files'])==3856 and stage['files']==538
assert sha(R/'RELEASE.json')==stage['manifest_sha256'].lower()=='d563f95ffe26cfef9c3d0034a17a84b0b730fa02ed32ccb86f10cfd3d4d20160'
for p in pins['files']:
 q=S/p['path'];assert q.stat().st_size==p['bytes'] and sha(q)==p['sha256'],p['path']
(OUT/'F82-INPUTS-VERIFIED.json').write_text(json.dumps({'stageSha256':expected['STAGED.json'],
 'unifiedPinsSha256':expected['UNIFIED-PINS.json'],'releaseManifestSha256':stage['manifest_sha256'],
 'frozenInputsSha256':sha(frozen),'filesVerified':3856,'resources':538,'frozenRoot':str(F),
 'sourceRoot':str(S),'release':str(R),'originalReadonly':True},ensure_ascii=False,indent=2)+'\n','utf-8')

adaptations=[]
def prepare(name,source_name,ranges=None,replacements=(),extra_insertion=None):
 src=W/source_name;raw=src.read_text('utf-8-sig');lines=raw.splitlines(keepends=True)
 selected=''.join(''.join(lines[a-1:b]) for a,b in ranges) if ranges else raw
 adapted=selected
 for old,new in replacements:
  assert old in adapted,(name,old);adapted=adapted.replace(old,new,1)
 if extra_insertion:
  old,new=extra_insertion;assert old in adapted;adapted=adapted.replace(old,new,1)
 assert_nodes=lambda s:[ast.dump(n,include_attributes=False) for n in ast.walk(ast.parse(s)) if isinstance(n,ast.Assert)]
 # Additional resolve assertions may be inserted, but every original selected
 # assertion must survive byte-for-byte in its syntax tree.
 original_asserts=assert_nodes(selected) if name.endswith('.py') else []
 final_asserts=assert_nodes(adapted) if name.endswith('.py') else []
 for item in original_asserts:assert item in final_asserts,name
 target=OUT/name;target.write_text(adapted,'utf-8')
 (OUT/(name+'.diff')).write_text(''.join(difflib.unified_diff(raw.splitlines(keepends=True),adapted.splitlines(keepends=True),fromfile=source_name,tofile=name)),'utf-8')
 adaptations.append({'target':name,'source':source_name,'originalSha256':sha(src),'adaptedSha256':sha(target),'selectedSourceLineRanges':ranges,'originalSelectedAssertions':len(original_asserts),'allSelectedAssertionsPreserved':True,'additionalAssertions':len(final_asserts)-len(original_asserts),'changes':'Fixed F82 input paths and selected original representative groups only; extra purpose resolve probe when present'})

dm_prefix="W=Path(__file__).resolve().parent;P=W.parents[2];S=W/'qa-only-project'"
dm_new="W=Path(__file__).resolve().parent;P=W.parents[2];S=Path("+repr(str(S))+")"
old_stage="stage_paths=sorted((S/'work/ui-native-r57/candidates').glob('*.json'));stage=json.loads(stage_paths[-1].read_text('utf-8-sig'));R=Path(stage['release'])"
new_stage="stage=json.loads(Path("+repr(str(F/'STAGED.json'))+").read_text('utf-8-sig'));R=Path(stage['release'])"
probe=""" from core.douyin_comments_policy import DouyinCommentsPolicy
 comment_review=DouyinCommentsPolicy(runtime.server).resolve()
 assert comment_review and comment_review['purpose']=='douyin_owned_video_comments' and len(comment_review['revision'])==64,comment_review
 save('ACTIVE-PURPOSES.json',{'accountComponentsRevision':component_revision,'commentPurposeResolve':comment_review,'bridgeRuntime':str(runtime.server.bridge.runtime),'sourceResources':str(core.resources_dir),'scope':runtime.server._runtime_license_usage_scope('internal_self_use_read'),'publicSendHold':runtime.server.company['runtime']['public_send_hold'],'platformRequests':0})
 checks.append('Additional F82 original main-comment-purpose resolver accepts exact combined reviewed source with original fixed purpose and no network')
"""
prepare('test_dm_factory.py','dm-controlled-transport-f81-independent-review/test_factory_dm.py',
 [(1,115),(123,133),(138,190),(230,245)],[(dm_prefix,dm_new),(old_stage,new_stage)],
 (" for i in range(2):\n",probe+" for i in range(2):\n"))
bridge_old="const ROOT=path.join(__dirname,'qa-only-project/work/ui-runtime-r55/work/runtime/douyin-bridge');"
bridge_new="const ROOT="+json.dumps(str(S/'work/ui-runtime-r55/work/runtime/douyin-bridge'))+";"
prepare('bridge_fixture.cjs','dm-controlled-transport-f81-independent-review/bridge_fixture.cjs',replacements=[(bridge_old,bridge_new)])

live_prefix="W=Path(__file__).resolve().parent;P=W.parents[2];S=W/'qa-only-project';BR=S/'work/ui-runtime-r55/work/runtime/douyin-bridge'"
live_new=dm_new+";BR=S/'work/ui-runtime-r55/work/runtime/douyin-bridge'"
live_stage="reports=sorted((S/'work/ui-native-r57/candidates').glob('*.json'),key=lambda p:p.stat().st_mtime_ns);stage=json.loads(reports[-1].read_text('utf-8'));R=Path(stage['release'])"
prepare('test_factory.py','livestream-controlled-observer-independent-review/test_factory.py',
 replacements=[(live_prefix,live_new),(live_stage,new_stage)])
prepare('vm_bridge_service.cjs','livestream-controlled-observer-independent-review/vm_bridge_service.cjs')
prepare('test_live_policy.py','livestream-controlled-observer-candidate/test_policy_managed.py',
 [(1,28),(72,82)])
(OUT/'HARNESS-ADAPTATION.json').write_text(json.dumps({'changesOnlyOwnHarness':True,'productSourceWritten':False,'selectedOriginalAssertionASTsUnchanged':True,'adaptations':adaptations},ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps({'status':'FIXED_F82_READY','filesVerified':3856,'harnesses':len(adaptations),'selectedDMGroups':'components/listen/UID/held/success/concurrent/cross-channel/unknown/reopen','liveFactoryGroups':6,'livePolicyGroups':2},ensure_ascii=False))
