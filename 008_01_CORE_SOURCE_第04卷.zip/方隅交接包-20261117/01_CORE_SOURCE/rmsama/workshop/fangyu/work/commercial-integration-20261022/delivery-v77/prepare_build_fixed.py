from pathlib import Path
import hashlib,json,runpy
D=Path(__file__).resolve().parent;source=D.parent/'delivery-v76/fix_package_build_pins.py'
raw=source.read_bytes();text=raw.decode('utf-8')
old='602f2bc7f30743c5c83b9b9194ab9e706e40f98e344ed956bbea543c63b466a8'
assert text.count(old)==1 and text.count("build['files']==3931")==1
text=text.replace('v76','v77').replace('V76','V77').replace("build['files']==3931","build['files']==3951").replace(old,'a8220d69b0f77b063d79fa8d7eaa2abe39f7abed59397df31d792a016ff4d2e3')
target=D/'fix_package_build_pins.py';assert not target.exists();target.write_text(text,encoding='utf-8')
(D/'BUILD-DESCRIPTOR-GENERATOR.json').write_text(json.dumps({'parentSha256':hashlib.sha256(raw).hexdigest(),'derivedSha256':hashlib.sha256(target.read_bytes()).hexdigest(),'scope':'Version path and actual completed 3951-file SFX pin only; descriptor captures actual files, not a delivery approval'},indent=2)+'\n',encoding='utf-8')
runpy.run_path(str(target),run_name='__main__')
