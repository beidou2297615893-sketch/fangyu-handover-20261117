from pathlib import Path
import hashlib,json,shutil,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;P=W.parents[2];F=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v74';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pins=json.loads((W/'BASE-AND-CANDIDATE-PINS.json').read_text('utf-8'));unified=json.loads((F/'UNIFIED-PINS.json').read_text('utf-8'));project=W/'project';project.mkdir()
for row in unified['files']:
    source=F/'project'/row['path'];assert source.stat().st_size==row['bytes'] and sha(source)==row['sha256'];target=project/row['path'];target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
for rel,item in pins['files'].items():
    source=W/'candidate'/rel;target=project/rel
    if item['beforeSha256'] is not None:assert sha(target)==item['beforeSha256'],rel
    assert sha(source)==item['sha256'];target.write_bytes(source.read_bytes())
assert sha(project/'work/ui-approved-implementation/ui-preview/pages/acquire.mjs')==pins['originalAcquireSha256']
print('Private F74 copy plus exactly six UI source files; no snapshot or fresh candidate overlay')
