from pathlib import Path
import hashlib
D=Path(__file__).resolve().parent;source=D.parent/'delivery-v77/check_actual_entry.py';text=source.read_text('utf-8')
anchor="assert sha(N / 'run_workbench.py') == '52c4db8cddb64802121c1a77d25f86149ba321f7427a45f46a4758d577e3fe3f'";assert text.count(anchor)==1
replacement="plan = json.loads((D/'next-launch-prepared/candidate-unified-v79/CANONICAL-DELEGATION-PREPARED.json').read_text('utf-8'))\nassert plan['release_id'] == 'ui-r57-20261023T054104Z-893b8383'\nassert sha(N / 'run_workbench.py') == plan['launcher_sha256'].lower()"
target=D/'check_actual_entry.py';assert not target.exists();target.write_text(text.replace(anchor,replacement),'utf-8');print(hashlib.sha256(target.read_bytes()).hexdigest())
