from pathlib import Path
import ast,hashlib,json
W=Path(__file__).resolve().parent;P=W.parents[2]
rel='work/ui-runtime-r55/src/core/engine.py'
origin=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v82/project'/rel
t=origin.read_text('utf-8')
needle="    def _handle(self,action,data,user,*,execution_guard=None):\n        runtime=self.deployment_config.get('runtime') or {}\n"
assert t.count(needle)==1
t=t.replace(needle,needle+"""        customer_douyin_task=False
        if action in ('run_task','run_task_sequence','resume_task'):
            from .douyin_customer_tasks import core_action_allowed
            customer_douyin_task=core_action_allowed(self,action,data,user)
""")
needle="                and not self._page_read_allowed(action)\n                and action in ('account_login_spec'"
assert t.count(needle)==1
t=t.replace(needle,"                and not self._page_read_allowed(action)\n                and not customer_douyin_task\n                and action in ('account_login_spec'")
ast.parse(t);path=W/'source-candidate'/rel;assert not path.exists();path.write_text(t,'utf-8')
origins=json.loads((W/'BEFORE-ORIGINS.json').read_bytes())
origins.append({'path':rel,'beforeOrigin':str(origin),'beforeSha256':hashlib.sha256(origin.read_bytes()).hexdigest(),
    'afterSha256':hashlib.sha256(path.read_bytes()).hexdigest()})
(W/'BEFORE-ORIGINS.json').write_text(json.dumps(origins,ensure_ascii=False,indent=2),'utf-8')
print('Only original Core._handle platform-gate hunk changed; import/filter/analysis bytecode remain original')
