from pathlib import Path
import ast,hashlib,json
W=Path(__file__).resolve().parents[1];D=Path(__file__).resolve().parent
source=W/'delivery-v73/install_verified_entry.py';raw=source.read_bytes();text=raw.decode('utf-8')
tree=ast.parse(text);lines=text.splitlines(keepends=True)
replacements={
 'ACCEPTED':'ACCEPTED = {}\n',
 'INSTALLATION_REVIEWED':'INSTALLATION_REVIEWED = False  # Await exact v74 evidence and root review.\n',
 'OLD_LAUNCHER_SHA':"OLD_LAUNCHER_SHA = '64f6129e337016f1eb87a7200563fd9cf390b4615d54118b95f9e9d66d48d102'\n",
 'OLD_FROZEN_SHA':"OLD_FROZEN_SHA = '8d2f1967a1c7cb9230c5db73c3940e36db113d77308743060fa29b1825cb414a'\n",
}
selected=[n for n in tree.body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id in replacements]
assert len(selected)==4
for node in sorted(selected,key=lambda n:n.lineno,reverse=True):lines[node.lineno-1:node.end_lineno]=[replacements[node.targets[0].id]]
text=''.join(lines)
anchor="    closure(F / 'candidate-unified-v72', '1a1c49af3fee70e1270a5fe71e12d24b6a35480814dc16c7a02205ae0d139295', 3152)"
assert text.count(anchor)==1
text=text.replace(anchor,anchor+"\n    closure(F / 'candidate-unified-v73', 'c0a72be807965903a5cbb9dfee9ba6549a6157ccf622fd7df86a9ef1397a167b', 3156)")
ast.parse(text);target=D/'install_verified_entry.py';assert not target.exists()
target.write_text(text,encoding='utf-8')
old_functions={n.name:ast.dump(n,include_attributes=False) for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
new_functions={n.name:ast.dump(n,include_attributes=False) for n in ast.parse(text).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
assert {k for k in old_functions if old_functions[k]!=new_functions[k]}=={'check'}
out={'sourceSHA256':hashlib.sha256(raw).hexdigest(),'draftSHA256':hashlib.sha256(target.read_bytes()).hexdigest(),'allFunctionsExceptCheckIdentical':True,'checkOnlyAddsExactV73RollbackClosure':True,'installationReviewed':False,'accepted':{},'canonicalWritten':False}
(D/'NEXT-ENTRY-DRAFT.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps(out))
