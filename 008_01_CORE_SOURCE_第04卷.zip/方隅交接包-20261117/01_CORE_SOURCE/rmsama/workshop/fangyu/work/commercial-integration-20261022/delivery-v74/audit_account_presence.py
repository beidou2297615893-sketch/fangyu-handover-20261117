"""Only non-secret account metadata, read-only; never restore or read sessions/tokens."""
from pathlib import Path
import sqlite3,json,hashlib
P=Path('C:/积木软件工坊/项目/方隅公寓客户版');D=Path(__file__).resolve().parent
b=json.loads((P/'work/ui-native-r57/state/production-workspace.json').read_text('utf-8-sig'))
db=sqlite3.connect((Path(b['data_dir'])/'workspace.sqlite3').as_uri()+'?mode=ro',uri=True)
db.execute('PRAGMA query_only=ON');db.execute('BEGIN')
rows=db.execute("SELECT platform,store_id,status FROM (SELECT json_extract(body,'$.cloud_owner') AS owner,json_extract(body,'$.platform') AS platform,json_extract(body,'$.store_id') AS store_id,json_extract(body,'$.status') AS status FROM records WHERE entity='accounts') WHERE owner=?",(b['owner'],)).fetchall()
counts={}
for platform,store,status in rows:
    item=counts.setdefault(platform,{'records':0,'statuses':{},'storeCount':set()});item['records']+=1;item['statuses'][status]=item['statuses'].get(status,0)+1;item['storeCount'].add(store)
for item in counts.values():item['storeCount']=len(item['storeCount'])
lead_count=db.execute("SELECT COUNT(*) FROM records WHERE entity='leads' AND json_extract(body,'$.cloud_owner')=?",(b['owner'],)).fetchone()[0]
db.close()
out={'readOnly':True,'accountRecords':len(rows),'byPlatform':counts,'commentRecords':lead_count,'credentialsOrSessionsRead':False,'productionWritten':False,'backupRestored':False}
(D/'ACCOUNT-PRESENCE.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(out,ensure_ascii=False))
