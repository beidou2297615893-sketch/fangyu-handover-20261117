from pathlib import Path
import ast,subprocess,sys
T=Path(__file__).resolve().parent
B=T/(sys.argv[1] if len(sys.argv)>1 else 'source-joint1')
subprocess.run([sys.executable,str(T/'prepare_entry.py'),B.name],check=True)
header=(T/'probe_body.py.in').read_text('utf-8').split('    # Leave the original AI queue')[0]
a=header.index('    account_revision=connection._components')
b=header.index('    assert runtime.server._customer_read_authority.runtime_license_review',a)
header=header[:a]+"""    for purpose in ('douyin_owned_connection','douyin_owned_video_comments','douyin_owned_keyword_search_page'):
        assert runtime.server._customer_distribution_purpose(purpose) is not None,purpose
    assert DouyinCommentsPolicy(runtime.server).resolve() is None
    assert DouyinSearchPolicy(runtime.server).resolve() is None
    denied(lambda:connection._components(runtime.server))
"""+header[b:]
a=header.index("    checks.append({'group':'original-host-and-factory")
b=header.index('    assert binding_denied()',a)
header=header[:a]+"""    checks.append({'group':'original-factory-exact-customer-materials-before-lease-closed',
        'threeIndependentRawReviews':True,'componentsNotExecutionPermission':True,
        'scope':'customer_distribution_read','originalHolds':True})
"""+header[b:]
a=header.index('    device_calls=[];held=')
b=header.index('    deadline=time.monotonic()+10',a)
header=header[:a]+"""    device_calls=[];commands=[];outcomes={}
    cloud_port=json.loads((W.parent/'ORIGINAL-CLOUD-BRIDGE.json').read_bytes())['port']
    def cloud_control(path,data=None):
        c=http.client.HTTPConnection('127.0.0.1',cloud_port,timeout=30)
        c.request('POST','/'+path,json.dumps(data or {}).encode(),{'Content-Type':'application/json'})
        r=c.getresponse();out=json.loads(r.read());c.close();assert r.status==200,out
        return out
    def actual_cloud(operation,data,token=''):
        out=cloud_control('call',{'operation':operation,'data':data,'token':token})
        if out['status']!=200:
            from assistant.transport import CloudError
            raise CloudError(out['status'],str(out.get('data',{}).get('error','own-cloud-rejected')))
        return out['data']
    class OwnDeviceCloud:
        def __init__(self,*args,**kwargs):pass
        def call(self,operation,data,credential):
            device_calls.append(operation)
            return actual_cloud(operation,data,credential)
        def close(self):pass
    from assistant.customer_read_lease import current as current_read_lease,enrollment_fields
    own_token=actual_cloud('login',{'username':'fixture-admin','password':fixture.PASSWORD})['token']
    pair=actual_cloud('pair_create',{'name':'抖音客户只读隔离电脑',**enrollment_fields(runtime.server)},own_token)
    runtime.service.cloud_factory=OwnDeviceCloud
    runtime.service.bind(pair['pair_code'])
"""+header[b:]
header=header.replace("assert original_binding[3]=='owned-customer-device'", "assert original_binding[3]==runtime.service.device['id'] and len(original_binding[3])>=16")
needle="    account={'id':'owned-customer-account'"
insert="""    deadline=time.monotonic()+25
    while not current_read_lease(runtime.server,'douyin_owned_keyword_search_page') and time.monotonic()<deadline:time.sleep(.03)
    assert current_read_lease(runtime.server,'douyin_owned_keyword_search_page')
    assert current_read_lease(runtime.server,'douyin_owned_video_comments')
    assert current_read_lease(runtime.server,'douyin_owned_connection')
    assert not core._employee_release_allowed() and not core.employee_release_device_id and core.employee_release_until_monotonic==0
    runner=runtime.service._customer_read_runner
    assert runner.accept_commands is False and runner.portable_employee_release is False
    account_revision=connection._components(runtime.server)
    assert DouyinSearchPolicy(runtime.server).resolve() and DouyinCommentsPolicy(runtime.server).resolve()
    checks.append({'group':'actual-original-cloud-login-pair-enroll-poll-and-private-readlease',
        'actualCreateService':True,'realCloudNetwork':False,'fakeDeviceSessionOrLease':False,
        'generalEmployeeGrant':False,'remoteCommands':False,'scopeDoesNotGrantSends':True})
"""
assert header.count(needle)==1;header=header.replace(needle,insert+needle)
header=header.replace("'syntheticBoundaryOnly':True", "'actualOriginalCloudServiceLoopback':True,'nativeUiLoginTransportSynthetic':True")
tail=(T/'task_probe_tail.py.in').read_text('utf-8')
tail=tail.replace("    user={**user,'_workbench_store_id':store}","""    user={**user,'_workbench_store_id':store}
    assert runtime._executor(user,read_purpose='douyin_owned_keyword_search_page') is runtime.service.executor
    assert runtime._collection_readiness(user,account)==('','')
    denied(lambda:runtime._executor(user))
    assert not current_read_lease(runtime.server,'unknown-purpose')
""")
a=tail.index("    task2=new_task('合成第二账号同来源'")
b=tail.index('    all_leads=',a)
tail=tail[:a]+"""    outer=runtime.start_acquisition(user,{'taskName':'合成第二账号普通开始入口','platform':'douyin',
        'accountId':accounts[1]['id'],'keywords':['上海古北'],'dailyLimit':3,'targetCount':20,
        'time':'all','storeId':store,'intentMode':'all'})
    assert outer['result']['accepted'] is True
    second_id=outer['result']['taskId'];worker=runtime._runs[second_id]
    worker.join(420);assert not worker.is_alive(),'Actual ordinary UI task did not exit'
    task2=core.store.get('tasks',second_id)
    result2=task2['last_result']
    summary=result2.get('summary') or result2
    result2={**result2,'duplicates':summary.get('duplicates',0),'imported':summary.get('imported',0)}
    assert '首屏' in task2.get('last_message','')
    checks.append({'group':'actual-outer-start-acquisition-readlease-and-original-worker',
        'accepted':True,'actualOuterExecutorAndReadiness':True,'originalWorkerExited':True,
        'originalHoldsAndGeneralEmployeeFieldsUnchanged':True})
"""+tail[b:]
tail=tail.replace('    held[0]=True',"    cloud_control('qa-policy',{'enabled':False})")
tail=tail.replace('    held[0]=False',"    cloud_control('qa-policy',{'enabled':True})")
tail=tail.replace('    revoked[0]=True',"    actual_cloud('device_revoke',{'device_id':runtime.service.device['id']},own_token)")
tail=tail.replace("    assert runtime.service.state=='held';count=len(processes)","    assert runtime.service.state=='held';assert not current_read_lease(runtime.server,'douyin_owned_keyword_search_page');count=len(processes)")
tail=tail.replace("    if server:server.shutdown();server.server_close()", "    if 'cloud_control' in globals():\n        try:cloud_control('shutdown')\n        except Exception:pass\n    if server:server.shutdown();server.server_close()")
tail=tail.replace("'ownCloudContractResponses':True", "'actualOriginalCloudServiceLoopback':True,'nativeUiCloudLoginSynthetic':True")
body=header+tail;ast.parse(body)
entry=B/'probe_entry-joint.py';assert not entry.exists()
entry.write_text((B/'standard_loader_prefix.py').read_text('utf-8')+'\n'+body,'utf-8')
print('Exact original cloud + private readlease + outer start + CLI/Core own VM entry ready')
