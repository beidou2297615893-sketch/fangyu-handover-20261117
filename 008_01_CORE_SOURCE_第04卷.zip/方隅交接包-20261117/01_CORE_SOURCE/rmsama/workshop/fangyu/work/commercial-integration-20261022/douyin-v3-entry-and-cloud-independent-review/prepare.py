from pathlib import Path
import ast,hashlib,json,shutil,sqlite3,subprocess,sys
T=Path(__file__).resolve().parent;W=T.parent
A=W/'douyin-search-customer-after-f82-candidate'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(A/'FINAL-RECEIPT.json')=='4b3dcde74c380a3261f3f2820b4ed3db4dde25c6ddacf597d876785d3a36b002'
assert sha(A/'SEALED.json')=='f8f4f08d893b6f0dfe92fe38fadf43b7d7a580d92a6b8e2f15fd1788ab113828'
for row in json.loads((A/'SOURCE-FILES.json').read_bytes())['files']:
    source=A/'source-candidate'/row['path'];assert sha(source)==row['afterSha256']
    target=T/'source-candidate'/row['path'];target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
for name in ('prepare_probe.py','prepare_entry.py','probe_body.py.in','run_probe.py','search_bridge_fixture.cjs','source_entry_check.py.in'):
    shutil.copy2(A/name,T/name)
t=(A/'prepare_joint_probe.py').read_text('utf-8').replace('shared-read-lease-qa-v1','shared-read-lease-qa-v3').replace(
    'f4c82e9b629c8af2afd88e6aa2e21aac050ed40171e9de4ddc92b877907e4932',
    '76176e4ffd98335893fa53f37dbfac2ae9c6a1b86996680c414a13871ba2552e')
(T/'prepare_joint_probe.py').write_text(t,'utf-8')
subprocess.run([sys.executable,str(T/'prepare_joint_probe.py'),'source-joint-v3'],check=True)
B=T/'source-joint-v3'
subprocess.run([sys.executable,str(T/'prepare_entry.py'),B.name],check=True)
body=(A/'source-joint1/probe_entry-joint2.py').read_text('utf-8')
body=body[body.index("if hasattr(sys.stdout,'reconfigure')"):]
body=body[:body.index('    serial=0')]+(T/'minimal_tail.py.in').read_text('utf-8')
body=body.replace("W.parent/'cloud-joint2/ORIGINAL-CLOUD-BRIDGE.json'","W.parent/'ORIGINAL-CLOUD-BRIDGE.json'")
ast.parse(body)
(B/'probe_entry-minimal.py').write_text((B/'standard_loader_prefix.py').read_text('utf-8')+'\n'+body,'utf-8')
# Reuse exactly one prior OWN synthetic comment, never account/session rows.
prior=A/'source-joint1/payload/factory-c62f2a1d17ba41bba07e308aac8ded3e/data/workspace.sqlite3'
with sqlite3.connect(prior.as_uri()+'?mode=ro',uri=True) as db:
    rows=db.execute("SELECT body FROM records WHERE entity='leads'").fetchall()
assert len(rows)==1
row=json.loads(rows[0][0]);assert row['author']=='合成求租客户'
seed={k:row[k] for k in ('platform','source_id','text','source_type','author','author_id','url','note_url','comment_id','published_at','content_title','content_author') if k in row}
(B/'payload/qa-fixtures/seed-lead.json').write_text(json.dumps(seed,ensure_ascii=False,indent=2),'utf-8')
(T/'INPUTS.json').write_text(json.dumps({'sealedSixSourceFinal':sha(A/'FINAL-RECEIPT.json'),
    'sharedV3InterfaceSha256':sha(W/'xhs-customer-runtime-after-f82-candidate/shared-read-lease-qa-v3/INTERFACE.json'),
    'cloudSourceManifestSha256':sha(W/'customer-read-cloud-lease-candidate/SOURCE-CANDIDATE.json'),
    'rootCloudHeldZipSha256':sha(W/'customer-read-cloud-lease-candidate/customer-read-cloud-held.zip'),
    'seed':'One own prior VM comment through original importer; explicitly marked already-analyzed only to avoid model requests; no real data, credentials or platform evidence'},ensure_ascii=False,indent=2),'utf-8')
print('Fixed v3 minimal original HTTP button and outer worker prepared')
