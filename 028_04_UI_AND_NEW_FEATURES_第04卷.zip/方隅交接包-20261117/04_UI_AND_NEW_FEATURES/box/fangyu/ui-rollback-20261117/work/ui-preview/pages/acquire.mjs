import {customerAvatar,bindCustomerAvatars} from '../avatar.mjs';
import {requestAction} from '../dry-run-gate.mjs';
const escape = value => String(value ?? '').replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
const asset = name => `/assets/${name}`;
const icon = (name, cls='') => `<img class="acquire-icon ${cls}" src="${asset(name)}" alt="" aria-hidden="true">`;
let progressTimer = null;

function model(state) {
  if(state.connection==='preview')state.store ||= '古北店';
  const assignedStore=state.stores?.find(item=>item.id===state.storeId);
  state.acquire ??= {region:state.connection==='preview'?'上海 · 长宁区':assignedStore?.region||'',time:'最近7天',platforms:['小红书','抖音'],status:'idle',stage:0,tick:0,read:0,added:0,analyzed:0,duplicates:0,records:[]};
  const a=state.acquire;
  if(a.run&&a.run.store!==state.store){
    if(['running','paused'].includes(a.status))a.records.unshift({text:`${a.run.store} · 已切换门店，本次演示结束`,status:'已停止'});
    Object.assign(a,{status:'idle',stage:0,tick:0,read:0,added:0,analyzed:0,duplicates:0,run:null,region:state.connection==='preview'?(state.store==='浦江店'?'上海 · 闵行区':state.store==='徐汇店'?'上海 · 徐汇区':'上海 · 长宁区'):assignedStore?.region||''});
  }
  return state.acquire;
}
const phase = a => ({idle:'待开始',running:['搜索中','读取中','分析中','即将完成'][a.stage] || '采集中',paused:'已暂停',completed:'已完成',failed:'采集已中断'})[a.status];
const selected = (value, expected) => value === expected ? ' selected' : '';
const option = (text,value) => `<option${selected(value,text)}>${escape(text)}</option>`;


const copyFor = (status) => ({
  idle: {title:'待开始', sub:'门店已记住。点一次即可启动或继续。本预览没有本机账本，统计显示 —。', action:'启动／继续', icon:'icon-play-filled.svg'},
  running: {title:'运行中', sub:'演练闸门已记下启动，不会采集或发送。', action:'暂停', icon:'fy-icon-54-pause.png'},
  paused: {title:'已安全暂停', sub:'已先停住。可再点启动／继续。', action:'启动／继续', icon:'icon-play-filled.svg'},
  completed: {title:'待开始', sub:'上次演练已结束，不会留下真实采集结果。', action:'启动／继续', icon:'icon-play-filled.svg'},
  failed: {title:'已安全暂停', sub:'演练已停住，未连接本机真链路。', action:'启动／继续', icon:'icon-play-filled.svg'}
}[status] || {title:'待开始', sub:'门店已记住。点一次即可启动或继续。', action:'启动／继续', icon:'icon-play-filled.svg'});

export function render(state) {
  const a = model(state);
  const copy = copyFor(a.status);
  const store = state.store || '古北店';
  return `<div class="acquire-page home-control" data-page-acquire data-dry-run="true">
    <section class="acquire-card home-control-card" aria-label="一键获客">
      <p class="home-store">当前门店<span>${escape(store)}</span><em>已记住，日常不必来回切换</em></p>
      <h2 class="home-status" aria-live="polite">${escape(copy.title)}</h2>
      <p class="home-sub">${escape(copy.sub)}</p>
      <button class="acquire-start home-action" type="button" data-home-action="${a.status==='running'?'pause':'start'}">${icon(copy.icon)}<span>${escape(copy.action)}</span></button>
      <p class="home-gate">硬闸门演练：不会打开创作者中心，也不会连接本机采集或发送。</p>
    </section>
  </div>`;
}

export function bind(root,ctx) {
  clearTimeout(progressTimer);
  progressTimer = null;
  const mount = root.querySelector('[data-page-acquire]');
  if (!mount) return () => {};
  const {state} = ctx;
  const change = fn => ctx.update(s => fn(model(s),s));
  const button = root.querySelector('[data-home-action]');
  button?.addEventListener('click', () => {
    const a = model(state);
    const next = a.status === 'running' ? 'pause' : (a.status === 'paused' ? 'resume' : 'start');
    const gated = requestAction(next, {store: state.store || '古北店', from: a.status, dryRun: true});
    change(acq => {
      acq.records = acq.records || [];
      if (next === 'pause') {
        acq.status = 'paused';
        acq.records.unshift({text: '演练暂停（硬闸门，未发送采集指令）', status: '已安全暂停'});
      } else {
        acq.status = 'running';
        acq.run = {store: state.store || '古北店', dryRun: true};
        acq.records.unshift({text: `演练${next==='resume'?'继续':'启动'}（硬闸门，未采集）`, status: '运行中'});
      }
    });
    ctx.toast(next === 'pause' ? '已安全暂停。仅改变预览状态。' : '已记下启动。本副本不会采集或发送。');
    return gated;
  });
  return () => { clearTimeout(progressTimer); progressTimer = null; };
}

const count=value=>Number.isSafeInteger(value)&&value>=0?value:'—';

const livePhase=value=>({search:0,searching:0,read:1,reading:1,collect:1,collecting:1,save:2,saving:2,analyzing:2,complete:3,completed:3,finished:3})[value]??(Number.isInteger(value)&&value>=0&&value<=3?value:-1);
const liveStatus=value=>({idle:'待开始',queued:'等待执行',running:'采集中',pausing:'正在暂停',paused:'已暂停',resuming:'正在恢复',completed:'已完成',failed:'未完成',blocked:'已暂停 · 待核验',held:'已暂停 · 待核验',unconfirmed:'结果待核对',cancelled:'已取消',stopped:'已停止'})[value]||'状态待核验';
function unknownStart(state){return Boolean(state.acquisitionAttempt?.unconfirmed||['submitted','unconfirmed'].includes(state.platform?.lastRequest?.state));}
function visibleAcquisition(state,live){const last=state.platform?.lastRequest;return unknownStart(state)&&(!last?.job?.taskId||last.job.taskId!==live.taskId)?{...live,taskId:last?.job?.taskId||'',taskScope:null,status:'unconfirmed',phase:null,counts:{},records:[],canPause:false,canResume:false}:live;}
function liveModel(state){
  const store=state.stores?.find(item=>item.id===state.storeId),platforms=(state.platform?.platforms||[]).filter(row=>row.enabled);
  state.acquire??={region:store?.region||'',time:'最近7天'};
  const draft=state.acquire;draft.region??=store?.region||'';draft.time||='最近7天';
  if(unknownStart(state)){const conditions=state.acquisitionAttempt?.payload||state.platform?.lastRequest?.conditions||{};draft.region=typeof conditions.region==='string'?conditions.region:'';draft.time=typeof conditions.time==='string'?conditions.time:'';if(conditions.platform)draft.selectedPlatform=conditions.platform;}
  if(!platforms.some(row=>row.id===draft.selectedPlatform))draft.selectedPlatform=platforms[0]?.id||'';
  const platform=platforms.find(row=>row.id===draft.selectedPlatform);
  return {draft,store,platform,platforms,accountId:state.platformAccountSelections?.[platform?.id]||platform?.accountId||'',live:visibleAcquisition(state,state.platform?.acquisition||{})};
}
const activeStatuses=['running','queued','pausing','resuming','stopping'];
const currentCommentPolicy=scope=>Boolean(scope&&scope.scope==='search_comments'
  &&scope.commentKeywordMode==='all'&&scope.continuousEnabled===false
  &&scope.region===''&&scope.unknownPolicy==='exclude');
const legacyTaskPolicy=live=>Boolean(live.taskScope&&!currentCommentPolicy(live.taskScope));
const canResumeTask=(state,live)=>Boolean(currentCommentPolicy(live.taskScope)&&state.storeId&&live.taskScope?.storeId===state.storeId
  &&live.taskId&&live.canResume&&['paused','stopped'].includes(live.status));
function matchesTaskScope(state,current){
  const {draft,store,platform,accountId,live}=current,scope=live.taskScope;
  const words=state.platform?.lastRequest?.job?.taskId===live.taskId&&Array.isArray(state.platform?.lastRequest?.keywordBatch)?state.platform.lastRequest.keywordBatch:state.selection?.applied?.selectedKeywords,days={'最近3天':3,'最近7天':7,'最近30天':30}[draft.time];
  if(!scope||!days||!Array.isArray(words)||!words.length||words.some(word=>typeof word!=='string'))return false;
  const keywords=[...new Set(words.map(word=>word.trim()))];
  const today=new Date(Date.now()+8*60*60*1000).toISOString().slice(0,10);
  const from=new Date(Date.parse(today+'T00:00:00Z')-(days-1)*86400000).toISOString().slice(0,10);
  return scope.storeId===state.storeId&&scope.platform===platform?.id&&scope.accountId===accountId
    &&currentCommentPolicy(scope)&&scope.region===''&&(draft.region||'')===(store?.region||'')
    &&scope.city===(store?.city||'')&&scope.area===(store?.area||'')&&scope.dateFrom===from&&scope.dateTo===today
    &&JSON.stringify(scope.keywords)===JSON.stringify(keywords)&&scope.scope==='search_comments'
    &&scope.commentDateRange==='all'&&scope.intentMode==='all'
    &&Array.isArray(scope.excludes)&&scope.excludes.length===0
    &&scope.dailyLimit===(platform?.id==='xiaohongshu'?100:20)&&scope.targetCount===100;
}
function taskCaption(state,live){
  const scope=live.taskScope,platform={xiaohongshu:'小红书',douyin:'抖音'}[scope?.platform]||'原平台';
  const store=state.stores?.find(row=>row.id===scope?.storeId)?.name||'原门店';
  const date=/^\d{4}-\d{2}-\d{2}$/;
  const time=scope&&date.test(scope.dateFrom)&&date.test(scope.dateTo)?`${scope.dateFrom} 至 ${scope.dateTo}`
    :scope&&scope.dateFrom===''&&scope.dateTo===''?'全部时间':'原时间条件';
  return `${platform} · ${store} · ${time}`;
}
function recentPeople(state){const live=visibleAcquisition(state,state.platform?.acquisition||{});return live.status==='unconfirmed'?[]:Array.isArray(live.recent)?live.recent:[];}
export function renderTaskExecution(state,live={}){
  const scope=live.taskScope;
  if(!live.taskId||!scope||scope.storeId!==state.storeId)return '<section class="acquire-execution" aria-label="当前任务执行范围"><strong>当前任务执行范围</strong><p>当前门店暂无已核对的任务条件；词库总量不代表已执行词。</p></section>';
  const words=value=>Array.isArray(value)?value.filter(v=>typeof v==='string').map(escape).join('、'):'';
  const analysis=live.analysis||{},pending=count(analysis.pending);
  const analysisStatus={running:'意向分析中',queued:'等待意向分析',pending:'等待意向分析',paused:'意向分析已暂停',blocked:'意向分析受阻',completed:'本批分析已结束',succeeded:'本批分析已结束',failed:'本批分析未完成',unknown:'分析结果待核对'}[analysis.status]||'分析状态未返回';
  const analysisReason={AI_DISABLED:'企业 AI 未启用',AI_NOT_CONFIGURED:'企业 AI 尚未配置',AI_BILLING_UNKNOWN:'原分析请求结果未确认，不会自动重复提交',verification_required:'平台要求重新验证登录'}[analysis.code]||analysis.code||'';
  const time=scope.dateFrom&&scope.dateTo?`${escape(scope.dateFrom)} 至 ${escape(scope.dateTo)}`:scope.dateFrom===''&&scope.dateTo===''?'全部时间':'未返回';
  return `<section class="acquire-execution" aria-label="当前任务执行范围"><strong>当前任务执行范围</strong><dl><dt>搜帖词</dt><dd>${words(scope.keywords)||'未返回'}</dd><dt>任务排除词</dt><dd>${Array.isArray(scope.excludes)?words(scope.excludes)||'未设置':'未返回'}</dd><dt>帖子日期</dt><dd>${time} · 评论范围：${scope.commentDateRange==='all'?'全部时间':'按原任务条件'}</dd><dt>任务目标 / 日上限</dt><dd>${count(scope.targetCount)} / ${count(scope.dailyLimit)}</dd><dt>本批待分析</dt><dd>${pending} · ${escape(analysisStatus)}${analysisReason?' · '+escape(analysisReason):''}</dd><dt>本批分析来源</dt><dd>${analysis.provider||analysis.model?escape([analysis.provider,analysis.model].filter(Boolean).join(' · ')):'尚未返回模型来源；不能把本机判断或历史评级当成本批 AI 结果'}</dd></dl><p>以上来自已保存任务条件，不表示每个词已搜索完成；待分析数使用后台回执，模型来源不代表真实调用成功。</p></section>`;
}
function renderConnected(state){
  const current=liveModel(state),{draft,store,platform,accountId,live}=current,status=live.status||'unknown',stage=livePhase(live.phase),counts=live.counts||{};
  const timeRanges=Array.isArray(state.platform?.capabilities?.timeRanges)?state.platform.capabilities.timeRanges:[];
  const unconfirmed=unknownStart(state),last=state.platform?.lastRequest,pauseUnknown=Boolean(unconfirmed&&last?.requestId===(state.acquisitionAttempt?.payload?.requestId||last.requestId)&&last.job?.taskId&&live.canPause),locked=state.busy||unconfirmed||activeStatuses.includes(status),taskResume=Boolean(!unconfirmed&&canResumeTask(state,live)),resume=Boolean(taskResume&&matchesTaskScope(state,current)),startAllowed=Boolean(!state.busy&&(unconfirmed||resume||(!locked&&live.canStart!==false)));
  const statusMessage=state.platformError?'状态暂未更新：'+state.platformError:unconfirmed?(last?.message||'上次开始采集的结果尚未确认，操作编号与原条件已保留；请核对有归属的任务，不能重复发起。'):live.message||state.platform?.device?.message||(!state.platform?'正在读取真实采集状态…':'');
  const message=[statusMessage,timeRanges.length&&!timeRanges.includes('最近24小时')?'当前支持最近7天、3天或30天；最近24小时暂不可用。':''].filter(Boolean).join(' ');
  return `<div class="acquire-page" data-page-acquire>
    <section class="acquire-card acquire-launch" aria-label="获客范围"><div class="acquire-fields">
      <label class="acquire-field"><span>门店</span><div class="acquire-select-wrap">${icon('tabler-upgrade-calendar.svg')}<select data-acquire-store aria-label="选择门店" ${locked?'disabled':''}>${!state.storeId?'<option value="" selected disabled>请选择门店</option>':''}${(state.stores||[]).map(item=>`<option value="${escape(item.id)}"${selected(state.storeId,item.id)}>${escape(item.name)}</option>`).join('')||'<option value="">待管理员分配门店</option>'}</select></div></label>
      <label class="acquire-field"><span>区域</span><div class="acquire-select-wrap">${icon('tabler-upgrade-pin.svg')}<select data-acquire-region aria-label="选择区域" ${locked?'disabled':''}>${draft.region?`<option>${escape(draft.region)}</option>`:`<option value="">${unconfirmed?'上次区域待核对':'门店区域待配置'}</option>`}</select></div></label>
      <label class="acquire-field"><span>时间</span><div class="acquire-select-wrap">${icon('tabler-upgrade-calendar.svg')}<select data-acquire-time aria-label="选择时间范围" title="以后台实际支持的日期范围为准；最近24小时暂不可用" ${locked?'disabled':''}>${!draft.time?'<option value="" selected disabled>上次条件待核对</option>':''}${['最近7天','最近3天','最近24小时','最近30天'].map(item=>`<option${selected(draft.time,item)}${timeRanges.includes(item)?'':' disabled'}>${escape(item)}</option>`).join('')}</select></div></label>
      <button class="acquire-start" data-acquire-start aria-busy="${Boolean(state.busy)}" style="cursor:${state.busy?'wait':startAllowed?'pointer':'default'}" ${startAllowed?'':'disabled'}>${icon('icon-play-filled.svg')}<span>${state.busy?'处理中…':unconfirmed?'核对采集状态':resume?'继续获客':status==='completed'?'再次获客':'开始获客'}</span></button>
    </div><div class="acquire-launch-bottom"><button class="acquire-platform" data-acquire-platform aria-label="选择获客平台" title="切换小红书 / 抖音" style="display:inline-flex;align-items:center;gap:8px;padding:5px 10px;border:1px solid #cbdfe3;border-radius:5px;background:#fff" ${locked?'disabled':''}>平台：${escape(platform?.name||'平台尚未开通')} · 切换<img class="acquire-chevron" src="/assets/tabler-chevron-down.svg" alt="" aria-hidden="true"></button><button class="acquire-link" data-acquire-presets ${unconfirmed?'disabled':''}>更换门店预设 <img class="acquire-chevron" src="/assets/tabler-chevron-down.svg" alt="" aria-hidden="true"></button></div></section>
    <section class="acquire-card acquire-progress" aria-label="采集进度"><div class="acquire-card-heading"><h2>当前任务进度</h2><button class="acquire-link" data-acquire-records>查看记录 <img class="acquire-chevron" src="/assets/tabler-chevron-down.svg" alt="" aria-hidden="true"></button></div>
      <div class="acquire-stages"><ol>${['搜索','读取','意向分析','完成'].map((name,index)=>`<li class="${index===stage?'current ':''}${stage>index||status==='completed'?'complete ':''}"><span class="acquire-stage-dot">${stage>index||status==='completed'?icon('tabler-upgrade-check.svg'):''}</span><span>${name}</span></li>`).join('')}</ol><span class="acquire-status ${escape(status)}" aria-live="polite">${escape(state.platformLoading&&!state.platform?'正在读取':live.phase==='analyzing'?(status==='running'?'意向分析中':'意向分析待继续'):liveStatus(status))}</span></div>
      <div class="acquire-progress-bottom"><div class="acquire-metrics">${[['本次已读',counts.read],['新增入库',counts.added],['已分析',counts.analyzed],['重复',counts.duplicates],['筛除',counts.filtered]].map(([label,value])=>`<div><span>${label}</span><strong>${count(value)}</strong></div>`).join('<i aria-hidden="true">·</i>')}</div><button class="acquire-pause" data-acquire-pause title="${escape(taskResume?'继续原任务：'+taskCaption(state,live):'暂停当前任务')}" ${!state.busy&&(unconfirmed?pauseUnknown:(live.canPause||taskResume))?'':'disabled'}>${icon(taskResume?'icon-play-filled.svg':'fy-icon-54-pause.png')}<span>${taskResume?'继续':status==='pausing'?'暂停中':'暂停'}</span></button></div>
      <p class="acquire-count-note">已读不等于新增客户；筛除数量未返回时显示 —。历史客户请在客户页查看。</p>${message?`<p class="acquire-inline-error" role="status">${escape(message)}</p>`:''}${renderTaskExecution(state,live)}
    </section>
    <section class="acquire-card acquire-recent" aria-label="最新意向"><div class="acquire-card-heading"><h2>最新意向</h2><button class="acquire-link" data-acquire-customers>查看客户清单 <img class="acquire-chevron" src="/assets/tabler-chevron-down.svg" alt="" aria-hidden="true"></button></div><div class="acquire-recent-list">${recentPeople(state).map((person,index)=>`<button class="acquire-person" data-live-acquire-person="${index}">${customerAvatar(person,'acquire-avatar')}<strong>${escape(person.name||person.authorName||'平台客户')}</strong><span class="acquire-person-copy">${escape(person.copy||person.text||person.content||'')}</span><span class="acquire-intent">${escape(person.intent||person.level||'尚未分析')}</span><time>${escape(person.time||person.createdAt||'')}</time><img class="acquire-person-next" src="/assets/tabler-chevron-down.svg" alt="" aria-hidden="true"></button>`).join('')||'<p class="muted">暂无本门店的真实采集结果。</p>'}</div></section>
  </div>`;
}
function bindConnected(root,ctx){
  bindCustomerAvatars(root);
  clearTimeout(progressTimer);progressTimer=null;
  const {state}=ctx,{draft,live,platforms}=liveModel(state);
  root.querySelector('[data-acquire-store]')?.addEventListener('change',event=>{if(event.target.value)ctx.actions.selectStore(event.target.value);});
  root.querySelector('[data-acquire-region]')?.addEventListener('change',event=>ctx.update(s=>{s.acquire.region=event.target.value;}));
  root.querySelector('[data-acquire-time]')?.addEventListener('change',event=>ctx.update(s=>{s.acquire.time=event.target.value;}));
  root.querySelector('[data-acquire-presets]')?.addEventListener('click',()=>ctx.navigate('presets'));
  root.querySelector('[data-acquire-customers]')?.addEventListener('click',()=>ctx.navigate('customers'));
  root.querySelector('[data-acquire-platform]')?.addEventListener('click',()=>ctx.modal({title:'选择获客平台',html:`<div class="acquire-platform-options">${platforms.map(row=>`<label><input type="radio" name="live-acquire-platform" value="${escape(row.id)}" ${draft.selectedPlatform===row.id?'checked':''}> ${escape(row.name)}</label>`).join('')||'<p>当前企业尚未开通采集平台。</p>'}</div><p class="modal-note">仅使用当前门店已授权并核验的平台账号。</p>`,confirmLabel:'确认选择',onConfirm:()=>{const value=document.querySelector('input[name="live-acquire-platform"]:checked')?.value;if(!value)return false;ctx.update(s=>{s.acquire.selectedPlatform=value;});}}));
  root.querySelector('[data-acquire-start]')?.addEventListener('click',()=>{
    if(state.busy)return;
    if(unknownStart(state))return ctx.actions.verifyAcquisition?.();
    const current=liveModel(state);
    if(canResumeTask(state,current.live)&&matchesTaskScope(state,current))return ctx.actions.resumeAcquisition?.(current.live.taskId);
    if(activeStatuses.includes(current.live.status)||current.live.canStart===false)return;
    return ctx.actions.startAcquisition?.();
  });
  root.querySelector('[data-acquire-pause]')?.addEventListener('click',()=>{
    if(state.busy)return;
    const current=liveModel(state),live=current.live,last=state.platform?.lastRequest;
    if(unknownStart(state)){
      if(last?.job?.taskId&&last.requestId===(state.acquisitionAttempt?.payload?.requestId||last.requestId)&&live.canPause)
        return ctx.actions.pauseAcquisition?.(last.job.taskId);
      return;
    }
    if(!canResumeTask(state,live))return live.canPause?ctx.actions.pauseAcquisition?.(live.taskId):undefined;
    if(matchesTaskScope(state,current))return ctx.actions.resumeAcquisition?.(live.taskId);
    const taskId=live.taskId,actor=JSON.stringify([state.user,state.storeId]),scope=JSON.stringify(live.taskScope);
    return ctx.modal({title:'继续原任务',html:`<p>${escape(taskCaption(state,live))}</p>`,confirmLabel:'继续原任务',onConfirm:()=>{
      const fresh=liveModel(state).live;
      if(state.busy||unknownStart(state)||actor!==JSON.stringify([state.user,state.storeId])
          ||fresh.taskId!==taskId||!canResumeTask(state,fresh)||JSON.stringify(fresh.taskScope)!==scope)return false;
      return ctx.actions.resumeAcquisition?.(taskId);
    }});
  });
  root.querySelector('[data-acquire-records]')?.addEventListener('click',()=>ctx.modal({title:'采集记录',html:`<div class="acquire-records"><p>${escape(taskCaption(state,live))}</p><div class="acquire-record-summary"><strong>${escape(liveStatus(live.status))}</strong><span>本次已读 ${count(live.counts?.read)} · 新增入库 ${count(live.counts?.added)} · 已分析 ${count(live.counts?.analyzed)} · 重复 ${count(live.counts?.duplicates)}</span></div>${(Array.isArray(live.records)?live.records:[]).map(record=>`<div class="acquire-record-row"><span>${escape(record.text||record.message||'')}</span><b>${escape(record.status||'')}</b></div>`).join('')||'<p class="modal-note">当前没有可显示的真实采集记录。</p>'}</div>`,confirmLabel:'刷新状态',onConfirm:async()=>{await ctx.actions.refreshPlatform();return false;}}));
  for(const button of root.querySelectorAll('[data-live-acquire-person]'))button.onclick=()=>{const person=recentPeople(state)[Number(button.dataset.liveAcquirePerson)];if(person)ctx.modal({title:person.name||person.authorName||'采集结果',html:`<p>${escape(person.copy||person.text||person.content||'暂无正文')}</p><p class="muted">${escape(person.intent||person.level||'尚未分析')}</p>`});};
  return ()=>{clearTimeout(progressTimer);progressTimer=null;};
}
