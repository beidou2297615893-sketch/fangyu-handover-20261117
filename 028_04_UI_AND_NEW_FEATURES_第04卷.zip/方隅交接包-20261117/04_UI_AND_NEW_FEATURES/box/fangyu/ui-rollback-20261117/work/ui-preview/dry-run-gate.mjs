/* 本副本硬闸门：只允许改变本地预览状态，绝不采集、发送或连接本机真链路。 */
export const GATE = Object.freeze({
  mode: 'dry-run',
  allowRealAcquisition: false,
  allowRealSend: false,
  allowRealBridge: false,
  allowOpenDouyin: false,
  douyinLoginUrl: 'https://www.douyin.com/jingxuan',
  forbidCreatorCenter: true,
  note: '云电脑工作副本。启动／暂停、登录与回复都只改本页演示状态。'
});

const log = [];

export function gateStatus() {
  return {...GATE, actions: log.slice(-20)};
}

export function requestAction(action, detail = {}) {
  const entry = {
    time: new Date().toISOString(),
    action,
    detail,
    allowedLocalState: true,
    blockedRealLink: true
  };
  if (['start', 'resume', 'pause', 'login-douyin', 'send', 'prepare', 'connect-account'].includes(action)) {
    entry.reason = 'hard-gate: dry-run only, no real collection/send/bridge';
  }
  log.push(entry);
  if (log.length > 100) log.shift();
  return {ok: true, dryRun: true, blockedRealLink: true, action, detail};
}
