'use strict';
const fs=require('node:fs'),path=require('node:path');
const {BridgeClient}=require('../runtime/douyin-bridge/lib/client/bridge-client');
const read=file=>JSON.parse(fs.readFileSync(file,'utf8'));
async function main(){
 const [planFile,configFile]=process.argv.slice(2),plan=read(planFile);
 const bridge=new BridgeClient({...read(configFile).bridge,reuseConnections:false});
 const current=(await bridge.status()).connections?.['douyin.com']||[];
 if(current.filter(c=>c.alive&&c.id===plan.connection_id).length!==1)throw Error('pinned_connection_unavailable');
 const refused=await bridge.call({site:'douyin.com',connId:'nonexistent-collection-confirmation-proof',expression:'1',awaitPromise:true,timeout:3000});
 if(refused.ok!==false||!/指定(?:群工具|浏览器)连接已离线/.test(refused.error))throw Error('strict_route_not_verified');
 const expression=`(async()=>{const page_ready=!!document.body&&location.hostname==='www.douyin.com';const challenge_visible=Array.from(document.querySelectorAll('iframe')).some(f=>{const r=f.getBoundingClientRect(),s=getComputedStyle(f);return /verifycenter|captcha|rmc.bytedance.com/.test(f.src)&&r.width>0&&r.height>0&&s.display!=='none'&&s.visibility!=='hidden'&&s.opacity!=='0';});if(!page_ready||challenge_visible)return {page_ready,challenge_visible};const q=new URLSearchParams(window.__bridge._q());const r=await fetch('/aweme/v1/web/user/profile/self/?'+q,{credentials:'include',redirect:'error',signal:AbortSignal.timeout(8000)});if(!r.ok||!(r.headers.get('content-type')||'').includes('json'))return null;const d=await r.json();return {page_ready,challenge_visible,status:d.status_code,sec_uid:d.user?.sec_uid,nickname:d.user?.nickname,unique_id:d.user?.unique_id||d.user?.short_id};})()`;
 const result=await bridge.call({site:'douyin.com',connId:plan.connection_id,expression,awaitPromise:true,timeout:14000});
 if(result.ok!==true||result.connection!==plan.connection_id||result.value?.page_ready!==true||result.value?.challenge_visible!==false||result.value?.status!==0||result.value.sec_uid!==plan.account_uid){console.error(JSON.stringify({ok:result.ok,connection_matches:result.connection===plan.connection_id,page_ready:result.value?.page_ready,challenge_visible:result.value?.challenge_visible,status:result.value?.status,uid_matches:result.value?.sec_uid===plan.account_uid}));throw Error('authorized_account_not_verified');}
 console.log(JSON.stringify({observed_at:new Date().toISOString(),connection_id:result.connection,account:result.value}));
}
main().catch(()=>{console.error('Pinned collection account could not be verified.');process.exitCode=1;});
