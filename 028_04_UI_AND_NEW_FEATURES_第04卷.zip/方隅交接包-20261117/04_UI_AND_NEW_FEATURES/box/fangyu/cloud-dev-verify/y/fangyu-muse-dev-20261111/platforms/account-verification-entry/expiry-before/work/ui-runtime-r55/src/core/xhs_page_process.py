"""Pinned CLI reuse for one explicit task, with parent-owned durable receipts."""
from contextlib import nullcontext
import hashlib
import json
import os
from pathlib import Path
import queue
import re
import secrets
import stat
import subprocess
import threading
import time
from assistant.xhs_cli_page_worker import LIMIT,digest,page_key,validate_args

class PageWorkerError(RuntimeError):
    def __init__(self,code,message):super().__init__(message);self.code=code

def plain(path):
    path=Path(path).absolute()
    for item in (path,*path.parents):
        if not item.exists():continue
        info=item.lstat()
        if item.is_symlink() or getattr(info,'st_file_attributes',0)&0x400:
            raise PageWorkerError('CLI_PAGE_PATH','采集回执路径无法核对')
        if item.is_file() and (not stat.S_ISREG(info.st_mode) or info.st_nlink!=1):
            raise PageWorkerError('CLI_PAGE_PATH','采集回执文件无法核对')
    return path

def fingerprint(home):
    path=plain(Path(home)/'.xiaohongshu-cli/cookies.json')
    if not path.exists():return None
    before=path.stat();data=path.read_bytes();after=path.stat()
    if (before.st_size,before.st_mtime_ns,before.st_ino)!=(after.st_size,after.st_mtime_ns,after.st_ino):
        raise PageWorkerError('CLI_SESSION_CHANGED','账号会话正在变化，请保留当前任务')
    return hashlib.sha256(data).hexdigest()

class PageWorker:
    def __init__(self,spec,job_id,scope,guard,register_process=None,unregister_process=None,*,spawn_lock=None,protocol=None,recover_unsent=False,verified_retry=None):
        import re
        if (type(spec) is not dict or not callable(guard) or not re.fullmatch(r'[A-Za-z0-9_-]{1,160}',job_id)
                or not re.fullmatch(r'[0-9a-f]{64}',scope)):
            raise ValueError('Exact original task scope required')
        self.spec=spec;self.job_id=job_id;self.scope=scope;self.guard=guard
        self.home=plain(spec['env']['HOME']);self.account=self.home.name
        self.receipts=plain(self.home/'.workbench-page-receipts'/job_id)
        self.cookie=fingerprint(self.home);self.nonce=secrets.token_hex(32)
        self._register=register_process or (lambda p:None);self._unregister=unregister_process or (lambda p:None)
        self._spawn_lock=spawn_lock;self._request_lock=threading.Lock();self._process_lock=threading.RLock()
        self._process=None;self._reader_thread=None;self._frames=queue.Queue(maxsize=8)
        self._closed=False;self._active=False;self._stderr='';self._guard_failed=False
        self.protocol=protocol;self.recover_unsent=recover_unsent is True
        self._ready=False;self._last_exit_code=None
        self.verified_retry=dict(verified_retry or {});self._verified_used=set()

    def _check(self,*,starting=False):
        if self._closed:raise PageWorkerError('CLI_WORKER_STOPPED','本次采集进程已停止，原回执保留')
        try:self.guard()
        except BaseException:
            self._guard_failed=True;raise
        if fingerprint(self.home)!=self.cookie:
            self._guard_failed=True
            raise PageWorkerError('CLI_SESSION_CHANGED','账号会话已变化，原采集断点保留')

    def _save(self,path,value):
        plain(self.receipts).mkdir(parents=True,exist_ok=True);plain(path)
        temporary=plain(path.with_name(path.name+'.'+secrets.token_hex(8)+'.tmp'))
        raw=(json.dumps(value,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n').encode('utf-8')
        if len(raw)>LIMIT+65536:raise PageWorkerError('CLI_PAGE_SIZE','本页输出超出保存范围')
        with temporary.open('xb') as stream:stream.write(raw);stream.flush();os.fsync(stream.fileno())
        plain(path);os.replace(temporary,path)

    def _send(self,packet):
        # Frozen Windows stdin may still be cp936 even with PYTHONUTF8=1.
        # ASCII JSON preserves the exact Unicode values across that pipe.
        raw=json.dumps(packet,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n'
        if len(raw.encode('utf-8'))>LIMIT:raise ValueError('Page frame exceeds bound')
        process=self._process
        if process is None or process.poll() is not None:raise EOFError('Original page worker exited')
        process.stdin.write(raw);process.stdin.flush()

    def _next(self,deadline):
        while True:
            remaining=deadline-time.monotonic()
            if remaining<=0:raise TimeoutError('Original page response timed out')
            try:value=self._frames.get(timeout=min(.1,remaining))
            except queue.Empty:
                self._check();continue
            if isinstance(value,BaseException):raise value
            if type(value) is not dict or value.get('nonce')!=self.nonce:raise ValueError('Original worker frame mismatch')
            return value

    def _start(self,deadline):
        if self._process is not None:
            if self._process.poll() is not None:raise EOFError('Original page worker exited')
            return
        self._check()
        argv=self.spec['argv']
        # Only the pinned executable can dispatch this fixed owned helper.
        if not argv or not Path(argv[0]).is_absolute():raise ValueError('Fixed CLI executable required')
        with self._spawn_lock or nullcontext():
            if self._closed:raise EOFError('Page task closed')
            process=subprocess.Popen([argv[0],'--owned-xhs-cli-pages'],shell=False,
                stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                text=True,encoding='utf-8',errors='strict',cwd=self.spec.get('cwd'),
                env={**os.environ,**self.spec['env']},creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
            self._process=process
            try:self._register(process)
            except BaseException:
                process.terminate();process.wait(timeout=3);self._process=None;raise
        def read_frames():
            try:
                while True:
                    line=process.stdout.readline(LIMIT+1)
                    if not line:raise EOFError('Original page response disconnected')
                    if len(line.encode('utf-8'))>LIMIT:raise ValueError('Page frame exceeds bound')
                    self._frames.put(json.loads(line),timeout=1)
            except BaseException as error:
                try:self._frames.put(error,timeout=1)
                except queue.Full:pass
        def read_stderr():
            try:
                while True:
                    part=process.stderr.read(1024)
                    if not part:return
                    self._stderr=(self._stderr+part)[-65536:]
            except Exception:pass
        self._reader_thread=threading.Thread(target=read_frames,name='xhs-page-read',daemon=True);self._reader_thread.start()
        threading.Thread(target=read_stderr,name='xhs-page-errors',daemon=True).start()
        self._send({'type':'hello','version':1,'nonce':self.nonce,'scope':self.scope,'task':self.job_id,'account':self.account})
        ready=self._next(deadline)
        if ready!={'type':'ready','nonce':self.nonce,'scope':self.scope}:raise ValueError('Original task handshake mismatch')
        self._ready=True

    def request(self,args,timeout=35):
        validate_args(args);key=page_key(args);arguments=digest(args)
        with self._request_lock:
            self._guard_failed=False
            self._check();path=plain(self.receipts/(key+'.json'))
            verified_retry=False;grant=None
            if path.exists():
                try:
                    previous_raw=path.read_bytes()
                    if len(previous_raw)>LIMIT+65536:raise ValueError('Receipt exceeds bound')
                    previous=json.loads(previous_raw.decode('utf-8'))
                except (OSError,ValueError):raise PageWorkerError('CLI_PAGE_UNCONFIRMED','原页回执无法核对，不会重新读取') from None
                if type(previous) is not dict:
                    raise PageWorkerError('CLI_PAGE_UNCONFIRMED','原页回执格式无法核对，不会重新读取')
                if (previous.get('scope')!=self.scope or previous.get('page')!=key
                        or previous.get('args_digest')!=arguments):
                    raise PageWorkerError('CLI_PAGE_SCOPE_CHANGED','原页任务或来源已变化，保留原记录')
                result=previous.get('result')
                if (previous.get('state') in ('received','acknowledged') and type(result) is dict
                        and set(result)=={'stdout','stderr','returncode'} and type(result.get('stdout')) is str
                        and type(result.get('stderr')) is str and type(result.get('returncode')) is int
                        and digest(result)==previous.get('digest')):
                    from .xhs_verified_resume import captcha_receipt
                    grant=self.verified_retry.get(key)
                    verified_retry=bool(type(grant) is dict and key not in self._verified_used
                        and self.protocol=='task-bound-read-v1' and self._process is None
                        and re.fullmatch(r'[a-f0-9]{32}',str(grant.get('generation') or ''))
                        and re.fullmatch(r'[a-f0-9]{64}',str(grant.get('account_revision') or ''))
                        and grant.get('task')==self.job_id and grant.get('scope')==self.scope
                        and grant.get('args_digest')==arguments
                        and grant.get('credential_sha256')==self.cookie
                        and type(grant.get('expires_at')) in (int,float) and time.time()<grant['expires_at']
                        and grant.get('receipt_sha256')==hashlib.sha256(previous_raw).hexdigest()
                        and captcha_receipt(previous))
                    if not verified_retry:return result['stdout'],result['stderr'],result['returncode']
                not_sent=(previous.get('state')=='not_sent' and type(previous.get('wire_allow_attempts')) is int
                    and previous['wire_allow_attempts']==0 and previous.get('process_exited') is True)
                legacy_unsent=(self.recover_unsent and self.protocol=='task-bound-read-v1' and self._process is None
                    and type(previous.get('version')) is int and previous['version']==1
                    and previous.get('task')==self.job_id and previous.get('state')=='unknown'
                    and previous.get('error_type')=='EOFError' and type(previous.get('wire_allow_attempts')) is int
                    and previous['wire_allow_attempts']==0 and 'result' not in previous and 'digest' not in previous)
                if not not_sent and not legacy_unsent and not verified_retry:
                    raise PageWorkerError('CLI_PAGE_UNCONFIRMED','原页结果尚未确认，已保留断点，不会重复请求')
                if legacy_unsent or verified_retry:
                    # The pinned protocol cannot enter HTTP before a persisted
                    # allow attempt. Only an explicit employee resume may recover
                    # this old local EOF; retain the original record as evidence.
                    self._check();plain(path)
                    if path.read_bytes()!=previous_raw:raise PageWorkerError('CLI_PAGE_SCOPE_CHANGED','原页记录已变化，保留原断点')
                    proof=hashlib.sha256(previous_raw).hexdigest()
                    archive=plain(path.with_name(path.stem+('.verified-' if verified_retry else '.unsent-')+proof+'.json'))
                    try:
                        with archive.open('xb') as stream:stream.write(previous_raw);stream.flush();os.fsync(stream.fileno())
                    except FileExistsError:
                        if archive.read_bytes()!=previous_raw:raise PageWorkerError('CLI_PAGE_UNCONFIRMED','原页归档无法核对，保留原断点') from None
                    if path.read_bytes()!=previous_raw:raise PageWorkerError('CLI_PAGE_SCOPE_CHANGED','原页记录已变化，保留原断点')
            record={'version':1,'scope':self.scope,'task':self.job_id,'page':key,'args_digest':arguments,
                'operation':args[0],'state':'submitted','created_at':time.time(),'wire_allow_attempts':0}
            if path.exists() and 'legacy_unsent' in locals() and legacy_unsent:
                record['unsent_recovery']={'explicit_resume':True,'previous_sha256':proof,'archive':archive.name}
            if verified_retry:
                record['verified_retry']={'explicit_resume':True,'previous_sha256':proof,
                    'archive':archive.name,'generation':grant['generation']}
                self._verified_used.add(key)
            self._save(path,record);deadline=time.monotonic()+timeout;self._active=True
            received=False
            try:
                self._start(deadline);self._check()
                self._send({'type':'page','nonce':self.nonce,'page':key,'args':args})
                while True:
                    event=self._next(deadline)
                    if event.get('page')!=key:raise ValueError('Original page identity mismatch')
                    if event.get('type')=='wire_ready':
                        self._check()
                        wire=event.get('wire')
                        if event.get('method') not in ('GET','POST') or not isinstance(wire,str) or len(wire)!=32:raise ValueError('Invalid wire identity')
                        record['wire_allow_attempts']+=1;self._save(path,record)
                        self._send({'type':'wire_allow','nonce':self.nonce,'page':key,'wire':wire})
                        continue
                    if event.get('type')!='result':raise ValueError('Unexpected page event')
                    result={k:event.get(k) for k in ('stdout','stderr','returncode')}
                    if (type(result['stdout']) is not str or type(result['stderr']) is not str or type(result['returncode']) is not int
                            or digest(result)!=event.get('digest')):raise ValueError('Original CLI result mismatch')
                    # Do not ACK an ephemeral result. Recovery reads this exact
                    # page rather than issuing another HTTP request.
                    record.update(state='received',result=result,digest=event['digest'],received_at=time.time())
                    self._save(path,record);received=True
                    self._send({'type':'ack','nonce':self.nonce,'page':key,'digest':event['digest']})
                    record['state']='acknowledged';self._save(path,record)
                    if result['returncode']:self.close()
                    return result['stdout'],result['stderr'],result['returncode']
            except BaseException as error:
                if not received:
                    record.update(state='unknown',error_type=type(error).__name__,updated_at=time.time())
                    self._save(path,record)
                self.close()
                record.update(worker_ready=self._ready,exit_code=self._last_exit_code,
                    stderr_bytes=len(self._stderr.encode('utf-8')),stderr_sha256=hashlib.sha256(self._stderr.encode('utf-8')).hexdigest())
                local_unsent=(isinstance(error,EOFError) and self.protocol=='task-bound-read-v1')
                if (not received and (self._guard_failed or local_unsent) and record['wire_allow_attempts']==0 and self._process is None):
                    record.update(state='not_sent',process_exited=True)
                if not received:self._save(path,record)
                if isinstance(error,PageWorkerError):raise
                raise PageWorkerError('CLI_PAGE_UNCONFIRMED','本页读取结果尚未确认，原回执已保留，不会重复请求') from None
            finally:self._active=False

    def close(self):
        with self._process_lock:
            self._closed=True;process=self._process
            if process is None:return
            if process.poll() is None:
                try:
                    if not self._active:
                        self._send({'type':'close','nonce':self.nonce});process.stdin.close()
                        process.wait(timeout=2)
                    else:process.terminate();process.wait(timeout=2)
                except (OSError,ValueError,subprocess.TimeoutExpired):
                    if process.poll() is None:process.kill();process.wait(timeout=2)
            if process.poll() is not None:
                self._last_exit_code=process.returncode
                self._unregister(process);self._process=None
            else:raise PageWorkerError('CLI_WORKER_STOPPING','采集进程尚在退出，保留原工作区占用')
