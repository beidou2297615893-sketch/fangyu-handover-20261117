import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
const source=process.env.FANGYU_TEST_PROJECT||'C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project';
const {render,bind}=await import(pathToFileURL(source+'/work/ui-approved-implementation/ui-preview/pages/acquire.mjs'));
const base=()=>({connection:'connected',user:'fixture',storeId:'gubei',activePlatform:'xiaohongshu',stores:[{id:'gubei',name:'古北店',region:'上海'}],platform:{device:{bound:true,state:'offline'},platforms:[{id:'xiaohongshu',name:'小红书',enabled:true,accountId:'account-one'}],acquisition:{status:'paused',phase:'analyzing',canStart:false,canResume:false,reasonCode:'device_not_ready',message:'工作连接尚未恢复，请点击重新连接'}}});
for(const status of ['offline','stopped','error']){
 const state=base();state.platform.device.state=status;
 const html=render(state);assert.match(html,/data-acquire-reconnect/);assert.match(html,/工作连接未恢复/);
 let clicked,called;const root={querySelector:s=>s==='[data-acquire-reconnect]'?{addEventListener:(type,handler)=>{assert.equal(type,'click');clicked=handler;}}:null,querySelectorAll:()=>[]};
 const dispose=bind(root,{state,actions:{preparePlatform:p=>{called=p;}}});
 clicked();assert.deepEqual(called,{existingOnly:true});dispose();
}
for(const status of ['online','held','revoked','other_owner']){
 const state=base();state.platform.device.state=status;
 assert.ok(!render(state).includes('data-acquire-reconnect'),status);
}
const connecting=base();connecting.deviceReconnecting=true;
assert.ok(!render(connecting).includes('data-acquire-reconnect'));assert.match(render(connecting),/正在恢复工作连接/);
const recovered=base();recovered.platform.device.state='online';recovered.platform.acquisition.canStart=true;
assert.match(render(recovered),/data-acquire-start[^>]*><img/); // start is enabled after actual readiness
const failed=base();failed.deviceReconnectError='网络暂不可用';assert.match(render(failed),/网络暂不可用/);
console.log(JSON.stringify({status:'PASS',retryEntry:true,retryUsesExistingBinding:true,retryHiddenForRevokedHeldAndOnline:true,noFalseReady:true}));
