'use strict';
const fs=require('fs'),path=require('path'),{spawnSync}=require('child_process');
const {normalizePlan,selectTask}=require('./runner.cjs');
const plan=normalizePlan(JSON.parse(fs.readFileSync('../15-store-plan-strict.json','utf8')));
plan.qualification_policy=JSON.parse(fs.readFileSync('../runner-audit-myeaj720/runner-qualification-policy.json','utf8'));
const r=spawnSync('python',['runner_ledger_adapter.py',path.resolve('production-snapshot.sqlite3'),'snapshot'],{input:JSON.stringify(plan),encoding:'utf8',env:{...process.env,PYTHONIOENCODING:'utf-8'}});
if(r.status!==0)throw Error(r.stderr);
const s=JSON.parse(r.stdout);const sampled=plan.stores.map((store,i)=>{
 const a=selectTask(plan,s,i,{});const b=selectTask(plan,s,i,{[store.store_id]:2});
 return {store:store.store_id,video_available:s.videos.some(v=>v.store_id===store.store_id),comment_phase:a?.task.kind,search_phase:b?.task.kind};
});
console.log(JSON.stringify({summary:s.summary,review_counts:s.review_counts,cache_stats:s.cache_stats,sampled},null,2));
