"""Reserve a live-verified target; never sends network requests or browser actions."""
import sys,json,sqlite3,pathlib,hashlib,subprocess,datetime
cid,uid,video,evidence=sys.argv[1:]
p=pathlib.Path(__file__).parent
db=sqlite3.connect('work/shared-acquisition-ledger/shared.sqlite3')
assert not db.execute("select 1 from reservations where platform='douyin' and token like 'douyin-task2-%' and status in ('unknown','reserved') limit 1").fetchone(),'Unresolved outcome blocks further sending'
c=sqlite3.connect('Codex获客工作台/work/reply_receipts.sqlite3')
assert not c.execute('select status from sends where uid=? or cid=?',(uid,cid)).fetchall(),'Existing receipt'
r=next(json.loads(l) for l in open('work/fangyu-text-business-20261029/pool-sop-v3/douyin-replies.jsonl',encoding='utf-8') if json.loads(l).get('comment_id')==cid)
assert hashlib.sha256(r['reply']['draft_text'].encode()).hexdigest()==r['reply_body_sha256']
assert not r['reply']['contact_hold'] and not r.get('needs_currentness_review')
assert '我住' not in r['reply']['draft_text'],'Unverified resident claim'
r['original_reply_body_sha256']=r['reply_body_sha256']
r['original_draft_text']=r['reply']['draft_text']
r['reply']['draft_text']=r['reply']['draft_text'].replace('我介绍有优惠','介绍有优惠').replace('介绍有优惠','我介绍有优惠')
r['reply_body_sha256']=hashlib.sha256(r['reply']['draft_text'].encode()).hexdigest()
r['wording_authorization']='User 2026-11-02: add 我, use 我介绍有优惠; retain sent history'
token='douyin-task2-20261102-'+cid
r.update(customer_uid=uid,video_id=video,attempt_id=token,status='prepared',authorized=True,account_uid='[REDACTED:douyin_sec_uid]',automatic_retry=False)
assert not db.execute("select 1 from reservations where platform='douyin' and (customer=? or comment=?)",(uid,cid)).fetchone(),'Existing shared reservation'
assert not (p/(cid+'.json')).exists(),'Existing attempt file'
(p/(cid+'.json')).write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf-8')
a=p/(cid+'-assessment.json')
a.write_text(json.dumps(dict(source=evidence,intent='rental',store='方隅公寓',match='match',pending='',draft=r['reply']['draft_text'],peer_reply='none'),ensure_ascii=False),encoding='utf-8')
base=[sys.executable,'work/shared-acquisition-ledger/ledger.py','--db','work/shared-acquisition-ledger/shared.sqlite3']
for args in [['identity-bind','douyin',uid,uid,evidence],['lead','douyin',uid,cid],['assess','douyin',uid,cid,str(a)],['review','douyin',uid,cid,'codex',evidence],['reserve','douyin',uid,cid,token]]:
 out=subprocess.check_output(base+args,text=True,encoding='utf-8')
 if args[0]=='reserve':assert json.loads(out)['granted']
print(json.dumps({'reserved':True,'cid':cid,'draft':r['reply']['draft_text']},ensure_ascii=False))
