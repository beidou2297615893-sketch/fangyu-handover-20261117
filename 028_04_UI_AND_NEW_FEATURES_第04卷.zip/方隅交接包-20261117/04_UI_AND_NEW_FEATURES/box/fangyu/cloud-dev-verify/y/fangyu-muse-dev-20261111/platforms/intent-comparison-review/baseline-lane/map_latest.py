"""Map frozen 2026-10-27 release review to the same blinded customer sample.

Read only. Results contain alias sample identifiers and projected status, no
real IDs, comments, reasons or customer data. The human-unconfirmed AI review
is a reference, not a truth set. Current-eligibility differs from past intent.
"""
from pathlib import Path
from collections import Counter, defaultdict
import hashlib
import json
import sys

HERE = Path(__file__).resolve().parent
TASK = HERE.parent
OLD = Path('C:/积木软件工坊/项目/方隅公寓客户版/work/unified-intent-recheck-20261026')
NEW = Path('C:/积木软件工坊/项目/方隅公寓客户版/work/region-followup-20261027')
FILES = {
    'alias': OLD/'alias-index.json', 'old_input': OLD/'model-customers.json',
    'v5_input': NEW/'region/v5/model-customers.json',
    'review': NEW/'MIXED-COMPLETE-REVIEW.json', 'plan': NEW/'import-plan.json',
    'preparation_receipt': NEW/'MIXED-PROJECTION-PREPARATION-RECEIPT.json',
    'import_receipt': NEW/'PRODUCTION-IMPORT-RECEIPT.json',
    'final_receipt': NEW/'FINAL-DELIVERY-VERIFICATION.json',
    'labels': TASK/'blind_agent_labels.json',
}
def load(path):
    raw=path.read_bytes(); return json.loads(raw.decode('utf-8-sig')),hashlib.sha256(raw).hexdigest()
def index(rows,key):
    result={}
    for r in rows:
        if r[key] in result: raise ValueError('Duplicate key in frozen data')
        result[r[key]]=r
    return result
def main():
    loaded={key:load(path) for key,path in FILES.items()}
    data={key:value[0] for key,value in loaded.items()}; sha={key:value[1] for key,value in loaded.items()}
    if data['final_receipt']['status']!='PASS' or data['import_receipt']['status']!='APPLIED_AND_READBACK_VERIFIED': raise ValueError('Not a confirmed delivery receipt')
    if sha['review']!=data['preparation_receipt']['artifacts']['MIXED-COMPLETE-REVIEW.json']: raise ValueError('Review hash mismatch')
    if sha['plan']!=data['preparation_receipt']['artifacts']['import-plan.json'] or sha['plan']!=data['import_receipt']['planSha256']: raise ValueError('Plan not bound to confirmed import')
    if sha['import_receipt']!=data['final_receipt']['receiptSha256']['PRODUCTION-IMPORT-RECEIPT.json']: raise ValueError('Receipt hash mismatch')
    if data['labels']['humanConfirmed'] is not False: raise ValueError('Unexpected reference provenance')
    old=index(data['old_input'],'customerId'); new=index(data['v5_input'],'customerId'); review=index(data['review']['customers'],'customerId')
    derived=index([x['body'] for x in data['plan']['derived'] if x['entity']=='customer_intent_projection_v1'],'customer_id')
    refs=index(data['labels']['labels'],'sample'); expected={x['file']:x['sha256'] for x in data['labels']['source_files']}
    groups={}; seen=set()
    for fn in ('blind_sample.json','blind_challenge.json'):
        sample,sample_hash=load(TASK/fn)
        if sample_hash!=expected[fn] or sample['source_sha256']!=sha['old_input']: raise ValueError('Sample input hash mismatch')
        table=defaultdict(Counter); output=[]; errors=Counter()
        for row in sample['customers']:
            name,alias=row['sample'],row['customerId']
            if name in seen or name not in refs or alias not in data['alias'] or alias not in old: raise ValueError('Identity or labels invalid')
            seen.add(name); mapping=data['alias'][alias]; cid=mapping['customerId']
            orig=old[alias]; current=new.get(cid); result=review.get(cid); persisted=derived.get(cid)
            if not current or not result or not persisted: errors['customer_missing']+=1;continue
            # Input/review digest and projection digest use different contracts.
            # The approved import plan binds the review hash and exact customer.
            if current['contextDigest']!=result['contextDigest']: errors['context_digest_mismatch']+=1;continue
            if result['customer']!=persisted['customer']: errors['review_projection_mismatch']+=1;continue
            old_comments=orig['comments']; blind_comments=row['comments']; current_comments=index(current['comments'],'id')
            if len(old_comments)!=len(blind_comments) or set(mapping['leads'].values())!=set(current_comments): errors['comment_set_mismatch']+=1;continue
            bad=False
            for previous,blind in zip(old_comments,blind_comments):
                if {k:v for k,v in previous.items() if k!='id'}!=blind: bad=True; break
                c=current_comments[mapping['leads'][previous['id']]]
                values={'text':c['text'],'postTitle':c['post']['title'],'postText':c['post']['text'],
                        'parentText':c['parent_text'],'isPostAuthor':c['is_post_author'],
                        'publishedAt':c['published_at'],'capturedAt':c['captured_at']}
                if any((blind.get(k) or '')!=(v or '') for k,v in values.items()): bad=True;break
            if bad: errors['source_content_mismatch']+=1;continue
            c=result['customer']; interest=c['interestStatus']
            if interest=='graded': prediction='positive'
            elif interest=='unrelated': prediction='no_evidence_or_supply'
            elif interest=='uncertain': prediction='abstain'
            else: raise ValueError('Unknown interest status')
            reference=refs[name]['expected_evidence_class']; table[reference][prediction]+=1
            output.append({'sample':name,'reference_class':reference,'interest_prediction':prediction,
                           'interestLevel':c.get('interestLevel'),'demandState':c.get('demandState'),
                           'final_status':c.get('status'),'final_level':c.get('level'),
                           'source_kind':result['provenance'].get('kind')})
        if errors or len(output)!=len(sample['customers']): raise ValueError('sample has identity or context mismatch: '+str(dict(errors)))
        groups[fn]={'count':len(output),'comparison':{k:dict(table.get(k,{})) for k in ('positive','no_evidence','supply','uncertain')},'rows':output,'mismatch_counts':dict(errors)}
    if seen!=set(refs): raise ValueError('Reference sample not complete')
    final={'limitations':['AI blind reference, not user confirmed','Interest is observed evidence, current demand and store eligibility are independent axes','Negative means no observed personal evidence, not proof of no real need','Challenge sample is enriched, not representative'],
           'release_delivery_time_utc':data['final_receipt']['atUtc'],'release_review_as_of':data['review']['reviewContext']['reviewAsOf'],
           'source_sha256':sha,'groups':groups}
    (HERE/'latest-blind-comparison.json').write_text(json.dumps(final,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    for fn,g in groups.items():print(fn,json.dumps({'count':g['count'],'cross_table':g['comparison'],'mismatch_counts':g['mismatch_counts']},ensure_ascii=False))
    return 0
if __name__=='__main__': sys.exit(main())
