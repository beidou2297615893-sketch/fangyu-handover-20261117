import json
import sqlite3
import tempfile
import unittest
from pathlib import Path

from ledger import Ledger, encoded


class LedgerTests(unittest.TestCase):
    def setUp(self):
        self.root = Path(tempfile.mkdtemp(prefix='test-', dir=Path(__file__).parent))
        self.ledger = Ledger(self.root / 'collection.sqlite3')

    def spec(self, request_id='r1', cursor=0, kind='comments', target='123'):
        return dict(request_id=request_id, account_uid='owner-1', connection_id='conn-1',
                    kind=kind, target=target, cursor=cursor, rule_source='synthetic-test')

    def response(self, items=None, cursor=20, more=1):
        return dict(ok=True, connection='conn-1', value=dict(status_code=0,
                    comments=items if items is not None else [dict(cid='9007199254740993', text='原文', user=dict(uid='u1'))],
                    cursor=cursor, has_more=more))

    def test_raw_and_stable_ids_survive_reopen_and_duplicate_page(self):
        result = self.ledger.ingest(self.spec(), self.response())
        self.assertEqual((result['state'], result['added']), ('parsed', 1))
        self.assertEqual(Ledger(self.root / 'collection.sqlite3').summary()['items'], 1)
        duplicate = self.ledger.ingest(self.spec('r2'), self.response())
        self.assertEqual(duplicate['state'], 'duplicate_page')
        self.assertEqual(self.ledger.summary()['items'], 1)
        self.assertEqual(self.ledger.summary()['attempts'], 2)
        self.assertEqual(self.ledger.checkpoint('owner-1', 'comments', '123')['cursor'], 20)

    def test_changed_text_same_id_is_not_new_customer_or_item(self):
        self.ledger.ingest(self.spec(), self.response())
        result = self.ledger.ingest(self.spec('r2', 20), self.response([dict(cid='9007199254740993', text='编辑后')], 40))
        self.assertEqual(result['added'], 0)
        self.assertEqual(self.ledger.summary()['items'], 1)

    def test_bad_cursor_and_missing_id_preserve_raw_without_advancing(self):
        for index, response in enumerate([self.response(cursor=0), self.response([dict(text='无ID')])]):
            spec = dict(self.spec('r'+str(index)), account_uid='synthetic-owner-'+str(index))
            result = self.ledger.ingest(spec, response)
            self.assertEqual(result['state'], 'invalid_response')
            self.assertIsNone(self.ledger.checkpoint(spec['account_uid'], 'comments', '123'))
            self.assertFalse(self.ledger.can_collect(spec['account_uid']))
        self.assertEqual(self.ledger.summary()['attempts'], 2)
        self.assertEqual(self.ledger.summary()['items'], 0)
        self.assertIsNone(self.ledger.checkpoint('owner-1', 'comments', '123'))

    def test_verification_error_timeout_and_wrong_connection_do_not_advance(self):
        cases = [
            (dict(ok=True, connection='conn-1', value=dict(status_code=0, search_nil_info=dict(search_nil_type='verify_check'))), 'verification_required'),
            (dict(ok=True, connection='conn-1', value=dict(status_code=8, status_msg='限流')), 'platform_error'),
            (dict(transport_error='timeout'), 'unknown'),
            (dict(self.response(), connection='other'), 'connection_mismatch'),
        ]
        for index, (response, expected) in enumerate(cases):
            spec = dict(self.spec('r'+str(index)), account_uid='synthetic-owner-'+str(index))
            self.assertEqual(self.ledger.ingest(spec, response)['state'], expected)
            self.assertFalse(self.ledger.can_collect(spec['account_uid']))
        self.assertIsNone(self.ledger.checkpoint('owner-1', 'comments', '123'))

    def test_search_video_is_entry_and_credentials_never_persist(self):
        payload = dict(ok=True, connection='conn-1', value=dict(status_code=0,
                       data=[dict(aweme_info=dict(aweme_id='100', desc='公寓', cookie='SECRET'))], cursor=10, has_more=0))
        result = self.ledger.ingest(self.spec(kind='search', target='古北租房'), payload)
        self.assertEqual((result['state'], result['added']), ('parsed', 1))
        self.assertNotIn(b'SECRET', (self.root / 'collection.sqlite3').read_bytes())
        self.assertEqual(self.ledger.summary()['comments'], 0)

    def test_same_request_id_is_idempotent_but_conflicting_payload_rejected(self):
        self.ledger.ingest(self.spec(), self.response())
        self.ledger.ingest(self.spec(), self.response())
        self.assertEqual(self.ledger.summary()['attempts'], 1)
        with self.assertRaises(ValueError):
            self.ledger.ingest(self.spec(), self.response(cursor=99))

    def test_numeric_id_and_missing_more_are_rejected_without_guessing(self):
        numeric = self.response([dict(cid=9007199254740993, text='unsafe JS numeric ID')])
        missing_more = self.response()
        del missing_more['value']['has_more']
        for index, response in enumerate([numeric, missing_more]):
            spec = dict(self.spec('r'+str(index)), account_uid='synthetic-owner-'+str(index))
            self.assertEqual(self.ledger.ingest(spec, response)['state'], 'invalid_response')
        self.assertEqual(self.ledger.summary()['items'], 0)

    def test_failed_evidence_write_rolls_back_items_and_checkpoint(self):
        with sqlite3.connect(self.ledger.path) as db:
            db.execute("CREATE TRIGGER reject_evidence BEFORE INSERT ON attempts BEGIN SELECT RAISE(ABORT,'synthetic disk failure'); END")
        with self.assertRaises(sqlite3.DatabaseError):
            self.ledger.ingest(self.spec(), self.response())
        self.assertEqual(self.ledger.summary()['items'], 0)
        self.assertIsNone(self.ledger.checkpoint('owner-1', 'comments', '123'))

    def test_stale_and_exhausted_streams_do_not_skip_pages(self):
        self.assertEqual(self.ledger.ingest(self.spec(cursor=20), self.response(cursor=40))['state'], 'stale_cursor')
        self.assertFalse(self.ledger.can_collect('owner-1'))
        self.ledger.resume('owner-1', 'r1', 'synthetic-reviewer', 'corrected local cursor', 'synthetic-test')
        self.ledger.ingest(self.spec('r2'), self.response(cursor=20, more=0))
        self.assertEqual(self.ledger.ingest(self.spec('r3', cursor=20), self.response(cursor=40))['state'], 'stale_cursor')
        self.assertEqual(self.ledger.checkpoint('owner-1', 'comments', '123')['exhausted'], 1)

    def test_new_scan_can_revisit_exhausted_target_and_keeps_both_observations(self):
        first = dict(self.spec(), scan_id='scan-one', store_id='store-a', keyword='古北租房')
        second = dict(first, request_id='r2', scan_id='scan-two')
        self.ledger.ingest(first, self.response(more=0))
        result = self.ledger.ingest(second, self.response(more=0))
        self.assertEqual(result['state'], 'parsed')
        self.assertEqual(result['added'], 0)
        with sqlite3.connect(self.ledger.path) as db:
            self.assertEqual(db.execute('SELECT COUNT(*) FROM observations').fetchone()[0], 2)

    def test_same_comment_across_store_keyword_and_target_has_one_global_entity(self):
        self.ledger.ingest(dict(self.spec(), scan_id='s1', store_id='a', keyword='租房'), self.response(more=0))
        second = dict(self.spec('r2', target='456'), scan_id='s1', store_id='b', keyword='公寓')
        result = self.ledger.ingest(second, self.response(more=0))
        self.assertEqual(result['added'], 0)
        with sqlite3.connect(self.ledger.path) as db:
            self.assertEqual(db.execute('SELECT COUNT(*) FROM entities').fetchone()[0], 1)
            rows = db.execute('SELECT store_id,keyword,target FROM observations ORDER BY request_id').fetchall()
            self.assertEqual(rows, [('a', '租房', '123'), ('b', '公寓', '456')])

    def test_unknown_blocks_other_targets_and_reopen_until_explicit_review(self):
        self.ledger.ingest(self.spec(), dict(transport_error='timeout'))
        reopened = Ledger(self.ledger.path)
        result = reopened.ingest(self.spec('r2', target='456'), self.response(more=0))
        self.assertEqual(result['state'], 'blocked')
        self.assertFalse(reopened.can_collect('owner-1'))
        with self.assertRaises(ValueError):
            reopened.resume('owner-1', 'wrong-request', 'operator', 'reviewed', 'synthetic-test')
        self.assertFalse(reopened.can_collect('owner-1'))
        reopened.resume('owner-1', 'r1', 'operator', 'checked platform and account manually', 'synthetic-test')
        self.assertTrue(Ledger(self.ledger.path).can_collect('owner-1'))
        self.assertEqual(reopened.ingest(self.spec('r3'), self.response(more=0))['state'], 'parsed')
        with sqlite3.connect(self.ledger.path) as db:
            self.assertEqual(db.execute('SELECT state FROM attempts WHERE request_id="r1"').fetchone()[0], 'unknown')
            self.assertEqual(db.execute('SELECT COUNT(*) FROM recovery_events').fetchone()[0], 1)

    def test_failure_to_write_evidence_also_rolls_back_associations_and_halt(self):
        with sqlite3.connect(self.ledger.path) as db:
            db.execute("CREATE TRIGGER reject_evidence BEFORE INSERT ON attempts BEGIN SELECT RAISE(ABORT,'synthetic disk failure'); END")
        with self.assertRaises(sqlite3.DatabaseError):
            self.ledger.ingest(dict(self.spec(), scan_id='s1', store_id='a', keyword='租房'), self.response())
        self.assertEqual(self.ledger.summary()['items'], 0)
        self.assertIn('observations', self.ledger.summary())
        self.assertEqual(self.ledger.summary()['observations'], 0)
        with self.assertRaises(sqlite3.DatabaseError):
            self.ledger.ingest(self.spec(), dict(transport_error='timeout'))
        self.assertTrue(self.ledger.can_collect('owner-1'))

    def test_duplicate_page_blocks_later_work_until_explicit_review(self):
        self.ledger.ingest(self.spec(), self.response())
        result = self.ledger.ingest(self.spec('r2'), self.response())
        self.assertEqual(result['state'], 'duplicate_page')
        self.assertFalse(Ledger(self.ledger.path).can_collect('owner-1'))
        self.assertEqual(self.ledger.ingest(self.spec('r3', target='456'), self.response())['state'], 'blocked')

    def test_failed_manual_recovery_write_keeps_halt_and_original_attempt(self):
        self.ledger.ingest(self.spec(), dict(transport_error='timeout'))
        with sqlite3.connect(self.ledger.path) as db:
            db.execute("CREATE TRIGGER reject_recovery BEFORE INSERT ON recovery_events BEGIN SELECT RAISE(ABORT,'synthetic disk failure'); END")
        with self.assertRaises(sqlite3.DatabaseError):
            self.ledger.resume('owner-1', 'r1', 'synthetic-reviewer', 'reviewed unknown result', 'synthetic-test')
        self.assertFalse(Ledger(self.ledger.path).can_collect('owner-1'))
        self.assertEqual(self.ledger.summary()['states'], {'unknown': 1})

    def test_database_context_releases_connection_after_commit(self):
        with self.ledger._db() as db:
            db.execute('SELECT 1')
        with self.assertRaises(sqlite3.ProgrammingError):
            db.execute('SELECT 1')

    def test_legacy_upgrade_preserves_original_evidence_and_cursor(self):
        # Simulate an untouched v1 isolated database using its documented four tables.
        path = self.root / 'legacy.sqlite3'
        spec, response = self.spec(), self.response(more=0)
        evidence = ('r1', '2026-01-01T00:00:00+00:00', encoded(spec), encoded(response),
                    'original-digest-not-recomputed', 'parsed', 'original-detail', 1)
        with sqlite3.connect(path) as db:
            db.executescript('''
                CREATE TABLE attempts(request_id TEXT PRIMARY KEY,collected_at TEXT,spec TEXT,response TEXT,digest TEXT,state TEXT,detail TEXT,added INTEGER);
                CREATE TABLE items(stable_key TEXT PRIMARY KEY,kind TEXT,source_id TEXT,target TEXT,first_request TEXT,data TEXT);
                CREATE TABLE streams(account_uid TEXT,kind TEXT,target TEXT,cursor INTEGER,exhausted INTEGER,last_request TEXT,PRIMARY KEY(account_uid,kind,target));
                CREATE TABLE pages(account_uid TEXT,kind TEXT,target TEXT,cursor INTEGER,request_id TEXT,PRIMARY KEY(account_uid,kind,target,cursor));
            ''')
            db.execute('INSERT INTO attempts VALUES(?,?,?,?,?,?,?,?)', evidence)
            db.execute('INSERT INTO items VALUES(?,?,?,?,?,?)', ('comment:123:9007199254740993', 'comments', '9007199254740993', '123', 'r1', encoded(response['value']['comments'][0])))
            db.execute("INSERT INTO streams VALUES('owner-1','comments','123',20,1,'r1')")
            db.execute("INSERT INTO pages VALUES('owner-1','comments','123',0,'r1')")
        upgraded = Ledger(path)
        self.assertEqual(upgraded.summary()['items'], 1)
        self.assertEqual(upgraded.summary()['observations'], 1)
        self.assertEqual(upgraded.scan_checkpoint('owner-1', 'comments', '123', 'legacy'),
                         {'cursor': 20, 'exhausted': 1, 'last_request': 'r1'})
        with sqlite3.connect(path) as db:
            self.assertEqual(db.execute('SELECT * FROM attempts').fetchone(), evidence)
        self.assertEqual(Ledger(path).summary()['observations'], 1)

    def test_same_target_for_two_stores_keeps_two_associations_and_first_entity_text(self):
        first = dict(self.spec(), scan_id='s1', store_id='a', keyword='租房')
        second = dict(first, request_id='r2', store_id='b')
        self.ledger.ingest(first, self.response(more=0))
        result = self.ledger.ingest(second, self.response([dict(cid='9007199254740993', text='后续原文')], more=0))
        self.assertEqual((result['state'], result['added']), ('parsed', 0))
        self.assertEqual(self.ledger.summary()['observations'], 2)
        with sqlite3.connect(self.ledger.path) as db:
            original = json.loads(db.execute('SELECT data FROM entities').fetchone()[0])
            self.assertEqual(original['text'], '原文')
            texts = [json.loads(r[0])['text'] for r in db.execute('SELECT data FROM observations ORDER BY request_id')]
            self.assertEqual(texts, ['原文', '后续原文'])


if __name__ == '__main__':
    unittest.main()
