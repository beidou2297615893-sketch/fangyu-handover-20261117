from pathlib import Path
import datetime,hashlib,json,urllib.request,difflib
T=Path(__file__).resolve().parent;O=T/'flow-audit';D=O/'upstream';D.mkdir(parents=True,exist_ok=True)
P=Path('C:/积木软件工坊/项目/方隅公寓客户版')
ACTIVE=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v24/project/work/speed-collection-worker/component/artifacts/platform-cli-guarded/_internal'
def fetch(url):
 req=urllib.request.Request(url,headers={'User-Agent':'Fangyu-workbench-readonly-audit'})
 with urllib.request.urlopen(req,timeout=25) as r:return r.read()
pkg=json.loads(fetch('https://pypi.org/pypi/xiaohongshu-cli/json'))
commit=json.loads(fetch('https://api.github.com/repos/jackwener/xiaohongshu-cli/commits/main'))
sha=commit['sha'];paths=['pyproject.toml','xhs_cli/client.py','xhs_cli/constants.py','xhs_cli/cookies.py','xhs_cli/qr_login.py','xhs_cli/commands/reading.py','xhs_cli/commands/interactions.py']
files=[]
for rel in paths:
 raw=fetch('https://raw.githubusercontent.com/jackwener/xiaohongshu-cli/'+sha+'/'+rel)
 target=D/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
 local=ACTIVE/rel
 row={'path':rel,'upstream_sha256':hashlib.sha256(raw).hexdigest(),'bundled_source_present':local.is_file()}
 if local.is_file():
  old=local.read_bytes();row.update(bundled_sha256=hashlib.sha256(old).hexdigest(),identical=old.replace(b'\r\n',b'\n')==raw.replace(b'\r\n',b'\n'))
  if not row['identical']:
   diff=''.join(difflib.unified_diff(old.decode('utf-8').splitlines(True),raw.decode('utf-8').splitlines(True),fromfile='bundled/'+rel,tofile='upstream/'+rel))
   (D/(rel.replace('/','__')+'.diff')).write_text(diff,encoding='utf-8');row['diff_lines']=len(diff.splitlines())
 files.append(row)
result={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'installed_distribution_version':'0.6.4','pypi_latest':pkg['info']['version'],'pypi_upload':pkg['urls'][0]['upload_time_iso_8601'],'upstream_commit':sha,'upstream_commit_date':commit['commit']['committer']['date'],'upstream_commit_subject':commit['commit']['message'].splitlines()[0],'files':files,'active_runtime_replaced':False,'network_scope':'public upstream metadata and source only'}
(O/'CLI-VERSION-AUDIT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'version':result['pypi_latest'],'commit':sha,'date':result['upstream_commit_date'],'same_files':[r['path'] for r in files if r.get('identical')],'different_files':[r['path'] for r in files if r.get('identical') is False]},ensure_ascii=False))
