'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('fs'),path=require('path');
const {normalizePlan,selectTask,Runner}=require('./runner.cjs');
const plan=normalizePlan({scan_id:'s',account_uid:'a',connection_id:'c',rule_source:'test',stores:Array.from({length:15},(_,i)=>({store_id:`store-${i}`,keywords:[`term-${i}`]}))});
const snapshot={checkpoints:{},videos:plan.stores.map((s,i)=>({kind:'comments',target:String(i+1),store_id:s.store_id,keyword:`term-${i}`,cursor:20,pages:1}))};
test('two comments then one search per store despite first pages on search terms',()=>{
 assert.equal(selectTask(plan,snapshot,0,{}).task.kind,'comments');
 assert.equal(selectTask(plan,snapshot,0,{'store-0':1}).task.kind,'comments');
 assert.equal(selectTask(plan,snapshot,0,{'store-0':2}).task.kind,'search');
});
test('round robin visits all 15 stores with available work',()=>{
 let next=0;const visited=[];
 for(let i=0;i<15;i++){const chosen=selectTask(plan,snapshot,next,{});visited.push(chosen.task.store_id);next=chosen.nextIndex;}
 assert.deepEqual(visited,plan.stores.map(s=>s.store_id));assert.equal(next,0);
});
test('no video falls back to search; exhausted searches fall back to comments',()=>{
 assert.equal(selectTask(plan,{...snapshot,videos:[]},0,{}).task.kind,'search');
 const checks=Object.fromEntries(plan.search_tasks.map(x=>[JSON.stringify([x.kind,x.target,x.store_id,x.keyword]),{cursor:10,exhausted:1,pages:1}]));
 assert.equal(selectTask(plan,{...snapshot,checkpoints:checks},0,{'store-0':2}).task.kind,'comments');
});
test('quota and next store survive restart and replay is idempotent',()=>{
 const dir=fs.mkdtempSync(path.join(__dirname,'schedule-synthetic-'));
 const opts={plan,ledger:{},transport(){},directory:dir,minimum_delay_ms:30000};
 const first=new Runner(opts),spec={request_id:'synthetic-request',kind:'comments',store_id:'store-0',schedule_store_id:'store-0'};
 first.applySchedule(spec);first.save();
 const next=new Runner(opts);assert.equal(next.state.nextIndex,1);assert.equal(next.state.commentStreaks['store-0'],1);
 next.applySchedule(spec);assert.equal(next.state.commentStreaks['store-0'],1);
 next.applySchedule({...spec,request_id:'another'});assert.equal(next.state.commentStreaks['store-0'],2);
 next.applySchedule({...spec,request_id:'search',kind:'search'});assert.equal(next.state.commentStreaks['store-0'],0);
});
test('locally recovered committed request advances quota once',()=>{
 const dir=fs.mkdtempSync(path.join(__dirname,'schedule-recovery-'));
 const runner=new Runner({plan,ledger:{ingest:()=>({state:'parsed',added:1})},transport(){throw Error('not called')},directory:dir,minimum_delay_ms:30000});
 const spec={request_id:'recover-me',kind:'comments',store_id:'store-0',schedule_store_id:'store-0'};
 const record=path.join(dir,'recover.json');fs.writeFileSync(record,JSON.stringify({spec,response:{ok:true}}));
 runner.state.pending={request_id:spec.request_id,record_path:record,phase:'dispatching'};runner.save();
 assert.equal(runner.recoverLocal().state,'local_evidence_reconciled');
 assert.equal(runner.state.commentStreaks['store-0'],1);assert.equal(runner.state.nextIndex,1);
 assert.equal(runner.recoverLocal().state,'nothing_to_recover');assert.equal(runner.state.commentStreaks['store-0'],1);
});
