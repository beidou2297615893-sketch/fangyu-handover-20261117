import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
const code=fs.readFileSync(new URL('verification-observation.js',import.meta.url),'utf8');
const link={innerText:'我',getAttribute:()=>'/user/profile/123456789012345678901234',getBoundingClientRect:()=>({width:10,height:10})};
function observe(text,origin='https://www.xiaohongshu.com'){
 const document={body:{innerText:text},addEventListener(){},querySelectorAll(q){return q==='a[href]'?[link]:[];}};
 return vm.runInNewContext(code,{document,window:{},location:{origin,pathname:'/explore/123456789012345678901234',href:origin+'/'},URL,getComputedStyle:()=>({display:'block',visibility:'visible',opacity:'1'})});
}
assert.equal(observe('请通过验证 为保护账号安全，请使用已登录该账号的小红书APP扫码验证身份').challenged,true);
assert.equal(observe('请通过验证 为保护账号安全，请使用已登录该账号的小红书APP扫码验证身份').logged,true);
assert.equal(observe('欢迎 我的主页').challenged,false);
assert.equal(observe('请通过验证 扫码验证身份').challenged,true);
assert.equal(observe('欢迎','https://example.invalid'),null);
console.log('PASS: actual QR prompt blocks readiness even when profile remains logged in; ordinary page and foreign origin guarded');
