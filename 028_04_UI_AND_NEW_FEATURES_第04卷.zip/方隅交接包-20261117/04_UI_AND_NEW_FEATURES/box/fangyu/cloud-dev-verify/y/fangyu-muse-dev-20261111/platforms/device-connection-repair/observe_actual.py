"""Read-only scoped state; no sessions, credentials, comments or account secrets."""
from pathlib import Path
import sqlite3,json,hashlib,datetime,collections,urllib.request
T=Path(__file__).resolve().parent;P=Path('C:/积木软件工坊/项目/方隅公寓客户版');N=P/'work/ui-native-r57'
read=lambda p:json.loads(p.read_text('utf-8-sig'))
b=read(N/'state/production-workspace.json')
tenant='cloud-'+hashlib.sha256((b['environment_id']+'\n'+b['company_id']).encode()).hexdigest()[:24]
con=sqlite3.connect((Path(b['data_dir'])/'workspace.sqlite3').as_uri()+'?mode=ro',uri=True);con.execute('PRAGMA query_only=ON')
def rows(entity):return [json.loads(r[0]) for r in con.execute('SELECT body FROM records WHERE entity=? AND tenant_id=?',(entity,tenant))]
tasks=sorted([r for r in rows('tasks') if r.get('cloud_owner')==b['owner']],key=lambda r:r.get('created_at',''),reverse=True)
leads=[r for r in rows('leads') if r.get('cloud_owner')==b['owner']]
jobs={r['id']:r for r in rows('ai_jobs')}
active=read(N/'state/active.json')
try:live=json.load(urllib.request.urlopen('http://127.0.0.1:'+str(active['stablePort'])+'/__workbench_status',timeout=3))
except Exception:live={}
value={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'access':'readonly_actual_bound_workspace',
 'installedRelease':read(N/'FROZEN.json')['release_id'],'active':active,'live':live,'leadCount':len(leads),'taskCount':len(tasks),
 'taskStates':dict(collections.Counter(r.get('status') for r in tasks)),
 'recentTasks':[{'id':r['id'],'storeId':r.get('store_id'),'platform':r.get('platform'),'status':r.get('status'),
   'pauseReason':r.get('pause_reason'),'createdAt':r.get('created_at'),'collectorAccountId':r.get('account_id'),
   'commentCount':sum(l.get('task_id')==r['id'] for l in leads),
   'uniqueAuthors':len({l['author_id'] for l in leads if l.get('task_id')==r['id'] and l.get('author_id')}),
   'analyzed':sum(l.get('task_id')==r['id'] and isinstance(l.get('ai_intent'),dict) and l['ai_intent'].get('status') in ('graded','uncertain','unrelated') for l in leads),
   'analysis':{k:jobs.get(r['id'],{}).get(k) for k in ('status','code','pending')}} for r in tasks[:2]]}
con.close()
(T/'ACTUAL-LATEST.json').write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n','utf-8')
with (T/'ACTUAL-SAMPLES.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(value,ensure_ascii=False)+'\n')
print(json.dumps(value,ensure_ascii=False))
