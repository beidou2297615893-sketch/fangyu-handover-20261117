"""Explicit task resume after one verified same-account browser handoff."""
import hashlib
import json
import math
import re
import time
from pathlib import Path
from .xhs_page_process import plain, fingerprint
from .xhs_identity_recovery import read_activity, rows_of, scan_activity, digest
from assistant.browser_session_commit import account_revision
from assistant.xhs_cli_page_worker import LIMIT, digest as result_digest


def captcha_receipt(value):
    if (type(value) is not dict or value.get('state') not in ('received','acknowledged')
            or type(value.get('version')) is not int or value['version'] != 1
            or type(value.get('wire_allow_attempts')) is not int or value['wire_allow_attempts'] < 1
            or value.get('operation') not in ('search','comments','sub-comments','read')):
        return False
    result=value.get('result')
    if (type(result) is not dict or set(result)!={'stdout','stderr','returncode'}
            or type(result.get('returncode')) is not int or result['returncode']!=1
            or type(result.get('stdout')) is not str or type(result.get('stderr')) is not str
            or result_digest(result)!=value.get('digest')):
        return False
    try:payload=json.loads(result['stdout'])
    except (ValueError,TypeError):return False
    error=payload.get('error') if type(payload) is dict else None
    return bool(type(error) is dict and error.get('code')=='verification_required'
        and type(error.get('message')) is str and len(error['message'])<=512
        and re.fullmatch(r'Captcha required: type=[1-9][0-9]{0,5}, uuid=[A-Za-z0-9_-]{8,160}',error['message']))


def verified_pages(directory,task_id,scope,account):
    """Return only proven failed page grants. No network, replay, or state changes."""
    if account.get('status')!='ready' or not re.fullmatch(r'[a-f0-9]{32}',str(account.get('identity_revalidation_generation') or '')):
        return {}
    try:
        raw,_=read_activity(Path(directory)/'platform-activity.jsonl')
        state=scan_activity(raw)
        if state['pending'] or state['unfinished']:return {}
        events=[row for _,_,row in rows_of(raw) if row.get('stage')=='identity_revalidated']
        if not events:return {}
        event=events[-1];generation=account['identity_revalidation_generation']
        if (event.get('revalidation_generation')!=generation
                or event.get('uid_hash')!=digest(str(account.get('platform_uid') or '').encode())
                or event.get('next_auth_generation_hash')!=digest(str(account.get('auth_generation') or '').encode())
                or event.get('identity_evidence_kind')!='single_status_receipt'
                or not 0<=time.time()-event['at']<=600):return {}
        cookie=fingerprint(directory)
        if not cookie:return {}
        folder=plain(Path(directory)/'.workbench-page-receipts'/task_id)
        if not folder.is_dir():return {}
        grants={}
        for path in folder.glob('*.json'):
            if not re.fullmatch(r'[a-f0-9]{64}\.json',path.name):continue
            source=plain(path).read_bytes()
            if len(source)>LIMIT+65536:return {}
            value=json.loads(source)
            if not captcha_receipt(value):continue
            received=value.get('received_at')
            if (value.get('task')!=task_id or value.get('scope')!=scope or value.get('page')!=path.stem
                    or type(received) not in (int,float) or not math.isfinite(received)
                    or not 0<received<=event['at']):return {}
            grants[path.stem]={'receipt_sha256':hashlib.sha256(source).hexdigest(),
                'generation':generation,'credential_sha256':cookie,'account_revision':account_revision(account),
                'expires_at':time.time()+60,'task':task_id,'scope':scope,'args_digest':value.get('args_digest')}
        return grants if len(grants)==1 else {}
    except (OSError,ValueError,TypeError,KeyError):return {}
