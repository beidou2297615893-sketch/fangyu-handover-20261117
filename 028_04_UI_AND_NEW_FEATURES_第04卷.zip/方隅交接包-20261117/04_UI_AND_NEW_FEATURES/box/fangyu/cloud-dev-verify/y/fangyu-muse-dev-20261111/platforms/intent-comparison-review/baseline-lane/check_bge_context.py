"""Inspect BGE prompt token lengths only; do not export any customer text."""
from pathlib import Path
import collections
import importlib.util
import json
import sys

HERE = Path(__file__).resolve().parent
PARENT = HERE.parent.parent
RERANKER = PARENT / 'intent-comparison-paddle'
sys.path.insert(0, str(RERANKER / 'pydeps'))
spec = importlib.util.spec_from_file_location('candidate_for_length_check', RERANKER / 'evaluate.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
tokenizer = module.Tokenizer.from_file(str(RERANKER / 'tokenizer.json'))
output = {}
for name in ('blind_sample.json', 'blind_challenge.json'):
    sample = json.loads((HERE.parent / name).read_text(encoding='utf-8-sig'))
    count = collections.Counter()
    max_length = 0
    for customer in sample['customers']:
        n = max(len(tokenizer.encode(query, module.context(customer)).ids) for query in module.QUERIES.values())
        max_length = max(max_length, n)
        count['customers'] += 1
        count['over_512'] += n > 512
    output[name] = dict(count, max_tokens=max_length)
print(json.dumps(output, ensure_ascii=False))
