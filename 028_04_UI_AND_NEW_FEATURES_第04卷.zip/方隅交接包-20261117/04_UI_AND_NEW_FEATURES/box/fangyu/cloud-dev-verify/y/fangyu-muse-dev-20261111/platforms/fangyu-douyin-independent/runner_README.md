# 方隅抖音持续采集 runner 接入说明

此处是已完成离线安全验证的只读采集组件。作者没有执行平台调用、启动采集、改服务或发送消息；真实接入由主任务单独验证。直接执行 `node runner.cjs` 只显示说明，只有明确传入 `--run` 才可能联网。

## 已验证与未验证

- 离线核对已有原始探针：搜索页10卡、返回游标10、仍有下一页；评论页20条、返回游标20、仍有下一页。评论原文的 `cid`、`aweme_id` 为字符串，20条都有 `ip_label`。没有打印账号、评论、人名或ID。
- 复用本地 MIT 来源 `Yht20927/douyin-cli` 的 Node BridgeClient 和已检查 userscript 的两个 GET 接口/参数。账本复用同目录 `ledger.py`，没有修改其文件。
- 新表达式使用已存在的 GET 路径和参数，经合成页面执行验证；尚未对真实网页执行。它在同一 Bridge call 中先核本人 `sec_uid`，读取一页，再核身份。实际返回 connection 也必须与指定连接一致；不匹配或不明结果不导入项目实体，仅留未知尝试并暂停。
- 原 helper 对空、HTML、网络错误会隐式重试一次，且 JSON reviver 无法挽回已经丢失的整数精度。新表达式直接返回同接口响应文本，不重试；Node 在 JSON.parse 前保留不安全整数词素。原始数据的已知凭据键、敏感URL参数脱敏后保存，不宣称是网络原始字节档案。HTML/无效正文仅保留类型、HTTP状态及摘要，不泄漏正文中的未知凭据。
- 搜索为已有综合接口默认返回，**没有“最新”排序控制**。对当前已返回的作品，只按原始 `create_time`、再按 `statistics.digg_count` 做局部候选优先；缺值保留待核。这不是意向识别，关键词命中也不证明本人求租。评论保留平台原顺序，不声称最新。

## 调度与持久化

15店显式轮换，搜索和已发现作品评论分页交错。每轮优先该店已提交页数较少的流，评论候选在同等进度下优先已返回的较新作品、再比较点赞；不会从店名推断用户归属。已耗尽流不重扫，所有既定词与结果都耗尽时返回 `sources_exhausted`，不会冒称已完成十万目标。

同一关键词跨店只请求一个规范搜索流，全部来源店存于 `store_refs/source_refs`；同一视频跨词/店只采一个规范评论流，其它搜索观察关系可关联追溯。这些是搜索入口关联，不能解释为客户已经归属某店。新增搜索关系会在账本中保留；历史评论可经作品ID连接新发现的搜索来源。

唯一游标来自账本 `scan_streams/scan_pages`，不另造断点库。`runner_ledger_adapter.py` 使用现行 `scan_id/account_uid/kind/target/store_id/keyword` 契约恢复队列；同视频已有评论scope优先，包括真实20→40断点，不能因搜索发现次序改变而回0。`control.json` 只保存公平轮换位置、节奏时间、待确认请求和本地停止状态。

目标只统计**相关来源关系下去重cid**，累计达到 `target_comments`（最高100000）才返回 `target_reached`；这不是独立人数、意向人数或已确认门店客户数。`summary.comments` 是相关目标数，`summary.total_comments` 是保留的全部去重评论。明确误选的18条来源关系不计目标；同cid将来在合格来源再次出现仍可计，不全局封禁该cid。历史人工选定来源通过独立 `--qualification-policy` 请求白名单留证，新请求必须带实际正文守门的 `eligibility.state=eligible`。最后一页请求量不超过相关目标剩余数。`page_committed.added` 仍是原账本新增实体数，与新增加的合格来源关系数有区别。

新评论候选须在实际返回的作品正文中同时找到明确城市/批准的地域锚点和租赁语义；出现已识别的异地或买卖房语义时待核。搜索词本身不作正文证据，只有同城也不能确认特定门店意向。缺内容、缺地域、缺租赁依据的作品完整保留在原始证据与缓存待核，不进入新评论队列；待核计数和规则证据可查。待核候选尚存而已无可执行搜索/评论时返回 `awaiting_candidate_review`，不能宣称全部结果都耗尽。此保守词法守门不等于完整中文地名识别或真实意向审核。

独立 `runner-cache-v5.sqlite3` 只存可重建索引和派生计数，主账本通过 `mode=ro` 附加读取；只有显式 `ingest` 写原账本。首次按已提交attempt的原始response回填页指纹，旧spec没有digest也能识别；后续按rowid只解码新增请求。正文守门仅对新发现或明确修改后的计划计算一次。请求前的复核是单行账号halt查询，不再第二次全量snapshot。10万合成评论/5000页离线样本：首次缓存约0.933秒、暖snapshot约0.021秒，暖次解码0条；这不是实网速度承诺。

每次平台请求前先查 `can_collect`。验证码、非零状态、错连接、空列表却声称有下一页、不推进游标、同一批ID换游标反复返回、未知结果都持久暂停，停止切词/切店/换号重试。未知不写成失败。runner没有发送器或自动解除验证码/限流的方法。

**实网和CLI最短采集页间隔均强制30秒，默认40秒**，不接受5秒参数。这个间隔是两次采集页/Bridge call之间的节奏；同一次call内必要的本人身份前核、采集GET、身份后核共3个GET。若要求这3个GET彼此也隔30秒，应先改现有超时设计，不能把目前实现声称为所有HTTP都隔40秒。离线测试注入假时钟，未降低生产下限。

节奏等待期间不建立pending。每个请求在派发前先落意图与`prepared`标记，再将派发边界持久化为`dispatching`后调用平台；后续落反馈、账本事务与回执。崩溃留下已派发pending时不会重新请求；`--recover-local` 仅把已经落盘的确定反馈幂等送回本地账本。没有反馈的已派发pending仍为未知。`directory/STOP`、Ctrl+C或SIGTERM请求停止；正在进行的一页先保存结果。租约文件防本runner家族跨进程复用同连接或同数据库，陈旧租约只能人工核查；它不能管理其它程序的连接使用。

普通用户STOP可经明确的离线`--resume-local --review <审核JSON>`继续入口解除，命令只记恢复证据，不启动网络。review必须含与plan一致的`account_uid`以及非空`operator/reason/rule_source`。只有普通用户STOP，或同时具备`prepared`控制标记与`prepared_not_dispatched`原始记录、ID/账号一致且没有反馈的请求，才可显式取消未发出意图。`dispatching`未知、验证码、限流及账号halt不能由这个入口解除。恢复保存独立resume回执及STOP文件摘要，原证据保留；再次运行`--run`才实际继续。

评论 `ip_label` 原样保留在评论对象中，是平台公开IP属地标签，与独立账号网络IP/代理不是一回事，不是实际住址。没有配置代理、切换IP或绕过限制。

## 输入和启动前提

主任务提供的 `15-store-plan.json` 已离线通过本组件结构校验：15店、3000个规范搜索词，scan_id 为 `douyin-20261029-initial`。输入字段为 `scan_id/account_uid/connection_id/target_comments/rule_source/plan_source/stores`；每店为 `store_id/name/keywords`。`account_uid` 指实际 `sec_uid`。不能改变已启用目录里的plan内容而偷偷沿用control；显式改变扫描范围须另行核对账本scope与目录。

真实启动前要已有本人身份探针、独占指定连接、原服务严格连接路由预检证据。proof格式：`{"verified":true,"source":"本地可核验的预检证据文件","account_uid":"与计划一致","connection_id":"与计划一致"}`。本组件消费这个预检声明，不把它当作自己已实时验过服务；源代码里开启strict和服务当前运行strict是两个状态。登录/验证由本人正常完成；不改旧服务或借用其它账号。

显式启动示例（所有占位文件应由主任务提供，本文命令未执行）：

```powershell
node runner.cjs --run --plan 15-store-plan.json --bridge-config <已核实Bridge配置路径> --identity-probe identity-probe.json --strict-proof <严格路由核对证据JSON> --database runner-runtime/collection.sqlite3 --directory runner-runtime --minimum-delay-ms 40000
```

相对路径按当前工作目录解析；数据库和运行目录必须位于本独立目录内。可用 `--python` 指向本机已验证Python。日志只输出已提交页状态/类型/增量/请求号，不输出私人明细或登录配置；错误需在本地证据核对，不能直接自动重启。暂停退出码为2；sources_exhausted需按状态判断，不当作目标达成。

受控一页时，在启动命令追加 `--qualification-policy <历史人工已核来源白名单JSON> --max-pages 1`。只在一页确实落反馈、账本和回执后退出为 `bounded_batch_complete`；继续运行需本人明确执行，沿用同目录与同白名单以保持计划摘要一致。

当前白名单：`runner-audit-myeaj720/runner-qualification-policy.json`。它来自主任务明确确认的29条请求快照：127条全部去重评论、109条租房相关来源、18条误选保留不计。副本审计29页指纹全部命中、12评论流（11个20、1个40）、9个耗尽、scope/门店映射冲突均0；不等于此后账本仍停留在该数量。人工新增已核来源后可由主任务显式重新生成白名单，不能把未来无依据来源自动纳入。

离线测试：`node --test runner_test.cjs`（18项），`python runner_cache_test.py`（5项）。`python runner_audit.py` 只读备份当前账本到独立runner-audit目录，并在副本生成缓存、校验旧页/评论scope与源副本哈希及明确人工来源白名单；不改生产账本，不访问平台。合成SQLite与原始反馈只留在 `runner-test-*` / `runner-cache-test-*` 目录，不进入生产账本。新表达式实际可用、真实平台限制形态、本人账号业务效果及十万目标均未由这些测试证明。

文件所在目录：`C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/fangyu-douyin-independent`。
