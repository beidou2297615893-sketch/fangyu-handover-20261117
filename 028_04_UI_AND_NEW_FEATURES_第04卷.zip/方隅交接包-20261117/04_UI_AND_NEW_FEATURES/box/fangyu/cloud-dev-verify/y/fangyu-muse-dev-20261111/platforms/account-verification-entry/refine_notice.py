from pathlib import Path
import json,hashlib
T=Path(__file__).resolve().parent
S=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project')
def replace(rel,old,new):
 p=S/rel;b=p.read_text('utf-8');assert b.count(old)==1,(old,b.count(old));b=b.replace(old,new);p.write_bytes(b.encode('utf-8'))
replace('work/ui-approved-implementation/ui-preview/platform-notice.mjs',"verification_required:[`${name}需要验证码`,'点“去验证”打开此账号的小红书网页。完成验证后保持网页打开，再点“验证完成，继续原任务”。'],","verification_required:[`${name}需要验证码`,id==='xiaohongshu'?'点“去验证”打开此账号的小红书网页。完成验证后保持网页打开，再点“验证完成，继续原任务”。':'请到账号页查看此抖音账号的提示，在平台网页完成验证后再继续。'],")
replace('work/ui-approved-implementation/ui-preview/platform-notice.mjs',"if(job?.taskId!==n.taskId||job?.accountId!==n.accountId||p?.actor?.username!==state.user||p?.actor?.storeId!==state.storeId)","if(job?.taskId!==n.taskId||job?.accountId!==n.accountId||p?.actor?.username!==state.user||p?.actor?.storeId!==state.storeId\n          ||p.acquisition?.taskId!==n.taskId||p.acquisition.taskScope?.accountId!==n.accountId||p.acquisition.taskScope?.platform!==n.id)")
replace('work/ui-native-r57/workbench_backend.py',"            return {'platform': self._platform_state(user, profile), 'job': self._public_platform_job(job)}","            return {'platform': self._platform_state(user, profile,platform='xiaohongshu') if action in ('acquisition_verification_open','acquisition_verification_resume') else self._platform_state(user, profile), 'job': self._public_platform_job(job)}")
changes=json.loads((T/'SOURCE-CHANGES.json').read_text('utf-8'))
for row in changes:row['after']=hashlib.sha256((S/row['path']).read_bytes()).hexdigest()
(T/'SOURCE-CHANGES.json').write_bytes((json.dumps(changes,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
print('REFINED_RESPONSE_BINDING_AND_COPY')
