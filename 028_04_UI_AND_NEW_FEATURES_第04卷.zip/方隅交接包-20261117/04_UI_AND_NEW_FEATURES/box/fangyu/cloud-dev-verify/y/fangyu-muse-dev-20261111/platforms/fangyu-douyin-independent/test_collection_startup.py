"""Startup regression tests. All mutable paths are isolated; no platform calls."""
import json
import io
import os
import tempfile
import unittest
import subprocess
import sqlite3
from pathlib import Path
from unittest.mock import patch
from types import SimpleNamespace
from contextlib import redirect_stdout, closing

import continue_collection as continuation
import new_round
import collection_confirmed_scope as scopes
from scoped_recovery import initialize


class StartupEntry(unittest.TestCase):
    # A regression would reach the bridge or mutate leases despite an intentional hold.
    def test_continue_respects_collection_hold_before_any_recovery(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            stop = root / 'auto-collect.stop'
            stop.write_text('intentional collection hold', encoding='utf-8')
            lease = root / 'runner-lease-database-aaaaaaaaaaaaaaaaaaaaaaaa.json'
            lease.write_text('{"pid":9999999}', encoding='utf-8')
            (root / 'active-runner.json').write_text('{"pid":123}', encoding='utf-8')
            before = {p.name: p.read_bytes() for p in root.iterdir()}
            with patch.object(continuation, 'ROOT', root), patch.object(continuation, 'running', return_value=True), patch.object(continuation, 'gate', side_effect=AssertionError('must stay offline')):
                result = continuation.continue_active()
            self.assertIn('暂停', result)
            self.assertIn('auto-collect.stop', result)
            self.assertEqual({p.name: p.read_bytes() for p in root.iterdir()}, before)

    def test_new_round_respects_hold_without_loading_config_or_checking_browser(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / 'auto-collect.stop').write_text('hold', encoding='utf-8')
            (root / 'active-runner.json').write_text('{"pid":123}', encoding='utf-8')
            out = io.StringIO()
            with redirect_stdout(out), patch.object(new_round, 'ROOT', root), patch.object(new_round, 'running', return_value=True), patch.object(new_round, 'who', side_effect=AssertionError('must stay offline')):
                self.assertEqual(new_round.main(), 1)
            self.assertIn('暂停', out.getvalue())

    def test_continue_archives_dead_lease_before_reaching_ledger_check(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / 'active-runner.json').write_text(json.dumps({'pid': 9999999, 'plan':'plan.json', 'directory':'run'}), encoding='utf-8')
            (root / 'plan.json').write_text('{"account_uid":"synthetic","scan_id":"test"}', encoding='utf-8')
            (root / 'run').mkdir()
            (root / 'run/control.json').write_text('{}', encoding='utf-8')
            lease = root / 'runner-lease-database-aaaaaaaaaaaaaaaaaaaaaaaa.json'
            lease.write_text('{"pid":9999999}', encoding='utf-8')
            with patch.object(continuation, 'ROOT', root), patch.object(continuation, 'running', return_value=False), patch.object(continuation, 'gate', return_value={'halt': {'request_id':'synthetic'}}), patch.object(continuation.subprocess, 'run', side_effect=AssertionError('no platform access expected')):
                result = continuation.continue_active()
            self.assertIn('验证', result)
            self.assertFalse(lease.exists())
            self.assertEqual(len(list((root/'startup-recovery').rglob(lease.name))), 1)

    def test_page_failure_explains_refresh_and_never_retries(self):
        from collection_startup import identity_failure_message
        result = subprocess.CompletedProcess([], 1, b'', b'Pinned collection account could not be verified.')
        self.assertIn('刷新', identity_failure_message(result))
        challenge = subprocess.CompletedProcess([], 1, b'', b'{"challenge_visible":true}')
        self.assertIn('完成验证', identity_failure_message(challenge))


class LeaseRecovery(unittest.TestCase):
    def helpers(self):
        import collection_startup
        return collection_startup

    # A blanket unlink or PID-file mutex would fail the live/unknown/crash cases below.
    def test_dead_lease_is_archived_with_original_bytes(self):
        helpers = self.helpers()
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            lease = root / 'runner-lease-database-aaaaaaaaaaaaaaaaaaaaaaaa.json'
            original = b'{"pid":9999999,"created_at":"2026-11-09T15:09:01.430Z","note":"manual_review_if_stale"}'
            lease.write_bytes(original)
            helpers.recover_stale_leases(root, is_running=lambda pid: False)
            self.assertFalse(lease.exists())
            copies = list((root / 'startup-recovery').rglob(lease.name))
            self.assertEqual(len(copies), 1)
            self.assertEqual(copies[0].read_bytes(), original)

    def test_any_live_owner_blocks_and_leaves_all_leases_untouched(self):
        helpers = self.helpers()
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            dead = root / 'runner-lease-database-aaaaaaaaaaaaaaaaaaaaaaaa.json'
            live = root / 'runner-lease-connection-bbbbbbbbbbbbbbbbbbbbbbbb.json'
            dead.write_text('{"pid":9999999}', encoding='utf-8')
            live.write_text(json.dumps({'pid': os.getpid()}), encoding='utf-8')
            with self.assertRaises(helpers.StartupBlocked):
                helpers.recover_stale_leases(root, is_running=lambda pid: pid == os.getpid())
            self.assertTrue(dead.exists())
            self.assertTrue(live.exists())
            self.assertFalse((root / 'startup-recovery').exists())

    def test_unreadable_owner_blocks_instead_of_guessing_stale(self):
        helpers = self.helpers()
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            lease = root / 'runner-lease-database-aaaaaaaaaaaaaaaaaaaaaaaa.json'
            lease.write_text('truncated', encoding='utf-8')
            with self.assertRaises(helpers.StartupBlocked):
                helpers.recover_stale_leases(root, is_running=lambda pid: False)
            self.assertEqual(lease.read_text(), 'truncated')

    def test_real_process_probe_does_not_mistake_this_process_for_a_dead_owner(self):
        helpers = self.helpers()
        self.assertTrue(helpers.process_running(os.getpid()))
        self.assertFalse(helpers.process_running(-1))

    def test_empty_failed_initialization_can_resume_but_missing_control_with_evidence_cannot(self):
        helpers = self.helpers()
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            active={'status':'paused','startup_uninitialized':True,'needs_first_page_validation':True}
            self.assertEqual(helpers.control_for_start(active,root),{})
            (root/'some-request.json').write_text('{}',encoding='utf-8')
            with self.assertRaises(helpers.StartupBlocked):
                helpers.control_for_start(active,root)

    def test_os_lock_excludes_a_second_starter_and_is_reusable_after_close(self):
        helpers = self.helpers()
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            with helpers.startup_lock(root):
                with self.assertRaises(helpers.StartupBlocked):
                    with helpers.startup_lock(root):
                        self.fail('duplicate starter entered')
            with helpers.startup_lock(root):
                pass

    def test_dead_legacy_continue_lock_is_archived_live_one_is_respected(self):
        helpers = self.helpers()
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            path = root / 'continue-collection.lock'
            path.write_text('9999999', encoding='utf-8')
            helpers.recover_stale_leases(root, is_running=lambda pid: False)
            self.assertFalse(path.exists())
            path.write_text(str(os.getpid()), encoding='utf-8')
            with self.assertRaises(helpers.StartupBlocked):
                helpers.recover_stale_leases(root, is_running=lambda pid: True)
            self.assertTrue(path.exists())


class OrphanedDispatch(unittest.TestCase):
    def fixture(self, root):
        database = root / 'fixture.sqlite3'
        with closing(sqlite3.connect(database)) as db, db:
            db.executescript('CREATE TABLE account_halts(account_uid,request_id,state,detail,halted_at);'
                             'CREATE TABLE attempts(request_id,state,added,spec,response);')
            initialize(db)
        plan = {'account_uid':'a','connection_id':'c','scan_id':'old',
                'stores':[{'store_id':'s','keywords':['uncertain-word','fresh-word']}],
                'excluded_historical_videos':[]}
        record = {'spec':{'request_id':'missing-result','account_uid':'a','connection_id':'c',
                          'scan_id':'old','kind':'comments','target':'123','keyword':'uncertain-word'},
                  'response':None,'state':'prepared_not_dispatched'}
        path = root / 'original.json'
        path.write_text(json.dumps(record),encoding='utf-8')
        control = {'pending':{'phase':'dispatching','request_id':'missing-result','record_path':str(path)}}
        (root/'control.json').write_text(json.dumps(control),encoding='utf-8')
        return database,plan,control

    def test_missing_dispatched_response_is_preserved_and_target_excluded_from_new_scope(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);database,plan,control=self.fixture(root)
            original={p.name:p.read_bytes() for p in (root/'original.json',root/'control.json')}
            updated,evidence=scopes.prepare_orphaned_scope(database,plan,root,control,'new','explicit user click','identity.json')
            self.assertEqual(updated['stores'][0]['keywords'],['fresh-word'])
            self.assertEqual(updated['excluded_historical_videos'],['123'])
            self.assertEqual(updated['scan_id'],'new')
            self.assertEqual(evidence['unknown_request'],'missing-result')
            self.assertFalse(evidence['network_started'])
            self.assertEqual({p.name:p.read_bytes() for p in (root/'original.json',root/'control.json')},original)
            with closing(sqlite3.connect(database)) as db:
                self.assertEqual(db.execute('SELECT COUNT(*) FROM attempts').fetchone()[0],0)

    def test_mismatch_saved_response_or_prepared_only_cannot_use_unknown_skip(self):
        for mutation in ('mismatch','response','prepared'):
            with self.subTest(mutation=mutation),tempfile.TemporaryDirectory() as directory:
                root=Path(directory);database,plan,control=self.fixture(root)
                raw=json.loads((root/'original.json').read_text())
                if mutation=='mismatch':raw['spec']['account_uid']='different'
                if mutation=='response':raw['response']={'ok':True}
                if mutation=='prepared':control['pending']['phase']='prepared'
                (root/'original.json').write_text(json.dumps(raw),encoding='utf-8')
                (root/'control.json').write_text(json.dumps(control),encoding='utf-8')
                with self.assertRaises(ValueError):
                    scopes.prepare_orphaned_scope(database,plan,root,control,'new','explicit click','identity.json')

    def test_new_platform_halt_is_not_cleared_by_missing_response_recovery(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);database,plan,control=self.fixture(root)
            with closing(sqlite3.connect(database)) as db, db:
                db.execute('INSERT INTO collection_halt_events VALUES(?,?,?,?,?)',('a','captcha','verification_required','challenge','now'))
            with self.assertRaises(ValueError):
                scopes.prepare_orphaned_scope(database,plan,root,control,'new','explicit click','identity.json')

    def test_employee_continue_uses_new_scope_after_fresh_identity_without_replaying_orphan(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);database,plan,control=self.fixture(root)
            (root/'plan.json').write_text(json.dumps(plan),encoding='utf-8')
            (root/'active-runner.json').write_text(json.dumps({'pid':9999999,'plan':'plan.json','directory':'.',
                'stdout':'old.log','stderr':'old.err','qualification_policy':'policy.json','minimum_delay_ms':1000}),encoding='utf-8')
            (root/'old.log').write_text('',encoding='utf-8')
            original=(root/'control.json').read_bytes()
            calls=[]
            def run(command, **kwargs):
                calls.append(command)
                if 'collection_identity_check.cjs' in command:
                    return subprocess.CompletedProcess(command,0,b'{"connection_id":"c","account":{"sec_uid":"a"}}',b'')
                self.assertIn('--max-pages',command)
                before_dispatch=json.loads((root/'active-runner.json').read_text(encoding='utf-8'))
                self.assertEqual(before_dispatch['status'],'prepared')
                self.assertIsNone(before_dispatch['pid'])
                self.assertNotEqual(before_dispatch['plan'],'plan.json')
                kwargs['stdout'].write(b'{"state":"bounded_batch_complete"}\n')
                return subprocess.CompletedProcess(command,0)
            child=SimpleNamespace(pid=8888888,poll=lambda:None)
            with patch.object(continuation,'ROOT',root),patch.object(continuation,'DATABASE',database),patch.object(continuation,'running',return_value=False),patch.object(continuation.subprocess,'run',side_effect=run),patch.object(continuation.subprocess,'Popen',return_value=child),patch.object(continuation.time,'sleep'),patch('collection_wait_worker.ensure_worker'):
                message=continuation.continue_active()
            self.assertIn('继续采集',message)
            active=json.loads((root/'active-runner.json').read_text(encoding='utf-8'))
            new_plan=json.loads((root/active['plan']).read_text(encoding='utf-8'))
            self.assertNotEqual(new_plan['scan_id'],'old')
            self.assertEqual(new_plan['stores'][0]['keywords'],['fresh-word'])
            self.assertEqual(new_plan['excluded_historical_videos'],['123'])
            self.assertEqual((root/'control.json').read_bytes(),original)
            self.assertEqual(len(calls),2)

    def test_pause_arriving_during_first_page_prevents_background_launch(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);database,plan,control=self.fixture(root)
            (root/'plan.json').write_text(json.dumps(plan),encoding='utf-8')
            (root/'active-runner.json').write_text(json.dumps({'pid':9999999,'plan':'plan.json','directory':'.',
                'stdout':'old.log','stderr':'old.err','qualification_policy':'policy.json','minimum_delay_ms':1000}),encoding='utf-8')
            def run(command,**kwargs):
                if 'collection_identity_check.cjs' in command:
                    return subprocess.CompletedProcess(command,0,b'{"connection_id":"c","account":{"sec_uid":"a"}}',b'')
                kwargs['stdout'].write(b'{"state":"bounded_batch_complete"}\n')
                (root/'auto-collect.stop').write_text('user pause during first page',encoding='utf-8')
                return subprocess.CompletedProcess(command,0)
            with patch.object(continuation,'ROOT',root),patch.object(continuation,'DATABASE',database),patch.object(continuation,'running',return_value=False),patch.object(continuation.subprocess,'run',side_effect=run),patch.object(continuation.subprocess,'Popen',side_effect=AssertionError('must honor pause before launch')):
                message=continuation.continue_active()
            self.assertIn('暂停',message)
            self.assertTrue((root/'auto-collect.stop').exists())

    def test_proven_never_dispatched_intent_uses_local_cancel_not_unknown_replay(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);database,plan,control=self.fixture(root)
            control['pending']['phase']='prepared'
            (root/'control.json').write_text(json.dumps(control),encoding='utf-8')
            (root/'plan.json').write_text(json.dumps(plan),encoding='utf-8')
            (root/'active-runner.json').write_text(json.dumps({'pid':9999999,'plan':'plan.json','directory':'.',
                'stdout':'old.log','stderr':'old.err','qualification_policy':'policy.json','minimum_delay_ms':1000,
                'identity':'identity.json','strict_proof':'proof.json'}),encoding='utf-8')
            (root/'old.log').write_text('',encoding='utf-8')
            calls=[]
            def run(command,**kwargs):
                calls.append(command)
                if '--resume-local' in command:
                    (root/'control.json').write_text('{"pending":null,"stopped":null}',encoding='utf-8')
                    return subprocess.CompletedProcess(command,0)
                self.assertIn('collection_identity_check.cjs',command)
                return subprocess.CompletedProcess(command,0,b'{}',b'')
            with patch.object(continuation,'ROOT',root),patch.object(continuation,'DATABASE',database),patch.object(continuation,'running',return_value=False),patch.object(continuation.subprocess,'run',side_effect=run),patch.object(continuation.subprocess,'Popen',return_value=SimpleNamespace(pid=8888888,poll=lambda:None)),patch.object(continuation.time,'sleep'),patch('collection_wait_worker.ensure_worker'):
                message=continuation.continue_active()
            self.assertIn('继续采集',message)
            self.assertIn('--resume-local',calls[0])
            self.assertEqual(len(calls),2)


if __name__ == '__main__':
    unittest.main()
