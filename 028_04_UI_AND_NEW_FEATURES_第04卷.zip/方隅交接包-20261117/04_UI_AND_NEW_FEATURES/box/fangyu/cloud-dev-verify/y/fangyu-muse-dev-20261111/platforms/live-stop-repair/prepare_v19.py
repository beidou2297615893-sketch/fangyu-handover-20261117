"""Verify the collection/portrait increment and prepare the original entry."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
T=Path(__file__).resolve().parent;P=Path('C:/积木软件工坊/项目/方隅公寓客户版');F=P/'work/parallel-integration-20261018/final-integration'
C=F/'candidate-unified-v19';PROJECT=C/'project';N=P/'work/ui-native-r57'
def read(p):return json.loads(p.read_text('utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
before=read(F/'candidate-unified-v17/INPUT-SNAPSHOT.json')['files'];after=read(C/'INPUT-SNAPSHOT.json')['files']
changed={k for k in before.keys()|after.keys() if before.get(k)!=after.get(k)}
expected={r['path'] for r in read(T/'SOURCE-CHANGES.json')}
assert changed==expected,changed
pins=read(C/'UNIFIED-PINS.json');assert pins['component_use_policy']=='pending'
for row in pins['files']:
 p=PROJECT/row['path'];assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],row['path']
for k in expected:assert sha(PROJECT/k)==after[k],k
guard=PROJECT/'work/speed-collection-worker/component/artifacts/platform-cli-guarded/guard-manifest.json'
assert guard.read_bytes()==(F/'candidate-unified-v17/project'/guard.relative_to(PROJECT)).read_bytes()
assert (PROJECT/'work/app/company.json').read_bytes()==(F/'candidate-unified-v17/project/work/app/company.json').read_bytes()
staged=read(C/'STAGED.json');release=Path(staged['release']);manifest=read(release/'RELEASE.json')
assert sha(release/'RELEASE.json').upper()==staged['manifest_sha256'].upper()
files={row['path']:row for row in manifest['files']}
backend={r['path']:r['sha256'].lower() for r in read(release/'resources/backend-dependencies.json')['files']}
for k in expected:
 if k.startswith('work/ui-runtime-r55/src/'):assert backend[k.removeprefix('work/ui-runtime-r55/src/')]==after[k]
 elif k.startswith('work/ui-approved-implementation/ui-preview/'):assert sha(release/'web'/k.removeprefix('work/ui-approved-implementation/ui-preview/'))==after[k]
 elif k.startswith('work/ui-native-r57/'):assert sha(release/k.removeprefix('work/ui-native-r57/'))==after[k]
 else:assert sha(release/'resources/platform-runtime'/k.removeprefix('work/shared-backend-integration/'))==after[k]
assert sha(N/'run_workbench.py')=='b4260f7ae65bf03f0ea5c08100444ec895f70397b6b0e97e5985b6d8fec6a262'
assert sha(N/'state/production-workspace.json')=='14cf53964f5d44d123e989805ea741669ab3f05054e730ddcb299a0aac51a9cb'
assert (N/'state/production-workspace.json').read_bytes()==(PROJECT/'work/ui-native-r57/state/production-workspace.json').read_bytes()
assert sha(P/'work/app/company.json')=='bd71d4b7e6b05581702782bda87f0e228c84804decd36a0c4eaf54e0abc6077e'
receipt={'status':'PASS_INCREMENTAL_CLOSURE','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'release':staged['release_id'],'verified_files':len(pins['files']),'closure_sha256':sha(C/'UNIFIED-PINS.json'),
 'changed_files':sorted(changed),'CLI_artifact_and_permissions_unchanged':True,'all_other_sources_unchanged':True,
 'original_company_binding_preserved':True,'old_components_preserved':True,'old_suites_rerun':False,
 'new_real_collection':0,'model_calls':0,'sends':0,'UI_operations':0,'real_throughput_verified':False,
 'real_platform_461_recovery_verified':False,'manual_reopen_pending':True}
write(T/'CANDIDATE-VALIDATION.json',receipt)
write(T/'SOURCE-CHANGES.json',[{'path':k,'before':before.get(k),'after':after[k]} for k in sorted(changed)])
spec=importlib.util.spec_from_file_location('original_pause_avatar_launcher',N/'freeze_ui.py');builder=importlib.util.module_from_spec(spec);spec.loader.exec_module(builder)
body=builder.launcher_source(staged['release_id'],staged['manifest_sha256'],files['ui_native_host.py']['sha256'],files['lifecycle_log.py']['sha256'])
needle="RELEASE = ROOT / 'releases/"+staged['release_id']+"'";assert body.count(needle)==1
body=body.replace(needle,"PROJECT_ROOT = ROOT.parent.parent / 'work/parallel-integration-20261018/final-integration/candidate-unified-v19/project'\nRELEASE = PROJECT_ROOT / 'work/ui-native-r57/releases/"+staged['release_id']+"'\nBINDING_SHA256 = '"+sha(N/'state/production-workspace.json').upper()+"'")
assert body.count('project_root=ROOT.parent.parent')==1;body=body.replace('project_root=ROOT.parent.parent','project_root=PROJECT_ROOT')
needle="        pinned(RELEASE / 'RELEASE.json', MANIFEST_SHA256)";assert body.count(needle)==1
body=body.replace(needle,"        pinned(ROOT / 'state/production-workspace.json', BINDING_SHA256)\n        pinned(PROJECT_ROOT / 'work/ui-native-r57/state/production-workspace.json', BINDING_SHA256)\n"+needle)
compile(body,'run_workbench.py','exec');launcher=N/('run_delegated_candidate.'+staged['release_id']+'.py')
with launcher.open('xb') as stream:stream.write(body.encode('utf-8'))
entry=F/'entry-v19';entry.mkdir(exist_ok=False)
plan={'status':'PREPARED_NOT_INSTALLED','release_id':staged['release_id'],'release':staged['release'],'manifest_sha256':staged['manifest_sha256'],
 'launcher':str(launcher),'launcher_sha256':sha(launcher).upper(),'expected_previous_launcher_sha256':sha(N/'run_workbench.py').upper(),
 'expected_previous_frozen_sha256':sha(N/'FROZEN.json').upper(),'runtime_project_root':str(PROJECT),'installation_state_root':str(N/'state'),
 'workspace_binding_sha256':sha(N/'state/production-workspace.json').upper(),'full_closure_files_verified':len(pins['files']),
 'full_closure_manifest_sha256':sha(C/'UNIFIED-PINS.json').upper(),'validation':str(T/'CANDIDATE-VALIDATION.json'),
 'installed':False,'component_use_policy':'pending','production_cloud_activation':False,'compiled_cli_executed':False,'production_data_migration':False}
write(entry/'CANONICAL-DELEGATION-PREPARED.json',plan)
print(json.dumps({'status':receipt['status'],'release':staged['release_id'],'files':len(pins['files']),'launcher':str(launcher)},ensure_ascii=False))
