const fs=require('fs'),vm=require('vm'),assert=require('assert');
const source=fs.readFileSync('collection_refresh_page.cjs','utf8');
async function test(challenge,count=1,strict=true){
 let scheduled=0,output=[];
 class BridgeClient{
  async status(){return {connections:{'douyin.com':Array.from({length:count},(_,i)=>({alive:true,id:'c'+i}))}};}
  async call(a){
   if(a.connId.startsWith('nonexistent'))return {ok:!strict,error:'指定浏览器连接已离线'};
   const value=vm.runInNewContext(a.expression,{location:{hostname:'www.douyin.com'},document:{querySelectorAll:()=>challenge?[{src:'https://captcha/',getBoundingClientRect:()=>({width:100,height:100})}]:[]},getComputedStyle:()=>({display:'block',visibility:'visible',opacity:'1'}),setTimeout:()=>scheduled++});
   return {ok:true,connection:a.connId,value};
  }
 }
 vm.runInNewContext(source,{require:n=>n==='node:fs'?{readFileSync:()=>'{"bridge":{}}'}:{BridgeClient},process:{argv:['node','script','config']},console:{log:x=>output.push(JSON.parse(x))}});
 for(let i=0;i<10;i++)await Promise.resolve();
 return {scheduled,output};
}
(async()=>{
 let r=await test(true);assert.equal(r.scheduled,0);assert.equal(r.output[0].challenge_visible,true);
 r=await test(false);assert.equal(r.scheduled,1);assert.equal(r.output[0].refreshed,true);
 r=await test(false,2);assert.equal(r.scheduled,0);
 r=await test(false,1,false);assert.equal(r.scheduled,0);
 console.log('4 refresh safety cases PASS');
})().catch(e=>{console.error(e);process.exitCode=1});
