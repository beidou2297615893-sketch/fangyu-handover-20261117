from pathlib import Path
import tkinter as tk,json
from tkinter.scrolledtext import ScrolledText
P=Path(__file__).resolve().parent
w=tk.Tk();w.title('方隅抖音第四任务 — Aliie — 实时进度');w.geometry('950x600')
tk.Label(w,text='第四任务｜Aliie✨（yaoyao1212138）｜共享账本去重后续发',font=('Microsoft YaHei UI',14)).pack(pady=12)
s=tk.StringVar();tk.Label(w,textvariable=s,font=('Microsoft YaHei UI',11)).pack()
tk.Label(w,text='成功以平台回执及账本为准；关闭本窗口只关闭显示，不停止发送。').pack(pady=6)
b=ScrolledText(w,font=('Microsoft YaHei UI',11),wrap='word');b.pack(fill='both',expand=True,padx=12,pady=10)
last=''
def poll():
 global last
 try:
  d=json.loads((P/'batch-runner-status.json').read_text(encoding='utf-8'))
  s.set('本任务成功：'+str(d.get('confirmed_sent','请看日志'))+'条 ｜ 状态：'+{'sent':'运行中，最近一条成功','blocked':'已停止','unknown':'结果未知，已停止','not_sent':'未发送'}.get(d.get('status'),d.get('status',''))+' ｜ '+d.get('reason',''))
  text='本窗口显示第四任务内部序号，成功数不含第一任务。\n'+(P/'runner-stdout.log').read_text(encoding='utf-8',errors='replace')+'\n'+(P/'runner-stderr.log').read_text(encoding='utf-8',errors='replace')
  if text!=last:b.delete('1.0','end');b.insert('end',text);b.see('end');last=text
 except Exception as e:s.set('正在读取进度：'+str(e))
 w.after(1000,poll)
poll();w.mainloop()
