import tempfile, unittest
from pathlib import Path
from ledger import Ledger
from runner_ledger_adapter import Cache, assess

class FreshnessTests(unittest.TestCase):
 def test_freshness_then_body_store_area_and_unknown_retention(self):
  with tempfile.TemporaryDirectory(prefix='fresh-test-',dir=Path(__file__).parent) as td:
   db=Path(td)/'test.sqlite3'; ledger=Ledger(db)
   store={'store_id':'上海古北方隅服务公寓','name':'上海古北方隅服务公寓','city':'上海'}
   plan={'scan_id':'s','account_uid':'owner','stores':[store],'search_tasks':[]}
   start=1792022400 # synthetic timestamps only
   videos=[('100','上海古北租房',start,9999),('101','上海租房',start+604800,1),('102','上海古北租房',start+604800,0),('103','上海租房',None,10000)]
   for i,(vid,body,t,likes) in enumerate(videos):
    spec={'request_id':f'r{i}','scan_id':'s','account_uid':'owner','connection_id':'page','kind':'search','target':f'word{i}','store_id':store['store_id'],'keyword':f'word{i}','cursor':0,'rule_source':'synthetic'}
    response={'ok':True,'connection':'page','value':{'status_code':0,'data':[{'aweme_info':{'aweme_id':vid,'desc':body,'create_time':t,'statistics':{'digg_count':likes}}}],'cursor':10,'has_more':0}}
    self.assertEqual(ledger.ingest(spec,response)['state'],'parsed')
   cache=Cache(db);cache.sync(); snap=cache.snapshot(plan)
   self.assertEqual(snap['videos'][0]['target'],'102') # Same newest week, closer body wins.
   self.assertEqual(snap['review_counts']['eligible'],4) # Missing time/area retained.
   cache.db.execute("UPDATE videos SET published=published+1 WHERE video='101'")
   cache.db.commit()
   self.assertEqual(cache.snapshot(plan)['videos'][0]['target'],'101') # Newest timestamp wins even if it lacks the store-area mention.
   cache.db.close()
 def test_ip_and_comment_time_are_not_inferred_from_video(self):
  s={'store_id':'上海古北方隅服务公寓','name':'上海古北方隅服务公寓'}
  a=assess('上海古北租房',s)
  self.assertEqual(a['body_store_area_mentions'],['古北'])
  self.assertNotIn('ip_label',a);self.assertNotIn('comment_time',a)

if __name__=='__main__':unittest.main()
