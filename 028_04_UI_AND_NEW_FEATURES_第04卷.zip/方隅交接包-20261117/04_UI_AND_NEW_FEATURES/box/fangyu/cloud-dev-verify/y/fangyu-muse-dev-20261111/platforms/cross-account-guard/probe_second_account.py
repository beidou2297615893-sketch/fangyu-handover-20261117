from pathlib import Path
from unittest.mock import patch
import sys,json,traceback
sys.dont_write_bytecode=True
T=Path(__file__).resolve().parent
sys.path.insert(0,str(T.parent/'account-verification-entry/flow-audit'))
from test_delivery import DeliveryTests
f=DeliveryTests(methodName='test_three_item_authorized_batch_completes_in_original_queue_order');f.setUp()
try:
    f.backend.platform_runtime._platform_setup=True
    original=f.backend.platform_runtime.create_account
    def traced(*args,**kwargs):
        try:return original(*args,**kwargs)
        except Exception:
            traceback.print_exc();raise
    f.backend.platform_runtime.create_account=traced
    r=f.backend.dispatch('account_create',{'platform':'xiaohongshu','name':'隔离第二账号'},f.token)
    print('create_keys',list(r),'job',json.dumps(r.get('job'),ensure_ascii=True))
    ident=r['job']['accountId']
    actor=f.backend.core.session(f.token)
    # Public service boundary only; no browser is launched.
    service=f.backend.platform_runtime.service
    with patch.object(service,'start_account_login',return_value={'login_job':{'id':'a'*24,'status':'running','phase':'waiting_browser'}}) as start:
        try:
            result=f.backend.dispatch('account_connect',{'accountId':ident},f.token)
            print('result',json.dumps(result.get('job'),ensure_ascii=True))
        except Exception as error:
            print('connect_error',type(error).__name__,getattr(error,'code',None),str(error))
        print('requested_new_account',start.call_args is not None and start.call_args.args==(ident,))
finally:f.tearDown()
