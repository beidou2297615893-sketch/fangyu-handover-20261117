"""Focused same-UID handoff checks. Synthetic store; no platform or desktop."""
from pathlib import Path
from types import SimpleNamespace
import ast,copy,hashlib,json,os,re,sys,threading,time,unittest
sys.dont_write_bytecode=True
T=Path(__file__).resolve().parent
S=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project')
sys.path.insert(0,str(S/'work/shared-backend-integration/vendor-src'))
sys.path.insert(1,str(S/'work/ui-runtime-r55/src'))
def audit(event,args):
    if event in ('socket.connect','socket.bind','subprocess.Popen','os.system','os.startfile'):
        raise RuntimeError('Test prohibits network/process/desktop')
sys.addaudithook(audit)
from core.store import Store
from core.xhs_verified_resume import verified_pages,failed_page
from core.xhs_page_process import fingerprint,PageWorker,PageWorkerError
from assistant.browser_session_commit import account_revision
from assistant.xhs_cli_page_worker import digest,page_key
import assistant
assistant.__path__.insert(0,str(S/'work/shared-backend-integration/vendor-src/assistant'))
from assistant.xhs_browser_login import validate_browser_candidate
from core.adapters import Adapters

runtime_path=S/'work/shared-backend-integration/platform_runtime.py'
tree=ast.parse(runtime_path.read_text('utf-8'))
body=[copy.deepcopy(n) for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='PlatformRuntimeError']
names={'_verified_scope','_verified_task_pages','_commit_verified_browser','resume_verified_acquisition','_verification_windows'}
methods=[copy.deepcopy(n) for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name in names]
body.append(ast.ClassDef(name='Runtime',bases=[],keywords=[],body=methods,decorator_list=[]))
module=ast.fix_missing_locations(ast.Module(body=body,type_ignores=[]));space={'threading':threading,'time':time,'json':json,'hashlib':hashlib,'re':re}
exec(compile(module,str(runtime_path)+'[selected exact methods]','exec'),space)
Runtime=space['Runtime'];RuntimeErrorType=space['PlatformRuntimeError']

class HandoffTests(unittest.TestCase):
    def setUp(self):
        self.root=T/'session-fixtures'/os.urandom(8).hex();self.store=Store(self.root)
        self.account={'id':'1'*32,'tenant_id':'test-tenant','cloud_owner':'tester','store_id':'test-store',
            'platform':'xiaohongshu','platform_uid':'same-uid','status':'ready','auth_generation':'2'*32}
        self.home=self.root/'accounts'/self.account['tenant_id']/self.account['id']
        self.stage=self.home/'work/browser-login'/('3'*24)
        self.candidate=self.stage/'attempt-000001';self.cookie=self.candidate/'.xiaohongshu-cli/cookies.json'
        self.cookie.parent.mkdir(parents=True)
        self.cookie.write_bytes(json.dumps({'a1':'synthetic-a1','webId':'synthetic-web','web_session':'synthetic-session','saved_at':time.time()}).encode())
        active=self.home/'.xiaohongshu-cli/cookies.json';active.parent.mkdir()
        active.write_bytes(json.dumps({'a1':'old-a1','webId':'old-web','web_session':'old-session','saved_at':time.time()-30}).encode())
        self.activity=self.home/'platform-activity.jsonl'
        self.history=b'{"stage":"started","kind":"comments","request_id":"old-unfinished","method":"GET"}\n'
        self.activity.write_bytes(self.history)
        self.task='4'*32;self.scope='a'*64
        self.args=['comments','https://www.xiaohongshu.com/explore/synthetic','--json'];self.key=page_key(self.args)
        result={'stdout':json.dumps({'ok':False,'schema_version':'1','error':{'code':'verification_required','message':'Captcha required: type=124, uuid=synthetic_fixture_only'}}),'stderr':'','returncode':1}
        self.receipt={'version':1,'task':self.task,'scope':self.scope,'page':self.key,'args_digest':digest(self.args),
            'operation':'comments','state':'acknowledged','received_at':time.time()-10,'wire_allow_attempts':1,'result':result,'digest':digest(result)}
        self.path=self.home/'.workbench-page-receipts'/self.task/(self.key+'.json');self.path.parent.mkdir(parents=True)
        self.path.write_bytes(json.dumps(self.receipt).encode())
        self.context={'task':self.task,'scope':self.scope,'page':self.key,'args_digest':digest(self.args),
            'receipt_sha256':hashlib.sha256(self.path.read_bytes()).hexdigest()}
        self.store.put('accounts',self.account)

    def environment(self,uid='same-uid',mode='success'):
        self.calls={'status':0,'claim':0,'resume':0}
        user={'id':'test-user','tenant_id':'test-tenant','username':'tester','role':'operator','cloud_bound':True}
        self.store.put('users',user)
        def status(platform,args,home,**kwargs):
            self.calls['status']+=1
            self.assertEqual((platform,args),('xiaohongshu',['status','--json']))
            self.assertEqual(Path(kwargs['candidate_home']),self.candidate)
            if mode=='unknown':raise TimeoutError('Synthetic external status unknown')
            if mode=='captcha':return {'ok':False,'error':{'code':'verification_required'}}
            return {'ok':True,'data':{'authenticated':True,'user':{'id':uid,'nickname':'Test User','guest':False}}}
        adapters=SimpleNamespace(execute=status,require_account_safe=Adapters.require_account_safe)
        core=SimpleNamespace(store=self.store,lock=threading.RLock(),adapters=adapters,remote_safety_hold=False,
            deployment_config={},_account_access=lambda *a:None)
        self.job={'id':self.stage.name,'account_id':self.account['id'],'owner_id':user['id'],'tenant_id':user['tenant_id'],
            'kind':'assistant_account_login','purpose':'manual_verification','status':'running','window_open':True,
            'identity_capture_capable':True,'worker_done':threading.Event(),'process':SimpleNamespace(poll=lambda:None)}
        server=SimpleNamespace(core=core,company={},closing=False,account_connections=SimpleNamespace(locks={}),
            job_lock=threading.Lock(),jobs={self.job['id']:self.job})
        def claim(account):
            self.calls['claim']+=1
            if mode=='claim-failed':raise RuntimeError('Synthetic external claim rejected')
        service=SimpleNamespace(server=server,closed=False,state='online',stop_event=threading.Event(),
            _local_user=lambda **k:user,_claim_xhs_account=claim)
        return user,server,service

    def validate(self,uid='same-uid',mode='success'):
        user,server,service=self.environment(uid,mode)
        return validate_browser_candidate(service,user,self.account,self.home,self.stage,self.job,self.job['process'],
            lambda:(1,self.candidate,self.cookie),verified_resume=self.context)[0]

    def runtime(self,uid='same-uid',mode='success'):
        user,server,service=self.environment(uid,mode)
        task={'id':self.task,'account_id':self.account['id'],'platform':'xiaohongshu','status':'paused'}
        runtime=Runtime();runtime.server=server;runtime.service=service;runtime.core=server.core;runtime.data_dir=self.root
        runtime._run_lock=threading.RLock()
        runtime._principal=lambda u:u;runtime._executor=lambda u:service
        runtime._task=lambda u,i:task.copy();runtime._account=lambda u,i:self.store.get('accounts',i)
        runtime._collection_binding=lambda t:'original-policy';runtime._current_comment_policy=lambda t:True
        runtime._verification_idle=lambda *a:None
        runtime._verification_task=lambda u,d:(u,task.copy(),self.store.get('accounts',self.account['id']))
        def resume(u,d):
            self.calls['resume']+=1
            self.assertEqual(set(runtime._verified_task_pages(user,task,self.store.get('accounts',self.account['id']))),{self.key})
            return {'result':{'taskId':self.task,'status':'running'}}
        runtime.resume_acquisition=resume
        self.scope=runtime._verified_scope(user,task,self.account)
        self.receipt['scope']=self.scope;self.path.write_bytes(json.dumps(self.receipt).encode())
        self.context=failed_page(self.home,self.task,self.scope)
        (self.home/'xhs-browser-profile').mkdir()
        def browser_capture():
            deadline=time.monotonic()+3
            while not (self.stage/'capture.flag').exists() and time.monotonic()<deadline:time.sleep(.01)
            if (self.stage/'capture.flag').exists():
                (self.stage/'candidate-000001.ready.json').write_bytes(json.dumps({'version':1,'attempt':1,'candidate':'attempt-000001'}).encode())
        worker=threading.Thread(target=browser_capture,daemon=True);worker.start()
        return runtime,user,worker

    def proof_fixture(self):
        # Independent specification of the server's durable, task-bound proof.
        self.account['browser_verification_receipt']={**self.context,'version':1,'at':time.time(),
            'account_id':self.account['id'],'tenant_id':self.account['tenant_id'],
            'uid_sha256':hashlib.sha256(b'same-uid').hexdigest(),
            'auth_generation':self.account['auth_generation'],'credential_sha256':fingerprint(self.home)}

    def test_old_activity_does_not_veto_current_server_proof(self):
        self.proof_fixture()
        grants=verified_pages(self.home,self.task,self.scope,self.account)
        self.assertEqual(set(grants),{self.key})
        self.assertEqual(self.activity.read_bytes(),self.history)

    def test_real_coordinator_and_commit_publish_bound_proof(self):
        result=self.validate();self.assertEqual(result.state,'completed')
        fresh=self.store.get('accounts',self.account['id']);self.assertNotEqual(fresh['auth_generation'],self.account['auth_generation'])
        self.assertEqual(set(verified_pages(self.home,self.task,self.scope,fresh)),{self.key})
        self.assertEqual(self.activity.read_bytes(),self.history)
        self.assertEqual(self.calls,{'status':1,'claim':1,'resume':0})

    def test_ordinary_login_keeps_original_commit_behavior(self):
        user,server,service=self.environment()
        outcome,_=validate_browser_candidate(service,user,self.account,self.home,self.stage,self.job,self.job['process'],
            lambda:(1,self.candidate,self.cookie))
        self.assertEqual(outcome.state,'completed')
        fresh=self.store.get('accounts',self.account['id'])
        self.assertNotIn('browser_verification_receipt',fresh)
        self.assertFalse(verified_pages(self.home,self.task,self.scope,fresh))
        self.assertEqual(self.activity.read_bytes(),self.history)

    def test_endpoint_captures_owned_window_commits_and_resumes(self):
        runtime,user,worker=self.runtime()
        result=runtime.resume_verified_acquisition(user,{'taskId':self.task});worker.join(1)
        self.assertEqual(result['result']['accountId'],self.account['id'])
        self.assertEqual(self.calls,{'status':1,'claim':1,'resume':1})
        self.assertEqual(self.activity.read_bytes(),self.history)
        self.assertFalse(self.cookie.exists())
        # A lost response reuses proof without status/claim/capture again.
        runtime.resume_verified_acquisition(user,{'taskId':self.task})
        self.assertEqual(self.calls,{'status':1,'claim':1,'resume':2})

    def test_endpoint_rejects_other_uid_and_keeps_original_task(self):
        runtime,user,worker=self.runtime(uid='other-uid');old=self.store.get('accounts',self.account['id'])
        with self.assertRaises(RuntimeErrorType):runtime.resume_verified_acquisition(user,{'taskId':self.task})
        worker.join(1);self.assertEqual(self.store.get('accounts',self.account['id']),old)
        self.assertEqual(self.calls,{'status':1,'claim':0,'resume':0})

    def test_status_unknown_captcha_or_claim_failure_cannot_commit(self):
        for mode in ('unknown','captcha','claim-failed'):
            with self.subTest(mode=mode):
                old=self.store.get('accounts',self.account['id']);result=self.validate(mode=mode)
                self.assertNotEqual(result.state,'completed')
                self.assertEqual(self.store.get('accounts',self.account['id']),old)
                self.assertFalse(verified_pages(self.home,self.task,self.scope,old))

    def test_proof_rejects_changed_identity_generation_cookie_or_scope(self):
        self.assertEqual(self.validate().state,'completed');fresh=self.store.get('accounts',self.account['id'])
        for field,value in [('platform_uid','other'),('auth_generation','f'*32),('tenant_id','other'),('id','other'),('status','disconnected')]:
            altered={**fresh,field:value};self.assertFalse(verified_pages(self.home,self.task,self.scope,altered),field)
        self.assertFalse(verified_pages(self.home,self.task,'b'*64,fresh))
        self.assertFalse(verified_pages(self.home,'5'*32,self.scope,fresh))
        active=self.home/'.xiaohongshu-cli/cookies.json';active.write_bytes(b'changed-credential')
        self.assertFalse(verified_pages(self.home,self.task,self.scope,fresh))

    def test_receipt_change_before_commit_rejects_proof(self):
        self.receipt['state']='unknown';self.path.write_bytes(json.dumps(self.receipt).encode())
        self.assertNotEqual(self.validate().state,'completed')
        self.assertEqual(self.store.get('accounts',self.account['id']),self.account)

    def test_old_proof_cannot_authorize_unknown_or_later_captcha_receipt(self):
        self.proof_fixture()
        self.receipt['state']='unknown';self.receipt['wire_allow_attempts']=1
        self.path.write_bytes(json.dumps(self.receipt).encode())
        self.assertFalse(verified_pages(self.home,self.task,self.scope,self.account))
        self.receipt['state']='acknowledged';self.receipt['verified_retry']={'explicit_resume':True}
        self.path.write_bytes(json.dumps(self.receipt).encode())
        self.assertTrue(failed_page(self.home,self.task,self.scope))
        self.assertFalse(verified_pages(self.home,self.task,self.scope,self.account))

    def test_proof_expiry_multiple_pages_and_pending_commit_reject(self):
        self.proof_fixture();proof=self.account['browser_verification_receipt']
        proof['at']=time.time()-601
        self.assertFalse(verified_pages(self.home,self.task,self.scope,self.account))
        proof['at']=time.time()
        journal=self.home/'.xiaohongshu-cli/.browser-session-commit.json';journal.write_bytes(b'{}')
        self.assertFalse(verified_pages(self.home,self.task,self.scope,self.account));journal.unlink()
        other={**self.receipt,'page':'f'*64,'args_digest':'f'*64}
        self.path.with_name('f'*64+'.json').write_bytes(json.dumps(other).encode())
        self.assertFalse(verified_pages(self.home,self.task,self.scope,self.account))

    def worker(self,grants,mode='success'):
        spec={'argv':[sys.executable],'env':{'HOME':str(self.home)},'cwd':str(T)}
        worker=PageWorker(spec,self.task,self.scope,lambda:None,protocol='task-bound-read-v1',verified_retry=grants)
        calls=[];events=[]
        def start(deadline):
            calls.append('start')
            events.append({'type':'wire_ready','nonce':worker.nonce,'page':self.key,'wire':'7'*32,'method':'GET'})
            if mode=='success':
                result={'stdout':'{"ok":true,"schema_version":"1","data":{"comments":[]}}','stderr':'','returncode':0}
                events.append({'type':'result','nonce':worker.nonce,'page':self.key,**result,'digest':digest(result)})
        def send(packet):
            if packet['type']=='wire_allow':
                current=json.loads(self.path.read_bytes());self.assertEqual(current['wire_allow_attempts'],1)
                self.assertEqual((self.path.parent/current['verified_retry']['archive']).read_bytes(),json.dumps(self.receipt).encode())
                calls.append('allow')
        def receive(deadline):
            if not events:raise TimeoutError('Synthetic unknown result')
            return events.pop(0)
        worker._start=start;worker._send=send;worker._next=receive
        return worker,calls

    def test_new_commit_proof_allows_one_archived_exact_page_retry(self):
        self.assertEqual(self.validate().state,'completed');fresh=self.store.get('accounts',self.account['id'])
        grants=verified_pages(self.home,self.task,self.scope,fresh);worker,calls=self.worker(grants)
        self.assertEqual(worker.request(self.args)[2],0);self.assertEqual(calls,['start','allow'])
        self.assertEqual(worker.request(self.args)[2],0);self.assertEqual(calls,['start','allow'])
        self.assertFalse(verified_pages(self.home,self.task,self.scope,fresh));worker.close()

    def test_unknown_after_retry_is_durable_and_never_replayed(self):
        self.assertEqual(self.validate().state,'completed');fresh=self.store.get('accounts',self.account['id'])
        grants=verified_pages(self.home,self.task,self.scope,fresh);worker,calls=self.worker(grants,'unknown')
        with self.assertRaises(PageWorkerError):worker.request(self.args)
        self.assertEqual(calls,['start','allow']);self.assertEqual(json.loads(self.path.read_bytes())['state'],'unknown')
        again,later=self.worker(grants)
        with self.assertRaises(PageWorkerError):again.request(self.args)
        self.assertEqual(later,[]);self.assertFalse(verified_pages(self.home,self.task,self.scope,fresh))
        worker.close();again.close()

if __name__=='__main__':
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(HandoffTests)
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    report={'status':'PASS' if result.wasSuccessful() else 'FAIL','tests':result.testsRun,
        'failures':len(result.failures),'errors':len(result.errors),'synthetic_only':True,
        'network_process_desktop_operations':0,'production_data_reads_or_writes':0,
        'scope':'real selected endpoint methods, coordinator, SQLite session commit, proof and PageWorker; external status/claim/IPC are synthetic'}
    (T/'SESSION-TESTS.json').write_bytes((json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode())
    raise SystemExit(not result.wasSuccessful())
