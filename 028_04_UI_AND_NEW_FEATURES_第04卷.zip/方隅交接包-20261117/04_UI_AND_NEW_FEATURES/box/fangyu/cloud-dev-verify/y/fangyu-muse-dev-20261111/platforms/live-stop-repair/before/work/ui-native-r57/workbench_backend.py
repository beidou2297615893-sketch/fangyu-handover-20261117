"""Narrow customer login and local preset preferences over the existing core.

The host pins/imports the legacy source before loading this module. Optional
platform assembly reuses the guarded employee runtime without task recovery.
"""
import base64
import binascii
import hashlib
import json
import os
import re
import threading
import time
import unicodedata
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
from urllib.error import HTTPError

from core.engine import Core
from integrations import Integrations, IntegrationError, EmployeeLoginRequired
from assistant.ai_workflow import LocalAIWorkflow
from assistant.intent_rule_management import IntentRuleManagement


COMPANY_ID = 'fangyu-apartment-client'
ENTITY = 'ui_workbench_preferences_v1'
STORE_PREF_ENTITY = 'ui_workbench_store_presets_v2'
TONE_PREF_ENTITY = 'ui_workbench_tone_preferences_v1'
STORE_ID = re.compile(r'[A-Za-z0-9_-]{1,80}\Z')
ACTIONS = frozenset({'bootstrap', 'login', 'logout', 'select_store', 'apply_preset', 'refresh_assessments',
    'tone_preferences_read', 'tone_preferences_save'})
PLATFORM_ACTIONS = frozenset({'platform_snapshot', 'platform_prepare', 'account_create',
    'account_connect', 'account_check', 'account_job', 'account_cancel', 'account_safety',
    'account_review_confirm', 'account_verification_open', 'acquisition_start',
    'acquisition_pause', 'acquisition_resume','account_metadata_read','account_metadata_save'})
CUSTOMER_ACTIONS = frozenset({'customers', 'customer_detail', 'customer_export','customer_handoff_read','customer_handoff_save','customer_memo_export'})
REPLY_ACTIONS = frozenset({'reply_read', 'reply_save', 'reply_review', 'reply_check'})
DELIVERY_ACTIONS=frozenset({'reply_delivery_prepare','reply_delivery_start','reply_delivery_status','reply_delivery_cancel'})
REQUEST_ENTITY = 'ui_workbench_platform_requests_v1'
RULE_BUNDLE_FIELDS = {
    'rule_bundle_status': (), 'rule_bundle_export_chunk': ('revision','index'),
    'rule_bundle_import_begin': ('requestId','expectedRevision','digest','bytes','chunkCount'),
    'rule_bundle_import_chunk': ('uploadId','index','dataBase64'),
    'rule_bundle_import_prepare': ('uploadId',),
    'rule_bundle_import_commit': ('uploadId','previewDigest'),
    'rule_bundle_import_status': ('uploadId',)}
SEARCH_IDS = frozenset({'precise', 'commute'})
INTENT_IDS = frozenset({'standard', 'recent', 'rental-evidence'})
AI_RULE_ACTIONS = frozenset({'ai_readiness_read', 'ai_rules_read', 'ai_local_rules_save', 'ai_rules_export'})


class WorkbenchError(ValueError):
    def __init__(self, code, message, status=400):
        super().__init__(message)
        self.code, self.status = code, status


class _CloudServiceUnavailable(IntegrationError):
    code = 'CLOUD_SERVICE_UNAVAILABLE'
    status = http_status = 503

    def __init__(self):
        super().__init__('企业登录云服务因余额不足暂停，请联系企业管理员恢复服务后手动重试')


def _classify_cloud_failure(error):
    # The pinned integration retains the original failed response as context.
    # Inspect that response once; never probe/retry or publish provider details.
    response = error.__context__
    if not isinstance(response, HTTPError) or response.code != 400:
        return error
    try:
        raw = response.read(8193)
        if len(raw) > 8192:
            return error
        body = json.loads(raw)
        if not isinstance(body, dict):
            return error
        for key in ('error', 'errorMessage'):
            message = body.get(key)
            if (isinstance(message, str) and 'Function is Unavailable' in message
                    and re.search(r'\bAvailableStatus\s*=\s*InsufficientBalance\b', message)):
                return _CloudServiceUnavailable()
    except (OSError, ValueError, TypeError):
        pass
    return error


class _ProfileIntegrations(Integrations):
    """Retain the verified public me projection without a second cloud request."""
    def enter(self, *args, **kwargs):
        try:
            return super().enter(*args, **kwargs)
        except IntegrationError as error:
            raise _classify_cloud_failure(error) from None

    def _cloud(self, deployment_config, user, operation, **data):
        try:
            result = super()._cloud(deployment_config, user, operation, **data)
        except IntegrationError as error:
            failure = _classify_cloud_failure(error)
            if operation == 'me':
                # Legacy verify_identity intentionally returns None for any
                # IntegrationError. Preserve its safe HTTP classification so a
                # temporary outage cannot be mistaken for revoked authority.
                self.last_verification_error = failure
            raise failure from None
        if operation == 'me':
            self.last_verified_profile = deepcopy(result.get('user'))
        return result

class _ReadOnlyDeliveryIntegrations(_ProfileIntegrations):
    """Independent verification lock; never renew or write a DPAPI session.

    Queue validation runs under Core.lock. Reusing the login verifier here would
    invert its Integrations.lock -> Core.lock order. Expiry stops the queue.
    """
    def _refresh_session(self,config,user):
        session=config.get('sessions',{}).get(user['id'],{})
        if not session.get('token') or float(session.get('expires',0))<=time.time():
            error=IntegrationError('企业会话已过期，本批已停止，请重新登录后核对')
            error.http_status=401
            raise error
        return dict(session)


def _digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
        separators=(',', ':'), allow_nan=False).encode('utf-8')).hexdigest()


def _stamp():
    return datetime.now(timezone.utc).isoformat()


def _optional_platform(data):
    if 'platform' not in data:
        return None
    value=data['platform']
    if type(value) is not str or value not in ('xiaohongshu','douyin'):
        raise WorkbenchError('PLATFORM_INVALID','请选择小红书或抖音',400)
    return value


def _deny_cloud(*args, **kwargs):
    raise WorkbenchError('ACTION_NOT_AVAILABLE', '当前批次未接入 AI 或发送', 403)


class WorkbenchBackend:
    def __init__(self, project_root, data_dir=None, company=None, *, core_factory=Core,
                 integrations_factory=_ProfileIntegrations, workflow_factory=LocalAIWorkflow,
                 rules_factory=IntentRuleManagement, platform_factory=None, customer_factory=None,
                 materials_factory=None, rental_factory=None, reply_factory=None, delivery_factory=None, remote_factory=None):
        self.project_root = Path(project_root).resolve()
        if company is None:
            try:
                company = json.loads((self.project_root / 'work/app/company.json').read_text('utf-8-sig'))
            except (OSError, ValueError):
                raise WorkbenchError('CONFIG_UNAVAILABLE', '企业登录配置暂不可读，请联系管理员', 503) from None
        company = deepcopy(company)
        managed = company.get('managedWorkspace') if isinstance(company, dict) else None
        if (not isinstance(company, dict) or company.get('id') != COMPANY_ID
                or company.get('edition') != 'customer' or company.get('personalMode') is not False
                or company.get('authMode') != 'managed' or not isinstance(managed, dict)
                or not managed.get('environment_id') or not managed.get('endpoint')):
            raise WorkbenchError('CONFIG_INVALID', '此入口需要方隅客户企业登录配置', 503)
        self.company = company
        self.data_dir = Path(data_dir).resolve() if data_dir is not None else (
            Path(os.environ.get('LOCALAPPDATA', Path.home() / 'AppData/Local')) /
            (COMPANY_ID + 'Workspace')).resolve()
        self.lock = threading.RLock()
        self.platform_runtime = (platform_factory(project_root=self.project_root,
            data_dir=self.data_dir, company=deepcopy(company)) if platform_factory else None)
        self.core = self.platform_runtime.core if self.platform_runtime else core_factory(self.data_dir,
            self.project_root / 'work/ui-runtime-r55/src/resources', defer_startup_recovery=True)
        self.core.deployment_config = deepcopy(company)
        self.integrations = integrations_factory(self.core)
        self.customer_workbench = (customer_factory(self.core, deepcopy(company), self.project_root)
                                   if customer_factory else None)
        self.reply_workbench = (reply_factory(self.core,self.customer_workbench)
                                if reply_factory and self.customer_workbench else None)
        if reply_factory is None and self.customer_workbench is not None:
            from reply_workbench import ReplyWorkbench
            self.reply_workbench = ReplyWorkbench(self.core,self.customer_workbench)
        self.delivery_integrations=_ReadOnlyDeliveryIntegrations(self.core)
        self.reply_delivery=None
        if self.reply_workbench is not None:
            if delivery_factory is None:
                from reply_delivery import ReplyDelivery
                delivery_factory=ReplyDelivery
            self.reply_delivery=delivery_factory(self.core,self.reply_workbench,self.platform_runtime)
        self.workflow = workflow_factory(self.core, _deny_cloud, company=deepcopy(company))
        self.rules_factory = rules_factory
        if materials_factory is None:
            from store_materials import StoreMaterials
            materials_factory = StoreMaterials
        if rental_factory is None:
            from rental_assessment import RentalAssessmentService
            rental_factory = RentalAssessmentService
        self.materials = materials_factory(self.core)
        self.rental_factory = rental_factory
        if self.customer_workbench is not None:
            self.customer_workbench.rental_reader = self._read_rental_assessment
        if self.platform_runtime is not None:
            self.platform_runtime._rental_after_import = self._assess_imported
        self.central_configs = {}
        self.closed = False
        self.remote_management = remote_factory(self) if remote_factory else None

    def close(self):
        if not self.closed:
            self.closed = True
            if self.platform_runtime is not None:
                self.platform_runtime.close()
            else:
                self.core.adapters.close()

    def media(self,token,data):
        if (not isinstance(data,dict) or set(data)!={'storeId','leadId','kind'}
                or not isinstance(data.get('storeId'),str) or not STORE_ID.fullmatch(data['storeId'])
                or not isinstance(data.get('leadId'),str)
                or not re.fullmatch(r'(?:[0-9a-fA-F]{32}|[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12})',data['leadId'])
                or data.get('kind') not in ('author','post_author','cover')):
            raise WorkbenchError('INVALID_INPUT','图片来源参数无效',400)
        with self.lock:
            if self.closed:raise WorkbenchError('BACKEND_CLOSED','本地服务已关闭',503)
            user,profile=self._identity(token)
            if data['storeId']!=self._selected_store(user,profile):
                raise WorkbenchError('STORE_FORBIDDEN','不能读取其他门店的图片',403)
        return self.customer_workbench.media(user,data['storeId'],data['leadId'],data['kind'])

    def _remembered(self):
        row = self.core.store.get(ENTITY, 'remembered-username')
        return row.get('username', '') if row and row.get('tenant_id') == COMPANY_ID else ''

    def _remember(self, username):
        self.core.store.put(ENTITY, {'id': 'remembered-username', 'tenant_id': COMPANY_ID,
                                    'username': username, 'updated_at': _stamp()})

    def _identity(self, token, *, verification=None):
        integration=verification or self.integrations
        user = self.core.session(token)
        if not user or user.get('cloud_bound') is not True or user.get('role') not in ('operator', 'admin'):
            raise WorkbenchError('AUTH_REQUIRED', '请先使用企业员工账号登录', 401)
        # Every API request refreshes authority; an earlier cached me result
        # cannot authorize a later store selection or local write.
        integration.identity_cache.pop(user['id'], None)
        integration.last_verified_profile = None
        integration.last_verification_error = None
        verified = (integration.verify_identity(user,expected_user=user) if verification is not None
                    else integration.verify_identity(user))
        failure = integration.last_verification_error
        if isinstance(failure, _CloudServiceUnavailable):
            raise WorkbenchError(failure.code, str(failure), failure.status) from None
        if failure is not None and getattr(failure, 'http_status', None) not in (401, 403):
            raise WorkbenchError('AUTH_SERVICE_UNAVAILABLE',
                                 '企业身份服务暂不可用，已保留本机登录，请稍后手动重试', 503)
        if not verified or verified.get('role') not in ('operator', 'admin'):
            raise WorkbenchError('AUTH_REQUIRED', '员工登录已失效，请重新登录', 401)
        profile = integration.last_verified_profile
        if profile is None:  # Allows a factory using the original integration.
            config = integration._read(verified['tenant_id'])
            profile = integration._cloud(config, verified, 'me').get('user')
        if (not isinstance(profile, dict) or profile.get('username') != verified['username']
                or profile.get('role') != verified.get('role') or profile.get('disabled')):
            raise WorkbenchError('AUTH_REQUIRED', '员工身份需重新核对', 401)
        profile = deepcopy(profile)
        rows, directory_notice, central_directory = self._read_store_directory(integration, verified)
        profile['_workbench_stores'] = rows
        profile['_workbench_directory_notice'] = directory_notice
        profile['_central_directory'] = central_directory
        stores = self._stores(profile)
        selected = self._load_selection(verified, stores)['storeId']
        verified = {**verified, '_workbench_store_id':selected}
        profile['_workbench_store_id'] = selected
        return verified, profile

    def _read_store_directory(self, integration, user):
        """The central server scope is the only directory authority, including for operators."""
        try:
            config=integration._read(user['tenant_id'])
            response=integration._cloud(config,user,'store_config_read')
        except IntegrationError:
            return [],'已登录；中央门店目录尚未发布或暂不可读，保留无授权空态',None
        actor=response.get('actor') or {}; scope=response.get('scope') or {}
        rows=response.get('stores')
        valid=(response.get('contract')=='fangyu-workspace-v1' and response.get('company_id')==COMPANY_ID
            and response.get('environment_id')==self.company['managedWorkspace']['environment_id']
            and response.get('schema')=='store-config-v1' and response.get('read_only') is True
            and actor.get('username')==user['username'] and actor.get('role')==user['role']
            and scope.get('type')==('company' if user['role']=='admin' else 'store')
            and isinstance(scope.get('store_ids'),list) and isinstance(rows,list)
            and len({row.get('id') for row in rows if isinstance(row,dict)})==len(rows)
            and all(isinstance(row,dict) and isinstance(row.get('id'),str) and STORE_ID.fullmatch(row['id'])
                and row['id'] in scope['store_ids'] and isinstance(row.get('name'),str) for row in rows)
            and all(isinstance(row.get(key,''),str) and len(row.get(key,''))<=100
                and not any(ord(char)<32 for char in row.get(key,''))
                for row in rows for key in ('city','district'))
            and set(scope['store_ids'])=={row['id'] for row in rows}
            and isinstance(response.get('catalog_revision'),str)
            and isinstance(response.get('catalog_digest'),str) and re.fullmatch('[a-f0-9]{64}',response['catalog_digest']))
        if not valid:return [],'已登录；中央门店授权目录未通过核对',None
        stores=[{'id':row['id'],'name':row['name'],'description':row.get('district') or row.get('city') or '中央门店资料组',
            'region':row.get('district') or row.get('city') or '',
            'city':row.get('city',''),'area':row.get('district',''), 'materialKey':row.get('materialKey'),
            'status':row.get('status'),'configDigest':row.get('config_digest')} for row in rows]
        return stores,('当前账号未授予中央门店' if not stores else ''),response

    def _stores(self, profile):
        return deepcopy(profile.get('_workbench_stores', []))

    def _activate_central_config(self, user, profile, store_id, integration=None):
        if store_id not in {row['id'] for row in self._stores(profile)}:
            raise WorkbenchError('STORE_FORBIDDEN','中央门店授权已变化',403)
        integration=integration or self.integrations
        try:
            response=integration._cloud(integration._read(user['tenant_id']),user,'store_config_read',store_id=store_id)
        except IntegrationError:
            raise WorkbenchError('WORKSPACE_DATA_UNAVAILABLE','已登录；当前门店中央配置暂不可读，保留本机选择但停止业务操作',503) from None
        directory=profile.get('_central_directory') or {};config=response.get('config')
        actor=response.get('actor') or {};scope=response.get('scope') or {}
        if (response.get('contract')!='fangyu-workspace-v1' or response.get('company_id')!=COMPANY_ID
                or response.get('environment_id')!=self.company['managedWorkspace']['environment_id']
                or response.get('schema')!='store-config-v1' or response.get('read_only') is not True
                or actor.get('username')!=user['username'] or actor.get('role')!=user['role']
                or store_id not in scope.get('store_ids',[]) or response.get('store_id')!=store_id
                or response.get('catalog_revision')!=directory.get('catalog_revision')
                or response.get('catalog_digest')!=directory.get('catalog_digest')
                or not isinstance(config,dict) or config.get('store_id')!=store_id
                or response.get('config_digest')!=_digest(config)
                or response.get('config_digest')!=next((row.get('config_digest') for row in directory.get('stores',[]) if row.get('id')==store_id),None)):
            raise WorkbenchError('WORKSPACE_DATA_UNAVAILABLE','中央门店配置或授权版本已变化，请重新加载',503)
        metadata={'revision':response['catalog_revision'],'catalogDigest':response['catalog_digest'],
            'configDigest':response['config_digest'],'sourceVersions':response.get('source_versions')}
        self.materials.use_central_config(config,metadata)
        self.central_configs[store_id]=deepcopy(config)
        return config

    def _store_preference(self, user, store_id, db=None):
        ident=_digest(['store-preset-v2',COMPANY_ID,user['tenant_id'],user['username'],store_id])
        if db is None:row=self.core.store.get(STORE_PREF_ENTITY,ident)
        else:
            found=db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
                (STORE_PREF_ENTITY,ident,user['tenant_id'])).fetchone()
            row=json.loads(found['body']) if found else None
        if row and (row.get('storeId')!=store_id or row.get('owner')!=user['username'] or row.get('tenant_id')!=user['tenant_id']):
            raise WorkbenchError('PREFERENCE_SCOPE_INVALID','门店偏好归属未通过核对',409)
        return ident,row

    def _preference_id(self, user):
        return _digest(['workbench-preset-v1', COMPANY_ID, user['tenant_id'], user['username']])

    def _load_selection(self, user, stores, db=None):
        ident = self._preference_id(user)
        if db is None:
            row = self.core.store.get(ENTITY, ident)
        else:
            found = db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
                (ENTITY, ident, user['tenant_id'])).fetchone()
            row = json.loads(found['body']) if found else None
        if row and (row.get('owner') != user['username'] or row.get('tenant_id') != user['tenant_id']
                    or row.get('company_id') != COMPANY_ID):
            raise WorkbenchError('PREFERENCE_SCOPE_INVALID', '门店预设归属无法核对', 409)
        revision = row.get('revision', 0) if row else 0
        if type(revision) is not int or revision < 0:
            raise WorkbenchError('PREFERENCE_INVALID', '门店预设版本无法核对', 409)
        allowed = {store['id'] for store in stores}
        selection = {'storeId': stores[0]['id'] if stores and user.get('role') == 'operator' else '', 'searchPresetId': 'precise',
                     'intentPresetId': 'standard', 'revision': revision, 'applied': None, 'savedAt': None}
        if row and row.get('storeId') in allowed:
            if row.get('searchPresetId') not in SEARCH_IDS or row.get('intentPresetId') not in INTENT_IDS:
                raise WorkbenchError('PREFERENCE_INVALID', '门店预设方案无法核对', 409)
            for key in selection:
                selection[key] = deepcopy(row.get(key, selection[key]))
        if selection['storeId']:
            _, per_store=self._store_preference(user,selection['storeId'],db)
            if per_store:
                for key in ('searchPresetId','intentPresetId','applied','savedAt'):
                    selection[key]=deepcopy(per_store.get(key,selection[key]))
            else:
                selection.update(searchPresetId='precise',intentPresetId='standard',applied=None,savedAt=None)
        return selection

    def _catalog(self, user=None, store_id=None, material_selection=None):
        if user:
            if not store_id:return {'search':[],'intent':[]}
            if (getattr(self.materials,'central',None) or {}).get('storeId')!=store_id:
                raise WorkbenchError('WORKSPACE_DATA_UNAVAILABLE','请先加载当前门店中央配置',503)
            chosen=material_selection if material_selection is not None else self.materials.read_selection(user,store_id)
            search=[{'id':'precise','name':'精准获客','keywords':[]}, {'id':'commute','name':'通勤拓展','keywords':[]}]
            self._bind_material_search(search,chosen,store_id)
            for item in search:
                item['excludeTerms']=deepcopy((self.central_configs[store_id].get('runtimeSearch') or {}).get('excludeTerms',[]))
            rule=self._assessment_policy(store_id)
            enabled=rule['supported'] and rule.get('enabled') is True
            reference={**deepcopy(self.materials.central),'source':'central_store_config','runtimeAssessment':deepcopy(rule)}
            intent=[{'id':'standard','name':'标准意向','description':'综合显示当前求租与预算证据，历史评级保留','policyReference':reference,'assessmentEnabled':enabled},
                {'id':'recent','name':'优先近期入住','description':'优先显示近期入住，基础判断仍使用中央已支持执行契约','policyReference':reference,'assessmentEnabled':enabled},
                {'id':'rental-evidence','name':'租房与预算','description':('初始规则需人工校准，预算与收入独立判断；门店价格待核。' if enabled else '执行契约未支持，需要升级判断引擎。'),
                    'policyReference':reference,'assessmentEnabled':enabled,'runtimeAssessment':deepcopy(rule)}]
            return {'search':search,'intent':intent}
        return {'search': [], 'intent': []}

    @staticmethod
    def _bind_material_search(search, chosen, store_id):
        """Pure projection, safe inside the material/preferences transaction."""
        reference = {'id': chosen['materialKey'], 'revision': chosen['revision'],
            'digest': chosen['catalogDigest'], 'version': chosen['materialVersion'],
            'storeId': store_id, 'bindingConfirmed': chosen['currentBindingConfirmed'],
            'profileDigest':chosen.get('profileDigest')}
        for item in search:
            preset = chosen['searchPresets'][item['id']]
            item.update(keywords=list(preset['keywords']), source='confirmed_store_materials',
                libraryReference=deepcopy(reference), sourceBindings=deepcopy(preset['sourceBindings']),
                templateSupplement=[], materialName=chosen['source_material_name'],
                needsReapply=chosen['needsReapply'],automaticProfile=chosen.get('automaticProfile',False),
                profileDigest=chosen.get('profileDigest'),totalEligible=len(preset['keywords']),runLimit=100)

    def _current_preset(self, catalog, selection, applied_at):
        """Project validated current store inputs; never execute a stored old copy.

        The employee's chosen search/intent IDs remain unchanged. This is a
        local read projection, not a cloud edit, material rebinding or an
        implicit start. Admission and request reservation still follow it.
        """
        search = next((row for row in catalog['search'] if row['id'] == selection['searchPresetId']), None)
        intent = next((row for row in catalog['intent'] if row['id'] == selection['intentPresetId']), None)
        if search is None or intent is None:
            raise WorkbenchError('WORKSPACE_DATA_UNAVAILABLE', '正在更新门店配置，请稍后开始', 503)
        if not search['keywords'] or (len(search['keywords']) > 100 and not search.get('automaticProfile')):
            raise WorkbenchError('KEYWORDS_REQUIRED', '这家门店暂没有可用的搜索词，门店配置完成后即可开始', 409)
        reference = deepcopy(search.get('libraryReference') or {})
        return {'selectedKeywords': list(search['keywords']), 'keywordSource': search['source'],
            'excludeTerms':deepcopy(search.get('excludeTerms',[])),
            'libraryReference': reference, 'templateSupplement': deepcopy(search.get('templateSupplement', [])),
            'policyReference': deepcopy(intent['policyReference']), 'intentPreference': intent['id'],
            'appliedAt': applied_at, 'startsCollection': False, 'changesIntentPolicy': False,
            'sourceBindings': deepcopy(search.get('sourceBindings', [])),
            'rentalAssessmentEnabled': intent.get('assessmentEnabled') is True,
            'profileDigest': search.get('profileDigest'), 'automaticProfile': search.get('automaticProfile', False),
            'materialKey': reference.get('id') if search['source'] == 'confirmed_store_materials' else None,
            'centralVersion': deepcopy(self.materials.central)}

    def _bootstrap(self, token='', *, identity=None):
        user, profile, notice = None, None, ''
        if identity is not None:
            user, profile = identity
        elif token:
            try:
                user, profile = self._identity(token)
            except WorkbenchError as error:
                if error.code in ('AUTH_SERVICE_UNAVAILABLE', 'CLOUD_SERVICE_UNAVAILABLE'):
                    raise
                notice = '登录已失效或企业身份暂未确认，请重新登录'
        stores = self._stores(profile) if profile else []
        try:
            selection = self._load_selection(user, stores) if user else {
                'storeId': '', 'searchPresetId': 'precise', 'intentPresetId': 'standard',
                'revision': 0, 'applied': None, 'savedAt': None}
            user = {**user, '_workbench_store_id':selection['storeId']} if user else None
            if user and selection['storeId']:
                self._activate_central_config(user,profile,selection['storeId'])
                applied=selection.get('applied')
                if applied and applied.get('centralVersion')!=self.materials.central:
                    selection['applied']=None
            catalog = self._catalog(user, selection['storeId'])
            materials = self.materials.catalog(user, stores, selection) if user and selection['storeId'] else None
            if materials is not None:
                # The desktop host injects the hash-verified rental factory
                # under its frozen module name; never import a second copy.
                overview_reader = getattr(self.rental_factory, 'rule_overview', None)
                materials['localAssessmentOverview'] = (overview_reader() if callable(overview_reader)
                    else {'source': 'unavailable'})
                # Use the existing public read: private criteria stay behind
                # its manager check; never serialize SERVER ONLY snapshots.
                try:
                    saved_rules = self.rules_factory(self.core,user['tenant_id'],user['username'],self.company).execute('intent_rules_get',{},user)
                    summary = saved_rules.get('summary') or {}
                    overview = {'source':'local_evidence_policy','revision':summary.get('revision'),
                        'digest':summary.get('digest'),'can_manage':summary.get('can_manage') is True,
                        'providerCriteriaSource':'server','providerPromptAvailable':False}
                    if overview['can_manage'] and isinstance(saved_rules.get('policy'),dict):
                        overview['criteria']=deepcopy(saved_rules['policy'].get('criteria',{}))
                    materials['intentPolicyOverview']=overview
                except (ValueError,OSError):
                    materials['intentPolicyOverview']={'source':'unavailable','providerPromptAvailable':False}
        except (OSError, ValueError, KeyError, TypeError) as error:
            if user is None or getattr(error, 'status', None) in (401, 403):
                raise
            # Authentication has already succeeded. Unreadable business data
            # cannot revoke it, or be replaced by writable default preferences.
            message = '已登录；门店资料暂未加载，请重新加载后再应用预设或开始采集'
            return {'session': {'user': {'username': user['username'], 'role': user['role']}},
                'rememberedUsername': self._remembered(), 'stores': stores, 'selection': None,
                'catalog': {'search': [], 'intent': []}, 'materials': None,
                'capabilities': {'presets': False, 'platforms': self.platform_runtime is not None,
                    'customers': self.customer_workbench is not None, 'materials': False,
                    'rentalAssessment': False, 'reason': message},
                'workspaceError': {'code': 'WORKSPACE_DATA_UNAVAILABLE', 'message': message},
                'notice': message}
        result = {'session': {'user': {'username': user['username'], 'role': user['role']}} if user else None,
                  'rememberedUsername': self._remembered(), 'stores': stores,
                  'selection': selection, 'catalog': catalog,
                  'materials': materials,
                  'capabilities': {'presets': bool(user and selection['storeId']),
                      'platforms': self.platform_runtime is not None,
                      'customers': self.customer_workbench is not None, 'materials': bool(user and selection['storeId']),
                      'rentalAssessment': bool(user and selection['storeId']),
                      'reason': '' if user and selection['storeId'] else ('请先明确选择云端已绑定门店分组' if stores else '云端暂无已绑定门店分组，请在原管理后台核对成员门店') if user else '请先登录'},
                  'notice': notice or (profile or {}).get('_workbench_directory_notice','')}
        return result

    def _selected_store(self, user, profile):
        selected = self._load_selection(user, self._stores(profile))['storeId']
        if not selected:
            raise WorkbenchError('STORE_REQUIRED', '请先明确选择云端已绑定门店分组', 403)
        self._activate_central_config(user,profile,selected)
        return selected

    @staticmethod
    def _tone_values_valid(data, *, saved=False):
        def line(value, maximum, required=False):
            return (isinstance(value,str) and len(value)<=maximum and (not required or bool(value.strip()))
                and not any(unicodedata.category(char) in ('Cc','Cf','Cs','Zl','Zp') for char in value))
        templates=data.get('templates',{'employee':'','customer':''})
        if (not isinstance(templates,dict) or set(templates)!={'employee','customer'}
                or any(not isinstance(v,str) or len(v)>1000 or any(unicodedata.category(c) in ('Cf','Cs') or ord(c)<32 and c not in '\n\t\r' for c in v) for v in templates.values())):return False
        focus=data.get('focus')
        return (line(data.get('identity'),80,required=saved) and line(data.get('salutation'),20)
            and data.get('tone') in ('friendly','concise','patient') and isinstance(focus,list)
            and all(isinstance(item,str) and item in ('budget','moveIn','housing') for item in focus)
            and len(focus)==len(set(focus)))

    def _tone_preferences(self, user, profile, data, token, *, save):
        fields={'storeId','expectedRevision','identity','tone','salutation','focus'} if save else {'storeId'}
        if (set(data)-{'templates'}!=fields or not isinstance(data.get('storeId'),str)
                or not STORE_ID.fullmatch(data['storeId'])
                or save and (type(data.get('expectedRevision')) is not int or data['expectedRevision']<0
                    or not self._tone_values_valid(data,saved=True))):
            raise WorkbenchError('INPUT_INVALID','IP口吻参数格式无效，请核对身份、称呼和关注项')
        if save and (user.get('role')!='admin' or profile.get('role')!='admin'):
            raise WorkbenchError('ADMIN_REQUIRED','只有当前企业管理员可以保存IP口吻',403)
        store_id=self._selected_store(user,profile)
        if data['storeId']!=store_id:
            raise WorkbenchError('STORE_FORBIDDEN','当前门店已变化，请重新读取IP口吻',403)
        ident=_digest(['tone-preferences-v1',COMPANY_ID,user['tenant_id'],store_id])
        with self.core.lock,self.core.store.connect() as db:
            db.execute('BEGIN IMMEDIATE' if save else 'BEGIN')
            session=db.execute('SELECT user_id FROM sessions WHERE token=? AND expires>?',
                (hashlib.sha256(token.encode()).hexdigest(),time.time())).fetchone()
            actor=db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
                ('users',user['id'],user['tenant_id'])).fetchone()
            actor=json.loads(actor['body']) if actor else {}
            if (self.closed or not session or session['user_id']!=user['id'] or actor.get('disabled')
                    or actor.get('cloud_bound') is not True or any(actor.get(key)!=user.get(key)
                        for key in ('id','tenant_id','username','role'))):
                raise WorkbenchError('AUTH_REQUIRED','员工会话或权限已变化，请重新登录',401)
            if self._load_selection(user,self._stores(profile),db)['storeId']!=store_id:
                raise WorkbenchError('STORE_FORBIDDEN','当前门店已变化，请重新读取IP口吻',403)
            found=db.execute('SELECT body FROM records WHERE entity=? AND id=?',(TONE_PREF_ENTITY,ident)).fetchone()
            try:row=json.loads(found['body']) if found else None
            except (TypeError,ValueError):
                raise WorkbenchError('PREFERENCE_INVALID','IP口吻记录格式无法核对',409) from None
            if found and (not isinstance(row,dict) or row.get('tenant_id')!=user['tenant_id'] or row.get('company_id')!=COMPANY_ID
                    or row.get('storeId')!=store_id or row.get('id')!=ident
                    or type(row.get('revision')) is not int or row['revision']<1
                    or not self._tone_values_valid(row,saved=True)):
                raise WorkbenchError('PREFERENCE_INVALID','IP口吻记录归属或格式无法核对',409)
            value={key:deepcopy(row[key]) for key in ('revision','identity','tone','salutation','focus')} if row else {
                'revision':0,'identity':'','tone':'friendly','salutation':'你好','focus':['budget','moveIn','housing']}
            value['templates']=deepcopy((row or {}).get('templates',{'employee':'','customer':''}))
            if save:
                if data['expectedRevision']!=value['revision']:
                    raise WorkbenchError('TONE_REVISION_CONFLICT','IP口吻已在其他窗口更新，请重新读取',409)
                previous_templates=deepcopy(value['templates'])
                value={key:deepcopy(data[key]) for key in ('identity','tone','salutation','focus')}
                value['templates']=deepcopy(data.get('templates',previous_templates))
                value['identity']=value['identity'].strip()
                value['salutation']=value['salutation'].strip()
                value['revision']=(row['revision'] if row else 0)+1
                record={**value,'id':ident,'tenant_id':user['tenant_id'],'company_id':COMPANY_ID,
                    'storeId':store_id,'updatedBy':user['username'],'updatedAt':_stamp()}
                db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',
                    (TONE_PREF_ENTITY,ident,user['tenant_id'],json.dumps(record,ensure_ascii=False,allow_nan=False)))
            return {'preferences':{'actor':{'username':user['username'],'storeId':store_id},**value}}

    def _save_selection(self, user, stores, data, *, apply):
        if not stores or data.get('storeId') not in {row['id'] for row in stores}:
            raise WorkbenchError('STORE_FORBIDDEN', '不能使用未分配给当前员工的门店', 403)
        if apply and data.get('storeId') != self._load_selection(user, stores)['storeId']:
            raise WorkbenchError('STORE_FORBIDDEN', '请先切换当前门店再应用预设', 403)
        if apply and (data.get('searchPresetId') not in SEARCH_IDS or data.get('intentPresetId') not in INTENT_IDS):
            raise WorkbenchError('PRESET_INVALID', '请选择有效的搜索和意向预设')
        if 'expectedRevision' in data and (type(data['expectedRevision']) is not int or data['expectedRevision'] < 0):
            raise WorkbenchError('REVISION_INVALID', '预设版本格式无效')
        if apply and 'expectedRevision' not in data:
            raise WorkbenchError('REVISION_REQUIRED', '应用预设前需要当前版本')
        # The legacy policy read owns its own BEGIN IMMEDIATE. Complete it
        # before acquiring the material/preferences transaction; only pure
        # projections and same-connection writes are allowed after this point.
        catalog = self._catalog(user, data['storeId']) if apply else None
        if apply and data.get('intentPresetId')=='rental-evidence' and not next(row for row in catalog['intent'] if row['id']=='rental-evidence')['assessmentEnabled']:
            raise WorkbenchError('CENTRAL_RULE_DRAFT','中央租房与预算规则仍为草稿，尚未启用',409)
        with self.core.lock, self.core.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            current = self._load_selection(user, stores, db)
            expected = data.get('expectedRevision', current['revision'])
            if expected != current['revision']:
                raise WorkbenchError('PRESET_REVISION_CONFLICT', '预设已在其他窗口更新，请重新读取', 409)
            if not apply and current['storeId'] == data['storeId']:
                return
            value = {**current, 'storeId': data['storeId'], 'revision': current['revision'] + 1,
                     'savedAt': _stamp()}
            if apply:
                material_selection = None
                if 'materialKey' in data:
                    material_selection = self.materials.save_selection(user, data['storeId'],
                        data['materialKey'], data.get('keywordIds'), data.get('expectedMaterialRevision'),
                        confirm_binding=data.get('confirmMaterialBinding') is True,
                        expected_catalog_digest=data.get('expectedCatalogDigest'), db=db)
                if material_selection is not None:
                    self._bind_material_search(catalog['search'], material_selection, data['storeId'])
                value.update(searchPresetId=data['searchPresetId'], intentPresetId=data['intentPresetId'])
                value['applied'] = self._current_preset(catalog, value, value['savedAt'])
            else:
                _, saved_store=self._store_preference(user,data['storeId'],db)
                value.update(searchPresetId='precise',intentPresetId='standard',applied=None)
                if saved_store:
                    for key in ('searchPresetId','intentPresetId','applied','savedAt'):
                        value[key]=deepcopy(saved_store.get(key,value[key]))
            record = {**value, 'id': self._preference_id(user), 'tenant_id': user['tenant_id'],
                      'owner': user['username'], 'company_id': COMPANY_ID}
            db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',
                (ENTITY, record['id'], record['tenant_id'], json.dumps(record, ensure_ascii=False, allow_nan=False)))
            if apply:
                store_preference_id,_=self._store_preference(user,data['storeId'],db)
                store_record={**record,'id':store_preference_id}
                db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',
                    (STORE_PREF_ENTITY,store_preference_id,user['tenant_id'],json.dumps(store_record,ensure_ascii=False,allow_nan=False)))

    def _delivery_identity(self, token):
        user,profile=self._identity(token,verification=self.delivery_integrations)
        selected=self._load_selection(user,self._stores(profile))['storeId']
        if not selected:raise WorkbenchError('STORE_REQUIRED','当前门店授权已撤销',403)
        self._activate_central_config(user,profile,selected,integration=self.delivery_integrations)
        return user,profile

    def _assessment_policy(self, store_id):
        config=self.central_configs.get(store_id) or {}
        rule=deepcopy(config.get('runtimeAssessment') or {})
        rule['supported']=(rule.get('schema')=='fangyu-runtime-assessment/1'
            and rule.get('version')=='2026-10-17.intent-evidence-contract-draft-v4'
            and rule.get('engineVersion')=='2026-10-18.intent-evidence-contract-draft-v4-review2'
            and rule.get('contractDigest')=='a493c0d812cb35cd76f51c23c92942ff75d68c547bde57885bd7bf8cf422dcf2'
            and isinstance(rule.get('sourceDigest'),str) and re.fullmatch('[a-f0-9]{64}',rule['sourceDigest']) is not None
            and bool(rule.get('bundleRevision')))
        if not rule['supported']:rule['status']='requires_engine_update'
        return rule

    def _assessment_for(self, user, store_id, rule_version=None):
        rule=self._assessment_policy(store_id)
        if not rule['supported'] or rule.get('enabled') is not True or (rule_version and rule_version!=rule['engineVersion']):
            raise WorkbenchError('ASSESSMENT_ENGINE_UPDATE_REQUIRED','判断执行契约未支持，需要升级引擎或重新核对历史任务',409)
        return self.rental_factory(self.core,self.company,rule_version=rule['engineVersion'],store_id=store_id)

    def _read_rental_assessment(self, user, store_id, lead_id):
        rule=self._assessment_policy(store_id)
        if not rule['supported'] or rule.get('enabled') is not True:
            return {'intent_level':'unknown','reason':'requires_engine_update','review_required':True,
                'rule_version':rule.get('version'),'eligibility':'uncertain','store_matches':[],'budget':{},'income_self_report':None}
        result=self._assessment_for(user,store_id).read_assessment(user,lead_id)
        if result is None:result={'intent_level':'unknown','reason':'当前规则尚未完成这条来源的判断',
            'review_required':True,'rule_version':rule['engineVersion'],'eligibility':'uncertain','store_matches':[],'budget':{},'income_self_report':None}
        return {**result,'contract_digest':rule['contractDigest'],'rule_source_digest':rule['sourceDigest'],
            'bundle_revision':rule['bundleRevision'],'calibrated':False}

    def _assess_imported(self, user, task_id):
        context=self.core.store.get('rental_task_context_v1',task_id)
        if (not context or context.get('tenant_id')!=user['tenant_id'] or context.get('owner')!=user['username'] or context.get('enabled') is not True):return None
        rule=self._assessment_policy(context['store_id'])
        if not rule['supported'] or context.get('rule_version')!=rule.get('engineVersion'):
            return {'status':'requires_engine_update','review_required':True}
        if not context.get('contractDigest'):
            # The unchanged runtime accepts four context fields. Bind the
            # authenticated request reservation to its newly created task here.
            matches=[row for row in self.core.store.list(REQUEST_ENTITY,user['tenant_id'])
                if row.get('owner')==user['username'] and (row.get('job') or {}).get('taskId')==task_id]
            head=matches[0] if matches else (self.core.store.get(REQUEST_ENTITY,_digest(['head',user['tenant_id'],user['username']])) or {})
            policy=head.get('assessmentPolicy') or {}
            matching=(head.get('tenant_id')==user['tenant_id'] and head.get('owner')==user['username']
                and head.get('storeId')==context['store_id'] and policy.get('contractDigest')==rule['contractDigest']
                and policy.get('engineVersion')==context['rule_version']
                and ((head.get('state')=='submitted' and context.get('created_at','')>=head.get('created_at','z'))
                    or (head.get('job') or {}).get('taskId')==task_id))
            if not matching:return {'status':'historical_contract_unverified','review_required':True}
            context={**context,'contractDigest':policy['contractDigest'],'sourceDigest':policy['sourceDigest'],
                'bundleRevision':policy['bundleRevision'],'requestId':head['requestId']}
            self.core.store.put('rental_task_context_v1',context)
        if context.get('contractDigest')!=rule['contractDigest']:
            return {'status':'requires_engine_update','review_required':True}
        return self._assessment_for(user,context['store_id'],context['rule_version']).assess_task(user,task_id)

    def _platform_state(self, user, profile=None, *, platform=None):
        actor = {'username': user['username'], 'storeId': self._load_selection(user, self._stores(profile))['storeId'] if profile else ''}
        if self.platform_runtime is None:
            return {'actor': actor, 'available': False, 'device': {'state': 'unavailable', 'bound': False,
                'message': '当前版本的平台后台尚未就绪'}, 'accounts': [], 'platforms': [],
                'acquisition': {'taskId': '', 'status': 'idle', 'canStart': False,
                                'canPause': False, 'canResume': False}}
        result = dict(self.platform_runtime.snapshot(user,platform=platform)
                      if platform is not None else self.platform_runtime.snapshot(user))
        result.pop('rawWorkspace', None)
        selection = self._load_selection(user, self._stores(profile)) if profile else {}
        summary_reader = getattr(self.customer_workbench, 'acquisition_summary', None)
        if callable(summary_reader) and actor['storeId']:
            acquisition = dict(result.get('acquisition') or {})
            task_id = acquisition.get('taskId')
            if task_id:
                current = (summary_reader(user, actor['storeId'], task_id,platform=platform)
                           if platform is not None else summary_reader(user, actor['storeId'], task_id))
                acquisition['recent'] = current['recent']
                acquisition['summary'] = current['summary']
                acquisition['counts'] = {**(acquisition.get('counts') or {}), 'analyzed': current['analyzed']}
                result['acquisition'] = acquisition
        result['actor'] = actor
        result['available'] = True
        result.setdefault('capabilities', {})['timeRanges'] = ['最近7天', '最近3天', '最近30天']
        head = self.core.store.get(REQUEST_ENTITY, _digest(['head', user['tenant_id'], user['username']]))
        if platform is not None and head and (head.get('storeId')!=actor['storeId']
                or (head.get('conditions') or {}).get('platform')!=platform):
            head=None
        head = self._reconcile_request(user,head)
        if head and head.get('tenant_id') == user['tenant_id'] and head.get('owner') == user['username']:
            result['lastRequest'] = {key: deepcopy(head[key]) for key in
                ('requestId', 'storeId', 'state', 'conditions', 'job', 'code', 'message','keywordBatch','batchOffset','batchEnd','totalEligible','profileDigest') if key in head}
        return result

    def _reconcile_request(self,user,head):
        """CAS one named task's private launch receipt; never search latest/start."""
        if (not head or head.get('state') not in ('submitted','unconfirmed')
                or head.get('tenant_id')!=user['tenant_id'] or head.get('owner')!=user['username']
                or head.get('storeId')!=user.get('_workbench_store_id')):return head
        task_id=(head.get('job') or {}).get('taskId')
        if not isinstance(task_id,str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,160}',task_id):return head
        from core.acquisition_receipts import ENTITY as RECEIPTS,matches_receipt
        request_id=_digest([user['tenant_id'],user['username'],head.get('requestId')])
        head_id=_digest(['head',user['tenant_id'],user['username']])
        with self.core.lock,self.core.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            def read(entity,ident):
                row=db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
                    (entity,ident,user['tenant_id'])).fetchone()
                return json.loads(row['body']) if row else None
            fresh_head=read(REQUEST_ENTITY,head_id);record=read(REQUEST_ENTITY,request_id)
            if (not fresh_head or _digest(fresh_head)!=_digest(head) or not record
                    or record.get('state') not in ('submitted','unconfirmed')
                    or record.get('owner')!=user['username'] or record.get('tenant_id')!=user['tenant_id']
                    or record.get('signature')!=head.get('signature') or record.get('job')!=head.get('job')):return fresh_head or head
            task=read('tasks',task_id);receipt=read(RECEIPTS,task_id)
            if not matches_receipt(receipt,record,task):return head
            status=task.get('status') or 'submitted'
            job={'taskId':task_id,'status':status,'accepted':True,
                 'message':'已核对原任务已受理，当前进度以原任务为准'}
            accepted={**record,'state':'accepted','job':job,'code':'',
                'message':job['message'],'reconciled_at':_stamp()}
            updated_head={**accepted,'id':head_id}
            for value in (accepted,updated_head):
                db.execute('UPDATE records SET body=? WHERE entity=? AND id=? AND tenant_id=?',
                    (json.dumps(value,ensure_ascii=False,allow_nan=False),REQUEST_ENTITY,value['id'],user['tenant_id']))
            return updated_head

    def _request_record(self, user, request_id):
        ident = _digest([user['tenant_id'], user['username'], request_id])
        value = self.core.store.get(REQUEST_ENTITY, ident)
        if value and (value.get('tenant_id') != user['tenant_id'] or value.get('owner') != user['username']):
            raise WorkbenchError('REQUEST_SCOPE_INVALID', '操作回执归属无法核对', 409)
        return ident, value

    def _save_request(self, user, record):
        head = {**record, 'id': _digest(['head', user['tenant_id'], user['username']])}
        with self.core.lock,self.core.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            if record.get('state')=='rejected' and record.get('cursorId'):
                found=db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
                    ('ui_keyword_cursor_v1',record['cursorId'],user['tenant_id'])).fetchone()
                cursor=json.loads(found['body']) if found else None
                if cursor and cursor.get('requestId')==record['requestId']:
                    cursor['offset']=record['batchOffset'];cursor['requestId']=None
                    db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',
                        ('ui_keyword_cursor_v1',cursor['id'],user['tenant_id'],json.dumps(cursor,ensure_ascii=False)))
            for value in (record,head):
                db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',
                    (REQUEST_ENTITY,value['id'],user['tenant_id'],json.dumps(value,ensure_ascii=False,allow_nan=False)))

    def _reserve_request(self,user,record,applied,preset,platform):
        words=applied['selectedKeywords']
        ident=_digest(['keyword-cursor-v1',user['tenant_id'],user['username'],record['storeId'],platform,preset,
            applied.get('profileDigest') or _digest(applied.get('libraryReference'))])
        with self.core.lock,self.core.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            previous=db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
                (REQUEST_ENTITY,record['id'],user['tenant_id'])).fetchone()
            if previous:
                old=json.loads(previous['body'])
                if old.get('signature')!=record.get('signature'):
                    raise WorkbenchError('REQUEST_CONFLICT','同一操作编号的条件已经变化',409)
                raise WorkbenchError('REQUEST_UNCONFIRMED','原请求已预约；请核对原任务，不会重复启动',409)
            prior_head=db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
                (REQUEST_ENTITY,_digest(['head',user['tenant_id'],user['username']]),user['tenant_id'])).fetchone()
            if prior_head and json.loads(prior_head['body']).get('state') in ('submitted','unconfirmed'):
                raise WorkbenchError('REQUEST_UNCONFIRMED','上次请求尚未核实，不会预约下一段词',409)
            found=db.execute('SELECT body FROM records WHERE entity=? AND id=? AND tenant_id=?',
                ('ui_keyword_cursor_v1',ident,user['tenant_id'])).fetchone()
            cursor=json.loads(found['body']) if found else {}
            offset=cursor.get('offset',0)
            if type(offset) is not int or not 0<=offset<len(words):offset=0
            end=min(offset+100,len(words))
            record={**record,'keywordBatch':words[offset:end],'batchOffset':offset,'batchEnd':end,
                'totalEligible':len(words),'profileDigest':applied.get('profileDigest'),'cursorId':ident}
            cursor={'id':ident,'tenant_id':user['tenant_id'],'owner':user['username'],'storeId':record['storeId'],
                'platform':platform,'profileDigest':applied.get('profileDigest'),'offset':0 if end==len(words) else end,
                'requestId':record['requestId']}
            head={**record,'id':_digest(['head',user['tenant_id'],user['username']])}
            for entity,value in (('ui_keyword_cursor_v1',cursor),(REQUEST_ENTITY,record),(REQUEST_ENTITY,head)):
                db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',
                    (entity,value['id'],user['tenant_id'],json.dumps(value,ensure_ascii=False,allow_nan=False)))
        return record

    @staticmethod
    def _public_platform_job(value):
        if not isinstance(value, dict):
            raise WorkbenchError('PLATFORM_RESPONSE_INVALID', '平台回执格式需核对', 503)
        raw = value.get('result', value)
        if not isinstance(raw, dict):
            return {}
        allowed = ('id', 'jobId', 'accountId', 'taskId', 'status', 'state', 'message',
                   'phase', 'qrUrl', 'accepted', 'maxBatches','revision','reviewRequired',
                   'reviewReason','verificationWindowOpen','canConfirmReview')
        public = {key: deepcopy(raw[key]) for key in allowed if key in raw}
        for key in ('windowOpen', 'persistentBrowser'):
            if type(raw.get(key)) is bool:
                public[key] = raw[key]
        for key in ('platformLoginConfirmed','collectionAuthorized','autoResume'):
            if type(raw.get(key)) is bool:public[key]=raw[key]
        if type(raw.get('errorCode')) is str and raw['errorCode'] == 'LOGIN_WINDOW_PROCESS_FAILED':
            public['errorCode'] = 'LOGIN_WINDOW_PROCESS_FAILED'
        return public

    def _platform_dispatch(self, action, data, token):
        fields = {'platform_snapshot': {'platform'}, 'platform_prepare': {'existingOnly'},
            'account_metadata_read':{'accountId','platform'},
            'account_metadata_save':{'accountId','platform','name','expectedMetadataDigest','url'},
            'account_create': {'platform', 'name'}, 'account_connect': {'accountId'}, 'account_check': {'accountId'},
            'account_safety':{'accountId'},'account_review_confirm':{'accountId','revision','confirmed'},
            'account_verification_open':{'accountId'},
            'account_job': {'jobId'}, 'account_cancel': {'jobId'},
            'acquisition_start': {'storeId', 'expectedRevision', 'platform', 'accountId',
                                  'region', 'time', 'requestId'},
            'acquisition_pause': {'taskId'}, 'acquisition_resume': {'taskId'}}[action]
        if not isinstance(data, dict) or set(data) - fields:
            raise WorkbenchError('INPUT_INVALID', '操作参数格式无效')
        selected_platform=_optional_platform(data) if action=='platform_snapshot' else None
        with self.lock:
            user, profile = self._identity(token)
            if action == 'platform_snapshot':
                return {'platform': self._platform_state(user, profile,platform=selected_platform)}
            self._selected_store(user, profile)
            if self.platform_runtime is None:
                raise WorkbenchError('PLATFORM_UNAVAILABLE', '当前版本的平台后台尚未就绪', 503)
            if action in ('account_metadata_read','account_metadata_save'):
                result=self.platform_runtime.account_metadata(user,data,save=action=='account_metadata_save')
                try:
                    fresh,fresh_profile=self._identity(token)
                    if (any(fresh.get(k)!=user.get(k) for k in ('id','tenant_id','username','role','cloud_bound'))
                            or self._selected_store(fresh,fresh_profile)!=user.get('_workbench_store_id')):
                        raise WorkbenchError('ACCOUNT_SCOPE_FORBIDDEN','当前身份或门店已变化，请重新读取账号资料',403)
                    current=self.platform_runtime.account_metadata(fresh,
                        {key:data[key] for key in ('accountId','platform')})
                    if current['metadataDigest']!=result['metadataDigest']:
                        raise WorkbenchError('ACCOUNT_METADATA_CONFLICT','账号资料已变化，请重新读取',409)
                except Exception:
                    if action=='account_metadata_save':
                        raise WorkbenchError('ACCOUNT_METADATA_RESULT_UNCONFIRMED',
                            '备注可能已保存，最终身份确认未完成；请读取原账号核对，不要自动重复保存',409) from None
                    raise
                return {'accountMetadata':result}
            if action == 'platform_prepare':
                existing_only=data.get('existingOnly',False)
                if type(existing_only) is not bool:
                    raise WorkbenchError('INPUT_INVALID','连接参数格式无效')
                job = self.platform_runtime.prepare(user,existing_only=True) if existing_only else self.platform_runtime.prepare(user)
            elif action == 'account_create':
                platform, name = data.get('platform'), data.get('name', '')
                if platform not in self.company.get('platforms', []):
                    raise WorkbenchError('PLATFORM_NOT_ENABLED', '企业尚未开通此平台', 403)
                if not isinstance(name, str) or len(name.strip()) > 80:
                    raise WorkbenchError('INPUT_INVALID', '请输入80字以内的账号名称')
                job = self.platform_runtime.create_account(user, {'platform': platform, 'name': name.strip()})
            elif action in ('account_safety','account_review_confirm','account_verification_open'):
                ident=data.get('accountId')
                if not isinstance(ident,str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,160}',ident):
                    raise WorkbenchError('INPUT_INVALID','请先选择有效的账号')
                method={'account_safety':'read_account_safety','account_review_confirm':'confirm_account_review',
                    'account_verification_open':'open_account_verification'}[action]
                job=getattr(self.platform_runtime,method)(user,dict(data))
            elif action in ('account_connect', 'account_check', 'account_job', 'account_cancel', 'acquisition_pause', 'acquisition_resume'):
                key = 'accountId' if action in ('account_connect', 'account_check') else 'jobId' if action.startswith('account_') else 'taskId'
                ident = data.get(key)
                if not isinstance(ident, str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,160}', ident):
                    raise WorkbenchError('INPUT_INVALID', '请先选择有效的账号或任务')
                method = {'account_connect': 'connect_account', 'account_check': 'check_account', 'account_job': 'account_job',
                    'account_cancel': 'cancel_account', 'acquisition_pause': 'pause_acquisition',
                    'acquisition_resume': 'resume_acquisition'}[action]
                job = getattr(self.platform_runtime, method)(user, {key: ident})
            else:
                stores = self._stores(profile)
                if data.get('storeId') != self._selected_store(user, profile):
                    raise WorkbenchError('STORE_FORBIDDEN', '不能使用未分配给当前员工的门店', 403)
                selection = self._load_selection(user, stores)
                if type(data.get('expectedRevision')) is not int or data['expectedRevision'] != selection['revision']:
                    raise WorkbenchError('PRESET_REVISION_CONFLICT', '门店预设已更新，请重新读取', 409)
                # Current validated central words/policy are loaded on this
                # explicit start. A stale saved projection is not employee work.
                applied = self._current_preset(self._catalog(user, data['storeId']), selection, _stamp())
                platform, account = data.get('platform'), data.get('accountId')
                if platform not in self.company.get('platforms', []):
                    raise WorkbenchError('PLATFORM_NOT_ENABLED', '企业尚未开通此平台', 403)
                if not isinstance(account, str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,160}', account):
                    raise WorkbenchError('ACCOUNT_REQUIRED', '请先选择已连接的平台账号')
                if data.get('time') not in ('最近7天', '最近3天', '最近24小时', '最近30天'):
                    raise WorkbenchError('TIME_INVALID', '请选择有效的时间范围')
                if not isinstance(data.get('region', ''), str) or len(data.get('region', '')) > 100:
                    raise WorkbenchError('REGION_INVALID', '地区格式无效')
                request_id = data.get('requestId')
                if not isinstance(request_id, str) or not re.fullmatch(r'[A-Za-z0-9_-]{16,80}', request_id):
                    raise WorkbenchError('REQUEST_ID_REQUIRED', '请重新发起本次采集操作')
                ident, prior = self._request_record(user, request_id)
                head = self.core.store.get(REQUEST_ENTITY, _digest(['head', user['tenant_id'], user['username']]))
                head = self._reconcile_request(user,head)
                if prior and prior.get('state') in ('submitted','unconfirmed'):
                    ident,prior=self._request_record(user,request_id)
                if (head and head.get('tenant_id') == user['tenant_id'] and head.get('owner') == user['username']
                        and head.get('state') in ('submitted', 'unconfirmed') and head.get('requestId') != request_id):
                    raise WorkbenchError('REQUEST_UNCONFIRMED', '上次采集结果尚未确认，请先核对当前任务；不会另起重复采集', 409)
                signature = _digest({'data':data,'profileDigest':applied.get('profileDigest'),'libraryReference':applied.get('libraryReference')})
                if prior:
                    if prior.get('signature') != signature:
                        raise WorkbenchError('REQUEST_CONFLICT', '同一操作编号的条件已经变化', 409)
                    if prior.get('state') == 'accepted':
                        return {'platform': self._platform_state(user, profile), 'job': deepcopy(prior['job'])}
                    if prior.get('state') == 'rejected':
                        raise WorkbenchError(prior['code'], prior['message'], prior.get('status', 409))
                    raise WorkbenchError('REQUEST_UNCONFIRMED', '上次操作尚未确认，请先查看任务状态；不会重复发起', 409)
                record = {'id': ident, 'tenant_id': user['tenant_id'], 'owner': user['username'],
                    'requestId': request_id, 'storeId': data['storeId'], 'signature': signature,
                    'conditions': {key: deepcopy(data.get(key, '')) for key in
                        ('storeId', 'platform', 'accountId', 'region', 'time', 'expectedRevision')},
                    'state': 'submitted', 'created_at': _stamp()}
                record['assessmentPolicy']=self._assessment_policy(data['storeId']) if applied.get('rentalAssessmentEnabled') else None
                record=self._reserve_request(user,record,applied,selection['searchPresetId'],platform)
                store=next(row for row in stores if row['id']==data['storeId'])
                # Search area is trusted store context, not a commenter's IP.
                # The original requested display region stays in the idempotency record above.
                payload = {'platform': platform, 'accountId': account, 'region': '', 'storeId':data['storeId'],
                    'city':store.get('city',''),'area':store.get('area',''),
                    'time': {'最近7天': '7d', '最近3天': '3d', '最近24小时': '24h', '最近30天': '30d'}[data['time']],
                    'keywords': list(record['keywordBatch']), 'excludes':deepcopy(applied.get('excludeTerms',[])),
                    'dailyLimit':1000,'targetCount':1000,
                    'intentMode': 'all'}
                if applied.get('rentalAssessmentEnabled'):
                    payload['rentalAssessment'] = {'enabled': True, 'storeId': data['storeId'],
                        'ruleVersion': self._assessment_policy(data['storeId'])['engineVersion'],
                        'materialKey': applied.get('materialKey')}
                from core.acquisition_receipts import make_binding
                record={**record,'launchConditions':deepcopy(payload),'requestBinding':make_binding(record,payload)}
                self._save_request(user,record)
                payload['requestBinding']=deepcopy(record['requestBinding'])
                try:
                    job = self._public_platform_job(self.platform_runtime.start_acquisition(user, payload))
                except Exception as error:
                    rejected = getattr(error, 'mutation_committed', None) is False and isinstance(getattr(error, 'code', None), str)
                    uncertain = {**record, 'state': 'rejected' if rejected else 'unconfirmed',
                        'code': getattr(error, 'code', 'PLATFORM_ACTION_FAILED'),
                        'status': getattr(error, 'status', 409),
                        'message': str(error) if rejected else '本次未取得成功回执，请先核对任务状态'}
                    task_id = getattr(error, 'task_id', '')
                    if isinstance(task_id, str) and re.fullmatch(r'[A-Za-z0-9_-]{1,160}', task_id):
                        uncertain['job'] = {'taskId': task_id, 'status': 'unconfirmed'}
                    self._save_request(user, uncertain)
                    if not rejected:
                        raise WorkbenchError('REQUEST_UNCONFIRMED', '采集结果尚未确认，请先核对当前任务；不会自动重复发起', 409) from None
                    raise
                self._save_request(user, {**record, 'state': 'accepted', 'job': deepcopy(job)})
            return {'platform': self._platform_state(user, profile), 'job': self._public_platform_job(job)}

    def _customer_dispatch(self, action, data, token):
        fields = {'customers': {'query', 'filter', 'sort', 'sortDirection', 'page', 'pageSize','audience','platform','intent','acquiredDate'},
            'customer_detail': {'id','platform'},
            'customer_export': {'query', 'filter', 'sort', 'sortDirection', 'selectedIds','platform','intent','acquiredDate'},
            'customer_memo_export':{'storeId','id','platform'},
            'customer_handoff_read':{'storeId','id','requestId'},
            'customer_handoff_save':{'storeId','id','expectedVersion','sourceDigest','note','nextStep','requestId'}}[action]
        if not isinstance(data, dict) or set(data) - fields:
            raise WorkbenchError('INPUT_INVALID', '客户查询参数无效')
        selected_platform=_optional_platform(data)
        with self.lock:
            user, profile = self._identity(token)
            if self.customer_workbench is None:
                raise WorkbenchError('CUSTOMERS_UNAVAILABLE', '客户功能尚未装入当前后台，请正常重开已验证的工作台版本', 503)
            stores = self._stores(profile)
            if not stores or not self._load_selection(user,stores)['storeId']:
                if action == 'customers' and user.get('role') == 'admin':
                    return {'customers':{'actor':{'username':user['username'],'storeId':''},
                        'scope':'employee-local-history','items':[],'stats':{'total':0,'high':0,'replied':0,'handoff':0},
                        'total':0,'page':1,'pageSize':20,'pages':0,
                        'scopeNotice':profile.get('_workbench_directory_notice') or '请先选择已授权门店分组'}}
                raise WorkbenchError('STORE_REQUIRED', '请先选择已核实门店分组', 403)
            store_id = self._selected_store(user, profile)
            actor = dict(user)
            # This permission is not persisted by legacy Integrations. Use the
            # fresh, trusted enterprise profile on every export.
            if 'can_export' in profile:
                actor['can_export'] = profile['can_export']
            if action in ('customer_handoff_read','customer_handoff_save','customer_memo_export'):
                if data.get('storeId')!=store_id:
                    raise WorkbenchError('STORE_FORBIDDEN','当前门店已变化，请重新读取客户备忘',403)
                if user.get('role')!='admin' or profile.get('role')!='admin':
                    raise WorkbenchError('MEMO_ADMIN_REQUIRED','客户备忘仅限管理员本人使用',403)
                result=({'file':self.customer_workbench.memo_export(actor,store_id,data)}
                    if action=='customer_memo_export' else {'handoff':self.customer_workbench.handoff(
                        actor,store_id,data,save=action=='customer_handoff_save')})
                try:
                    fresh,fresh_profile=self._identity(token)
                    if (any(fresh.get(k)!=user.get(k) for k in ('id','tenant_id','username','role','cloud_bound'))
                            or fresh_profile.get('role')!='admin'
                            or self._selected_store(fresh,fresh_profile)!=store_id):
                        raise WorkbenchError('MEMO_SCOPE_CHANGED','当前身份或门店已变化，请重新读取备忘',403)
                    if action=='customer_memo_export' and (fresh.get('can_export') is False
                            or fresh_profile.get('can_export') is False):
                        raise WorkbenchError('EXPORT_FORBIDDEN','当前账号没有导出权限',403)
                except Exception:
                    if action=='customer_handoff_save':
                        raise WorkbenchError('MEMO_RESULT_UNCONFIRMED',
                            '备忘保存后的身份确认未完成，请保留输入；重新登录后查询原操作，不要重复保存',409) from None
                    raise
                return result
            if action == 'customers':
                return {'customers': self.customer_workbench.list(actor, store_id, data)}
            if action == 'customer_detail':
                if not {'id'}.issubset(data) or set(data)-{'id','platform'}:
                    raise WorkbenchError('INPUT_INVALID', '请选择有效客户')
                return {'customer': self.customer_workbench.detail(actor, store_id, data['id'],platform=selected_platform)}
            return {'file': self.customer_workbench.export(actor, store_id, data)}

    def _rule_bundle_dispatch(self, action, data, token):
        """Narrow same-origin bridge; the cloud token never enters the page."""
        with self.lock:
            user,profile=self._identity(token)
            if user.get('role')!='admin' or profile.get('role')!='admin':
                raise WorkbenchError('RULE_BUNDLE_ADMIN_REQUIRED','规则文件仅限真实企业管理员',403)
            fields=set(RULE_BUNDLE_FIELDS[action])
            status_lookup=action=='rule_bundle_import_status' and isinstance(data,dict) and set(data) in ({'uploadId'},{'requestId'})
            if not isinstance(data,dict) or (not status_lookup and set(data)!=fields):
                raise WorkbenchError('INPUT_INVALID','规则文件操作参数无效')
            for key in ('uploadId','requestId','revision','expectedRevision'):
                if key in data and (not isinstance(data[key],str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,160}',data[key])):
                    raise WorkbenchError('INPUT_INVALID','规则文件编号格式无效')
            for key in ('digest','previewDigest'):
                if key in data and (not isinstance(data[key],str) or not re.fullmatch(r'[a-f0-9]{64}',data[key])):
                    raise WorkbenchError('INPUT_INVALID','规则文件摘要格式无效')
            if 'index' in data and (type(data['index']) is not int or not 0<=data['index']<86):
                raise WorkbenchError('INPUT_INVALID','规则文件分片编号无效')
            if action=='rule_bundle_import_begin':
                size,count=data['bytes'],data['chunkCount']
                if (type(size) is not int or not 0<size<=8388608 or type(count) is not int
                        or count!=(size+98303)//98304 or not 1<=count<=86):
                    raise WorkbenchError('INPUT_INVALID','只接受不超过8MiB的JSON规则文件')
            if action=='rule_bundle_import_chunk':
                encoded=data['dataBase64']
                if not isinstance(encoded,str) or not 0<len(encoded)<=131072:
                    raise WorkbenchError('INPUT_INVALID','规则文件分片大小无效')
                try:
                    raw=base64.b64decode(encoded,validate=True)
                except (binascii.Error,ValueError):
                    raise WorkbenchError('INPUT_INVALID','规则文件分片编码无效') from None
                if not 0<len(raw)<=98304:
                    raise WorkbenchError('INPUT_INVALID','规则文件分片大小无效')
            try:
                result=self.integrations._cloud(self.integrations._read(user['tenant_id']),user,action,**data)
            except Exception as error:
                status=getattr(error,'http_status',getattr(error,'status',None))
                if status in (401,403):
                    raise WorkbenchError('RULE_BUNDLE_ADMIN_REQUIRED','管理员会话已失效或权限已撤销',status) from None
                # Mutations are never retried. Unknown upload state is resolved
                # only through the explicit status action and existing uploadId.
                if action.startswith('rule_bundle_import_') and action!='rule_bundle_import_status':
                    raise WorkbenchError('RULE_BUNDLE_RESULT_UNCONFIRMED',
                        '规则文件操作结果未知；请核对导入状态，不会自动重试或再次应用',503) from None
                raise WorkbenchError('RULE_BUNDLE_UNAVAILABLE','规则文件状态暂不可读，请手动重新核对',503) from None
            allowed=('revision','digest','bytes','chunkCount','summary','index','dataBase64',
                'uploadId','requestId','state','previewDigest','warnings','receivedIndices','receivedCount','expectedRevision')
            if not isinstance(result,dict):
                raise WorkbenchError('RULE_BUNDLE_UNAVAILABLE','规则文件回执格式无效',503)
            return {'ruleBundle':{key:deepcopy(result[key]) for key in allowed if key in result}}

    @staticmethod
    def _public_ai_profile(value):
        config = value.get('config', value) if isinstance(value, dict) else None
        if (not isinstance(config, dict) or type(config.get('enabled')) is not bool
                or type(config.get('configured')) is not bool
                or config.get('provider') not in ('deepseek', 'openai')
                or type(config.get('revision')) is not int or config['revision'] < 0
                or any(not isinstance(config.get(key), str) or not 0 < len(config[key]) <= 180
                       for key in ('model', 'rules_version'))):
            raise WorkbenchError('AI_PROFILE_INVALID', '企业 AI 配置回执无法核对', 503)
        return {key: deepcopy(config[key]) for key in
                ('enabled', 'configured', 'provider', 'model', 'revision', 'rules_version')}

    def _business_rules_result(self, action, data, token, user, profile, store_id):
        # Read the pinned company presentation only. No policy publication,
        # model probe, customer scan or credential access belongs here.
        import types
        base = self.project_root / 'work/ui-native-r57'
        admin = user.get('role') == 'admin' and profile.get('role') == 'admin'
        allowed = {row['id'] for row in self._stores(profile)}
        try:
            if self.company.get('id') != COMPANY_ID:
                raise PermissionError('这份资料不属于当前企业。')
            source_path = base / 'business_rules.py'
            if source_path.is_symlink():
                raise ValueError('获客规则资料需要更新，请正常更新后重开。')
            source = source_path.read_bytes()
            if hashlib.sha256(source).hexdigest() != '843cb3999060369f01fbf26c6cbd6f119b3b06a15fa7fb5c0ab81850d2388f17':
                raise ValueError('获客规则资料需要更新，请正常更新后重开。')
            helper = types.ModuleType('fangyu_annual_business_rules')
            helper.__file__ = str(source_path)
            exec(compile(source, str(source_path), 'exec'), helper.__dict__)
            dataset = helper.load_data(base / 'business_rules_data.json', '3b776e23788f953ea8fb4e205cdaeed81a89dd659a61fb2733da2d590d08a973')
            approved_path=base/'approved_intent_policy.json'
            approved_raw=approved_path.read_bytes()
            if approved_path.is_symlink() or hashlib.sha256(approved_raw).hexdigest()!='0fd99bd0fc7142eb7e478bda1fcdff045167dc8f2e77755ddc7fcf8c78f6f6f9':
                raise ValueError('已确认规则完整性需要核对。')
            approved=json.loads(approved_raw.decode('utf-8'))
            provider_verified=False
            try:
                current_config=self.integrations._cloud(self.integrations._read(user['tenant_id']),user,
                    'ai_config_read' if admin else 'ai_profile').get('config',{})
                criteria=approved['criteria']
                criteria_hash=hashlib.sha256(json.dumps(criteria,ensure_ascii=False,separators=(',',':')).encode('utf-8')).hexdigest()[:12]
                provider_verified=(current_config.get('rules_version')==
                    'fangyu-approved-20261019-v1|apartment-rental-20261019-approved-v1|p'+criteria_hash
                    and (not admin or current_config.get('intent_policy')==criteria))
            except IntegrationError:
                pass
            catalog=self._catalog(user,store_id)
            selection=self._load_selection(user,self._stores(profile))
            search=next((row for row in catalog['search'] if row['id']==selection['searchPresetId']),None)
            document = helper.project(dataset, allowed, store_id, admin=admin,active_policy=approved,
                provider_verified=provider_verified,active_search={'keywords':list((search or {}).get('keywords',[])),
                    'name':(search or {}).get('name','本店默认词库'),'batchSize':100})
            actor = {'username':user['username'], 'storeId':store_id}
            result = ({'file': helper.exported_file(document, data.get('format','html'),
                       base / 'business_rules_meeting.pptx', 'fe5225ae5a8255bc59e9865323902c87f7caf331c79206cb5b6f3d963d49870c')}
                      if action == 'ai_rules_export' else
                      {'actor':actor, 'businessReview':document})
        except PermissionError as error:
            raise WorkbenchError('BUSINESS_RULES_FORBIDDEN', str(error), 403) from None
        except Exception:
            raise WorkbenchError('BUSINESS_RULES_UNAVAILABLE',
                '获客规则资料尚未完整装入当前版本，请正常更新后重开。', 503) from None
        current, fresh = self._identity(token)
        if (any(current.get(k) != user.get(k) for k in ('id','tenant_id','username','role'))
                or fresh.get('role') != profile.get('role')
                or self._selected_store(current, fresh) != store_id
                or {row['id'] for row in self._stores(fresh)} != allowed):
            raise WorkbenchError('AUTH_REQUIRED', '员工或门店权限已变化，请重新读取。', 403)
        return result

    def _ai_rules_dispatch(self, action, data, token):
        fields = ({'storeId', 'policy', 'expected_revision', 'idempotency_key'}
                  if action == 'ai_local_rules_save' else
                  {'storeId','view'} if action == 'ai_rules_read' and isinstance(data,dict) and 'view' in data else
                  {'storeId','format'} if action == 'ai_rules_export' and isinstance(data,dict) and 'format' in data else {'storeId'})
        if (isinstance(data,dict) and
                (('view' in data and data['view'] != 'business')
                 or ('format' in data and data['format'] not in ('html','pptx')))):
            raise WorkbenchError('INPUT_INVALID', '请选择业务规则或会议演示。')
        if (not isinstance(data, dict) or set(data) != fields
                or not isinstance(data.get('storeId'), str) or not STORE_ID.fullmatch(data['storeId'])):
            raise WorkbenchError('INPUT_INVALID', 'AI 规则操作参数无效')
        with self.lock:
            user, profile = self._identity(token)
            store_id = self._selected_store(user, profile)
            if data['storeId'] != store_id:
                raise WorkbenchError('STORE_FORBIDDEN', '当前门店已变化，请重新读取规则', 403)
            actor = {'username': user['username'], 'storeId': store_id}
            if action == 'ai_readiness_read':
                result = {'actor': actor, 'scope': 'configuration_read_only',
                    'configurationStatus': 'unknown', 'providerSuccess': 'unknown',
                    'providerRequestsStarted': False, 'realCallPerformed': False,
                    'checkedAt': _stamp(), 'profile': None, 'publishedPolicy': None,
                    'notice': '仅读取企业配置；未请求模型，真实调用和费用回执尚未验证。'}
                try:
                    # Deliberately no connectivity_check field: true invokes a
                    # provider probe in the original cloud implementation.
                    raw = self.integrations._cloud(self.integrations._read(user['tenant_id']), user, 'ai_profile')
                    result['profile'] = self._public_ai_profile(raw)
                    from assistant.ai_workflow import published_policy_metadata
                    result['publishedPolicy'] = published_policy_metadata(raw.get('config', raw))
                    config = result['profile']
                    result['configurationStatus'] = ('disabled' if not config['enabled'] else
                        'configured' if config['configured'] else 'not_configured')
                except Exception as error:
                    if getattr(error, 'http_status', getattr(error, 'status', None)) in (401, 403):
                        raise WorkbenchError('AUTH_REQUIRED', '企业 AI 配置读取权限已变化', 403) from None
                    result.update(profile=None, publishedPolicy=None,
                        notice='企业配置暂不可读；配置与真实调用状态均未知，未请求模型。')
                current, fresh = self._identity(token)
                if (any(current.get(k) != user.get(k) for k in ('id', 'tenant_id', 'username', 'role'))
                        or self._selected_store(current, fresh) != store_id):
                    raise WorkbenchError('AUTH_REQUIRED', '员工或门店范围已变化，请重新读取', 403)
                return {'readiness': result}
            admin = user.get('role') == 'admin' and profile.get('role') == 'admin'
            if action in ('ai_local_rules_save', 'ai_rules_export') and not admin:
                raise WorkbenchError('ADMIN_REQUIRED', '规则编辑和导出仅限当前企业管理员', 403)
            if action == 'ai_rules_export' or (action == 'ai_rules_read' and data.get('view') == 'business'):
                return self._business_rules_result(action, data, token, user, profile, store_id)
            manager = self.rules_factory(self.core, user['tenant_id'], user['username'], self.company)
            if action == 'ai_local_rules_save':
                try:
                    saved = manager.execute('intent_rules_save', {k: deepcopy(data[k]) for k in
                        ('policy', 'expected_revision', 'idempotency_key')}, user)
                except Exception as error:
                    if isinstance(error, ValueError):
                        code = getattr(error, 'code', 'INTENT_RULES_INVALID')
                        status = 409 if code == 'INTENT_RULES_REVISION_CONFLICT' else 403 if code == 'INTENT_RULES_FORBIDDEN' else 400
                        raise WorkbenchError(code, str(error), status) from None
                    raise
                return {'actor': actor, 'localPolicy': saved, 'providerPolicyChanged': False}
            local = manager.execute('intent_rules_get', {}, user)
            can_manage = admin and (local.get('summary') or {}).get('can_manage') is True
            # Preserve the existing private-rule boundary even when a trusted
            # operator can manage via another server-side product surface.
            if not can_manage:
                local = {'summary': deepcopy(local.get('summary') or {})}
            from core.intent_policy import normalize_policy
            from assistant.company_intent_policy import safe_projection
            cloud_config, grade, published = None, {'source': 'cloud_ai_config.intent_policy',
                'available': False, 'criteria': None, 'revision': None, 'rulesVersion': None}, {
                'source': 'cloud_published_company_policy', 'status': 'unknown', 'summary': None, 'can_publish': False}
            try:
                raw = self.integrations._cloud(self.integrations._read(user['tenant_id']), user,
                    'ai_config_read' if admin else 'ai_profile')
                cloud_config = self._public_ai_profile(raw)
                grade.update(revision=cloud_config['revision'], rulesVersion=cloud_config['rules_version'])
                if admin and isinstance(raw.get('config', raw).get('intent_policy'), dict):
                    grade.update(available=True, criteria=normalize_policy({
                        'criteria': raw.get('config', raw)['intent_policy']})['criteria'])
            except Exception as error:
                if getattr(error, 'http_status', getattr(error, 'status', None)) in (401, 403):
                    raise WorkbenchError('AUTH_REQUIRED', '企业 AI 配置读取权限已变化', 403) from None
            try:
                raw_policy = self.integrations._cloud(self.integrations._read(user['tenant_id']), user, 'intent_policy_read')
                if not isinstance(raw_policy, dict) or type(raw_policy.get('can_publish')) is not bool or 'summary' not in raw_policy:
                    raise ValueError('Invalid public policy response')
                published.update(status='read', summary=(None if raw_policy['summary'] is None else safe_projection(raw_policy['summary'])),
                    can_publish=admin and raw_policy['can_publish'])
                if admin and isinstance(raw_policy.get('policy'), dict):
                    published['policy'] = normalize_policy(raw_policy['policy'])
            except Exception as error:
                if getattr(error, 'http_status', getattr(error, 'status', None)) in (401, 403):
                    raise WorkbenchError('AUTH_REQUIRED', '公司规则读取权限已变化', 403) from None
                published = {'source': 'cloud_published_company_policy', 'status': 'unknown', 'summary': None, 'can_publish': False}
            catalog = self._catalog(user, store_id)
            overview_reader = getattr(self.rental_factory, 'rule_overview', None)
            rules = {'actor': actor, 'storeId': store_id, 'canManage': can_manage,
                'search': deepcopy(catalog['search']), 'centralVersion': deepcopy(self.materials.central),
                'searchScope': {'source': 'current_store_material_catalog',
                    'activeTaskKeywordsIncluded': False,
                    'notice': '此处为当前门店词库方案；实际执行词以采集任务的关键词批次记录为准。词命中不证明本人求租。'},
                'sourceArtifacts': deepcopy(self.materials.package.get('sourceArtifacts', [])),
                'localAssessmentOverview': overview_reader() if callable(overview_reader) else {'source': 'unavailable'},
                'localPolicy': local, 'providerGradeCriteria': grade, 'providerPolicy': published,
                'providerPrompt': {'source': 'cloud_server_contract', 'available': False,
                    'rulesVersion': cloud_config['rules_version'] if cloud_config else None},
                'localPolicyExecution': {'criteriaTextUsedByLocalEvaluator': False,
                    'criteriaTextSentToProvider': False,
                    'criteriaEditingEffect': 'reference_text_and_policy_revision_only',
                    'evidenceValidation': 'fixed_engine_contract',
                    'propertyFacts': 'post_model_property_match',
                    'notice': '本机五级文字作为规则记录保存；固定证据引擎不解释这些文字。公寓资料用于返回后的资料匹配。改变模型分级需发布云标准。'},
                'usage': {'localCriteriaSentToProvider': False, 'providerRequestsStarted': False,
                    'realCallPerformed': False, 'providerSuccess': 'unknown',
                    'localPolicyScope': 'tenant_owner_post_model_validation',
                    'notice': '本机规则只校验模型返回；云分级标准和已发布公司规则才参与模型提示词。'}}
            current, fresh = self._identity(token)
            if (any(current.get(k) != user.get(k) for k in ('id', 'tenant_id', 'username', 'role'))
                    or self._selected_store(current, fresh) != store_id):
                raise WorkbenchError('AUTH_REQUIRED', '员工或门店范围已变化，请重新读取', 403)
            if action == 'ai_rules_export':
                encoded = json.dumps({'schema': 'fangyu-ai-rules-export/1', 'readOnly': True,
                    'exportedAt': _stamp(), 'rules': rules}, ensure_ascii=False, sort_keys=True,
                    separators=(',', ':'), allow_nan=False).encode('utf-8')
                return {'file': {'filename': 'fangyu-ai-rules-' + store_id + '.json',
                    'mime': 'application/json', 'contentBase64': base64.b64encode(encoded).decode('ascii')},
                    'rulesDigest': _digest(rules)}
            return {'rules': rules}

    def dispatch(self, action, data, token=''):
        if self.closed:
            raise WorkbenchError('BACKEND_CLOSED', '工作台已关闭', 503)
        if action in AI_RULE_ACTIONS:
            return self._ai_rules_dispatch(action, data, token)
        remote = getattr(self,'remote_management',None)
        if remote is not None and action in remote.actions:
            try:
                return remote.dispatch(action,data,token)
            except remote.error_type as error:
                raise WorkbenchError(error.code,str(error),error.status) from None
            except Exception as error:
                status = getattr(error,'http_status',getattr(error,'status',503))
                if status not in (400,401,403,409):status=503
                raise WorkbenchError('REMOTE_RESULT_UNCONFIRMED',
                    '远程操作回执尚未确认，请保留原编号核对；不会自动重试',status) from None
        if action in RULE_BUNDLE_FIELDS:
            return self._rule_bundle_dispatch(action,data,token)
        if action in REPLY_ACTIONS or action in DELIVERY_ACTIONS:
            try:
                with self.lock:
                    user, profile = self._identity(token)
                    stores = self._stores(profile)
                    if not isinstance(data,dict) or not isinstance(data.get('storeId'),str):
                        raise WorkbenchError('INPUT_INVALID','回复门店参数无效')
                    store_id = self._selected_store(user, profile)
                    if data['storeId'] != store_id:
                        raise WorkbenchError('STORE_FORBIDDEN','当前门店已变化，请重新读取',403)
                    if self.reply_workbench is None:
                        raise WorkbenchError('REPLIES_UNAVAILABLE','回复草稿功能尚未装入当前后台，请正常重开已验证的版本',503)
                    if action in DELIVERY_ACTIONS:
                        return {'delivery':self.reply_delivery.execute(action,user,store_id,data,
                            lambda:self._delivery_identity(token))}
                    return {'replyWorkspace':self.reply_workbench.execute(action,user,store_id,data)}
            except WorkbenchError:
                raise
            except Exception as error:
                code, status = getattr(error,'code',None),getattr(error,'status',400)
                if isinstance(code,str) and type(status) is int and status in (400,401,403,404,409,422,503):
                    raise WorkbenchError(code,str(error),status) from None
                raise WorkbenchError('REPLIES_UNAVAILABLE','回复资料暂不可读，请重新核对原评论',503) from None
        if action in CUSTOMER_ACTIONS:
            try:
                return self._customer_dispatch(action, data, token)
            except WorkbenchError:
                raise
            except Exception as error:
                code, status = getattr(error, 'code', None), getattr(error, 'status', 400)
                if isinstance(code, str) and type(status) is int and status in (400, 401, 403, 404, 409, 422, 429, 503):
                    raise WorkbenchError(code, str(error), status) from None
                raise WorkbenchError('CUSTOMERS_UNAVAILABLE', '客户资料暂不可读，请稍后重新加载', 503) from None
        if action in PLATFORM_ACTIONS:
            try:
                return self._platform_dispatch(action, data, token)
            except WorkbenchError:
                raise
            except Exception as error:
                code = getattr(error, 'code', None)
                status = getattr(error, 'status', 400)
                if isinstance(code, str) and type(status) is int and status in (400, 401, 403, 409, 422, 429, 503):
                    raise WorkbenchError(code, str(error), status) from None
                raise WorkbenchError('PLATFORM_ACTION_FAILED', '平台操作未取得确认，请查看当前状态后再处理', 503) from None
        if action not in ACTIONS:
            raise WorkbenchError('ACTION_FORBIDDEN', '当前批次未开放此操作', 403)
        allowed = {'bootstrap': set(), 'login': {'username', 'password', 'rememberUsername'},
                   'logout': set(), 'select_store': {'storeId', 'expectedRevision'},
                   'apply_preset': {'storeId', 'searchPresetId', 'intentPresetId', 'expectedRevision',
                       'materialKey', 'keywordIds', 'expectedMaterialRevision', 'expectedCatalogDigest',
                       'confirmMaterialBinding'},
                   'refresh_assessments': {'storeId', 'expectedRevision'},
                   'tone_preferences_read': {'storeId'},
                   'tone_preferences_save': {'storeId','expectedRevision','identity','tone','salutation','focus','templates'}}[action]
        if not isinstance(data, dict) or set(data) - allowed:
            raise WorkbenchError('INPUT_INVALID', '操作参数格式无效')
        with self.lock:
            try:
                if action == 'bootstrap':
                    return self._bootstrap(token)
                if action == 'login':
                    name, password = data.get('username'), data.get('password')
                    if (not isinstance(name, str) or not 0 < len(name.strip()) <= 80
                            or not isinstance(password, str) or not 0 < len(password) <= 256
                            or type(data.get('rememberUsername', False)) is not bool):
                        raise WorkbenchError('LOGIN_INPUT_INVALID', '请输入员工用户名和密码')
                    entered = self.integrations.enter({'username': name.strip(), 'password': password}, employee_only=False)
                    try:
                        identity = self._identity(entered['token'])
                    except Exception:
                        self.core.handle('logout', {'token': entered['token']})
                        raise
                    self._remember(name.strip() if data.get('rememberUsername') else '')
                    return {**self._bootstrap(identity=identity), 'token': entered['token'],
                            'cookie_max_age': entered.get('cookie_max_age')}
                if action == 'logout':
                    user = self.core.session(token)
                    cloud_unconfirmed = False
                    try:
                        if user and user.get('cloud_bound'):
                            self.integrations.handle('cloud_logout', {}, user)
                    except IntegrationError:
                        cloud_unconfirmed = True
                    finally:
                        self.core.handle('logout', {'token': token})
                    result = self._bootstrap()
                    if cloud_unconfirmed:
                        result['notice'] = '已退出本机；云端退出回执暂未确认，不会自动重试'
                    return result
                user, profile = self._identity(token)
                stores = self._stores(profile)
                if action in ('tone_preferences_read','tone_preferences_save'):
                    return self._tone_preferences(user,profile,data,token,save=action=='tone_preferences_save')
                if action == 'refresh_assessments':
                    if data.get('storeId') not in {row['id'] for row in stores}:
                        raise WorkbenchError('STORE_FORBIDDEN', '不能评估未分配的门店', 403)
                    current = self._load_selection(user, stores)
                    if type(data.get('expectedRevision')) is not int or data['expectedRevision'] != current['revision']:
                        raise WorkbenchError('PRESET_REVISION_CONFLICT', '预设已变化，请重新读取', 409)
                    if not (current.get('applied') or {}).get('rentalAssessmentEnabled'):
                        raise WorkbenchError('RULES_NOT_APPLIED', '请先应用租房与预算规则', 409)
                    summary = self._assessment_for(user, data['storeId']).assess_visible(user)
                    return {**self._bootstrap(identity=(user, profile)), 'assessment': summary}
                if action == 'apply_preset':
                    self._selected_store(user,profile)
                self._save_selection(user, stores, data, apply=action == 'apply_preset')
                result = self._bootstrap(identity=(user, profile))
                if action == 'apply_preset' and ((result.get('selection') or {}).get('applied') or {}).get('rentalAssessmentEnabled'):
                    # The selection is already committed. A grading failure is
                    # reported separately; retrying grading never repeats collection.
                    try:
                        result['assessment'] = self._assessment_for(user, data['storeId']).assess_visible(user)
                    except Exception:
                        result['assessment'] = {'status': 'retry_required', 'message': '预设已保存；现有客户判断未完成，可单独重新评估'}
                return result
            except EmployeeLoginRequired:
                raise WorkbenchError('EMPLOYEE_ONLY', '请使用企业员工账号登录；管理员请使用管理后台', 403) from None
            except IntegrationError as error:
                if isinstance(error, _CloudServiceUnavailable):
                    raise WorkbenchError(error.code, str(error), error.status) from None
                if getattr(error, 'http_status', None) in (401, 403):
                    raise WorkbenchError('AUTH_REQUIRED', '账号或企业会话无效，请核对后重新登录', 401) from None
                raise WorkbenchError('AUTH_SERVICE_UNAVAILABLE',
                                     '企业登录服务暂不可用，已保留本机状态，请稍后手动重试', 503) from None
            except WorkbenchError:
                raise
            except Exception as error:
                if isinstance(getattr(error, 'code', None), str) and getattr(error, 'status', None) in (400,401,403,409,422,503):
                    raise WorkbenchError(error.code, str(error), error.status) from None
                raise
