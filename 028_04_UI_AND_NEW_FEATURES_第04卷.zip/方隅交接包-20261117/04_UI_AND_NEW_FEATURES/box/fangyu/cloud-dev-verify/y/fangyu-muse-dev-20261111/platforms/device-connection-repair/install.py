from pathlib import Path
import importlib.util,sys
sys.dont_write_bytecode=True
P=Path('C:/积木软件工坊/项目/方隅公寓客户版');F=P/'work/parallel-integration-20261018/final-integration'
spec=importlib.util.spec_from_file_location('device_existing_canonical_installer',F.parent/'integration/entry/install_canonical_delegation.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.HERE=F/'entry-v48';m.P=P;m.NATIVE=P/'work/ui-native-r57';m.OUT=F/'candidate-unified-v48'
if __name__=='__main__':m.main()
