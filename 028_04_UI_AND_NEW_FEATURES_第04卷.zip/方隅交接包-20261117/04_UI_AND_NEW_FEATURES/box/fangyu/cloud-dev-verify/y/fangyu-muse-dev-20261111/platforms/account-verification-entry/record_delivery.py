from pathlib import Path
import datetime,hashlib,json,sqlite3
T=Path(__file__).resolve().parent
P=Path('C:/积木软件工坊/项目/方隅公寓客户版');F=P/'work/parallel-integration-20261018/final-integration'
N=P/'work/ui-native-r57';C=F/'candidate-unified-v21'
def read(p):return json.loads(p.read_text('utf-8-sig'))
def write(p,data):p.write_bytes((json.dumps(data,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
staged=read(C/'STAGED.json');check=read(T/'ENTRY-CHECK.json')
assert check['status']=='PASS' and check['release_id']==staged['release_id']
plan=read(F/'entry-v21/CANONICAL-DELEGATION-PREPARED.json')
assert sha(N/'run_workbench.py').upper()==plan['launcher_sha256']
assert read(T/'SESSION-TESTS.json')['status']=='PASS'
assert read(T/'EXPORT-CHECK.json')['status']=='PASS'
for row in read(T/'SOURCE-CHANGES.json'):
 assert sha(C/'project'/row['path'])==row['after'],row['path']
binding=read(N/'state/production-workspace.json');root=Path(binding['data_dir'])
with sqlite3.connect((root/'workspace.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
 tasks=[json.loads(r[0]) for r in db.execute('SELECT body FROM records WHERE entity=?',('tasks',))]
 task=max(tasks,key=lambda r:r.get('created_at',''))
 run=json.loads(db.execute('SELECT body FROM records WHERE entity=? AND id=?',('workbench_collection_run_v1',task['id'])).fetchone()[0])
 started=datetime.datetime.fromisoformat(run['created_at']);finished=datetime.datetime.fromisoformat(run['updated_at'])
 elapsed=(finished-started).total_seconds()
receipt={'status':'INSTALLED_UI_SMOKE_COMPLETE_PLATFORM_AUTH_SKIPPED','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'version':'v21','release_id':staged['release_id'],'launcher_sha256':sha(N/'run_workbench.py'),
 'installed_via_original_CAS':True,'native_entry_check':check,'focused_tests':read(T/'SESSION-TESTS.json'),
 'closure_files_verified':2723,'changed_source_files':12,'CLI_recompiled':False,
 'review':{'read_only_agent':'review_handoff','remaining_blocking_findings':0,
   'fixes':['removed duplicate non-reentrant adapter channel lock','watcher readiness serialized with session commit','core.lock then job_lock on helper launch']},
 'computer_use':{'used':True,'original_desktop_shortcut_reopened':True,'current_window':'方隅工作台',
   'customer_list':True,'customer_pagination':True,'customer_detail':True,'saved_intent_reason':True,
   'reply_page':True,'rule_page':True,'DeepSeek_config_read':True,'DeepSeek_model':'deepseek-flash',
   'export':read(T/'EXPORT-CHECK.json'),'xhs_new_collection':{'status':'failed_session_expired','task_id':task['id'],
      'elapsed_seconds':elapsed,'pages':run.get('pages'),'counts':run.get('counts'),
      'platform_http_status':200,'platform_code':-100,'source_mapping':'xhs_cli/client.py:144-145 -> SessionExpiredError'},
   'effective_collection_throughput':None,'throughput_reason':'No successful new page; session expired',
   'same_UID_real_browser_commit_verified':False,'new_end_to_end_AI_analysis_verified':False,
   'douyin':'No completed connected account visible; authentication skipped',
   'authentication_and_CAPTCHA_skipped_per_user':True,'real_messages_sent':0,
   'final_state':'xiaohongshu acquisition paused, prior records and new test breakpoint retained'},
 'export_file':str(P/'outputs/验证续接实测/客户清单.xlsx')}
write(T/'DELIVERY.json',receipt)
report='''# 客户端修复与实测结果

验证后的任务续接补丁已安装，并已从原桌面入口重新打开。12项定向技术检查通过；真人验证码后的完整恢复仍未实测。

已通过客户端实际检查：客户列表、分页、详情、已保存的意向判断依据、回复工作台、获客规则和公司 DeepSeek 模型配置读取。当前公司模型是 DeepSeek Flash。

Excel 已成功导出72位客户，文件包含一行表头和72行客户内容，人数与界面一致，未发现内部编号或本机路径混入。

新获客实测约4秒后被小红书以登录会话已过期拒绝，本轮新增评论为0，不能据此计算有效采集速度或宣称全部流程已跑通。新评论到五级分析的完整链路也尚未实测。抖音没有已完成连接的可用账号。

按本次要求，涉及本人登录或验证码的部分已跳过，其他检查继续完成。没有发送真实消息；历史客户与任务记录保留，客户端留在小红书获客的暂停状态。
'''
(P/'outputs/验证续接实测/实测结果.md').write_bytes(report.encode('utf-8'))
summary=f'''# 当前续行摘要

2026-10-19：v21 已按原 CAS/公司/绑定/CLI 校验安装到原桌面入口；用户随后明确授权 Computer Use 实跑，并要求遇到本人验证码跳过继续其他检查。

本轮仅修 account-verification-entry 精简交接的最后同 UID 会话提交衔接：复用现有 BrowserLoginCoordinator/status/claim/commit；新凭据由会话提交事务写入，绑定账号/UID/任务/scope/精确失败页/旧回执SHA/当前凭据/auth_generation，不再以全历史 identity_revalidated 为续接条件。历史日志保留；不恢复人工复核锁。PageWorker严格封包不放宽，原失败页最多一次，未知结果不重放。

12项定向合成检查通过，只读差异审查完成，2723文件冻结闭包核验，原入口 --check 通过；已通过 Computer Use 从原桌面快捷方式重开 v21。

真实 UI 检查：72位客户列表/分页/详情/意向依据/回复页/规则页/DeepSeek配置读取通过；Excel导出73行含表头且无技术字段泄露。新获客约{elapsed:.2f}秒，平台 HTTP 200 / code -100；固定CLI源码将 -100 定义为 SessionExpiredError。0新评论，吞吐速度无法有效验证，新评论→AI五级分析未实跑；抖音无已完成连接账号。真人验证码/登录按用户要求跳过，不发送消息。

UI测试创建一个新获客任务；原任务和数据未删除。客户端留在小红书获客暂停页。账户页面仍显示上次“已连接”，而请求已返回会话过期；这是实测限制，不宣称流程全部跑通，不用模拟测试替代真人验证。后续需本人更新登录后再核对真实采集。

证据：C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/account-verification-entry/DELIVERY.json
交付：C:/积木软件工坊/项目/方隅公寓客户版/outputs/验证续接实测
仅此短入口续记；勿重读旧聊天、29.7MB历史、重整上下文或重跑旧完整测试。不要重编CLI，不重开17小时任务，不改自用/核心/其他客户。
'''
target=P/'work/当前续行摘要.md'
if target.exists() and not (T/'summary-before-v21.md').exists():(T/'summary-before-v21.md').write_bytes(target.read_bytes())
target.write_bytes(summary.encode('utf-8'))
(T/'CONTINUE.md').write_bytes(summary.encode('utf-8'))
session=P/'memory/sessions/2026-10-19-验证续接v21与客户端实测.md';session.parent.mkdir(exist_ok=True)
session.write_bytes(summary.encode('utf-8'))
print(json.dumps({'status':receipt['status'],'elapsed_seconds':elapsed,'new_comments':0,'export_rows':72,'entry_check':'PASS'},ensure_ascii=False))
