用户明确要求修复抖音连接；此授权仅覆盖连接问题，其他界面仍按先改图、确认后改代码。
已确认根因：_douyin_result合法返回id空串；showAccountJob原来只在jobId存在时安排检查、继续计时。因此抖音受控浏览器网页登录后没有自动身份核对，快照仍logging_in。
v40仅改app.mjs/account-connection-state.mjs/pages/accounts.mjs。当前exact accountId且windowOpen真时进行原account_check；不调用start重新开登录，不改服务/CLI/身份守卫。最多12次或120秒，逐步退避；成功、失败、关闭、换账号/平台/员工/门店即停止。手动检查原窗口也能进入同一有界自动确认。平台严格身份+绑定+同账号ready仍是成功条件。
账号页抖音未连接按钮改“连接此账号/继续连接”，成功显示平台昵称和“已连接”；历史失败文案不覆盖新成功。其他账号行为保留。
先RED复现无jobId不安排检查，再GREEN。正向自动确认昵称、未知不冒成功、关闭/换账号/失败停止、有界等待、既有终态回执/旧回调、跨账号回复选择回归通过。测试初次漏activePlatform辅助函数已补齐fixture，不是产品故障。JS语法通过。
2733 closure与137 release --check通过，source和release三文件字节一致，原入口已安装v40，SHA55E39FFA3BAEE8F723C081238283E5B824AF0513486F29189B508BD25885036E；entry-v40/canonical-entry-before备份v39。下一变更before必须v40。绑定hash未变，未写生产DB/会话/断点、未发起平台请求/真实发送。
未重启用户当前工作台，不能声称新版实窗或真实平台已通过。需保存草稿后退出重开原入口，抖音点连接原账号，既有持久profile资料继续复用。平台本人验证码仍本人完成，不能用人工ready或旧昵称伪造成功。整体夜间goal的其他未完成项保持，不标complete。
