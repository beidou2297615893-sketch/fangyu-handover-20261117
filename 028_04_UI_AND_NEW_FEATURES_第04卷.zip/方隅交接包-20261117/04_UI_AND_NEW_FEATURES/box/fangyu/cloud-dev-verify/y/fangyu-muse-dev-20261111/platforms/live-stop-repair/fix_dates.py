from pathlib import Path
import json,hashlib
S=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project');T=Path(__file__).resolve().parent
rows=json.loads((T/'SOURCE-CHANGES.json').read_text('utf-8'))
def edit(name,fn):
    p=S/name;raw=p.read_bytes();s=raw.decode('utf-8');new=fn(s);assert s!=new
    compile(new,str(p),'exec')
    backup=T/'before'/name;backup.parent.mkdir(parents=True,exist_ok=True)
    with backup.open('xb') as f:f.write(raw)
    p.write_text(new,encoding='utf-8');rows.append({'path':name,'before':hashlib.sha256(raw).hexdigest(),'after':hashlib.sha256(p.read_bytes()).hexdigest()})
def rep(s,a,b):
    assert s.count(a)==1,(a[:80],s.count(a));return s.replace(a,b)
def pipeline(s):
    s=rep(s,'from copy import deepcopy','from copy import deepcopy\nfrom datetime import datetime')
    s=rep(s,'\ndef _seen_note_key(platform,url):','''
def uses_post_dates(task):
    # The employee workspace labels date_from/to as post time, and explicitly
    # requests all comment dates. Preserve legacy/continuous task semantics.
    return (task.get('platform') in ('xiaohongshu','douyin')
        and task.get('scope')=='search_comments'
        and task.get('continuous_enabled') is False
        and task.get('comment_keyword_mode')=='all'
        and task.get('comment_date_range')=='all')


def post_date_status(value,task):
    if not task.get('date_from') and not task.get('date_to'):return 'unrestricted'
    date=str(value or '')[:10]
    try:datetime.strptime(date,'%Y-%m-%d')
    except ValueError:return 'unverified'
    if ((task.get('date_from') and date<task['date_from'])
            or (task.get('date_to') and date>task['date_to'])):return 'outside'
    return 'in_range'


def _seen_note_key(platform,url):''')
    s=rep(s,"        if decision!='exclude':break","""        date_outside=uses_post_dates(task) and post_date_status(note.get('published_at'),task)=='outside'
        if decision!='exclude' and not date_outside:break
        if date_outside:state['date_skipped_posts']=state.get('date_skipped_posts',0)+1""")
    return s
edit('work/ui-runtime-r55/src/core/pipeline.py',pipeline)
def engine(s):
    # Keep existing lock, inbox, identity, keyword, intent and quota behavior.
    a="                    exclude=False; filter_reason=''\n                    for field,expected in ([] if task.get('continuous_enabled') else [('region',task.get('region')),('published_at',task.get('date_from') or task.get('date_to'))]):"
    b="""                    exclude=False; filter_reason=''
                    from .pipeline import uses_post_dates,post_date_status
                    post_dates=uses_post_dates(task)
                    date_field='content_published_at' if post_dates else 'published_at'
                    if post_dates:
                        item['post_date_status']=post_date_status(item.get('content_published_at'),task)
                        if item['post_date_status']=='unverified':
                            reason='平台未提供帖子日期，所选帖子时间范围待核实'
                            previous=str(item.get('filter_review_reason') or '')
                            item['filter_review_reason']='；'.join(dict.fromkeys(filter(None,[previous,reason])))
                            item['verification_status']='pending'
                    for field,expected in ([] if task.get('continuous_enabled') else [('region',task.get('region')),(date_field,task.get('date_from') or task.get('date_to'))]):
                        # Missing post metadata is not proof the comment is
                        # outside its explicit all-time scope. Keep it flagged.
                        if post_dates and field==date_field and item['post_date_status']=='unverified':continue"""
    s=rep(s,a,b)
    s=rep(s,"                        elif field=='published_at':","                        elif field==date_field:")
    return s
edit('work/ui-runtime-r55/src/core/engine.py',engine)
(T/'SOURCE-CHANGES.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
print('Post/comment date scopes separated for explicit employee all-comments tasks; unknown post date retained as unverified')
