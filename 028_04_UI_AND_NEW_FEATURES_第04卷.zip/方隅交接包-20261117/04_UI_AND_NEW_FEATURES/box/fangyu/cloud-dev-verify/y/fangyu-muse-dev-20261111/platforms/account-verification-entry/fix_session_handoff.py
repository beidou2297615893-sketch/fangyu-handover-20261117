"""One-shot, backed-up final correction. UTF-8 LF sources only."""
from pathlib import Path
import hashlib,json,textwrap
T=Path(__file__).resolve().parent
S=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project')
changes=[]
def edit(relative,fn):
    p=S/relative;raw=p.read_bytes();before=T/'session-before'/relative
    before.parent.mkdir(parents=True,exist_ok=True)
    with before.open('xb') as f:f.write(raw)
    value=fn(raw.decode('utf-8').replace('\r\n','\n'))
    compile(value,str(p),'exec');p.write_bytes(value.encode('utf-8'))
    changes.append({'path':relative,'before':hashlib.sha256(raw).hexdigest(),'after':hashlib.sha256(p.read_bytes()).hexdigest()})

def grants(s):
    s=s.replace('from .xhs_identity_recovery import read_activity, rows_of, scan_activity, digest, IdentityRecoveryError\n','')
    s=s[:s.index('def verified_pages(')]+'''def failed_page(directory,task_id,scope):
    """Select exactly one explicit original CAPTCHA receipt; never infer unknowns."""
    if (not re.fullmatch(r'[A-Za-z0-9_-]{1,160}',str(task_id))
            or not re.fullmatch(r'[a-f0-9]{64}',str(scope))):return None
    folder=plain(Path(directory)/'.workbench-page-receipts'/task_id)
    if not folder.is_dir():return None
    found=[]
    for path in folder.glob('*.json'):
        if not re.fullmatch(r'[a-f0-9]{64}\\.json',path.name):continue
        source=plain(path).read_bytes()
        if len(source)>LIMIT+65536:return None
        value=json.loads(source,object_pairs_hook=_unique)
        if not captcha_receipt(value) or 'verified_retry' in value:continue
        received=value.get('received_at')
        if (value.get('task')!=task_id or value.get('scope')!=scope or value.get('page')!=path.stem
                or not re.fullmatch(r'[a-f0-9]{64}',str(value.get('args_digest')))
                or type(received) not in (int,float) or not math.isfinite(received)
                or not 0<received<=time.time()):return None
        found.append({'task':task_id,'scope':scope,'page':path.stem,
            'args_digest':value['args_digest'],'receipt_sha256':hashlib.sha256(source).hexdigest()})
    return found[0] if len(found)==1 else None


def verified_pages(directory,task_id,scope,account):
    """Use the server's committed same-UID proof, independent of old activity."""
    if account.get('status')!='ready':return {}
    try:
        proof=account.get('browser_verification_receipt')
        if (type(proof) is not dict or type(proof.get('version')) is not int or proof['version']!=1
                or proof.get('account_id')!=account.get('id') or proof.get('tenant_id')!=account.get('tenant_id')
                or not account.get('platform_uid') or account.get('platform')!='xiaohongshu'
                or proof.get('uid_sha256')!=hashlib.sha256(account['platform_uid'].encode()).hexdigest()
                or not re.fullmatch(r'[a-f0-9]{32}',str(proof.get('auth_generation')))
                or proof['auth_generation']!=account.get('auth_generation')
                or type(proof.get('at')) not in (int,float) or not math.isfinite(proof['at'])
                or not 0<=time.time()-proof['at']<=600
                or (Path(directory)/'.xiaohongshu-cli/.browser-session-commit.json').exists()):return {}
        cookie=fingerprint(directory)
        if not cookie or cookie!=proof.get('credential_sha256'):return {}
        context=failed_page(directory,task_id,scope)
        if not context or any(proof.get(k)!=v for k,v in context.items()):return {}
        value=json.loads(plain(Path(directory)/'.workbench-page-receipts'/task_id/(context['page']+'.json')).read_bytes(),object_pairs_hook=_unique)
        if value['received_at']>proof['at']:return {}
        return {context['page']:{**context,'generation':proof['auth_generation'],
            'credential_sha256':cookie,'account_revision':account_revision(account),
            'expires_at':min(time.time()+60,proof['at']+600)}}
    except (OSError,ValueError,TypeError,KeyError):return {}
'''
    return s
edit('work/ui-runtime-r55/src/core/xhs_verified_resume.py',grants)

def commit(s):
    old='guard: Callable[[], bool]) -> str:'
    assert s.count(old)==1;s=s.replace(old,'guard: Callable[[], bool], *, verified_resume=None) -> str:')
    old="        source = Path(candidate_cookie_path)\n";assert s.count(old)==1
    s=s.replace(old,"""        if verified_resume is not None:
            from core.xhs_verified_resume import failed_page
            if (type(verified_resume) is not dict or not expected_account.get('platform_uid')
                    or failed_page(account_dir,verified_resume.get('task'),verified_resume.get('scope'))!=verified_resume):
                return 'verification_receipt_changed'
"""+old)
    old="            updated = dict(current)\n            updated.update(status='ready', checked_at=";assert s.count(old)==1
    s=s.replace(old,"""            if verified_resume is not None and failed_page(account_dir,verified_resume['task'],verified_resume['scope'])!=verified_resume:
                raise _GuardRejected()
            updated = dict(current)
            updated.pop('browser_verification_receipt',None)
            if verified_resume is not None:
                updated['browser_verification_receipt']={**verified_resume,'version':1,'at':time.time(),
                    'account_id':account_id,'tenant_id':tenant_id,
                    'uid_sha256':hashlib.sha256(decision['uid'].encode()).hexdigest(),
                    'auth_generation':nonce,'credential_sha256':hashlib.sha256(active.read_bytes()).hexdigest()}
            updated.update(status='ready', checked_at=""")
    return s
edit('work/ui-runtime-r55/src/assistant/browser_session_commit.py',commit)

def browser(s):
    a=s.index('                    diagnostic = None\n',s.index('def start_persistent_login('))
    b=s.index('                    completed = outcome.state',a)
    block=textwrap.dedent(s[a:b])
    block=block.replace('                            original[\'_account\'], decision, canonical_cookie, guard)',
                        '                            original[\'_account\'], decision, canonical_cookie, guard, verified_resume=verified_resume)')
    # Dedent changes indentation; make the exact call substitution independently.
    block=block.replace("original['_account'], decision, canonical_cookie, guard)","original['_account'], decision, canonical_cookie, guard, verified_resume=verified_resume)")
    block=block.replace("        def snapshot(): return _snapshot(service, user, account['id'], account_dir)",
        "        def snapshot():\n            authorize()\n            return _snapshot(service, user, account['id'], account_dir)")
    block=block.replace("        initial = _snapshot(service, user, account['id'], account_dir)",
        "        authorize()\n        initial = _snapshot(service, user, account['id'], account_dir)\n        attempt, candidate_root, cookie = candidate_provider()")
    block=block.replace('                # Read only while commit_browser_session',
        '                try:authorize()\n                except Exception:return False\n                # Read only while commit_browser_session')
    helper='''def validate_browser_candidate(service,user,account,account_dir,staging,job,proc,candidate_provider,*,verified_resume=None,authorize=lambda:None):
    """One owned candidate, original coordinator and journal; no browser creation."""
    server=service.server
    job_id=job['id']
'''+textwrap.indent(block,'    ')+'''    return outcome,diagnostic


'''
    s=s[:a]+"                    outcome,diagnostic=validate_browser_candidate(service,user,account,account_dir,staging,job,proc,lambda:candidate)\n"+s[b:]
    return s.replace('def start_persistent_login(',helper+'def start_persistent_login(',1)
edit('work/shared-backend-integration/vendor-src/assistant/xhs_browser_login.py',browser)

def runtime(s):
    a=s.index('            try:result=self._recover_xhs_identity(user,account)',s.index('    def resume_verified_acquisition'))
    b=s.index("            fresh=self._task",a)
    s=s[:a]+'''            from core.xhs_verified_resume import failed_page
            directory=self.data_dir/'accounts'/user['tenant_id']/account['id']
            try:context=failed_page(directory,task['id'],self._verified_scope(user,task,account))
            except (OSError,ValueError,TypeError):context=None
            if context is None:
                raise PlatformRuntimeError('VERIFICATION_RECEIPT_REQUIRED','原失败页尚未确认，已保留断点，不会重复请求',409)
            self._commit_verified_browser(user,task,account,context)
'''+s[b:]
    a=s.index('    def _verified_task_pages(');b=s.index('    def open_acquisition_verification',a)
    s=s[:a]+'''    def _verified_scope(self,user,task,account):
        identity=tuple(account.get(k) for k in ('id','tenant_id','cloud_owner','store_id','platform','platform_uid'))
        return hashlib.sha256(json.dumps([user['tenant_id'],user['username'],task['id'],identity,self._collection_binding(task)],ensure_ascii=True,sort_keys=True).encode()).hexdigest()

    def _verified_task_pages(self,user,task,account):
        from core.xhs_verified_resume import verified_pages
        directory=self.core.store.directory/'accounts'/user['tenant_id']/account['id']
        return verified_pages(directory,task['id'],self._verified_scope(user,task,account),account)

    def _commit_verified_browser(self,user,task,account,context):
        from assistant.browser_login_service import _profile_scope,_staging_scope
        from assistant.xhs_browser_login import _candidate,_signal,_ack,validate_browser_candidate
        from assistant.cli_staging import discard_cli_candidate
        from assistant.browser_session_commit import account_revision
        directory=self.data_dir/'accounts'/user['tenant_id']/account['id']
        windows=self._verification_windows(user,account)
        if (len(windows)!=1 or windows[0].get('identity_capture_capable') is not True
                or windows[0].get('window_open') is not True or not account.get('platform_uid')):
            raise PlatformRuntimeError('VERIFICATION_WINDOW_REQUIRED','请保持此账号的原验证窗口打开，再继续原任务',409)
        job=windows[0];proc=job.get('process');stage=directory/'work/browser-login'/job['id']
        profile=directory/'xhs-browser-profile'
        if (proc is None or not _profile_scope(self.data_dir,directory,profile) or not profile.is_dir()
                or not _staging_scope(self.data_dir,directory,stage) or not stage.is_dir()):
            raise PlatformRuntimeError('VERIFICATION_WINDOW_INVALID','原验证窗口需重新核对',409)
        executor=self._executor(user);binding=self._collection_binding(task);revision=account_revision(account)
        selected=[]
        def authorize():
            actor=self._principal(user)
            if self._executor(actor) is not executor:raise ValueError('device_changed')
            current=self._task(actor,task['id']);fresh=self._account(actor,account['id'])
            if (current.get('account_id')!=account['id'] or self._collection_binding(current)!=binding
                    or account_revision(fresh)!=revision or not self._current_comment_policy(current)
                    or job.get('status')!='running' or proc.poll() is not None
                    or (stage/'cancel.flag').exists()):raise ValueError('verification_scope_changed')
            self._verification_idle(actor,fresh)
        def capture():
            authorize();previous={p.name for p in stage.glob('candidate-*.ready.json')}
            _signal(stage,'capture.flag');deadline=time.monotonic()+12
            while time.monotonic()<deadline:
                authorize()
                markers=[p for p in stage.glob('candidate-*.ready.json') if p.name not in previous]
                if len(markers)>1:raise ValueError('verification_candidate_invalid')
                if markers:
                    candidate=_candidate(stage,markers[0])
                    if candidate is None:raise ValueError('verification_candidate_invalid')
                    selected.append((markers[0],candidate));return candidate
                self.service.stop_event.wait(.05)
            raise ValueError('verification_capture_unconfirmed')
        with self.core.adapters.channel_guard:
            channel=self.core.adapters.channel_locks.setdefault('xiaohongshu:'+str(directory.resolve()),threading.Lock())
        if not channel.acquire(blocking=False):
            raise PlatformRuntimeError('ACCOUNT_BUSY','此账号正在处理请求，请稍后继续',409)
        completed=False
        try:
            outcome,diagnostic=validate_browser_candidate(self.service,user,account,directory,stage,job,proc,
                capture,verified_resume=context,authorize=authorize)
            completed=outcome.state=='completed'
            if not completed:
                raise PlatformRuntimeError('VERIFICATION_NOT_FINISHED','本次账号会话尚未核实，请完成本人验证后再继续；原任务已保留',409)
        except PlatformRuntimeError:raise
        except Exception:
            raise PlatformRuntimeError('VERIFICATION_NOT_FINISHED','本次验证结果尚未确认，原任务已保留，请核对窗口状态',409) from None
        finally:
            try:
                for marker,candidate in selected:
                    discard_cli_candidate(candidate[2]);_ack(stage,candidate[0],'completed' if completed else 'failed')
                    marker.unlink(missing_ok=True)
            finally:channel.release()

'''+s[b:]
    return s
edit('work/shared-backend-integration/platform_runtime.py',runtime)
(T/'SESSION-CHANGES.json').write_bytes((json.dumps(changes,ensure_ascii=False,indent=2)+'\n').encode())
print(json.dumps({'changed':len(changes),'files':[r['path'] for r in changes]},ensure_ascii=False))
