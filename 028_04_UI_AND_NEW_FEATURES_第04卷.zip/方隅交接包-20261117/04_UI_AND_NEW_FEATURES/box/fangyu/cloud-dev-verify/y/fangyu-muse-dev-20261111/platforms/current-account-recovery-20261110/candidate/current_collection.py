"""Explicitly enabled collector recovery; never replays an uncertain target."""
import copy, json, os, sqlite3, subprocess, sys, time
from contextlib import closing
from pathlib import Path
from collection_startup import startup_lock, recover_stale_leases, process_running, collection_pause_reason, control_for_start, StartupBlocked
ROOT=Path(__file__).resolve().parent
FLAGS=0x08000000

def send_busy():
    result=subprocess.run(['powershell','-NoProfile','-Command',
        "Get-CimInstance Win32_Process -Filter \"Name='python.exe' OR Name='pythonw.exe' OR Name='node.exe'\" | Select-Object -ExpandProperty CommandLine"],capture_output=True,text=True,creationflags=FLAGS,timeout=20)
    if result.returncode: return True
    return any(x in result.stdout for x in ('batch_reply_runner','send_cli_once','control.py'))

def probe_decision(verified):
    return 'ready' if verified else 'waiting_for_page'

def remaining_config(root,database,active,config):
    root=Path(root).resolve(); words=set(); videos=set(config.get('excluded_historical_videos',[])); accounts=set(config.get('collection_accounts',[]))
    directory=(root/active['directory']).resolve()
    if not directory.is_relative_to(root): raise StartupBlocked('断点目录不在采集目录内。')
    control=control_for_start(active,directory)
    pending=control.get('pending')
    if pending:
        path=Path(pending['record_path']).resolve()
        if not path.is_relative_to(directory): raise StartupBlocked('断点记录路径无法核对。')
        record=json.loads(path.read_text(encoding='utf-8-sig')); spec=record.get('spec',{})
        original=json.loads((root/active['plan']).read_text(encoding='utf-8-sig'))
        if (spec.get('request_id')!=pending.get('request_id') or any(spec.get(k)!=original[k] for k in ('account_uid','connection_id','scan_id'))):
            raise StartupBlocked('断点与原任务不一致，已保留原记录。')
        # Exclude the whole target whether saved, unknown, or prepared: never replay.
        if spec.get('keyword'): words.add(spec['keyword'])
        (words if spec['kind']=='search' else videos).add(spec['target'])
        accounts.add(spec['account_uid'])
    with closing(sqlite3.connect(Path(database).resolve().as_uri()+'?mode=ro',uri=True)) as db:
        for (raw,) in db.execute('SELECT spec FROM attempts'):
            spec=json.loads(raw)
            if spec.get('account_uid'): accounts.add(spec['account_uid'])
            (words if spec['kind']=='search' else videos).add(spec['target'])
    cfg=copy.deepcopy(config)
    cfg['stores']=[dict(st,keywords=[k for k in st['keywords'] if k not in words]) for st in cfg['stores']]
    if any(not st['keywords'] for st in cfg['stores']): raise StartupBlocked('剩余未尝试关键词已用尽，已保留断点。')
    cfg.update(excluded_historical_videos=sorted(videos),collection_accounts=sorted(accounts))
    return cfg

def start():
    import new_round
    if send_busy(): return '发送仍在运行，采集等待让路。'
    paused=collection_pause_reason(ROOT)
    if paused:return paused
    try:
        with startup_lock(ROOT):
            active=json.loads((ROOT/'active-runner.json').read_text(encoding='utf-8-sig'))
            if process_running(active.get('pid')):return '采集已在运行，未重复启动。'
            if (ROOT/active['directory']/'STOP').exists():return '采集已按停止按钮暂停；断点已保留。'
            cfg=remaining_config(ROOT,new_round.DB,active,new_round.rd(new_round.CONFIG))
            recover_stale_leases(ROOT)
            if send_busy():return '发送仍在运行，采集等待让路。'
            code=new_round._main(config_override=cfg)
            return '已使用当前登录页面继续采集。' if code==0 else '采集尚未启动；可能出验证码了，或页面未响应。完成验证后将自动检查恢复。'
    except StartupBlocked as e:return str(e)
    except (OSError,ValueError,KeyError,sqlite3.Error,subprocess.TimeoutExpired) as e:
        return '采集恢复等待本地检查：'+type(e).__name__+'；未知记录已保留。'

def ensure_supervisor():
    with startup_lock(ROOT):
        state=ROOT/'current-collection-supervisor.json'
        old=json.loads(state.read_text(encoding='utf-8')) if state.exists() else {}
        if process_running(old.get('pid')):return
        with (ROOT/'current-collection-supervisor.log').open('ab') as out:
            p=subprocess.Popen([sys.executable,str(Path(__file__).resolve()),'--watch'],cwd=ROOT,stdout=out,stderr=out,creationflags=FLAGS)
        state.write_text(json.dumps({'pid':p.pid,'enabled_by':'user explicit continue 2026-11-10'}),encoding='utf-8')

def watch():
    previous=None
    while True:
        time.sleep(60)
        a=json.loads((ROOT/'active-runner.json').read_text(encoding='utf-8'))
        if (ROOT/'auto-collect.stop').exists() or (ROOT/a['directory']/'STOP').exists():return
        if process_running(a.get('pid')):continue
        result=start()
        if result!=previous:print(time.strftime('%m-%d %H:%M:%S'),result,flush=True);previous=result

if __name__=='__main__':
    if '--watch' in sys.argv:watch()
    else:
        print(start(),flush=True);ensure_supervisor()
