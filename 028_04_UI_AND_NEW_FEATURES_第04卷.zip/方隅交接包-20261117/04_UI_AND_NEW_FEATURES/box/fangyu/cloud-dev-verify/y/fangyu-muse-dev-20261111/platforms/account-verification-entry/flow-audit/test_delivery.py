"""Real employee runtime/Core/queues/SQLite; only external HTTP/CLI are fixtures."""
from pathlib import Path
import sys,json,tempfile,time,unittest,threading,http.client,hashlib
from unittest.mock import patch
ROOT=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project')
sys.dont_write_bytecode=True
sys.path[:0]=[str(ROOT/'work/ui-native-r57'),str(ROOT/'work/ui-runtime-r55/src'),str(ROOT/'work/shared-backend-integration')]
from test_workbench_backend import CloudFixture
from workbench_backend import WorkbenchBackend,WorkbenchError
from customer_workbench import CustomerWorkbench
from platform_runtime import PlatformRuntime
from ui_native_host import StaticServer

class DeviceCloud:
    def __init__(self):self.calls=[]
    def call(self,operation,data,token):
        self.calls.append(operation)
        if operation=='device_poll':return {'safety_hold':False,'poll_after':60}
        if operation=='device_account_claim':return {'claimed':True}
        raise AssertionError('unexpected device cloud operation '+operation)
    def close(self):pass

class EmployeeCloud(CloudFixture):
    def __init__(self):
        super().__init__();self.pause=False;self.entered=threading.Event();self.release=threading.Event();self.revocation=threading.Event()
    def __call__(self,url,payload,token=''):
        result=super().__call__(url,payload,token)
        if payload['operation']=='me' and self.user.get('can_reply') is False:self.revocation.set()
        if self.pause and payload['operation']=='me' and threading.current_thread().name=='reviewed-reply-queue':
            self.pause=False;self.entered.set()
            if not self.release.wait(4):raise TimeoutError('owned identity gate expired')
        return result

class DeliveryTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(dir=Path(__file__).parent)
        self.addCleanup(self.temp.cleanup)
        self.cloud=EmployeeCloud();self.cloud.user['can_reply']=True
        self.device=DeviceCloud();self.calls=[];self.outcome='sent'
        self.network=patch('integrations.request_json',side_effect=self.cloud);self.network.start()
        self.addCleanup(self.network.stop)
        self.cli=patch('core.adapters.Adapters.execute',side_effect=self.external_cli);self.cli.start()
        self.addCleanup(self.cli.stop)
        self.company={'id':'fangyu-apartment-client','name':'Owned fixture','edition':'customer',
            'personalMode':False,'authMode':'managed','platforms':['xiaohongshu'],'runtime':{
                'test_current_hold_guard_remains_closed':{'xiaohongshu_automation':'hold'},
                'test_portable_guard_remains_closed':{'portable_employee_release':True}}.get(self._testMethodName,{}),
            'managedWorkspace':{'environment_id':'fixture-env','endpoint':'https://example.invalid/workspace'}}
        self.backend=self.open_backend()
        self.addCleanup(self.backend.close)
        self.token=self.backend.dispatch('login',{'username':'fixture-employee','password':'[REDACTED:assigned_secret]','rememberUsername':False})['token']
        self.user=self.backend.core.session(self.token);self.tenant=self.user['tenant_id']
        runtime=self.backend.platform_runtime
        runtime.service.vault.write({'state':'bound','token':'T'*64,'device':{'id':'fixture-device','owner':'fixture-employee'}})
        runtime.service.device={'id':'fixture-device','owner':'fixture-employee'}
        runtime.service.start()
        deadline=time.monotonic()+3
        while runtime.service.state not in ('online','held','error') and time.monotonic()<deadline:time.sleep(.01)
        self.assertEqual(runtime.service.state,'held' if self.company['runtime'].get('portable_employee_release') else 'online')
        (Path(self.temp.name)/'adapters').mkdir(exist_ok=True)
        (Path(self.temp.name)/'adapters/xiaohongshu.json').write_text(json.dumps({'id':'xiaohongshu',
            'executable':sys.executable,'reply_contract_verified':True,'isolation_guard':True}),'utf-8')
        self.backend.core.store.put('accounts',{'id':'fixture-account','tenant_id':self.tenant,'cloud_owner':'fixture-employee',
            'platform':'xiaohongshu','platform_uid':'fixture-uid','name':'本人测试账号','status':'ready'})
        self.backend.core.store.put('leads',{'id':'comment-a','tenant_id':self.tenant,'cloud_owner':'fixture-employee',
            'platform':'xiaohongshu','source_type':'comment','source_id':'comment-a','comment_id':'comment-a',
            'author_id':'uid-a','author':'隔离客户','text':'请问周末方便吗？','content_title':'隔离原帖',
            'note_url':'https://www.xiaohongshu.com/explore/123456789012345678901234'})
        self.customer=self.backend.dispatch('customers',{},self.token)['customers']['items'][0]['id']

    def open_backend(self):
        """Root may override only construction with frozen host.create_backend."""
        return WorkbenchBackend(ROOT,data_dir=self.temp.name,company=self.company,
            customer_factory=CustomerWorkbench,platform_factory=lambda **kw:PlatformRuntime(**kw,cloud_factory=lambda *a:self.device))

    def external_cli(self,platform,args,account_dir,**kwargs):
        self.calls.append(list(args))
        callback=getattr(self,'on_send',None)
        if callback:callback(len(self.calls))
        if self.outcome=='unknown':raise TimeoutError('owned response lost')
        if self.outcome=='busy':
            from core.adapters import AdapterBusy
            raise AdapterBusy('owned busy')
        return {'ok':True,'data':{'id':'fixture-platform-reply'}}

    def tearDown(self):
        if hasattr(self,'backend'):self.backend.close()
        self.cli.stop();self.network.stop();self.temp.cleanup()

    def draft(self,lead_id='comment-a',customer=None):
        customer=customer or self.customer
        data={'storeId':'fixture-store-a','customerId':customer}
        row=next(r for r in self.backend.dispatch('reply_read',data,self.token)['replyWorkspace']['comments'] if r['id']==lead_id)
        base={**data,'leadId':row['id'],'sourceDigest':row['sourceDigest'],'expectedVersion':0,'expectedReplyId':''}
        saved=next(r for r in self.backend.dispatch('reply_save',{**base,'text':'方便说一下你预计什么时候入住吗？','requestId':'draft-'+lead_id},self.token)['replyWorkspace']['comments'] if r['id']==lead_id)['draft']
        self.backend.dispatch('reply_review',{**base,'expectedVersion':saved['version'],'expectedReplyId':saved['id'],
            'accountId':'fixture-account','confirmed':True,'requestId':'review-'+lead_id},self.token)
        return {'customerId':customer,'leadId':row['id'],'sourceDigest':row['sourceDigest'],
            'replyId':saved['id'],'version':saved['version'],'accountId':'fixture-account'}

    def items(self,count):
        items=[self.draft()]
        original=self.backend.core.store.get('leads','comment-a')
        for index in range(1,count):
            ident='comment-'+str(index)
            self.backend.core.store.put('leads',{**original,'id':ident,'source_id':ident,'comment_id':ident,'text':'隔离原评论 '+ident})
            items.append(self.draft(ident))
        return items

    def call(self,action,**data):
        if action=='reply_delivery_prepare':data.setdefault('requestId','prepare-one')
        return self.backend.dispatch(action,{'storeId':'fixture-store-a',**data},self.token)['delivery']
    def wait(self,ident):
        deadline=time.monotonic()+4
        while time.monotonic()<deadline:
            result=self.call('reply_delivery_status',id=ident)
            if result['state'] not in ('submitted','running','awaiting_collection'):return result
            time.sleep(.01)
        self.fail('owned queue did not finish')

    def test_one_exact_authorization_sends_once_and_unknown_is_never_replayed(self):
        item=self.draft()
        prepared=self.call('reply_delivery_prepare',items=[item])
        self.assertEqual(self.calls,[])
        self.assertEqual(prepared['items'][0]['text'],'方便说一下你预计什么时候入住吗？')
        self.call('reply_delivery_start',id=prepared['id'],snapshotDigest=prepared['snapshotDigest'],confirmed=True,requestId='send-one')
        result=self.wait(prepared['id'])
        self.assertEqual(result['state'],'completed')
        self.assertEqual(result['items'][0]['status'],'sent')
        self.assertEqual(len(self.calls),1)
        self.call('reply_delivery_start',id=prepared['id'],snapshotDigest=prepared['snapshotDigest'],confirmed=True,requestId='send-one')
        self.assertEqual(len(self.calls),1)

    def test_unknown_platform_result_stops_and_cannot_be_reauthorized(self):
        self.outcome='unknown'
        item=self.draft();prepared=self.call('reply_delivery_prepare',items=[item])
        self.call('reply_delivery_start',id=prepared['id'],snapshotDigest=prepared['snapshotDigest'],confirmed=True,requestId='unknown-one')
        result=self.wait(prepared['id'])
        self.assertEqual(result['state'],'stopped');self.assertEqual(result['items'][0]['status'],'unknown')
        self.assertEqual(len(self.calls),1)
        with self.assertRaises(WorkbenchError) as error:
            self.call('reply_delivery_start',id=prepared['id'],snapshotDigest=prepared['snapshotDigest'],confirmed=True,requestId='unknown-two')
        self.assertEqual(error.exception.code,'DELIVERY_ALREADY_AUTHORIZED')
        with self.assertRaises(WorkbenchError):self.call('reply_delivery_prepare',items=[item],requestId='prepare-new')
        self.assertEqual(len(self.calls),1)

    def test_batch_is_explicit_and_real_queue_rechecks_permission_before_next_item(self):
        items=self.items(3);prepared=self.call('reply_delivery_prepare',items=items)
        self.assertEqual(self.calls,[])
        self.on_send=lambda count:self.cloud.user.update(can_reply=False) if count==1 else None
        self.call('reply_delivery_start',id=prepared['id'],snapshotDigest=prepared['snapshotDigest'],confirmed=True,requestId='batch-authorized')
        self.assertTrue(self.cloud.revocation.wait(3))
        self.cloud.user['can_reply']=True
        result=self.wait(prepared['id'])
        self.assertEqual(result['state'],'stopped');self.assertEqual(len(self.calls),1)
        self.assertEqual([r['status'] for r in result['items']],['sent','approved','approved'])

    def test_twenty_prepared_items_and_strict_snapshot_or_foreign_id_rejection(self):
        items=self.items(20)
        prepared=self.call('reply_delivery_prepare',items=items)
        self.assertEqual(len(prepared['items']),20);self.assertEqual(self.calls,[])
        for bad in ([],items+[items[0]],[items[0],items[0]],[{**items[0],'replyId':'foreign-reply'}]):
            with self.subTest(count=len(bad)),self.assertRaises(WorkbenchError):
                self.call('reply_delivery_prepare',items=bad,requestId='invalid-'+str(len(bad)))
        with self.assertRaises(WorkbenchError):
            self.call('reply_delivery_start',id=prepared['id'],snapshotDigest='wrong',confirmed=True,requestId='bad-snapshot')
        self.assertEqual(self.calls,[])

    def test_current_hold_guard_remains_closed(self):
        item=self.draft();prepared=self.call('reply_delivery_prepare',items=[item])
        result=self.call('reply_delivery_start',id=prepared['id'],snapshotDigest=prepared['snapshotDigest'],confirmed=True,requestId='held-one')
        self.assertEqual(result['state'],'blocked');self.assertEqual(self.calls,[])

    def test_portable_guard_remains_closed(self):
        self.test_current_hold_guard_remains_closed()

    def test_public_status_and_cancel_terminate_while_worker_checks_identity(self):
        items=self.items(2);prepared=self.call('reply_delivery_prepare',items=items)
        cli_entered=threading.Event();cli_release=threading.Event()
        self.on_send=lambda count:(cli_entered.set(),cli_release.wait(4)) if count==1 else None
        self.cloud.pause=True
        self.call('reply_delivery_start',id=prepared['id'],snapshotDigest=prepared['snapshotDigest'],confirmed=True,requestId='cancel-batch')
        self.assertTrue(self.cloud.entered.wait(3))
        results=[]
        def status():results.append(self.call('reply_delivery_status',id=prepared['id']))
        def cancel():results.append(self.call('reply_delivery_cancel',id=prepared['id']))
        readers=[threading.Thread(target=status),threading.Thread(target=cancel)]
        for thread in readers:thread.start()
        self.cloud.release.set()
        self.assertTrue(cli_entered.wait(3))
        for thread in readers:thread.join(3);self.assertFalse(thread.is_alive(),'identity/status/cancel lock cycle')
        cli_release.set()
        deadline=time.monotonic()+3
        while time.monotonic()<deadline:
            result=self.call('reply_delivery_status',id=prepared['id'])
            if result['items'][0]['status']=='sent':break
            time.sleep(.01)
        self.assertEqual(result['state'],'cancelled');self.assertEqual(len(self.calls),1)
        self.assertEqual(result['items'][1]['status'],'approved')

    def original_adapter_send(self,outcome):
        """Keep Adapters.execute/_execute, channel/lifecycle locks and all guards."""
        self.cli.stop();self.outcome=outcome
        owner=self
        reached=threading.Event()
        class OwnedProcess:
            pid=777777
            returncode=None
            def __init__(self,argv,**kwargs):self.argv=argv;self.done=False
            def communicate(self,*args,**kwargs):
                if self.done:return '{}',''
                self.done=True
                reached.set()
                try:
                    offset=self.argv.index('reply')
                    return json.dumps(owner.external_cli('xiaohongshu',self.argv[offset:],owner.temp.name)),''
                finally:self.returncode=0
            def poll(self):return self.returncode
            def kill(self):self.returncode=-9
            def terminate(self):self.returncode=-9
            def wait(self,*args,**kwargs):return self.returncode
        with patch('core.adapters.subprocess.Popen',side_effect=OwnedProcess):
            item=self.draft();prepared=self.call('reply_delivery_prepare',items=[item])
            self.call('reply_delivery_start',id=prepared['id'],snapshotDigest=prepared['snapshotDigest'],confirmed=True,requestId='original-cli')
            self.assertTrue(reached.wait(3),'original CLI Popen boundary not reached')
            return self.wait(prepared['id'])

    def test_original_adapter_lifecycle_and_popen_boundary_success(self):
        result=self.original_adapter_send('sent')
        self.assertEqual(result['state'],'completed',result);self.assertEqual(result['items'][0]['status'],'sent')
        self.assertEqual(len(self.calls),1)

    def test_original_adapter_started_process_failure_stays_unknown(self):
        result=self.original_adapter_send('unknown')
        self.assertEqual(result['state'],'stopped');self.assertEqual(result['items'][0]['status'],'unknown')
        self.assertEqual(len(self.calls),1)

    def test_known_busy_stops_without_marking_sent_or_unknown(self):
        self.outcome='busy';item=self.draft();prepared=self.call('reply_delivery_prepare',items=[item])
        self.call('reply_delivery_start',id=prepared['id'],snapshotDigest=prepared['snapshotDigest'],confirmed=True,requestId='busy-one')
        result=self.wait(prepared['id'])
        self.assertEqual(result['state'],'stopped');self.assertEqual(result['items'][0]['status'],'approved')
        self.assertEqual(result['sent'],0)

    def test_final_spawn_guard_never_waits_for_core_while_holding_lifecycle(self):
        # A deterministic regression of the discovered ABBA boundary. The real
        # scope validator is installed but must not run when Core is contended.
        entered=threading.Event();finished=threading.Event();errors=[]
        delivery=self.backend.reply_delivery;adapters=self.backend.core.adapters
        def boundary():
            delivery.local.callback=lambda flag:delivery.validation('unsubmitted-reply',{})
            with adapters.lifecycle_lock:
                entered.set()
                try:adapters._guard_platform('xiaohongshu')
                except Exception as error:errors.append(error)
            finished.set()
        with self.backend.core.lock:
            thread=threading.Thread(target=boundary);thread.start()
            self.assertTrue(entered.wait(1));self.assertTrue(finished.wait(1),'lifecycle -> Core blocked')
        thread.join(1)
        from core.adapters import AdapterBusy
        self.assertEqual(len(errors),1);self.assertIsInstance(errors[0],AdapterBusy);self.assertEqual(self.calls,[])

    def test_three_item_authorized_batch_completes_in_original_queue_order(self):
        items=self.items(3);prepared=self.call('reply_delivery_prepare',items=items)
        done=threading.Event();self.on_send=lambda count:done.set() if count==3 else None
        self.call('reply_delivery_start',id=prepared['id'],snapshotDigest=prepared['snapshotDigest'],confirmed=True,requestId='three-authorized')
        self.assertTrue(done.wait(4));result=self.wait(prepared['id'])
        self.assertEqual(result['state'],'completed');self.assertEqual(result['sent'],3)
        self.assertEqual([a[a.index('--comment-id')+1] for a in self.calls],[r['leadId'] for r in items])
        self.assertEqual([r['receipt']['local_outcome'] for r in result['items']],['sent']*3)

    def test_unknown_delivery_survives_normal_reopen_without_automatic_recovery(self):
        self.outcome='unknown';item=self.draft();prepared=self.call('reply_delivery_prepare',items=[item])
        self.call('reply_delivery_start',id=prepared['id'],snapshotDigest=prepared['snapshotDigest'],confirmed=True,requestId='before-reopen')
        self.assertEqual(self.wait(prepared['id'])['items'][0]['status'],'unknown')
        self.backend.close();self.backend=self.open_backend();self.addCleanup(self.backend.close)
        result=self.call('reply_delivery_status',id=prepared['id'])
        self.assertEqual(result['state'],'stopped');self.assertFalse(result['canStart'])
        self.assertEqual(result['items'][0]['status'],'unknown');self.assertEqual(len(self.calls),1)
        self.call('reply_delivery_start',id=prepared['id'],snapshotDigest=prepared['snapshotDigest'],confirmed=True,requestId='before-reopen')
        self.assertEqual(len(self.calls),1)

    def test_source_and_account_change_cannot_authorize_a_prepared_snapshot(self):
        item=self.draft();prepared=self.call('reply_delivery_prepare',items=[item])
        lead=self.backend.core.store.get('leads','comment-a')
        self.backend.core.store.put('leads',{**lead,'text':'变化后的完整原评论'})
        with self.assertRaises(WorkbenchError) as error:
            self.call('reply_delivery_start',id=prepared['id'],snapshotDigest=prepared['snapshotDigest'],confirmed=True,requestId='source-changed')
        self.assertEqual(error.exception.code,'DELIVERY_SNAPSHOT_CHANGED');self.assertEqual(self.calls,[])
        self.backend.core.store.put('leads',lead)
        account=self.backend.core.store.get('accounts','fixture-account')
        self.backend.core.store.put('accounts',{**account,'conn_id':'changed-connection'})
        with self.assertRaises(WorkbenchError):
            self.call('reply_delivery_start',id=prepared['id'],snapshotDigest=prepared['snapshotDigest'],confirmed=True,requestId='account-changed')
        self.assertEqual(self.calls,[])

    def test_same_origin_http_authorization_requires_csrf_exact_schema_and_private_cookie(self):
        item=self.draft();fixture=Path(self.temp.name)/'owned-http';(fixture/'web').mkdir(parents=True)
        body=b'<!doctype html><title>Owned delivery test</title>';(fixture/'web/index.html').write_bytes(body)
        server=StaticServer(fixture,{'web/index.html':{'path':'web/index.html','size':len(body),'sha256':hashlib.sha256(body).hexdigest()}},backend=self.backend)
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start();origin='http://127.0.0.1:'+str(server.server_port)
        def request(action=None,data=None,headers=None):
            conn=http.client.HTTPConnection('127.0.0.1',server.server_port,timeout=5)
            conn.request('POST' if action else 'GET','/api/workbench' if action else '/api/workbench/bootstrap',json.dumps({'action':action,'data':data}) if action else None,headers or {})
            response=conn.getresponse();raw=response.read();value=(response.status,dict(response.getheaders()),raw);conn.close();return value
        try:
            _,_,raw=request();headers={'Origin':origin,'Content-Type':'application/json','X-Fangyu-CSRF':json.loads(raw)['csrfToken']}
            status,response,raw=request('login',{'username':'fixture-employee','password':'[REDACTED:assigned_secret]','rememberUsername':False},headers)
            self.assertEqual(status,200);self.assertNotIn(b'"token"',raw)
            headers['Cookie']=response['Set-Cookie'].split(';')[0]
            status,_,raw=request('reply_delivery_prepare',{'storeId':'fixture-store-a','items':[item],'requestId':'http-prepare'},headers)
            self.assertEqual(status,200);prepared=json.loads(raw)['delivery'];self.assertEqual(self.calls,[])
            data={'storeId':'fixture-store-a','id':prepared['id'],'snapshotDigest':prepared['snapshotDigest'],'confirmed':True,'requestId':'http-send'}
            self.assertEqual(request('reply_delivery_start',data,{**headers,'X-Fangyu-CSRF':'wrong'})[0],403)
            self.assertEqual(request('reply_delivery_start',{**data,'text':'caller-injected-new-text'},headers)[0],400)
            self.assertEqual(self.calls,[])
            sent=threading.Event();self.on_send=lambda _:sent.set()
            self.assertEqual(request('reply_delivery_start',data,headers)[0],200);self.assertTrue(sent.wait(3))
            status,_,raw=request('reply_delivery_status',{'storeId':'fixture-store-a','id':prepared['id']},headers)
            self.assertEqual(status,200);self.assertNotIn(b'"token"',raw);self.assertEqual(json.loads(raw)['delivery']['items'][0]['status'],'sent')
        finally:server.shutdown();server.server_close();thread.join(2)

if __name__=='__main__':unittest.main()
