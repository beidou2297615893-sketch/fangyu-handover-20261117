from pathlib import Path
import sys, threading, unittest
from unittest.mock import patch
sys.dont_write_bytecode=True
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'account-verification-entry/flow-audit'))
from test_delivery import DeliveryTests

class GuardTests(DeliveryTests):
    def setUp(self):
        super().setUp()
        self.backend.core.store.put('accounts',{**self.backend.core.store.get('accounts','fixture-account'),
            'id':'second-account','platform_uid':'second-uid','name':'第二账号'})

    def second(self, author='uid-a', account='second-account', ident='comment-b'):
        original=self.backend.core.store.get('leads','comment-a')
        self.backend.core.store.put('leads',{**original,'id':ident,'source_id':ident,'comment_id':ident,'author_id':author})
        people=self.backend.dispatch('customers',{},self.token)['customers']['items']
        customer=None
        # The customer projection remains the public read boundary.
        for person in people:
            detail=self.backend.dispatch('reply_read',{'storeId':'fixture-store-a','customerId':person['id']},self.token)['replyWorkspace']
            if any(c['id']==ident for c in detail['comments']):customer=person['id'];break
        row=next(c for c in detail['comments'] if c['id']==ident)
        base={'storeId':'fixture-store-a','customerId':customer,'leadId':ident,'sourceDigest':row['sourceDigest'],
              'expectedVersion':0,'expectedReplyId':''}
        saved=next(c for c in self.backend.dispatch('reply_save',{**base,'text':'请问什么时候入住？',
            'requestId':'second-save-'+ident},self.token)['replyWorkspace']['comments'] if c['id']==ident)['draft']
        self.backend.dispatch('reply_review',{**base,'expectedVersion':saved['version'],'expectedReplyId':saved['id'],
            'accountId':account,'confirmed':True,'requestId':'second-review-'+ident},self.token)
        return {'customerId':customer,'leadId':ident,'sourceDigest':row['sourceDigest'],
                'replyId':saved['id'],'version':saved['version'],'accountId':account}

    def prepare(self,item,key):return self.call('reply_delivery_prepare',items=[item],requestId='prepare-'+key)
    def start(self,p,key):return self.call('reply_delivery_start',id=p['id'],snapshotDigest=p['snapshotDigest'],confirmed=True,requestId='send-'+key)

    def test_customer_success_skips_other_account(self):
        a=self.prepare(self.draft(),'a');b=self.prepare(self.second(),'b')
        self.start(a,'a');self.assertEqual(self.wait(a['id'])['sent'],1)
        self.start(b,'b');result=self.wait(b['id'])
        self.assertEqual(len(self.calls),1);self.assertEqual(result['skipped'],1)
        self.assertEqual(result['items'][0]['status'],'skipped');self.assertEqual(result['sent'],0)
        self.assertEqual(self.backend.core.store.get('replies',b['items'][0]['replyId'])['status'],'approved')

    def test_two_accounts_concurrent_reservation(self):
        a=self.prepare(self.draft(),'a');b=self.prepare(self.second(),'b')
        entered=threading.Event();release=threading.Event()
        self.on_send=lambda n:(entered.set(),release.wait(3))
        try:
            self.start(a,'a');self.assertTrue(entered.wait(2));self.start(b,'b')
            result=self.wait(b['id']);self.assertEqual(result['skipped'],1);self.assertEqual(len(self.calls),1)
        finally:release.set()
        self.assertEqual(self.wait(a['id'])['sent'],1)

    def test_unknown_blocks_other_account(self):
        a=self.prepare(self.draft(),'a');b=self.prepare(self.second(),'b');self.outcome='unknown'
        self.start(a,'a');self.assertEqual(self.wait(a['id'])['state'],'stopped')
        self.outcome='sent';self.start(b,'b');result=self.wait(b['id'])
        self.assertEqual(result['skipped'],1);self.assertEqual(len(self.calls),1)

    def test_new_account_has_initial_status(self):
        self.backend.platform_runtime._platform_setup=True
        result=self.backend.dispatch('account_create',{'platform':'xiaohongshu','name':'第二个新增账号'},self.token)
        ident=result['job']['accountId']
        self.assertEqual(self.backend.core.store.get('accounts',ident)['status'],'login_required')
        self.assertEqual(self.backend.core.store.get('accounts','fixture-account')['platform_uid'],'fixture-uid')

    def test_existing_slot_without_status_can_connect_exact_account(self):
        self.backend.platform_runtime._platform_setup=True
        account=self.backend.core.store.get('accounts','second-account')
        account.pop('status');account.pop('platform_uid')
        self.backend.core.store.put('accounts',account)
        runtime=self.backend.platform_runtime
        job={'id':'a'*24,'kind':'assistant_account_login','account_id':'second-account',
             'status':'running','phase':'waiting_browser','worker_done':threading.Event()}
        runtime.server.jobs[job['id']]=job
        try:
            with patch.object(runtime.service,'start_account_login',return_value={'login_job':job['id']}) as start, \
                    patch.object(runtime.service,'account_job_status',return_value={'id':job['id'],'status':'running','phase':'waiting_browser'}):
                result=self.backend.dispatch('account_connect',{'accountId':'second-account'},self.token)
                start.assert_called_once_with('second-account')
                self.assertEqual(result['job']['accountId'],'second-account')
        finally:runtime.server.jobs.pop(job['id'],None)

    def test_skip_continues_to_next_unrelated_customer(self):
        a=self.prepare(self.draft(),'a')
        duplicate=self.second();other=self.second('uid-c',ident='comment-c')
        b=self.call('reply_delivery_prepare',items=[duplicate,other],requestId='prepare-b')
        self.start(a,'a');self.wait(a['id']);self.start(b,'b');result=self.wait(b['id'])
        self.assertEqual(result['state'],'completed');self.assertEqual(result['sent'],1)
        self.assertEqual(result['skipped'],1);self.assertEqual(len(self.calls),2)

    def test_historical_reply_before_upgrade_is_respected(self):
        item=self.second();p=self.prepare(item,'b')
        self.backend.core.store.put('replies',{'id':'historical','tenant_id':self.tenant,'lead_id':'comment-a','status':'sent'})
        self.start(p,'b');self.assertEqual(self.wait(p['id'])['skipped'],1);self.assertEqual(self.calls,[])

    def test_unknown_guard_survives_new_guard_instance(self):
        from reply_delivery import ReplyDelivery
        a=self.prepare(self.draft(),'a');b=self.prepare(self.second(),'b');self.outcome='unknown'
        self.start(a,'a');self.wait(a['id'])
        fresh=object.__new__(ReplyDelivery);fresh.core=self.backend.core
        self.assertTrue(fresh.customer_conflict(self.tenant,self.backend.core.store.get('leads','comment-b')))
        self.outcome='sent';self.start(b,'b');self.assertEqual(self.wait(b['id'])['skipped'],1)

    def test_definite_pre_send_refusal_releases_customer(self):
        a=self.prepare(self.draft(),'a');b=self.prepare(self.second(),'b');self.outcome='busy'
        self.start(a,'a');self.assertEqual(self.wait(a['id'])['sent'],0)
        self.outcome='sent';self.start(b,'b');self.assertEqual(self.wait(b['id'])['sent'],1)

class QueueRegressions(DeliveryTests):
    def items(self,count):
        # Older fixture used one author for all comments; the new requirement
        # intentionally skips those. Distinct customers exercise queue order.
        items=[self.draft()]
        for i in range(1,count):
            item=GuardTests.second(self,author='uid-'+str(i),account='fixture-account',ident='comment-'+str(i))
            items.append(item)
        return items

if __name__=='__main__':
    names=[n for n in GuardTests.__dict__ if n.startswith('test_')]
    suite=unittest.TestSuite(GuardTests(n) for n in names)
    suite.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(QueueRegressions))
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    sys.exit(not result.wasSuccessful())
