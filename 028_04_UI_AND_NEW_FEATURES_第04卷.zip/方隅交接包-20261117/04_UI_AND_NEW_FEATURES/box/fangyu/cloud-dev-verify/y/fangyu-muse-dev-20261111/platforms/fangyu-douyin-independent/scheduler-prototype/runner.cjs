'use strict';
// Explicitly imported building blocks only. Executing this file never contacts a platform.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { spawnSync } = require('node:child_process');
const ROOT = __dirname;
const SECRET = /cookie|authorization|token|password|secret|credential|sessionid/i;
const hash = value => crypto.createHash('sha256').update(value).digest('hex');
const key = task => JSON.stringify([task.kind, task.target, task.store_id, task.keyword]);

// JSON.parse revivers run after Number conversion. Quote large integer lexemes first.
function parseExact(text) {
  if (typeof text !== 'string' || text.length > 32 * 1024 * 1024) throw Error('invalid_body');
  let out = '', at = 0;
  while (at < text.length) {
    if (text[at] === '"') {
      const start = at++;
      while (at < text.length) {
        if (text[at] === '\\') { at += 2; continue; }
        if (text[at++] === '"') break;
      }
      out += text.slice(start, at);
    } else if (text[at] === '-' || /[0-9]/.test(text[at])) {
      const match = text.slice(at).match(/^-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?/);
      if (!match) throw Error('invalid_json_number');
      const number = match[0];
      out += /^-?\d+$/.test(number) && !Number.isSafeInteger(Number(number)) ? JSON.stringify(number) : number;
      at += number.length;
    } else out += text[at++];
  }
  return JSON.parse(out,(_key,value)=>{if(typeof value==='number'&&!Number.isFinite(value))throw Error('nonfinite_json_number');return value;});
}

function scrub(value) {
  if (Array.isArray(value)) return value.map(scrub);
  if (value && typeof value === 'object') return Object.fromEntries(Object.entries(value).map(([k,v]) => [k, SECRET.test(k) ? '[REDACTED]' : scrub(v)]));
  if (typeof value === 'string' && /^https?:\/\//.test(value)) {
    try { const url = new URL(value); for (const name of [...url.searchParams.keys()]) if (SECRET.test(name)) url.searchParams.set(name, '[REDACTED]'); return url.href; } catch {}
  }
  return value;
}

function inside(file) {
  const resolved = path.resolve(file), relative = path.relative(ROOT, resolved);
  if (!relative || relative.startsWith('..') || path.isAbsolute(relative)) throw Error('path_outside_isolated_directory');
  return resolved;
}
function atomic(file, value) {
  const temp = file + '.' + crypto.randomUUID() + '.tmp';
  fs.writeFileSync(temp, JSON.stringify(scrub(value), null, 2), { flag:'wx' });
  fs.renameSync(temp, file);
}

function normalizePlan(input) {
  if (!input || !Array.isArray(input.stores) || input.stores.length !== 15) throw Error('exactly_15_explicit_stores_required');
  for (const name of ['scan_id','account_uid','connection_id','rule_source']) if (typeof input[name] !== 'string' || !input[name].trim()) throw Error('explicit_' + name + '_required');
  const ids = new Set(), terms = new Map();
  const stores = input.stores.map(store => {
    if (!store || typeof store.store_id !== 'string' || !store.store_id.trim() || ids.has(store.store_id)) throw Error('unique_explicit_store_id_required');
    ids.add(store.store_id);
    if (!Array.isArray(store.keywords) || !store.keywords.length || store.keywords.some(term => typeof term !== 'string' || !term.trim())) throw Error('explicit_keywords_required');
    const result = { store_id:store.store_id, name:store.name || store.store_id, keywords:[...new Set(store.keywords.map(x=>x.trim()))],...(store.city?{city:store.city}:{}),...(store.geography_anchors?{geography_anchors:store.geography_anchors}:{}),...(store.aliases?{aliases:store.aliases}:{}) };
    for (const term of result.keywords) {
      if (!terms.has(term)) terms.set(term, {kind:'search',target:term,keyword:term,store_id:store.store_id,store_refs:[],source_refs:[]});
      terms.get(term).store_refs.push(store.store_id);
      terms.get(term).source_refs.push({store_id:store.store_id, keyword:term, source:store.source || input.plan_source || 'explicit_plan'});
    }
    return result;
  });
  const target = input.target_comments ?? 100000;
  if (!Number.isSafeInteger(target) || target < 1 || target > 100000) throw Error('target_must_be_1_to_100000');
  return {...input,stores,target_comments:target,search_tasks:[...terms.values()],sort_order:'comprehensive_default_no_newest_control',candidate_priority:'local_returned_post_time_then_likes_intent_unreviewed'};
}

// Only the GET routes and parameters present in the inspected upstream userscript.
// Raw JSON is returned as TEXT to avoid that helper's lossy reviver and hidden retries.
function buildExpression(spec, count) {
  if (!['search','comments'].includes(spec.kind)) throw Error('read_only_kind_required');
  if (!Number.isSafeInteger(spec.cursor) || spec.cursor < 0 || !Number.isInteger(count) || count < 1 || count > 20) throw Error('invalid_page_arguments');
  if (spec.kind === 'comments' && (typeof spec.target !== 'string' || !/^\d+$/.test(spec.target))) throw Error('exact_video_id_required');
  const params = spec.kind === 'search'
    ? {keyword:spec.target,offset:spec.cursor,count,search_channel:'aweme_general',search_source:'normal_search',query_correct_type:'1',is_filter_search:'0',need_filter_settings:'0',list_type:'single'}
    : {aweme_id:spec.target,cursor:spec.cursor,count,item_type:'0',pc_img_format:'webp',cut_version:'1'};
  const route = spec.kind === 'search' ? '/aweme/v1/web/general/search/single/' : '/aweme/v1/web/comment/list/';
  return `(async()=>{if(location.hostname!=='www.douyin.com'||!window.__bridge||typeof window.__bridge._q!=='function')return {runner_stop:'page_unavailable'};const check=async()=>{const r=await fetch('/aweme/v1/web/user/profile/self/?'+new URLSearchParams(window.__bridge._q()),{credentials:'include',redirect:'error'});if(!r.ok)return false;const d=await r.json();return d.status_code===0&&d.user&&d.user.sec_uid===${JSON.stringify(spec.account_uid)}};if(!await check())return {runner_stop:'identity_not_verified'};const p=new URLSearchParams(Object.assign(window.__bridge._q(),${JSON.stringify(params)}));const r=await fetch(${JSON.stringify(route)}+'?'+p,{credentials:'include',redirect:'error'});const body=await r.text();const matched=await check();return {identity_verified:matched,http_status:r.status,content_type:r.headers.get('content-type')||'',raw_text:body}})()`;
}

const queues = new Map();
const lastConnectionCall = new Map();
const systemClock={now:()=>Date.now(),sleep:ms=>new Promise(resolve=>setTimeout(resolve,ms))};
function createBridgeTransport(bridge, {connection_id, strict_proof,minimum_delay_ms=40000,clock=systemClock}) {
  if (!bridge || typeof bridge.call !== 'function' || typeof bridge.status !== 'function') throw Error('explicit_bridge_client_required');
  if (!strict_proof || strict_proof.verified !== true || typeof strict_proof.source !== 'string' || !strict_proof.source) throw Error('strict_connection_preflight_evidence_required');
  if(!Number.isSafeInteger(minimum_delay_ms)||minimum_delay_ms<30000)throw Error('live_collection_interval_must_be_at_least_30000ms');
  const queueKey = [bridge.host,bridge.port,connection_id].join(':');
  return async (spec, count) => {
    const preceding = queues.get(queueKey) || Promise.resolve();
    const operation = preceding.then(async()=>{
      const remaining=minimum_delay_ms-(clock.now()-(lastConnectionCall.get(queueKey)??-Infinity));
      if(remaining>0)await clock.sleep(remaining);
      const status = await bridge.status();
      const alive = (status.connections?.['douyin.com'] || []).filter(c=>c.alive);
      if (alive.length !== 1 || alive[0].id !== connection_id || spec.connection_id !== connection_id) return {ok:false,transport_error:'connection_changed'};
      let response;
      try{response = await bridge.call({site:'douyin.com',connId:connection_id,expression:buildExpression(spec,count),awaitPromise:true,timeout:30000});}
      finally{lastConnectionCall.set(queueKey,clock.now());}
      if (!response || response.ok !== true || response.connection !== connection_id) return {ok:false,connection:response?.connection,transport_error:'bridge_result_not_established'};
      const body = response.value;
      if (!body || body.identity_verified !== true) return {ok:false,connection:connection_id,transport_error:body?.runner_stop || 'identity_not_verified'};
      const metadata = {http_status:body.http_status,content_type:body.content_type,body_sha256:typeof body.raw_text==='string'?hash(body.raw_text):null,identity_verified:true};
      if (body.http_status !== 200 || /text\/html/i.test(body.content_type || '') || !body.raw_text?.trim()) {
        let value;
        if(typeof body.raw_text==='string'&&!/text\/html/i.test(body.content_type||''))try{value=parseExact(body.raw_text);}catch{}
        return {ok:false,connection:connection_id,transport_error:'http_or_nonjson_stop',transport_meta:metadata,...(value?{value}:{})};
      }
      try { return {ok:true,connection:connection_id,value:parseExact(body.raw_text),transport_meta:metadata}; }
      catch { return {ok:false,connection:connection_id,transport_error:'invalid_json_stop',transport_meta:metadata}; }
    });
    queues.set(queueKey, operation.catch(()=>{}));
    try { return await operation; } catch { return {ok:false,transport_error:'transport_unknown_no_retry'}; }
  };
}

function createLedgerAdapter(database, python = 'python') {
  const db = inside(database);
  function invoke(action, payload) {
    const result = spawnSync(python, [path.join(ROOT,'runner_ledger_adapter.py'), db, action], {input:JSON.stringify(payload),encoding:'utf8',env:{...process.env,PYTHONIOENCODING:'utf-8',PYTHONDONTWRITEBYTECODE:'1'},maxBuffer:8*1024*1024,windowsHide:true});
    if (result.status !== 0) throw Error('isolated_ledger_adapter_failed');
    return JSON.parse(result.stdout);
  }
  return {snapshot:plan=>invoke('snapshot',plan),gate:plan=>invoke('gate',{account_uid:plan.account_uid}),ingest:record=>invoke('ingest',record),pageSeen:record=>invoke('page_seen',record)};
}

function selectTask(plan, snapshot, startIndex = 0, commentStreaks = {}) {
  const searches = plan.search_tasks.map(task=>({...task,...(snapshot.checkpoints[key(task)] || {cursor:0,exhausted:0})}));
  for (let offset=0;offset<plan.stores.length;offset++) {
    const index=(startIndex+offset)%plan.stores.length, store=plan.stores[index];
    const videos=snapshot.videos.filter(task=>task.store_id===store.store_id&&!task.exhausted);
    const terms=searches.filter(task=>task.store_id===store.store_id&&!task.exhausted);
    // At most two comment pages before a search when both types are available.
    // Store fairness is governed by the outer loop, not this local quota.
    const preferComments=(commentStreaks[store.store_id]||0)<2;
    const candidates=[...videos,...terms].sort((a,b)=>{
      if(a.kind!==b.kind)return (a.kind==='comments' ? -1 : 1)*(preferComments?1:-1);
      const pageOrder=(a.pages||0)-(b.pages||0);if(pageOrder)return pageOrder;
      if(a.kind==='comments')return (b.priority_evidence?.published_at_unix??-1)-(a.priority_evidence?.published_at_unix??-1)||(b.priority_evidence?.likes??-1)-(a.priority_evidence?.likes??-1);
      return 0;
    });
    if(candidates.length)return {task:candidates[0],nextIndex:(index+1)%plan.stores.length};
  }
  return null;
}

class Runner {
  constructor({plan,ledger,transport,directory,minimum_delay_ms=40000,clock=systemClock}) {
    this.plan=normalizePlan(plan);this.ledger=ledger;this.transport=transport;
    this.directory=inside(directory);fs.mkdirSync(this.directory,{recursive:true});
    if (!Number.isSafeInteger(minimum_delay_ms)||minimum_delay_ms<30000) throw Error('collection_interval_must_be_at_least_30000ms');
    this.delay=minimum_delay_ms;this.clock=clock;this.active=false;this.lastCallAt=-Infinity;
    this.control=path.join(this.directory,'control.json');
    // This file stores only scheduler fairness / pending evidence, NEVER a cursor.
    if(fs.existsSync(this.control)){const c=JSON.parse(fs.readFileSync(this.control));if(c.scan_id!==this.plan.scan_id||c.plan_digest!==hash(JSON.stringify(this.plan)))throw Error('plan_changed_use_explicit_new_run_directory');this.state=c;}
    else{this.state={scan_id:this.plan.scan_id,plan_digest:hash(JSON.stringify(this.plan)),nextIndex:0,pending:null,stopped:null};this.save();}
    this.lastCallAt=this.state.last_completed_at??-Infinity;
  }
  save(){atomic(this.control,this.state);}
  applySchedule(spec){
    if(this.state.schedule_applied_request===spec.request_id)return;
    const store=spec.schedule_store_id||spec.store_id;
    const index=this.plan.stores.findIndex(x=>x.store_id===store);
    if(index<0)throw Error('schedule_store_not_in_plan');
    this.state.nextIndex=(index+1)%this.plan.stores.length;
    this.state.commentStreaks ||= {};
    this.state.commentStreaks[store]=spec.kind==='comments'?Math.min(2,(this.state.commentStreaks[store]||0)+1):0;
    this.state.schedule_applied_request=spec.request_id;
  }
  stop(reason){this.state.stopped=reason;this.save();return {state:'paused',reason};}
  recoverLocal() {
    if(!this.state.pending)return {state:'nothing_to_recover'};
    const file=inside(this.state.pending.record_path),record=JSON.parse(fs.readFileSync(file,'utf8'));
    if(!record.response||record.spec.request_id!==this.state.pending.request_id)return this.stop('result_unknown_manual_review_no_refetch');
    const receipt=this.ledger.ingest(record);
    atomic(path.join(this.directory,record.spec.request_id+'.receipt.json'),receipt);
    this.state.pending=null;
    if(receipt.state==='parsed')this.applySchedule(record.spec);
    // Explicit recovery clears only the local crash marker. Ledger halts remain authoritative.
    this.state.stopped=receipt.state==='parsed'?null:'ledger_'+receipt.state;
    this.save();return {state:'local_evidence_reconciled',receipt_state:receipt.state};
  }
  resumeLocal(review) {
    if(!review||review.account_uid!==this.plan.account_uid||['operator','reason','rule_source'].some(k=>typeof review[k]!=='string'||!review[k].trim()))throw Error('explicit_matching_local_resume_review_required');
    const current=this.ledger.gate?this.ledger.gate(this.plan):this.ledger.snapshot(this.plan);
    if(!current.can_collect)throw Error('ledger_halt_cannot_be_cleared_by_local_resume');
    if(this.state.pending){
      const record=JSON.parse(fs.readFileSync(inside(this.state.pending.record_path),'utf8'));
      if(this.state.pending.phase!=='prepared'||record.state!=='prepared_not_dispatched'||record.response!==null||record.spec.request_id!==this.state.pending.request_id||record.spec.account_uid!==this.plan.account_uid)throw Error('dispatch_unknown_cannot_resume_or_refetch');
      record.state='cancelled_before_dispatch';record.local_review=review;atomic(this.state.pending.record_path,record);
    }else if(this.state.stopped&&!this.state.stopped.startsWith('local_stop_'))throw Error('only_explicit_user_stop_can_be_locally_resumed');
    const stopFile=path.join(this.directory,'STOP');
    const audit={at:new Date().toISOString(),action:'explicit_local_resume',review,previous_stop:this.state.stopped,pending_cancelled:this.state.pending?.request_id||null,stop_file_sha256:fs.existsSync(stopFile)?hash(fs.readFileSync(stopFile)):null};
    atomic(path.join(this.directory,'resume-'+crypto.randomUUID()+'.json'),audit);
    if(fs.existsSync(stopFile))fs.unlinkSync(stopFile);
    this.state.pending=null;this.state.stopped=null;this.save();return {state:'local_resume_recorded',network_started:false};
  }
  async step() {
    if(this.active)throw Error('runner_step_already_active');
    this.active=true;
    try {
      if(this.state.stopped)return {state:'paused',reason:this.state.stopped};
      if(fs.existsSync(path.join(this.directory,'STOP')))return this.stop('local_stop_requested');
      if(this.state.pending)return this.stop('pending_request_requires_local_review_no_refetch');
      const snap=this.ledger.snapshot(this.plan);
      if(!snap.can_collect)return this.stop('ledger_account_halted');
      if(snap.summary.comments>=this.plan.target_comments)return {state:'target_reached',comments:snap.summary.comments};
      const selection=selectTask(this.plan,snap,this.state.nextIndex,this.state.commentStreaks||{});
      if(!selection)return {state:snap.review_counts?.review_required||snap.review_counts?.unmapped_store?'awaiting_candidate_review':'sources_exhausted',comments:snap.summary.comments,review_counts:snap.review_counts||{}};
      const task=selection.task;
      const spec={request_id:crypto.randomUUID(),account_uid:this.plan.account_uid,connection_id:this.plan.connection_id,scan_id:this.plan.scan_id,rule_source:this.plan.rule_source,kind:task.kind,target:task.target,store_id:task.scope_store_id||task.store_id,keyword:task.scope_keyword||task.keyword,schedule_store_id:task.store_id,cursor:task.cursor,store_refs:task.store_refs||[task.store_id],source_refs:task.source_refs||[],sort_order:this.plan.sort_order,priority_evidence:task.priority_evidence||null,eligibility:task.eligibility||null,requested_at:new Date().toISOString()};
      const wait=this.delay-(this.clock.now()-this.lastCallAt);if(wait>0)await this.clock.sleep(wait);
      if(fs.existsSync(path.join(this.directory,'STOP')))return this.stop('local_stop_requested_before_call');
      // Recheck the persistent account gate immediately before invoking the transport.
      if(!(this.ledger.gate?this.ledger.gate(this.plan):this.ledger.snapshot(this.plan)).can_collect)return this.stop('ledger_account_halted_before_call');
      const recordPath=path.join(this.directory,spec.request_id+'.json');
      atomic(recordPath,{spec,response:null,state:'prepared_not_dispatched'});
      this.state.pending={request_id:spec.request_id,record_path:recordPath,phase:'prepared'};this.save();
      if(fs.existsSync(path.join(this.directory,'STOP')))return this.stop('local_stop_requested_before_dispatch');
      // The durable dispatch boundary precedes calling transport. Unknown can never auto-resume.
      this.state.pending.phase='dispatching';this.save();
      let response;
      try{response=await this.transport(spec,task.kind==='search'?10:Math.min(20,this.plan.target_comments-snap.summary.comments));}
      catch{response={ok:false,transport_error:'transport_unknown_no_retry'};}
      this.lastCallAt=this.clock.now();this.state.last_completed_at=this.lastCallAt;response=scrub(response);
      if(response?.ok===true&&response.value){
        const rows=spec.kind==='search'?response.value.data:response.value.comments;
        if(Array.isArray(rows)&&rows.length){
          const ids=rows.map(row=>spec.kind==='search'?row?.aweme_info?.aweme_id:row?.cid).filter(x=>typeof x==='string');
          if(ids.length){spec.page_items_digest=hash(JSON.stringify([...new Set(ids)].sort()));if(this.ledger.pageSeen({spec}))response={...response,transport_error:'same_items_page_repeated_with_new_cursor'};}
        }
      }
      const record={spec,response};atomic(recordPath,record);
      const receipt=this.ledger.ingest(record);
      atomic(path.join(this.directory,spec.request_id+'.receipt.json'),receipt);
      this.state.pending=null;
      if(receipt.state!=='parsed')return this.stop('ledger_'+receipt.state);
      this.applySchedule(spec);
      this.save();
      return {state:'page_committed',kind:spec.kind,added:receipt.added,request_id:spec.request_id};
    } finally {this.active=false;}
  }
}

// Advisory cross-process lease for this runner family. Never remove a stale lease automatically.
function acquireLease({connection_id,database}) {
  const files=[path.join(ROOT,'runner-lease-connection-'+hash(connection_id).slice(0,24)+'.json'),path.join(ROOT,'runner-lease-database-'+hash(inside(database)).slice(0,24)+'.json')],owned=[];
  try{for(const file of files){fs.writeFileSync(file,JSON.stringify({pid:process.pid,created_at:new Date().toISOString(),note:'manual_review_if_stale'}),{flag:'wx'});owned.push(file);}}
  catch(error){for(const file of owned)fs.unlinkSync(file);throw Error('connection_or_database_already_leased_manual_review_required');}
  return ()=>{for(const file of owned)fs.unlinkSync(file);};
}
module.exports={parseExact,scrub,normalizePlan,buildExpression,createBridgeTransport,createLedgerAdapter,selectTask,Runner,acquireLease};

async function main(args) {
  if(!args.includes('--run')&&!args.includes('--recover-local')&&!args.includes('--resume-local')){console.log('Offline by default. Explicit --run and verified plan/config/identity/strict-proof paths are required.');return;}
  const opts={};
  for(let i=0;i<args.length;i++){const name=args[i];if(['--run','--recover-local','--resume-local'].includes(name)){opts[name]=true;continue;}if(!['--plan','--bridge-config','--identity-probe','--strict-proof','--database','--directory','--minimum-delay-ms','--python','--review','--max-pages','--qualification-policy'].includes(name)||!args[i+1]||args[i+1].startsWith('--'))throw Error('invalid_cli_arguments');opts[name]=args[++i];}
  for(const name of ['--plan','--database','--directory'])if(!opts[name])throw Error('missing_'+name.slice(2));
  const read=file=>JSON.parse(fs.readFileSync(file,'utf8').replace(/^\uFEFF/,''));
  const rawPlan=read(opts['--plan']);if(opts['--qualification-policy'])rawPlan.qualification_policy=read(opts['--qualification-policy']);
  const plan=normalizePlan(rawPlan);
  const release=acquireLease({connection_id:plan.connection_id,database:opts['--database']});
  try{
    const ledger=createLedgerAdapter(opts['--database'],opts['--python']||'python');
    if(opts['--resume-local']){if(!opts['--review'])throw Error('explicit_review_file_required');const r=new Runner({plan,ledger,transport:()=>{throw Error('offline_resume_only');},directory:opts['--directory']});console.log(JSON.stringify(r.resumeLocal(read(opts['--review']))));return;}
    if(opts['--recover-local']){const r=new Runner({plan,ledger,transport:()=>{throw Error('offline_recovery_only');},directory:opts['--directory']});console.log(JSON.stringify(r.recoverLocal()));return;}
    for(const name of ['--bridge-config','--identity-probe','--strict-proof'])if(!opts[name])throw Error('missing_'+name.slice(2));
    const config=read(opts['--bridge-config']),identity=read(opts['--identity-probe']),proof=read(opts['--strict-proof']);
    if(config.bridge?.host!=='127.0.0.1'||!Number.isInteger(config.bridge.port)||config.bridge.port<1||config.bridge.port>65535)throw Error('explicit_loopback_bridge_required');
    if(identity.connection_id!==plan.connection_id||identity.account?.sec_uid!==plan.account_uid)throw Error('plan_identity_mismatch');
    if(proof.connection_id!==plan.connection_id||proof.account_uid!==plan.account_uid)throw Error('strict_proof_scope_mismatch');
    const {BridgeClient}=require(path.resolve(ROOT,'../runtime/douyin-bridge/lib/client/bridge-client'));
    const delay=opts['--minimum-delay-ms']===undefined?40000:Number(opts['--minimum-delay-ms']);
    const transport=createBridgeTransport(new BridgeClient(config.bridge),{connection_id:plan.connection_id,strict_proof:proof,minimum_delay_ms:delay});
    const runner=new Runner({plan,ledger,transport,directory:opts['--directory'],minimum_delay_ms:delay});
    const maximum=opts['--max-pages']===undefined?Infinity:Number(opts['--max-pages']);if(maximum!==Infinity&&(!Number.isSafeInteger(maximum)||maximum<1))throw Error('invalid_max_pages');
    const requestStop=()=>{fs.writeFileSync(path.join(runner.directory,'STOP'),'Operator requested stop. Finish and persist any in-flight page.\n');};
    process.on('SIGINT',requestStop);process.on('SIGTERM',requestStop);
    try{let pages=0;while(true){const receipt=await runner.step();console.log(JSON.stringify(receipt));if(receipt.state!=='page_committed'){if(receipt.state==='paused')process.exitCode=2;break;}if(++pages>=maximum){console.log(JSON.stringify({state:'bounded_batch_complete',pages}));break;}}}
    finally{process.removeListener('SIGINT',requestStop);process.removeListener('SIGTERM',requestStop);}
  }finally{release();}
}
if(require.main===module)main(process.argv.slice(2)).catch(()=>{console.error('Runner stopped. Inspect isolated local evidence; no automatic retry.');process.exitCode=1;});
