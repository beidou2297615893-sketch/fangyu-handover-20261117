from pathlib import Path
import hashlib,json
T=Path(__file__).resolve().parent
S=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project')
def replace(path,old,new):
    p=S/path;b=p.read_text('utf-8');assert b.count(old)==1,(old,b.count(old));b=b.replace(old,new);compile(b,str(p),'exec');p.write_bytes(b.encode('utf-8'))
replace('work/ui-runtime-r55/src/core/xhs_verified_resume.py',"from .xhs_identity_recovery import read_activity, rows_of, scan_activity, digest","from .xhs_identity_recovery import read_activity, rows_of, scan_activity, digest, IdentityRecoveryError")
replace('work/ui-runtime-r55/src/core/xhs_verified_resume.py',"    error=payload.get('error') if type(payload) is dict else None","    if type(payload) is not dict or payload.get('ok') is not False:return False\n    error=payload.get('error')")
replace('work/ui-runtime-r55/src/core/xhs_verified_resume.py',"except (OSError,ValueError,TypeError,KeyError):return {}","except (OSError,ValueError,TypeError,KeyError,IdentityRecoveryError):return {}")
replace('work/shared-backend-integration/platform_runtime.py',"            result=self._recover_xhs_identity(user,account)\n            if result.get('result',{}).get('platformLoginConfirmed') is not True:","            try:result=self._recover_xhs_identity(user,account)\n            except PlatformRuntimeError as error:\n                if error.code=='RECOVERY_NOT_ELIGIBLE':\n                    raise PlatformRuntimeError(error.code,'该账号还保留未完成的读取记录，本次未恢复采集；原任务和数据已保留，请联系管理员处理',409) from None\n                raise\n            if result.get('result',{}).get('platformLoginConfirmed') is not True:")
replace('work/shared-backend-integration/platform_runtime.py',"        return self.resume_acquisition(user,data)\n\n    def account_job", "        response=self.resume_acquisition(user,data)\n        response['result'].update(accountId=account['id'])\n        return response\n\n    def account_job")
replace('work/shared-backend-integration/platform_runtime.py',"        start(ident,directory,scope,guard,recover_unsent=control.get('recover_unsent') is True,verified_retry=control.get('verified_retry'))", "        from assistant.browser_session_commit import account_revision\n        if any(grant.get('account_revision')!=account_revision(original) for grant in (control.get('verified_retry') or {}).values()):\n            raise PlatformRuntimeError('ACCOUNT_SCOPE_CHANGED','验证后的账号状态已变化，请保留原任务',409)\n        start(ident,directory,scope,guard,recover_unsent=control.get('recover_unsent') is True,verified_retry=control.get('verified_retry'))")
changes=json.loads((T/'SOURCE-CHANGES.json').read_text('utf-8'))
for row in changes:row['after']=hashlib.sha256((S/row['path']).read_bytes()).hexdigest()
(T/'SOURCE-CHANGES.json').write_bytes((json.dumps(changes,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
print('PASS_BACKEND_SYNTAX')
