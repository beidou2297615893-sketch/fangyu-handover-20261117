"""Public dispatch, real preserved Core/SQLite, external enterprise HTTP fixture."""
from pathlib import Path
import sys
import tempfile
import unittest
import json
import http.client
import threading
import hashlib
from concurrent.futures import ThreadPoolExecutor
from unittest.mock import patch

ROOT=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project')
sys.dont_write_bytecode = True
sys.path[:0] = [str(ROOT/'work/ui-native-r57'), str(ROOT/'work/ui-runtime-r55/src')]
from test_workbench_backend import CloudFixture
from customer_workbench import CustomerWorkbench
from workbench_backend import WorkbenchBackend, WorkbenchError
from ui_native_host import StaticServer


class ReplyWorkflowTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(dir=Path(__file__).parent)
        self.cloud = CloudFixture()
        self.cloud.user['can_reply'] = True
        self.network = patch('integrations.request_json', side_effect=self.cloud)
        self.network.start()
        self.company = {'id':'fangyu-apartment-client','edition':'customer',
            'personalMode':False,'authMode':'managed','managedWorkspace':{
                'environment_id':'fixture-env','endpoint':'https://example.invalid/workspace'}}
        self.backends = []
        self.backend = self.open()
        self.token = self.backend.dispatch('login', {'username':'fixture-employee',
            'password':'[REDACTED:assigned_secret]','rememberUsername':False})['token']
        user = self.backend.core.session(self.token)
        self.tenant = user['tenant_id']
        for ident in ('comment-a','comment-b'):
            self.backend.core.store.put('leads', {'id':ident,'tenant_id':self.tenant,
                'cloud_owner':'fixture-employee','platform':'xiaohongshu','source_type':'comment',
                'source_id':ident,'comment_id':ident,'author_id':'uid-one','author':'真实测试客户',
                'text':'原评论 '+ident,'content_title':'原始帖子',
                'note_url':'https://www.xiaohongshu.com/explore/123456789012345678901234'})
        self.customer = self.backend.dispatch('customers',{},self.token)['customers']['items'][0]['id']

    def open(self):
        backend = WorkbenchBackend(ROOT,data_dir=self.temp.name,company=self.company,
                                   customer_factory=CustomerWorkbench)
        self.backends.append(backend)
        return backend

    def tearDown(self):
        for backend in self.backends: backend.close()
        self.network.stop()
        self.temp.cleanup()

    def call(self, action, **data):
        return self.backend.dispatch(action,{'storeId':'fixture-store-a',
            'customerId':self.customer,**data},self.token)['replyWorkspace']

    def test_selected_original_comment_save_reopen_and_review_never_marks_sent(self):
        read = self.call('reply_read')
        self.assertEqual(len(read['comments']),2)
        original = next(row for row in read['comments'] if row['id']=='comment-b')
        self.assertIsNone(original['draft'])
        payload = dict(leadId='comment-b',text='请问你预计什么时候入住？',expectedVersion=0,
            expectedReplyId='',sourceDigest=original['sourceDigest'],requestId='fixture-save-one')
        saved = self.call('reply_save',**payload)
        draft = next(row for row in saved['comments'] if row['id']=='comment-b')['draft']
        self.assertEqual((draft['text'],draft['version'],draft['status']),('请问你预计什么时候入住？',1,'draft'))
        self.backend = self.open()
        reopened = self.call('reply_read')
        self.assertEqual(next(row for row in reopened['comments'] if row['id']=='comment-b')['draft'],draft)
        self.assertIsNone(next(row for row in reopened['comments'] if row['id']=='comment-a')['draft'])
        checked = self.call('reply_check',leadId='comment-b',requestId='fixture-save-one')
        self.assertEqual(checked['receipt']['state'],'accepted')
        self.assertFalse(self.backend.dispatch('customers',{},self.token)['customers']['items'][0]['replied'])

    def save_payload(self, request_id='fixture-save-one', text='请问你预计什么时候入住？'):
        row=next(r for r in self.call('reply_read')['comments'] if r['id']=='comment-b')
        return dict(leadId=row['id'],text=text,expectedVersion=row['draft']['version'] if row['draft'] else 0,
            expectedReplyId=row['draft']['id'] if row['draft'] else '',sourceDigest=row['sourceDigest'],requestId=request_id)

    def test_versions_idempotency_review_account_and_source_are_preserved(self):
        payload=self.save_payload()
        saved=self.call('reply_save',**payload)
        same=self.call('reply_save',**payload)
        self.assertEqual(saved['receipt'],same['receipt'])
        with self.assertRaises(WorkbenchError) as error:
            self.call('reply_save',**{**payload,'requestId':'another-window'})
        self.assertEqual(error.exception.code,'REPLY_VERSION_CONFLICT')
        row=next(r for r in saved['comments'] if r['id']=='comment-b')
        self.backend.core.store.put('accounts',{'id':'my-account','tenant_id':self.tenant,
            'cloud_owner':'fixture-employee','platform':'xiaohongshu','name':'本人测试账号'})
        review={k:v for k,v in self.save_payload().items() if k!='text'}
        review.update(requestId='review-one',accountId='my-account',confirmed=True)
        checked=self.call('reply_review',**review)
        draft=next(r for r in checked['comments'] if r['id']=='comment-b')['draft']
        self.assertEqual((draft['status'],draft['review_account_id']),('approved','my-account'))
        self.assertFalse(checked['item']['replied'])
        self.assertFalse(checked['sendAvailable'])
        changed=self.backend.core.store.get('leads','comment-b')
        changed['text']='原评论已修改'
        self.backend.core.store.put('leads',changed)
        with self.assertRaises(WorkbenchError) as stale:
            self.call('reply_save',**{**review,'text':'新草稿','requestId':'changed-source',
                **{'accountId':'my-account','confirmed':True}})
        self.assertEqual(stale.exception.code,'INPUT_INVALID')
        fresh=self.save_payload('changed-source')
        with self.assertRaises(WorkbenchError) as source:
            self.call('reply_save',**{**fresh,'sourceDigest':row['sourceDigest']})
        self.assertEqual(source.exception.code,'REPLY_SOURCE_CHANGED')

    def test_fresh_permission_store_foreign_comments_and_strict_schema(self):
        payload=self.save_payload()
        for bad in ({**payload,'text':{}},{**payload,'text':'x'*1001},{**payload,'expectedVersion':True},
                    {**payload,'owner':'other'},{**payload,'leadId':'foreign-comment'},
                    {**payload,'storeId':[]},{**payload,'storeId':{}}):
            with self.subTest(bad=bad),self.assertRaises(WorkbenchError):
                self.call('reply_save',**bad)
        self.cloud.user['can_reply']=False
        read=self.call('reply_read')
        self.assertTrue(all(not row['canSave'] for row in read['comments']))
        with self.assertRaises(WorkbenchError) as permission:
            self.call('reply_save',**payload)
        self.assertEqual(permission.exception.code,'REPLY_FORBIDDEN')
        self.cloud.user['store_id']='different-store'
        with self.assertRaises(WorkbenchError) as store:
            self.call('reply_read')
        self.assertIn(store.exception.code,('STORE_FORBIDDEN','STORE_REQUIRED'))
        self.cloud.revoked=True
        with self.assertRaises(WorkbenchError) as revoked:
            self.call('reply_read')
        self.assertEqual(revoked.exception.code,'AUTH_REQUIRED')

    def test_committed_draft_with_failed_audit_is_observed_without_replaying(self):
        payload=self.save_payload('audit-response-lost')
        with self.backend.core.store.connect() as db:
            db.execute("CREATE TRIGGER fail_reply_audit BEFORE INSERT ON records WHEN NEW.entity='audit' BEGIN SELECT RAISE(ABORT,'owned audit failure'); END")
        with self.assertRaises(WorkbenchError) as lost:
            self.call('reply_save',**payload)
        self.assertEqual(lost.exception.code,'REPLY_RESULT_UNCONFIRMED')
        with self.backend.core.store.connect() as db: db.execute('DROP TRIGGER fail_reply_audit')
        self.backend=self.open()
        read=self.call('reply_read')
        row=next(r for r in read['comments'] if r['id']=='comment-b')
        self.assertEqual(row['pendingRequestId'],'audit-response-lost')
        with self.assertRaises(WorkbenchError) as duplicate:
            self.call('reply_save',**self.save_payload('new-request-must-not-replay'))
        self.assertEqual(duplicate.exception.code,'REPLY_RESULT_UNCONFIRMED')
        checked=self.call('reply_check',leadId='comment-b',requestId='audit-response-lost')
        self.assertEqual(checked['receipt']['state'],'observed')
        self.assertEqual(next(r for r in checked['comments'] if r['id']=='comment-b')['draft']['version'],1)
        self.call('reply_save',**self.save_payload('user-explicit-next-edit','下一版草稿'))
        self.assertEqual(next(r for r in self.call('reply_read')['comments'] if r['id']=='comment-b')['draft']['version'],2)

    def test_real_storage_failure_before_change_and_known_core_rejection_can_recover(self):
        payload=self.save_payload('before-write-failure')
        with self.backend.core.store.connect() as db:
            db.execute("CREATE TRIGGER fail_reply_write BEFORE INSERT ON records WHEN NEW.entity='replies' BEGIN SELECT RAISE(ABORT,'owned reply failure'); END")
        with self.assertRaises(WorkbenchError) as lost: self.call('reply_save',**payload)
        self.assertEqual(lost.exception.code,'REPLY_RESULT_UNCONFIRMED')
        with self.backend.core.store.connect() as db: db.execute('DROP TRIGGER fail_reply_write')
        checked=self.call('reply_check',leadId='comment-b',requestId='before-write-failure')
        self.assertEqual(checked['receipt']['state'],'not_applied')
        self.call('reply_save',**self.save_payload('known-template','你好，{待填内容}'))
        self.backend.core.store.put('accounts',{'id':'my-account','tenant_id':self.tenant,
            'cloud_owner':'fixture-employee','platform':'xiaohongshu'})
        review={k:v for k,v in self.save_payload('reject-template').items() if k!='text'}
        with self.assertRaises(WorkbenchError) as rejected:
            self.call('reply_review',**review,accountId='my-account',confirmed=True)
        self.assertEqual(rejected.exception.code,'REPLY_REJECTED')
        self.assertEqual(self.call('reply_check',leadId='comment-b',requestId='reject-template')['receipt']['state'],'rejected')

    def test_changed_source_closes_uncertain_receipt_without_revalidating_old_review(self):
        payload=self.save_payload('saved-before-source-change','保留的原操作文字')
        with self.backend.core.store.connect() as db:
            db.execute("CREATE TRIGGER fail_reply_receipt BEFORE INSERT ON records WHEN NEW.entity='ui_reply_requests_v1' AND json_extract(NEW.body,'$.state')='accepted' BEGIN SELECT RAISE(ABORT,'owned receipt failure'); END")
        with self.assertRaises(WorkbenchError):self.call('reply_save',**payload)
        with self.backend.core.store.connect() as db:db.execute('DROP TRIGGER fail_reply_receipt')
        lead=self.backend.core.store.get('leads','comment-b');lead['text']='原评论后来改过';self.backend.core.store.put('leads',lead)
        checked=self.call('reply_check',leadId='comment-b',requestId='saved-before-source-change')
        self.assertEqual(checked['receipt']['state'],'changed')
        self.assertEqual(checked['receipt']['attemptText'],'保留的原操作文字')
        row=next(r for r in checked['comments'] if r['id']=='comment-b')
        self.assertEqual((row['draft']['version'],row['draft']['text']),(1,'保留的原操作文字'))
        self.assertFalse(row['pendingRequestId'])
        self.backend.core.store.put('accounts',{'id':'my-account','tenant_id':self.tenant,
            'cloud_owner':'fixture-employee','platform':'xiaohongshu'})
        review={k:v for k,v in self.save_payload('review-current-source').items() if k!='text'}
        reviewed=self.call('reply_review',**review,accountId='my-account',confirmed=True)
        self.assertTrue(next(r for r in reviewed['comments'] if r['id']=='comment-b')['reviewCurrent'])
        lead['text']='又一次变更后的原评论';self.backend.core.store.put('leads',lead)
        current=next(r for r in self.call('reply_read')['comments'] if r['id']=='comment-b')
        self.assertFalse(current['reviewCurrent']);self.assertTrue(current['canSave'])

    def test_concurrent_saves_and_older_receipt_do_not_overwrite_latest_draft(self):
        first=self.save_payload('window-one','窗口一草稿')
        second={**first,'requestId':'window-two','text':'窗口二草稿'}
        def save(data):
            try:return self.call('reply_save',**data)
            except WorkbenchError as error:return error.code
        with ThreadPoolExecutor(max_workers=2) as pool: results=list(pool.map(save,(first,second)))
        self.assertEqual(sum(isinstance(row,dict) for row in results),1)
        self.assertIn('REPLY_VERSION_CONFLICT',results)
        accepted=next(row for row in results if isinstance(row,dict))
        old_request=accepted['receipt']['requestId']
        self.call('reply_save',**self.save_payload('next-edit','最终新草稿'))
        checked=self.call('reply_check',leadId='comment-b',requestId=old_request)
        latest=next(r for r in checked['comments'] if r['id']=='comment-b')['draft']
        self.assertEqual((latest['text'],latest['version']),('最终新草稿',2))
        self.assertNotEqual(checked['receipt']['reply']['text'],latest['text'])

    def test_same_origin_http_roundtrip_and_csrf_keep_tokens_out_of_json(self):
        fixture=Path(self.temp.name)/'owned-http';(fixture/'web').mkdir(parents=True)
        body=b'<!doctype html><title>Owned reply transport fixture</title>'
        (fixture/'web/index.html').write_bytes(body)
        files={'web/index.html':{'path':'web/index.html','size':len(body),'sha256':hashlib.sha256(body).hexdigest()}}
        server=StaticServer(fixture,files,backend=self.backend)
        worker=threading.Thread(target=server.serve_forever,daemon=True);worker.start()
        origin='http://127.0.0.1:'+str(server.server_port)
        def request(action=None,data=None,headers=None):
            connection=http.client.HTTPConnection('127.0.0.1',server.server_port,timeout=5)
            connection.request('POST' if action else 'GET','/api/workbench' if action else '/api/workbench/bootstrap',
                json.dumps({'action':action,'data':data}) if action else None,headers or {})
            response=connection.getresponse();raw=response.read();result=(response.status,dict(response.getheaders()),raw)
            connection.close();return result
        try:
            _,_,raw=request();csrf=json.loads(raw)['csrfToken']
            headers={'Origin':origin,'Content-Type':'application/json','X-Fangyu-CSRF':csrf}
            status,response,raw=request('login',{'username':'fixture-employee','password':'[REDACTED:assigned_secret]',
                'rememberUsername':False},headers)
            self.assertEqual(status,200);self.assertNotIn(b'fixture-cloud-access',raw);self.assertNotIn(b'"token"',raw)
            headers['Cookie']=response['Set-Cookie'].split(';')[0]
            data={'storeId':'fixture-store-a','customerId':self.customer}
            status,_,raw=request('reply_read',data,headers)
            self.assertEqual(status,200)
            row=next(r for r in json.loads(raw)['replyWorkspace']['comments'] if r['id']=='comment-b')
            self.assertEqual(request('reply_read',data,{**headers,'X-Fangyu-CSRF':'wrong'})[0],403)
            self.assertEqual(request('reply_read',{**data,'owner':'other'},headers)[0],400)
            payload={'leadId':row['id'],'text':'通过同源HTTP保存的草稿','expectedVersion':0,
                'expectedReplyId':'','sourceDigest':row['sourceDigest'],'requestId':'http-save'}
            status,_,raw=request('reply_save',{**data,**payload},headers)
            self.assertEqual(status,200)
            self.assertEqual(json.loads(raw)['replyWorkspace']['receipt']['state'],'accepted')
            status,_,raw=request('reply_check',{**data,'leadId':'comment-b','requestId':'http-save'},headers)
            self.assertEqual(status,200);self.assertNotIn(b'"token"',raw)
            self.assertEqual(request('send_reply',{},headers)[0],403)
        finally:
            server.shutdown();server.server_close();worker.join(2)


if __name__ == '__main__': unittest.main()
