from pathlib import Path
import importlib.util,unittest,sys,os
sys.dont_write_bytecode=True
S=Path(os.environ.get('FANGYU_TEST_PROJECT','C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project'))
spec=importlib.util.spec_from_file_location('connection_repair_runtime',S/'work/shared-backend-integration/platform_runtime.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class AnalysisAdmission(unittest.TestCase):
 def setUp(self):
  self.page={'id':'original-task','tenant_id':'tenant','owner':'employee','status':'pending','code':'','lead_ids':['comment-original']}
  self.job={'id':'original-task','tenant_id':'tenant','owner':'employee','status':'completed','code':'','pending':0}
 def test_completed_attempt_with_saved_unprocessed_comments_does_not_block_a_new_explicit_batch(self):
  self.assertFalse(m.analysis_blocks_new_batch(self.page,self.job))
  self.assertEqual(self.page['lead_ids'],['comment-original'])
 def test_uncertain_and_active_analysis_still_block(self):
  for status,code,pending in [('running','',1),('paused','AI_BILLING_UNKNOWN',1),('unknown','AI_PROVIDER_TIMEOUT',1),('completed','',2)]:
   with self.subTest(status=status,code=code):self.assertTrue(m.analysis_blocks_new_batch(self.page,{**self.job,'status':status,'code':code,'pending':pending}))
  self.assertTrue(m.analysis_blocks_new_batch({**self.page,'code':'AI_BILLING_UNKNOWN'},self.job))
 def test_identity_mismatch_or_missing_receipt_never_unblocks(self):
  self.assertTrue(m.analysis_blocks_new_batch(self.page,{**self.job,'owner':'another'}))
  self.assertTrue(m.analysis_blocks_new_batch(self.page,{}))
 def test_no_saved_analysis_is_not_a_block(self):self.assertFalse(m.analysis_blocks_new_batch(None,{}))
if __name__=='__main__':unittest.main(verbosity=2)
