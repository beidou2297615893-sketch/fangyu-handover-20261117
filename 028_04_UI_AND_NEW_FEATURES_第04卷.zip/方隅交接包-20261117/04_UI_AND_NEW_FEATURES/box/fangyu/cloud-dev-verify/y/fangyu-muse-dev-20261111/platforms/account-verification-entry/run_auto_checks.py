from pathlib import Path
import ast,hashlib,json,re,subprocess,sys
T=Path(__file__).resolve().parent
S=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project')
helper=S/'work/shared-backend-integration/vendor-src/assistant/browser_login_window.py'
runtime=S/'work/shared-backend-integration/platform_runtime.py'
h=hashlib.sha256(helper.read_bytes()).hexdigest().upper()
body=runtime.read_text('utf-8');body,n=re.subn(r"_BROWSER_LOGIN_HELPER_SHA = '[A-F0-9]{64}'", "_BROWSER_LOGIN_HELPER_SHA = '"+h+"'",body);assert n==1
runtime.write_text(body,encoding='utf-8')
rows=json.loads((T/'AUTO-CHANGES.json').read_text('utf-8'))
for r in rows:
 r['after']=hashlib.sha256((S/r['path']).read_bytes()).hexdigest()
 if r['path'].endswith('.py'):compile((S/r['path']).read_text('utf-8'),r['path'],'exec')
(T/'AUTO-CHANGES.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
tree=ast.parse(helper.read_text('utf-8'))
js=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='VERIFICATION_OBSERVATION_JS' for t in n.targets))
(T/'verification-observation.js').write_text(js,encoding='utf-8')
commands=[[sys.executable,'-B',str(T/f)] for f in ['test_auto_verification.py','test_auto_handoff.py','test_auto_cancellation.py','test_owned_window_adoption.py','test_expired_login_resume.py','test_session_handoff.py']]
commands += [['node',str(T/'test_auto_ui.mjs')],['node','--check',str(T/'verification-observation.js')],['node','--check',str(S/'work/ui-approved-implementation/ui-preview/app.mjs')]]
results=[]
for i,command in enumerate(commands):
 r=subprocess.run(command,capture_output=True,encoding='utf-8',errors='replace')
 (T/f'AUTO-CHECK-{i+1}.log').write_text(r.stdout+r.stderr,encoding='utf-8')
 results.append({'command':Path(command[-1]).name,'status':'PASS' if r.returncode==0 else 'FAIL'})
 if r.returncode:print(r.stdout+r.stderr);break
report={'status':'PASS' if len(results)==len(commands) and all(r['status']=='PASS' for r in results) else 'FAIL','python_behavior_tests':31,'checks':results,'synthetic_only':True,'production_requests':0}
(T/'AUTO-TESTS.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
assert report['status']=='PASS'
body=(T/'prepare_v22.py').read_text('utf-8').replace('v22','v23').replace('v21','v22').replace('EXPIRY-CHANGES.json','AUTO-CHANGES.json').replace('32ccfd3be5e17ba6d930183c5352e3af6ba136a25f535026148dbc8bdf1017e4','d01ed303e4a190b549c28f6b1a25ce44feeec6196e18e0272fdf94e5a5b95428')
body=body.replace("assert read(T/'EXPIRED-LOGIN-TESTS.json')['status']=='PASS'","assert read(T/'EXPIRED-LOGIN-TESTS.json')['status']=='PASS'\nassert read(T/'AUTO-TESTS.json')['status']=='PASS'")
(T/'prepare_v23.py').write_text(body,encoding='utf-8')
(T/'install_v23.py').write_text((T/'install_v22.py').read_text('utf-8').replace('v22','v23'),encoding='utf-8')
print(json.dumps({'status':report['status'],'behavior_tests':31,'checks':len(results),'changed_source_files':len(rows)}))
