'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const {createBridgeTransport}=require('./runner.cjs');
const page='target-pinned-page', other='unrelated-page';
const spec={connection_id:page,account_uid:'synthetic',kind:'comments',target:'1234',cursor:0};
function harness(connections,returned=page){let calls=[];const clock={now:()=>0,sleep:async()=>{}};
 const bridge={host:'test',port:77,status:async()=>({connections:{'douyin.com':connections}}),call:async(args)=>{calls.push(args);return {ok:true,connection:returned,value:{identity_verified:true,http_status:200,content_type:'application/json',raw_text:'{"status_code":0,"comments":[]}'}};}};
 return {calls,transport:createBridgeTransport(bridge,{connection_id:page,strict_proof:{verified:true,source:'synthetic-proof'},minimum_delay_ms:30000,clock})};}
test('additional live tabs do not change target and call is exact connId',async()=>{let h=harness([{id:other,alive:true},{id:page,alive:true}]);let r=await h.transport(spec,20);assert.equal(r.ok,true);assert.equal(h.calls.length,1);assert.equal(h.calls[0].connId,page);assert.equal(h.calls[0].site,'douyin.com');});
test('missing target stops before call despite other tabs',async()=>{let h=harness([{id:other,alive:true}]);let r=await h.transport(spec,20);assert.equal(r.transport_error,'connection_changed');assert.equal(h.calls.length,0);});
test('target reported twice stops before call',async()=>{let h=harness([{id:page,alive:true},{id:page,alive:true}]);let r=await h.transport(spec,20);assert.equal(r.transport_error,'connection_changed');assert.equal(h.calls.length,0);});
test('dead target and spec mismatch both stop before call',async()=>{let h=harness([{id:page,alive:false},{id:other,alive:true}]);assert.equal((await h.transport(spec,20)).transport_error,'connection_changed');assert.equal(h.calls.length,0);h=harness([{id:page,alive:true}]);assert.equal((await h.transport({...spec,connection_id:other},20)).transport_error,'connection_changed');assert.equal(h.calls.length,0);});
test('unexpected returned connection is never accepted',async()=>{let h=harness([{id:page,alive:true},{id:other,alive:true}],other);let r=await h.transport(spec,20);assert.equal(r.ok,false);assert.equal(r.transport_error,'bridge_result_not_established');assert.equal(h.calls[0].connId,page);});
test('strict proof required independently of tab list',()=>{assert.throws(()=>createBridgeTransport({status(){},call(){}},{connection_id:page,strict_proof:{verified:false,source:'synthetic'}}));});
