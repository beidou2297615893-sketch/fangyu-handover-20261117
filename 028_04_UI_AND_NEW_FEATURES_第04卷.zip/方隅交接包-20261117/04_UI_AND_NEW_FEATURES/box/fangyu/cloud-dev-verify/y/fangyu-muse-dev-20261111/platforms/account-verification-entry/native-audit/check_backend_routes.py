"""Real new route/runtime method AST; fake owner records/window and no HTTP/UI."""
from pathlib import Path
from types import SimpleNamespace,MethodType,ModuleType
from copy import deepcopy
from contextlib import contextmanager
import ast,hashlib,json,os,re,stat,sys,tempfile,threading
from datetime import datetime,timezone
P=Path('C:/积木软件工坊/项目/方隅公寓客户版')
S=P/'work/parallel-integration-20261018/final-integration/stage-02/project'
O=Path(__file__).resolve().parent
R=S/'work/shared-backend-integration/platform_runtime.py';B=S/'work/ui-native-r57/workbench_backend.py';H=S/'work/ui-native-r57/ui_native_host.py'
class RuntimeError_(ValueError):
    def __init__(self,code,message='',status=400):self.code,self.status=code,status;super().__init__(message)
def method(path,cls,name,extra=None):
    tree=ast.parse(path.read_text('utf-8-sig'));cl=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name==cls);fn=next(n for n in cl.body if isinstance(n,ast.FunctionDef) and n.name==name);fn.decorator_list=[]
    space={'re':re,'hashlib':hashlib,'json':json,'deepcopy':deepcopy,'threading':threading,'PlatformRuntimeError':RuntimeError_,'WorkbenchError':RuntimeError_,'COMPANY_ID':'fangyu-apartment-client'}
    if extra:space.update(extra)
    exec(compile(ast.Module(body=[fn],type_ignores=[]),str(path),'exec'),space);return space[name]
results=[]
def check(name,fn):
    try:fn();results.append({'name':name,'status':'PASS'})
    except Exception as error:results.append({'name':name,'status':'FAIL','error':type(error).__name__+': '+str(error)})
def rejects(fn,code=None):
    try:fn()
    except RuntimeError_ as error:
        if code:assert error.code==code,(error.code,code)
        return error
    raise AssertionError('Operation was accepted')

def gateway(action,data):
    calls=[];user={'id':'user','username':'worker','tenant_id':'tenant','role':'operator'}
    def route(name):return lambda actor,payload:(calls.append((name,deepcopy(payload))) or {'result':{'status':'verification_open','taskId':payload['taskId'],'accountId':'task-account','windowOpen':True,'persistentBrowser':True}})
    runtime=SimpleNamespace(open_acquisition_verification=route('open'),resume_verified_acquisition=route('resume'))
    backend=SimpleNamespace(lock=threading.RLock(),platform_runtime=runtime,_identity=lambda token:(user,{}),_selected_store=lambda *a:'store',_platform_state=lambda *a,**kw:{'actor':{'username':'worker','storeId':'store'}})
    backend._public_platform_job=method(B,'WorkbenchBackend','_public_platform_job')
    response=method(B,'WorkbenchBackend','_platform_dispatch',{'_optional_platform':lambda data:None})(backend,action,data,'fake-token')
    return response,calls
for action,expected in [('acquisition_verification_open','open'),('acquisition_verification_resume','resume')]:
    def valid(action=action,expected=expected):
        response,calls=gateway(action,{'taskId':'owned-task'});assert calls==[(expected,{'taskId':'owned-task'})];assert response['job']['accountId']=='task-account';assert response['job']['taskId']=='owned-task'
    check('gateway '+action+' passes only exact taskId and preserves receipt binding',valid)
    for field in ('accountId','storeId','url','profileDir','owner','confirmed'):
        check(action+' rejects client '+field,lambda action=action,field=field:rejects(lambda:gateway(action,{'taskId':'owned-task',field:'injected'}),'INPUT_INVALID'))
    for data in ({},{'taskId':''},{'taskId':'../task'},{'taskId':1}):check(action+' rejects malformed task selector '+repr(data),lambda action=action,data=data:rejects(lambda:gateway(action,data),'INPUT_INVALID'))

def runtime(role='operator'):
    tenant='cloud-'+hashlib.sha256(('isolated-env\nfangyu-apartment-client').encode()).hexdigest()[:24]
    user={'id':'user','tenant_id':tenant,'username':'worker','role':role,'cloud_bound':True,'disabled':False,'_workbench_store_id':'store'}
    task={'id':'owned-task','tenant_id':tenant,'cloud_owner':'worker','store_id':'store','account_id':'task-account','platform':'xiaohongshu','status':'paused','policy':'current'}
    account={'id':'task-account','tenant_id':tenant,'cloud_owner':'worker','store_id':'store','platform':'xiaohongshu','platform_uid':'owned-uid','status':'ready'}
    rows={'users':{'user':deepcopy(user)},'tasks':{'owned-task':task},'accounts':{'task-account':account}};calls=[]
    def get(entity,ident,tenant_id):
        value=rows.get(entity,{}).get(ident)
        if not value or value.get('tenant_id')!=tenant_id:raise ValueError('isolated scope denied')
        calls.append(('get',entity,ident));return deepcopy(value)
    def access(actor,value,*args):
        if value.get('cloud_owner')!=actor['username'] or value.get('tenant_id')!=actor['tenant_id']:raise ValueError('isolated owner denied')
    core=SimpleNamespace(store=SimpleNamespace(get=lambda entity,ident:deepcopy(rows.get(entity,{}).get(ident))),_public=lambda v:deepcopy(v),_get=get,_task_access=access,_account_access=access,require_platform=lambda platform:None)
    obj=SimpleNamespace(closed=False,core=core,server=SimpleNamespace(company={'managedWorkspace':{'environment_id':'isolated-env'}}),_executor=lambda actor:calls.append(('executor',)),_verification_idle=lambda actor,acct:calls.append(('idle',acct['id'])),_current_comment_policy=lambda task:task.get('policy')=='current',_collection_binding=lambda task:(task['id'],task['account_id'],task['store_id'],task.get('policy')))
    for name in ('_principal','_task','_account','_verification_task','open_acquisition_verification','resume_verified_acquisition'):setattr(obj,name,MethodType(method(R,'PlatformRuntime',name),obj))
    return obj,user,task,account,rows,calls
for role in ('operator','admin'):
    def binding(role=role):
        obj,user,task,account,rows,calls=runtime(role);u,t,a=obj._verification_task(user,{'taskId':task['id']});assert a['id']==task['account_id'];assert [c for c in calls if c[0]=='get']==[('get','tasks','owned-task'),('get','accounts','task-account')]
    check('runtime '+role+' resolves task then task-owned account',binding)
def altered(kind):
    obj,user,task,account,rows,calls=runtime('admin')
    if kind=='task-owner':task['cloud_owner']='other-worker'
    elif kind=='task-store':task['store_id']='other-store'
    elif kind=='account-owner':account['cloud_owner']='other-worker'
    elif kind=='account-store':account['store_id']='other-store'
    elif kind=='account-tenant':account['tenant_id']='other-tenant'
    elif kind=='platform':task['platform']='douyin'
    elif kind=='user-disabled':rows['users']['user']['disabled']=True
    elif kind=='user-role':rows['users']['user']['role']='operator'
    elif kind=='policy':task['policy']='old'
    rejects(lambda:obj._verification_task(user,{'taskId':task['id']}))
for kind in ('task-owner','task-store','account-owner','account-store','account-tenant','platform','user-disabled','user-role','policy'):check('runtime rejects '+kind,lambda kind=kind:altered(kind))
for field in ('accountId','storeId','url'):
    def no_override(field=field):
        obj,user,*_=runtime();rejects(lambda:obj._verification_task(user,{'taskId':'owned-task',field:'injected'}),'INVALID_INPUT')
    check('runtime rejects extra '+field,no_override)
def open_binding():
    obj,user,task,account,rows,calls=runtime();obj.open_account_verification=lambda actor,data:(calls.append(('open-account',data)) or {'result':{'status':'verification_open'}})
    result=obj.open_acquisition_verification(user,{'taskId':task['id']});assert ('open-account',{'accountId':'task-account'}) in calls;assert result['result']['taskId']==task['id'] and result['result']['accountId']=='task-account'
check('task open delegates only to its actual account',open_binding)

def resume_case(kind):
    obj,user,task,account,rows,calls=runtime();grants=[{}, {'page':'grant'}];recover_calls=[];resume_calls=[]
    obj._verified_task_pages=lambda *a:grants.pop(0) if grants else {'page':'grant'}
    obj._verification_windows=lambda *a:[] if kind=='no-window' else [{'id':'existing-owned-window'}]
    def recover(*a):
        recover_calls.append(True)
        if kind=='mixed-journal':raise RuntimeError_('RECOVERY_NOT_ELIGIBLE','technical detail')
        if kind=='failed-identity':return {'result':{'platformLoginConfirmed':False}}
        if kind=='scope-changed':task['policy']='changed'
        if kind=='revoked-after-recovery':rows['users']['user']['disabled']=True
        return {'result':{'platformLoginConfirmed':True}}
    obj._recover_xhs_identity=recover
    obj.resume_acquisition=lambda actor,data:(resume_calls.append(deepcopy(data)) or {'result':{'taskId':data['taskId'],'status':'running','accepted':True}})
    if kind=='prior-verified-grant':grants[:]=[{'page':'grant'}]
    if kind=='no-page-proof':grants[:]=[{},{}];obj._verified_task_pages=lambda *a:grants.pop(0) if grants else {}
    if kind in ('success','prior-verified-grant'):
        result=obj.resume_verified_acquisition(user,{'taskId':task['id']});assert resume_calls==[{'taskId':'owned-task'}];assert result['result']['accountId']=='task-account';assert bool(recover_calls)==(kind=='success')
    else:
        error=rejects(lambda:obj.resume_verified_acquisition(user,{'taskId':task['id']}));assert not resume_calls
        if kind=='mixed-journal':assert '未恢复采集' in str(error) and '原任务和数据已保留' in str(error) and 'RECOVERY' not in str(error)
for kind in ('success','prior-verified-grant','no-window','mixed-journal','failed-identity','scope-changed','revoked-after-recovery','no-page-proof'):check('strict resume '+kind,lambda kind=kind:resume_case(kind))

@contextmanager
def module_stubs(mapping):
    previous={name:sys.modules.get(name) for name in mapping}
    try:sys.modules.update(mapping);yield
    finally:
        for name,value in previous.items():
            if value is None:sys.modules.pop(name,None)
            else:sys.modules[name]=value
def focus_existing():
    with tempfile.TemporaryDirectory(prefix='native-focus-',dir=O) as directory:
        root=Path(directory);account={'id':'task-account','tenant_id':'tenant','cloud_owner':'worker','store_id':'store','platform':'xiaohongshu','platform_uid':'uid','status':'ready'};user={'id':'user','tenant_id':'tenant','username':'worker'}
        profile=root/'accounts/tenant/task-account/xhs-browser-profile';profile.mkdir(parents=True);stage=profile.parent/'work/browser-login/existing';stage.mkdir(parents=True)
        job={'id':'existing','process':SimpleNamespace(poll=lambda:None)};signals=[]
        service_mod=ModuleType('assistant.browser_login_service');service_mod._profile_scope=lambda data,acct,prof:prof==profile;service_mod._staging_scope=lambda data,acct,path:path==stage
        login_mod=ModuleType('assistant.xhs_browser_login');login_mod._signal=lambda path,name:signals.append((path,name))
        obj=SimpleNamespace(data_dir=root,_principal=lambda actor:actor,_executor=lambda actor:object(),_account=lambda actor,ident:deepcopy(account),_readiness=lambda *a:('',''),_verification_idle=lambda *a:None,_verification_windows=lambda *a:[job],_run_lock=threading.RLock(),core=SimpleNamespace(lock=threading.RLock()),server=SimpleNamespace(job_lock=threading.Lock(),jobs={'existing':job},closing=False),snapshot=lambda actor:{'actor':{'username':'worker'}})
        fn=method(R,'PlatformRuntime','open_account_verification')
        with module_stubs({'assistant.browser_login_service':service_mod,'assistant.xhs_browser_login':login_mod}):
            first=fn(obj,user,{'accountId':'task-account'});second=fn(obj,user,{'accountId':'task-account'})
        assert first['result']['status']==second['result']['status']=='verification_open';assert len(obj.server.jobs)==1;assert signals==[(stage,'focus.flag'),(stage,'focus.flag')]
check('existing exact-account verification window is focused twice without new job/process',focus_existing)
def route_allowlists():
    for path,constant in ((B,'PLATFORM_ACTIONS'),(H,'API_ACTIONS')):
        tree=ast.parse(path.read_text('utf-8-sig'));assignment=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==constant for t in n.targets));values=ast.literal_eval(assignment.value.args[0])
        assert {'acquisition_verification_open','acquisition_verification_resume'}<=set(values)
check('both actions are actually present in host/backend route allowlists',route_allowlists)

files=[R,B,H];hashes={str(path.relative_to(S)).replace('\\','/'):hashlib.sha256(path.read_bytes()).hexdigest() for path in files}
for path in files:compile(path.read_bytes(),str(path),'exec')
report={'status':'PASS_INDEPENDENT_VERIFICATION_BACKEND' if all(r['status']=='PASS' for r in results) else 'FAIL_INDEPENDENT_VERIFICATION_BACKEND','at_utc':datetime.now(timezone.utc).isoformat(),'checks':len(results),'passed':sum(r['status']=='PASS' for r in results),'results':results,'source_sha256':hashes,'real_HTTP_requests':0,'real_platform_requests':0,'actual_product_modules_imported':False,'product_edits':0,'DB_writes':0,'UI_operations':0,'old_strict_70_rerun':False,'limits':['New route and method bodies with memory-only fake owner records/window.','Successful fresh status/grant receipts are synthetic; no real account verification claimed.','Exact page grant/schema/worker consumption is reviewed by its assigned reviewer.','Current actual historical journal remains ineligible as recorded in OWNED-FLAGS.json.']}
(O/'BACKEND-REVIEW.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8');print(json.dumps({k:v for k,v in report.items() if k!='results'}|{'failures':[r for r in results if r['status']=='FAIL']},ensure_ascii=False,indent=2));raise SystemExit(0 if report['status'].startswith('PASS') else 1)
