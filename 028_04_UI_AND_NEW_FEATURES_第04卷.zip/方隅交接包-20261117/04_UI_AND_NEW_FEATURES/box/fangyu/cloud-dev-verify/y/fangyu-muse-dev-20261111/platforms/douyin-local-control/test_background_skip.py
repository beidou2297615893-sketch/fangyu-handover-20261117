"""Background transport failures: isolated fixtures only, no platform or sender."""
import json
import subprocess
import tempfile
import unittest
from pathlib import Path
from unittest.mock import Mock

import unknown_resolution as rec
from attempt_recovery import finish_attempt
from read_recovery import recover_preflight
from test_employee_resume import fixture
from attempt_recovery import normalize_background_result,mark_background_target,background_target_skipped
from control import connect_for_start
import startup_recovery


class BackgroundSkip(unittest.TestCase):
    def test_startup_read_sleep_is_isolated_not_confirmed_unsent(self):
        result=rec.resolve_on_start(fixture(),{'now':lambda:'now',
            'read_reply':lambda *args:{'_stop':'page_unresponsive','own_reply_state':'unchecked'}})
        self.assertTrue(result['continue_queue'])
        self.assertEqual(result['auth']['isolated_unknown_comments'],['123'])
        self.assertEqual(result['auth']['preserve_unknown_comments'],[])
        self.assertEqual(result['records'],[])
        self.assertEqual(result['consecutive_skips'],1)

    def test_exact_field_no_polling_unknown_never_reposts_or_marks_failed(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);path=root/'captcha-recovery-authorization.json'
            path.write_text('{}',encoding='utf-8')
            outcome={'status':'unknown','error':'Request timeout after 15000ms — no polling client connected'}
            attempt={'comment_id':'123','video_id':'456','account_uid':'synthetic','attempt_id':'fixture-1'}
            def save(p,d):p.write_text(json.dumps(d),encoding='utf-8')
            self.assertFalse(finish_attempt(root,attempt,outcome,run_json=Mock(side_effect=AssertionError('do not read or repost while offline')),
                node='node',adapter='fixture',record=Mock(side_effect=AssertionError('unknown must stay unknown')),
                load=lambda p:json.loads(p.read_text(encoding='utf-8')),save=save,now=lambda:'now'))
            auth=json.loads(path.read_text(encoding='utf-8'))
            self.assertEqual(auth['isolated_unknown_comments'],['123'])
            self.assertEqual(outcome['status'],'unknown')

    def test_preflight_disconnection_is_a_bounded_skip_not_line_stop(self):
        with tempfile.TemporaryDirectory() as temp:
            read=Mock(return_value={'status':'not_sent','error':'Request timeout — no polling client connected'})
            result=recover_preflight(Path(temp),'same',read,Mock(),Mock(),
                probe=Mock(side_effect=RuntimeError('CURRENT_GATE:page_unresponsive')),ensure=Mock(),sleep=Mock(),attempts=2)
            self.assertEqual(result['status'],'target_check')
            self.assertTrue(result['diagnosis']['read_timeout'])
            self.assertFalse(result['submission_attempted'])
            self.assertEqual(read.call_count,2)

    def test_fresh_challenge_and_wrong_route_still_stop(self):
        for signal in ['CURRENT_GATE:captcha','CURRENT_GATE:rate_limit','CURRENT_GATE:identity','Connection mismatch']:
            with self.subTest(signal=signal),tempfile.TemporaryDirectory() as temp:
                with self.assertRaises(RuntimeError):
                    recover_preflight(Path(temp),'same',Mock(return_value={'status':'not_sent','error':'Request timeout'}),Mock(),Mock(),
                        probe=Mock(side_effect=RuntimeError(signal)),ensure=Mock(),sleep=Mock(),attempts=1)

    def test_pre_submit_sleep_is_unknown_and_target_fingerprint_survives_restart(self):
        status,result=normalize_background_result('not_sent',{'status':'not_sent','error':'CURRENT_GATE:page_unresponsive'})
        self.assertEqual(status,'unknown')
        self.assertFalse(result['submission_attempted'])
        with tempfile.TemporaryDirectory() as temp:
            load=lambda p:json.loads(p.read_text(encoding='utf-8'))
            save=lambda p,d:p.write_text(json.dumps(d),encoding='utf-8')
            mark_background_target(temp,{'cid':'123'},load=load,save=save,now=lambda:'now')
            self.assertTrue(background_target_skipped(temp,'123',load=load))
            self.assertFalse(background_target_skipped(temp,'124',load=load))

    def test_first_start_waits_read_only_then_recovers_without_second_click(self):
        probe=Mock(side_effect=[RuntimeError('CURRENT_GATE:page_unresponsive')]*3+[{'account_uid':'same'}])
        messages=[]
        result=connect_for_start(probe,Mock(),Mock(),wait_transport=True,require_allowed_fn=Mock(),report_fn=messages.append)
        self.assertEqual(result,{'account_uid':'same'})
        self.assertEqual(len(messages),3)
        self.assertFalse(any('刷新' in message for message in messages))

    def test_waiting_start_honors_user_stop_and_live_challenge(self):
        probe=Mock(side_effect=RuntimeError('CURRENT_GATE:page_unresponsive'))
        with self.assertRaisesRegex(RuntimeError,'user stop'):
            connect_for_start(probe,Mock(),Mock(),wait_transport=True,
                require_allowed_fn=Mock(side_effect=[None,RuntimeError('user stop')]))
        self.assertEqual(probe.call_count,1)
        with self.assertRaisesRegex(RuntimeError,'CURRENT_GATE:captcha'):
            connect_for_start(Mock(side_effect=RuntimeError('CURRENT_GATE:captcha')),Mock(),Mock(),
                wait_transport=True,require_allowed_fn=Mock())

    def test_migrated_adapter_never_posts_without_fresh_matching_identity(self):
        work=next(p for p in Path(__file__).resolve().parents if p.name=='work')
        source=work/'douyin-local-20261104-40aaf15b06'
        with tempfile.TemporaryDirectory() as temp:
            folder=Path(temp)
            for name in ['batch_reply_runner.py','send_cli_once.cjs','resume_after_confirmation.py']:
                (folder/name).write_bytes((source/name).read_bytes())
            startup_recovery.upgrade_task(folder)
            result=subprocess.run(['node',str(Path(__file__).with_name('test_identity_adapter.cjs')),str(folder/'send_cli_once.cjs')],
                capture_output=True,text=True,encoding='utf-8',timeout=15)
            self.assertEqual(result.returncode,0,result.stderr)
            self.assertIn('11 VM scenarios passed',result.stdout)

    def test_explicit_platform_429_dominates_a_transport_hint(self):
        value={'status':'unknown','receipt':{'status_code':429},'error':'CURRENT_GATE:page_unresponsive'}
        self.assertEqual(rec.current_stop(value),'rate_limit')
        result=rec.resolve_on_start(fixture(),{'now':lambda:'now',
            'read_reply':lambda *args:rec.diagnosis_from_cli(value)})
        self.assertFalse(result['continue_queue'])
        self.assertEqual(result['status']['blocked_reason'],'rate_limit')


if __name__=='__main__':unittest.main()
