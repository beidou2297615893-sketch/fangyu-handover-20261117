# 小红书浏览器人工登录与安全续采准备

记录日期：2026-11-10。对口同事：小红书链路。本文是准备结果，不是登录、解除验证或恢复采集的回执。

本次仅检查源代码、浏览器程序文件及版本元数据、脱敏现场状态，编写独立候选并运行本地模拟测试。没有启动登录、扫码或采集，没有读取或复制登录凭据、Cookie 或浏览器数据库，没有修改现场采集/发送程序、任务、队列、旧会话、停采标记或未知结果。没有下载安装、写系统目录、改 ACL 权限或系统代理。尚未做真实浏览器启动和平台验收。

## 1. 已知现场与本次核对

- 采集账号正确名称为「玉米碴」，期望 UID 为 `5f469df5000000000101ec0b`。期望 UID 用于这次任务身份核验，不应硬编码为所有员工、所有账号的固定身份。
- 2026-11-10 13:54，评论读取遇到 HTTP 461 且带验证要求。已停采，不能自动重试。现场任务目录：`C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/xhs-new-task-session-fix-20261029/runtime/live-tasks/stores15-resume007-20261110-135323`。
- 本次只读核对 `events.jsonl`：13:53:23 开始 batch-0023，目标“上海季乐路求租”第1页；13:54:58 写入 outcome_unknown。`state.json` 为 outcome_unknown、cursor=0、inflight=batch-0023。目标读取受阻不等于发送未知记录可以清除。
- 已核对该目录 `stop-today.json` 和 `C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/xhs-resume007-test-20261109/stop-today-resume007.json`：两者为11月10日停采记录，automatic_retry=false。本次原样保留。
- 现场 `task-config.json` 使用 `C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/xhs-standalone-session/yumicha-login-20261110-03`、正确期望 UID、delay=10。这里只读任务配置中的路径，没有打开该会话或读取登录文件。03会话及其他旧会话都不得覆盖。
- `continuation-receipt.json` 留存 prior_registered=3566、partial_registered_preserved=30、interrupted_batch_inserted=0、next_batch=23、remaining_pages=128；30是否包含于其他累计口径不能简单相加。应以共享账本与本地回执按source核对，不能把128页当128个客户。

## 2. 默认浏览器启动为何失败，以及本机可复用什么

用户提供的现场错误为默认 `C:/Users/rmsama/AppData/Local/camoufox` 写入拒绝。当前代码也显示一个可解释的路径问题：

- 原入口 `C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/xhs-standalone-session/diagnostics/browser_cli_once.py` 会实际运行登录，不可向其传 `--help` 来探测。
- 现有SDK `C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/vendor/cli-runtime/Lib/site-packages/xhs_cli/qr_login.py` 的浏览器就绪检查运行 `python -m camoufox path`，随后用 `Camoufox(headless=False)`，未指定浏览器本体路径。
- 本机包管理默认路径来自 user_cache_dir。默认位置没安装或不可写，与已有另一个缓存中存在浏览器是两件事。单独修改就绪检查仍不够，还要让真正启动的浏览器明确指向同一缓存本体，并避免默认插件下载/其他自动安装。
- `C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/vendor/cli-runtime/Scripts/camoufox.exe` 是Python包的命令行入口，不能直接当作Firefox浏览器本体传给Playwright。

本次仅读到两份已有程序文件和版本元数据：

1. `C:/Users/rmsama/AppData/Local/Packages/OpenAI.Codex_2p2nqsd0c76g0/LocalCache/Local/camoufox/camoufox/Cache/browsers/official/152.0.4-beta.31-ed63ea51/camoufox.exe`，文件版本152.0.4；其 application.ini、properties.json、version.json 等配套文件存在。它属于本窗口历史成功使用过的版本路线，因此作为本次候选默认值。
2. `C:/Users/rmsama/AppData/Local/Packages/OpenAI.Codex_2p2nqsd0c76g0/LocalCache/Local/camoufox/camoufox/Cache/browsers/official/156.0.1-beta.36-096fd483/camoufox.exe`，文件版本156.0.1。本次没有实际启动或比较，不能以版本新就认定更稳定，也不自动回退切版本。

元数据存在只说明具备值得验证的候选，不证明当前依赖与浏览器协议、页面、登录或验证一定兼容。若以后人工启动出现协议不兼容、缺库、页面或验证问题，保存脱敏类别并停止；不能自动下载、提权或绕过验证。

## 3. 独立补丁位置与行为

补丁文件夹：`C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/xhs-browser-login-preparation-20261110`。

- `browser_login_candidate.py`：默认离线预览；只有同时给出 `--execute --user-ready` 才会进入未来的人工登录流程。
- `verify_new_account_once.py`：默认离线预览；只有 `--execute --user-logged-in` 才会调用现有SDK做一次身份核验，输出新的脱敏回执。当前未执行此模式。
- `test_preparation.py`、`test_identity_preparation.py`：本地合成数据与内存替身测试。
- `red-tests.txt`、`green-tests.txt`：先失败、后通过的测试结果。最新17项测试通过；模拟中没有真实浏览器、真实网络或真实登录。

登录包装采用现有SDK原生 `_browser_assisted_qrcode_login`：由它在可见浏览器打开小红书原登录页，用户自己操作；SDK只在未来获准的本次新登录流程中保存新会话，包装不导入、迁移或解析任何已有登录态。包装不实现采集、发送、验证码解题或停采标记删除。

补丁仅在未来独立运行它的Python进程内指定已有浏览器本体、对应版本、可见窗口，并禁用自动下载/安装及默认插件下载，不走HTTP登录回退。运行时临时目录、APPDATA/LOCALAPPDATA重定向到本次新会话下的process-temp，防止又依赖不可写的默认目录；不改用户HOME、不更改注册表或机器环境。设置进程级 `NO_PROXY=xiaohongshu.com,.xiaohongshu.com`，并设置等值小写兼容项；不改系统代理，不动任何抖音进程。此处环境仅影响今后单独启动的这个小红书登录进程。

会话目录必须全新，已存在即拒绝，即便是空目录也不复用。不要预建 `.xiaohongshu-cli`。浏览器原生登录返回后，包装只报告“需要独立身份核验”，不把扫码确认或页面关闭当成采集登录成功。源SDK登录代码按SHA256固定，后续源变更则拒绝执行并先重新检查，避免静默依赖不兼容。

本次没有修改原 `browser_cli_once.py`、resume007、SDK、浏览器缓存或现场前台程序。没有运行本次候选的执行模式。无需安装、系统目录写入或权限变更；若以后确需安装，须先向小红书链路说明拟写位置、版本、空间和是否改权限，并等待明确确认。本文件不代替该确认。

## 4. 当前可以运行的离线预览

以下命令只有本地元数据检查，不导入真实登录模块、不发请求、不创建会话目录；本次已测试这条路径。路径需在PowerShell按完整字符串传递，使用 `-X utf8`。

```powershell
& 'C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/vendor/cli-runtime/Scripts/python.exe' -B -X utf8 `
  'C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/xhs-browser-login-preparation-20261110/browser_login_candidate.py' `
  --session-home 'C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/xhs-standalone-session/yumicha-browser-login-prepared-20261110-04'
```

这里的04只是候选新名称，不是已登录的会话；如果同事已使用该名称，应选择另一个从未创建的新目录。默认预览不会清空或覆盖它。

本候选的 `--help` 由 argparse 在任何登录导入之前处理，已用替身验证无登录调用；此结论仅适用于新候选，不适用于原 `browser_cli_once.py`。

## 5. 未来由用户准备好后人工登录的操作

当前只准备，不执行。等用户明确说准备好、同意启动本次新登录后，由小红书链路在现场执行并负责观察：

1. 核对没有其他仍在等待的扫码/登录进程，不终止或接管其他任务；确认新会话名称尚未使用。
2. 在上面的预览命令末尾增加 `--execute --user-ready`，仍只启动一次。必须在用户能看到的桌面会话中运行。
3. 出现浏览器后，用户自行用玉米碴操作登录或扫码、完成平台实际给出的验证。手机扫电脑二维码即可，不要在手机额外单独登录同一账号，避免挤掉电脑会话。
4. 原生流程发生461、验证异常、扫码超时或页面失败时停止；不自动换浏览器、换账号、导入浏览器数据库或HTTP重试。包装只输出固定脱敏错误类别，原始响应/异常可能含会话信息，不能贴进共享材料。
5. 即使流程返回，也不解除停采，更不开始采集。下一步只做必要身份核验。

这条路线避开默认安装目录的思路有本地代码依据，尚未做真实启动和平台验收。若用户认为浏览器窗口不可见，应先核对是否由可见的本地桌面进程启动，而不是不断生成新码。浏览器原流程若遇页面结构变化也须停下排查，不能据此宣称验证码已解除。

## 6. 登录后如何安全核验仍为玉米碴

核验对象必须是刚完成的那个新会话，不能把03旧会话的成功摘要套在新目录。昵称用于显示，UID用于绑定；玉米碴不是“玉米碎”。

补丁复用现有 `C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/xhs-reply-inbox/client.py` 的 `InboxClient.verify()`，该方法调用身份接口并通过既有 identify 检查非游客及期望UID；不是评论读取或消息读取。新核验包装不调用收件箱读取方法。它只将新会话的路径交给SDK按原生机制使用，不手工读取、复制或输出凭据。原生核验使用会话本身属于未来真实网络步骤，本次禁止执行。

只有用户完成本次登录、同意核验且小红书链路确认现场可进行时，才可以运行：

```powershell
& 'C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/vendor/cli-runtime/Scripts/python.exe' -B -X utf8 `
  'C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/xhs-browser-login-preparation-20261110/verify_new_account_once.py' `
  --session-home 'C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/xhs-standalone-session/yumicha-browser-login-prepared-20261110-04' `
  --expected-uid '5f469df5000000000101ec0b' `
  --output 'C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/xhs-browser-login-preparation-20261110/runtime/identity-check-04' `
  --execute --user-logged-in
```

输出目录也必须全新，不能覆盖旧回执。默认去掉两个执行开关时仅预览。若账号不符、游客、验证、会话变化或异常，输出stopped，停止后续步骤；不自动重试，不清除旧未知结果。成功回执应至少能核对本次时间、实际UID、新会话路径、非游客验证来源、status=verified，automatic_retry=false。

旧 `C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/xhs-resume007-test-20261109/identity_check_managed_once.py` 把03会话写死，并会写已有共享身份摘要；不要把它直接当新会话通用核验命令。旧 `C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/xhs-resume-20261103/verify_resume006.py` 虽接受会话参数，也把输出写到既有resume006摘要；本次未运行两者。

新登录包装的 `--review-receipt` 可以离线检查脱敏回执的UID、新目录和15分钟时效，但只验证文件一致性，不证明平台状态或人工授权，不会放行采集。即使提供 `--user-collection-approved`，其结果也只是交由现场负责人复核，不会删除任何停采标记或调用采集器。开关本身不产生用户授权，必须有本次用户原话或明确回执。

## 7. 验证与采集授权必须分开

顺序必须是：用户完成平台验证/新登录 → 核验本次新会话仍为玉米碴 → 用户明确同意本次恢复采集 → 小红书链路核对断点、账本及停止标记 → 才能有受控的恢复动作。登录成功不是恢复采集的授权，也不能把10月的旧授权充当解除今日停采的许可。

今日至少以下两个标记必须保持：

- `C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/xhs-new-task-session-fix-20261029/runtime/live-tasks/stores15-resume007-20261110-135323/stop-today.json`
- `C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/xhs-resume007-test-20261109/stop-today-resume007.json`

用户明确同意后，由现场负责人而不是此准备脚本执行状态变更：先记录授权时间、范围、核验回执和旧标记校验值，并保存停采事实的不可覆盖归档；再仅处理原程序确实检查的活动停采入口。不要直接删除整目录、清空未知状态、编辑旧batch结果或绕过检查。旧任务的停采事实应保留，不能把新任务未带标记当作可以偷偷绕过今日停采。若没有明确解除授权，任何新任务也不得启动。

## 8. 接上现有采集需要先完成的断点核对

本次只读源码发现，当前 `C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/xhs-resume007-test-20261109/resume007.py`：

- `STOP_TODAY_FIXED` 默认指向固定停采文件。
- `_validate_prior_state()` 默认仍校验resume006的outcome_unknown、旧batch-0023和run-receipts。
- `_execute()` 从旧resume006计划中截取剩余项，新建一个resume007目录执行；它不是专门读取今天已失败resume007目录的通用“继续”按钮。

因此，单纯解除固定标记并重跑原resume007，可能再次从旧前置构造任务，不能据此证明继承了今天的部分读取和待核状态。本次不改该脚本，不提供可盲目一键重跑的采集命令。

小红书链路在获得新的采集许可后，应使用已验收、能继承**今天这一目录**的续接入口；若尚无，先在新候选中做离线验证，再决定现场接入。具体要求：

1. 以今天目录的state、inflight、plan、attempt、partial/collection、登记回执和共享账本source为基准，确认batch-0023已有多少实际读到、多少已登记。现场receipt中的“0”不能未经检查就代表全部后续阶段都没有可恢复内容；存在未知登记必须先本地对账，禁止重抓重登。
2. 沿用同一个共享账本 `C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/shared-acquisition-ledger/shared.sqlite3`，按平台评论ID、可靠UID和既有事务去重；保留旧3,566条累计与30条partial的原始证据，不手动猜加。
3. 新任务使用新目录/新执行ID，但记录父任务是今日135323目录及准确游标映射；旧state、stop、partial和未知结果都原样保留。要确认“上海季乐路求租”第1页是需续读、仅需本地登记恢复还是应跳过，不能只凭页号机械重跑。
4. 传入新会话路径和本次核验的正确UID，保留现有节流delay=10及账号/任务互斥；不得覆盖老会话、强删锁或启动第二个调度器。共享账本防重范围和服务器跨机状态以当前实际实现为准。
5. 用户授权解除停采后，只按既定计划有序续接；再次遇461或验证立即停止并写今日停采，不做自动重试。先汇报实际新登记、重复、部分、失败和待核，不把程序返回0当作全部成功。

缺少现场原始启动命令及当前验收结果时，先按上述可核实条件准备，不等待材料才开工；材料补齐后由对口同事决定是否已有合适接续入口。本文不把尚未验证的接续能力冒称已完成。

## 9. 验证证据和待补材料

本次17项模拟测试通过：默认/帮助无登录、旧会话拒绝、缺本体拒绝、命令行包装不能冒充浏览器本体、执行必须有用户准备标记、进程级代理与临时目录、可见浏览器选项、禁自动安装、原生流程输出不泄露、无失败回退、错误/过期/跨会话身份回执拒绝、身份核验成功与账号不符分开、即使用户许可也不自动启动采集。浏览器及平台全为替身；没有对真实登录做“成功”断言。

原入口核对SHA256：

- browser_cli_once.py：`FDCE2E4BB253D275A1DD1BC8604945887E66E53581839891190E14729F15EC54`
- resume007.py：`117AC60A37D8A43230E9018D7EFC5CECCEC1DFB907A3969EBAC24F113C995635`

本次检查前后两者一致。本次没有把补丁安装到现用程序目录，新增仅在项目专用补丁目录和本说明文件。

已在本窗口向对口同事补要：今日浏览器失败的脱敏堆栈，以及resume007原启动命令和需保留的停采标记清单。材料暂未回到时不阻塞本次准备。仍待实际验收的项目是：缓存152.0.4与当前Playwright兼容性、可见页面是否正常、用户能否完成平台验证、平台是否接受本次新登录、非游客玉米碴身份核验、以及获准后的今日任务续接。任何一项不能用离线测试代替。


## 10. 今日断点的补充核对

继续离线核对发现：今日batch-0023的partial-0001.json包含0个客户、0条可用评论、1个待核项，曾读取1页评论；没有collection.json、register-result.json或registered-ready.json。防重统计为跳过6篇旧帖、过滤8条重复评论，不能合并当新增数。缺少回执不单独证明数据库从未写入，仍需按任务source核对账本；当前没有可直接当作新登记输入的客户记录。保留未知、partial、attempt和今日停采标记。

独立补充记录：C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/xhs-browser-login-preparation-20261110/resume-checkpoint-review.md。已向小红书链路询问从今日目录接续的已验收入口及脱敏命令。现用程序及两个停采标记校验值与此前准备快照一致；本轮未操作平台或客户账本。

## 11. 对口同事补充材料与新候选

小红书链路已在本窗口确认：尚无已验收、能从今日135323目录直接续接的入口，不能重新运行现用resume007冒充续接。13:53历史启动使用现用resume007、项目Python的-u -B -X utf8、执行模式、delay=10、进程级NO_PROXY和03会话；当日完整一行命令未留存，本说明不补造。

浏览器失败的脱敏现场结果也已补齐：默认camoufox位置拒绝写入，随后提示官方/稳定版未安装；未新安装、改权限或系统代理。两份今日停采标记必须原样保留，不删不清。材料缺口已按这份答复更新，不再因缺少完整命令原文等待或猜造。

新候选入口：C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/xhs-safe-successor-preparation-20261110/resume_from_stopped.py。

候选说明：C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/xhs-safe-successor-preparation-20261110/README.md。

已生成的新任务目录：C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/xhs-safe-successor-preparation-20261110/runtime/from-today135323-prepared。

当前候选只提供离线检查、生成停止状态的新任务和快照校验，没有真实平台执行器。父任务明确为今日135323目录，保留128项剩余计划、上海季乐路求租第1页以及旧batch-0023未知状态；新候选首批编号24，不代表自动重新抓取。相同共享账本只读按任务/批次source查到0行；partial中0条可用、1条待核保留为原始来源引用。新任务另有STOP，不删除两份原今日停采标记，不创建/读取/覆盖旧会话，不取消或修改现有队列。

20项离线测试通过，来源校验通过，can_collect=false、may_remove_stop=false。候选未接现场执行、未验收真实续采，用户完成新登录/平台验证、核验仍为玉米碴、明确同意恢复以及现场接入验收仍是必要条件。原程序和今日标记SHA256保持一致。
