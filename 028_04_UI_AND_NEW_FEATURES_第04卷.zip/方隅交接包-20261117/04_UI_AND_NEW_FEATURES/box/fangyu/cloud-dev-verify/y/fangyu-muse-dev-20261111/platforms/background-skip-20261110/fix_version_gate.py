"""Correct only the installed version gate while all sender locks are free."""
import ast
import hashlib
import json
import msvcrt
import os
from contextlib import ExitStack
from datetime import datetime
from pathlib import Path
import install_common

BASE=Path(__file__).resolve().parent
DEST=install_common.DEST
ROOT=install_common.ROOT
BACKUP=BASE/'version-gate-fix'
OLD="if VERSION!='employee-resume-20261110' or"
NEW="if VERSION!='background-skip-20261110' or"
PAUSE='连续12条被拒绝或跳过，已暂停。请检查已登录页面和平台提示后再点启动／继续。'
UPDATING='启动程序正在更新，请稍后再点启动／继续。'

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write_atomic(path,data):
    temporary=path.with_name(path.name+'.version-gate.tmp')
    temporary.write_bytes(data)
    os.replace(temporary,path)

def main():
    with ExitStack() as stack:
        locks=[DEST/'control.lock',*ROOT.glob('work/douyin-local-*/batch-runner.lock')]
        old_lock=ROOT/'work/douyin-round2-task5/batch-runner.lock'
        if old_lock.exists():locks.append(old_lock)
        for path in locks:
            handle=stack.enter_context(path.open('a+b'));handle.seek(0)
            msvcrt.locking(handle.fileno(),msvcrt.LK_NBLCK,1)
        if install_common.running_senders():raise RuntimeError('sender active: no changes')
        status_path=DEST/'status.json'
        status=json.loads(status_path.read_text(encoding='utf-8'))
        if status.get('message') not in (UPDATING,PAUSE):raise RuntimeError('newer status: no changes')
        batch=ROOT/'work/douyin-local-20261104-40aaf15b06/batch-runner-status.json'
        batch_state=json.loads(batch.read_text(encoding='utf-8'))
        if batch_state.get('status')!='blocked' or batch_state.get('reason')!=PAUSE:
            raise RuntimeError('batch state changed: no changes')
        version_ast=ast.parse((DEST/'startup_recovery.py').read_text(encoding='utf-8-sig'))
        versions=[node.value.value for node in version_ast.body if isinstance(node,ast.Assign)
                  and any(isinstance(t,ast.Name) and t.id=='VERSION' for t in node.targets)
                  and isinstance(node.value,ast.Constant)]
        if versions!=['background-skip-20261110']:raise RuntimeError('unexpected installed version')
        for name in ('page_guard.cjs','attempt_recovery.py'):
            if not (DEST/name).is_file():raise RuntimeError('incomplete bundle')
        source=DEST/'control.py';raw=source.read_bytes()
        text=raw.decode('utf-8')
        if text.count(OLD)!=1:raise RuntimeError('unexpected gate source')
        fixed=text.replace(OLD,NEW,1).encode('utf-8');ast.parse(fixed.decode('utf-8'))
        prior=json.loads((BASE/'protected-before.json').read_text(encoding='utf-8'))
        protected=[Path(p) for p in prior['files']]
        protected.extend(DEST/name for name in install_common.RUNTIME if name!='control.py')
        protected.append(batch)
        before={str(p):digest(p) for p in protected}
        BACKUP.mkdir(exist_ok=True)
        for path in (source,status_path,BASE/'install-result.json',BASE/'stage/control.py'):
            backup=BACKUP/(('stage-' if path.parent.name=='stage' else '')+path.name+'.before')
            if backup.exists():raise RuntimeError('backup exists: inspect before rerunning')
            backup.write_bytes(path.read_bytes())
        if install_common.running_senders():raise RuntimeError('sender appeared: no changes')
        write_atomic(source,fixed)
        stage=BASE/'stage/control.py'
        staged=stage.read_bytes()
        if staged.decode('utf-8').count(OLD)==1:
            write_atomic(stage,staged.decode('utf-8').replace(OLD,NEW,1).encode('utf-8'))
        status['message']=PAUSE
        write_atomic(status_path,json.dumps(status,ensure_ascii=False,indent=2).encode('utf-8'))
        manifest_path=BASE/'install-result.json'
        manifest=json.loads(manifest_path.read_text(encoding='utf-8'))
        stamp=datetime.now().astimezone().isoformat()
        manifest['files']['control.py']=digest(source)
        manifest['version_gate_corrected_at']=stamp
        write_atomic(manifest_path,json.dumps(manifest,ensure_ascii=False,indent=2).encode('utf-8'))
        after={str(p):digest(p) for p in protected}
        report={'fixed_at':stamp,'gate_expected_version':'background-skip-20261110',
                'production_source_change':'one version literal only',
                'status_message':status['message'],'protected_before':before,'protected_after':after,
                'protected_unchanged':before==after,'running_after':install_common.running_senders(),
                'send_or_collection_started':False,'production_task_migration_executed':False}
        (BACKUP/'result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
        if before!=after:raise RuntimeError('protected files changed; inspect report')
        print(json.dumps({k:v for k,v in report.items() if not k.startswith('protected_')},ensure_ascii=False))
        print('protected_unchanged='+str(before==after))

if __name__=='__main__':main()
