"""Separate an approved batch from its execution account. No network or sends here.

Only the explicit employee-start controller calls this module. Old queues,
attempts, auth and ledger are read-only. A new account gets an isolated copy.
"""
import ast
import hashlib
import json
import os
from pathlib import Path
import re
import sqlite3
import tempfile
from contextlib import closing

CODE_FILES=('batch_reply_runner.py','prepare_verified.py','send_cli_once.cjs',
            'target-diagnosis.cjs','commercial_gate.py','time_priority.py',
            'resume_after_confirmation.py')
OPTIONAL_FILES=('publish-pacing.json','tone-approved-source.jsonl')

def read(path):return json.loads(path.read_text(encoding='utf-8-sig'))
def sha(data):return hashlib.sha256(data).hexdigest()
def save(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')

def task_path(root,path):
    path=Path(path).resolve()
    if path.parent!=(root/'work').resolve() or not path.name.startswith('douyin-local-'):
        raise RuntimeError('本批任务目录无法核验；没有切换账号或发送。')
    return path

def queue_at(task):
    manifest=read(task/'approved-cli-queue.json')
    payload=json.dumps(manifest.get('items'),ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
    if (manifest.get('authorized') is not True or not manifest.get('account_uid')
        or manifest.get('prepared_by')!='douyin-classification-ready-v1'
        or sha(payload)!=manifest.get('items_sha256')):
        raise RuntimeError('本批批准清单无法核验；保留原任务。')
    return manifest

def batch_source(root,current):
    context=current/'batch-context.json'
    if not context.exists():return current
    value=read(context)
    source=task_path(root,value['source_task'])
    manifest=queue_at(current)
    expected_key=sha((str(source)+'\0'+manifest['items_sha256']).encode())[:16]
    if (manifest['items_sha256']!=value.get('items_sha256')
        or manifest['account_uid']!=value.get('account_uid')
        or value.get('batch_key')!=expected_key
        or value.get('version')!='account-neutral-20261110'):
        raise RuntimeError('本批接续清单已变化，需核对后继续。')
    # The original queue may later be republished; continue the exact snapshot
    # held by the current execution rather than silently adopting a different one.
    return source

def historical_exclusions(root,manifest,current):
    comments=set();customers=set();videos=set();fingerprints=set();quarantined=[]
    ledger_customers=None
    by_cid={str(i['cid']):str(i['uid']) for i in manifest['items']}
    for task in (root/'work').glob('douyin-*'):
        if not task.is_dir() or task.name=='douyin-local-control':continue
        if not (task/'approved-cli-queue.json').exists() and not (task/'batch_reply_runner.py').exists():continue
        own_queue=read(task/'approved-cli-queue.json') if (task/'approved-cli-queue.json').exists() else {}
        own_map={str(i.get('cid')):str(i.get('uid')) for i in own_queue.get('items',[]) if i.get('cid') and i.get('uid')}
        for filename in ('unavailable-targets.json',):
            p=task/filename
            if p.exists():
                ex=read(p)
                comments.update(str(cid) for cid in ex.get('comments',{}))
                # A video-level exclusion belongs to this batch, not every unrelated batch.
                if task==current:videos.update(ex.get('operator_skipped_videos',{}))
        for p in task.iterdir():
            match=re.fullmatch(r'(\d+)\.json(?:\.submitted)?',p.name)
            if not match:continue
            cid=match[1];comments.add(cid)
            if cid in by_cid:customers.add(by_cid[cid])
            if cid in own_map:customers.add(own_map[cid])
            if p.name.endswith('.json'):
                try:
                    attempt=read(p)
                    if not isinstance(attempt,dict):raise ValueError('not an attempt object')
                except (ValueError,UnicodeError):
                    # A damaged historic receipt is not a reason to revive it or
                    # stop an unrelated current target. Recover BOTH dedupe keys
                    # from independently persisted queue/ledger evidence.
                    if ledger_customers is None:
                        db=root/'work/shared-acquisition-ledger/shared.sqlite3'
                        ledger_customers={}
                        if db.exists():
                            with closing(sqlite3.connect(db.as_uri()+'?mode=ro',uri=True,timeout=5)) as conn:
                                for old_cid,old_uid in conn.execute("SELECT comment,customer FROM reservations WHERE platform='douyin'"):
                                    if old_uid:ledger_customers.setdefault(str(old_cid),set()).add(str(old_uid))
                    recovered={value for value in (by_cid.get(cid),own_map.get(cid)) if value}
                    recovered.update(ledger_customers.get(cid,set()))
                    if len(recovered)!=1:
                        raise RuntimeError('一条旧尝试记录损坏且无法唯一核对对应客户，已保留原件；没有重发或清除未知。') from None
                    customers.update(recovered)
                    quarantined.append({'file':str(p.relative_to(root)),'comment_id':cid,
                        'sha256':sha(p.read_bytes()),'customer_evidence_verified':True,
                        'action':'exclude_comment_and_customer_preserve_original'})
                    continue
                uid=attempt.get('customer_uid') or attempt.get('customer')
                if uid:customers.add(str(uid))
        # Non-submitted background skips have their own durable CID fingerprints.
        skip=task/'background-skipped-targets.json'
        if skip.exists():
            data=read(skip)
            fingerprints.update(data)
            customers.update(uid for cid,uid in own_map.items() if sha(('douyin\0'+cid).encode()) in data)
    for item in manifest['items']:
        cid=str(item['cid'])
        if (str(item['uid']) in customers or item['video'] in videos
            or sha(('douyin\0'+cid).encode()) in fingerprints):
            comments.add(cid)
    return {'comments':{cid:{'reason':'历史尝试或已隔离目标；换账号不重发',
                              'submission_attempted':None} for cid in sorted(comments)},
            'operator_skipped_videos':{v:{'reason':'本批原操作员跳过'} for v in sorted(videos)},
            'quarantined_attempts':quarantined}

def assert_batch_can_resume(task,*,cross_account=False):
    # Account discovery never overrides a batch-level operator stop or unresolved
    # platform stop. Ordinary historical unknowns are preserved and excluded.
    if (task/'batch-stop.json').exists():
        stop=read(task/'batch-stop.json')
        if not (stop.get('user_pause') is True and stop.get('ready_for_user_resume') is True):
            raise RuntimeError('本批仍有停止标记，换账号不会自动解除；请先处理停止原因。')
    state=task/'continuation-state.json'
    if state.exists() and read(state).get('status') not in ('authorized','ready',''):
        raise RuntimeError('本批仍有未解除的平台暂停，换账号不会清除；请先处理暂停原因。')
    status=task/'batch-runner-status.json'
    if cross_account and status.exists():
        from unknown_resolution import LIVE_STOPS
        latest=read(status)
        if latest.get('status')=='blocked' and latest.get('reason') in (LIVE_STOPS['captcha'],LIVE_STOPS['rate_limit']):
            raise RuntimeError('本批明确的验证或限流尚未解除；不能通过换账号绕过。')

def refresh_exclusions(root,task,manifest,*,preview=False):
    exclusions=historical_exclusions(root,manifest,task)
    path=task/'unavailable-targets.json'
    existing=read(path) if path.exists() else {}
    merged=dict(existing)
    merged['comments']={**exclusions['comments'],**existing.get('comments',{})}
    merged['operator_skipped_videos']={**exclusions['operator_skipped_videos'],**existing.get('operator_skipped_videos',{})}
    quarantined={r['sha256']:r for r in existing.get('quarantined_attempts',[])}
    quarantined.update({r['sha256']:r for r in exclusions['quarantined_attempts']})
    merged['quarantined_attempts']=list(quarantined.values())
    if not preview and merged!=existing:
        fd,name=tempfile.mkstemp(prefix='.exclusions-',suffix='.tmp',dir=task)
        with os.fdopen(fd,'w',encoding='utf-8') as stream:json.dump(merged,stream,ensure_ascii=False,indent=2)
        os.replace(name,path)
    return merged

def preview_result(task,manifest,exclusions,*,reused):
    return {'ready_to_prepare':True,'task':str(task),'reused':reused,
            'items_sha256':manifest['items_sha256'],'item_count':len(manifest['items']),
            'excluded_comment_count':len(exclusions['comments']),
            'quarantined_attempt_count':len(exclusions.get('quarantined_attempts',[])),
            'files_written':False,'submission_attempted':False}

def prepare_batch_session(root,control,identity,*,preview=False):
    root=Path(root).resolve();control=Path(control)
    uid=identity.get('account_uid') or ''
    if not re.fullmatch(r'[A-Za-z0-9_.-]{1,256}',uid):raise RuntimeError('当前登录身份无效')
    active=read(control/'active.json')
    current=task_path(root,active['task'])
    manifest=queue_at(current)
    if active.get('account_uid')!=manifest['account_uid']:
        raise RuntimeError('当前执行记录与批次身份不一致，保留原任务。')
    source=batch_source(root,current)
    cross_account=manifest['account_uid']!=uid
    assert_batch_can_resume(source,cross_account=cross_account)
    if current!=source:assert_batch_can_resume(current,cross_account=cross_account)
    if manifest['account_uid']==uid:
        exclusions=refresh_exclusions(root,current,manifest,preview=preview)
        if preview:return preview_result(current,manifest,exclusions,reused=True)
        return current
    source_manifest=queue_at(source)
    batch_key=sha((str(source)+'\0'+manifest['items_sha256']).encode())[:16]
    # Independent name, never a child prefix of the original attempt token.
    target=root/'work'/('douyin-local-batch-'+batch_key+'-'+sha(uid.encode())[:12])
    registry=read(control/'accounts.json') if (control/'accounts.json').exists() else {}
    candidates=[target]
    if uid in registry:candidates.append(task_path(root,registry[uid]))
    for candidate in candidates:
        if not candidate.exists():continue
        try:q=queue_at(candidate)
        except (RuntimeError,FileNotFoundError):
            if candidate==target:raise
            # An account's old, unfinished template is not this batch and must
            # neither replace this batch nor prevent this batch from continuing.
            continue
        if q['account_uid']==uid and q['items_sha256']==manifest['items_sha256']:
            context=candidate/'batch-context.json'
            if candidate==source or (context.exists() and batch_source(root,candidate)==source):
                assert_batch_can_resume(candidate,cross_account=cross_account)
                exclusions=refresh_exclusions(root,candidate,q,preview=preview)
                if preview:return preview_result(candidate,q,exclusions,reused=True)
                return candidate
        if candidate==target:raise RuntimeError('已有接续目录与本批不一致，原文件保持不变。')
    old_uid=manifest['account_uid']
    if not re.fullmatch(r'[A-Za-z0-9_.-]{1,256}',old_uid):raise RuntimeError('原执行身份无法核验')
    code={name:(current/name).read_text(encoding='utf-8-sig') for name in CODE_FILES}
    rewritten={}
    for name,text in code.items():
        text=text.replace(old_uid,uid).replace(current.name,target.name)
        if name.endswith('.py'):
            # User-controlled nicknames never become executable source text.
            # Exact UID and nickname remain in the runtime binding and receipts.
            text=re.sub(r'账号：[^|\n]*? \|','账号：当前核验账号 |',text)
            ast.parse(text)
        rewritten[name]=text
    exclusions=historical_exclusions(root,manifest,current)
    if preview:return preview_result(target,manifest,exclusions,reused=False)
    # Build under a hidden directory: incomplete copies are never discoverable as send tasks.
    temporary=Path(tempfile.mkdtemp(prefix='.douyin-batch-',dir=root/'work'))
    try:
        for name,text in rewritten.items():(temporary/name).write_text(text,encoding='utf-8')
        for name in OPTIONAL_FILES:
            if (current/name).exists():(temporary/name).write_bytes((current/name).read_bytes())
        new_manifest=dict(manifest,account_uid=uid)
        save(temporary/'approved-cli-queue.json',new_manifest)
        save(temporary/'continuation-state.json',{'status':'authorized','unknown':0,
             'authorization_source':'用户2026-11-10：主动换账号接续同一批未处理任务；旧未知不重发'})
        save(temporary/'captcha-recovery-authorization.json',{'preserve_unknown_comments':[],
             'isolated_unknown_comments':[],'events':[]})
        save(temporary/'unavailable-targets.json',exclusions)
        save(temporary/'batch-runner-status.json',{'status':'prepared','automatic_retry':False,
             'reason':'已准备接续同一批剩余任务，等待当前人工启动流程完成。'})
        save(temporary/'batch-context.json',{'source_task':str(source),'source_account_uid':source_manifest['account_uid'],
             'batch_key':batch_key,'items_sha256':manifest['items_sha256'],'account_uid':uid,
             'previous_execution':str(current),'switch_requires_employee_start':True,
             'prior_unknown_receipts_preserved':True,'version':'account-neutral-20261110'})
        # Preserve this account's most recent existing local pacing state.
        pacing=[]
        for old in (root/'work').glob('douyin-local-*'):
            risk=old/'cli-risk-state.json';q=old/'approved-cli-queue.json'
            if risk.exists() and q.exists() and read(q).get('account_uid')==uid:
                pacing.append(risk)
        if pacing:
            risk=max(pacing,key=lambda p:p.stat().st_mtime)
            (temporary/'cli-risk-state.json').write_bytes(risk.read_bytes())
        # Commit only a complete self-consistent snapshot. No registry/binding write here.
        queue_at(temporary)
        os.rename(temporary,target)
    except Exception:
        # Keep a failed staging copy as evidence, never expose it as a send task.
        raise
    return target
