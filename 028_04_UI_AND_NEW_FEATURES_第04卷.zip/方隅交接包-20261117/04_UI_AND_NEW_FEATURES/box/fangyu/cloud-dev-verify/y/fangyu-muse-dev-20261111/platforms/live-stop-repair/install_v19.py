from pathlib import Path
import importlib.util,sys
sys.dont_write_bytecode=True
P=Path('C:/积木软件工坊/项目/方隅公寓客户版');F=P/'work/parallel-integration-20261018/final-integration'
spec=importlib.util.spec_from_file_location('original_v19_entry_installer',F.parent/'integration/entry/install_canonical_delegation.py')
installer=importlib.util.module_from_spec(spec);spec.loader.exec_module(installer)
installer.HERE=F/'entry-v19';installer.P=P;installer.NATIVE=P/'work/ui-native-r57';installer.OUT=F/'candidate-unified-v19'
if __name__=='__main__':installer.main()
