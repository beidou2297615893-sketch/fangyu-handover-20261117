from pathlib import Path
import sqlite3,json,hashlib,datetime,re
P=Path('C:/积木软件工坊/项目/方隅公寓客户版');HERE=Path('C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/live-stop-repair/collection-audit')
binding=json.loads((P/'work/ui-native-r57/state/production-workspace.json').read_text('utf-8'))
data=Path(binding['data_dir']);db=sqlite3.connect((data/'workspace.sqlite3').as_uri()+'?mode=ro',uri=True);db.execute('PRAGMA query_only=ON');assert db.execute('PRAGMA query_only').fetchone()[0]
users=[json.loads(r[0]) for r in db.execute("SELECT body FROM records WHERE entity='users' AND json_extract(body,'$.username')=?",(binding['owner'],))];assert len(users)==1
tenant=users[0]['tenant_id'];owner=binding['owner']
tasks=[json.loads(r[0]) for r in db.execute("SELECT body FROM records WHERE entity='tasks' AND tenant_id=? AND json_extract(body,'$.cloud_owner')=?",(tenant,owner))];tasks.sort(key=lambda r:r.get('created_at',''),reverse=True)
active=json.loads((P/'work/ui-native-r57/state/active.json').read_text('utf-8'))
safe=lambda row,keys:{key:row.get(key) for key in keys if key in row}
result={'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'active':safe(active,['release','profile','instanceId','pid']),'tasks':[],'state_files':[p.name for p in (P/'work/ui-native-r57/state').iterdir() if p.is_file()],'data_top_files':[p.name for p in data.iterdir() if p.is_file()]}
for task in tasks[:5]:
 tid=task['id'];account=data/'accounts'/tenant/task['account_id'];receiptrow=db.execute("SELECT body FROM records WHERE entity='workbench_collection_run_v1' AND tenant_id=? AND id=? AND json_extract(body,'$.owner')=?",(tenant,tid,owner)).fetchone();receipt=json.loads(receiptrow[0]) if receiptrow else {}
 entry={'task':safe(task,['id','created_at','updated_at','status','state','phase','paused','pause_reason','stop_reason','last_platform_error','last_error','last_result','last_batch','run_id','pipeline','account_id','target_count','daily_limit','date_from','date_to','continuous_enabled']),'task_keys':list(task),'run_receipt':safe(receipt,['id','status','stop_reason','counts','pages','units','sequence','last_sequence','created_at','updated_at','completed_at','error','last_error','operation_key','binding']),'page_receipts':[],'account_top_files':[p.name for p in account.iterdir() if p.is_file()] if account.exists() else []}
 # Retain stage counters and safe terminal errors, not real post/comment data or tokens.
 pipe=entry['task'].get('pipeline') or {};entry['task']['pipeline']=safe(pipe,['keyword_index','search_page','note_index','browsed_notes','search_more','complete','status','stage']);entry['task']['pipeline'].update(notes_count=len(pipe.get('notes') or []),reply_queue_count=len(pipe.get('reply_queue') or []))
 for key in ('last_batch','last_result'):
  payload=entry['task'].get(key) or {}
  if key=='last_batch':entry['task'][key]=safe(payload,['read','filtered','duplicates','imported','filter_reasons','stage','phase','status','counts','reason','error','error_code'])
  else:entry['task'][key]=safe(payload,['status','completed_at','started_at','sequence','summary','error','error_code','reason','stop_reason'])
 pagefolder=account/'.workbench-page-receipts'/tid
 if pagefolder.exists():
  for file in sorted(pagefolder.glob('*.json'),key=lambda p:p.stat().st_mtime,reverse=True)[:12]:
   page=json.loads(file.read_text('utf-8'));row=safe(page,['version','task','scope','page','args_digest','operation','state','created_at','updated_at','received_at','error_type','wire_allow_attempts','process_exited','digest']);row['file']=str(file);row['file_sha256']=hashlib.sha256(file.read_bytes()).hexdigest()
   payload=page.get('result') or {};row['result_meta']={'returncode':payload.get('returncode'),'stdout_bytes':len(payload.get('stdout','').encode()),'stderr_bytes':len(payload.get('stderr','').encode())}
   try:
    value=json.loads(payload.get('stdout') or '{}')
    if isinstance(value,dict):row['result_meta']['stdout_keys']=list(value);row['result_meta']['error']=value.get('error')
   except (ValueError,TypeError):pass
   entry['page_receipts'].append(row)
 activity=account/'platform-activity.jsonl';start=datetime.datetime.fromisoformat(task['created_at']).replace(tzinfo=datetime.timezone(datetime.timedelta(hours=8))).timestamp()
 if activity.exists():
  rows=[json.loads(line) for line in activity.read_text('utf-8').splitlines() if line.strip()];finish=(task.get('last_result') or {}).get('completed_at');end=datetime.datetime.fromisoformat(finish).replace(tzinfo=datetime.timezone(datetime.timedelta(hours=8))).timestamp()+1 if finish else datetime.datetime.now(datetime.timezone.utc).timestamp();rows=[r for r in rows if start<=r.get('at',0)<=end];entry['recent_activity']=[safe(row,['at','kind','stage','status','http_status','platform_code','elapsed_ms','method','request_id','prewarm_unavailable']) for row in rows[-45:]]
 result['tasks'].append(entry)
db.close();(HERE/'LATEST-REAL.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'active':result['active'],'tasks':[{'id':x['task']['id'],'created':x['task']['created_at'],'status':x['task'].get('status'),'last_error':x['task'].get('last_error'),'last_platform_error':x['task'].get('last_platform_error'),'receipt':x['run_receipt'],'pages':[{k:r.get(k) for k in ('operation','state','error_type','wire_allow_attempts')} for r in x['page_receipts']]} for x in result['tasks']],'state_files':result['state_files'],'data_top_files':result['data_top_files']},ensure_ascii=False,indent=2))
