"""Narrow offline recovery for one locally verified preflight-only attempt.

No browser or network access. The source and this exact attempt are pinned.
The database event is committed before resetting control; a crash between the
two leaves control stopped, never an unlocked runner. Review all evidence and
back up the SQLite database before using this on live data.
"""
import datetime
import hashlib
import json
import os
import sqlite3
import sys
from pathlib import Path

EXPECTED_REQUEST = '9b3963b4-bec8-4c0b-9e87-564d1cdd6206'
EXPECTED_RUNNER_SHA256 = '2db4ac2c2e5dff54fd90ba58d73f0a52de65c5e589fb87139f499050a5f32e42'
EXPECTED_RESPONSE = {'ok': False, 'transport_error': 'connection_changed'}
GUARD = "if (alive.length !== 1 || alive[0].id !== connection_id || spec.connection_id !== connection_id) return {ok:false,transport_error:'connection_changed'};"
CALL = 'response = await bridge.call('

def sha(value):
    return hashlib.sha256(value).hexdigest()

def recover(root, expected_request=EXPECTED_REQUEST, expected_hash=EXPECTED_RUNNER_SHA256):
    root = Path(root).resolve()
    database = root / 'runtime' / 'collection.sqlite3'
    directory = root / 'runner-live-v2'
    control_path = directory / 'control.json'
    source = (root / 'runner.cjs').read_bytes()
    if sha(source) != expected_hash:
        raise ValueError('runner_source_hash_mismatch')
    code = source.decode('utf-8')
    if code.count(GUARD) != 1 or code.count("transport_error:'connection_changed'") != 1 or code.find(GUARD) > code.find(CALL) or code.find(CALL) < 0:
        raise ValueError('preflight_source_not_proven')
    old_control = control_path.read_bytes()
    control = json.loads(old_control)
    if control.get('stopped') != 'ledger_unknown' or control.get('pending') is not None:
        raise ValueError('unexpected_control_state')
    if (directory / 'STOP').exists():
        raise ValueError('stop_file_requires_review')
    db = sqlite3.connect(database, timeout=10)
    db.row_factory = sqlite3.Row
    leases = []
    try:
        halt = db.execute('SELECT * FROM account_halts').fetchall()
        if len(halt) != 1 or halt[0]['request_id'] != expected_request or halt[0]['state'] != 'unknown':
            raise ValueError('halt_not_exact_unique_unknown')
        account = halt[0]['account_uid']
        attempt = db.execute('SELECT * FROM attempts WHERE request_id=?', (expected_request,)).fetchone()
        if not attempt or attempt['state'] != 'unknown' or json.loads(attempt['response']) != EXPECTED_RESPONSE:
            raise ValueError('attempt_not_exact_preflight_response')
        spec = json.loads(attempt['spec'])
        if spec['account_uid'] != account or spec['request_id'] != expected_request or control.get('scan_id') != spec['scan_id']:
            raise ValueError('scope_mismatch')
        record = json.loads((directory / (expected_request + '.json')).read_text(encoding='utf-8'))
        receipt = json.loads((directory / (expected_request + '.receipt.json')).read_text(encoding='utf-8'))
        if record != {'spec': spec, 'response': EXPECTED_RESPONSE} or receipt.get('request_id') != expected_request or receipt.get('state') != 'unknown':
            raise ValueError('local_evidence_mismatch')
        # Same names and exclusivity as Node acquireLease. Neither stale lease is removed.
        for token in (('connection', spec['connection_id']), ('database', str(database.resolve()))):
            lease = root / ('runner-lease-' + token[0] + '-' + sha(token[1].encode('utf-8'))[:24] + '.json')
            fd = os.open(lease, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            leases.append(lease)
            with os.fdopen(fd, 'w', encoding='utf-8') as f:
                json.dump({'pid': os.getpid(), 'note': 'offline local preflight recovery'}, f)
        db.execute('BEGIN IMMEDIATE')
        h = db.execute('SELECT * FROM account_halts').fetchall()
        a = db.execute('SELECT * FROM attempts WHERE request_id=?', (expected_request,)).fetchone()
        if len(h) != 1 or h[0]['request_id'] != expected_request or h[0]['account_uid'] != account or h[0]['state'] != 'unknown' or not a or a['spec'] != attempt['spec'] or a['response'] != attempt['response'] or a['state'] != 'unknown':
            raise ValueError('halt_or_attempt_changed')
        fields = ('scan_id','account_uid','kind','target','store_id','keyword')
        cp = db.execute('SELECT cursor,exhausted FROM scan_streams WHERE scan_id=? AND account_uid=? AND kind=? AND target=? AND store_id=? AND keyword=?', tuple(spec[k] for k in fields)).fetchone()
        if cp is None or cp['cursor'] != spec['cursor'] or cp['exhausted'] or db.execute('SELECT 1 FROM scan_pages WHERE request_id=?', (expected_request,)).fetchone():
            raise ValueError('checkpoint_changed_or_request_committed')
        if control_path.read_bytes() != old_control:
            raise ValueError('control_changed')
        now = datetime.datetime.now(datetime.timezone.utc).isoformat()
        reason = 'Codex依据本次固定源码及本地原始记录核验：连接预检返回于bridge.call之前，采集请求未派发；不声称人工确认，原未知记录及游标保留。'
        db.execute('INSERT INTO recovery_events(account_uid,request_id,operator,reason,rule_source,recovered_at) VALUES(?,?,?,?,?,?)',
                   (account, expected_request, 'Codex代码及本地证据核验', reason, '用户授权继续抖音采集及不得重发未知结果', now))
        db.execute('DELETE FROM account_halts WHERE account_uid=? AND request_id=?', (account, expected_request))
        db.commit()
        # After the transaction, an interrupted write cannot start the runner:
        # its control is still stopped. The event is a durable audit anchor.
        if control_path.read_bytes() != old_control:
            raise ValueError('control_changed_after_db_commit_manual_review_required')
        control['stopped'] = None
        tmp = control_path.with_name('control.preflight-recovery.tmp')
        with tmp.open('x', encoding='utf-8') as f:
            json.dump(control, f, ensure_ascii=False, indent=2)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, control_path)
        return {'state':'preflight_evidence_reconciled','request_id':expected_request,'network_started':False,'attempt_preserved':True,'checkpoint_preserved':True}
    finally:
        db.close()
        for lease in leases:
            lease.unlink(missing_ok=True)

if __name__ == '__main__':
    if len(sys.argv) != 3 or sys.argv[1] != '--root':
        raise SystemExit('Usage: python recover_preflight.py --root <verified project directory>')
    print(json.dumps(recover(sys.argv[2]), ensure_ascii=False))
