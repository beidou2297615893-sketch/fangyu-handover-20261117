# 「回复语气｜关键词 过滤词」完整开发历程

整理日期：2026年11月10日。整理者：本窗口。

本文件依照 `C:\Users\rmsama\Documents\ChatGPT\codex-briefs-20261110\HISTORY-COMMON.md` 编写。内容来自本窗口的对话记忆、实际执行记录，以及本次只读核对到的本地文件；没有拿其他窗口的开发历程代替本窗口经历。

本次只编写这份文档，没有启动、停止或重启采集、分类、发送，没有修改使用中的规则、命令行工具实现、发送批次、客户数据或登录状态。文中出现的启动方式是供后续获授权接续时识别入口，本文编写过程中未执行。

这是技术交接历程，因此保留必要的完整路径、程序名称和版本。没有复制客户明细、客户标识、账号凭据、Cookie、密钥或密码。历史评论问题采用概括描述；模板例句属于业务话术，不对应具体客户。

## 一、本窗口到底负责什么

本窗口负责两平台共用的文字业务：门店搜索词、过滤和意向判断规则、多标签分类池、细分类词、母句语气、本地回复适配、评论分析旁注、时间预算意愿排序，以及供CLI消费的文字结果和指针。

用户最早已经明确：软件功能的想法向「代码与功能整合」窗口交代，本窗口先做文本，不接管软件开发。采集由小红书、抖音各自窗口执行；真实发送由对应CLI窗口在用户授权后执行。后来为了让本地文字结果真正被CLI读到，本窗口补做了本地批处理、兼容、消费指针、验收及协调，但这不等于本窗口独立完成了平台采集和发送能力。

必须始终区分以下状态：

1. 评论已采集、已登记，尚未判断。
2. 评论已判断，仍可能是待核、非需求或需求结束。
3. 已经分池，不代表已有符合语气的回复。
4. 已有本地母句草稿，不代表当前CLI队列已消费新稿。
5. 已入队，不代表已提交平台。
6. 已提交，不代表平台确认成功。
7. 结果未知，不得当作失败自动重发。

这几层在早期被混用过，是用户多次质疑和后续返工的主要原因。后面的开发实际是在逐步把它们拆开、关联，并用文件和校验落实。

本窗口主要工作目录：

`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029`

人可读的文字交付目录：

`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\outputs\方隅双平台文本业务`

## 二、起点：全店词库、筛选流程、十个需求池和母评论

### 2.1 用户最初提出的任务

用户要求先把所有门店的搜索词找全，检查为什么只有13家有内置词，补齐缺店；同时梳理筛选流程，用分类池和母句代替每次从头分析原文、从头写回复。古北优先做真实评论和语气校准，全店词库并行整理。两个平台使用共通业务语言，但账本和统计分别计算。

最初计划把25家当作待核目标，每店首轮200条、总量约5000条。用户后来明确纠正：公司这次实际范围是15家，不是25家。之前的13家，是既有内置词库覆盖数，不能解释为软件或公司只有13家；官网的15条资料也不该一直称“15个官网项目”而让业务方误解。

### 2.2 门店和搜索词实际怎么整理

我检索了本地门店资料、历史导出与公开资料，保留了原有词库，没有用未证实的道路、地铁、商圈或通勤时长补空。对历史别名、更名、重复和不确定经营状态分别留依据。资料中出现的历史名称不能直接当作当前新增门店。

词库整理经历了两个数量口径：

- 原有13店词条与新增公开资料整理到的完整资料行，共有5988行的历史资料口径；其中原13组5588行，另两组400行。这里包括完整资料层，不能直接与最终优先词表混算。
- 最终按用户确认的15家业务范围，各选200条，形成3000条门店—搜索词关系。这才是后续统一使用的首轮优先搜索词口径。

3000条后来再分层，核验前后词条集合、门店关系和总量未变：主动求租与找房511条，地域与租住条件2297条，补充探索192条；15家都覆盖三层。不是把全部词当作同等优先，也没有靠机械同义排列凑量。跨店共享词允许存在，同一个搜索词可适用于多个门店，但必须保留对应关系。

最终目录包含的15家名称是：FUNLIVE·上海天璟方隅服务公寓、上海中骏广场方隅服务公寓、上海会展方隅国际公寓、上海古北方隅服务公寓、上海浦江方隅服务公寓、上海联航路云涛公寓、上海龙柏方隅服务公寓、北京天璟方隅公寓、北京未来云城方隅公寓、北京沙河方隅服务公寓、成都高新西方隅服务公寓、杭州东站方隅公寓、杭州余杭方隅公寓、杭州青山湖方隅服务公寓、福州白湖亭方隅服务公寓。15家总数经用户纠正，不能据此声称每个正式名称、经营状态和房源承接政策都已逐店人工认可。

主要文件：

| 文件或目录完整路径 | 作用 |
|---|---|
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\outputs\方隅双平台文本业务\15家门店关键词` | 最终逐店CSV、TXT和总表目录 |
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\outputs\方隅双平台文本业务\15家门店关键词\15家门店关键词总表.csv` | 15家优先词总表 |
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\stores\当前门店范围.json` | 记录15家、撤销25家目标和名称确认边界 |
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\stores\最终覆盖核对.json` | 当时资料覆盖、缺口和来源边界 |
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\stores\词库分层验证.json` | 3000条分层前后不变的核验 |
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\stores\public_sources.json` | 公开资料来源记录 |

### 2.3 第一版统一筛选流程

最早定下的顺序是：登记来源与去重，识别本人需求及供需身份，判断地区和时间，多标签分池，核对门店适配，选择母句或进入疑难审核。

评论自身优先。只有指代不明、金额含义不明、否定、供需混合、已租到、旧日期或地区冲突时，才补看已有帖子标题、正文和直接上级评论；不能把每条普通明确评论都拖入长上下文。求租地区与IP分开，来源门店与目标门店分开，意向与联系状态分开。

“不要中介”“不能合租”不能凭一个词机械删掉；要知道否定限制的是什么，回复身份是否符合，是否仍有有效求租需求。供给、结束、无关、信息不足分别记录，不能全叫低意向。

最初的文本规范文件仍存在，但其中“文字就绪、尚未部署、未完成留出验证”的早期状态不能误当当前全链状态：

`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\rules\规则交付与验证.json`

### 2.4 十个需求池

初版十个大池一直是业务骨架：价格预算、位置通勤、户型面积与居住方式、房内设施、宠物、楼层电梯、入住与租期、房源状态、费用合同、看房联系。

一个评论可以同时进入多个池。家庭严肃语境、否定条件、供给身份、需求结束和联系限制另记，不能把这些全部挤进十个需求池。多个需求要形成一条综合接话，不能机械拼成几段。

“需求池”“母句库”“异常处理池”后来被用户明确要求长期有效。最终落实的是这三种业务资产长期维护，不设置整库到期；会变化的是客户当前性、评论时效和门店房源事实。不能用模板长期有效推导客户永久有效。

## 三、母句从10条、50条到按池微调的历程

### 3.1 最初的校准方式和认可边界

第一步先拿10条定口气。用户认可了住户推荐式接法，随后明确说10条都看过，要求一次展示50条或100条，不要一条一条问。于是形成首50条：30条单需求、15条组合、5条语境变体。

首版验证文件记录50条模板中10条沿用已认可原句，40条为新增待审。这是当时的认可状态，不应把后来的方向认可反写成“最初50条全部逐句认可”。用户明确允许使用“我住方隅”“我介绍有优惠”这种口气，并多次强调本人住这里是事实，不准把它再当普遍拦截条件。

相关文件：

| 完整路径 | 内容 |
|---|---|
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\mothers\first10.json` | 首10条校准母句 |
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\mothers\first50.json` | 首50条模板 |
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\mothers\first50-validation.json` | 30/15/5结构及当时认可状态 |
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\mothers\本人认可记录.jsonl` | 认可和纠正记录，含业务资料，不在本历程复制内容 |
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\outputs\方隅双平台文本业务\母评论校准` | 人工审阅模板与场景量表 |

### 3.2 第一类错误：统一品牌被做成了统一介绍句

用户发现50条回复大多仍是同一句介绍。问题并非母句不能复用，而是不同需求池没有真正进入母句选择，统一称“方隅公寓”被错误实现成全部回同一句。

修正要求明确为：先复用已判的需求池和条件，选择相应母句家族，再用评论里的地区、预算、户型、宠物、入住时间等做本地微调。同池同条件可以相同，不同池不能无差别退回统一介绍。用户已经写明的信息不能又当未知重复问。多个池综合成一句，不逐条AI改写。

同50条先形成第二版批量审阅稿，用户又反馈太长、太杂，希望要素不减而简短。随后做短版，通常目标20至40字，多条件时可更长；删掉重复解释和不必要追问，保留关键条件。这是对方向的认可，不是每个变体都完成逐句审批。

历史文件：

- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\pool-mother-review\fifty-review-v2.jsonl`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\pool-mother-review\fifty-review-v3-short.jsonl`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\rules\按池选母句与微调执行方式.json`

真实评论审阅稿后来受30天和低意向清理影响，行数可能减少。它们是历史证据入口，不能以文件名中的“50”推断现在仍保留50条客户记录。

### 3.3 第二类错误：母句修好了，发送方还读旧冻结队列

2026年11月1日本窗口实际核对了用户指出的前8次提交。记录是8次提交、7次平台成功、1次结果未知。发送方消费的旧567行冻结队列只有两种文案；一大部分是统一介绍，另一部分只加了地点。剩余559行也没有因为本窗口做出新稿而自动变成新版。

根因已经落盘：把“分类和草稿准备完成”误认为“发送全链已接通”。当时只对这8条做了本地修订旁注，7条得到修订候选，1条保留核对；没有把实际回执改成新稿，没有重发未知，也没有冒称余下559条已全部换新。

这个阶段查到的资产数字是10个大池、170个池内词项、157个识别表达、78个地区词项、首50条母句和30个短句家族。它们是当时不同层资产的数量，不能互相相加，更不能把“词项多”说成“回复已经适配好”。

核心证据：

`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\reply-consumption-audit-20261101\root-cause.json`

由此补上的要求是：结果文件有版本和哈希；CLI必须明确读取新消费指针；冻结批次、预览、评审稿、最终原样入队稿要能对上。仅发消息给别的窗口、写文件、得到“已收到”都不等于它已经加载新稿。

### 3.4 结论式口气与具体事实的边界

用户反对把正常需求全部改成客服式追问，尤其反对宠物场景总是问“能否带、是否另收费”。方向改为偏结论性的住户推荐：例如宠物池用“宝宝，我住方隅这边，能带猫的，我介绍有优惠。”这一类已明确肯定的说法；楼层、电梯、面积、水电、租期、位置、价格各有对应接法。

这里有两条不能混为一谈：用户对住户身份和特定母句的确认应正常沿用，不再重复卡；但自动程序不能仅凭一个“宠物”“燃气”“便宜”关键词，就把不同门店或不同房源的价格、库存、政策拼成同一套房的承诺。缺具体信息时采用该池通用SOP，并在结构化记录中保留缺口，不靠无尽追问阻塞普通草稿，也不凭空补数字。

之后又将“介绍有优惠”统一调整成“我介绍有优惠”。这是有限的文字替换，并非重写所有历史回复；已发原文与真实回执不能跟着替换。

相关实现：

- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\pool-mother-review\approved-mother-overrides-20261101.json`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\pool-sop-v3\mothers-referral-v4\mother-config.json`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\pool-sop-v3\mothers-referral-v4\renderer.py`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\pool-sop-v3\mothers-referral-v4\test_renderer.py`

## 四、采集不停时，分类如何接续，以及AI路线为何来回变化

### 4.1 增量登记和独立账本

用户要求采集不等分类，采集完成后本窗口直接分类、配母句、写回本地，不要两个窗口反复让用户转述。小红书曾暂停，抖音继续增长。早期抖音1000条仅是检查节点，首次观察到1034条并留痕，不是采集上限；后来5187条首次追平分类。

这些数字是历史检查点。2755、3601属于早期小红书文本批次；抖音后来的12409、18215、34840等也是不同时间的快照，不能拿来充当今天的总量，更不能将两平台、测试样本、重复记录与新增登记混合。

本窗口按稳定评论ID取差集，源采集库只读；来源必须满足资格策略。历史来源按资格文件核验，新增页只收成功解析、评论类型且资格为eligible的数据，排除已知误入的买房来源。更换采集账号不清空去重、不把同条评论当新增；实际采集账号和来源门店保留，但不据来源门店决定客户目标店。

### 4.2 本地规则原型与质量问题

用户希望未来百万条评论主要靠本地链路，少量疑难才用AI。我做过独立本地分类器、流式运行器、冻结配置、上下文回补、留出对照和性能试验。明确规则包括供需、否定、家庭代求租、金额与时间作用范围、需求结束和短句语境等。

原型并未证明接近AI或达到99%。修复版200条历史模型对照中，供需角色一致71条、意向一致69条、需求池集合一致157条；只有30条被本地明确决定，170条要求上下文。它暴露出覆盖和分歧问题，不能把快和词命中当作质量达标。旧模型也不是人工金标，因此这些是一致性对照，不是准确率。

另外跑过100万条合成输入：四进程约19.118秒、约52307条/秒，模型调用计数0。只是重复合成模板的本地分类器吞吐，不是百万真实评论、真实采集、完整账本和发送端到端能力。这个实验说明本地确定性计算可扩量，不能证明语义判断正确。

原型目录：

`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\local-rule-pipeline`

特别要保留的原型文件：

- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\local-rule-pipeline\local_classifier.py`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\local-rule-pipeline\run_local_pipeline.py`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\local-rule-pipeline\acceptance-fix3-report.md`

这是历史原型，不应绕过后续质量纠正重新直接启用。

### 4.3 用户一度明确改为全部AI初筛、细筛

在覆盖不足与担心漏人之后，用户明确要求额度够时所有新增合格评论都用AI语义初筛和细筛，质量优先。回复正文仍按母句本地生成，不变成每条AI重新写一遍。

当时普通额度检查使用率100%、ordinaryUsageAllowed=false，新增5806条冻结待处理。最初没有默认动用额外credits；用户明确允许“现有credits，先小批核对消耗后继续”，又进一步授权优先把这个核心环节做好。随后完成首200条抖音小批及独立细筛，再接后续冻结批。这200条不是小红书批，不是新增采集授权，也不是200条人工金标。

后续形成按帖共享必要上下文、分片逐页落盘、每条显式语义判断、完成文件和质量闸门的接续。曾有7439条冻结批；是否完成以当时manifest、结果SHA、分片进度和发布指针为准，不重复冻结重叠批。存在唯一发布协调者时，只由它完成那一批，不再平行重复派审计，也不让它擅自冻结下一批。

初筛、细筛、定向独立复核是不同阶段，历史12409条初判不能自动标为新增双筛完成。模型usage拿不到就记未知；任务数不能冒充API请求数，全账户credits差额也不能当本任务成本。

这一阶段主要入口：

| 完整路径 | 作用 |
|---|---|
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\prepare_authorized_ai_pilot.py` | 当时有授权的首批小样准备 |
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\douyin-registered-v2\increments` | 历史冻结增量、分片和评审记录 |
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\compile_reviewed_increment.py` | 参数化编译已评审增量 |
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\publish_douyin_increment_snapshot.py` | 校验后发布本地结果快照 |
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\sync_ai_text_status.py` | 同步当时AI链路状态和指针 |
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\check_registered_delta.py` | 只读核对登记差集及冻结状态 |

旧的 `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\sync_douyin_text_status.py` 在当时已经要求弃用，不能用它覆盖新指针。

### 4.4 token消耗失控的纠正

用户随后指出：已有本地池和母句，为什么一下午还在大量使用token。回查并不是只有新增评论的少量判断，而是扩展到了历史回复反复改造、长上下文设计和多轮审查。

2026年10月30日18:32的核对记录显示：当时已发表抖音合格结果34840条，新增登记差集为0，却对12963条历史候选做过重构，并额外形成267条语义参考标签；该历史修订尚未发布。问题是任务范围扩大，不应简单解释为每条新评论天然耗费巨大。

据此停止了无新增的模型工作和重复模型心跳，保留现有源和生产回复指针；改回本地优先，复用既有AI标签，只有真正未解决的新疑难批量交AI。历史全量重跑、母句持续重构、重复多代理审核和空心跳不自动执行。用户曾允许全部AI，是当时授权；不能用那次授权覆盖后来明确的本地优先纠正。

证据和当前优先政策：

- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\cost-audit\用户纠偏与工作核对.json`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\rules\本地优先与疑难AI执行方式.json`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\rules\评论分析执行方式.json`

上述第三份文件保留了一些旧AI额度和授权字段，不能只看到旧字段就恢复全量AI。应结合覆盖文件和用户最新指令判断。

DeepSeek在对话中被提作后续软件模型选择和成本方向，用户还专门要求告知代码窗口“DeepSeek尚未确认”。本窗口不能据此写成已接通真实DeepSeek API、已计费或已完成产品集成。

## 五、地区、IP和品牌统一旁注

用户关心采到外地人、员工给别家店找客户，并要求按客户实际想租地区和时间再核，不能按采集来源店分配。早期反复问每店预算、租期、库存后，用户又明确：母句通常不用具体店名，不明确地区可以统一说方隅公寓，缺店级承接口径不应阻止通用回复。

形成的业务顺序是：客户明确说的求租地点优先；其余参考原采集评论IP归区域；省级IP不能硬当城市和具体店；同地区多店共享候选，不为了凑逐店数量把一个客户重复算成多家确定可接。来源门店、明确目标地区、候选门店、最终指派分别保存。客户没明确地区，不编店名。

我做的是独立地区和品牌母句旁注，保留原判断原稿，以已发布源SHA冻结，源变化后增量更新。禁止默认使用旧manifest导致指针退回。

相关文件：

- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\rules\地域与品牌母句执行方式.json`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\region-brand-routing\build_region_brand_sidecars.py`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\region-brand-routing\current.json`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\region-brand-routing\build_human_report.py`

这个步骤提供有证据的区域候选，不等于每家店的实时库存、最低总预算、入住日和租期政策全部核过。也不能通过IP判断一个人一定住在该城市或只愿意租当地。

## 六、从十个大池到40个细标签，再到可用SOP

### 6.1 细标签旁注先做成独立候选

用户希望十个大池细分，本地关键词尽可能接近语义判断；AI识别过的表达以后能够复用。我先做了不覆盖原AI意向的细标签旁注，记录原文证据的字符范围、分句、极性、条件、否定和OR关系。

第二版是10个大池、40个细标签。对当时12209条历史高意向池，10537条有细标签证据，占86.31%；1672条未命中保留。555条含局部否定信号，20条供需混合，4024条涉及多个池。这是当时全池旁注的统计，不能换算成真实准确率或今天客户数量。

当时细标签与旧AI池完全一致6400条、52.42%，池项重叠71.89%。另外新抽200条中本地明确决定仅17条，183条待语义核对。说明“能找出词证据”与“能独立完成大多数意向判断”不是同一个指标，所以当时保留候选，不直接替换运行中的生产分类。

### 6.2 母句契约和覆盖修复

细标签到母句之间单独做了契约：上游必须先明确主体、极性、条件和所有硬约束，下游只按结构化标签和槽位本地渲染。额外命中一个池并不自动构成冲突；未知价格或地点，也不应把整个普通客户卡成无回复。

用户反复指出“待适配”过多、“多少米”是问多少钱、“滴滴”是联系暗语，要求绝大多数明确租房需求都有池可进、有SOP可接，只有疑难AI托底。随后补了短表达、价格问法、位置、房态、设施、联系等通道；利用已有语义标签和少量表达组复核，避免重新逐条AI写正文。

### 6.3 pool-sop-v3的实际完成范围

2026年11月1日形成12209条历史高意向池的分池和SOP草稿版本。manifest记录：复用历史标签11996条，本地补分87条，有限语义复核126条、22个表达组；原先审阅的50条和旧待适配25条都形成了草稿。分类测试25项、母句测试39项，另2项组合检查。

这证明当时这批历史池已具备SOP承接，不证明未来所有真实评论本地准确率99%。当时manifest仍明确production_consumer_verified=false，发送授权=false。后来有代码窗口接收和消费方面的后续记录，也必须以具体回执区分，不能倒改当时尚未接通的事实。

后来保留的reply-handoff-current汇总记录，将这12209条历史文字结果分为抖音11252条、小红书957条，记录空池0、空回复0、不同回复正文3435种。这回答的是那次历史候选文字准备情况，不是全部采集数、最新筛选后的高意向数或真实发送数；特别不能把957一直当成后来小红书的最新合格客户数。

目录与文件：

| 完整路径 | 地位 |
|---|---|
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\local-subtag-v2\local_subtagger.py` | 独立细标签和意向候选原型 |
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\local-subtag-v2\README.md` | 当时覆盖、限制和运行说明 |
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\local-subtag-integration-20261101\manifest.json` | 10大池40细标签离线候选状态 |
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\subtag-mother-contract\renderer.py` | 标签到母句的独立确定性渲染契约 |
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\pool-sop-v3\classifier\classifier.py` | 后续分池与复用实现 |
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\pool-sop-v3\classifier\rules.json` | 本地分池规则资料 |
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\pool-sop-v3\classifier\semantic-cache.jsonl` | 历史语义复用缓存，含业务资料，不复制到历程 |
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\pool-sop-v3\manifest.json` | 12209条历史阶段说明 |
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\pool-sop-v3\release-report.json` | 当时草稿发布文件和依赖摘要 |
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\当前按池SOP回复指针.json` | SOP消费入口之一，接续前核实际文件 |
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\reply-handoff-current\manifest.json` | 历史两平台12209条文字交付、空池和不同正文统计 |

“AI学过一次下次会用”的实际实现方向是可追溯语义标签、相同语境缓存和已验证规则提升，不是训练了一个专属大模型。不能宣称已经微调模型或构成自动自学习闭环。员工反馈的规则提案、理由、审批、版本和回退是设计内容，不等于百名员工的生产反馈系统已部署。

## 七、真实错回复暴露了什么，如何补语义作用范围

用户发过真实截图：把“寻找房子的持续时间”误当成“只租这么久”，再把宠物的否定条件机械塞进回复，造成明显不自然、答非所问。这个错误本该在本地分类和母句匹配之前处理，不能由发送方临时补救。

之后的纠正重点是：

- 找房耗时不等于租期；实习时长不直接等于租期。
- 月租、面积、年份、押金、水电、人均分摊、工资和每天报价必须区分用途。
- 工作地点不直接等于希望租住地点，公司搬迁日期不直接等于入住日。
- 只因提到猫不能自动说客户养猫，也不能把“不养”改写成正向携宠需求。
- 别人问是否找到房，不等于本人已经找到房。
- 续租问题应落租期池，但不能虚构“肯定能续”。
- 引用别人的话、房东招租、推荐别人的房、群聊广告，不等于本人需求。
- 否定要限制到对应分句；不能一个“不”“没”“中介”就把整条判掉。

后续形成语义守卫、定向复核和本地已确认需求补母句，不重新从零生成正文。当前接续要读这些实际文件，而不是回到早期仅查词的原型：

- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\douyin-semantic-repair-v5\semantic_guard.py`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\douyin-semantic-repair-v5\test_semantic_guard.py`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\douyin-semantic-repair-v5\local_recheck.py`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\douyin-semantic-repair-v5\complete_local_demand.py`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\douyin-semantic-repair-v5\base_renderer.py`

这些修复和反例测试是必要改进，不是对所有历史已发文案的质量担保。不能改掉已发回执后假装当时发送的就是修订稿。

## 八、预算交叉筛选：从误放低预算，到误把高意向筛成零，再修正

### 8.1 最先出现的问题

用户发现一千多、两千多预算的人被列为超高，甚至已经回复后才发现预算不可能承接。原逻辑过于重视明确求租和时间，未把商业预算条件正确交叉进去。用户明确：方隅并没有这种低价房，需求强不等于适合本业务。

我据此做预算、时效、意愿交叉筛选，并保存客户本人预算、来源帖价格与其他金额的不同证据。不能把工资、押金、费用或过去租金当可用月租预算。

### 8.2 又发生过的过筛问题

之后两个平台高意向一度成零。问题转向另一个极端：把“必须明确报4000以上”当作全部高意向前提。用户再次纠正：明确想租、无明显不匹配证据，即使没报金额也应保留中高需求；预算符合、时间也近且需求明确，才是超高。没有金额不等于预算不足。

这个纠正促使本地筛选拆成独立轴，不再用一个布尔条件决定所有层：供需身份、需求强度、预算证据、原评论时间、地区冲突、联系限制、回复准备状态。

### 8.3 v4.3形成的业务口径

本次只读核对的代码版本仍是 `fangyu-commercial-fit-v4.3-20261106`。其主要意思是：

| 等级/状态 | 业务含义 |
|---|---|
| 超高 | 本人明确求租、可用预算符合门槛、近15天且无已知冲突 |
| 高 | 明确求租或正在找房，无明确不匹配证据；预算允许未知 |
| 中 | 租房语境中问价、位置、设施、房态、看房等，未充分表达本人正在租房 |
| 低 | 明确不够的客户预算，或明显低价来源房源兴趣且无更强兼容预算证据 |
| 待核 | 金额用途、供需主体、时间或语境冲突，需要保留而非猜删 |
| 非客户/结束 | 供给、无本人求租、纯互动或明确需求结束，按实际原因处理 |

当时实际代码门槛是：明确整租月预算上限低于3000排出待发；3000至3999保留待核，不擅自当完全匹配；4000及以上也必须结合本人需求和时间。客户明确给出兼容月预算时，优先于来源帖低价；来源房源的明确低月租另作过滤，不冒充客户亲自报出的预算。视频口播或画面未提取到本地，价格就是未知。

这段写的是已落盘的阶段规则，不是本历程重新制定门店价格。门店承接口径日后变化，要由业务确认后另改规则，不应在写历程时顺手修改。

当前主要文件：

- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\business-fit\business_fit.py`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\business-fit\test_business_fit.py`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\rules\预算时效交叉筛选纠正.md`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\rules\意向分级与预算口径-20261105.md`

最后一份说明仍保留“超过90天低优先”和“仅抖音30天归档”的旧段落，后面的11月6日双平台删除政策优先；读到旧段不能恢复旧归档路线。

## 九、时效、排序和CLI入队的反复修复

### 9.1 为什么要把时间放最前

用户发送数百条、上千条后回应很少，发现不少客户是一个月甚至更久以前找房，多半已找到。用户明确要求近7天最高，8至15天其次，较早记录极低优先；最终顺序是时间、预算、租房意愿，而不是先看意向强度再把近期客户压在旧高意向后面。

时间必须用原评论发表时间，不用采集时间、重新分析时间或文件修改时间。相对日期按可靠采集锚点理解，不能今天重跑就把旧的“明天”变成新的明天。兼容原日期字段、嵌套原始元数据以及秒/毫秒时间戳；未来和未知日期隔离。

### 9.2 排序文件与真实发送队列脱节

用户曾问为什么近7天回复为零，原来本地排过序不等于CLI按新顺序消费。又出现30天候选总数与实际入队数不同，被误解释成筛选没做完。必须分别说明：时间范围内评论、业务合格客户、已有母句、当前账号可回复、账本去重后入队、已发和未知，各有不同分母。

我把本地排序结果做成消费指针，按源SHA核对，不允许静默退回旧默认队列。已发、未知、在途和客户级重复在入队和发送前再查；真正的平台发送边界仍归CLI。

用户特别要求正常的“我住方隅”推荐口气不能再卡掉候选。解决方向是文字身份口气按本人确认沿用，预算、时间、需求和联系限制独立检查；不是取消共享账本去重或目标校验。

### 9.3 两平台接续

抖音排序和发布队列有本地入口；小红书后来也按当时444条源重建过优先发送批次。444是那次源规模，不是此后永远固定的可回复数。新采集进入本地判断和排序，原正在发送批次不被本窗口强制替换。用户必须到对应CLI窗口下达发布指令。

时间刷新改成纯本地，不为每日排序逐条调用模型。建立Windows任务 `Fangyu-Local-Daily-Time-Sort`，后来记录的运行间隔为15分钟，并在完成抖音新快照后再刷新一次。

主要入口：

| 完整路径 | 作用 |
|---|---|
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\recency-priority\recency.py` | 原评论日期、时间档和优先级计算 |
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\recency-priority\daily_time_sort.py` | 按最新账本和业务筛选本地排序 |
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\recency-priority\daily-priority\current.json` | 两平台当前排序结果指针 |
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\recency-priority\publish_douyin_send_queue.py` | 抖音排序到消费队列的衔接 |
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\recency-priority\build_xhs_source_queue.py` | 小红书来源及时间队列整理 |
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\rules\时间优先排序-20261102.json` | 排序历次更新与本地任务说明 |

## 十、4712条本地复核与旧库覆盖核对

用户围绕“约15000条30天内评论，剩下为什么没入候选”反复追问。我的早期回答把不同子集、待核和低意向混在一起，造成用户认为几千条未经解释就被筛掉。后来必须明确：待核不等于未处理；未入队也不必然是低意向；固定复核4712条只是一个具体批次，不是全部约15000条的替代分母。

按用户要求，这4712条不用AI全量重核，而走已建立的本地链路。2026年11月6日完成记录表明4712条全部逐条本地检查，支持需求1200条，并均有母句；model_calls=0、platform_requests=0，本地执行耗时约1.223秒。判断为待核的记录仍有明确处理结果，不能冒称完全没分析过，也不能自动变成负样本。

另做旧库完整覆盖核对，记录合格旧来源缺失0、已支持需求缺母句0、保留待核2147、测试51项通过，以及CLI消费方已确认接续。它是当时覆盖核对结果，不是51项测试证明全部真实评论准确。期间没有修改源采集库、真实发送回执或活动发送批次。

主要证据：

- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\local-backlog-recheck-20261105\manifest.json`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\local-backlog-recheck-20261105\summary.json`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\old-library-audit-20261106\run_audit.py`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\old-library-audit-20261106\completion.json`

## 十一、11月6日的大清理：不是归档，而是删除过期和已确认低意向

### 11.1 用户最后收紧的范围

用户要求在采集窗口、共享账本和系统显示中删掉超30天记录，之后又明确：意向筛完只留中、高、超高，确认低预算、低意愿也删除，不再一堆历史数字干扰判断。不能影响采集和正在发送的任务。

我明确分开三层处理：

1. 业务记录中的过期、确认低意向、非客户和需求结束记录删除，不只移到可见历史归档。
2. 未判清、未处理的新评论留后台，不误当低意向删除，也不显示为可用客户。
3. 已发送、结果未知、占用和恢复链所必需的最小防重及签名证据隐藏保留。不能为了界面清爽破坏防重、未知停线和原始回执。

分类规则、搜索词、母句和门店资料是长期业务资产，不按30天一起删除。

### 11.2 采集源的删除由源窗口实施

我协调抖音采集源窗口处理其拥有的collection.sqlite3、runner缓存和采集计数，没有由根文本清理脚本并发乱改源库。

源窗口起初按自然日边界处理，本窗口发现与“滚动30天”不一致，要求改成精确30×86400秒；源窗口补清边界记录，建立过期指纹，防旧缓存或旧页面重新导入。

对确认低意向，又要求使用最新版v4.3及整份all-pool文件SHA，逐条核对评论ID和原文证据。明确低预算的硬原因不能与高意向标签冲突；冲突就拒删待核，不能按关键词猜删。该次源窗口报告删除9211个独立评论：非客户7343、低意向1856、需求结束12；78条文本或快照不匹配拒删，规则矛盾0。未判清继续保留后台。

上述9211是源窗口交接并有本地证据的独立评论数量；不能与后面的数百万“副本引用”相加。

源证据与实现路径：

- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\runtime\collection.sqlite3`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\comment_retention.py`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\classified_comment_prune.py`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\comment-retention-rolling-verification-20261106.json`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\classification-exclusion-verification-20261106.json`

本窗口当时也查明采集源进程在前夜已因请求超时退出；不是这轮本地清理把采集杀了，不能将其误记为清理造成的故障。后续用户在采集窗口重新授权恢复，由源窗口独立管理，本窗口只接新观察，不接管账号或平台限制。

### 11.3 本窗口清理文本副本和缓存

我做了项目范围内的文本清理器，按评论标识、原平台日期和删除指纹清JSON/JSONL引用；原平台时间优先于旧扁平快照。明确排除词库、母句、规则、门店资产、夹具和正在由生产构建器生成的规范输出。写入用临时文件、原子替换及并发写入检查；遇权限占用有界重试，变化中的文件不盲盖。关联指针的文件哈希随实际改动核对。

实际经历多轮：

- 第一轮检查2959份文件，修改1344份，清掉2546096处过期记录引用。
- 合入源低意向指纹后的下一轮检查2961份，修改1174份，清掉653911处引用。
- 小红书补清后的最后记录检查2996份，修改505份，清掉22110处引用；无延后失败项。

这些是重复快照和副本中的引用，不是新增或独立客户数。中间文件会被后一次报告覆盖，因此历程分别记录当时执行结果，不把三轮数字包装成单次客户删除量。

私有SQLite缓存先清138062行，后续增量又清22行。共享账本先删2168份可安全移除的旧assessment正文，后续2份；随后删2319条已经确认清除、没有发送索引和assessment依赖的未联系旧lead。发送过、结果未知、在途以及活动队列所需接口没有粗暴哈希替换。

之所以不能直接把共享库所有原ID都抹掉，是当时实际消费者仍直接按原ID读取reserve、outcome、check、prepare和发送去重。如果中途改成另一种键，会让原令牌、未知结果和在途流程失去对应。处理方式是业务可见池只用正向名单；底层必要索引隐藏保留，未接触旧行在依赖允许时物理删除。

另删除48份旧人可读客户统计/评论导出，保留词库、规则与母句，把主入口改成只看当前客户池。旧历史总量、低意向和待核数不再堆到用户眼前。

### 11.4 小红书不是直接照搬抖音源删除

我对小红书已有分类文本用v4.3本地重筛，形成仅中、高、超高且eligible的独立正向文件。当次可见416条，待核后台保留；确认删除及过期共887条。无AI调用、无平台请求，不动正在发送批次。

小红书源和冻结发送文件归小红书窗口处理。我提供正向文件和排除指纹，要求其完成依赖，而不是只删正文留下坏哈希。该窗口交接记录显示：冻结评论源和分类源各清1994处引用，草稿源清384处；39份旧派生文件中34份有改动，共清8424处引用；历史发送事件做最小化。它们也都是文件引用统计，不是独立客户数。

清理还暴露了历史特例授权绑定原正文哈希的问题。特定未知结果隔离授权不能靠改常量哈希“复活”；最终要求将失去证据的旧特例明确退休，保留未知停线，新普通队列另做离线验证。对方记录两账号新队列180条和34条离线预览通过、local_holds=0，本轮发送0；这不等于获准清除未知停线，也不是已发送。

源窗口文件仅作为本窗口协调的边界和交接证据，不冒称均由本窗口亲手开发：

- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\xhs-resume-20261103\frozen-retention-deletion.json`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\xhs-resume-20261103\retention-dependency-rebuild.json`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\xhs-send-current-20261029\retirement-verification.json`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\xhs-send-current-20261029\current-visible-statistics.json`

### 11.5 清理器和结果清单

| 完整路径 | 功能及注意事项 |
|---|---|
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\rules\只保留30天评论执行方式.json` | 11月6日双平台最终删除及显示政策，覆盖旧归档说明 |
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\recency-priority\retention30.py` | 原评论时间、滚动30天和删除指纹判断 |
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\retention-cleanup-20261106\scrub_text_records.py` | 文本副本清理；会真实改数据，不能当只读检查随便运行 |
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\retention-cleanup-20261106\prune_cached_records.py` | 私有缓存、允许删除的旧assessment及未联系lead清理 |
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\retention-cleanup-20261106\retain_xhs_business.py` | 小红书既有文本重筛、删除及正向池生成 |
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\retention-cleanup-20261106\refresh_visible_business.py` | 当前可见统计、状态和进度页更新；不带refresh-only时还涉及旧导出清理 |
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\retention-cleanup-20261106\expired-fingerprints.json` | 已清除记录指纹集合，后来也合入确认低意向，不应只按文件名理解为日期过期 |
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\retention-cleanup-20261106\text-cleanup-result.json` | 最近一轮文本副本清理结果 |
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\retention-cleanup-20261106\cache-cleanup-result.json` | 最近一轮缓存及共享正文清理结果 |
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\retention-cleanup-20261106\xiaohongshu-cleanup-result.json` | 当次小红书本地重筛结果 |
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\retention-cleanup-20261106\final-verification.json` | 当时两平台正向池和23项回归核验、未实施范围 |

“删除”在这里是业务工作副本与允许清除的数据行删除，不是对所有磁盘扇区、备份、SQLite历史页或签名原始证据做密码学擦除。部分必须保留的回执与防重索引明确排除于业务显示；不能对外宣称所有原始字节都消失。

## 十二、本地持续工作者、状态指针和可见数字

### 12.1 持续分类工作者

最终持续接续入口是douyin-semantic-repair-v5。它监听已登记的源变化，按稳定ID增量处理，复用本地规则与历史语义结果，只在另有授权时做少量疑难AI。它不登录、不请求平台、不发送评论。

构建器做过的重要兼容修改包括：

- 从源评论读取原平台时间，覆盖旧缓存中不可靠的扁平日期。
- 只纳入仍存在于源库且满足资格的评论ID，防止源删完、旧基线又造出一批缺原文的幽灵记录。
- 30天外不再生成业务归档文件，旧归档输出置空。
- 全部已处理文本与待核后台仍可分开保存；用户可见文件只保留medium/high/super_high且eligible。
- 每次快照后本地排序并刷新消费指针、可见统计。
- 复核结果按原文和必要语境指纹缓存，源和规则变了才重新判，减少重复计算。

watch_increment.py有Windows单实例锁，build_snapshot.py有构建锁；有签名变化才构建，轮询间隔60秒，并通过时间桶让旧评论自然过窗。后台本地轮询不等于每分钟叫醒模型。用户要求的模型核验频率后来降为约15分钟低频或异常时，正常无需重复通知。

### 12.2 稳定运行的计划任务

因为先前直接启动的本地工作者曾在会话交接后不稳定，本窗口补了Windows计划任务 `Fangyu-Local-Text-Worker`，由ensure_text_worker.py先核单实例锁再托管工作者。重复任务IgnoreNew，不会为了显示进度启动第二份；启动目录曾在检查中发现偏一层，已经修成工程根目录。任务不包含采集或发送动作。

代码修改写盘并不会热更新正在运行的Python进程。例如watch_increment.py后来改成简化进度文案，旧进程未重载前仍可能按旧格式写实时进度。实际用户界面应读新的可见池，不能把编辑脚本误称运行窗口已刷新。

### 12.3 当前关键运行文件

| 完整路径 | 用途 |
|---|---|
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\douyin-semantic-repair-v5\watch_increment.py` | 单实例本地工作者 |
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\douyin-semantic-repair-v5\build_snapshot.py` | 本地源核对、分类、母句、快照构建 |
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\classification-handoff-status.json` | 分类发布状态与工作者心跳入口 |
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\douyin-semantic-repair-v5\all-pool-business-fit.jsonl` | 已处理全池，可含后台待核，不直接当可用客户总数 |
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\douyin-semantic-repair-v5\retained-business-customers.jsonl` | 抖音当前正向业务名单 |
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\douyin-semantic-repair-v5\douyin-replies.jsonl` | 抖音文字结果和回复资料 |
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\douyin-semantic-repair-v5\pending-candidates.jsonl` | 排除已发/未知等后待回复候选 |
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\douyin-semantic-repair-v5\visible-refresh-status.json` | 可见统计刷新结果 |
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\douyin-semantic-repair-v5\watch.log` | 本地构建日志，可能含业务资料，不复制到历程 |
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\recency-priority\xiaohongshu-retained-business-customers.jsonl` | 小红书正向文本名单，需核自身更新时间 |
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\retention-cleanup-20261106\ensure_text_worker.py` | 本地计划任务托管器 |
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\retention-cleanup-20261106\visible-current.json` | 对人的统一精简统计与来源SHA |
| `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\当前文本处理运行状态.json` | 已改为精简当前状态，不再堆旧AI批次累计数 |

### 12.4 统计为什么不能继续相加

用户最后希望只看抖音多少、小红书多少、中高低意向多少、已回复多少，后来又进一步要求不显示过期和低意向。最后的人用界面主要保留符合条件、本批可回复、已回复，不再展示历史累计、源原始总数和后台待核总数。

“已回复”要按当前正向池与真实已发凭据取交集，不是过去所有账号所有历史成功数。“本批可回复”还是当前账号、当前批次、目标可用性、客户级去重及未知记录拦截后的数量，不等于所有正向客户都可在当前账号发送。去重口径有评论和客户两种，不能看见数量少了就说被低意向筛掉。

本窗口曾按用户要求改写给领导的汇报数字，随后用户明确只改数字不要扩写。因此后续不能顺手把采集速度、日上限、转化率等未经当前同分母核验的假设一并变成事实。高意向率必须说明平台、截止时间、去重单位、已分类覆盖和意向级别，不能拿已分类子集的比例冒充全部采集率。

## 十三、和CLI、共享账本、代码窗口如何衔接

### 13.1 共享账本与发送去重

共享库是：

`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\shared-acquisition-ledger\shared.sqlite3`

本窗口涉及文字层时主要读取leads、assessments、reservations、身份别名及已有发送证据。不同发送端仍可能直接SQL读取这些表，故数据迁移必须考虑兼容，不能只改一个入口。

另一个实际回执来源是：

`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\Codex获客工作台\work\reply_receipts.sqlite3`

不能只读一个库就报全部发送数，也不能把评审稿、草稿或提交当平台确认。未知不能重发，缺事实不能伪造回执。

### 13.2 抖音发送窗口显示的协调

本窗口协调发送窗口将summary.py和panel.py改成只读当前正向池与账本交集。旧面板曾是控制器的父进程，直接关会影响任务，发送窗口采取最小化旧面板、另开独立只读面板，而非杀父进程。

后来发送窗口只读复核实际数字正常，但一度无法将窗口置前截到目标页面，因此没有称那次已完成视觉验收。它还报告自然停线或上笔未知时，本窗口没有代为启动、切号或解除限制。

相关文件：

- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\douyin-local-control\summary.py`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\douyin-local-control\panel.py`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\douyin-local-control\active.json`

这些属于发送窗口管理范围。历程写路径用于定位，不代表本次读取了账号资料或接管其运行。

### 13.3 小红书窗口与页面

小红书重建过当前待发入口、离线预览和简化统计页。根文本刷新程序后来也更新两个人用HTML页，带本地页面重载提示，只读显示当前正向池，不控制采集发送：

- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\outputs\小红书15店采集进度\进度.html`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\outputs\小红书回复发送进度\进度.html`

HTML定时重载不等于数据生成器和小红书新采集分类链已自动持续接通。要核实际生成时间、输入SHA及小红书窗口状态，不能因页面能打开就称双平台实时同步全部完成。

### 13.4 代码与功能整合窗口的交接

本窗口先后交代过：真实门店目录、IP字段、来源地区与目标地区分离、逐批输入和分析回执、服务器搜索进度、跨员工跨店去重、反馈审批和版本发布；后来又交代按池母句、短句、细标签、本地优先、预算时间意愿排序、最新消费指针和正向显示。

这是业务定义和文字材料交接，不等于这些服务器和员工功能全部已开发。用户说软件后接DeepSeek，也不是本窗口擅自开付费API的授权。

截至11月6日最后清理验收，代码窗口明确说客户版界面尚未实施这轮正向显示，因为其当时额度停线没有继续修改。本窗口最后向用户如实报告“本地和CLI已处理，客户版旧界面尚待同步”，没有宣称所有界面都生效。

客户实例位置：

`C:\积木软件工坊\项目\方隅公寓客户版`

本历程没有重验客户版是否在其他窗口后来完成更新，不能把11月6日的未完成状态推断成11月10日一定仍未完成，也不能反过来假设已经部署。应由代码窗口当前交付证据确认。

## 十四、本次11月10日只读核对到了什么

本次没有为了写历史去读客户明细或重新计算全量业务数据，主要查看目录、规则文本、历史聚合报告和当前工作者摘要。

只读看到：

- business_fit.py的版本常量仍为v4.3-20261106。
- 抖音分类交接状态的快照更新时间为2026年11月10日06:16:34 UTC，即北京时间14:16:34；工作者摘要检查到06:20:38 UTC，即北京时间14:20:38，phase为watching_for_registered_delta，model_auto_calls=false，error为空。
- 摘要记录的工作者进程号已不是11月6日那一份，说明不能把旧进程号继续当当前运行事实。这里仅记录摘要和任务管理器状态，未独立做完整进程、源增量、发送端到端健康验收。
- Windows任务Fangyu-Local-Text-Worker为Running，Fangyu-Local-Daily-Time-Sort为Ready；Ready只表示任务等待触发，不等于排序故障，也不等于刚成功刷新。
- 当前精简状态文件也更新到了11月10日；11月6日的latest-continuation-health.json仍是旧检查留痕，不能覆盖新交接摘要。
- 一些最早的规则交付、旧母句审阅和原型manifest仍保留当时“未接生产”的状态，它们是历史记录，不应整份拿来覆盖当前指针。

本次没有核实真实采集是否正在成功产出、今日发送量、今日回复率、平台限制、当前账号授权、全部软件界面或现金转化。历史文档不输出一组新的“今天业务总数”来制造额外混淆。

## 十五、现在怎样定位、启动与接续

### 15.1 先看状态，不直接开第二份任务

后续接续应先读当前源、消费指针、规则覆盖关系和单实例锁。尤其不能把几个月前的heartbeat文字当当前模型授权，不能因为存在历史批次目录就重跑AI。

只读定位可使用以下命令；本次仅把它们写入文档：

```powershell
Get-Content -LiteralPath 'C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\classification-handoff-status.json' -Raw
Get-Content -LiteralPath 'C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\当前文本处理运行状态.json' -Raw
Get-ScheduledTask -TaskName 'Fangyu-Local-Text-Worker','Fangyu-Local-Daily-Time-Sort'
```

然后核对交接摘要引用的文件存在、SHA一致、评论标识稳定、时间未过窗。全池包含后台待核时，不把它当可见正向池。新源差集应走现有本地工作者，不重新冻重叠批。

### 15.2 本地分类工作者确实不在运行时

只有在后续获授权进行运维、且确认不是用户主动暂停时，才由原入口接续。已有计划任务时优先恢复它，不同时手工再开watch_increment.py。必须先核STOP标记的来源；不能为了恢复任务删除用户设置的停止。

计划任务托管入口的完整路径是：

`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\retention-cleanup-20261106\ensure_text_worker.py`

独立工作者入口是：

`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\douyin-semantic-repair-v5\watch_increment.py`

它们是本地写入程序，不是只读预览；本次没有执行启动、恢复或重启。

### 15.3 修规则或母句时怎样不重演旧问题

先冻结待改规则、代表反例和当前消费指针；针对出现的问题修局部作用范围和模板选择。已有样本一旦用于改词，就归为回归样本，不能继续称独立留出。确认词法覆盖、语义判断、草稿承接、消费者加载是不同验证。

开发后核对：同一评论需求是否保留，否定是否反转，时间是否错填，预算是否来自本人，回复是否选对应家族，槽位是否真的来自已知证据，旧回执是否保持原文。只在实际授权后切换后续批次，禁止重写正在发送批次或把已发原稿替换成新话术。

复用的测试入口包括business-fit/test_business_fit.py、语义守卫测试、complete_local_demand测试、母句renderer测试、recency和retention测试，以及清理器7项回归。11月6日清理验收23项是当时7项清理加16项业务筛选；更早旧库核对的51项属于另一轮范围，不把它们相加当覆盖全部业务。

### 15.4 若确实还需要AI

仅选择本地无法可靠判断的新疑难；按帖共享必要上下文，输出最少结构化标签和依据，不逐条重写回复。保留原本地判定、修订来源、规则版本和可取得的实际usage。预算不明、地区不明、疑难不能统一标低，也不能无证据强升高。未有新差集时不自动做模型任务。

历史全AI编译和发布脚本只用于恢复明确尚未完成且有原授权的冻结批，先核唯一owner、manifest、阶段、完成文件和SHA。不能因历史credits许可仍在JSON里，就恢复新的大批全量模型作业。

### 15.5 真实发送的接续

本窗口只交文字候选、排序和版本证据。账号、平台验证、限流、目标可达性、队列预留和提交由对应CLI窗口执行。用户到CLI说发布后，由该窗口按最新规则和账本准备；不是运行本文某个脚本就自动发送。

如果当前有unknown或验证码/平台限制，保留停止原因，不重发未知、不换号绕过、不伪造授权。旧内容哈希特例失效时退休旧scope，不通过换常量绕过原证据要求。

## 十六、还没有解决、不能夸大和需要继续留意的事项

1. **99%是业务目标，不是已证明准确率。** 历史高意向池SOP覆盖100%，不代表所有未来原始评论本地准确。细标签词命中、模型一致性、合成压力测试和真实发送效果必须分开。
2. **低意向规则经过两种极端错误。** 一度放过明显低预算，后来又把没报足额预算的人全拦；后续维护不能再回到其中一端。预算、来源价格、需求、时效和联系边界各自保留证据。
3. **缺上下文不等于没有需求。** 也不能为了达到高覆盖把纯互动、供给、广告和已结束都强塞为客户。待核要有明确原因，并与可见客户池分开。
4. **短句需要语义作用范围。** 找房耗时、实习时长、租期、金额用途、否定对象和第三方引用都是已出现过真实风险的部分。母句层不能补救上游把条件解析错的问题。
5. **模板口气认可不等于所有事实都已核验。** 用户确认住户口气要正常使用，不能反复当全库拦截；但具体库存、报价、优惠、设施和门店政策仍不能自动拼凑。
6. **本地缓存复用不是训练完成专属大模型。** 尚无本窗口证明DeepSeek真实API已接通或模型微调完成；员工建议的共享审核和自动发布也不能当生产事实。
7. **小红书正向名单要核自身时点。** 页面重载和抖音工作者健康不能证明小红书新采集全都同步分类。要核新输入、来源日期、分类版本和待发哈希。
8. **旧规则文件有并存冲突。** 早期不删除、90天低优先、仅抖音30天归档，已被11月6日双平台滚动30天删除和正向显示覆盖。历程记录冲突，不在本次顺手改使用中规则。
9. **工作者脚本和运行进程不是同一个状态。** 修改文件后旧进程可能仍用旧显示逻辑；应由后续受控维护在检查点验证加载，不能写盘就说已生效。
10. **历史清理报告不是永久全盘删除保证。** 必须防止旧快照、旧缓存重导；保留最小防重、签名恢复证据不显示为客户。不能宣称做过磁盘安全擦除或所有备份销毁。
11. **软件客户版与本地CLI分开验收。** 11月6日客户版界面迁移未由本窗口证实完成；11月10日也没有借写历史重验或修改。其他窗口若后来完成，以其实际交付证据为准。
12. **真实转化率尚没有本窗口闭环证据。** 用户说回复很少，不能直接断言平台异常或正常；时效、文案、预算、可见性和送达都可能影响。没有完整曝光与回信证据，不承诺回复率或商业转化。
13. **逐店承接量不能按来源分摊。** IP通常只到区域，同区域多店候选不能算多份确定客源。缺实际门店事实时可以通用品牌接话，但不等于已经证明某家店可接多少。
14. **跨窗口沟通要少而准。** 用户多次反对来回打扰。正常本地增量和普通进度静默落盘；只有实质失败、必须用户处理或约定重要节点通知。没有明确授权不向其他聊天发消息，本次历程任务没有发送跨窗口消息。

## 十七、本窗口最后应交给接续者的认识

这条链路不是“有词库就好了”，也不是“全交AI就好了”。本窗口实际踩过的坑依次包括：门店基数误解、泛介绍句替代按池回复、草稿与CLI旧队列脱节、模型工作扩到无新增历史重构、否定和时间作用范围错读、预算漏筛与过筛、排序文件未被发送消费、统计分母混乱、源删除后旧缓存复活，以及清理正文破坏历史哈希依赖。

最后形成的接续方式是：按原评论和来源资格登记去重，本地识别主体与约束，按时间、预算、需求交叉判断，多池细标签选择已认可母句并本地微调，疑难另留；按当前正向名单生成和排序候选，消费方明确核版本与SHA，真实发送仍受共享账本、账号和平台回执约束。过期和确认不适配的业务记录按用户要求清除，未判清后台保留，必要防重证据不干扰可见数字。

所有历史数量、认可状态和完成状态都只在自己的时间点和范围内成立。本文件用于让接续者知道为什么这样做、哪些路不能再走一遍，不是新的使用中规则，也不是恢复任何暂停任务或发送的指令。
