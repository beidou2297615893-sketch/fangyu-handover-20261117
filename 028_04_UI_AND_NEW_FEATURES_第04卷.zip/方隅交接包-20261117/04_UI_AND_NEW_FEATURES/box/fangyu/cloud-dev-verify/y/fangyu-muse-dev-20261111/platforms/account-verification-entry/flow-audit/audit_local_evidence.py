from pathlib import Path
import collections,datetime,json,re,sqlite3,zipfile,xml.etree.ElementTree as E
T=Path(__file__).resolve().parent
P=Path('C:/积木软件工坊/项目/方隅公寓客户版')
D=Path('C:/Users/rmsama/AppData/Local/Packages/OpenAI.Codex_2p2nqsd0c76g0/LocalCache/Local/fangyu-apartment-clientWorkspace')
file=P/'outputs/验证续接实测/客户清单82位.xlsx'
ns={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
with zipfile.ZipFile(file) as z:
 shared=[''.join(n.itertext()) for n in E.fromstring(z.read('xl/sharedStrings.xml')).findall('m:si',ns)]
 root=E.fromstring(z.read('xl/worksheets/sheet1.xml'));rows=root.findall('m:sheetData/m:row',ns)
 def cell(c):
  v=c.find('m:v',ns)
  return shared[int(v.text)] if c.get('t')=='s' else (v.text if v is not None else ''.join(c.itertext()))
 values=[[cell(c) for c in row] for row in rows]
 technical=re.findall(r'(?i)(?:C:\\Users|tenant_id|sourceDigest|rule_version|traceback|schema_version)',json.dumps(values,ensure_ascii=False))
 export={'rows':len(rows)-1,'bytes':file.stat().st_size,'technical_string_matches':len(technical),'header':values[0]}
 assert export['rows']==82 and not technical
(T/'EXPORT-82-CHECK.json').write_text(json.dumps(export,ensure_ascii=False,indent=2),encoding='utf-8')
report=json.loads((T/'FLOW-TESTS.json').read_text('utf-8'));report['export']=export
(T/'FLOW-TESTS.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
db=sqlite3.connect(D.joinpath('workspace.sqlite3').as_uri()+'?mode=ro',uri=True)
db.row_factory=sqlite3.Row
entities={r[0]:r[1] for r in db.execute('select entity,count(*) from records group by entity')}
entity_names=[n for n in entities if any(v in n for v in ('run','repl','task'))]
replies=[json.loads(r[0]) for r in db.execute("select body from records where entity='replies'")]
plans=[json.loads(r[0]) for r in db.execute("select body from records where entity='ui_reply_delivery_plans_v1'")]
summary={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'related_entity_counts':{k:entities[k] for k in entity_names},'reply_status_counts':dict(collections.Counter(r.get('status') for r in replies)),'plan_status_counts':dict(collections.Counter(r.get('state') for r in plans))}
activity=D/'accounts/cloud-5f633971ed95c5a0e0187b71/7dadec8b3e6241d583f8b234619ae32c/platform-activity.jsonl'
items=[json.loads(x) for x in activity.read_text('utf-8').splitlines() if x.strip()]
summary['activity_record_count']=len(items)
summary['activity_keys']=sorted({k for r in items for k in r})
summary['stage_counts']=dict(collections.Counter(str(r.get('stage')) for r in items))
summary['http_status_counts']=dict(collections.Counter(str(r.get('status')) for r in items if type(r.get('status')) is int))
summary['last_40_event_metadata']=[{k:r[k] for k in ('at','stage','kind','status','elapsed_ms') if k in r} for r in items[-40:]]
summary['last_event_metadata']=[{k:r[k] for k in ('timestamp','at','utc','event','kind','operation','command','status','reason','method','path','endpoint') if k in r and isinstance(r[k],(int,float,bool,str)) and len(str(r[k]))<180} for r in items[-12:]]
(T/'LOCAL-STATE-EVIDENCE.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'export':export,'reply_status':summary['reply_status_counts'],'stage_counts':summary['stage_counts'],'http_status_counts':summary['http_status_counts'],'last_events':summary['last_40_event_metadata'][-18:]},ensure_ascii=True))
