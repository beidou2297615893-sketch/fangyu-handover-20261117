"""Exercise the installed entry with the real batch/history in a temporary root.

Network is forbidden and the final worker call is intercepted before execution.
Only this validation report is persisted in the project.
"""
from contextlib import ExitStack,closing
import copy
import hashlib
import json
from pathlib import Path
import sqlite3
import sys
import tempfile
import traceback
from unittest.mock import patch

BASE=Path(__file__).resolve().parent
REAL=BASE.parents[1]
COMMON=REAL/'work/douyin-local-control'
sys.path.insert(0,str(COMMON))
import control
import account_batch

def read(path):return json.loads(path.read_text(encoding='utf-8-sig'))
def write(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')

def main():
    active=read(COMMON/'active.json');source=Path(active['task'])
    manifest=account_batch.queue_at(source)
    exclusions=account_batch.historical_exclusions(REAL,manifest,source)
    ledger=REAL/'work/shared-acquisition-ledger/shared.sqlite3'
    with closing(sqlite3.connect(ledger.as_uri()+'?mode=ro',uri=True)) as db:
        rows=db.execute("SELECT platform,comment,customer,token,status FROM reservations WHERE platform='douyin'").fetchall()
    boundary=[];resolution_ready=[]
    with tempfile.TemporaryDirectory(prefix='douyin-start-validation-') as td,ExitStack() as stack:
        root=Path(td);work=root/'work';work.mkdir();common=work/'douyin-local-control';common.mkdir()
        task=work/source.name;task.mkdir()
        for name in account_batch.CODE_FILES+account_batch.OPTIONAL_FILES:
            if (source/name).exists():(task/name).write_bytes((source/name).read_bytes())
        for name in ('approved-cli-queue.json','continuation-state.json','captcha-recovery-authorization.json','batch-runner-status.json'):
            (task/name).write_bytes((source/name).read_bytes())
        for name in ('page_guard.cjs','attempt_recovery.py','account_batch.py'):
            (common/name).write_bytes((COMMON/name).read_bytes())
        write(common/'active.json',dict(active,task=str(task)))
        write(common/'accounts.json',{active['account_uid']:str(task)})
        d=work/'shared-acquisition-ledger';d.mkdir()
        with closing(sqlite3.connect(d/'shared.sqlite3')) as db:
            db.execute('CREATE TABLE reservations(platform TEXT,comment TEXT,customer TEXT,token TEXT,status TEXT)')
            db.executemany('INSERT INTO reservations VALUES(?,?,?,?,?)',rows);db.commit()
        identity={'account_uid':'offline-new-execution-account','nickname':'离线核验账号','connection_id':'offline-fixed'}
        def probe(timeout=None,*,discover_current=False):
            assert discover_current
            return identity
        def no_process(args,**kwargs):
            script=next((Path(arg) for arg in args[1:] if str(arg).endswith('.py')),None)
            assert script is not None and script.parent.is_relative_to(root),'unexpected process outside temporary root'
            assert script.name=='batch_reply_runner.py','unexpected process: '+script.name
            selected=read(common/'active.json')
            copied=Path(selected['task'])
            assert read(copied/'approved-cli-queue.json')['items_sha256']==manifest['items_sha256'],'queue mismatch'
            assert resolution_ready==[True],'resolution did not allow continuation'
            boundary.append(True)
            raise RuntimeError('OFFLINE_VALIDATION_COMPLETE_WORKER_NOT_STARTED')
        stack.enter_context(patch.object(control,'P',common))
        stack.enter_context(patch.object(control,'ROOT',root))
        stack.enter_context(patch.object(sys,'argv',['control.py','--employee-start']))
        stack.enter_context(patch.object(control,'require_send_allowed'))
        stack.enter_context(patch.object(control,'ensure_local_bridge'))
        stack.enter_context(patch.object(control,'probe',side_effect=probe))
        original_resolution=control.resolve_task_on_start
        def checked_resolution(identity,task):
            result=original_resolution(identity,task)
            assert result.get('continue_queue') is True,'unknown resolution blocked continuation'
            resolution_ready.append(True)
            return result
        stack.enter_context(patch.object(control,'resolve_task_on_start',side_effect=checked_resolution))
        original_save=control.save
        def diagnostic_save(path,data):
            if data.get('message')=='':traceback.print_exc(limit=7)
            return original_save(path,data)
        stack.enter_context(patch.object(control,'save',side_effect=diagnostic_save))
        stack.enter_context(patch.object(account_batch,'historical_exclusions',side_effect=lambda *args:copy.deepcopy(exclusions)))
        stack.enter_context(patch.object(control.subprocess,'run',side_effect=no_process))
        control.main()
        result=read(common/'status.json')
        assert boundary==[True],result
        assert result['message']=='OFFLINE_VALIDATION_COMPLETE_WORKER_NOT_STARTED',result
    report={'actual_batch_sha256':manifest['items_sha256'],'real_history_used':True,
            'quarantined_attempts':len(exclusions['quarantined_attempts']),
            'passed_through':['version_gate','explicit_account_discovery','real_batch_session_preparation',
                'adapter_upgrade','frozen_queue_check','unknown_resolution','shared_reservation_check','worker_launch_boundary'],
            'worker_started':False,'platform_requests':0,'production_business_writes':0}
    write(BASE/'real-entry-validation.json',report)
    print(json.dumps(report,ensure_ascii=False))

if __name__=='__main__':main()
