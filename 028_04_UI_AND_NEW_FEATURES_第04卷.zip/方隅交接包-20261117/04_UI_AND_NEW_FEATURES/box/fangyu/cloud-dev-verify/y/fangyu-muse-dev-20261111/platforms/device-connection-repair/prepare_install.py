from pathlib import Path
import json,hashlib,importlib.util,sys
sys.dont_write_bytecode=True
T=Path(__file__).resolve().parent;P=Path('C:/积木软件工坊/项目/方隅公寓客户版');F=P/'work/parallel-integration-20261018/final-integration'
S=F/'stage-02/project';C=F/'candidate-unified-v48';PROJECT=C/'project';N=P/'work/ui-native-r57'
read=lambda p:json.loads(p.read_text('utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n','utf-8')
before=read(F/'candidate-unified-v47/INPUT-SNAPSHOT.json')['files'];after=read(C/'INPUT-SNAPSHOT.json')['files']
changed={k for k in before.keys()|after.keys() if before.get(k)!=after.get(k)}
assert changed==set(read(T/'CHANGED.json')),changed
for k in changed:
 assert sha(T/'before'/k)==before[k],k
 assert sha(S/k)==after[k] and sha(PROJECT/k)==after[k],k
pins=read(C/'UNIFIED-PINS.json')
for row in pins['files']:
 p=PROJECT/row['path'];assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],row['path']
assert sha(N/'run_workbench.py').upper()=='21A9203A6C38FED5A4D1CB99DA9C4CB222A34C7A1D3BFE78376EA9FF7EC2AA35'
binding=sha(N/'state/production-workspace.json').upper();assert binding=='14CF53964F5D44D123E989805EA741669AB3F05054E730DDCB299A0AAC51A9CB'
staged=read(C/'STAGED.json');release=Path(staged['release']);manifest=read(release/'RELEASE.json');files={r['path']:r for r in manifest['files']}
assert sha(release/'RELEASE.json').upper()==staged['manifest_sha256'].upper()
for rel in ('work/speed-collection-worker/component/artifacts/platform-cli-guarded/guard-manifest.json','work/shared-backend-integration/vendor-src/SOURCE.json'):
 assert (PROJECT/rel).read_bytes()==(F/'candidate-unified-v47/project'/rel).read_bytes()
validation=read(F/'runtime-fixture-device-v48/STATUS.json');assert validation['status']=='PASS_FROZEN_MERGED_HTTP_FIXTURE'
assert validation['release']==staged['release_id'] and validation['real_sends']==0 and validation['real_platform_requests']==0
spec=importlib.util.spec_from_file_location('device_existing_entry_builder',N/'freeze_ui.py');builder=importlib.util.module_from_spec(spec);spec.loader.exec_module(builder)
body=builder.launcher_source(staged['release_id'],staged['manifest_sha256'],files['ui_native_host.py']['sha256'],files['lifecycle_log.py']['sha256'])
needle="RELEASE = ROOT / 'releases/"+staged['release_id']+"'";assert body.count(needle)==1
body=body.replace(needle,"PROJECT_ROOT = ROOT.parent.parent / 'work/parallel-integration-20261018/final-integration/candidate-unified-v48/project'\nRELEASE = PROJECT_ROOT / 'work/ui-native-r57/releases/"+staged['release_id']+"'\nBINDING_SHA256 = '"+binding+"'")
assert body.count('project_root=ROOT.parent.parent')==1;body=body.replace('project_root=ROOT.parent.parent','project_root=PROJECT_ROOT')
needle="        pinned(RELEASE / 'RELEASE.json', MANIFEST_SHA256)";assert body.count(needle)==1
body=body.replace(needle,"        pinned(ROOT / 'state/production-workspace.json', BINDING_SHA256)\n        pinned(PROJECT_ROOT / 'work/ui-native-r57/state/production-workspace.json', BINDING_SHA256)\n"+needle)
compile(body,'run_workbench.py','exec');launcher=N/('run_delegated_candidate.'+staged['release_id']+'.py')
with launcher.open('xb') as h:h.write(body.encode('utf-8'))
entry=F/'entry-v48';entry.mkdir(exist_ok=False)
plan={'status':'PREPARED_NOT_INSTALLED','release_id':staged['release_id'],'release':staged['release'],'manifest_sha256':staged['manifest_sha256'],
 'launcher':str(launcher),'launcher_sha256':sha(launcher).upper(),'expected_previous_launcher_sha256':sha(N/'run_workbench.py').upper(),'expected_previous_frozen_sha256':sha(N/'FROZEN.json').upper(),
 'runtime_project_root':str(PROJECT),'installation_state_root':str(N/'state'),'workspace_binding_sha256':binding,'full_closure_files_verified':len(pins['files']),
 'full_closure_manifest_sha256':sha(C/'UNIFIED-PINS.json').upper(),'validation':str(F/'runtime-fixture-device-v48/STATUS.json'),'installed':False,'component_use_policy':'unchanged',
 'production_cloud_activation':False,'production_data_migration':False,'scope':'customer-only device recovery; no task replay; four source files'}
write(entry/'CANONICAL-DELEGATION-PREPARED.json',plan);write(T/'CHANGES.json',[{'path':k,'before':before[k],'after':after[k]} for k in sorted(changed)])
print(json.dumps({'prepared':True,'release':staged['release_id'],'closure_files':len(pins['files']),'changed':len(changed)}))
