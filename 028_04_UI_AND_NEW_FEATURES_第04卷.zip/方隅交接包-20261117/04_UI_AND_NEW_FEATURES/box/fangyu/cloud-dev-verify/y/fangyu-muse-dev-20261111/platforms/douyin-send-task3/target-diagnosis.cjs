'use strict';
const diagnosticCodes = [2053, 2055, 2209, 3220];
function canSkip(receipt, diagnosis) {
  return !!receipt && !receipt.cid && diagnosticCodes.includes(receipt.status_code)
    && diagnosis?.detail_status === 0 && diagnosis.comments_status === 0
    && diagnosis.has_more === 0 && diagnosis.target_present === false
    && (diagnosis.video_present === true || (diagnosis.video_present === false && diagnosis.count === 0));
}
module.exports = { diagnosticCodes, canSkip };
