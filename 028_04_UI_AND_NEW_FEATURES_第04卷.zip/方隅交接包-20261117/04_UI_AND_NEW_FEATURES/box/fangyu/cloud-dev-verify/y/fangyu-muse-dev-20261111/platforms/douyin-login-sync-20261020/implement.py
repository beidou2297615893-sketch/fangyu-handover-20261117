from pathlib import Path
S=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project/work/ui-approved-implementation/ui-preview')
def edit(p,old,new):
 s=p.read_text('utf-8');assert s.count(old)==1,(p.name,old[:70],s.count(old));p.write_text(s.replace(old,new),encoding='utf-8')
p=S/'app.mjs'
edit(p,"const jobId=job?.id||job?.jobId,key=jobId||'platform:'+platformId;", "const jobId=job?.id||job?.jobId,key=jobId||'platform:'+platformId,targetAccountId=job?.accountId;\n  const autoDouyin=platformId==='douyin'&&!jobId&&Boolean(targetAccountId)&&job?.windowOpen===true,autoStarted=Date.now();let autoChecks=0;")
edit(p,"actor===actorKey();\n  function display(value)", "actor===actorKey()&&(!targetAccountId||!state.platformAccountSelections?.[platformId]||state.platformAccountSelections[platformId]===targetAccountId);\n  function schedule(initial=false){\n    if(!owns()||connectionComplete)return;\n    if(jobId){timer=setTimeout(check,initial?1200:2500);return;}\n    if(!autoDouyin||latestJob?.windowOpen!==true)return;\n    if(autoChecks>=12||Date.now()-autoStarted>=120000){const browser=document.getElementById('account-job-browser');if(browser)browser.textContent='自动确认暂未完成，登录窗口和资料已保留；可点检查连接继续，无需重复扫码。';return;}\n    timer=setTimeout(()=>check(true),initial?2500:autoChecks<3?5000:10000);\n  }\n  function display(value)")
edit(p,"async function check(){\n    if(!owns()||checking)return;checking=true;clearTimeout(timer);", "async function check(automatic=false){\n    if(!owns()||checking)return;checking=true;clearTimeout(timer);if(automatic&&autoDouyin)autoChecks++;")
edit(p,"const result=jobId?await backend.accountJob(jobId):await checkAccount(platformId);", "const result=jobId?await backend.accountJob(jobId):autoDouyin?await runPlatformOperation('account_check',{accountId:targetAccountId}):await checkAccount(platformId);")
edit(p,"if(!display(result.job)&&jobId)timer=setTimeout(check,2500);", "if(!display(result.job))schedule();")
edit(p,"if(!display(job)&&jobId)timer=setTimeout(check,1200);", "if(!display(job))schedule(true);")
edit(p,"value?.windowOpen===true?'平台浏览器仍保持打开，可在其中手动登录或完成网页验证码；再次切回请点原来的登录按钮。'", "value?.windowOpen===true?(autoDouyin?'原抖音窗口保持打开，完成本人登录后会自动确认账号和昵称；已登录时无需重复扫码。':'平台浏览器仍保持打开，可在其中手动登录或完成网页验证码；再次切回请点原来的登录按钮。')")
# Manual status can start the same bounded watcher; it never opens/recreates a browser.
old="  const result=await runPlatformOperation('account_check',{accountId:id});\n  if(result)toast(result.job?.message||'账号检查完成，请查看当前状态。');"
new="  const actor=actorKey(),result=await runPlatformOperation('account_check',{accountId:id});\n  if(result&&actor===actorKey()){toast(result.job?.message||'账号检查完成，请查看当前状态。');if(platformId==='douyin'&&state.page==='accounts'&&result.job?.windowOpen===true&&!accountConnectionState(platformId,result.job,state.platform?.accounts?.find(a=>a.id===id)).complete)showAccountJob(result.job,platformId,actor);}"
edit(p,old,new)
p=S/'account-connection-state.mjs';edit(p,"phase=complete?'已连接':needsSnapshot?", "phase=complete?'已连接':value.status==='checking'?'正在确认账号身份':needsSnapshot?")
p=S/'pages/accounts.mjs'
edit(p,"  if(model(s).failures?.[row.id])return '待重新检查';\n  if(['ready','connected','online'].includes(row.status))return row.account?'已连接':'待核验';", "  if(['ready','connected','online'].includes(row.status))return row.account?'已连接':'待核验';\n  if(model(s).failures?.[row.id])return '待重新检查';")
edit(p,"${escape(account.remarks||account.name||'未命名账号')}", "${escape(id==='douyin'&&actual?actual:account.remarks||account.name||'未命名账号')}")
edit(p,"${busy?'disabled':''}>登录此账号</button>", "${busy?'disabled':''}>${id==='douyin'?['logging_in','waiting_login','checking','unverified'].includes(account.status)?'继续连接':'连接此账号':'登录此账号'}</button>")
edit(p,"if(!own())return;ui.feedback[id]=result?.job?.message||state.platformError||'';", "if(!own())return;ui.feedback[id]=result?.job?.message||state.platformError||'';ui.failures??={};ui.failures[id]=['failed','cancelled','stopped'].includes(result?.job?.status);")
print('Updated bounded jobless Douyin identity confirmation; no backend or identity guard changed.')
