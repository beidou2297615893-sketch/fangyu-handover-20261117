'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { EventEmitter } = require('node:events');
const { Readable } = require('node:stream');
const { spawnSync } = require('node:child_process');
const net = require('node:net');
const originalListen = net.Server.prototype.listen;
net.Server.prototype.listen = function () { throw Error('TEST_FORBIDS_LISTEN'); };
const { createStrictBridge, readConfig, DEFAULT_UPSTREAM } = require('./strict-bridge-server.cjs');
const CONFIG = { bridge: { token: 'synthetic-offline-test-token-only', port: 19422, host: '0.0.0.0', requestTimeout: 40 } };
const hash = p => crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const originalConfigPath = path.resolve(DEFAULT_UPSTREAM, '../../data/bridge.json');
const protectedFiles = ['server.js', 'lib/server/router.js', 'lib/server/registry.js', 'lib/server/ws-hub.js'].map(p => path.join(DEFAULT_UPSTREAM, p)).concat(originalConfigPath);
const before = protectedFiles.map(hash);
const passed = [];
function response() {
  const res = new EventEmitter();
  res.headersSent = false; res.setHeader = () => {};
  res.writeHead = code => { res.code = code; res.headersSent = true; };
  res.end = text => { res.text = text || ''; res.body = text ? JSON.parse(text) : null; res.emit('finished'); };
  return res;
}
function request(router, method, url, body, authorized = true) {
  const req = Readable.from(body === undefined ? [] : [Buffer.from(JSON.stringify(body))]);
  req.method = method; req.url = url;
  req.headers = { host: '127.0.0.1', ...(authorized ? { authorization: 'Bearer ' + CONFIG.bridge.token } : {}) };
  const res = response(); const done = router.handle(req, res);
  return { res, done };
}
async function test(name, fn) { await fn(); passed.push(name); }
async function fixture(fn) {
  const bridge = createStrictBridge({ config: CONFIG, port: 19423 });
  bridge.registry.get = () => { throw Error('FALLBACK_FORBIDDEN'); };
  try { await fn(bridge); }
  finally { await bridge.stop(); }
}
(async () => {
  await test('import and factory do not listen; strict mode forced and loopback isolated', async () => {
    const bridge = createStrictBridge({ config: CONFIG, port: 19423, strictConnections: false });
    assert.equal(bridge.router.strictConnections, true);
    assert.equal(bridge.router.allowedSite, 'douyin.com');
    assert.equal(bridge.httpServer.listening, false);
    assert.equal(bridge.hub._wss, null);
    assert.equal(bridge.summary().host, '127.0.0.1');
    assert.equal(CONFIG.bridge.host, '0.0.0.0');
    assert.equal(CONFIG.bridge.port, 19422);
    await bridge.stop();
  });
  await test('reject inherited port, active original port, external host and missing credential', async () => {
    assert.throws(() => createStrictBridge({ config: CONFIG }), /explicit_independent_port_required/);
    assert.throws(() => createStrictBridge({ config: CONFIG, port: 19422 }), /original_port_protected/);
    assert.throws(() => createStrictBridge({ config: CONFIG, port: 19423, host: '0.0.0.0' }), /loopback_host_required/);
    assert.throws(() => createStrictBridge({ config: { bridge: {} }, port: 19423 }), /configured_token_required/);
  });
  await test('explicit owned 19422 override permits construction only and preserves strict routing', async () => {
    const bridge = createStrictBridge({ config: CONFIG, port: 19422, allowOwned19422: true });
    assert.equal(bridge.summary().port, 19422); assert.equal(bridge.summary().owned19422Override, true);
    assert.equal(bridge.router.strictConnections, true); assert.equal(bridge.router.allowedSite, 'douyin.com');
    assert.equal(bridge.httpServer.listening, false); assert.equal(bridge.hub._wss, null);
    await bridge.stop();
  });
  await test('config fields and truthy strings cannot bypass default 19422 protection', async () => {
    const config = { ...CONFIG, allowOwned19422: true, bridge: { ...CONFIG.bridge, allowOwned19422: true } };
    assert.throws(() => createStrictBridge({ config, port: 19422 }), /original_port_protected/);
    for (const allowOwned19422 of ['true', 1, false, null]) {
      assert.throws(() => createStrictBridge({ config: CONFIG, port: 19422, allowOwned19422 }), /original_port_protected/);
    }
  });
  await test('CLI check requires the exact owned-port flag and still never starts a service', async () => {
    const args = [path.join(__dirname, 'strict-bridge-server.cjs'), '--check-config', '--config', originalConfigPath, '--port', '19422'];
    const run = extra => spawnSync(process.execPath, args.concat(extra), { encoding: 'utf8', timeout: 5000 });
    const protectedRun = run([]); assert.equal(protectedRun.status, 1); assert.equal(protectedRun.stderr.trim(), 'original_port_protected');
    const allowedRun = run(['--allow-owned-19422']); assert.equal(allowedRun.status, 0);
    const summary = JSON.parse(allowedRun.stdout); assert.equal(summary.owned19422Override, true);
    assert.equal(summary.port, 19422); assert.equal(summary.listening, false); assert.equal(summary.strictConnections, true);
    assert.equal(summary.activeBridge19422Compatibility, 'UNVERIFIED');
    for (const extra of [['--allow-owned-19422=true'], ['--allow-owned-19422', '--allow-owned-19422']]) assert.equal(run(extra).status, 1);
    const config = readConfig(originalConfigPath);
    assert.equal((allowedRun.stdout + allowedRun.stderr).includes(config.bridge.token), false);
  });
  for (const mode of ['missing', 'closed']) await test(mode + ' exact connection rejects without fallback or task', () => fixture(async b => {
    let sends = 0;
    const other = b.registry.register('douyin.com', { readyState: 1, send() { sends++; } });
    let id = 'synthetic-removed-connection';
    if (mode === 'closed') id = b.registry.register('douyin.com', { readyState: 3, send() { sends++; } }).id;
    const op = request(b.router, 'POST', '/api/call', { site: 'douyin.com', connId: id, expression: '1' });
    await op.done;
    assert.equal(op.res.code, 503); assert.equal(op.res.body.ok, false);
    assert.equal(sends, 0); assert.equal(b.router._pending.size, 0); assert.equal(b.router._pollQueue.size, 0);
    assert.ok(b.registry.getById('douyin.com', other.id));
  }));
  await test('call without connection ID and wrong site reject', () => fixture(async b => {
    for (const body of [{ site: 'douyin.com', expression: '1' }, { site: 'example.invalid', connId: 'x', expression: '1' }]) {
      const op = request(b.router, 'POST', '/api/call', body); await op.done; assert.equal(op.res.code, 400);
    }
    assert.equal(b.router._pollQueue.size, 0);
  }));
  await test('legacy poll with no ID cannot claim a site or exact task', () => fixture(async b => {
    b.router._pollQueue.set('douyin.com', [{ msgId: 'synthetic-site-task', expression: '1', awaitPromise: true }]);
    const op = request(b.router, 'GET', '/api/poll?site=douyin.com'); await op.done;
    assert.equal(op.res.code, 400); assert.equal(b.router._pollQueue.get('douyin.com').length, 1);
    assert.equal(b.router._legacyPollingSeenAt.size, 0);
  }));
  await test('removed exact polling ID returns 410 and cannot consume task', () => fixture(async b => {
    const conn = b.registry.register('douyin.com', null); b.registry.unregister(conn.id);
    b.router._pollQueue.set(conn.id, [{ msgId: 'synthetic-pending-task', expression: '1', awaitPromise: true }]);
    const op = request(b.router, 'GET', '/api/poll?site=douyin.com&id=' + conn.id); await op.done;
    assert.equal(op.res.code, 410); assert.equal(b.router._pollQueue.get(conn.id).length, 1);
  }));
  await test('valid precise WebSocket connection routes only there and completes', () => fixture(async b => {
    let chosenSends = 0, otherSends = 0;
    b.registry.register('douyin.com', { readyState: 1, send() { otherSends++; } });
    const chosen = b.registry.register('douyin.com', { readyState: 1, send(raw) {
      chosenSends++; const msg = JSON.parse(raw);
      queueMicrotask(() => b.hub.emit('result', { id: msg.id, value: 'synthetic-ws-result' }));
    } });
    const op = request(b.router, 'POST', '/api/call', { site: 'douyin.com', connId: chosen.id, expression: '1' }); await op.done;
    assert.equal(op.res.code, 200); assert.equal(op.res.body.connection, chosen.id);
    assert.equal(op.res.body.value, 'synthetic-ws-result'); assert.equal(chosenSends, 1); assert.equal(otherSends, 0);
    assert.equal(b.router._pending.size, 0);
  }));
  await test('precise polling queue excludes legacy and another live connection', () => fixture(async b => {
    const chosen = b.registry.register('douyin.com', null);
    const other = b.registry.register('douyin.com', null);
    b.router._legacyPollingSeenAt.set('douyin.com', Date.now());
    const op = request(b.router, 'POST', '/api/call', { site: 'douyin.com', connId: chosen.id, expression: '2', timeout: 1000 });
    await new Promise(resolve => setImmediate(resolve));
    assert.equal(b.router._pollQueue.has(chosen.id), true); assert.equal(b.router._pollQueue.has('douyin.com'), false);
    const wrong = request(b.router, 'GET', '/api/poll?site=douyin.com&id=' + other.id); await wrong.done;
    assert.equal(wrong.res.headersSent, false); wrong.res.emit('close');
    const legacy = request(b.router, 'GET', '/api/poll?site=douyin.com'); await legacy.done; assert.equal(legacy.res.code, 400);
    const poll = request(b.router, 'GET', '/api/poll?site=douyin.com&id=' + chosen.id); await poll.done;
    assert.equal(poll.res.body.type, 'eval'); assert.equal(poll.res.body.expression, '2');
    const result = request(b.router, 'POST', '/api/result', { id: poll.res.body.id, value: 'synthetic-poll-result' }); await result.done; await op.done;
    assert.equal(op.res.code, 200); assert.equal(op.res.body.connection, chosen.id);
    assert.equal(op.res.body.value, 'synthetic-poll-result'); assert.equal(b.router._pending.size, 0);
  }));
  await test('unauthenticated call rejected before queueing', () => fixture(async b => {
    const op = request(b.router, 'POST', '/api/call', { site: 'douyin.com', connId: 'x', expression: '1' }, false);
    await op.done; assert.equal(op.res.code, 401); assert.equal(b.router._pollQueue.size, 0);
  }));
  await test('precise WebSocket timeout does not send to another connection or queue', () => fixture(async b => {
    let otherSends = 0;
    b.registry.register('douyin.com', { readyState: 1, send() { otherSends++; } });
    const chosen = b.registry.register('douyin.com', { readyState: 1, send() {} });
    const op = request(b.router, 'POST', '/api/call', { site: 'douyin.com', connId: chosen.id, expression: '1', timeout: 20 });
    await op.done; assert.equal(op.res.code, 503); assert.equal(otherSends, 0);
    assert.equal(b.router._pending.size, 0); assert.equal(b.router._pollQueue.size, 0);
  }));
  await test('stopping isolated bridge resolves outstanding request without touching other instance', () => fixture(async b => {
    const conn = b.registry.register('douyin.com', null);
    const op = request(b.router, 'POST', '/api/call', { site: 'douyin.com', connId: conn.id, expression: '1', timeout: 1000 });
    await new Promise(resolve => setImmediate(resolve));
    assert.equal(b.router._pending.size, 1);
    await b.stop(); await op.done;
    assert.equal(op.res.code, 503); assert.equal(b.router._pending.size, 0); assert.equal(b.router._pollQueue.size, 0);
  }));
  await test('existing configuration read-only, valid, and never printed; protected sources unchanged', async () => {
    const config = readConfig(originalConfigPath);
    assert.ok(config.bridge && typeof config.bridge.token === 'string' && config.bridge.token.length > 0);
    assert.deepEqual(protectedFiles.map(hash), before);
    const bridge = createStrictBridge({ config, port: 19423 });
    const publicText = JSON.stringify(bridge.summary());
    assert.equal(publicText.includes(config.bridge.token), false); await bridge.stop();
  });
  const report = { result: 'PASS', tests: passed.length, cases: passed, network_listeners_created: 0,
    real_browser_requests: 0, original_files_unchanged: true, active_bridge_19422_compatibility: 'UNVERIFIED',
    scope: 'Offline simulation of the reused Router, ConnectionRegistry and WebSocketHub; no browser or platform validation.' };
  if (!process.argv.includes('--no-write-report')) fs.writeFileSync(path.join(__dirname, 'strict-bridge-test-result.json'), JSON.stringify(report, null, 2) + '\n');
  console.log(JSON.stringify(report, null, 2));
})().catch(() => { console.error('FAIL: offline strict bridge verification; no configuration values printed'); process.exitCode = 1; })
  .finally(() => { net.Server.prototype.listen = originalListen; });
