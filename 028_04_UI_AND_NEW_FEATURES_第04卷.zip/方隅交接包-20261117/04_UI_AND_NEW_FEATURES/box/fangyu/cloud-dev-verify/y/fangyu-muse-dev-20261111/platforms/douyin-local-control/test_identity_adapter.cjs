'use strict';
// Execute only a VM copy with fake fs, fake client and fake publish; never a live adapter.
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const guard=require('./page_guard.cjs');
async function run(source,scenario){
 const account=source.match(/const accountUid='([^']+)'/)[1],prints=[];let posts=0;
 const task={account_uid:account,comment_id:'123',video_id:'456',reply:{draft_text:'fixture'}};
 const fakeFs={existsSync:()=>true,writeFileSync(){},readFileSync:p=>{
  p=String(p);
  if(p.endsWith('bridge.json'))return '{"bridge":{}}';
  if(p.endsWith('cli-current-binding.json'))return JSON.stringify({connection_id:'fixed',account_uid:account});
  if(p.endsWith('continuation-state.json'))return '{"status":"authorized","unknown":0}';
  return JSON.stringify(task);
 }};
 class BridgeClient{
  async call(options){
   if(options.expression.includes('/user/profile/self/')){
    if(scenario==='sleep')return {ok:false,error:'Request timeout after 15000ms — no polling client connected'};
    if(scenario==='profile_http429')return {ok:false,error:'Local Bridge HTTP request failed: HTTP 429'};
    if(scenario==='profile_platform429')return {ok:true,connection:'fixed',value:{code:429,uid:account}};
    return {ok:true,connection:'fixed',value:{code:0,uid:scenario==='wrong_uid'?'other':account}};
   }
   if(options.expression==='fixture_publish'&&scenario==='post_wrong_route')return {ok:false,connection:'other',error:'no polling client connected'};
   if(options.expression==='fixture_publish')return {ok:true,connection:'fixed',value:{status_code:0,
     comment:{cid:'999',text:'fixture',user:{sec_uid:account},reply_id:'123',status:2}}};
   if(scenario==='page_throw429')throw Error('HTTP request failed: HTTP 429');
   if(scenario==='page_http429')return {ok:false,error:'HTTP request failed: HTTP 429'};
   return {ok:true,connection:scenario==='wrong_route'?'other':'fixed',
     value:scenario==='captcha'?'captcha':scenario==='rate'?'rate_limit':'ready'};
  }
 }
 const proc={argv:['node','adapter','fixture-attempt.json'],env:{},exitCode:0};
 await vm.runInNewContext(source,{__dirname:path.dirname(process.argv[2]),process:proc,console:{log:v=>prints.push(JSON.parse(v))},
  require:name=>{
   if(name==='fs')return fakeFs;if(name==='path')return path;
   if(name.endsWith('/lib/client/bridge-client')||name.endsWith('\\lib\\client\\bridge-client'))return {BridgeClient};
   if(name.endsWith('/lib/commands/post')||name.endsWith('\\lib\\commands\\post'))return async ctx=>{posts++;return ctx.loggedCall('fixture',{},'fixture_publish')};
   if(name.includes('page_guard'))return guard;
   if(name.includes('target-diagnosis'))return {diagnosticCodes:[],canSkip:()=>false};
   throw Error('unexpected fixture dependency');
  }});
 return {posts,result:prints.at(-1)};
}
(async()=>{
 const source=fs.readFileSync(process.argv[2],'utf8');
 for(const [scenario,reason] of [['sleep','page_unresponsive'],['wrong_uid','identity'],['wrong_route','identity'],['captcha','captcha'],['rate','rate_limit'],['page_http429','rate_limit'],['page_throw429','rate_limit'],['profile_http429','rate_limit'],['profile_platform429','rate_limit']]){
  const r=await run(source,scenario);assert.equal(r.posts,0);assert.equal(r.result.error,'CURRENT_GATE:'+reason);
 }
 const good=await run(source,'ready');assert.equal(good.posts,1);assert.equal(good.result.status,'sent');
 const wrong=await run(source,'post_wrong_route');assert.equal(wrong.posts,1);assert.equal(wrong.result.status,'unknown');assert.equal(wrong.result.error,'CURRENT_GATE:identity');
 console.log('Migrated adapter: 11 VM scenarios passed; no live publish calls.');
})().catch(error=>{console.error(error);process.exitCode=1});
