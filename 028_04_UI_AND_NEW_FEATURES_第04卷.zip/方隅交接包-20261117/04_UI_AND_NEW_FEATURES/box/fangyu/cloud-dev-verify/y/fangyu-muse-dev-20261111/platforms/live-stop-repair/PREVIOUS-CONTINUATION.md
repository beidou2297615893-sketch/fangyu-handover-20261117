# 当前优先：v17 已装（2026-10-19）

先读 work/pause-avatar-repair/DELIVERY.json，再按需要看本摘要下方旧v16背景；已验不重跑，不读巨大聊天。
- 用户本轮要求：彻底修自行中断和继续无效；小红书/抖音CLI是底座；头像提前下载，账号问号同行。保持禁止UI/代重启/扫码/外发/清风险/扩大权限，root唯一作者。
- 确切最新故障：v16任务376ed0bfb9b340799d72524d85a48a3d第一中文搜索在发HTTP前EOF，wire_allow_attempts严格0；旧unknown又永远挡住显式resume。本轮不是新461或掉线。
- 实际PageWorker+已装冻结CLI对照确认：父帧ensure_ascii=False在Windows冻结stdin默认编码下损坏中文；改ensure_ascii=True即可正常收到result/ack。CLI未重编，修的是父传输。
- 新显式resume仅可恢复同scope/task/page/args、固定协议、旧version1、EOF且严格int0授权、无result/digest的本地未发送页；先不可覆盖归档原bytes，再开始新尝试。普通start无此权限；wire>0/timeout/其他unknown/拒绝不放行，安装时未改任何旧unknown或业务DB。
- 头像已用客户/回复回执和获客近期数据进行离DOM预热，缓存30分钟、作者优先、18秒媒体deadline、2/6秒有限本地图片重查；换身份/范围清除，沿用原后端鉴权及磁盘缓存。当前已存117条XHS记录、72身份组全有头像来源，不是本轮新增。
- 账号问号与标题同一flex行、padding0、最终CSS优先级修正；暂停时真实后台message可见。
- 已安装v17：ui-r57-20261019T075625Z-e6716b13，完整project在work/parallel-integration-20261018/final-integration/candidate-unified-v17/project，2720文件不可删；pins 9b0747c38beb1fa4ba4c4126b2c1bdce9cbe68e1a879a2c3bc6970b0ef925171。
- 原launcher SHA b4260f7ae65bf03f0ea5c08100444ec895f70397b6b0e97e5985b6d8fec6a262，原入口--check PASS131、native_windows_opened0；手动重开待用户，不冒称正在用的窗口已加载v17。
- 9份源变化：3份父/runtime接线+6份UI；独立新父/恢复29项、头像UI16项、release9项通过。旧CLI/所有其他源码与v16相同，原company/绑定/设备/用途常量不变。
- DY实际node/cli纯离线help/中文/转义/分页模块检查通过，19材料pins一致；当前DY账号logging_in且conn_id为空，不能借旧state ID自动绑定；真实DY采集/登录跳过。
- 本轮真实采集0、模型0、CDN0、发送0、UI0、业务DB写0；root仅就地读现会话作禁止wire的SDK准备探针，不复制凭据。真实连续吞吐/461恢复和原生视觉仍未实测，不能称整软件全验通。
- 后续从用户手动重开后的确切release/任务短回执继续。保持活动完整闭包与旧90a/CLI/各闭包不清理，不恢复过期17小时自动化。原总控合并拒绝边界仍在，只存本任务证据。

---
以下为v16及更早背景，不作为当前安装版本：
# 方隅当前续行摘要

更新：2026-10-19 15:06 Asia/Shanghai。先读本摘要和 work/speed-collection-worker/DELIVERY.json。不要读29.7MB聊天/图片编码。旧17小时任务已过期，不重启、不重置额度。

## 最新优先级与边界

- 核心是连续真实采集速度和同步DeepSeek；用户不接受只解释不修、模拟条数冒充真实成果。本轮只收尾采集链，不扩大UI范围。
- 用户正在用电脑，禁止UI操作、代开/关闭/重启客户端、代登录扫码；由用户手动重开。缺会话跳过，不问密码、不找凭据。
- 原账号/设备/state/原company/旧CLI/90a保留；禁真实外发、付费AI、扩大权限、清平台风险暂停、自动重放被拒/未知请求。
- 已授权多代理，root单一产品作者，代理只读审查；不改其他客户/聊天。旧总控合并曾自动审批拒绝无理由，不绕过，只存独立证据和本摘要。

## 当前安装：v16，用户手动重开后才生效

- 原入口 work/ui-native-r57/run_workbench.py 已经原CAS两文件事务接v16，SHA 5bc96d8e281795e808e835a45479621473402a79e4a5aa1b1b452e02e6232e82。
- release ui-r57-20261019T070046Z-3f29e904。活动完整闭包 work/parallel-integration-20261018/final-integration/candidate-unified-v16/project：2720文件，pins fc513ca67ce1116ae257a8bc2f1aefbbf1ed070eee208bb3e45f54dd3fcdad5c，不可清理。
- 原入口无窗口 --check PASS131；独立完整闭包及250后台依赖核对通过。未操作真实客户端；先前活动仍v15，不能冒称已加载v16。
- 原绑定SHA 14cf53964f5d44d123e989805ea741669ab3f05054e730ddcb299a0aac51a9cb、原company SHA bd71d4b7e6b05581702782bda87f0e228c84804decd36a0c4eaf54e0abc6077e 不变。所有旧闭包/CLI保留。
- 可编辑源 work/parallel-integration-20261018/final-integration/stage-02/project。新改需新版本固化、完整pins、原入口事务，不能直接改冻结包。

## v16 本轮改动与证据

- 旧桌面每搜索/主评/楼中楼一页重启CLI，SDK响应cookie只留内存，与连续CLI生命周期不同。现同一明确任务复用一个原CLI进程及同一XhsClient/连接/内存cookie。
- 新 core/xhs_page_process.py、assistant/xhs_cli_page_worker.py，dispatcher仅固定read页入口；不接任意命令，不改登录/回复/其他owner用途。
- 每HTTP继续核当前任务/账号/UID/设备/lease/license/策略，保留原节奏日志及首次拒绝停止。页结果持久保存后ACK；未知/拒绝不重放。只有证明未授权任何wire且进程退出的not_sent可明确恢复。
- 保留主评/楼中楼分页和原断点，不用会隐藏剩余cursor/漏子评的comments --all直接替换。v15 UI字节、并行DeepSeek和inbox路径均保留。
- 新CLI根（相对v16 project）work/speed-collection-worker/component/artifacts/platform-cli-guarded，exe d46186f0c10791e5ea2d989019b26f6a3fb24cfd523ebea729461da7af4efe59，tree b6ec1f2e0e6ba6dd5bcb0b5e66f6ef8f40e82ef835f1981f632ca2ebbf1fd3f7。
- wrapper fa8e8f21f6830a139839a457e3acd9940bbf0beb290cf52670d445ac20069843；仅方隅3项WORKBENCH artifact pins、候选company sourcepin/来源记录更新。其他owner/private常量未改，用途仍pending。
- 分轮新增：协议16项，not_sent20项，同帖预热7项，接线11项及末边界4项；保留精确hash和RED证据，不重跑旧全GUI/导出/未改CLI套件。
- 独立精确构建审查后离线编译，真实PYZ解归档确认child/dispatcher；空HOME新exe握手关闭exit0、非法reply帧exit2，隐藏进程已退出，真实平台0。
- 旧安装schema的compiled_cli_executed固定false不代表没烟测；DELIVERY明确isolated_cli_smoke_executed=true、real_platform_requests=0。
- 本轮真实新增采集0、模型调用0、发送0、登录0、UI操作0、业务DB写0。真实吞吐提升和461恢复尚未实测，不能宣称连续几百/几千条通过。
- 证据 work/speed-collection-worker：DELIVERY、CANDIDATE-VALIDATION、FROZEN-SMOKE、SOURCE-CHANGES、review-worker/review-integration/review-release；入口事务 final-integration/entry-v16。

## 真实采集事实，禁止混用模拟和历史

- 12:15任务221802c745aa483eb8f1aebec28e52a5：331秒读181/筛152/入29，19位明确作者；29条有revision5真实DeepSeek回执（15无关、9待定、5分级），停止HTTP461。不是29有效客户，也不是v15/v16成果。
- v15 13:49搜索成功、首主评461、入0；13:47读7筛7后楼中楼461、入0。泛461是platform_rejected、auth_signal=null、requires_auth=false，不能推成必须扫码/掉线/人工复核；13:10另一个-100/session_missing须分开。
- 历史1000条是模拟，不得当真实成果。旧152条筛除原文未留存，只有计数，不可伪补分级。新增客户按作者去重，评论条数不等于客户人数；未分析筛除不可编为低意向。
- 搜索默认general，7天为下载后本地过滤，先补楼中楼可能延迟换帖。本轮未放宽门店词、日期规则或增加平台并发；不是简单30条上限。
- 上游仍0.6.4/main 4d63f3c，无新合并461修复；PR81已有，PR87自动重试未采用。短来源 speed-collection-worker/upstream-audit。

## 保留成果和未完成项

- v15：本地页最多50受目标/当日剩余限制；同帖20条AI批次、单任务单分析线程/持久队列并行采集；暂停等在途，未知模型结果不重放。read/filter/重复按真回执累计。
- 已有总采集工作量、去重新增/已分析/高意向、日历和平台缓存；回复默认帖子/大小/折叠原因/单原帖入口；客户页查询导出、单条去回复。具体改动和旧分轮证据见speed-first-recovery/DELIVERY.json，不重做。
- 管理SOP两类正文，管理员保存员工选用；公司未给正文就明确未配置。回复本页全选/五级状态筛选/逐条预览/原最终发送确认，20条上限/一人一评论保留；未实测几百条真群发。
- DeepSeek已接，管理→AI模型可看和保存，当前deepseek-flash；50元是用户已充值，不改预算。全店五级revision5已有前述29条真回执。
- 13店1762条公共可执行词，选授权门店带词，不代表词都执行。门店安装归属仅图片，不把软件变演示。远程更新按用户决定暂缓。
- 新反馈优先核真实release及命名任务短日志。用户手动重开前不代重启；不重放旧失败请求。真实长采集未通过前，持续诚实保留未达标状态，不以本地验收当真实吞吐通过。
