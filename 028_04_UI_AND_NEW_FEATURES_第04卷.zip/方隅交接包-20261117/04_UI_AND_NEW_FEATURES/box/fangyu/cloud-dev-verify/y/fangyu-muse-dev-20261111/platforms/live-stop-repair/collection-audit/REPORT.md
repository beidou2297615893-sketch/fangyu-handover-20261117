# v17 真实停止原因，只读审计

这次已实际加载 v17 `ui-r57-20261019T075625Z-e6716b13`，PID74668。不是旧v16中文EOF；本次每一页都正常授权并收到、确认原CLI结果。

## 最新任务的实际停止

最新任务 `50df39c35e6c41e3b1da447cfcf32c5d`，16:12:42开始，目标1000、日限1000，选中日期10月13日至19日。

真实顺序：搜索HTTP200；第一主评页HTTP200，映射1条；第二主评页HTTP200，映射16条；随后楼中楼HTTP461，CLI原错误明确为 `Captcha required: type=124`。当前暂停是平台验证码挑战，不能改称掉线或必须扫码。停止前累计读取17、筛除17、入库0，已完成2页；最后一次失败单批的summary为0，不是整个任务读0。

17条的评论日期均在10月13日至19日外：第一条9月11日，其余16条7月23日至10月8日。但员工所选是“帖子时间”，评论范围明确“全部时间”；因此这些筛除并非正常业务筛除，下面已确认是帖子/评论日期错用的本地缺陷。实际帖子日期缺失，不能据评论时间认定帖子不在范围内。它们没有被当新客户或已AI分析。最新三次任务都没有 cancel_task 审计，暂停原因collection_error；不是员工主动暂停、1条数量上限或额度已满。

前两次：`923ce94ad6e34ffc9af56d43ce0dd60d` 读1/筛1后第二主评页挑战124；`3c44f918027f41f39c017af850356c69` 首主评页即挑战124。它们是本轮新原响应，未借用历史461。

## 请求时间与来源

最新任务各HTTP开始时间为16:12:46.069（搜索）、49.226（主评）、52.841（主评）、56.428（楼中楼）；开始间隔3.157、3.615、3.586秒，上次完成至下次开始2.235、2.963、2.808秒。没有平台并发连发证据，不能由此认定挑战的触发原因。461收到至CLI报错约5秒，对应原SDK验证码cooldown。

根据原已保存搜索输出、同任务pipeline和cursor重建参数，再逐一对照page_key及args_digest，最新4页各唯一匹配。两主评和失败楼中楼的token均在，来自同次原搜索的同一帖子；原source也存在且一致。楼中楼root属于同帖，cursor与主评内嵌子评断点一致。未输出token、source的值或原文。

固定PR81 wrapper主评GET `/api/sns/web/v2/comment/page`；楼中楼GET `/api/sns/web/v2/comment/sub/page`，参数为note_id/root_comment_id/num30/cursor/image_formats/top_comment_id/xsec_token。原PR81只接xsec-token，不接xsec-source标志；source在来源URL与上下文缓存中，不能当作丢参。GET签名与实际URL构造使用同一params对象。

活动日志不记录URL；上述路径对应确切固定SDK函数与页类型白名单，并非本轮另发HTTP探测所得。未发现能解释三次挑战的统一局部拼参错误。冻结exe仍为d46186...，PR81与source pins匹配，详细哈希见REQUEST-CONTRACT.json。

## 可修部分与仍未知

当前task.last_platform_error、last_result及run安全字段仍是generic platform_rejected/auth_signal=null。明确验证码原信息只在同账号同任务的failed acknowledged CLI回执。可严格核scope、时段、result形状/digest及verification_required，再匹配固定SDK有界验证码错误格式，只投影captcha_challenge枚举给员工；不输出uuid、不改原任务、不借历史461推断。

最终员工计数应优先使用累计run回执17/17/0，不拿最后失败单批0覆盖。本次没有重发、清风险、登录、UI操作、生产写入或新模型请求。

平台为什么给挑战124仍未知，不能声称真实持续采集已修通。原账号真实会话、平台验证及后续请求是否会获准，本轮均未尝试。

## 新确认的日期缺陷及候选补丁审查

真实客户页 acquire.mjs 显示“帖子时间”和“评论范围：全部时间”；当前任务 comment_date_range=all。原 pipeline 将帖子日期保留在 content_published_at，Adapters 将评论日期放入 published_at，但原 Core 用 selected date_from/to 筛 published_at，误将帖子条件应用到评论。这是本轮可证明的本地功能错误；不能把17条筛除描述为正常筛除。

两个原搜索卡片均没有可识别的发布时间字段，映射帖子日期也为空。对同17条只读重放确切源码过滤段：旧版17条全被日期排除；新段17条保留并标“帖子日期待核实”。这17条没有导入生产、没有调用模型，也不能称已核实的近7天帖子。来源字段名和日期矩阵在 CACHED-17-BASELINE.json。

候选新段还证实：已知范围外帖子在 before_read 前跳过，HTTP适配器零调用；范围内新帖允许旧评论；原 comments、continuous、非 all 评论策略和其他平台旧日期段保持原行为。首轮发现的重复日期提示已由根作者修复；另一首轮RED是测试误读 pipeline 而非 _pipeline_next，原跳过请求行为始终通过。原RED留存。

验证码修复对3份原ACK载荷输出仅固定 captcha_challenge，CLI原回执前后hash不变。精确异常类型为 AdapterPlatformFailure，而不是 AdapterAuthRequired；实际 Core 异常处理源码段在隔离内存存储中执行后账号仍ready、无accounts写入，只暂停任务。通用461及不完整type/uuid不推断验证码。外层runtime catch无自动登录或cookie删除，此项为静态审查范围。

DATE-CAPTCHA-RESULT.json汇总20项通过，最后追验执行5项，其余15项引用首轮已通过证据，未重复全套；FINAL-REVIEW.json另核11源实际hash、CustomerHistory投影和原精确pin。新产品未由本审查安装/启动，真实持续采集未复测，挑战124触发原因仍未知。
