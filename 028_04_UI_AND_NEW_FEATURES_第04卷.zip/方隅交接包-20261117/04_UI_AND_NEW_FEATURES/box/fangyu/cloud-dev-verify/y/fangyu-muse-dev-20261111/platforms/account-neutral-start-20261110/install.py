"""Install only shared entry code under all sender locks; never start a task."""
import ast
from contextlib import ExitStack
from datetime import datetime
import hashlib
import json
import msvcrt
import os
from pathlib import Path
import subprocess
import sys

BASE=Path(__file__).resolve().parent
ROOT=BASE.parents[1]
DEST=ROOT/'work/douyin-local-control'
sys.path.insert(0,str(ROOT/'work/background-skip-20261110'))
from install_common import running_senders
FILES=('control.py','account_probe.cjs','account_batch.py','test_account_probe.cjs',
       'test_account_batch.py','test_account_start_entry.py','test_version_gate.py')

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def atomic(path,data):
    temporary=path.with_name(path.name+'.account-neutral.tmp');temporary.write_bytes(data);os.replace(temporary,path)

def main():
    with ExitStack() as stack:
        for path in [DEST/'control.lock',*ROOT.glob('work/douyin-*/batch-runner.lock')]:
            handle=stack.enter_context(path.open('a+b'));handle.seek(0)
            msvcrt.locking(handle.fileno(),msvcrt.LK_NBLCK,1)
        if running_senders():raise RuntimeError('active sender/controller: install deferred')
        previous=BASE/'installed.json'
        if previous.exists():
            if sys.argv[1:]!=['--refresh']:raise RuntimeError('already installed: inspect first')
            installed=json.loads(previous.read_text(encoding='utf-8'))
            if any(digest(DEST/name)!=value for name,value in installed['files'].items()):
                raise RuntimeError('installed code changed: refresh deferred')
            history=BASE/'before-refresh';history.mkdir(exist_ok=True)
            for name in FILES:(history/name).write_bytes((DEST/name).read_bytes())
            (history/'installed.json').write_bytes(previous.read_bytes())
        else:
            for name in ('control.py','account_probe.cjs'):
                if (DEST/name).read_bytes()!=(BASE/'before'/name).read_bytes():
                    raise RuntimeError('shared entry changed during preparation: '+name)
        active=json.loads((DEST/'active.json').read_text(encoding='utf-8-sig'))
        task=Path(active['task']).resolve()
        if task.parent!=ROOT/'work':raise RuntimeError('unexpected task')
        protected=[p for p in task.iterdir() if p.is_file() and not p.name.endswith('.lock')]
        protected.extend(DEST/name for name in ('active.json','accounts.json'))
        protected.append(ROOT/'work/fangyu-douyin-independent/auto-collect.stop')
        protected.extend(p for p in (ROOT/'work/shared-acquisition-ledger').glob('shared.sqlite3*') if p.is_file())
        before={str(p):digest(p) for p in protected}
        (BASE/'protected-before.json').write_text(json.dumps(before,ensure_ascii=False,indent=2),encoding='utf-8')
        for name in FILES:
            source=BASE/'stage'/name
            if name.endswith('.py'):ast.parse(source.read_text(encoding='utf-8-sig'))
            else:
                check=subprocess.run(['node','--check',str(source)],capture_output=True,timeout=15,
                                     creationflags=subprocess.CREATE_NO_WINDOW)
                if check.returncode:raise RuntimeError('invalid JS: '+name)
            target=DEST/name
            backup=BASE/'before'/name
            if target.exists() and not backup.exists():backup.write_bytes(target.read_bytes())
        if running_senders():raise RuntimeError('sender appeared: install deferred')
        # Install dependency first, controller last. The control lock prevents
        # an employee click observing a partially installed bundle.
        for name in [n for n in FILES if n!='control.py']+['control.py']:
            atomic(DEST/name,(BASE/'stage'/name).read_bytes())
        stamp=datetime.now().astimezone().isoformat()
        after={str(p):digest(p) for p in protected}
        result={'installed_at':stamp,'files':{name:digest(DEST/name) for name in FILES},
                'protected_unchanged':before==after,'changed_protected_paths':[p for p in before if before[p]!=after[p]],
                'running_after':running_senders(),'collection_started':False,'send_started':False,
                'production_account_session_created':False}
        (BASE/'installed.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
        if before!=after:raise RuntimeError('protected files changed; inspect result')
        # Update only the stale identity-error text; never overwrite a newer live state.
        status_path=DEST/'status.json'
        status=json.loads(status_path.read_text(encoding='utf-8-sig'))
        if status.get('message') in ('当前账号身份无法核验，请确认已登录正确账号后再点启动／继续。',
                                     'Expecting value: line 1 column 1 (char 0)'):
            (BASE/'before/status.json').write_bytes(status_path.read_bytes())
            status['message']='旧记录读取问题已修复。点启动／继续将跳过已尝试目标，接续同一批；原未知和预留记录保留。'
            atomic(status_path,json.dumps(status,ensure_ascii=False,indent=2).encode('utf-8'))
        print(json.dumps({'installed_at':stamp,'files':len(FILES),
              'protected_unchanged':result['protected_unchanged'],'running_after':result['running_after'],
              'send_started':False,'collection_started':False},ensure_ascii=False))

if __name__=='__main__':main()
