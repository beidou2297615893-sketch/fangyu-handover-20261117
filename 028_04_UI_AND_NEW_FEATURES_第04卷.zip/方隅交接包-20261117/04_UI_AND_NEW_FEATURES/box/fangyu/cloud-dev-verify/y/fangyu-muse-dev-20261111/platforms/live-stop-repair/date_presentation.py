from pathlib import Path
import hashlib,json
S=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project');T=Path(__file__).resolve().parent
rows=json.loads((T/'SOURCE-CHANGES.json').read_text('utf-8'))
def update(path,a,b):
    p=S/path;s=p.read_text('utf-8');assert s.count(a)==1,(path,a);s=s.replace(a,b)
    if p.suffix=='.py':compile(s,str(p),'exec')
    p.write_text(s,encoding='utf-8')
    next(row for row in rows if row['path']==path)['after']=hashlib.sha256(p.read_bytes()).hexdigest()
update('work/ui-runtime-r55/src/core/engine.py',"'comment_date_evidence','verification_status'}","'comment_date_evidence','verification_status','post_date_status'}")
update('work/ui-native-r57/customer_workbench.py',"            'evidence':evidence[:9],","""            'sourceNotice':'帖子日期未提供，时间范围待核实' if any(
                (comment.get('lead') or {}).get('post_date_status')=='unverified' for comment in comments) else '',
            'evidence':evidence[:9],""")
update('work/ui-approved-implementation/ui-preview/pages/reply-connected.mjs',"<p class=\"rp-loading-note\" role=\"status\">${v.detailLoading?","${preview.sourceNotice?`<p class=\"rp-loading-note\">${esc(preview.sourceNotice)}</p>`:''}<p class=\"rp-loading-note\" role=\"status\">${v.detailLoading?")
update('work/ui-approved-implementation/ui-preview/pages/reply-connected.mjs',"${esc(row.publishedAt||'原评论时间未提供')}</span><button", "${esc(row.publishedAt||'原评论时间未提供')}</span>${person.sourceNotice?`<small class=\"rp-loading-note\">${esc(person.sourceNotice)}</small>`:''}<button")
(T/'SOURCE-CHANGES.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
print('Post date uncertainty persisted and visible alongside original source')
