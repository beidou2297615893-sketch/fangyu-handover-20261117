from pathlib import Path
import hashlib,json
T=Path('C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/douyin-login-sync-20261020');P=Path('C:/积木软件工坊/项目/方隅公寓客户版');F=P/'work/parallel-integration-20261018/final-integration';S=F/'stage-02/project';N=P/'work/ui-native-r57';plan=json.loads((F/'entry-v40/CANONICAL-DELEGATION-PREPARED.json').read_text('utf-8-sig'));R=Path(plan['release']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest().upper()
assert sha(N/'run_workbench.py')==plan['launcher_sha256'];assert sha(N/'state/production-workspace.json')==plan['workspace_binding_sha256']
for n in ['app.mjs','account-connection-state.mjs','pages/accounts.mjs']:assert (R/'web'/n).read_bytes()==(S/'work/ui-approved-implementation/ui-preview'/n).read_bytes()
result={'status':'INSTALLED_SOURCE_VERIFIED','release_id':plan['release_id'],'canonical_sha256':sha(N/'run_workbench.py'),'changed_files':3,'closure_files':2733,'release_check_files':137,'jobless_douyin_auto_confirmation':'PASS_RED_TO_GREEN','verified_nickname_display':'PASS','exact_account_scope':'PASS','stop_on_success_close_account_switch_and_failure':'PASS','bounded_checks':'12 checks maximum; 120 seconds maximum; backoff 2.5/5/10 seconds','old_terminal_receipt_regressions':'PASS','reply_sender_regression':'PASS','real_platform_calls':0,'real_sends':0,'production_data_mutation':False,'latest_native_window':'NOT_RESTARTED_OR_VISUALLY_VERIFIED','current_real_platform_login':'NOT_VERIFIED_BY_AGENT'}
(T/'FINAL.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
text='''用户明确要求修复抖音连接；此授权仅覆盖连接问题，其他界面仍按先改图、确认后改代码。
已确认根因：_douyin_result合法返回id空串；showAccountJob原来只在jobId存在时安排检查、继续计时。因此抖音受控浏览器网页登录后没有自动身份核对，快照仍logging_in。
v40仅改app.mjs/account-connection-state.mjs/pages/accounts.mjs。当前exact accountId且windowOpen真时进行原account_check；不调用start重新开登录，不改服务/CLI/身份守卫。最多12次或120秒，逐步退避；成功、失败、关闭、换账号/平台/员工/门店即停止。手动检查原窗口也能进入同一有界自动确认。平台严格身份+绑定+同账号ready仍是成功条件。
账号页抖音未连接按钮改“连接此账号/继续连接”，成功显示平台昵称和“已连接”；历史失败文案不覆盖新成功。其他账号行为保留。
先RED复现无jobId不安排检查，再GREEN。正向自动确认昵称、未知不冒成功、关闭/换账号/失败停止、有界等待、既有终态回执/旧回调、跨账号回复选择回归通过。测试初次漏activePlatform辅助函数已补齐fixture，不是产品故障。JS语法通过。
2733 closure与137 release --check通过，source和release三文件字节一致，原入口已安装v40，SHA55E39FFA3BAEE8F723C081238283E5B824AF0513486F29189B508BD25885036E；entry-v40/canonical-entry-before备份v39。下一变更before必须v40。绑定hash未变，未写生产DB/会话/断点、未发起平台请求/真实发送。
未重启用户当前工作台，不能声称新版实窗或真实平台已通过。需保存草稿后退出重开原入口，抖音点连接原账号，既有持久profile资料继续复用。平台本人验证码仍本人完成，不能用人工ready或旧昵称伪造成功。整体夜间goal的其他未完成项保持，不标complete。
'''
(T/'CONTINUE.md').write_text(text,encoding='utf-8')
with (T.parent/'overnight-verification/CONTINUE.md').open('a',encoding='utf-8') as h:h.write('\n## 2026-10-20 上午：抖音无任务编号登录自动确认修复 v40\n'+text+'\n')
(P/'memory/sessions/2026-10-20-douyin-login-sync.md').write_text(text,encoding='utf-8')
print(json.dumps(result))
