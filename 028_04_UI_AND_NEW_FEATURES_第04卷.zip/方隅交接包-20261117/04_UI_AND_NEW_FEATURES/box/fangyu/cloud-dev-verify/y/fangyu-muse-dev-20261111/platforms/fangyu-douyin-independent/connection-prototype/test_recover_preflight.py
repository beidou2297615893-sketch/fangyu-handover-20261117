import hashlib
import json
import sqlite3
import tempfile
import unittest
from pathlib import Path

from recover_preflight import recover, GUARD, CALL

SOURCE = ('async function invoke(){\n' + GUARD + '\n' + CALL + ');\n}').encode()
SOURCE_HASH = hashlib.sha256(SOURCE).hexdigest()
REQUEST = 'synthetic-request-only'

class RecoveryTests(unittest.TestCase):
 def setUp(self):
  self.tmp = tempfile.TemporaryDirectory(); self.root=Path(self.tmp.name)
  (self.root/'runtime').mkdir(); (self.root/'runner-live-v2').mkdir()
  (self.root/'runner.cjs').write_bytes(SOURCE)
  self.spec={'request_id':REQUEST,'account_uid':'synthetic-account','connection_id':'synthetic-page','scan_id':'synthetic-scan','kind':'comments','target':'123','store_id':'synthetic-store','keyword':'synthetic','cursor':40}
  self.response={'ok':False,'transport_error':'connection_changed'}
  self.control={'scan_id':'synthetic-scan','stopped':'ledger_unknown','pending':None,'nextIndex':4,'commentStreaks':{'synthetic-store':1}}
  self.write_json('runner-live-v2/control.json',self.control)
  self.write_json('runner-live-v2/'+REQUEST+'.json',{'spec':self.spec,'response':self.response})
  self.write_json('runner-live-v2/'+REQUEST+'.receipt.json',{'state':'unknown','request_id':REQUEST})
  self.db=sqlite3.connect(self.root/'runtime/collection.sqlite3')
  self.db.executescript('''
   CREATE TABLE account_halts(account_uid TEXT PRIMARY KEY,request_id TEXT,state TEXT,detail TEXT,halted_at TEXT);
   CREATE TABLE attempts(request_id TEXT PRIMARY KEY,state TEXT,spec TEXT,response TEXT);
   CREATE TABLE recovery_events(event_id INTEGER PRIMARY KEY,account_uid TEXT,request_id TEXT,operator TEXT,reason TEXT,rule_source TEXT,recovered_at TEXT);
   CREATE TABLE scan_streams(scan_id TEXT,account_uid TEXT,kind TEXT,target TEXT,store_id TEXT,keyword TEXT,cursor INTEGER,exhausted INTEGER);
   CREATE TABLE scan_pages(request_id TEXT);
  ''')
  self.db.execute('insert into account_halts values(?,?,?,?,?)',('synthetic-account',REQUEST,'unknown','unknown','time'))
  self.db.execute('insert into attempts values(?,?,?,?)',(REQUEST,'unknown',json.dumps(self.spec),json.dumps(self.response)))
  self.db.execute('insert into scan_streams values(?,?,?,?,?,?,?,?)',('synthetic-scan','synthetic-account','comments','123','synthetic-store','synthetic',40,0));self.db.commit()
 def tearDown(self): self.db.close();self.tmp.cleanup()
 def write_json(self,relative,value): (self.root/relative).write_text(json.dumps(value),encoding='utf8')
 def run_recover(self): return recover(self.root,REQUEST,SOURCE_HASH)
 def assert_halted(self):
  self.assertEqual(self.db.execute('select count(*) from account_halts').fetchone()[0],1)
  self.assertEqual(self.db.execute('select count(*) from recovery_events').fetchone()[0],0)
  self.assertEqual(json.loads((self.root/'runner-live-v2/control.json').read_text())['stopped'],'ledger_unknown')
 def test_exact_preflight_reconciles_without_request_or_cursor_changes(self):
  self.assertEqual(self.run_recover()['state'],'preflight_evidence_reconciled')
  self.assertEqual(self.db.execute('select count(*) from account_halts').fetchone()[0],0)
  self.assertEqual(self.db.execute('select state from attempts').fetchone()[0],'unknown')
  self.assertEqual(self.db.execute('select cursor from scan_streams').fetchone()[0],40)
  operator,reason=self.db.execute('select operator,reason from recovery_events').fetchone()
  self.assertEqual(operator,'Codex代码及本地证据核验');self.assertIn('不声称人工确认',reason)
  control=json.loads((self.root/'runner-live-v2/control.json').read_text(encoding='utf8'))
  self.assertIsNone(control['stopped']);self.assertEqual(control['nextIndex'],4);self.assertEqual(control['commentStreaks'],self.control['commentStreaks'])
 def test_other_unknown_never_unblocks(self):
  self.db.execute('update attempts set response=?',(json.dumps({'ok':False,'transport_error':'transport_unknown_no_retry'}),));self.db.commit()
  with self.assertRaises(ValueError):self.run_recover()
  self.assert_halted()
 def test_verification_or_limit_never_unblocks(self):
  self.db.execute("update account_halts set state='verification_required'");self.db.commit()
  with self.assertRaises(ValueError):self.run_recover()
  self.assert_halted()
 def test_changed_control_pending_never_unblocks(self):
  self.control['pending']={'phase':'dispatching'};self.write_json('runner-live-v2/control.json',self.control)
  with self.assertRaises(ValueError):self.run_recover()
  self.assert_halted()
 def test_cursor_changed_never_unblocks(self):
  self.db.execute('update scan_streams set cursor=60');self.db.commit()
  with self.assertRaises(ValueError):self.run_recover()
  self.assert_halted()
 def test_wrong_runner_source_never_unblocks(self):
  (self.root/'runner.cjs').write_text('different',encoding='utf8')
  with self.assertRaises(ValueError):self.run_recover()
  self.assert_halted()
 def test_receipt_mismatch_never_unblocks(self):
  self.write_json('runner-live-v2/'+REQUEST+'.receipt.json',{'request_id':REQUEST,'state':'parsed'})
  with self.assertRaises(ValueError):self.run_recover()
  self.assert_halted()
 def test_existing_lease_never_unblocks(self):
  h=hashlib.sha256(b'synthetic-page').hexdigest()[:24]
  (self.root/('runner-lease-connection-'+h+'.json')).write_text('{}')
  with self.assertRaises(FileExistsError):self.run_recover()
  self.assert_halted()

if __name__=='__main__': unittest.main()
