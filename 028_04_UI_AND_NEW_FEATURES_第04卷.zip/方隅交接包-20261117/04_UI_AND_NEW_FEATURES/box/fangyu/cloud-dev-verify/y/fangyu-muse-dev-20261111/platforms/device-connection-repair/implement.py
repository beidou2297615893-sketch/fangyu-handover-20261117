from pathlib import Path
import json,shutil
T=Path(__file__).resolve().parent;S=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project')
files=['work/ui-approved-implementation/ui-preview/'+n for n in ('device-reconnect.mjs','pages/acquire.mjs','app.mjs')]+['work/shared-backend-integration/platform_runtime.py']
for f in files:
 d=T/'before'/f;d.parent.mkdir(parents=True,exist_ok=True);assert not d.exists();shutil.copyfile(S/f,d)
(T/'CHANGED.json').write_text(json.dumps(files,ensure_ascii=False,indent=2),'utf-8')
(T/'PLAN.md').write_text('修复原生重开后，旧暂停任务的分析phase阻止纯电脑连接恢复；只恢复existingOnly连接，不自动续采/重发未知分析/重新平台登录。对已确认模型请求完成且pending=0、仅本机页队列待处理的历史记录，允许主动新建新批；原队列/断点保留。未知计费、运行中、跨身份仍阻止。开始页增加明确重连入口，离线状态说明下一步。源仅本客户四文件，独立备份；不写真实分析记录/设备授权/账号会话。',encoding='utf-8')
def edit(f,old,new):
 p=S/f;b=p.read_text('utf-8');assert b.count(old)==1,(f,old[:80],b.count(old));p.write_text(b.replace(old,new),'utf-8')
f=files[0]
edit(f,'const p=state.platform,d=p?.device,user=state.user,analysis=p?.acquisition?.analysis;','const p=state.platform,d=p?.device,user=state.user;')
edit(f,"      ||['running','starting','pausing','analyzing','queued'].includes(p.acquisition?.status)\n      ||p.acquisition?.phase==='analyzing'||analysis?.pending>0\n      ||['running','queued','pending','unknown'].includes(analysis?.status)\n      ||/UNKNOWN|UNCONFIRMED/.test(analysis?.code||''))return;", "      ||['running','starting','pausing','analyzing','queued'].includes(p.acquisition?.status))return;\n    // The explicit-local connection starts only its control-plane heartbeat.\n    // Saved/unknown analysis is kept intact and must not prevent recovery.")
f='work/shared-backend-integration/platform_runtime.py'
edit(f,"class PlatformRuntimeError(ValueError):",'''def analysis_blocks_new_batch(pending, job):
    """Admission only; never alters a saved source or repeats an AI request."""
    if pending is None:
        return False
    confirmed_backlog=(pending.get('status')=='pending' and not pending.get('code')
        and job.get('status')=='completed' and not job.get('code')
        and type(job.get('pending')) is int and job['pending']==0
        and all(pending.get(key) and pending.get(key)==job.get(key) for key in ('id','tenant_id','owner')))
    return not confirmed_backlog


class PlatformRuntimeError(ValueError):''')
edit(f,"'offline':'电脑已绑定，等待企业连接'", "'offline':'工作连接尚未恢复，请点击重新连接'")
edit(f,"        if state=='held' and reason in", "        if state=='offline' and self.service.thread is not None and self.service.thread.is_alive():\n            message='正在恢复工作连接；网络未恢复时可点击重新连接检查'\n        if state=='held' and reason in")
edit(f,"        if analysis_pending and not active:\n            status='paused'", "        analysis_blocked=analysis_blocks_new_batch(analysis_pending,ai_job)\n        if analysis_pending and not active:\n            status='paused'")
edit(f,"            if not code:message=analysis_message", "            if not code:message=analysis_message if analysis_blocked else '旧任务还有待分析评论，已保留；可继续原任务，或按当前条件开始新批次'")
edit(f,"'canStart':not code and not active and not analysis_pending", "'canStart':not code and not active and not analysis_blocked")
f='work/ui-approved-implementation/ui-preview/app.mjs'
edit(f,"async function preparePlatform(){const result=await runPlatformOperation('platform_prepare');", "async function preparePlatform(options={}){const result=await runPlatformOperation('platform_prepare',options?.existingOnly===true?{existingOnly:true}:{});")
edit(f,"  state.platform=platform;showPlatformNotice();", "  state.platform=platform;if(platform?.device?.state==='online')state.deviceReconnectError='';showPlatformNotice();")
f='work/ui-approved-implementation/ui-preview/pages/acquire.mjs'
edit(f,"resume=false,enabled=false,accountLink=false})", "resume=false,enabled=false,accountLink=false,reconnect=false})")
edit(f,"${accountLink?'<button type=\"button\" class=\"acquire-link\" data-acquire-accounts>连接本店账号</button>':''}", "${reconnect?'<button type=\"button\" class=\"acquire-link\" data-acquire-reconnect>重新连接</button>':''}${accountLink?'<button type=\"button\" class=\"acquire-link\" data-acquire-accounts>连接本店账号</button>':''}")
edit(f,"  const accountLink=blocked&&live.reasonCode==='account_not_ready';", "  const accountLink=blocked&&live.reasonCode==='account_not_ready';\n  const reconnect=blocked&&!state.deviceReconnecting&&state.platform?.device?.bound===true&&['offline','stopped','error'].includes(state.platform.device.state);")
edit(f,"    ||(blocked||failure?live.message||", "    ||(blocked||failure?state.deviceReconnectError||live.message||")
edit(f,":blocked?(accountLink?`本店${platformName}账号未连接`:'暂不能开始')", ":blocked?(reconnect?'工作连接未恢复':accountLink?`本店${platformName}账号未连接`:'暂不能开始')")
edit(f,"statusRow({status,label,message,accountLink,pause:", "statusRow({status,label,message,accountLink,reconnect,pause:")
edit(f,"  root.querySelector('[data-acquire-verify]')?.addEventListener", "  root.querySelector('[data-acquire-reconnect]')?.addEventListener('click',()=>ctx.actions.preparePlatform?.({existingOnly:true}));\n  root.querySelector('[data-acquire-verify]')?.addEventListener")
compile((S/'work/shared-backend-integration/platform_runtime.py').read_bytes(),'platform_runtime.py','exec')
print(json.dumps({'changed_files':len(files),'platform_or_ai_requests_started':0,'production_data_mutation':False}))
