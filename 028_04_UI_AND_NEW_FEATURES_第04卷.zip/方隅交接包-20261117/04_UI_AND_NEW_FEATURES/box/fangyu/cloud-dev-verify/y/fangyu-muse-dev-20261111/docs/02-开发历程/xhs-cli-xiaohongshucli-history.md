# 本窗口「小红书cli」开发与操作历程

编写日期为2026-11-10。本文依据本窗口保留的对话、执行结果和接续记忆整理，没有读取其他窗口历程，没有读取客户原文或登录凭据。下述日期、数字、状态都是当时快照，不代表2026-11-10现状。部分早期步骤仅保留心跳交接摘要，本文明确区分交接记忆与本窗口可见工具执行。没有足够证据的环节不追认为本窗口已完成。

## 一、任务起点与授权变化

2026-10-29之后，用户要求持续采集小红书评论，共用本地去重账本。最初交接基线为2755条，CSV、JSONL和SQLite快照位于 C:/Users/rmsama/Documents/ChatGPT/自动获客系统/outputs/古北采集数据与去重账本。交接说明这些数据已合并核验，但本次历史整理没有重新验证。实际共享账本路径为 C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/shared-acquisition-ledger/shared.sqlite3。

用户澄清新账号任务与旧账号故障相互独立，仅共用账本，不能把旧账号限流、失效直接套到新任务。早期心跳记忆称新账号任务首批新增122条。这是交接快照，本次没有重新执行该批。

后来范围扩大到15家门店，要求轮流覆盖关键词，优先近期需求，减少明确同行推广来源。来源门店仅为搜索入口，不能直接作为客户意向门店，IP地区也不能替代实际需求地区。用户要求每新增100条去重入账主动汇报，原始抓取数不能冒充登记数。

用户随后授权回复已有高意向评论，多次要求整批发送、使用新语气、按账号登录接续。本窗口最终确认慧慧酱改名为玉米碴是同一发送账号。2026-11-03用户要求暂停采集、改发剩余高意向。2026-11-05再次明确发布慧慧酱批次。2026-11-06有恢复采集指令，随后又进入明确的本地清理任务。历次授权应按时间和任务分别解释，不能用历史发布授权自动恢复后来暂停或清理中的任务。

## 二、2026-10-29至10-30的采集接续记忆

15店入口为 C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/xhs-15-store-collection-20261029/run.py。首段运行目录为 C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/xhs-new-task-session-fix-20261029/runtime/live-tasks/stores15-segment001-20261029。账号当时为蕾姆。首段145词页是分段计划，不能称整体采集完成。

交接心跳先记录264条，再记录305条。305的构成为264+41，第三批搜索预热返回HTTP461，第三批新增0，进程退出。随后部分登记恢复13条，形成318条基线。resume001、resume002、resume003记为0新增，避免重复计算。上述属于早期交接记忆中的已核验结论，不是本次重新对账结果。

2026-10-30接续目录为 C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/xhs-new-task-session-fix-20261029/runtime/live-tasks/stores15-resume004-20261030。当时最小诊断曾在同会话同参数下成功读取原失败笔记4条，均已入账，没有借此重登或声称所有461修好。诊断摘要在 C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/xhs-461-diagnosis-20261030/diagnosis-summary.json。

用户反复指出网页没有验证码。本窗口形成的边界是，后台461/471不能直接说成网页弹窗或账号封禁。实际验证、429、会话失效、结果未知出现时停止新请求，保存断点，未知登记先本地对账，不能盲重试。

## 三、2026-11-01发送历史及其不确定性

发送工程位于 C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/xhs-send-current-20261029。原冻结任务567条，结构为4超高、548高、15中，这只是当时分类与草稿快照。新增846另批，不能混算。

本窗口保留了发送到第8条附近出错、错误-1、后续-9131、未知结果隔离与继续批次的对话。不能仅凭这些对话断言几百条全部公开可见。2026-11-03读取旧status.json时发现其中数字滞后且混有多个阶段，例如26次请求、23回执、3未知，以及后续53/12等字段。随后读取的 reply-milestone-report.json 记载最近报告261回执、13未知。它们均为历史文件读数，不能合成今天累计，更不能作为公开可见数。

相关实现包括 bulk_run.py、managed_send_client.py、readback_client.py、scoped_isolation.py、tone_singleton.py、tone_batch.py、target_isolation.py，均位于上述发送工程。共享账本保留reservation与结果语义，unknown不得自动重发。direct-id模式可用既有评论ID和核准文本，平台接受回执与独立公开回读分开统计。

历史停止状态和撤销链位于该工程 emergency-platform-halts 及 runs 子目录。旧特例策略绑定特定历史批次、账号、原文摘要和未知记录，并非通用解锁开关。

## 四、2026-11-03的CLI问题调查

接续工程为 C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/xhs-resume-20261103。曾读取 README.md、resume006.py、verify_resume006.py、login_diagnostic.py、active-runner.json 及脱敏诊断。

旧CLI采集resume004有3566条的本地对账逻辑，早期总基线有3884，部分恢复再加30成为原15店3914。上述数字是不同阶段口径，不能相互替代。本窗口读取代码时确认resume006默认预览，执行需专用会话与身份核验，并采用共享账本、锁和批次登记回执。

Chrome会话同步曾有 NoCookieError，原生诊断显示 RequiresAdminError。专用HTTP二维码已扫描确认但完成阶段要求验证，未保存会话。相关文件在接续工程内 chrome-sync-result-02.json、chrome-native-local-diagnostic.json、dedicated-login-result.json。没有通过管理员读取浏览器凭据来解决。

曾使用 C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/xhs-standalone-session/diagnostics/qr_http_adapter.py。它处理整数/字符串扫码状态、完成响应与当前身份一致性，事件输出固定类别，避免凭据进入诊断。适配存在及离线测试通过不表示真实扫码完成。

2026-11-03实际用旧慧慧酱专用会话做只读身份诊断，后一次证据明确显示HTTP200、success=false、业务码-100、删除web_session、无验证头。报告在 C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/xhs-resume-20261103/sender-session-diagnosis.json。它证明那份保存会话当时不可用，不能推断账号封禁。

## 五、网页DOM临时采集及Token路线纠正

CLI受阻期间，本窗口通过CUA可见内置浏览器读取公开笔记、顶层评论和展开楼中楼，使用 import_browser_dom.py 本地预览后登记共享账本。文件在 C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/xhs-resume-20261103。原始样本为 browser-sample*.json，批次为 browser-runtime/batch-*，状态为 browser-collection-status.json。

本轮网页登记按真实manifest累计，旧3914和全账本基线13243不算新本轮。保留记忆中的进度依次有7、23、104、137、142、151。104时报告过首个100门槛。至batch0040为137，batch0041新增5到142，batch0042新增6、0043新增3，到151。网页原始精选条数与登记数有区别，batch0001有2条已有记录。此处不列客户正文或客户身份。

操作上优先近期个人求租、转租，展开可见回复，排除明显房源推广。部分笔记只读第一批评论，明确 note_completion_proven=false，不能声称穷尽。曾遇跨轮浏览器句柄报 browser.user is unavailable，创建同浏览器新页可继续，当时未把它当平台限流。

用户指出模型逐页读网页消耗Token。本窗口停止网页路线，删除 automation-9，保存151条与断点。状态写为用户成本偏好停止，后又写为用户暂停。此前逐页执行并没有满足用户希望CLI本地执行的成本目标，是实际路线偏差。

## 六、本地低Token原则与时间排序接入

2026-11-03后读取 C:/Users/rmsama/.codex/rules/cli-local-execution-low-token-long-term-rules.md，常规调度、去重、计数、回执由本地程序处理，模型约15分钟低频核验，正常安静。网页每分钟心跳已删除，不能说仍自动监测。

2026-11-04本窗口实际新增 daily_time_order.py 并在 bulk_run.py 正常CLI入口调用。路径为 C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/xhs-send-current-20261029。读取每日指针 C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/fangyu-text-business-20261029/recency-priority/daily-priority/current.json，核source与queue SHA，仅重排原授权rows，不添加目标或改文案，缺目标会停止准备。

起初按原评论时间降序，后上游规则变为7/15/30天时间档、预算证据、意向、同档新旧。本窗口消费指针原顺序，未自写覆盖预算/意愿。曾用444条倒序输入验证可恢复队列顺序、哈希一致。47项bulk_run测试通过，表示本地回归通过，不是平台发送成功。

原评论时间字段published_at_unix的秒/毫秒兼容，以及每日00:05本地刷新，是其他窗口交接的实现。本窗口只验证消费端，不把上游代码算成本窗口开发。

## 七、2026-11-04至11-05真实登录与发送启动

2026-11-04通过 login_diagnostic.py 启动专用HTTP扫码，目录 C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/xhs-standalone-session/huihuijiang-reply-relogin-20261104-01，后来日志为scan_timeout。

2026-11-05目录 huihuijiang-reply-relogin-20261105-01 的日志确认扫描、手机确认后，completion返回HTTP471且验证头存在，停止且未保存会话。用户手机和内置浏览器均无验证码。之后 huihuijiang-reply-verified-20261105-02 又产生新二维码，最终scan_timeout。反复HTTP二维码没有解决实际登录，这一阶段多次答复停在阻碍，未完成用户要求的发送。

本窗口曾打开内置浏览器并用公开“我”链接核对同账号，但该网页登录并不自动同步CLI会话。

随后实际启动已有 browser_cli_once.py，调用CLI自己的可见浏览器辅助二维码登录，目录 C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/xhs-standalone-session/huihuijiang-browser-login-20261105-01。该入口禁HTTP fallback。CUA看到Camoufox登录页并前置窗口。后来从exec会话96548读取到登录确认、authenticated=true、非游客、账号玉米碴，CLI退出0并保存会话。浏览器随登录程序结束关闭。本窗口曾未及时读取成功输出，错误地继续报告等待登录，后向用户更正。

2026-11-05实际运行 bulk_run.py --latest-priority --execute --direct-id，显式指定慧慧酱UID、上述专用session-home、旧platform-access-state、新run-name huihui-latest-live-20261105-01。执行结果accepted=0、post_attempts=0，停止原因 persistent_platform_halt_requires_review。当天可见本窗口工具结果没有成功提交评论，不能把230条预览当发送。

当时最新发布指针为 latest-priority-batch.json，原270条分230/40两账号。批次是上游准备，本窗口实际预览慧慧酱230条local_holds=0。后来用户要求修到发完，本窗口只调查旧unknown授权结构，未完成发送恢复。

## 八、2026-11-06采集核验失败

用户要求恢复采集。本窗口用 verify_resume006.py 对2026-11-05浏览器登录会话做一次身份请求。结果stopped、error_type=Halt、request_started=true，没有具体HTTP诊断，新增0。不能据此判会话一定失效、验证码或账号限制。日志覆盖不足仍未补齐，这次未启动搜索采集。

## 九、2026-11-06清理任务的实际修改与缺口

上游明确清理超过30天和最终low/non_customer/ended，未知隔离，原长期门店/词库/母句保留，共享库由根窗口负责。本窗口仅处理自己范围，未请求平台或启动发送。

复用清理器 C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/fangyu-text-business-20261029/retention-cleanup-20261106/scrub_text_records.py 和 recency-priority/retention30.py。第一次检查43份网页样本命中0，不证明全部满足保留条件。报告 C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/xhs-resume-20261103/retention-cleanup-result.json。

按上游最新排除指纹，冻结源 all-classifications.jsonl 和 source-input.jsonl 各删除1994条引用，各剩761；precomputed-replies.jsonl 删除384，剩183。这些都是当时引用数，不是不同客户数。直接 frozen-source-receipt.json 更新SHA，复算通过。结果 frozen-retention-deletion.json 在接续工程内。

随后旧runs中39份指定输入/映射/批次副本检查，34份修改，删除8424条引用。没有将旧批次重新声明为可执行。报告 retention-dependency-rebuild.json 在接续工程内。

本窗口运行 prepare_latest_priority.py 重建当前入口，2026-11-06该快照235源候选、214入队，分180/34两账号。慧慧酱和另账号均真实CLI离线preview通过，local_holds=0，0平台请求。源来自根文本窗口，未重跑AI分类。新批次位于发送工程 runs/latest-priority-20261106-093642-041909。不能把214当成功发送或全部高意向。

8份历史events.jsonl做了命中记录的最小化，保留目标ID、账号、状态、结果、时间等字段和规范化原记录SHA摘要。这个摘要不等于原始字节签名或完整历史授权证明。曾先删正文后处理依赖，导致旧策略无法原样复验，是实际处理顺序缺陷。

在上游明确边界后，本窗口在 scoped_isolation.py、tone_batch.py、target_isolation.py 的validate_context入口加入退休标记检查，标记 retired-historical-scopes.json。共4类历史策略离线验证拒绝使用，固定原因 historical_scope_retired_after_retention_cleanup。这是退休旧特例授权，不是迁移成新豁免。旧unknown停线未解除。保留旧代码历史哈希作来历，但不宣称仍可重建已删正文。

current-visible-statistics.json 当时读取正向池416条，中411、高4、超高1。它是2026-11-06快照，未声称2026-11-10仍为这些数量。outputs/小红书回复发送进度/进度.html 由该统计生成，是静态HTML，未实现持续刷新。采集进度旧页由根处理，本窗口没有完成它。retirement-verification.json 保存4类退休校验、两账号预览与0请求记录。

## 十、接续入口及尚未验收项

工程根为 C:/Users/rmsama/Documents/ChatGPT/自动获客系统。Python运行环境为该根下 work/vendor/cli-runtime/Scripts/python.exe。本文只记录入口，不在写史时执行。

发送普通离线入口为该根下 work/xhs-send-current-20261029/bulk_run.py --latest-priority，指定账号UID后预览。准备入口为同目录 prepare_latest_priority.py。真正发送还要求实际有效登录、明确授权、实时账本reserve、防重和平台停止状态检查，不能仅因preview通过执行。历史特例已退休，不能替换常量让它复活。

采集旧入口在 work/xhs-resume-20261103/resume006.py，存在固定旧对账前置、固定新runtime目录和身份receipt前提。其存在不代表可以直接重新执行，必须先核当前源与断点，避免已存在目录和旧断点冲突。最近15/30天过滤预接在本窗口未完整实施，曾阅读上游口径后被用户发送请求打断，不能称平台筛选已接通。

登录可见浏览器入口在 work/xhs-standalone-session/diagnostics/browser_cli_once.py。历史上2026-11-05成功一次，不能推定今天有效。用户需完成扫码或验证时应保留真正专用窗口，不能用普通内置浏览器登录来冒充CLI会话。

未完成事项包括采集身份请求缺少详细安全错误证据、恢复采集到原时间过滤与实际入账的整链验收、新发送授权与未知停线接续、历史回执最小化覆盖完整性复核、静态进度持续刷新、清理后旧单元测试及全部调用者的兼容回归。4类退休拒绝和两账号preview是局部验收，不能称全部旧测试通过或发送已恢复。

## 十一、本次写史操作边界

2026-11-10本次仅阅读指定HISTORY-COMMON.md并写本文。未打开小红书，未采集、发送、登录或重试，未清除unknown，未读取客户原文和登录凭据，未修改生产文件，未取消任务。未修改「小红书 CLI｜搜索跟进」的xhs-cli-history.md或其他窗口历程。以上历史细节来源于本窗口上下文，未通过现在重新运行生产链路验证。
