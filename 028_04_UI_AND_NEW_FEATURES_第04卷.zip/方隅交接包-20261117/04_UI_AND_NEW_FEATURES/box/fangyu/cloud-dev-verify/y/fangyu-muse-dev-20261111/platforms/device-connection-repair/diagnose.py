from pathlib import Path
import sqlite3,json,hashlib
T=Path(__file__).resolve().parent;P=Path('C:/积木软件工坊/项目/方隅公寓客户版');N=P/'work/ui-native-r57'
b=json.loads((N/'state/production-workspace.json').read_text('utf-8-sig'))
tenant='cloud-'+hashlib.sha256((b['environment_id']+'\n'+b['company_id']).encode()).hexdigest()[:24]
con=sqlite3.connect((Path(b['data_dir'])/'workspace.sqlite3').as_uri()+'?mode=ro',uri=True);con.execute('PRAGMA query_only=ON')
def rows(entity):return [json.loads(r[0]) for r in con.execute('SELECT body FROM records WHERE entity=? AND tenant_id=?',(entity,tenant))]
tasks=sorted([r for r in rows('tasks') if r.get('cloud_owner')==b['owner']],key=lambda r:r.get('created_at',''),reverse=True)
latest=tasks[0] if tasks else {}
jobs=[r for r in rows('ai_jobs') if r['id']==latest.get('id')]
pages=[r for r in rows('workbench_collection_page_analysis_v1') if r['id']==latest.get('id')]
value={'access':'read_only_actual_workspace','latestTask':{k:latest.get(k) for k in ('id','name','status','pause_reason','created_at','platform','store_id')},
 'aiJobs':[{k:r.get(k) for k in ('id','status','code','pending','updated_at')} for r in jobs],
 'pageAnalysis':[{'status':r.get('status'),'code':r.get('code'),'pendingLeadCount':len(r.get('lead_ids',[])),
   'receiptIdentityMatches':bool(jobs and all(r.get(k) and r.get(k)==jobs[0].get(k) for k in ('id','tenant_id','owner')))} for r in pages],
 'active':json.loads((N/'state/active.json').read_text('utf-8-sig')) if (N/'state/active.json').exists() else None}
con.close();(T/'REAL-DIAGNOSTIC.json').write_text(json.dumps(value,ensure_ascii=False,indent=2),'utf-8');print(json.dumps(value,ensure_ascii=False))
