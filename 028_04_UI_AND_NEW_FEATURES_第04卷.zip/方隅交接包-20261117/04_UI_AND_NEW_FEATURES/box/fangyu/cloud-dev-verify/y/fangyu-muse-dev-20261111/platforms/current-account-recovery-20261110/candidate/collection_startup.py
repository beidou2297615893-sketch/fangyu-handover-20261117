"""Local startup coordination. No import-time actions or platform requests."""
import ctypes
import json
import os
import re
import uuid
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path


class StartupBlocked(RuntimeError):
    pass


def process_running(pid):
    if type(pid) is not int or pid < 1:
        return False
    kernel = ctypes.windll.kernel32
    kernel.OpenProcess.restype = ctypes.c_void_p
    handle = kernel.OpenProcess(0x100000, False, pid)
    if not handle:
        # Access denied is not proof of a dead owner.
        return kernel.GetLastError() == 5
    try:
        return kernel.WaitForSingleObject(ctypes.c_void_p(handle), 0) != 0
    finally:
        kernel.CloseHandle(ctypes.c_void_p(handle))


def collection_pause_reason(root):
    if (Path(root) / 'auto-collect.stop').exists():
        return ('采集已按你的要求暂停（auto-collect.stop 仍在，发送期间不恢复采集）。'
                '本次未启动、未清除停止标记；发送结束后请先确认可以恢复采集。')
    return None


def control_for_start(active, directory):
    directory = Path(directory)
    control = directory / 'control.json'
    if control.exists():
        return json.loads(control.read_text(encoding='utf-8-sig'))
    empty = not directory.exists() or (directory.is_dir() and not any(directory.iterdir()))
    if (active.get('startup_uninitialized') is True and active.get('needs_first_page_validation') is True
            and active.get('status') in ('prepared','paused') and empty):
        return {}
    raise StartupBlocked('采集断点文件缺失或已有请求痕迹，未猜测游标、未重读。请查看本地启动记录。')


@contextmanager
def startup_lock(root):
    """One OS-owned mutex for both new-round and continue; crash releases it."""
    import msvcrt
    with (Path(root) / 'collection-startup.lock').open('a+b') as handle:
        handle.seek(0)
        try:
            msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
        except OSError as error:
            raise StartupBlocked('已有启动／继续操作正在处理，请等待当前检查结果。') from error
        try:
            if handle.seek(0, os.SEEK_END) == 0:
                handle.write(b'0')
                handle.flush()
            yield
        finally:
            handle.seek(0)
            msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)


def recover_stale_leases(root, is_running=process_running):
    """Archive only proven-dead owners, preserving bytes; never clear business state.

    Caller holds startup_lock. Validate the whole set before moving any file.
    The runner's own exclusive-create leases remain the final duplicate guard.
    """
    root = Path(root)
    candidates = sorted(root.glob('runner-lease-*.json'))
    legacy = root / 'continue-collection.lock'
    if legacy.exists():
        candidates.append(legacy)
    validated = []
    for path in candidates:
        try:
            content = path.read_bytes()
            if len(content) > 4096:
                raise ValueError('oversized lock')
            if path == legacy:
                pid = int(content.decode('utf-8-sig').strip())
            else:
                if not re.fullmatch(r'runner-lease-(?:connection|database)-[a-f0-9]{24}\.json', path.name):
                    raise ValueError('unrecognized lease name')
                pid = json.loads(content.decode('utf-8-sig'))['pid']
            if type(pid) is not int or pid < 1:
                raise ValueError('invalid owner')
            if is_running(pid):
                raise StartupBlocked('采集或继续操作的进程仍在，未重复启动；请等待进度更新。')
            validated.append((path, content))
        except StartupBlocked:
            raise
        except (OSError, ValueError, KeyError, TypeError) as error:
            raise StartupBlocked('采集锁的归属暂时无法核实，未清锁、未启动。请查看本地启动记录。') from error
    if not validated:
        return []
    # A newly changed lock must not be mistaken for the stale owner we observed.
    if any(path.read_bytes() != content for path, content in validated):
        raise StartupBlocked('采集状态刚刚发生变化，请稍后再点启动／继续。')
    destination = root / 'startup-recovery' / (datetime.now().strftime('%Y%m%d-%H%M%S-%f') + '-' + uuid.uuid4().hex[:8])
    destination.mkdir(parents=True)
    archived = []
    for path, content in validated:
        if path.read_bytes() != content:
            raise StartupBlocked('采集锁正在更新，已保留原记录，请稍后再试。')
        path.replace(destination / path.name)
        archived.append(path.name)
    return archived


def identity_failure_message(result):
    """Summarize only known diagnostic fields; never surface bridge/config secrets."""
    stderr = result.stderr or b''
    if isinstance(stderr, bytes):
        stderr = stderr.decode('utf-8', errors='replace')
    for line in stderr.splitlines():
        try:
            diagnosis = json.loads(line)
        except ValueError:
            continue
        if isinstance(diagnosis, dict):
            if diagnosis.get('challenge_visible') is True:
                return '当前页面仍有平台验证。请在原抖音页面完成验证，再点继续；未知记录不会重发。'
            if diagnosis.get('uid_matches') is False and diagnosis.get('page_ready') is True:
                return '当前页面的原采集账号未核实，请确认原账号仍已登录，刷新页面后再点继续。'
    return '采集连接或页面暂未响应。请刷新已登录的原抖音页面，再点启动／继续；未知记录不会重发。'
