from pathlib import Path
import hashlib,json
T=Path(__file__).resolve().parent
S=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project')
relative='work/ui-approved-implementation/ui-preview/platform-notice.mjs'
p=S/relative
raw=p.read_bytes()
before='平台要求人工验证。查看账号页面的提示，完成后回到获客页继续。'.encode('utf-8')
after='请在这个账号的平台网页按提示完成验证，再回获客页点“继续原任务”；没有验证入口时联系管理员。'.encode('utf-8')
assert raw.count(before)==1
raw=raw.replace(before,after).replace('查看平台提示</button>'.encode('utf-8'),'查看账号</button>'.encode('utf-8'))
p.write_bytes(raw)
(T/'platform-notice.mjs').write_bytes(raw)
changes=json.loads((T/'SOURCE-CHANGES.json').read_text('utf-8-sig'))
for row in changes:
    if row['path']==relative:row['after']=hashlib.sha256(raw).hexdigest()
(T/'SOURCE-CHANGES.json').write_bytes((json.dumps(changes,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
print(hashlib.sha256(raw).hexdigest())
