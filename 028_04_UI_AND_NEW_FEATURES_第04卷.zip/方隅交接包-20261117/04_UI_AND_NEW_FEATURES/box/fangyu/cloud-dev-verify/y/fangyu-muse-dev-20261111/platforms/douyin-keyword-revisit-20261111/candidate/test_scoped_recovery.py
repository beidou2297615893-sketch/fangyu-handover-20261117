import json,sqlite3,unittest
from pathlib import Path
from tempfile import TemporaryDirectory
from collection_confirmed_scope import prepare_scope
from scoped_recovery import initialize,effective_halt

class ScopedRecoveryTests(unittest.TestCase):
 def setUp(self):
  self.c=sqlite3.connect(':memory:');self.c.row_factory=sqlite3.Row
  self.c.executescript('CREATE TABLE account_halts(account_uid,request_id,state,detail,halted_at);CREATE TABLE attempts(request_id,state,added,spec,response);');initialize(self.c)
  self.c.execute('insert into account_halts values(?,?,?,?,?)',('a','old','unknown','transport','1'))
  self.c.execute('insert into attempts values(?,?,?,?,?)',('old','unknown',0,json.dumps({'account_uid':'a','scan_id':'oldscan','target':'oldword'}),json.dumps({'ok':False,'transport_error':'bridge_result_not_established'})))
  self.c.execute('insert into collection_scope_reviews values(?,?,?,?,?,?,?)',('a','newscan','old','["newword"]','["123"]','user explicit','2'))
 def tearDown(self):self.c.close()
 def test_only_reviewed_scope(self):
  self.assertIsNotNone(effective_halt(self.c,'a','oldscan'));self.assertIsNone(effective_halt(self.c,'a','newscan'))
 def test_unknown_word_and_old_video_blocked(self):
  self.assertIsNone(effective_halt(self.c,'a','newscan',{'kind':'search','keyword':'newword','target':'newword'}))
  self.assertIsNotNone(effective_halt(self.c,'a','newscan',{'kind':'search','keyword':'oldword','target':'oldword'}))
  self.assertIsNotNone(effective_halt(self.c,'a','newscan',{'kind':'comments','keyword':'newword','target':'123'}))
 def test_future_faults_preserve_history_and_block(self):
  for n in range(2):self.c.execute('insert into collection_halt_events values(?,?,?,?,?)',('a','new'+str(n),'unknown','new fault',str(n+3)))
  self.assertEqual(effective_halt(self.c,'a','newscan')['request_id'],'new1')
  self.assertEqual(self.c.execute('select count(*) from account_halts').fetchone()[0],1)
 def test_platform_rejection_not_reviewable(self):
  self.c.execute('update attempts set response=?',(json.dumps({'ok':True,'value':{'status_code':2147}}),))
  self.assertIsNotNone(effective_halt(self.c,'a','newscan'))
 def test_mismatched_review_does_not_clear(self):
  self.c.execute("update collection_scope_reviews set reviewed_request_id='other'")
  self.assertIsNotNone(effective_halt(self.c,'a','newscan'))

 def test_legacy_unknown_requires_exact_hash_and_excludes_target_and_keyword(self):
  import hashlib
  response=json.dumps({'ok':False,'transport_error':'transport_unknown_no_retry'})
  spec=json.dumps({'account_uid':'a','scan_id':'oldscan','kind':'comments','target':'123','keyword':'oldword'})
  self.c.execute('update attempts set response=?,spec=?',(response,spec))
  self.assertIsNotNone(effective_halt(self.c,'a','newscan'))
  self.c.execute('insert into collection_event_reviews values(?,?,?,?,?,?,?)',
                 ('a','newscan','old',hashlib.sha256(response.encode()).hexdigest(),'explicit authorization','fresh identity and local diagnostics','3'))
  self.assertIsNone(effective_halt(self.c,'a','newscan',{'kind':'search','keyword':'newword','target':'newword'}))
  self.assertIsNotNone(effective_halt(self.c,'a','oldscan'))
  self.assertIsNotNone(effective_halt(self.c,'a','newscan',{'kind':'comments','keyword':'newword','target':'123'}))
  self.c.execute("update collection_scope_reviews set excluded_videos='[]'")
  self.assertIsNotNone(effective_halt(self.c,'a','newscan'))
  self.c.execute("""update collection_scope_reviews set excluded_videos='["123"]',allowed_keywords='["newword","oldword"]'""")
  self.assertIsNotNone(effective_halt(self.c,'a','newscan'))
  self.c.execute("""update collection_scope_reviews set allowed_keywords='["newword"]'""")
  self.c.execute("update collection_event_reviews set response_sha256='wrong'")
  self.assertIsNotNone(effective_halt(self.c,'a','newscan'))

 def test_exact_event_review_only(self):
  import hashlib
  response=json.dumps({'ok':False,'transport_error':'request_timeout','transport_meta':{'stage':'business'}})
  self.c.execute('insert into collection_halt_events values(?,?,?,?,?)',('a','timeout','unknown','transport','3'))
  self.c.execute('insert into attempts values(?,?,?,?,?)',('timeout','unknown',0,json.dumps({'account_uid':'a','scan_id':'previous','target':'badword','keyword':'badword'}),response))
  self.c.execute('insert into collection_event_reviews values(?,?,?,?,?,?,?)',('a','newscan','timeout',hashlib.sha256(response.encode()).hexdigest(),'explicit user resume','same account page and identity verified','4'))
  self.assertIsNone(effective_halt(self.c,'a','newscan',{'kind':'search','keyword':'newword','target':'newword'}))
  self.assertIsNotNone(effective_halt(self.c,'a','previous'))
  self.assertIsNotNone(effective_halt(self.c,'a','newscan',{'kind':'search','keyword':'badword','target':'badword'}))
  self.c.execute('insert into collection_halt_events values(?,?,?,?,?)',('a','future','unknown','transport','5'))
  self.assertEqual(effective_halt(self.c,'a','newscan')['request_id'],'future')
  self.c.execute("delete from collection_halt_events where request_id='future'")
  self.c.execute("update attempts set response=? where request_id='timeout'",(json.dumps({'ok':True,'value':{'status_code':2147}}),))
  self.assertIsNotNone(effective_halt(self.c,'a','newscan'))

 def test_confirmation_uses_current_id_and_leaves_verification_evidence(self):
  spec={'account_uid':'a','scan_id':'oldscan','kind':'search','target':'oldword','keyword':'oldword'}
  response={'ok':True,'value':{'search_nil_info':{'search_nil_type':'verify_check'}}}
  self.c.execute("update attempts set state='verification_required',spec=?,response=?",
                 (json.dumps(spec),json.dumps(response)))
  self.c.execute("update account_halts set state='verification_required'")
  self.c.commit()
  plan={'account_uid':'a','scan_id':'oldscan','stores':[{'keywords':['oldword','fresh']}]}
  with TemporaryDirectory() as tmp:
   path=Path(tmp)/'local.sqlite3'
   copy=sqlite3.connect(path)
   self.c.backup(copy)
   copy.close()
   with self.assertRaises(ValueError):
    prepare_scope(path,plan,'stale','resumed','user confirmation','identity.json')
   new,evidence=prepare_scope(path,plan,'old','resumed','user confirmation','identity.json')
   self.assertEqual(new['stores'][0]['keywords'],['fresh'])
   self.assertEqual(evidence['excluded_target'],'oldword')
   copy=sqlite3.connect(path);copy.row_factory=sqlite3.Row
   try:
    self.assertIsNotNone(effective_halt(copy,'a','oldscan'))
    self.assertIsNone(effective_halt(copy,'a','resumed',{'kind':'search','keyword':'fresh','target':'fresh'}))
    self.assertIsNotNone(effective_halt(copy,'a','resumed',{'kind':'search','keyword':'oldword','target':'oldword'}))
    self.assertEqual(json.loads(copy.execute("select response from attempts where request_id='old'").fetchone()[0]),response)
   finally:
    copy.close()

if __name__=='__main__':unittest.main()
