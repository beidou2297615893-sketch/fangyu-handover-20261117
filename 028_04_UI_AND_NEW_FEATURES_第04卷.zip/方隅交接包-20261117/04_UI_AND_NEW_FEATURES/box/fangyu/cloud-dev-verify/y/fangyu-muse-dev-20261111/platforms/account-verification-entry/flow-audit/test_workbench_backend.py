"""Public dispatch behavior with the existing integration's outbound transport fixture."""
import importlib
import concurrent.futures
import sys
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project')
SOURCE = ROOT / 'work/ui-runtime-r55/src'
sys.path.insert(0, str(SOURCE))
sys.path.insert(0, str(Path(__file__).resolve().parent))


class LegacyCloudFixture:
    def __init__(self):
        self.calls = []
        self.user = {'username': 'fixture-employee', 'role': 'operator',
                     'disabled': False, 'can_reply': False, 'store_id': 'fixture-store-a'}
        self.revoked = False
        self.logout_fails = False
        self.transient_failure = False

    def __call__(self, url, payload, token=''):
        operation = payload['operation']
        self.calls.append(operation)
        from integrations import IntegrationError
        if operation not in ('login', 'me', 'logout'):
            raise AssertionError('Unexpected cloud operation: ' + operation)
        if self.revoked and operation != 'logout':
            error = IntegrationError('fixture-session-revoked')
            error.http_status = 401
            raise error
        if self.transient_failure and operation == 'me':
            raise IntegrationError('fixture-temporary-connection-timeout')
        if self.logout_fails and operation == 'logout':
            raise IntegrationError('fixture-logout-response-lost')
        if operation == 'login' and (payload['username'] != self.user['username']
                                     or payload['password'] != 'fixture-password-123'):
            raise IntegrationError('账号或密码错误')
        value = {'contract': 'fangyu-workspace-v1', 'company_id': 'fangyu-apartment-client',
                 'environment_id': 'fixture-env', 'user': dict(self.user)}
        if operation == 'login':
            value.update(token='fixture-cloud-access', expires=time.time() + 3600)
        return value


class BackendBehavior(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(dir=ROOT / 'work')
        self.fixture = CloudFixture()
        self.outbound = patch('integrations.request_json', side_effect=self.fixture)
        self.outbound.start()
        self.module = importlib.import_module('workbench_backend')
        self.company = {'id': 'fangyu-apartment-client', 'name': '方隅测试',
                        'edition': 'customer', 'personalMode': False, 'authMode': 'managed',
                        'managedWorkspace': {'environment_id': 'fixture-env',
                                             'endpoint': 'https://example.invalid/workspace'}}
        self.backends = []
        self.backend = self.open_backend()

    def tearDown(self):
        for backend in self.backends:
            backend.close()
        self.outbound.stop()
        self.temp.cleanup()

    def open_backend(self):
        backend = self.module.WorkbenchBackend(ROOT, data_dir=self.temp.name, company=self.company)
        self.backends.append(backend)
        return backend

    def login(self):
        return self.backend.dispatch('login', {'username': 'fixture-employee',
            'password': '[REDACTED:assigned_secret]', 'rememberUsername': True})

    def test_employee_applies_preset_and_reopen_restores_selection(self):
        self.assertIsNone(self.backend.dispatch('bootstrap', {})['session'])
        logged = self.login()
        self.assertEqual(logged['stores'][0]['id'], 'fixture-store-a')
        applied = self.backend.dispatch('apply_preset', {
            'storeId': 'fixture-store-a', 'searchPresetId': 'commute',
            'intentPresetId': 'recent', 'expectedRevision': logged['selection']['revision']},
            logged['token'])
        self.assertEqual(applied['selection']['searchPresetId'], 'commute')
        self.assertEqual(applied['selection']['intentPresetId'], 'recent')
        self.assertEqual(applied['selection']['revision'], 1)
        reopened = self.open_backend().dispatch('bootstrap', {}, logged['token'])
        self.assertEqual(reopened['selection'], applied['selection'])
        self.assertEqual(reopened['rememberedUsername'], 'fixture-employee')
        self.assertEqual(set(self.fixture.calls), {'login', 'me'})

    def test_logout_closes_local_session_even_if_cloud_response_is_lost(self):
        logged = self.login()
        self.fixture.logout_fails = True
        result = self.backend.dispatch('logout', {}, logged['token'])
        self.assertIsNone(result['session'])
        self.assertIsNone(self.backend.dispatch('bootstrap', {}, logged['token'])['session'])
        self.assertIn('本机', result['notice'])

    def test_explicit_empty_existing_keyword_selection_stays_empty(self):
        logged = self.login()
        user = self.backend.core.session(logged['token'])
        self.backend.workflow.keyword_state(user, {'mode': 'save', 'city': '测试市',
            'area': '测试区', 'expected_revision': 0, 'keywords': ['fixture-word'], 'selected': []})
        boot = self.backend.dispatch('bootstrap', {}, logged['token'])
        precise = next(row for row in boot['catalog']['search'] if row['id'] == 'precise')
        self.assertEqual(precise['keywords'], [])
        self.assertEqual(precise['source'], 'existing_keyword_selection')

    def apply(self, token, **changes):
        payload = {'storeId': 'fixture-store-a', 'searchPresetId': 'precise',
                   'intentPresetId': 'standard', 'expectedRevision': 0, **changes}
        return self.backend.dispatch('apply_preset', payload, token)

    def test_anonymous_or_expired_session_cannot_apply(self):
        with self.assertRaises(self.module.WorkbenchError) as caught:
            self.apply('')
        self.assertEqual(caught.exception.code, 'AUTH_REQUIRED')
        logged = self.login()
        self.backend.core.handle('logout', {'token': logged['token']})
        with self.assertRaises(self.module.WorkbenchError) as caught:
            self.apply(logged['token'])
        self.assertEqual(caught.exception.status, 401)

    def test_cloud_revocation_rechecks_authority_before_write(self):
        logged = self.login()
        self.fixture.revoked = True
        with self.assertRaises(self.module.WorkbenchError) as caught:
            self.apply(logged['token'])
        self.assertEqual(caught.exception.code, 'AUTH_REQUIRED')
        self.assertIsNone(self.backend.dispatch('bootstrap', {}, logged['token'])['session'])
        self.fixture.revoked = False
        restored = self.backend.dispatch('bootstrap', {}, logged['token'])
        self.assertEqual(restored['selection']['revision'], 0)

    def test_cross_store_request_cannot_change_selection(self):
        logged = self.login()
        for action, payload in [('select_store', {'storeId': 'fixture-store-b'}),
                ('apply_preset', {'storeId': 'fixture-store-b', 'searchPresetId': 'precise',
                                  'intentPresetId': 'standard', 'expectedRevision': 0})]:
            with self.assertRaises(self.module.WorkbenchError) as caught:
                self.backend.dispatch(action, payload, logged['token'])
            self.assertEqual(caught.exception.code, 'STORE_FORBIDDEN')
        boot = self.backend.dispatch('bootstrap', {}, logged['token'])
        self.assertEqual(boot['selection'], logged['selection'])

    def test_unassigned_employee_gets_no_demo_stores(self):
        self.fixture.user.pop('store_id')
        logged = self.login()
        self.assertEqual(logged['stores'], [])
        self.assertFalse(logged['capabilities']['presets'])
        self.assertEqual(logged['selection']['storeId'], '')
        with self.assertRaises(self.module.WorkbenchError):
            self.apply(logged['token'])

    def test_store_change_drops_stale_applied_preference(self):
        logged = self.login()
        self.apply(logged['token'])
        self.fixture.user['store_id'] = 'fixture-store-b'
        changed = self.backend.dispatch('bootstrap', {}, logged['token'])
        self.assertEqual([row['id'] for row in changed['stores']], ['fixture-store-b'])
        self.assertEqual(changed['selection']['storeId'], 'fixture-store-b')
        self.assertIsNone(changed['selection']['applied'])
        with self.assertRaises(self.module.WorkbenchError) as caught:
            self.apply(logged['token'], expectedRevision=1)
        self.assertEqual(caught.exception.code, 'STORE_FORBIDDEN')

    def test_concurrent_same_revision_has_one_commit(self):
        logged = self.login()
        other = self.open_backend()
        payload = {'storeId': 'fixture-store-a', 'searchPresetId': 'precise',
                   'intentPresetId': 'standard', 'expectedRevision': 0}
        def write(backend):
            try:
                return backend.dispatch('apply_preset', payload, logged['token'])['selection']['revision']
            except self.module.WorkbenchError as exc:
                return exc.code
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            answers = list(pool.map(write, [self.backend, other]))
        self.assertCountEqual(answers, [1, 'PRESET_REVISION_CONFLICT'])
        self.assertEqual(self.backend.dispatch('bootstrap', {}, logged['token'])['selection']['revision'], 1)

    def test_existing_keyword_selection_and_policy_are_referenced_without_rewrite(self):
        logged = self.login()
        user = self.backend.core.session(logged['token'])
        library = self.backend.workflow.keyword_state(user, {'mode': 'save', 'city': '测试市',
            'area': '测试区', 'expected_revision': 0, 'keywords': ['fixture-first', 'fixture-second'],
            'selected': ['fixture-second']})['library']
        before = self.backend.rules_factory(self.backend.core, user['tenant_id'], user['username'],
                                           self.company).execute('intent_rules_get', {}, user)
        saved = self.apply(logged['token'], intentPresetId='recent')
        applied = saved['selection']['applied']
        self.assertEqual(applied['selectedKeywords'], ['fixture-second'])
        self.assertEqual(applied['libraryReference']['revision'], library['revision'])
        self.assertEqual(applied['policyReference']['revision'], before['summary']['revision'])
        self.assertFalse(applied['startsCollection'])
        self.assertFalse(applied['changesIntentPolicy'])
        after_library = self.backend.workflow.keyword_state(user, {'mode': 'read', 'city': '测试市', 'area': '测试区'})['library']
        self.assertEqual(after_library, library)
        after_policy = self.backend.rules_factory(self.backend.core, user['tenant_id'], user['username'],
                                           self.company).execute('intent_rules_get', {}, user)
        self.assertEqual(after_policy['summary']['digest'], before['summary']['digest'])
        self.assertEqual(after_policy['summary']['revision'], before['summary']['revision'])

    def test_admin_is_rejected_and_no_local_session_created(self):
        self.fixture.user['role'] = 'admin'
        with self.assertRaises(self.module.WorkbenchError) as caught:
            self.login()
        self.assertEqual(caught.exception.code, 'EMPLOYEE_ONLY')
        self.assertIsNone(self.backend.dispatch('bootstrap', {})['session'])
        self.assertEqual(self.backend.dispatch('bootstrap', {})['rememberedUsername'], '')

    def test_no_route_allows_platform_ai_or_rule_writes(self):
        logged = self.login()
        count = len(self.fixture.calls)
        for action in ('run_task', 'send_reply', 'intent_rules_save', 'keyword_recommend', 'member_save', 'bootstrap_admin'):
            with self.assertRaises(self.module.WorkbenchError) as caught:
                self.backend.dispatch(action, {}, logged['token'])
            self.assertEqual(caught.exception.status, 403)
        self.assertEqual(len(self.fixture.calls), count)

    def test_remember_username_can_be_cleared_and_responses_contain_no_credentials(self):
        logged = self.login()
        logged.pop('token')
        response_text = str(logged)
        for secret in ('fixture-password-123', 'fixture-cloud-access', 'password_hash', 'refresh_token'):
            self.assertNotIn(secret, response_text)
        second = self.backend.dispatch('login', {'username': 'fixture-employee',
            'password': '[REDACTED:assigned_secret]', 'rememberUsername': False})
        self.assertEqual(second['rememberedUsername'], '')
        self.assertEqual(self.open_backend().dispatch('bootstrap', {})['rememberedUsername'], '')

    def test_input_does_not_accept_role_tenant_or_rule_overrides(self):
        logged = self.login()
        for forbidden in ('role', 'tenant_id', 'policy', 'password'):
            with self.assertRaises(self.module.WorkbenchError) as caught:
                self.backend.dispatch('select_store', {'storeId': 'fixture-store-a', forbidden: 'x'}, logged['token'])
            self.assertEqual(caught.exception.code, 'INPUT_INVALID')

    def test_backend_open_does_not_recover_existing_business_states(self):
        fixtures = [('tasks', {'id': 'fixture-task', 'tenant_id': 'fixture-tenant',
                              'sequence_status': 'running'}),
                    ('replies', {'id': 'fixture-reply', 'tenant_id': 'fixture-tenant',
                                 'status': 'sending'}),
                    ('reply_queues', {'id': 'fixture-queue', 'tenant_id': 'fixture-tenant',
                                     'status': 'running', 'reviewed': True, 'pid': 99999999}),
                    ('continuous_tasks', {'id': 'fixture-continuous', 'tenant_id': 'fixture-tenant',
                                          'status': 'running', 'pid': 99999999})]
        for entity, row in fixtures:
            self.backend.core.store.put(entity, row)
        reopened = self.open_backend()
        reopened.dispatch('bootstrap', {})
        for entity, row in fixtures:
            self.assertEqual(reopened.core.store.get(entity, row['id']), row)
        self.assertFalse(reopened.core.continuous.autostart)
        self.assertFalse(reopened.core.reviewed_reply_queues.autostart)

    def test_temporary_cloud_failure_preserves_session_and_reports_unavailable(self):
        logged = self.login()
        self.fixture.transient_failure = True
        for action, payload in [('bootstrap', {}), ('apply_preset', {
                'storeId': 'fixture-store-a', 'searchPresetId': 'precise',
                'intentPresetId': 'standard', 'expectedRevision': 0})]:
            with self.assertRaises(self.module.WorkbenchError) as caught:
                self.backend.dispatch(action, payload, logged['token'])
            self.assertEqual(caught.exception.code, 'AUTH_SERVICE_UNAVAILABLE')
            self.assertEqual(caught.exception.status, 503)
            self.assertIsNotNone(self.backend.core.session(logged['token']))
        self.fixture.transient_failure = False
        recovered = self.backend.dispatch('bootstrap', {}, logged['token'])
        self.assertEqual(recovered['session']['user']['username'], 'fixture-employee')
        self.assertEqual(recovered['selection']['revision'], 0)


if __name__ == '__main__':
    unittest.main()

class CloudFixture(LegacyCloudFixture):
    """Only the external directory fixture is updated for the central contract."""
    def __call__(self,url,payload,token=''):
        if payload['operation']!='store_config_read':return super().__call__(url,payload,token)
        import copy,json,hashlib
        response=super().__call__(url,{**payload,'operation':'me'},token)
        compiled=json.loads(Path('C:/积木软件工坊/项目/方隅公寓客户版/work/central-store-config/compiled-fixture.json').read_text('utf-8-sig'))
        base=next(r['config'] for r in compiled['documents'] if r.get('doc_type')=='store_config_version')
        digest=lambda v:hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
        configs={k:{**copy.deepcopy(base),'store_id':k} for k in ('fixture-store-a','fixture-store-b')}
        allowed=list(configs) if self.user['role']=='admin' else [self.user.get('store_id','fixture-store-a')]
        rows=[{'id':k,'name':'合成门店 '+k,'materialKey':configs[k]['material_key'],'config_digest':digest(configs[k])} for k in allowed if k in configs]
        response.update(schema='store-config-v1',read_only=True,catalog_revision='synthetic-central-v1',catalog_digest='a'*64,actor={'username':self.user['username'],'role':self.user['role']},scope={'type':'company' if self.user['role']=='admin' else 'store','store_ids':[r['id'] for r in rows]},stores=rows)
        if payload.get('store_id'):
            k=payload['store_id'];response.update(store_id=k,config=configs[k],config_digest=digest(configs[k]))
        return response
