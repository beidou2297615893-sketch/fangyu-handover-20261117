"""Read-only source inventory; never opens customer config or runtime data."""
from pathlib import Path
import hashlib
import json
import re

SOURCE = Path(r"C:/积木软件工坊/项目/方隅公寓客户版/work/app/src")
OUTPUT = Path(__file__).resolve().parent

PORTABLE_CORE = [
    "core/store.py", "core/engine.py", "core/selection.py", "core/pipeline.py",
    "core/account_safety.py", "core/backups.py", "core/contact_journal.py",
    "core/response_journal.py",
    "core/continuous.py", "core/douyin_pages.py", "core/page_errors.py",
    "core/review_queue.py", "core/runtime_guards.py", "core/entitlements.py",
    "core/adapters.py", "core/wechat_channels.py", "core/__init__.py",
    "assistant/customer_list.py", "assistant/lead_groups.py", "assistant/saved_media.py",
    "assistant/ai_workflow.py", "assistant/ai_worker.py", "assistant/business.py",
    "assistant/customer_response_monitor.py", "assistant/login_outcome.py",
    "assistant/login_natural_identity.py", "assistant/login_natural_proof.py",
    "assistant/browser_login_service.py", "assistant/browser_session_commit.py",
    "assistant/owned_webview2_cookies.py", "assistant/browser_login_coordinator.py",
    "assistant/browser_login_window.py", "assistant/__init__.py",
    "bridge.py", "account_browser.py", "account_connections.py",
    "wechat_channels_connection.py", "platform_cli.py", "desktop.py",
    "ui_customization.py",
]
UI = [f"web/workspace/{name}" for name in [
    "index.html", "site.css", "app.mjs", "enterprise-ui.mjs",
    "enterprise-model.mjs", "customer-ui.mjs", "customer-ui.css",
    "platform-account.mjs", "platform-account.css", "collection-progress.mjs",
    "collection-progress.css", "contact-verification.mjs", "local-transport.mjs",
    "transport.mjs", "gsap.min.js",
]]
PREFIXES = ("core/", "assistant/", "web/workspace/")
SKIP_PARTS = {"__pycache__", "node_modules"}
TEXT_SUFFIXES = {".py", ".js", ".mjs", ".cjs", ".css", ".html", ".json"}
PATTERNS = {
    "customer_identity": r"fangyu-apartment-client|fangyu-workspace-v1|方隅|方渔",
    "industry_coupling": r"apartment|租房|求租|租客|招租|房东",
    "absolute_local_path": r"(?:[A-Za-z]:[\\/]|C:/|C:\\\\)",
    "cloud_environment_reference": r"environment_id|environmentId|tencent|tcb|cloudbase|\.apigw\.",
}

def record(relative, purpose):
    path = SOURCE / relative
    if not path.is_file():
        return None
    return {"path": relative, "bytes": path.stat().st_size,
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "purpose": purpose}

def main():
    entries = []
    for relative in sorted(set(PORTABLE_CORE)):
        row = record(relative, "candidate_reuse_requires_dependency_and_policy_review")
        if row:
            entries.append(row)
    for relative in UI:
        row = record(relative, "latest_four_page_UI_requires_brand_and_transport_parameterization")
        if row:
            entries.append(row)
    for path in sorted((SOURCE / "resources" / "licenses").glob("*")):
        if path.is_file():
            row = record(path.relative_to(SOURCE).as_posix(), "retain_license_and_provenance_only")
            entries.append(row)
    for path in sorted((SOURCE / "web" / "workspace" / "assets").glob("*")):
        if path.is_file() and (path.name.startswith("tabler-") or path.name.startswith("platform-")):
            row = record(path.relative_to(SOURCE).as_posix(), "generic_or_platform_icon")
            entries.append(row)
    findings = []
    for path in sorted(SOURCE.rglob("*")):
        if not path.is_file() or path.suffix not in TEXT_SUFFIXES or set(path.parts) & SKIP_PARTS:
            continue
        relative = path.relative_to(SOURCE).as_posix()
        if not relative.startswith(PREFIXES) and path.parent != SOURCE:
            continue
        content = path.read_text(encoding="utf-8", errors="replace")
        # Report location only. Never print literal URLs, paths, customer text, or credential-looking values.
        for kind, pattern in PATTERNS.items():
            hits = sorted({content.count("\n", 0, match.start()) + 1 for match in re.finditer(pattern, content)})
            if hits:
                findings.append({"path": relative, "kind": kind, "line_count": len(hits), "lines": hits[:15]})
    result = {
        "source": str(SOURCE), "read_only": True,
        "forbidden_inputs_not_opened": ["company.json", "data/**", "runtime sessions", "private-backup/**", "cloud credentials"],
        "candidate_files": entries,
        "not_a_drop_in_build": True,
        "sanitization_findings": findings,
        "must_exclude": ["data/**", "**/__pycache__/**", "work/runtime/** sessions and credentials",
                         "company.json", "客户定制/** (customer config)", "private-backup/**", "outputs/**",
                         "native company logo and customer/apartment photos", "cloud environment IDs and bindings",
                         "release approval/QA/device IDs", "signed update roots and local permits"],
    }
    OUTPUT.mkdir(parents=True, exist_ok=True)
    (OUTPUT / "source-whitelist-and-sanitization.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    summary = {"candidate_count": len(entries), "source_files_flagged": len({f["path"] for f in findings}),
               "findings_by_kind": {kind: sum(f["line_count"] for f in findings if f["kind"] == kind) for kind in PATTERNS},
               "output": str(OUTPUT / "source-whitelist-and-sanitization.json")}
    print(json.dumps(summary, ensure_ascii=False))

if __name__ == "__main__":
    main()
