from pathlib import Path
T=Path(__file__).resolve().parent;S=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project')
body=(T/'implement.py').read_text('utf-8');start=body.index("f='work/ui-approved-implementation/ui-preview/app.mjs'")
def edit(f,old,new):
 p=S/f;b=p.read_text('utf-8');assert b.count(old)==1,(f,old[:80],b.count(old));p.write_text(b.replace(old,new),'utf-8')
import json
files=json.loads((T/'CHANGED.json').read_text('utf-8'))
exec(compile(body[start:],str(T/'implement.py'),'exec'),globals())
