from pathlib import Path
import os,re,shutil,json,hashlib,zipfile
K=Path('C:/积木软件工坊/项目/方隅公寓客户版')
R=Path('C:/Users/rmsama/Documents/ChatGPT/自动获客系统')
W=K/'work/cloud-dev-package-20261111'
OUT=K/'outputs/Linux云端开发工程'
ROOT=OUT/'fangyu-cloud-dev'
ROOT.mkdir(parents=True,exist_ok=True)
old=K/'outputs/软件完整交接/方隅软件交接包'
deny={'node_modules','.git','.venv','venv','__pycache__','site-packages','profiles','sessions','state','data','logs','backups','backup'}
allowed={'.py','.js','.cjs','.mjs','.ts','.tsx','.jsx','.html','.css','.json','.sql','.md','.txt','.toml','.yaml','.yml','.svg','.png','.jpg','.jpeg','.webp','.ico','.woff','.woff2','.ttf','.map','.sh','.ps1','.cmd','.bat'}
suspect=re.compile(r'(^\.env|cookie.*\.(json|txt)$|credential|production-workspace|storage.?state|auth-state|session-state|token.*\.json$)',re.I)
secret=re.compile(r'sk-[A-Za-z0-9_-]{20,}|Bearer\s+[A-Za-z0-9._-]{24,}|(?:api_key|access_token|refresh_token|password|cookie)\s*[=:]\s*[\x22\x27][A-Za-z0-9/+=._%-]{20,}[\x22\x27]',re.I)
entries=[]
def copytree(src,dst):
    if not src.exists():return
    for current,dirs,files in os.walk(src,followlinks=False):
        dirs[:]=[d for d in dirs if d.lower() not in deny and not (Path(current)/d).is_symlink()]
        for name in files:
            p=Path(current)/name;rel=p.relative_to(src);reason=None
            if p.suffix.lower() not in allowed:reason='platform_binary_or_unselected_type'
            elif suspect.search(name):reason='credential_or_production_binding'
            elif p.is_symlink():reason='link'
            elif p.stat().st_size>15*1024*1024:reason='large_file'
            else:
                raw=p.read_bytes()
                if p.suffix.lower() in {'.py','.js','.cjs','.mjs','.json','.md','.txt','.yaml','.yml','.toml','.ps1','.sh'} and secret.search(raw.decode('utf-8-sig',errors='replace')):reason='possible_embedded_secret'
                else:
                    target=dst/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
                    entries.append({'file':str(target.relative_to(ROOT)),'source':str(p),'sha256':hashlib.sha256(raw).hexdigest()});continue
            entries.append({'source':str(p),'excluded':reason})
# Preserve the reviewed handoff, including the authorized consistent business ledger snapshot.
shutil.copytree(old,ROOT/'handoff',dirs_exist_ok=True)
copytree(K/'work/integration-20261111/backend',ROOT/'project/backend')
baseline=K/'work/combined-full-candidate-20261027/project'
release=baseline/'work/ui-native-r57/releases/ui-r57-20261027T130512Z-a9ba360f'
copytree(release/'web',ROOT/'project/frontend')
copytree(release,ROOT/'project/windows-release-source')
copytree(baseline/'work/ui-runtime-r55/src',ROOT/'project/desktop-core')
copytree(R/'src',ROOT/'project/original-core/src')
copytree(R/'tests',ROOT/'project/original-core/tests')
copytree(R/'tools',ROOT/'project/original-core/tools')
copytree(K/'outputs/简洁无小字界面',ROOT/'designs/最新三屏待图审')
copytree(K/'outputs/暖色公寓简洁界面',ROOT/'designs/暖色浮窗与参考')
copytree(W/'tools',ROOT/'tools')
for name in ['README.md','requirements-dev.txt']:
    if (W/name).exists():shutil.copy2(W/name,ROOT/name)
(ROOT/'SOURCE-STATUS.md').write_text('前端project/frontend是原工作台可编辑静态源码，最新designs样图尚未实现。project/backend是11月11日独立候选。windows-release-source及desktop-core是供参考改造的Windows宿主来源，不是已准入完整可执行发布包。Linux仅验证离线模块和静态页面；pywebview/WebView2与真实平台需回Windows后另验。handoff含用户授权业务账本快照，不能替代最新生产库、凭据或新发送授权。',encoding='utf-8')
(ROOT/'source-copy-manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'root':str(ROOT),'copied':sum('file'in r for r in entries),'excluded':sum('excluded'in r for r in entries)},ensure_ascii=False))
