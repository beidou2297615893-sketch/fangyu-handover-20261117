"""Compare historical outcomes with a blind AI reviewer; no personal text.

The reference class concerns evidence at comment time; the historical result
also takes current demand status into account. Mismatches are therefore not
automatically errors. This is not a human-confirmed accuracy evaluation.
"""
from pathlib import Path
from collections import Counter, defaultdict
import hashlib
import json
import sys

HERE = Path(__file__).resolve().parent
TASK = HERE.parent

def read(path):
    raw = path.read_bytes()
    return json.loads(raw.decode('utf-8-sig')), hashlib.sha256(raw).hexdigest()

def main():
    labels, label_hash = read(TASK / 'blind_agent_labels.json')
    if labels.get('humanConfirmed') is not False or labels.get('blinded_to_predictions') is not True:
        raise ValueError('Unexpected review provenance: refusing to claim blinded AI reference')
    label_index = {}
    for row in labels['labels']:
        if row['sample'] in label_index:
            raise ValueError('Duplicate label sample')
        if row['expected_evidence_class'] not in {'positive', 'no_evidence', 'supply', 'uncertain'}:
            raise ValueError('Unknown reference category')
        label_index[row['sample']] = row
    expected_hash = {row['file']: row['sha256'] for row in labels['source_files']}
    groups = {}
    seen = set()
    for kind in ('blind_sample', 'blind_challenge'):
        baseline, digest = read(HERE / (kind + '-baseline-mapped.json'))
        if not baseline.get('integrity_pass'):
            raise ValueError('Baseline map integrity failed')
        if expected_hash.get(kind + '.json') != baseline['source_sha256']['blind_sample']:
            raise ValueError('Blind labels and baseline refer to different sample bytes')
        table = defaultdict(Counter)
        mismatches = []
        n = Counter()
        for row in baseline['rows']:
            sample = row['sample']
            if sample in seen or sample not in label_index:
                raise ValueError('Sample collision or missing reference')
            seen.add(sample)
            ref = label_index[sample]['expected_evidence_class']
            old = row['baseline_customer']['status']
            if old == 'graded': pred = 'positive'
            elif old == 'unrelated': pred = 'no_evidence_or_supply'
            elif old == 'uncertain': pred = 'abstain'
            else: raise ValueError('Unknown baseline status')
            table[ref][pred] += 1
            n['total'] += 1
            if ref == 'uncertain':
                n['reference_uncertain'] += 1
                continue
            n['clear_reference'] += 1
            if pred == 'abstain':
                n['baseline_abstained_on_clear'] += 1
                continue
            n['baseline_decisive_on_clear'] += 1
            actual = ref == 'positive'
            predicted = pred == 'positive'
            if actual and predicted: n['tp'] += 1
            elif not actual and predicted: n['fp'] += 1
            elif actual and not predicted: n['fn'] += 1
            else: n['tn'] += 1
            if actual != predicted:
                mismatches.append({'sample': sample, 'reference_class': ref,
                                   'baseline_projection': pred,
                                   'baseline_demand_state': row['baseline_customer']['demandState']})
        groups[kind] = {
            'baseline_map_sha256': digest,
            'reference_by_baseline': {k: dict(table.get(k, {})) for k in ('positive','no_evidence','supply','uncertain')},
            'counts': dict(n),
            'decisive_agreement_ratio': (
                (n['tp'] + n['tn']) / n['baseline_decisive_on_clear']
                if n['baseline_decisive_on_clear'] else None),
            'positive_precision_among_decisive': n['tp'] / (n['tp'] + n['fp']) if n['tp'] + n['fp'] else None,
            'positive_recall_among_decisive': n['tp'] / (n['tp'] + n['fn']) if n['tp'] + n['fn'] else None,
            'disagreement_sample_ids_only': mismatches,
        }
    if seen != set(label_index):
        raise ValueError('Not all blinded labels mapped')
    result = {
        'limitations': [
            'Independent blinded AI reviewer, not human confirmed; reference classes are not ground truth.',
            'Reference asks whether a comment shows evidence at time of writing; historical classification also incorporates current demand. A disagreement may be a changed time scope, not a model error.',
            'Only predictions made on clearly referenced rows are compared. Abstentions are listed, not treated as negative or error.',
            'Challenge set is deliberately enriched and nonrepresentative; report separately from uniform sample.',
        ],
        'label_source_sha256': label_hash,
        'reviewer': labels['reviewer'],
        'human_confirmed': labels['humanConfirmed'],
        'groups': groups,
    }
    (HERE / 'blind-baseline-comparison.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    for kind, group in groups.items():
        print(kind, json.dumps({'reference_by_baseline': group['reference_by_baseline'], 'counts': group['counts']}, ensure_ascii=False))
    return 0

if __name__ == '__main__':
    sys.exit(main())
