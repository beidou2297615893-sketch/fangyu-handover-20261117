import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
const source=process.env.FANGYU_TEST_PROJECT||'C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project';
const {createDeviceReconnect}=await import(pathToFileURL(source+'/work/ui-approved-implementation/ui-preview/device-reconnect.mjs'));
const base=()=>({connection:'connected',user:'employee',session:{user:{username:'employee'}},storeId:'gubei',page:'acquire',busy:false,platform:{actor:{username:'employee',storeId:'gubei'},device:{bound:true,state:'offline'},acquisition:{status:'paused',phase:'analyzing',analysis:{status:'completed',pending:0}}}});
let calls=[];const s=base();const reconnect=createDeviceReconnect({state:s,prepare:async p=>calls.push(p),hasUnconfirmed:()=>false});
await reconnect();assert.deepEqual(calls,[{existingOnly:true}],'saved analysis must not prevent a pure device reconnect');
await reconnect();assert.equal(calls.length,1,'polls must not start duplicate reconnects');
for(const kind of ['wrong-actor','unbound','active-task','unconfirmed-business-action']){
 const state=base();if(kind==='wrong-actor')state.platform.actor.username='another';if(kind==='unbound')state.platform.device.bound=false;if(kind==='active-task')state.platform.acquisition.status='running';
 let count=0;const attempt=createDeviceReconnect({state,prepare:async()=>count++,hasUnconfirmed:()=>kind==='unconfirmed-business-action'});await attempt();assert.equal(count,0,kind);
}
const pending=base();pending.platform.acquisition.analysis={status:'unknown',pending:33,code:'AI_BILLING_UNKNOWN'};
let pendingCalls=0;await createDeviceReconnect({state:pending,prepare:async p=>{assert.deepEqual(p,{existingOnly:true});pendingCalls++;},hasUnconfirmed:()=>false})();
assert.equal(pendingCalls,1,'connection recovery must not replay or modify an unknown AI result');
// A process/page restart gets one recovery attempt; polls in that page do not.
await createDeviceReconnect({state:s,prepare:async p=>calls.push(p),hasUnconfirmed:()=>false})();
assert.equal(calls.length,2);
// A network failure releases the busy indicator and never asserts online or loops.
const offline=base();let failures=0;
const fail=createDeviceReconnect({state:offline,prepare:async()=>{failures++;throw new Error('network unavailable');},hasUnconfirmed:()=>false});
await assert.rejects(fail(),/network unavailable/);assert.equal(offline.deviceReconnecting,false);
assert.equal(offline.platform.device.state,'offline');await fail();assert.equal(failures,1);
// Switching platform accounts never starts a second device connection.
s.activePlatform='douyin';s.platformAccountSelections={xiaohongshu:'account-two'};
await reconnect();assert.equal(calls.length,2);
// A new authenticated employee requires matching actor and device ownership.
s.user='employee-two';s.session.user.username='employee-two';await reconnect();assert.equal(calls.length,2);
s.platform.actor.username='employee-two';await reconnect();assert.equal(calls.length,3);
assert.equal(s.platform.device.state,'offline','only a backend lease can assert online');
console.log(JSON.stringify({status:'PASS',oldAnalysisDoesNotBlockConnection:true,reconnectExistingOnly:true,noDuplicateCalls:true,identityAndActiveTaskGuards:true,unknownAnalysisNotReplayed:true,restart:true,networkFailure:true,accountSwitch:true,noFalseOnline:true}));
