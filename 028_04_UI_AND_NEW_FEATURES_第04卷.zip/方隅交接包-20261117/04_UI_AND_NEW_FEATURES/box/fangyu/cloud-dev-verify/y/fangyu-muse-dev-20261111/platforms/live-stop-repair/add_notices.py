from pathlib import Path
import json,hashlib
S=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project');T=Path(__file__).resolve().parent
rows=json.loads((T/'SOURCE-CHANGES.json').read_text('utf-8'));prefix='work/ui-approved-implementation/ui-preview/'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,body):
    p=S/prefix/name;row=next((r for r in rows if r['path']==prefix+name),None)
    if row is None:
        row={'path':prefix+name,'before':sha(p) if p.exists() else None};rows.append(row)
        if p.exists():
            b=T/'before'/prefix/name;b.parent.mkdir(parents=True,exist_ok=True);b.write_bytes(p.read_bytes())
    p.write_bytes(body.encode('utf-8'));row['after']=sha(p)
def rep(s,a,b):
    assert s.count(a)==1,(a[:80],s.count(a));return s.replace(a,b)
save('platform-notice.mjs',(T/'platform-notice.mjs').read_text('utf-8'))
p=S/prefix/'app.mjs';s=p.read_text('utf-8')
s="import {updatePlatformNotice,createCollectionMonitor} from './platform-notice.mjs';\n"+s
s=rep(s,'const paneScroll=createPaneScroll(app,()=>state);',"""const paneScroll=createPaneScroll(app,()=>state);
function showPlatformNotice(){updatePlatformNotice(state,document.getElementById('platform-notice-host'),id=>{
  if(id!==(state.activePlatform||'xiaohongshu'))switchPlatform(id);
  if(id===(state.activePlatform||'xiaohongshu'))navigate('accounts');
});}
const collectionMonitor=createCollectionMonitor({state,read:data=>backend.platform(data),changed:showPlatformNotice});""")
s=rep(s,'  state.platform=platform;queueMicrotask(', '  state.platform=platform;showPlatformNotice();collectionMonitor.sync();queueMicrotask(')
s=rep(s,'<div class="shell" data-current="${state.page}" data-platform="${activePlatform(state)}">','<div class="shell" data-current="${state.page}" data-platform="${activePlatform(state)}"><div id="platform-notice-host" class="platform-notice-host" hidden></div>')
s=rep(s,'  paneScroll.restore();\n  syncPlatformPolling();','  paneScroll.restore();\n  showPlatformNotice();collectionMonitor.sync();\n  syncPlatformPolling();')
save('app.mjs',s)
css=(S/prefix/'canvas-fit.css').read_text('utf-8')+'''
.platform-notice-host{position:fixed;top:70px;right:24px;width:min(470px,calc(100vw - 48px));z-index:65;display:grid;gap:10px}
.platform-notice-host[hidden]{display:none}
.platform-alert{display:flex;align-items:flex-start;gap:14px;padding:16px 18px;background:#fff6e8;color:#66401d;border:1px solid #e4c592;border-radius:10px;box-shadow:0 10px 30px #24374729}
.platform-alert strong{font-size:16px;line-height:1.5}.platform-alert p{font-size:13px;line-height:1.6;margin:5px 0 0}.platform-alert button{flex:0 0 auto;font-size:13px;line-height:1.5;padding:7px 10px;border:1px solid #b88542;border-radius:6px;background:#fffaf2;color:#714716;cursor:pointer}
.shell[data-platform=douyin] .platform-alert{background:#352e28;color:#ffdfb3;border-color:#806344}.shell[data-platform=douyin] .platform-alert button{background:#493a29;color:#ffe7c2;border-color:#967347}
'''
save('canvas-fit.css',css)
(T/'SOURCE-CHANGES.json').write_bytes((json.dumps(rows,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
print(json.dumps({'changed_files':len(rows),'new_feature':'persistent cross-page platform alert; background monitor never redraws editor'},ensure_ascii=False))
