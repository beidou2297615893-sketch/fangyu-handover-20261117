"""Bound-owner task/account flags and strict activity eligibility, no credential reads."""
from pathlib import Path
from datetime import datetime,timezone
import ast,hashlib,json,math,os,re,sqlite3,stat
from collections import Counter
P=Path('C:/积木软件工坊/项目/方隅公寓客户版')
S=P/'work/parallel-integration-20261018/final-integration/stage-02/project'
O=Path(__file__).resolve().parent
binding=json.loads((P/'work/ui-native-r57/state/production-workspace.json').read_text('utf-8'))
root=Path(binding['data_dir']);owner=binding['owner']
db=sqlite3.connect((root/'workspace.sqlite3').as_uri()+'?mode=ro',uri=True);db.execute('PRAGMA query_only=ON')
users=list(db.execute("SELECT json_extract(body,'$.tenant_id'),json_extract(body,'$.role') FROM records WHERE entity='users' AND json_extract(body,'$.username')=?",(owner,)));assert len(users)==1
tenant,role=users[0]
prefs=[json.loads(row[0]) for row in db.execute("SELECT body FROM records WHERE entity='ui_workbench_preferences_v1' AND tenant_id=? AND json_extract(body,'$.owner')=? AND json_extract(body,'$.company_id')=?",(tenant,owner,binding['company_id']))]
stores={p['storeId'] for p in prefs if p.get('storeId')};assert len(stores)==1;store=next(iter(stores))
tasks=[json.loads(row[0]) for row in db.execute("SELECT body FROM records WHERE entity='tasks' AND tenant_id=? AND json_extract(body,'$.cloud_owner')=? AND json_extract(body,'$.platform')='xiaohongshu'",(tenant,owner))]
tasks=[t for t in tasks if t.get('store_id') in (None,'',store) and (role!='admin' or t.get('store_id')==store)]
tasks.sort(key=lambda t:t.get('created_at',''),reverse=True);assert tasks
t=tasks[0];row=db.execute("SELECT body FROM records WHERE entity='accounts' AND tenant_id=? AND id=? AND json_extract(body,'$.cloud_owner')=?",(tenant,t['account_id'],owner)).fetchone();assert row
a=json.loads(row[0]);assert a['platform']=='xiaohongshu' and a.get('store_id') in (None,'',store)
db.close()
account=root/'accounts'/tenant/a['id'];assert account.resolve().is_relative_to(root.resolve())
def plain_dir(path):
    try:return path.is_dir() and not path.is_symlink() and not getattr(path.lstat(),'st_file_attributes',0)&0x400
    except OSError:return False
source=S/'work/ui-runtime-r55/src/core/xhs_identity_recovery.py';tree=ast.parse(source.read_text('utf-8-sig'))
wanted={'IdentityRecoveryError','digest','_plain','read_activity','rows_of','_receipt','scan_activity'}
nodes=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in wanted]
space={'Path':Path,'hashlib':hashlib,'json':json,'math':math,'os':os,'re':re,'stat':stat,'MAX_LOG':8*1024*1024,'_HEX':re.compile(r'[a-f0-9]{64}\Z'),'_ID':re.compile(r'[a-f0-9]{32}\Z')}
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(source),'exec'),space)
activity_path=account/'platform-activity.jsonl';raw,_=space['read_activity'](activity_path);scan=space['scan_activity'](raw);rows=[r for _,_,r in space['rows_of'](raw)]
recent=[r for r in rows if r.get('stage') in ('finished','cli_finished')][-12:]
pending_count=len(scan['pending']);nonrecoverable=sum(not value for _,value in scan['pending'])
rows_by_end={end:row for _,end,row in space['rows_of'](raw)}
blocked=Counter((rows_by_end[end].get('stage'),rows_by_end[end].get('kind'),str(rows_by_end[end].get('status'))) for end,recoverable in scan['pending'] if not recoverable)
report={'status':'READ_ONLY_OWNED_FLAGS_AND_RECOVERY_ELIGIBILITY','at_utc':datetime.now(timezone.utc).isoformat(),'scope':'bound owner + exact tenant + saved selected store; latest owned XHS task/account only','task':{'id':t['id'],'status':t.get('status'),'created_at_local':t.get('created_at'),'platform_error':{k:v for k,v in (t.get('last_platform_error') or {}).items() if k in ('code','kind','http_status','category')}},'account_flags':{'status':a.get('status'),'platform_uid_present':bool(a.get('platform_uid')),'disabled':a.get('disabled') is True,'identity_recovery_pending':bool(a.get('identity_recovery_pending')),'original_profile_exists_plain_directory':plain_dir(account/'xhs-browser-profile'),'CLI_session_file_exists':(account/'.xiaohongshu-cli/cookies.json').is_file(),'session_commit_marker_exists':(account/'.xiaohongshu-cli/.browser-session-commit.json').exists()},'strict_activity_scanner':{'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'total_events':len(rows),'pending':pending_count,'nonrecoverable_pending':nonrecoverable,'unfinished':len(scan['unfinished']),'resolution_count':scan['resolution_count'],'identity_attempt_activity_eligible':not scan['unfinished'] and pending_count>0 and nonrecoverable==0},'recent_activity_nonsecret_fields':[{k:r[k] for k in ('stage','kind','status','http_status','platform_code','exit_code') if k in r} for r in recent],'credential_file_contents_read':False,'real_platform_calls':0,'UI_operations':0,'production_writes':0,'DB_query_only':True}
report['strict_activity_scanner']['nonrecoverable_event_kinds']=[{'stage':key[0],'kind':key[1],'status':key[2],'count':count} for key,count in blocked.items()]
report['strict_activity_scanner']['unfinished_nonsecret_fields']=[{key:row.get(key) for key in ('kind','method','at')} for row in scan['unfinished'].values()]
(O/'OWNED-FLAGS.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8');print(json.dumps({'status':report['status'],'strict_activity_scanner':report['strict_activity_scanner']},ensure_ascii=False,indent=2))
