from pathlib import Path
import datetime,json,hashlib
T=Path(__file__).resolve().parent;P=Path('C:/积木软件工坊/项目/方隅公寓客户版');F=P/'work/parallel-integration-20261018/final-integration';N=P/'work/ui-native-r57'
read=lambda p:json.loads(p.read_text('utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest().upper()
plan=read(F/'entry-v48/CANONICAL-DELEGATION-PREPARED.json');actual=read(T/'ACTUAL-LATEST.json');fixture=read(F/'runtime-fixture-device-v48/STATUS.json')
assert sha(N/'run_workbench.py')==plan['launcher_sha256']
assert actual['live']['release']==plan['release_id']==actual['active']['release']==fixture['release']
assert fixture['status']=='PASS_FROZEN_MERGED_HTTP_FIXTURE'
assert sha(N/'state/production-workspace.json')==plan['workspace_binding_sha256']
report={'status':'FIX_INSTALLED_NATIVE_VERSION_VERIFIED_USER_CONFIRMED_REAL_COLLECTION_STARTED',
 'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'release':plan['release_id'],'changedSourceFiles':read(T/'CHANGED.json'),
 'customerOnly':True,'otherCustomerOrCoreOrSelfUseModified':False,'workspaceBindingUnchanged':True,
 'savedHistoryOrQueueRewritten':False,'realCommentOrMessageSendsByAgent':0,
 'userConfirmed':'已重开，连接恢复了','actualTask':actual['recentTasks'][0],'actualObservedAt':actual['at'],
 'actualWorkbenchAccessibility':{'url':'http://127.0.0.1:56519/canvas.html#acquire','status':'采集中 / 正在分析','taskCommentCount':33,'dailyNewCustomers':19,'dailyAnalyzedCustomers':17,'dailyHighIntentCustomers':1},
 'actualVisualScreenshotVerified':False,'actualAccessibilityVerified':True,
 'regression':{'reconnectRestartAndSavedAnalysis':'PASS','noDuplicatePollRequests':'PASS','networkFailureReleaseAndNoFalseOnline':'PASS simulated frontend prepare failure; no real network interruption',
 'accountSwitchAndActorGuards':'PASS','manualRetryUsesExistingOnly':'PASS','unknownAIReceiptProtection':'PASS',
 'analysisAdmission':'4 tests PASS','frozenBackendHTTP':'PASS synthetic external identity and comments',
 'closureFiles':2733,'nativeEntryCheckFiles':137},
 'notYetVerified':['End-to-end real disconnection and reconnection during a running batch','Another computer/customer installation','Real replies (manual only)','Full-batch completion and sustained collection rate'],
 'automaticPlatformRequestsStartedByAgent':False,'actualCollection':'User initiated from native workbench; independently observed SQLite and UI; no fabricated session',
 'restartRequired':False,'backup':str(F/'entry-v48/canonical-entry-before')}
(T/'FINAL.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8')
note=f'''# 电脑工作连接恢复修复与独立客户工作台交接

最新用户要求：Codex自用获客与交付客户的软件应分别成立，不能依赖逐次人工修补；只修客户版已有工程，不动其他客户/工坊核心/自用实例。回复本人手动，禁止自动发送。

本轮已完成：客户版v48 {plan['release_id']}；canonical launcher SHA {plan['launcher_sha256']}。四源文件列CHANGED.json，before保留v47原字节；entry-v48/canonical-entry-before可恢复旧入口；冻结candidate不可修改。2733闭包和137入口文件校验通过。

根因：旧暂停任务有33条本机页队列待分析，模型任务却已completed/pending0；UI把旧analysis phase/pending当成电脑连接恢复禁令，导致已经绑定的电脑在重开后无法启动控制面心跳。

修复契约：已有正确员工绑定可在获客/账号页面每个员工每次页面生命周期自动恢复一次existingOnly连接；只启用已有控制面心跳。设备/员工/门店scope、未确认业务操作与活动任务守卫保留；不绑定新设备、不平台重登、不自动续采、不重发AI。普通网络错误仍由既有心跳1至30秒退避恢复；新增明确人工重新连接入口，拒绝假报online。已确认模型完成且无code/pending、页队列仅pending且同task/tenant/owner时允许用户主动新批次；未知模型、计费、身份不一致仍拦截，旧记录一字不改。

固定回归：test_reconnect.mjs覆盖旧分析、页面重开、轮询不重连、账号切换、网络失败状态释放及不假报在线；test_connection_ui.mjs覆盖重连按钮、状态与existingOnly动作；test_analysis_admission.py四项覆盖已确认与未知分析接纳边界。可设FANGYU_TEST_PROJECT指向待交付candidate/project，对冻结源码运行同一测试。exact frozen host/backend/Core/HTTP/SQLite原回归仍通过（synthetic identity/comments，不算实采）。已有新版本更新需执行这些检查，不能只跑源码或只更改入口。

实际运行已验：active.json和真实loopback均为v48，instance {actual['active']['instanceId']}，PID {actual['active']['pid']}。用户明确回复“已重开，连接恢复了”。Computer Use已读取本机工作台56519的accessibility，获客页为采集中/正在分析；截图返回与目标窗口不一致，未采纳视觉截图，不可声称视觉验收。

真实采集已开始：用户自己从工作台启动新任务 {actual['recentTasks'][0]['id']}，古北店、小红书、采集账号仍为原选择；截至{actual['at']}，新任务{actual['recentTasks'][0]['commentCount']}条原评论/{actual['recentTasks'][0]['uniqueAuthors']}位唯一作者，{actual['recentTasks'][0]['analyzed']}条有分析结果。UI较数据库略早一帧显示33条评论、当天19位客户/17位分析/1位高意向；评论数、作者数、客户显示数和分析条目数不可混为一谈。未中断这批任务、未点击发送、未代做认证。

当前任务仍在推进，不需重启/重建/重复采集。后续先读ACTUAL-LATEST.json与FINAL.json再按需运行observe_actual.py，只读绑定库，不输出凭证/Cookie/私密评论。全批完成、真实断网恢复、其他电脑安装、回复发送均未验收，不冒充全功能或跨客户发布完成。原Gubei1—12个月规则和46词保留；公司云端模型提示词未因本轮改变。最新实际状态优先于10月17旧STATUS和过期夜间自动化。
'''
(T/'CONTINUE.md').write_text(note,'utf-8')
session=P/'memory/sessions/2026-10-21-device-connection-recovery-v48.md';session.write_text(note,'utf-8')
status=P/'memory/STATUS.md';marker='## 2026-10-21 客户版工作连接恢复 v48'
old=status.read_text('utf-8-sig')
if marker not in old:
 status.write_text(old+f'\n\n{marker}\n\n当前已安装并真实运行 {plan["release_id"]}。修复旧分析断点阻止纯设备连接恢复，增加existingOnly手动重连；未知结果/身份守卫及原断点保留。重开/账号切换/网络失败状态与冻结HTTP回归通过，137入口/2733闭包已核。用户已确认“已重开，连接恢复了”，本人启动的古北新任务已实采34条评论、20位作者；仍在采集，未自动发送。客户、自用、其他客户不互相覆盖。实际断网重连与其他电脑安装未验，不称全面交付。交接：memory/sessions/2026-10-21-device-connection-recovery-v48.md；证据：C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/device-connection-repair/FINAL.json。\n','utf-8')
print(json.dumps({'status':report['status'],'release':report['release'],'actualComments':report['actualTask']['commentCount'],'actualAuthors':report['actualTask']['uniqueAuthors'],'userConfirmed':True},ensure_ascii=False))
