# 对应账号网页验证与原任务继续：只读调查

结论：已有可复用的账号独立 WebView2 profile、窗口聚焦、人工验证后捕获、同UID核验与CLI会话提交链。可以在此基础上补员工按钮。现有SDK没有验证码直达URL；当前原任务继续还存在已ACK失败页永远返缓存的本地堵点，必须一起修，不能只增加打开网页按钮。

本轮未打开窗口、启动CLI、请求平台或模型，也未读取真实Cookie值、修改产品、写生产数据库。源码指纹与行号在 RESULT.json；隔离红样例在 audit_verification.py / RESUME-RED.json。

## 原验证码诊断提供什么

固定SDK client.py 的HTTP461/471分支只取响应头 verifytype / verifyuuid，生成 NeedVerifyError。该异常构造只生成 `Captcha required: type=<header>, uuid=<header>`，没有URL或response内容。原CLI formatter_utils.error_payload输出 ok:false/schema_version/error。不能凭UUID拼一个未经验证的验证码链接；泛461也不能据此认定验证码、掉线或必须扫码。

目前可确认的网页入口是固定 `https://www.xiaohongshu.com/explore`。它能打开原账号的网页环境，是否会直接呈现API刚返回的挑战124，本轮没有验证，源码也没有实现相应深链。

## 直接复用现有账号会话

1. `open_account_verification` 校验当前员工、租户、门店和账号UID，选择固定 `accounts/<tenant>/<account>/xhs-browser-profile`。没有原profile就明确不能冒称已复用，不能退回默认浏览器或新匿名会话。
2. 既有验证窗口按同owner/tenant/account筛选，重复点击发送focus.flag，不再开第二份profile。没有窗口时，固定helper以 `--keep-open --explicit-capture-only` 打开WebView2。
3. helper设置 `private_mode=False`，storage_path精确指向原账号profile；不自动提取登录候选，也不因为页面显示账号就继续采集。
4. 员工明确点击“验证完成，继续”后，可以复用 `_recover_xhs_identity`：给唯一登记的原窗口发capture.flag、取得新candidate、单次status取得当前UID、与原platform_uid严格比较，经原claim/commit提交。profile路径本身不是网页当前UID的证明；同UID校验必须成功。
5. `commit_identity_revalidation` 用事务/文件journal切换CLI会话，记录identity_revalidated并把账号置ready。candidate提交会改变auth_generation、identity_revalidation_generation、完整account_revision及通常的credential指纹；原活动风险只由已有严格身份回执解析，不追加人工“复核完成”假记录。

当前分派缺口：`connect_account` / `check_account` 只有 `_readiness` 返回account_review_required时才走 `_recover_xhs_identity`。当前 `_readiness` 已不再生成该码。新“验证完成并继续”动作应显式调用严格恢复链；不要为走到旧分支而恢复已撤销的本地人工复核锁，也不要普通account_status失败后循环重试。

## 原任务继续为何仍会堵住

`PageWorker.request` 对同task/scope/page的received或acknowledged回执，校验digest后直接返回原stdout/stderr/returncode，包括returncode=1的已知验证码失败。新worker不会忽略它。已有recover_unsent只恢复严格0-wire EOF，不处理已ACK验证码。

隔离红样例实际调用当前父PageWorker：旧已ACK验证码原页返回缓存；仅改变合成会话文件后创建新worker，仍返回相同失败。没有启动进程。unknown且wire_allow_attempts=1的原页仍拒绝，此边界正确。

现有scope由tenant/username/task id、账号六元组(id/tenant/cloud_owner/store/platform/platform_uid)、task binding生成；不含cookie、auth_generation或identity_revalidation_generation。因此正确的会话提交不会自然消除失败回执。cookie变化只会终止旧worker，新worker仍能命中原失败。

## 建议的最小新尝试接口

父`PageWorker(..., captcha_resume_grant=None)`接收内部可信grant；网页只传精确taskId并明确要求验证后继续，不接受网页传入URL、cookie、scope或“已验证=true”作为证明。

grant只在本次明确动作中、同UID网页candidate已成功commit后创建。至少绑定：

- tenant、owner、account、原UID、task id、原scope、page key、完整args_digest；
- 当前任务最后一份失败receipt的原字节SHA、result digest、operation；
- 新identity_revalidation_generation、提交后的完整account_revision与credential指纹；
- 短期限、唯一grant id、显式resume的请求幂等绑定。

`request`只有旧页received/acknowledged、returncode=1、原生失败envelope、严格非空type/uuid CAPTCHA匹配、无成功data，并且grant全匹配时，才允许生成一份新attempt。操作限原有只读search/comments/sub-comments。普通461、签名错误、传输错、未知结果、已有成功页、其他账号/任务/页一律不适用。

写入次序建议沿用现有fsync/CAS：先独占归档原失败字节并核hash，再持久新attempt、parent receipt SHA与grant已消费状态，之后才可授权第一条wire。原失败不删除、不修改成成功。崩溃后只根据新attempt的确切not_sent/unknown/received状态恢复；若新attempt已wire但未知，不得再借旧grant重发。新attempt再次被挑战，必须新一轮同UID验证generation及新的明确继续动作。

原页key刻意忽略access token，但args_digest不忽略。grant必须同时匹配两者，不能靠换token把未知页变成“新页”。如来源token真正失效，需要另有明确已知错误及原来源更新流程；本轮没有验证此情况。

## 交付时应明确的限度

这次只证明现有源码可复用接口与缓存失败堵点。没有证明打开探索页一定呈现原挑战，没有完成一次真实人工验证码，也没有在验证后发出原页新请求。实现后需先做隔离的grant一次性/跨账号/unknown/崩溃边界检查；员工真正验证后才可报告实际原任务续行结果。

## 候选修复后的独立增量审查

上面的只读调查与红样例描述修复前问题。根作者随后增加严格已验证续行grant；当前候选新增31项隔离行为全部通过，6个修改Python从实际保存字节编译通过，10个声明改动hash与当前实物一致。

实际验证的是新 verified_pages、captcha_receipt、PageWorker.request，以及从源码直接提取的runtime相关方法。接口使用合成账号/活动日志、假HOME和内存IPC事件，没有启动原CLI或浏览器，也没有平台/模型请求。原CLI本轮未修改、未重编。

严格验证包含：固定字符串schema_version="1"、ok=false、三键错误封包、两键error、重复JSON键/成功data/generic461拒绝；同UID/auth_generation与10分钟状态回执；未完成日志/新于验证的挑战拒绝；旧原页先归档再授权wire；原件及parent SHA保存；新结果重复读取不重发；新attempt的wire-unknown重启仍拒绝；再次挑战需要新验证；scope/task/args/credential/原件SHA/期限/协议保护；每wire核两项会话generation；本地返回丢失可复用已确认身份回执，无窗口时不会隐式开启或探测。

FINAL-REVIEW.json和INCREMENTAL-RESULT.json记录本次源码精确hash与验证范围。原RESUME-RED.json继续保留。没有实际完成人工验证码或继续真实任务；混杂、未完成和未知风险仍不放行，因此不能据隔离通过承诺当前真实账号必然可恢复。
