// Approved preparation card and two platform rows; existing actions own login and checks.
const escape=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const slots=[{id:'xiaohongshu',name:'小红书',aliases:['xhs','xiaohongshu'],description:'笔记与评论获客'},{id:'douyin',name:'抖音',aliases:['douyin','dy'],description:'视频与评论获客'}];
// The local authoring helper inserts the existing project's vector paths.
const brandPaths={xiaohongshu:'M22.405 9.879c.002.016.01.02.07.019h.725a.797.797 0 0 0 .78-.972.794.794 0 0 0-.884-.618.795.795 0 0 0-.692.794c0 .101-.002.666.001.777zm-11.509 4.808c-.203.001-1.353.004-1.685.003a2.528 2.528 0 0 1-.766-.126.025.025 0 0 0-.03.014L7.7 16.127a.025.025 0 0 0 .01.032c.111.06.336.124.495.124.66.01 1.32.002 1.981 0 .01 0 .02-.006.023-.015l.712-1.545a.025.025 0 0 0-.024-.036zM.477 9.91c-.071 0-.076.002-.076.01a.834.834 0 0 0-.01.08c-.027.397-.038.495-.234 3.06-.012.24-.034.389-.135.607-.026.057-.033.042.003.112.046.092.681 1.523.787 1.74.008.015.011.02.017.02.008 0 .033-.026.047-.044.147-.187.268-.391.371-.606.306-.635.44-1.325.486-1.706.014-.11.021-.22.03-.33l.204-2.616.022-.293c.003-.029 0-.033-.03-.034zm7.203 3.757a1.427 1.427 0 0 1-.135-.607c-.004-.084-.031-.39-.235-3.06a.443.443 0 0 0-.01-.082c-.004-.011-.052-.008-.076-.008h-1.48c-.03.001-.034.005-.03.034l.021.293c.076.982.153 1.964.233 2.946.05.4.186 1.085.487 1.706.103.215.223.419.37.606.015.018.037.051.048.049.02-.003.742-1.642.804-1.765.036-.07.03-.055.003-.112zm3.861-.913h-.872a.126.126 0 0 1-.116-.178l1.178-2.625a.025.025 0 0 0-.023-.035l-1.318-.003a.148.148 0 0 1-.135-.21l.876-1.954a.025.025 0 0 0-.023-.035h-1.56c-.01 0-.02.006-.024.015l-.926 2.068c-.085.169-.314.634-.399.938a.534.534 0 0 0-.02.191.46.46 0 0 0 .23.378.981.981 0 0 0 .46.119h.59c.041 0-.688 1.482-.834 1.972a.53.53 0 0 0-.023.172.465.465 0 0 0 .23.398c.15.092.342.12.475.12l1.66-.001c.01 0 .02-.006.023-.015l.575-1.28a.025.025 0 0 0-.024-.035zm-6.93-4.937H3.1a.032.032 0 0 0-.034.033c0 1.048-.01 2.795-.01 6.829 0 .288-.269.262-.28.262h-.74c-.04.001-.044.004-.04.047.001.037.465 1.064.555 1.263.01.02.03.033.051.033.157.003.767.009.938-.014.153-.02.3-.06.438-.132.3-.156.49-.419.595-.765.052-.172.075-.353.075-.533.002-2.33 0-4.66-.007-6.991a.032.032 0 0 0-.032-.032zm11.784 6.896c0-.014-.01-.021-.024-.022h-1.465c-.048-.001-.049-.002-.05-.049v-4.66c0-.072-.005-.07.07-.07h.863c.08 0 .075.004.075-.074V8.393c0-.082.006-.076-.08-.076h-3.5c-.064 0-.075-.006-.075.073v1.445c0 .083-.006.077.08.077h.854c.075 0 .07-.004.07.07v4.624c0 .095.008.084-.085.084-.37 0-1.11-.002-1.304 0-.048.001-.06.03-.06.03l-.697 1.519s-.014.025-.008.036c.006.01.013.008.058.008 1.748.003 3.495.002 5.243.002.03-.001.034-.006.035-.033v-1.539zm4.177-3.43c0 .013-.007.023-.02.024-.346.006-.692.004-1.037.004-.014-.002-.022-.01-.022-.024-.005-.434-.007-.869-.01-1.303 0-.072-.006-.071.07-.07l.733-.003c.041 0 .081.002.12.015.093.025.16.107.165.204.006.431.002 1.153.001 1.153zm2.67.244a1.953 1.953 0 0 0-.883-.222h-.18c-.04-.001-.04-.003-.042-.04V10.21c0-.132-.007-.263-.025-.394a1.823 1.823 0 0 0-.153-.53 1.533 1.533 0 0 0-.677-.71 2.167 2.167 0 0 0-1-.258c-.153-.003-.567 0-.72 0-.07 0-.068.004-.068-.065V7.76c0-.031-.01-.041-.046-.039H17.93s-.016 0-.023.007c-.006.006-.008.012-.008.023v.546c-.008.036-.057.015-.082.022h-.95c-.022.002-.028.008-.03.032v1.481c0 .09-.004.082.082.082h.913c.082 0 .072.128.072.128V11.19s.003.117-.06.117h-1.482c-.068 0-.06.082-.06.082v1.445s-.01.068.064.068h1.457c.082 0 .076-.006.076.079v3.225c0 .088-.007.081.082.081h1.43c.09 0 .082.007.082-.08v-3.27c0-.029.006-.035.033-.035l2.323-.003c.098 0 .191.02.28.061a.46.46 0 0 1 .274.407c.008.395.003.79.003 1.185 0 .259-.107.367-.33.367h-1.218c-.023.002-.029.008-.028.033.184.437.374.871.57 1.303a.045.045 0 0 0 .04.026c.17.005.34.002.51.003.15-.002.517.004.666-.01a2.03 2.03 0 0 0 .408-.075c.59-.18.975-.698.976-1.313v-1.981c0-.128-.01-.254-.034-.38 0 .078-.029-.641-.724-.998z',douyin:'M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.63.41-1.11 1.04-1.36 1.75-.21.51-.15 1.07-.14 1.61.24 1.64 1.82 3.02 3.5 2.87 1.12-.01 2.19-.66 2.77-1.61.19-.33.4-.67.41-1.06.1-1.79.06-3.57.07-5.36.01-4.03-.01-8.05.02-12.07z'};
const scope=s=>JSON.stringify([s.authEpoch||0,s.connection,s.user||'',s.storeId||'',s.activePlatform||'xiaohongshu']);
function model(s){const key=scope(s);if(s.accountPage?.scope!==key)s.accountPage={scope:key,pending:'',feedback:{},failures:{}};return s.accountPage;}
function currentPlatform(s){const p=s.platform;return s.connection==='connected'&&s.session?.user?.username===s.user&&p?.actor?.username===s.user&&p.actor.storeId===s.storeId?p:null;}
function platforms(s){
  const p=currentPlatform(s);
  return slots.map(slot=>{const live=p?.platforms?.find(r=>slot.aliases.includes(r.id)),accountId=s.platformAccountSelections?.[live?.id]||live?.accountId,account=p?.accounts?.find(r=>r.id===accountId&&slot.aliases.includes(r.platform));return {...slot,...live,accountId,account,displayName:slot.name,status:account?.status||live?.status,message:account?.message||live?.message,requiresReview:account?.requiresReview??account?.requires_review??live?.requiresReview,accountName:account?.name||account?.platformNickname||account?.platform_nickname||live?.accountName||'尚未连接'};});
}
function status(row,s){
  if(s.connection==='preview')return '待登录';
  const p=currentPlatform(s);if(s.platformLoading&&!p)return '正在读取';if(!p||s.platformError)return '状态待读取';if(row.enabled===false)return '未开通';if(row.enabled!==true)return '状态待读取';
  const d=p.device||{};if(['held','blocked','paused','review_required'].includes(d.state)||row.requiresReview)return '暂停 · 待核验';if(!d.bound)return '待准备';if(d.state!=='online')return '电脑待连接';
  if(model(s).failures?.[row.id])return '待重新检查';
  if(['ready','connected','online'].includes(row.status))return row.account?'已连接':'待核验';
  return ({logging_in:'连接中',waiting_login:'等待扫码',checking:'核对中',held:'暂停 · 待核验',blocked:'暂停 · 待核验',login_required:'待登录',disconnected:'待连接',failed:'连接未完成',unverified:'待核验'})[row.status]||'待登录';
}
function preparation(s,pending=model(s).pending){
  const p=currentPlatform(s),d=p?.device;
  if(pending==='prepare')return {label:'准备中…',ready:false,message:'正在检查当前电脑的连接环境'};
  if(s.connection==='preview')return {label:'待准备',ready:false,message:'自动检查连接环境，准备好后再登录平台'};
  if(!p||s.platformError)return {label:s.platformLoading?'正在读取':'待读取',ready:false,message:s.platformError||'自动检查连接环境，准备好后再登录平台'};
  if(d?.bound&&d.state==='online')return {label:'已准备',ready:true,message:'本机连接已确认，可以选择平台登录'};
  return {label:['held','blocked','paused'].includes(d?.state)?'待核验':d?.state==='binding'?'准备中':'待准备',ready:false,message:d?.message||'自动检查连接环境，准备好后再登录平台'};
}
function brand(id){const path=brandPaths[id],shape=id==='douyin'?`<path d="${path}" fill="#25f4ee" transform="translate(-.7 -.1)"/><path d="${path}" fill="#fe2c55" transform="translate(.7 .5)"/><path d="${path}" fill="#fff"/>`:`<path d="${path}" fill="#fff"/>`;return `<span aria-hidden="true" style="width:80px;height:80px;display:flex;align-items:center;justify-content:center;border-radius:21px;background:${id==='douyin'?'#101214':'#ff2442'};flex-shrink:0"><svg viewBox="0 0 24 24" style="width:${id==='douyin'?51:69}px;height:${id==='douyin'?58:69}px">${shape}</svg></span>`;}
const textButton='border:0;background:transparent;padding:3px 6px;color:#087d91;font-size:15px;white-space:nowrap';
const primary='background:#007e89;color:#fff;border:1px solid #007e89;border-radius:8px;font-size:22px;font-weight:600;height:63px;padding:0 24px;white-space:nowrap';
const chip=(text,ok=false,neutral=false)=>`<span role="status" style="display:inline-block;padding:6px 20px;border-radius:24px;background:${ok?'#e5f8f3':neutral?'#eef4f8':'#fff1dc'};color:${ok?'#087f75':neutral?'#8399af':'#a45d15'};font-size:18px;line-height:1.4;font-weight:500;white-space:nowrap">${escape(text)}</span>`;
export function render(s){
  const id=s.activePlatform||'xiaohongshu',row=platforms(s).find(x=>x.id===id),p=currentPlatform(s),prep=preparation(s),ui=model(s);
  const accounts=(p?.accounts||[]).filter(a=>row.aliases.includes(a.platform)),busy=s.busy||Boolean(ui.pending);
  return `<div class="platform-accounts-page"><section class="account-platform-card card"><div class="account-platform-heading"><img src="/assets/brand-${id}.svg" alt=""><div class="account-title-line"><h2>${row.displayName}账号</h2><span class="account-help"><button type="button" data-account-help aria-label="账号使用说明" aria-describedby="account-help-text">?</button><span id="account-help-text" role="tooltip">当前工作门店由工作台所选门店决定，不是小红书自动识别。任务保存当时的门店条件；换词无需重登。登录与请求验证分别判断，验证码或人脸核验仍需本人完成。</span></span></div><button type="button" class="primary" data-account-add>新增账号</button></div><div class="account-rows">${accounts.length?accounts.map(account=>{
    const selected=row.accountId===account.id,entry={...row,account,status:account.status,requiresReview:account.requiresReview??account.requires_review};
    const actual=account.platformNickname||account.platform_nickname||'',label=status(entry,s);
    return `<article class="account-row ${selected?'is-selected':''}"><img class="account-brand" src="/assets/brand-${id}.svg" alt=""><div class="account-name"><strong>${escape(account.remarks||account.name||'未命名账号')}</strong><span>${actual?'平台昵称：'+escape(actual):'登录后读取平台身份'}</span><span>当前工作门店：${escape(s.store||'尚未选择')}</span></div><span class="account-status" role="status">${escape(label)}</span>${account.status==='ready'?`<button type="button" data-account-select="${escape(account.id)}" ${busy||selected?'disabled':''}>${selected?'当前使用':'使用此账号'}</button>`:`<button type="button" data-account-connect="${escape(account.id)}" ${busy?'disabled':''}>登录此账号</button>`}<button type="button" class="text-button" data-account-check="${escape(account.id)}" ${busy?'disabled':''}>检查连接</button><button type="button" class="text-button" data-account-edit="${escape(account.id)}">修改</button></article>`;
  }).join(''):'<div class="account-empty"><p>还没有'+row.displayName+'账号</p><span>新增一个账号后，在平台窗口完成登录。</span></div>'}</div><p class="account-feedback" role="status">${escape(ui.feedback[id]||s.platformError||'')}</p></section><div class="account-device"><span>${escape(prep.message)}</span><button type="button" class="text-button" data-account-prepare ${busy?'disabled':''}>${prep.ready?'检查本机':'准备本机连接'}</button></div></div>`;
}
export function bind(root,ctx){
  const help=root.querySelector('[data-account-help]');help?.addEventListener('keydown',e=>{if(e.key==='Escape'){help.blur();help.closest('.account-help')?.classList.add('is-dismissed');}});for(const name of ['focus','mouseenter'])help?.addEventListener(name,()=>help.closest('.account-help')?.classList.remove('is-dismissed'));
  const state=ctx.state,key=scope(state),id=state.activePlatform||'xiaohongshu';
  const own=()=>scope(state)===key&&state.page==='accounts';
  async function run(kind,accountId){
    const ui=model(state);if(ui.pending||state.busy)return;
    if(state.connection==='preview'){ctx.toast('界面预览不会连接真实账号。');return;}
    ui.pending=kind;ui.feedback[id]='正在处理…';ctx.update(()=>{});
    try{
      if(accountId){state.platformAccountSelections??={};state.platformAccountSelections[id]=accountId;}
      const result=kind==='prepare'?await ctx.actions.preparePlatform():kind==='check'?await ctx.actions.checkAccount(id):await ctx.actions.connectAccount(id,accountId);
      if(!own())return;ui.feedback[id]=result?.job?.message||state.platformError||'';
    }catch(error){if(own())ui.feedback[id]=error.message;}
    finally{if(own()){ui.pending='';ctx.update(()=>{});}}
  }
  root.querySelector('[data-account-add]')?.addEventListener('click',()=>{
    const name=id==='douyin'?'抖音':'小红书';
    const dialog=ctx.modal({title:'新增'+name+'账号',html:`<form class="account-add-form"><label>账号备注<input id="account-new-name" maxlength="80" autocomplete="off" placeholder="例如：古北店前台A" required></label><p>登录后由平台读取昵称，备注用于你自己区分账号。</p><p data-account-create-error role="alert"></p></form>`,confirmLabel:'新增并登录',onConfirm:async()=>{
      if(!own()||state.busy)return false;const input=dialog.querySelector('#account-new-name'),name=input.value.trim();if(!name){input.reportValidity();return false;}
      if(state.connection==='preview'){ctx.toast('预览不会新增真实账号');return true;}
      const button=dialog.querySelector('.modal-confirm');button.disabled=true;
      try{const result=await ctx.actions.accountCreate({platform:id,name});if(!own())return false;const accountId=result?.job?.accountId||result?.accountId;if(!accountId)throw Error('新增结果尚未确认，请刷新账号列表核对。');state.platformAccountSelections??={};state.platformAccountSelections[id]=accountId;dialog.close();await run('connect',accountId);return false;}
      catch(error){if(own())dialog.querySelector('[data-account-create-error]').textContent=error.message;return false;}
      finally{if(button.isConnected)button.disabled=false;}
    }});
  });
  root.querySelectorAll('[data-account-edit]').forEach(button=>button.addEventListener('click',async()=>{
    const accountId=button.dataset.accountEdit;let value=null,pending=false;
    const dialog=ctx.modal({title:'修改账号',html:'<p role="status">正在读取账号资料…</p>',canClose:()=>{if(pending){ctx.toast('请先重新读取，核对原账号修改结果。');return false;}return true;}});
    const modalOwner=dialog.__modalOwner,owns=()=>own()&&dialog.open&&dialog.__modalOwner===modalOwner;
    function show(message=''){
      if(!owns()||!value)return;
      dialog.querySelector('.modal-content').innerHTML=`<form class="account-add-form"><label>账号备注<input id="account-edit-name" maxlength="100" value="${escape(value.name)}"></label><label>平台昵称<input value="${escape(value.platformNickname||'登录后读取')}" readonly></label><label>登录入口<input value="${escape(value.url)}" readonly></label><p>登录入口由平台固定；修改备注不会更换登录身份。</p><p data-account-edit-message role="status">${escape(message)}</p><button type="button" data-account-edit-read>重新读取</button></form>`;
      const actions=dialog.querySelector('.modal-actions');actions.innerHTML=`<button type="button" class="modal-cancel">关闭</button><button type="button" class="primary" data-account-edit-save ${pending?'disabled':''}>保存备注</button>`;
      actions.querySelector('.modal-cancel').onclick=()=>{if(!pending)dialog.close();else ctx.toast('请先重新读取核对修改结果。');};
      dialog.querySelector('[data-account-edit-read]').onclick=()=>readMetadata();
      actions.querySelector('[data-account-edit-save]').onclick=async()=>{
        if(!owns()||pending)return;const name=dialog.querySelector('#account-edit-name').value.trim();if(!name){dialog.querySelector('[data-account-edit-message]').textContent='请填写账号备注。';return;}
        pending=true;actions.querySelector('[data-account-edit-save]').disabled=true;
        try{const result=await ctx.actions.accountMetadataSave({accountId,platform:id,name,expectedMetadataDigest:value.metadataDigest});if(!owns())return;value=result?.accountMetadata;if(!value||value.accountId!==accountId||value.platform!==id)throw Error('账号修改回执不一致，请重新读取。');pending=false;show('备注已保存。');ctx.actions.refreshPlatform({manual:true});}
        catch(error){if(!owns())return;const uncertain=['RESULT_UNCONFIRMED','ACCOUNT_METADATA_RESULT_UNCONFIRMED'].includes(error.code);pending=uncertain;dialog.querySelector('[data-account-edit-message]').textContent=error.message+(uncertain?' 请重新读取核对原账号，输入已保留。':'');actions.querySelector('[data-account-edit-save]').disabled=uncertain;}
      };
    }
    async function readMetadata(){
      try{const result=await ctx.actions.accountMetadataRead({accountId,platform:id});if(!owns())return;const next=result?.accountMetadata;if(next?.accountId!==accountId||next.platform!==id||next.urlEditable!==false)throw Error('账号资料暂未确认。');value=next;pending=false;show();}
      catch(error){if(owns()){const message=dialog.querySelector('[data-account-edit-message]');if(message)message.textContent=error.message;else dialog.querySelector('.modal-content').textContent=error.message;}}
    }
    await readMetadata();
  }));
  root.querySelector('[data-account-prepare]')?.addEventListener('click',()=>run('prepare'));
  root.querySelectorAll('[data-account-select]').forEach(button=>button.addEventListener('click',()=>{
    if(!own()||state.busy||state.pendingAction?.unconfirmed||state.acquisitionAttempt?.unconfirmed)return;
    const current=currentPlatform(state),account=current?.accounts?.find(a=>a.id===button.dataset.accountSelect&&a.platform===id);
    if(model(state).pending||['submitted','unconfirmed'].includes(current?.lastRequest?.state)){ctx.toast('请先核对上次采集状态，再选择账号。');return;}
    if(!account||account.status!=='ready'||account.requiresReview)return;
    if(['running','queued','pausing','resuming','stopping'].includes(current.acquisition?.status)){ctx.toast('请先暂停当前采集，再选择账号。');return;}
    state.platformAccountSelections??={};state.platformAccountSelections[id]=account.id;
    ctx.update(()=>{});ctx.toast('已选用本店账号，沿用现有登录。');
  }));
  root.querySelectorAll('[data-account-connect]').forEach(b=>b.addEventListener('click',()=>run('connect',b.dataset.accountConnect)));
  root.querySelectorAll('[data-account-check]').forEach(b=>b.addEventListener('click',()=>run('check',b.dataset.accountCheck)));
  return ()=>{};
}
