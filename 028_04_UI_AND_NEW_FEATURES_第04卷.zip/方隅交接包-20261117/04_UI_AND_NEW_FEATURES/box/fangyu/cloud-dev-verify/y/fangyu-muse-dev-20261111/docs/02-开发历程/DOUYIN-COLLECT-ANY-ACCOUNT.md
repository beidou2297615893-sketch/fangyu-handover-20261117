# 抖音采集：永远不认旧连接，谁登录就用谁采（用户 2026-11-10 22:37 明确要求）

你是官方 Codex，这条任务由 Grok 窗口「抖音链路」按用户本人要求交给你。双方平等协作：你擅长的自己发现问题、自己改；缺我们手上的材料，直接在本窗口向「抖音链路」要，不要停着干等。每做出一个结果，都在本窗口写清：做到哪一步、东西存在哪（路径）、怎么做的、下一步是什么、现在能不能立刻用。做完必须马上写结果，不能做完不吭声。

## 用户原话
「采集程序永远不要认旧连接，我随时换号，我无论用什么号你就用那个去采，没关系的。」
另（19:27）：「采集要跟自动发送一样，小问题就一次性点掉；除非确定网页出验证码了，告诉我『可能出验证码了』；没有验证码就直接自动采集，不要每次让我按继续采集。」

## 已知事实（抖音链路只读核对）
- 根目录 R = C:\Users\rmsama\Documents\ChatGPT\自动获客系统；采集 F = R\work\fangyu-douyin-independent；发送控制 C = R\work\douyin-local-control。Python = C:\Users\rmsama\miniconda3\python.exe。
- 现在点「继续采集」（continue_collection.continue_active）一直返回「采集连接或页面暂未响应。请刷新已登录的原抖音页面…」，用户已刷新浏览器、页面正常、没有验证码。
- 根因：F\active-runner.json 仍是 status running、pid 62008（已死）、账号 小烨Cc.、轮次 round-20261109-230850；计划绑定旧 account_uid 和旧 connection_id。待发阶段卡在 dispatching 无响应，于是跑 node collection_identity_check.cjs <plan> 抖音自用采集台\data\bridge.json，拿旧 connection_id 去对，刷新后旧连接已不存在，所以永远过不了。还有 runner-lease-*.json 残留。
- F\auto_collect.py 只在 ledger_unknown / sources_exhausted / bounded_batch_complete / awaiting_candidate_review 时重开 new_round，且有 lease 文件就一直等；它的 stop 文件已改名为 auto-collect.stop.bak-20261110-191550，现未运行。
- 采集进度窗口 collection_progress_window.py 开着。
- 发送侧：C\auto_continue.py 已加「采集时让路」——检测到采集进度窗口/采集程序在跑时，发送完全不动、不弹窗。发送目前停着（泪痣连续12条暂停，已发322条）。

## 要你做的
1. 采集永远不绑定旧连接、旧账号：每次继续或新开一轮，都用当前已登录、能用的那个抖音页面/连接和那个账号身份；账号变了就按当前账号接着采，不报「身份不一致」去卡人。采集配置（关键词、筛选等）固定不变。
2. 小问题自动处理掉再继续：死掉的 runner、残留 lease、旧 connection、dispatching 无响应、断点等——安全回收后从断点接着采，不要让用户反复点「继续采集」。可以用官方方式刷新/重连当前页面，但不关页面、不自动换号、不提取浏览器凭据。
3. 只在真有验证码、限流、账号异常（被封/登出）时停下并提醒用户；不确定时提示「可能出验证码了」。其他一律自动处理。
4. 采集和发送绝不同时用同一前台页面：采集跑时不启动发送（auto_continue 已让路，别改发送程序和发送队列，不重发任何已发/未知记录）。
5. 改前备份原文件，可先离线测试；装好后真正把采集跑起来，并在本窗口报告：改了哪些文件、备份在哪、现在采集是否真的在跑（看进度窗口/日志里新进的条数）。
