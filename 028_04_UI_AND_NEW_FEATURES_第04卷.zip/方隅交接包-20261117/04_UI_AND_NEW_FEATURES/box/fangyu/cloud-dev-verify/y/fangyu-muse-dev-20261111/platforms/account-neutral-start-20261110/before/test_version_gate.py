"""Run the real controller entry in a temporary root and stop at the version gate.

No probe, sender, task preparation, or production state access is permitted.
"""
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import control
import startup_recovery


class VersionGate(unittest.TestCase):
    def invoke(self, *, version=None, missing=None):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder)
            for name in ('page_guard.cjs','attempt_recovery.py'):
                if name!=missing:(root/name).write_text('fixture',encoding='utf-8')
            reached=[]
            def stop_after_gate():
                reached.append(True)
                raise RuntimeError('OFFLINE_TEST_STOP_AFTER_VERSION_GATE')
            with patch.object(control,'P',root),patch.object(control,'ROOT',root), \
                    patch.object(sys,'argv',['control.py','--employee-start']), \
                    patch.object(control,'employee_start',return_value=True), \
                    patch.object(control,'require_send_allowed',side_effect=stop_after_gate), \
                    patch.object(control,'connect_for_start',side_effect=AssertionError('no bridge or sender allowed')), \
                    patch.object(startup_recovery,'VERSION',version or startup_recovery.VERSION):
                control.main()
            return reached,json.loads((root/'status.json').read_text(encoding='utf-8'))

    def test_installed_background_skip_bundle_can_pass_real_entry_gate(self):
        reached,status=self.invoke()
        self.assertEqual(reached,[True])
        self.assertEqual(status['message'],'OFFLINE_TEST_STOP_AFTER_VERSION_GATE')

    def test_old_or_unrecognized_bundle_remains_blocked(self):
        for version in ('employee-resume-20261110','unknown-version'):
            with self.subTest(version=version):
                reached,_=self.invoke(version=version)
                self.assertEqual(reached,[])

    def test_incomplete_bundle_still_cannot_start(self):
        for name in ('page_guard.cjs','attempt_recovery.py'):
            with self.subTest(name=name):
                reached,_=self.invoke(missing=name)
                self.assertEqual(reached,[])


if __name__=='__main__':unittest.main()
