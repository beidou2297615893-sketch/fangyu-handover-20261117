'use strict';
// Read-only diagnostics; no task preparation, binding changes, or business POST.
const fs=require('fs'),path=require('path');
const root=path.resolve(__dirname,'../..');
const read=p=>JSON.parse(fs.readFileSync(p,'utf8').replace(/^\uFEFF/,''));
const {BridgeClient}=require(path.join(root,'work/runtime/douyin-bridge/lib/client/bridge-client'));
const client=new BridgeClient({...read(path.join(root,'抖音自用采集台/data/bridge.json')).bridge,reuseConnections:false});
const binding=read(path.join(root,'work/douyin-local-control/active.json'));
const {assertPageReady}=require('../douyin-local-control/page_guard.cjs');
(async()=>{
 const status=await client.status(),records=[];
 for(const page of (status.connections?.['douyin.com']||[]).filter(p=>p.alive)){
  const row={pinned:page.id===binding.connection_id,page_path:page.url?new URL(page.url).pathname:undefined};
  try{await assertPageReady(client,page.id);row.visible_gate='ready';}
  catch(error){row.visible_gate=error.message;records.push(row);continue;}
  const r=await client.call({site:'douyin.com',connId:page.id,timeout:10000,
    expression:`(async()=>{const r=await fetch('/aweme/v1/web/user/profile/self/?'+new URLSearchParams(window.__bridge._q()),{credentials:'include'});const d=await r.json();return {http_status:r.status,status_msg:d.status_msg,status_code:d.status_code,account_uid:d.user?.sec_uid,nickname:d.user?.nickname}})()`});
  Object.assign(row,{ok:r?.ok,route_present:!!r?.connection,route_matches:r?.connection===page.id,
    error:r?.error,reply_keys:Object.keys(r||{}),value_keys:Object.keys(r?.value||{}),
    http_status:r?.value?.http_status,status_code:r?.value?.status_code,
    status_code_type:typeof r?.value?.status_code,uid_present:!!r?.value?.account_uid,
    uid_matches:!!r?.value?.account_uid&&r.value.account_uid===binding.account_uid,
    live_nickname:r?.value?.nickname,expected_nickname:binding.nickname});
  records.push(row);
 }
 console.log(JSON.stringify({checked_at:new Date().toISOString(),pages:records},null,2));
})().catch(error=>{console.error(error.message);process.exitCode=1;});
