"""Read-only local keyword history audit; writes only its own audit output."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[1]
QUEUE = PROJECT / 'work/fangyu-text-business-20261029/gubei-existing46-next.json'
AREAS = [
    'xhs-continuous-runner/work', 'xhs-collection-candidate/work',
    'xhs-parallel-pipeline/work', 'xhs-browser-context-recovery',
    'xhs-context-controlled/work', 'xhs-standalone-session/collection-live',
    'xhs-account-switch-candidate/runtime',
    'xhs-account-switch-recovery-candidate/runtime', 'xhs-recording-audit',
]

def main():
    config = json.loads(QUEUE.read_text(encoding='utf-8-sig'))
    words = [item['keyword'] for item in config['keywords']]
    source = Path(config['source'])
    raw = source.read_bytes()
    approved = {line.strip() for line in raw.decode('utf-8-sig').splitlines() if line.strip()}
    assert len(words) == len(set(words)) == 28
    assert all(word in approved for word in words)
    assert hashlib.sha256(raw).hexdigest() == config['source_sha256']
    exact = {word: [] for word in words}
    text_only = {word: [] for word in words}
    roots = []
    errors = []
    for area in AREAS:
        root = PROJECT / 'work' / area
        count = 0
        for path in root.rglob('*') if root.exists() else []:
            if not path.is_file() or path.suffix not in ('.json', '.jsonl'):
                continue
            if any(part.startswith('tmp') or part in ('tests', 'fixtures', 'test-fixtures', 'synthetic') for part in path.parts):
                continue
            count += 1
            try:
                text = path.read_text(encoding='utf-8-sig')
                matching = [word for word in words if word in text]
                if not matching:
                    continue
                values = ([json.loads(line) for line in text.splitlines() if line.strip()]
                          if path.suffix == '.jsonl' else [json.loads(text)])
                def visit(value, pointer=''):
                    if isinstance(value, dict):
                        if isinstance(value.get('keyword'), str) and value['keyword'] in exact:
                            word = value['keyword']
                            exact[word].append({'path': str(path), 'pointer': pointer,
                                'page': value.get('search_page', value.get('page')),
                                'status': value.get('status'),
                                'note': 'field observation alone is not a verified successful search'})
                        for key, child in value.items():
                            visit(child, pointer + '/' + key)
                    elif isinstance(value, list):
                        for index, child in enumerate(value):
                            visit(child, pointer + '/' + str(index))
                    elif isinstance(value, str):
                        for word in matching:
                            if word in value and not pointer.endswith('/keyword'):
                                text_only[word].append({'path': str(path), 'pointer': pointer,
                                    'meaning': 'text occurrence does not establish a search task or cursor'})
                for index, value in enumerate(values):
                    visit(value, '' if path.suffix == '.json' else '/' + str(index))
            except Exception as exc:
                errors.append({'path': str(path), 'category': type(exc).__name__})
        roots.append({'path': str(root), 'exists': root.exists(), 'json_files_scanned': count})
    result = {
        'schema': 'gubei-local-keyword-history-v1',
        'generated_at': datetime.now(timezone.utc).isoformat(),
        'source_queue': str(QUEUE), 'source_queue_sha256': hashlib.sha256(QUEUE.read_bytes()).hexdigest(),
        'original_word_source': str(source), 'original_word_source_sha256': hashlib.sha256(raw).hexdigest(),
        'scanned_roots': roots, 'files_scanned': sum(item['json_files_scanned'] for item in roots),
        'read_errors': errors,
        'current_three_keywords_excluded': config['current_keywords_preserve'],
        'keywords': [],
        'limitations': [
            'This is a bounded local history scan, not proof that a keyword was never searched anywhere.',
            'A keyword in post/comment text, a plan, or an attempt is not a successful search cursor.',
            'A registered search page does not prove every comment page on every note is exhausted.',
            'The current worker can create new files during this read-only snapshot; no running file was changed.',
        ],
        'platform_requests': 0,
    }
    for word in words:
        has_metadata = bool(exact[word])
        result['keywords'].append({'keyword': word, 'source_set': 'existing_46',
            'history_status': 'keyword_metadata_requires_review' if has_metadata else 'no_execution_evidence_in_scanned_roots',
            'trusted_success_pages': [], 'trusted_next_page': None,
            'resume_page': None if has_metadata else 1,
            'resume_basis': 'review_observed_metadata_before_cursor' if has_metadata else 'no_matching_keyword_execution_record_in_scanned_roots',
            'keyword_metadata': exact[word], 'text_only_references': text_only[word],
            'do_not_treat_as_exhausted': True})
    output = HERE / 'history.json'
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf8')
    print(json.dumps({'output': str(output), 'keywords': len(words),
        'files_scanned': result['files_scanned'], 'exact_keyword_matches': sum(map(len, exact.values())),
        'read_errors': len(errors)}, ensure_ascii=False))

if __name__ == '__main__':
    main()
