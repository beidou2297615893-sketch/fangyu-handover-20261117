from pathlib import Path
import ast,hashlib,json,re
H=Path(__file__).resolve().parent
P=Path('C:/积木软件工坊/项目/方隅公寓客户版')
S=P/'work/parallel-integration-20261018/final-integration/stage-02/project'
SRC=S/'work/ui-runtime-r55/src'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path):return path.read_text('utf-8')
def assignment(tree,name):return ast.literal_eval(next(n.value for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in n.targets)))
suite=json.loads(read(H/'DATE-CAPTCHA-RESULT.json'));assert suite['status']=='PASS_DATE_CAPTCHA_INCREMENTAL'
normalization=json.loads(read(H/'PRE-NORMALIZATION-TESTED-AST.json'))
provenance={}
for name,baseline in normalization.items():
    current=SRC/name
    current_ast=hashlib.sha256(ast.dump(ast.parse(current.read_bytes()),include_attributes=False).encode()).hexdigest()
    frozen=S.parents[1]/'candidate-unified-v18/project/work/ui-runtime-r55/src'/name
    assert sha(frozen)==baseline['source_sha256'],name
    assert re.sub(rb'\r+\n',b'\n',frozen.read_bytes())==current.read_bytes(),name
    provenance[name]={**baseline,'current_source_sha256':sha(current),'ast_unchanged':current_ast==baseline['ast_sha256_without_positions'],
      'exact_byte_difference_only_CR_runs_to_LF':True,'tested_byte_source':str(frozen),
      'note':'Full AST can differ in embedded multiline string newlines; source bytes otherwise identical.'}
if any(suite['source_sha256'][name]!=sha(SRC/name) for name in normalization):
    archive=H/'DATE-CAPTCHA-RESULT.PASS-before-normalization.json'
    if not archive.exists():archive.write_bytes((H/'DATE-CAPTCHA-RESULT.json').read_bytes())
    suite['behavior_tested_source_sha256']=dict(suite['source_sha256'])
    suite['normalization_byte_equivalence']=provenance
    suite['source_sha256'].update({name:sha(SRC/name) for name in normalization})
    (H/'DATE-CAPTCHA-RESULT.json').write_text(json.dumps(suite,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
changes=json.loads(read(H.parent/'SOURCE-CHANGES.json'))
assert len(changes)==11
for entry in changes:
    target=S/entry['path'];assert sha(target)==entry['after'],entry['path']
    if target.suffix=='.py':compile(target.read_bytes(),str(target),'exec')
customer=SRC/'assistant/customer_list.py';native=S/'work/ui-native-r57/customer_workbench.py'
overlay=S/'work/shared-backend-integration/vendor-src/douyin_pipeline_overlay.py'
assert assignment(ast.parse(read(overlay)),'_PIPELINE_SHA').lower()==sha(SRC/'core/pipeline.py')
assert assignment(ast.parse(read(native)),'DEPENDENCY_SHA256')['assistant/customer_list.py'].lower()==sha(customer)
projection=next(n for n in ast.walk(ast.parse(read(customer))) if isinstance(n,ast.DictComp) and isinstance(n.generators[0].iter,ast.Tuple) and 'post_date_status' in [e.value for e in n.generators[0].iter.elts if isinstance(e,ast.Constant)])
assert eval(compile(ast.Expression(projection),str(customer)+'[exact-lead-projection]','eval'),{'lead':{'id':'isolated','post_date_status':'unverified'}})['post_date_status']=='unverified'
engine=ast.parse(read(SRC/'core/engine.py'))
importer=next(n for n in ast.walk(engine) if isinstance(n,ast.FunctionDef) and n.name=='_import')
allowed=next(n for n in importer.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='allowed' for t in n.targets))
assert {'post_date_status','filter_review_reason','verification_status'}.issubset(ast.literal_eval(allowed.value))
runtime=S/'work/shared-backend-integration/platform_runtime.py';runtime_tree=ast.parse(read(runtime))
runtime_evidence=[]
for name in ('_bounded_collection','_start_task'):
    method=next(n for n in ast.walk(runtime_tree) if isinstance(n,ast.FunctionDef) and n.name==name)
    handlers=[n for n in ast.walk(method) if isinstance(n,ast.ExceptHandler)]
    calls=sorted({ast.unparse(n.func) for h in handlers for n in ast.walk(h) if isinstance(n,ast.Call)})
    assert not any(any(word in call.lower() for word in ('start_account_login','open_account_verification','logout','unlink','remove_cookie','delete_cookie')) for call in calls)
    runtime_evidence.append({'method':name,'line':method.lineno,'catch_calls':calls,'automatic_login_or_cookie_deletion_in_catches':False})
checks=[{'name':'All 11 declared source changes match actual file hash and all 8 changed Python files compile from read-back bytes','status':'PASS'},
 {'name':'Exact customer-history lead projection retains post_date_status and native dependency pin matches','status':'PASS'},
 {'name':'Core import allowlist retains date pending flag/review evidence and normalized DY exact pipeline pin matches','status':'PASS'},
 {'name':'Collection runtime catch paths retain task error and have no automatic login/cookie deletion','status':'PASS','kind':'static scope, not full backend execution'}]
final={'status':'PASS_INCREMENTAL_COLLECTION_DATE_AND_CAPTCHA_REVIEW','behavior_review':'DATE-CAPTCHA-RESULT.json',
 'behavior_checks_total':len(suite['checks']),'behavior_checks_executed_followup':5,'prior_pass_checks_reused':15,
 'additional_checks':checks,'runtime_catch_review':runtime_evidence,
 'source_sha256':{entry['path']:sha(S/entry['path']) for entry in changes},'post_test_normalization_equivalence':provenance,
 'real_cached_comments_read':17,'old_date_rejections':17,'candidate_retained_pending_post_date':17,'verified_in_range_posts_from_real_cache':0,
 'real_platform_requests':0,'real_model_requests':0,'CLI_processes_started':0,'UI_operations':0,'production_writes':0,'product_edits_by_reviewer':0,
 'limits':['17-row check executes exact source date block on cached mapped rows; it is not an import or model run',
 'Core failure handler executed against fake in-memory store; runtime outer catch reviewed statically',
 'No real task resumed and no platform challenge solved; sustained real acquisition remains unverified',
 'Actual search cards for both cached posts have no recognized published date; retained rows are explicitly pending, not verified recent posts'],
 'red_evidence_preserved':'DATE-CAPTCHA-RESULT.RED-before-fix.json'}
(H/'FINAL-REVIEW.json').write_text(json.dumps(final,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
result=json.loads(read(H/'RESULT.json'))
result['status']='LIVE_V17_STOP_AND_POST_DATE_FILTER_BUG_CONFIRMED; CANDIDATE_INCREMENTAL_REVIEW_PASS'
result['date_semantic_bug_confirmed']=True
result['date_semantic_bug']='UI selects post time and all comment time, but v17 filtered comment.published_at against post date range'
result['actual_post_dates_available_for_17_comments']=0
result['candidate_readonly_date_matrix']={'old_rejected':17,'new_retained':17,'new_post_date_pending':17,'verified_post_dates':0,'imported_by_review':0,'analyzed_by_review':0}
result['proven_local_followups']=['Fix post/comment date-domain mismatch; preserve unknown post dates as explicit pending rather than silently date-rejecting comments',
 'Project explicit current-task CAPTCHA signal as fixed enum; generic HTTP461 remains no authentication inference',
 'Keep CAPTCHA as AdapterPlatformFailure, not AdapterAuthRequired; retain ready account and original receipts',
 'Use cumulative run receipt counts instead of last failed single-batch zeros']
result['evidence']=list(dict.fromkeys(result['evidence']+['DATE-POLICY-EVIDENCE.json','CACHED-17-BASELINE.json','DATE-CAPTCHA-RESULT.json','FINAL-REVIEW.json']))
(H/'RESULT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
report=read(H/'REPORT.md')
report=report.split('\n## 新确认的日期缺陷及候选补丁审查')[0]
report=report.replace('17条均在选定日期外：第一条9月11日，其余16条7月23日至10月8日。未把它们当新客户或已AI分析。',
 '17条的评论日期均在10月13日至19日外：第一条9月11日，其余16条7月23日至10月8日。但员工所选是“帖子时间”，评论范围明确“全部时间”；因此这些筛除并非正常业务筛除，下面已确认是帖子/评论日期错用的本地缺陷。实际帖子日期缺失，不能据评论时间认定帖子不在范围内。它们没有被当新客户或已AI分析。')
report+='''
## 新确认的日期缺陷及候选补丁审查

真实客户页 acquire.mjs 显示“帖子时间”和“评论范围：全部时间”；当前任务 comment_date_range=all。原 pipeline 将帖子日期保留在 content_published_at，Adapters 将评论日期放入 published_at，但原 Core 用 selected date_from/to 筛 published_at，误将帖子条件应用到评论。这是本轮可证明的本地功能错误；不能把17条筛除描述为正常筛除。

两个原搜索卡片均没有可识别的发布时间字段，映射帖子日期也为空。对同17条只读重放确切源码过滤段：旧版17条全被日期排除；新段17条保留并标“帖子日期待核实”。这17条没有导入生产、没有调用模型，也不能称已核实的近7天帖子。来源字段名和日期矩阵在 CACHED-17-BASELINE.json。

候选新段还证实：已知范围外帖子在 before_read 前跳过，HTTP适配器零调用；范围内新帖允许旧评论；原 comments、continuous、非 all 评论策略和其他平台旧日期段保持原行为。首轮发现的重复日期提示已由根作者修复；另一首轮RED是测试误读 pipeline 而非 _pipeline_next，原跳过请求行为始终通过。原RED留存。

验证码修复对3份原ACK载荷输出仅固定 captcha_challenge，CLI原回执前后hash不变。精确异常类型为 AdapterPlatformFailure，而不是 AdapterAuthRequired；实际 Core 异常处理源码段在隔离内存存储中执行后账号仍ready、无accounts写入，只暂停任务。通用461及不完整type/uuid不推断验证码。外层runtime catch无自动登录或cookie删除，此项为静态审查范围。

DATE-CAPTCHA-RESULT.json汇总20项通过，最后追验执行5项，其余15项引用首轮已通过证据，未重复全套；FINAL-REVIEW.json另核11源实际hash、CustomerHistory投影和原精确pin。新产品未由本审查安装/启动，真实持续采集未复测，挑战124触发原因仍未知。
'''
(H/'REPORT.md').write_text(report,encoding='utf-8')
print(json.dumps({'status':final['status'],'behavior_total':20,'followup_executed':5,'static_checks':4,'engine_sha256':sha(SRC/'core/engine.py'),'evidence_dir':str(H)},ensure_ascii=False,indent=2))
