const fs=require('fs'),path=require('path');
const root=path.resolve(__dirname,'../..'), runtime=path.join(root,'work/runtime/douyin-bridge');
const read=p=>JSON.parse(fs.readFileSync(p,'utf8').replace(/^\uFEFF/,''));
const identityOnly=process.argv[2]==='--identity';
const task=identityOnly?null:read(process.argv[2]);
process.env.DOUYIN_RISK_STATE_PATH=path.join(__dirname,'cli-risk-state.json');
process.env.DOUYIN_LOG_DIR=path.join(__dirname,'cli-logs');
const {BridgeClient}=require(path.join(runtime,'lib/client/bridge-client'));
const client=new BridgeClient(read(path.join(root,'抖音自用采集台/data/bridge.json')).bridge);
const bindingPath=path.join(__dirname,'cli-current-binding.json');
let connId=fs.existsSync(bindingPath)?read(bindingPath).connection_id:null;
const accountUid='[REDACTED:douyin_sec_uid]';
const post=require(path.join(runtime,'lib/commands/post'));
const {diagnosticCodes,canSkip}=require('./target-diagnosis.cjs');
let attempted=false,receipt=null;
const ctx={noStore:true,audit:{startOperation(){},endOperation(){}},loggedCall:async(endpoint,params,expression)=>{
 fs.writeFileSync(process.argv[2]+'.submitted',new Date().toISOString(),{flag:'wx'});
 attempted=true;
 const r=await client.call({site:'douyin.com',connId,expression,timeout:15000});
 if(!r.ok||r.connection!==connId)throw Error(r.error||'Connection mismatch');
 const d=r.value,c=d?.comment;
 receipt={status_code:d?.status_code,message:d?.status_msg,cid:c?.cid,text:c?.text,sec_uid:c?.user?.sec_uid,reply_id:c?.reply_id,status:c?.status};
 fs.writeFileSync(process.argv[2]+'.receipt.json',JSON.stringify({at:new Date().toISOString(),connection_id:connId,receipt},null,2),{flag:'wx'});
 return d;
}};
(async()=>{try{
 if(identityOnly){
  const status=await client.status();
  const pages=(status.connections?.['douyin.com']||[]).filter(c=>c.alive&&!c.url.includes('/ucenter/security/')).sort((a,b)=>Date.parse(b.lastActivity)-Date.parse(a.lastActivity));
  if(!pages.length)throw Error('No active Douyin page connection');
  if(!pages.some(p=>p.id===connId))throw Error('Task3 fixed connection unavailable');
  const r=await client.call({site:'douyin.com',connId,timeout:10000,expression:`(async()=>{const p=new URLSearchParams(window.__bridge._q());const r=await fetch('/aweme/v1/web/user/profile/self/?'+p,{credentials:'include'});const d=await r.json();return {status_code:d.status_code,account_uid:d.user?.sec_uid,nickname:d.user?.nickname}})()`});
  if(!r.ok||r.connection!==connId||r.value?.status_code!==0||r.value?.account_uid!==accountUid)throw Error('Current account identity not verified');
  fs.writeFileSync(bindingPath,JSON.stringify({connection_id:connId,account_uid:accountUid,verified_at:new Date().toISOString()},null,2));
  console.log(JSON.stringify({verified:true,...r.value,connection_id:connId}));return;
 }
 const state=read(path.join(__dirname,'continuation-state.json'));
 if(!connId||read(bindingPath).account_uid!==accountUid)throw Error('Batch account binding missing');
 if(state.status==='stopped_platform_rejection'||state.unknown>0)throw Error('Unresolved platform rejection; no submission');
 if(task.account_uid!==accountUid)throw Error('Task account mismatch');
 const identity=await client.call({site:'douyin.com',connId,timeout:10000,expression:`(async()=>{const r=await fetch('/aweme/v1/web/user/profile/self/?'+new URLSearchParams(window.__bridge._q()),{credentials:'include'});const d=await r.json();return {code:d.status_code,uid:d.user?.sec_uid}})()`});
 if(!identity.ok||identity.connection!==connId||identity.value?.code!==0||identity.value?.uid!==accountUid)throw Error('Task3 identity changed; no submission');
 await post(ctx,[task.video_id,task.reply.draft_text,'--reply-to',task.comment_id]);
 if(!receipt?.cid||receipt.status_code!==0||receipt.text!==task.reply.draft_text||receipt.sec_uid!==task.account_uid||String(receipt.reply_id)!==task.comment_id)throw Error('Incomplete CLI success receipt');
 receipt.success_basis='platform_publish_response';
 console.log(JSON.stringify({status:'sent',receipt}));
}catch(e){
 let diagnosis=null,skip_target=false;
 if(attempted && !receipt?.cid && diagnosticCodes.includes(receipt?.status_code)){
  try{
   const video=JSON.stringify(task.video_id),cid=JSON.stringify(task.comment_id);
   const r=await client.call({site:'douyin.com',connId,timeout:15000,expression:`(async()=>{const v=await window.__bridge.getDetail(${video});if(v.status_code!==0)return {detail_status:v.status_code};let cursor=0,total=0,seen=new Set();for(let n=0;n<100;n++){if(seen.has(cursor))break;seen.add(cursor);const d=await window.__bridge.getComments(${video},cursor,50);total+=(d.comments||[]).length;const found=(d.comments||[]).some(c=>String(c.cid)===${cid});if(d.status_code!==0||found||d.has_more===0)return {detail_status:v.status_code,video_present:!!v.aweme_detail,comments_status:d.status_code,has_more:d.has_more,count:total,target_present:found,pages:n+1};if(d.cursor===undefined)break;cursor=d.cursor;}return {detail_status:v.status_code,video_present:!!v.aweme_detail,comments_status:0,has_more:1,count:total,target_present:false,incomplete:true}})()`});
   if(r.ok && r.connection===connId){
    diagnosis=r.value;
    skip_target=canSkip(receipt,diagnosis);
   }
  }catch(diagnosticError){diagnosis={error:diagnosticError.message};}
 }
 console.log(JSON.stringify({status:skip_target?'not_sent':attempted?'unknown':'not_sent',error:e.message,receipt,skip_target,diagnosis}));process.exitCode=1;
}})();
