"""Passive human-verification readiness: no platform requests or desktop actions."""
import ast, pathlib, unittest
S=pathlib.Path('C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project')
p=S/'work/shared-backend-integration/vendor-src/assistant/browser_login_window.py'
tree=ast.parse(p.read_text('utf-8'))
node=next((n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='VerificationTransition'),None)
if node is None:raise ImportError('Human verification transition is not implemented')
space={};exec(compile(ast.fix_missing_locations(ast.Module(body=[node],type_ignores=[])),str(p),'exec'),space)
Transition=space['VerificationTransition']
def page(logged=True,challenged=False,activity=0,guest=False):
 return dict(logged=logged,challenged=challenged,activity=activity,guest=guest)
class VerificationTests(unittest.TestCase):
 def test_existing_login_is_not_captcha_completion(self):
  t=Transition('verification_required')
  self.assertFalse(t.update(0,page()));self.assertFalse(t.update(60,page()))
 def test_challenge_must_disappear_and_stay_clear(self):
  t=Transition('verification_required')
  self.assertFalse(t.update(0,page(challenged=True)))
  self.assertFalse(t.update(1,page()));self.assertFalse(t.update(3,page()))
  self.assertTrue(t.update(4,page()));self.assertFalse(t.update(8,page()))
 def test_active_challenge_blocks_even_after_human_activity(self):
  t=Transition('verification_required')
  self.assertFalse(t.update(0,page(activity=0)))
  self.assertFalse(t.update(30,page(challenged=True,activity=1)))
  self.assertFalse(t.update(60,page(challenged=True,activity=2)))
 def test_human_action_without_challenge_does_not_mean_verified(self):
  t=Transition('verification_required');t.update(0,page())
  self.assertFalse(t.update(1,page(activity=1)))
  self.assertFalse(t.update(4,page(activity=1)))
  self.assertFalse(t.update(5,page(activity=2)))
 def test_completed_login_transition_can_continue(self):
  t=Transition('verification_required');t.update(0,page(logged=False,guest=True))
  self.assertFalse(t.update(10,page()));self.assertTrue(t.update(13,page()))
 def test_expired_login_can_reuse_already_logged_browser_once(self):
  t=Transition('authentication_required');self.assertFalse(t.update(0,page()))
  self.assertTrue(t.update(3,page()));self.assertFalse(t.update(4,page()))
 def test_new_challenge_resets_clear_interval(self):
  t=Transition('verification_required');t.update(0,page(challenged=True));t.update(1,page())
  self.assertFalse(t.update(3,page(challenged=True)))
  self.assertFalse(t.update(4,page()));self.assertFalse(t.update(6,page()))
  self.assertTrue(t.update(7,page()))
if __name__=='__main__':unittest.main(verbosity=2)
