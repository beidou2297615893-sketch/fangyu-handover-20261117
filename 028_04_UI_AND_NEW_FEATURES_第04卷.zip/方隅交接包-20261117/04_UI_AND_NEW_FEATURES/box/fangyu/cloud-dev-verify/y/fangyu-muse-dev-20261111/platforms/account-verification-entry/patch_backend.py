from pathlib import Path
import hashlib,json
T=Path(__file__).resolve().parent
P=Path('C:/积木软件工坊/项目/方隅公寓客户版')
F=P/'work/parallel-integration-20261018/final-integration';S=F/'stage-02/project'
changes=[]
def edit(relative,fn):
    p=S/relative;original=F/'candidate-unified-v20/project'/relative;before=original.read_bytes() if original.exists() else None
    backup=T/'before'/relative;backup.parent.mkdir(parents=True,exist_ok=True)
    if before is not None and not backup.exists():backup.write_bytes(before)
    body=fn(before.decode('utf-8').replace('\r\n','\n') if before else '')
    if p.suffix=='.py':compile(body,str(p),'exec')
    p.write_bytes(body.encode('utf-8'))
    changes.append({'path':relative,'before':hashlib.sha256(before).hexdigest() if before else None,'after':hashlib.sha256(p.read_bytes()).hexdigest()})
def replace(body,old,new,count=1):
    assert body.count(old)==count,(old,body.count(old));return body.replace(old,new)
edit('work/ui-runtime-r55/src/core/xhs_verified_resume.py',lambda _: (T/'verified_pages.py').read_text('utf-8'))
def page(body):
    body=replace(body,'protocol=None,recover_unsent=False):','protocol=None,recover_unsent=False,verified_retry=None):')
    body=replace(body,'self._ready=False;self._last_exit_code=None','self._ready=False;self._last_exit_code=None\n        self.verified_retry=dict(verified_retry or {});self._verified_used=set()')
    body=replace(body,"            if path.exists():\n                try:","            verified_retry=False;grant=None\n            if path.exists():\n                try:")
    body=replace(body,"                    return result['stdout'],result['stderr'],result['returncode']\n                not_sent=",'''                    from .xhs_verified_resume import captcha_receipt
                    grant=self.verified_retry.get(key)
                    verified_retry=bool(type(grant) is dict and key not in self._verified_used
                        and self.protocol=='task-bound-read-v1' and self._process is None
                        and grant.get('task')==self.job_id and grant.get('scope')==self.scope
                        and grant.get('args_digest')==arguments
                        and grant.get('credential_sha256')==self.cookie
                        and type(grant.get('expires_at')) in (int,float) and time.time()<grant['expires_at']
                        and grant.get('receipt_sha256')==hashlib.sha256(previous_raw).hexdigest()
                        and captcha_receipt(previous))
                    if not verified_retry:return result['stdout'],result['stderr'],result['returncode']
                not_sent=''' )
    body=replace(body,'if not not_sent and not legacy_unsent:','if not not_sent and not legacy_unsent and not verified_retry:')
    body=replace(body,'                if legacy_unsent:\n','                if legacy_unsent or verified_retry:\n')
    body=replace(body,"archive=plain(path.with_name(path.stem+'.unsent-'+proof+'.json'))","archive=plain(path.with_name(path.stem+('.verified-' if verified_retry else '.unsent-')+proof+'.json'))")
    body=replace(body,"            self._save(path,record);deadline=time.monotonic()+timeout;self._active=True",'''            if verified_retry:
                record['verified_retry']={'explicit_resume':True,'previous_sha256':proof,
                    'archive':archive.name,'generation':grant['generation']}
                self._verified_used.add(key)
            self._save(path,record);deadline=time.monotonic()+timeout;self._active=True''')
    return body
edit('work/ui-runtime-r55/src/core/xhs_page_process.py',page)
def adapters(body):
    body=replace(body,'scope,guard,*,recover_unsent=False):','scope,guard,*,recover_unsent=False,verified_retry=None):')
    body=replace(body,"'recover_unsent':recover_unsent is True}","'recover_unsent':recover_unsent is True,'verified_retry':dict(verified_retry or {})}")
    return replace(body,"recover_unsent=entry['recover_unsent'])","recover_unsent=entry['recover_unsent'],verified_retry=entry['verified_retry'])")
edit('work/ui-runtime-r55/src/core/adapters.py',adapters)
def runtime(body):
    pos='    def account_job(self, user, data):'
    addition='''    def _verification_task(self,user,data):
        user=self._principal(user)
        if type(data) is not dict or set(data)!={'taskId'}:
            raise PlatformRuntimeError('INVALID_INPUT','请选择原采集任务',400)
        task=self._task(user,data['taskId']);account=self._account(user,task.get('account_id'))
        if task.get('platform')!='xiaohongshu' or account.get('platform')!='xiaohongshu':
            raise PlatformRuntimeError('PLATFORM_UNSUPPORTED','此验证入口用于原小红书任务',400)
        self._executor(user);self._verification_idle(user,account)
        if not self._current_comment_policy(task):
            raise PlatformRuntimeError('TASK_POLICY_CHANGED','任务条件已变化，请保留原记录',409)
        return user,task,account

    def _verified_task_pages(self,user,task,account):
        from core.xhs_verified_resume import verified_pages
        identity=tuple(account.get(k) for k in ('id','tenant_id','cloud_owner','store_id','platform','platform_uid'))
        scope=hashlib.sha256(json.dumps([user['tenant_id'],user['username'],task['id'],identity,self._collection_binding(task)],ensure_ascii=True,sort_keys=True).encode()).hexdigest()
        directory=self.core.store.directory/'accounts'/user['tenant_id']/account['id']
        return verified_pages(directory,task['id'],scope,account)

    def open_acquisition_verification(self,user,data):
        user,task,account=self._verification_task(user,data)
        result=self.open_account_verification(user,{'accountId':account['id']})
        result['result'].update(taskId=task['id'],accountId=account['id'])
        return result

    def resume_verified_acquisition(self,user,data):
        user,task,account=self._verification_task(user,data)
        binding=self._collection_binding(task)
        # A confirmed handoff can survive a lost local response without a new probe.
        pages=self._verified_task_pages(user,task,account)
        if not pages:
            if not self._verification_windows(user,account):
                raise PlatformRuntimeError('VERIFICATION_WINDOW_REQUIRED','请先点“去验证”，完成网页验证后保持窗口打开，再继续原任务',409)
            result=self._recover_xhs_identity(user,account)
            if result.get('result',{}).get('platformLoginConfirmed') is not True:
                raise PlatformRuntimeError('VERIFICATION_NOT_FINISHED','网页验证尚未完成，请完成后再继续',409)
            fresh=self._task(self._principal(user),task['id']);account=self._account(user,fresh['account_id'])
            if self._collection_binding(fresh)!=binding:
                raise PlatformRuntimeError('TASK_SCOPE_CHANGED','原任务条件已变化，断点保留',409)
            pages=self._verified_task_pages(user,fresh,account)
        if not pages:
            raise PlatformRuntimeError('VERIFICATION_RECEIPT_REQUIRED','账号已核对，但原失败页尚未确认，保留断点，请联系管理员',409)
        return self.resume_acquisition(user,data)

'''
    body=replace(body,pos,addition+pos)
    body=replace(body,"start(ident,directory,scope,guard,recover_unsent=control.get('recover_unsent') is True)","start(ident,directory,scope,guard,recover_unsent=control.get('recover_unsent') is True,verified_retry=control.get('verified_retry'))")
    body=replace(body,'def _start_task(self, executor, user, ident, *, recover_unsent=False):','def _start_task(self, executor, user, ident, *, recover_unsent=False,verified_retry=None):')
    body=replace(body,"'recover_unsent':recover_unsent is True}","'recover_unsent':recover_unsent is True,'verified_retry':dict(verified_retry or {})}")
    body=replace(body,"            self._execute(executor,user,'task_resume',{'task_id':task['id']})\n            return self._start_task(executor,user,task['id'],recover_unsent=True)","            verified_retry=self._verified_task_pages(user,task,account) if task.get('platform')=='xiaohongshu' else {}\n            self._execute(executor,user,'task_resume',{'task_id':task['id']})\n            return self._start_task(executor,user,task['id'],recover_unsent=True,verified_retry=verified_retry)")
    return body
edit('work/shared-backend-integration/platform_runtime.py',runtime)
def backend(body):
    body=replace(body,"'acquisition_pause', 'acquisition_resume','account_metadata_read'","'acquisition_pause', 'acquisition_resume','acquisition_verification_open','acquisition_verification_resume','account_metadata_read'")
    body=replace(body,"'acquisition_pause': {'taskId'}, 'acquisition_resume': {'taskId'}}[action]","'acquisition_pause': {'taskId'}, 'acquisition_resume': {'taskId'},\n            'acquisition_verification_open':{'taskId'},'acquisition_verification_resume':{'taskId'}}[action]")
    body=replace(body,"            elif action in ('account_safety','account_review_confirm','account_verification_open'):","            elif action in ('acquisition_verification_open','acquisition_verification_resume'):\n                ident=data.get('taskId')\n                if not isinstance(ident,str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,160}',ident):\n                    raise WorkbenchError('INPUT_INVALID','请先选择原采集任务')\n                method='open_acquisition_verification' if action.endswith('_open') else 'resume_verified_acquisition'\n                job=getattr(self.platform_runtime,method)(user,{'taskId':ident})\n            elif action in ('account_safety','account_review_confirm','account_verification_open'):")
    return body
edit('work/ui-native-r57/workbench_backend.py',backend)
edit('work/ui-native-r57/ui_native_host.py',lambda b:replace(b,"'acquisition_start', 'acquisition_pause', 'acquisition_resume', 'customer_export'","'acquisition_start', 'acquisition_pause', 'acquisition_resume', 'acquisition_verification_open', 'acquisition_verification_resume', 'customer_export'"))
(T/'SOURCE-CHANGES.json').write_bytes((json.dumps(changes,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
print(json.dumps({'status':'BACKEND_PATCHED','files':len(changes)}))
