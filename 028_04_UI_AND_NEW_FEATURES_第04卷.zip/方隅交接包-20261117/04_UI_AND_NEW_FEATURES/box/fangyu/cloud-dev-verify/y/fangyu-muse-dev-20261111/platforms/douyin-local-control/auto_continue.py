"""自动续跑：发送暂停后代替手动点“启动／继续”。只调用与面板按钮完全相同的 control.py --employee-start，不改账本/队列/授权。
只在可安全续跑的暂停(平台拒绝单条/回执未知/只读超时/页面失联)后续跑；
连续12条退回 -> 不续，提醒“该换号了”；验证码/限流/账号不符/身份异常 -> 不续，只提醒；用户暂停、无进展过多次则停手。
2026-11-10 抖音链路按用户授权修改：原来不带参数调用 control.py 会被拒，且“连续12条”不在白名单里一直不提醒。"""
import json, time, subprocess, sys, datetime, pathlib
C = pathlib.Path(__file__).resolve().parent
ROOT = C.parents[1]
PY = r'C:\Users\rmsama\miniconda3\python.exe'
PYW = r'C:\Users\rmsama\miniconda3\pythonw.exe'
LOG = C / 'auto-continue.log'
STATE = C / 'auto-continue-state.json'
STOPFILE = C / 'auto-continue.stop'
OK = ('不会自动重发', '存在结果未知', '回执未知', '只读超时', '暂跳过', '目标评论核验未完成', '目标视频或评论列表无法核验', '平台目标核验未完成', '重新检查超时', 'queue_partial', '未响应', '无响应', '页面失联', 'page_unresponsive')
HARD = ('验证码', 'captcha', '安全验证', '限流', '频繁', '账号不匹配', '账号不符', '未核验', '身份不符', '身份异常')
SWITCH = ('连续12条',)
def log(m):
    with LOG.open('a', encoding='utf-8') as f: f.write(f"{datetime.datetime.now():%m-%d %H:%M:%S} {m}\n")
def rj(p):
    try: return json.loads(p.read_text(encoding='utf-8-sig'))
    except Exception: return {}
def busy():
    out = subprocess.run(['powershell','-NoProfile','-Command',"Get-CimInstance Win32_Process -Filter \"Name='python.exe'\" | % CommandLine"], capture_output=True, text=True, creationflags=0x08000000).stdout
    return any(k in out for k in ('control.py', 'batch_reply_runner.py', 'send_cli_once'))
def collecting():
    """采集和发送不能同时用同一个抖音页面：采集进度窗口开着或采集程序在跑时，发送这边完全不动、也不弹窗。"""
    out = subprocess.run(['powershell','-NoProfile','-Command',"Get-CimInstance Win32_Process -Filter \"Name like 'python%'\" | % CommandLine"], capture_output=True, text=True, creationflags=0x08000000).stdout
    return any(k in out for k in ('collection_progress_window', 'fangyu-douyin-independent', 'new_round.py', 'continue_collection'))
def held():
    sys.path.insert(0, str(C))
    try:
        import importlib, send_hold; importlib.reload(send_hold); return send_hold.hold_reason()
    except Exception as e: return f'hold check failed {e}'
_notified = set()
def notify(key, title, text):
    """同一次停只提醒一次：桌面置顶弹窗 + 提示音。不阻塞续跑循环。"""
    if key in _notified: return
    _notified.add(key)
    log(f'提醒用户：{title}｜{text}')
    code = ("import tkinter as t,tkinter.messagebox as m,winsound,sys;"
            "winsound.MessageBeep(winsound.MB_ICONEXCLAMATION);"
            "r=t.Tk();r.withdraw();r.attributes('-topmost',True);"
            "m.showwarning(sys.argv[1],sys.argv[2],parent=r)")
    try: subprocess.Popen([PYW, '-c', code, title, text], creationflags=0x08000000)
    except Exception as e: log(f'提醒弹窗失败 {e!r}')
def main():
    noprog = 0; last_sent = None; cool = 60
    log('自动续跑已启动（2026-11-10 版：--employee-start + 停了提醒 + 采集时让路）')
    while True:
        if STOPFILE.exists(): log('发现 auto-continue.stop，退出'); return
        time.sleep(20)
        if busy(): continue
        if collecting(): continue
        active = rj(C/'active.json'); task = active.get('task')
        if not task: continue
        nick = active.get('nickname') or ''
        st = rj(pathlib.Path(task)/'batch-runner-status.json')
        status = st.get('status',''); reason = (st.get('reason') or '')
        key = (task, status, reason, st.get('updated_at'))
        if status in ('queue_complete','queue_empty'):
            notify(key, '抖音发送：已发完', f'当前账号「{nick}」这批已经发完了，共确认发出 {st.get("confirmed_sent")} 条。'); continue
        if status not in ('blocked','queue_partial','unknown','stopped'): continue
        h = held()
        if h: log(f'用户/系统暂停中，不续跑：{h}'); time.sleep(300); continue
        if any(k in reason for k in HARD) and not any(k in reason for k in ('不会自动重发','存在结果未知')):
            notify(key, '抖音发送停了：需要你处理', f'「{nick}」停了，原因：{reason[:80]}\n请在抖音页面完成验证或核对账号，然后点「启动／继续」。不会自动续，也不会换号。')
            log(f'停线类暂停，不自动续跑，需人工：{reason[:160]}'); time.sleep(300); continue
        if any(k in reason for k in SWITCH):
            notify(key, '抖音发送停了：该换号了', f'「{nick}」连续12条被抖音退回，已暂停（已确认发出 {st.get("confirmed_sent")} 条）。\n该换号了：在抖音页面换成别的号，核对昵称和头像后点「启动／继续」。已发的不会重发。')
            time.sleep(60); continue
        if not (status=='queue_partial' or any(k in reason for k in OK)):
            notify(key, '抖音发送停了', f'「{nick}」停了，原因：{reason[:80] or status}\n请看进度窗口，必要时点「启动／继续」。')
            log(f'未识别的暂停，不续跑：{status} {reason[:160]}'); time.sleep(300); continue
        sent = st.get('confirmed_sent')
        if last_sent is not None and sent is not None and sent <= last_sent: noprog += 1
        else: noprog = 0
        last_sent = sent
        if noprog >= 5:
            notify(key, '抖音发送：多次自动续跑都没发出去', f'「{nick}」连续5次自动续跑都没有新的成功，可能被平台限制了。先歇30分钟；建议看看页面，必要时换号。')
            log(f'连续5次续跑无新增成功，疑似平台限流，停 30 分钟'); time.sleep(1800); noprog = 0; continue
        wait = min(cool * (2 ** noprog), 600)
        log(f'检测到可续跑暂停（{status}，累计{sent}）：{reason[:120]}；{wait}s 后自动点启动')
        time.sleep(wait)
        if busy() or collecting() or STOPFILE.exists(): continue
        if rj(C/'active.json').get('task') != task: log('等待期间当前任务变了，本次不续'); continue
        subprocess.Popen([PY, str(C/'control.py'), '--employee-start'], cwd=str(ROOT), creationflags=0x08000000)
        log('已自动启动／继续（--employee-start）')
        time.sleep(30)
if __name__ == '__main__':
    try: main()
    except Exception as e: log(f'异常退出 {e!r}')
