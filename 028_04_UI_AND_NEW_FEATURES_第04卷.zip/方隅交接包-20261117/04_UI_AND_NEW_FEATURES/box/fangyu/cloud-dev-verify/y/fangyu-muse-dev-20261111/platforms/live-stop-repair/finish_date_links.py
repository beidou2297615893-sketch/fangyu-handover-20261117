from pathlib import Path
import hashlib,json
S=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project');T=Path(__file__).resolve().parent
rows=json.loads((T/'SOURCE-CHANGES.json').read_text('utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def edit(path,old,new):
    p=S/path;before=p.read_bytes();s=before.decode('utf-8');assert s.count(old)==1,(path,s.count(old));s=s.replace(old,new);compile(s,str(p),'exec')
    existing=next((r for r in rows if r['path']==path),None)
    if existing is None:
        b=T/'before'/path;b.parent.mkdir(parents=True,exist_ok=True)
        with b.open('xb') as f:f.write(before)
        existing={'path':path,'before':sha(p)};rows.append(existing)
    p.write_text(s,encoding='utf-8');existing['after']=sha(p)
edit('work/ui-runtime-r55/src/core/engine.py',"dict.fromkeys(filter(None,[previous,reason]))","dict.fromkeys(filter(None,[*previous.split('；'),reason]))")
history='work/ui-runtime-r55/src/assistant/customer_list.py'
old=sha(S/history)
edit(history,"'analysis_status','verification_status','ip_location'","'analysis_status','verification_status','post_date_status','ip_location'")
edit('work/ui-native-r57/customer_workbench.py',old.upper(),sha(S/history).upper())
edit('work/shared-backend-integration/vendor-src/douyin_pipeline_overlay.py',
     "_PIPELINE_SHA='FF370452BE1F3FA6141EBC2BB92B982A10D8C844580D3000DE17DD3828E786AA'",
     "_PIPELINE_SHA='"+sha(S/'work/ui-runtime-r55/src/core/pipeline.py').upper()+"'")
(T/'SOURCE-CHANGES.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'changed_files':len(rows),'history_sha':sha(S/history),'pipeline_sha':sha(S/'work/ui-runtime-r55/src/core/pipeline.py')},ensure_ascii=False))
