from pathlib import Path
import hashlib,json,re
S=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project');T=Path(__file__).resolve().parent
rows=json.loads((T/'SOURCE-CHANGES.json').read_text('utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for row in rows:
    p=S/row['path'];raw=p.read_bytes();raw=re.sub(rb'\r+\n',b'\n',raw)
    if p.suffix=='.py':compile(raw,str(p),'exec')
    p.write_bytes(raw)
history=S/'work/ui-runtime-r55/src/assistant/customer_list.py'
customer=S/'work/ui-native-r57/customer_workbench.py'
s=customer.read_text('utf-8')
s,count=re.subn(r"('assistant/customer_list.py':')[A-F0-9]{64}(')",lambda m:m[1]+sha(history).upper()+m[2],s)
assert count==1;customer.write_bytes(s.encode('utf-8'))
overlay=S/'work/shared-backend-integration/vendor-src/douyin_pipeline_overlay.py'
s=overlay.read_text('utf-8');s,count=re.subn(r"(_PIPELINE_SHA=')[A-F0-9]{64}(')",lambda m:m[1]+sha(S/'work/ui-runtime-r55/src/core/pipeline.py').upper()+m[2],s)
assert count==1;overlay.write_bytes(s.encode('utf-8'))
for row in rows:
    p=S/row['path'];raw=p.read_bytes()
    if p.suffix=='.py':compile(raw,str(p),'exec')
    row['after']=sha(p)
(T/'SOURCE-CHANGES.json').write_bytes((json.dumps(rows,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
bad=S.parents[1]/'candidate-unified-v18'
assert bad.is_dir()
(bad/'NOT-INSTALLED.json').write_bytes(json.dumps({'status':'REJECTED_BEFORE_INSTALL','reason':'Source line-ending validation failure; original desktop remains v17','installed':False}).encode('utf-8'))
print(json.dumps({'syntax':'PASS_READ_BACK_BYTES','files':len(rows),'customer_sha':sha(customer),'history_sha':sha(history)},ensure_ascii=False))
