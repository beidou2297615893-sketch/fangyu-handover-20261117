# 抖音 CLI｜搜索跟进：开发历程与接续说明

整理日期：2026-11-10（Asia/Shanghai）。

对应窗口：**抖音 CLI｜搜索跟进**。对应工程：方隅项目的抖音本地 CLI 搜索、评论采集、入账、去重、分类交接与采集进度窗口。

本文按本窗口已有对话、压缩后保留的工作记忆和本次只读核对到的代码、配置、日志、状态文件重新整理，没有照抄其他窗口的开发历程。历史记忆不完整的细节明确写成待核；本次发现的后续文件也与本窗口能够确认的历史工作分开叙述。

**本次唯一交付是这份文档。没有启动、停止、恢复或修改任何采集、发送、分类、守护程序，没有更新采集计划、共享账本或自动化。** 本文的启动说明供后续另行授权执行，不代表本次已执行。

## 1. 这个窗口到底负责什么

用户要的不是一个只会跑一次搜索的小脚本，而是一条能持续找到租房相关评论、保存原始结果、避免重复采集和重复回复、接上本地意向分类、出现问题能够解释和接续的实际链路。

本窗口的主要职责逐步形成如下分工：

1. 在用户已登录的抖音页面和明确授权的账号范围内搜索。
2. 从合格的视频来源读取评论，保存评论 ID、原发布时间、原文及平台提供的公开字段。
3. 本地保存请求意图、反馈、回执、游标和关联来源；未知结果不冒充失败，不重新请求原未知目标。
4. 与共享发送账本核对抖音侧的防重证据，不重置 sent、unknown、reserved。
5. 按原评论时间做准入及保留期处理，把合格增量交给本地分类链路。
6. 消费语气窗口提供的版本化分类结果，显示有效中、高、超高意向与可回复数量。
7. 提供可见的采集状态、停止原因和用户完成验证码后的继续入口。

意向、预算、双方意愿、母句和回复口吻的规则主体由「回复语气｜关键词 过滤词」窗口维护。本窗口负责接入其产物和保证采集侧口径一致，不应自行另造一套分类标准。

**采集授权与发送授权分开。** 本窗口后续持续任务明确为只采集、分类和草稿，不发送、不操作其他平台。共享账本里存在历史发送回执，不能据此推断本窗口现在获得发送授权。

## 2. 完整路径总入口

项目根目录：

`C:\Users\rmsama\Documents\ChatGPT\自动获客系统`

本窗口主要工作目录：

`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent`

本次文档：

`C:\Users\rmsama\Documents\ChatGPT\codex-briefs-20261110\douyin-cli-search-history.md`

统一编写要求：

`C:\Users\rmsama\Documents\ChatGPT\codex-briefs-20261110\HISTORY-COMMON.md`

重要原则：这个目录内的客户运行数据不能复制到通用工坊、其他客户实例或别的项目。本文只记录路径、机制和必要汇总，不复制客户原文、客户身份、登录状态、密码、Cookie、Token 或连接配置内容。

## 3. 最早阶段：先把本地账本做对，再接真实平台

### 3.1 为什么先做独立账本

早期已有本机抖音 CLI 和 Bridge，但旧包装器绑定原实例配置及连接。直接复用包装器容易混用账号、端口、配置和数据，所以本窗口先建立独立本地账本小样。

核心文件：

- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\ledger.py`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\test_ledger.py`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\import_initial.py`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\README.md`

账本最初使用 Python 标准库和 SQLite，先用合成输入验证，不把离线测试当真实平台验收。后续才逐步承接真实采集。

### 3.2 一开始就确定的存储原则

- 视频与评论分开；视频是获客入口，不能把视频数算成评论数。
- 评论按平台原始字符串 CID 去重，不能把长整数先转成 JavaScript Number 再恢复。
- 同一评论可以对应多个搜索来源，来源关系不是独立客户人数。
- 相同 request_id、相同内容重复入账应幂等；同 ID 内容冲突拒绝覆盖旧证据。
- 请求、反馈、实体、来源关系和游标提交应具有事务一致性，写入失败不能只推进游标。
- 平台未知结果、验证、错连接、非零状态、无效响应、不推进游标等情况必须分开记录。
- 原始返回是经过已知敏感字段脱敏的 JSON 结构，不是网络原始字节档案，也不承诺任意自由文本已绝对脱敏。

### 3.3 上游复用和没有直接照搬的原因

本地 Bridge 来源为 `Yht20927/douyin-cli`，早期本地许可核对为 MIT。这里记录的是当时复用依据，本次没有联网复核上游最新版本，也没有更新依赖。

发现过的关键风险：当 strictConnections 未启用、指定连接失效时，旧路由可能退回站点第一个连接。前后读取账号只能降低风险，不能代替服务端严格路由；必须核实实际运行服务严格拒绝无效连接。

因此后续采用：严格路由预检、固定连接、页面内账号前核、业务读取、账号后核、实际返回 connection 复核。不能只看到源码里有 strict 分支就说当前服务已隔离。

## 4. 2026-10-29 起：持续采集 runner 与多来源调度

### 4.1 从一次性导入升级到持续采集

建立 Node runner，负责调度和 Bridge 读取；Python 账本负责落盘和去重。主要文件：

- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\runner.cjs`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\runner_test.cjs`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\runner_ledger_adapter.py`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\runner_cache_test.py`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\runner_audit.py`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\runner_README.md`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\create_plan.py`

最初计划覆盖 15 个门店入口和约 3000 个规范搜索词。这是当时计划，不是当前所有版本固定不变的词量。

### 4.2 搜索、评论与公平调度

搜索页与已发现视频的评论页交错执行，避免只一直搜索却不读评论，或一直陷在单个视频里。门店间公平轮换，优先已提交页数较少的流。

同一关键词跨门店只执行一个规范搜索流，同时保存全部来源关联。同一视频跨关键词、门店只采一个规范评论流，来源可以继续补充。不能把某个搜索入口对应的门店写成客户已经选择的门店。

真实断点来自账本中的 scan_streams、scan_pages，不从搜索发现顺序重新推导。曾特别保护评论流从 20 到 40 等已存在游标，不能换了候选排序就从 0 重扫。

### 4.3 来源相关性守门

新评论队列不是只凭搜索词里出现「租房」就放行，而是检查实际返回的视频正文：地域锚点、租赁语义、已识别异地及买卖房语义分别判断。

正文缺失、地域不明、缺少租赁依据等候选保留证据待核，不虚构相关性。来源合格只表示适合继续读取评论，不表示该评论作者有求租意愿，更不表示适合方隅。

### 4.4 防重复页和异常停止

页指纹不仅检查 cursor，还检查返回 ID 组合。处理过「同批 ID 换游标继续返回」「空列表却说有下一页」「游标不前进」等情况。它们不能被当作正常下一页，也不能无条件认定整个来源已耗尽。

状态区分包括：达到计划目标、有限一页验证完成、来源耗尽、等待候选审核、账号或平台阻断、本地故障。停止原因不同，接续方式也不同。

### 4.5 先落意图，再派发，再保存确定结果

请求状态先写 prepared，跨派发边界写 dispatching，之后调用平台、保存反馈、提交账本并输出回执。

如果崩溃时只留下 dispatching 而没有确定反馈，不能认为没发出去，不能自动重发。`--recover-local` 的用途是重放已经落盘的确定反馈到本地账本，不是重新请求平台。

`control.json` 负责本轮调度、节奏、pending 和本地停止状态；它不是替代源账本的另一套游标真相。

## 5. 早期性能优化：本地缓存、增量索引和调度

持续采集后，反复扫描全量 SQLite、解码历史响应、重算来源关系会放大每页开销。为此增加可重建派生缓存，源账本以只读附加方式被读取，只有明确 ingest 才写源库。

缓存历经多个版本，当前可见主要路径是：

`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\runtime\runner-cache-v7.sqlite3`

不要被旧 README 中 v5 路径误导。缓存是派生物，不能替代源库：

`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\runtime\collection.sqlite3`

优化包括：按新增 attempt rowid 解码、正文守门对新候选或明确变更后的计划计算、请求前用轻量账号 gate 复核，不再反复全量 snapshot。

早期离线记录曾在 10 万合成评论、5000 页样本上测到约 0.933 秒首次缓存、约 0.021 秒暖 snapshot；这是历史离线性能证据，不能拿来承诺真实抖音吞吐。本次没有重跑该性能测试。

保留的代表性实验及回退目录包括：

- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\scheduler-prototype`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\freshness-prototype`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\zero-delay-prototype`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\connection-prototype`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\runner-backup-before-scheduling`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\runner-backup-before-freshness`

这些是实验、测试或备份，不应优先拿来覆盖当前源码。

## 6. 10 月底至 11 月初：多次接续、账号范围和统计口径

用户在浏览器中打开不同账号，要求按已有规则接着采集。因而计划逐渐分成多个 account2、resume、confirmed 版本，每一版都保存自己的 scan_id、账号绑定、连接证据和运行目录。

此阶段反复强调：先读 active-runner.json；按实际 plan、directory、pid 核对，不重复启动；只读确认账号，不根据昵称或旧窗口印象猜当前 UID。

历史计划及脚本仍留在目录内，例如 20261030、20261031、20261101、20261102 的 account2 与 resume 版本。文件存在说明曾保留过一条历史路径，不代表今天可以任选一个直接启动。

### 6.1 曾用过的累计起点

旧阶段用过 35588 作为一批起点；11 月 4 日重新授权时改用 36034 历史保留起点。本轮新增应当用当时约定的起点及同口径累计相减，不能把两个阶段混加。

随后引入滚动保留与业务正文清理，源表数量会下降，旧的「当前表行数减 36034」不再成立。36034、35588 是历史统计口径，不是当前有效线索或剩余任务条件。

### 6.2 为什么必须加载 qualification_policy

历史导入并非每条都带后来新增的正文 eligibility 证据。为保护已人工核准的来源，需要与计划一起加载白名单：

`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\runner-audit-myeaj720\runner-qualification-policy.json`

不加载它，会漏掉一部分历史已核准评论。早期说明里有 127 全部、109 相关、18 误选的样例记录；后来 active 文件又提示漏掉 72 条历史获准评论。它们属于不同阶段和范围，不是可以直接互相替换的当前总数。

### 6.3 账号历史 halt 不能清空

旧账号阻断与当前账号、本轮 scope 的有效阻断必须区分。为此实现：

- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\scoped_recovery.py`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\test_scoped_recovery.py`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\collection_confirmed_scope.py`

effective_halt 以 plan.account_uid、scan_id、必要时具体 spec 判断。旧 account_halts 保留，新 collection_halt_events 继续阻断；不能只看旧表第一条就宣布当前账号异常，也不能因为某次恢复成功就删掉所有历史故障。

作用域复核保存原响应 SHA、授权来源、身份核验证据、允许的关键词和排除的视频；复核只对那条事件、那个新 scope 有效。新故障仍会停，不能无限放行。

## 7. 2026-11-04：本地优先、5 万目标和 1 秒间隔

用户明确要求停止发送，使用当时指定账号启动新一轮，累计约 5 万；时间、预算优先，本地 CLI 和本地分类承担常规执行，AI 只做疑难抽查和低频核验。

本窗口将持续运行、去重、计数、回执、进度交给本地程序，不逐条调用 AI。模型约 15 分钟核验是当时的低频监督策略，不是每 15 分钟必须给用户发一次重复通知。

### 7.1 间隔修改

早期生产节奏默认 40 秒、最低 30 秒。用户指出太慢，明确要求每页改为 1 秒。后续配置的 minimum_delay_ms 变为 1000。

**1 秒是上一页回执完成后的节奏等待，不是每秒必得一页，也不是并发无上限。** 一次业务 call 内还包含身份前核、业务请求、身份后核，真实耗时受页面、平台、连接和返回量影响。大量评论过期、重复或来源不合格时，新有效客户会明显少于读取量。

当前代码还允许其他间隔取值，实验目录也有 zero-delay 名称；不能据此说本轮实际已经零间隔。本次只读看到 active 文件仍写 1000。

### 7.2 5 万目标后来为何不再适用

用户后来明确否定把旧约 5 万条当有意义的本轮成果，要求新一轮只看近期有效客户。后续旧目标字段和历史累计不能自动作为新的停止或成功条件。

当前计划仍有 target_comments=100000 的技术字段，这只能描述该文件的参数。不能反推用户今天重新要求凑满 10 万，更不能把旧库累计当成本轮新客户。

## 8. 采集环节连续遇到的故障与修复

下列是本窗口保留的具体排错记忆和对应文件证据。它们是不同故障，不应全部笼统归结为「浏览器超时」。

### 8.1 浏览器看起来正常，但 CLI 返回未知

用户多次指出页面没有验证码、账号没变，为何仍停。实际链路包含浏览器、Bridge 服务、本地 HTTP、账号前核、业务请求和账号后核；页面正常不等于这些环节全正常。

旧代码曾在异常处理里丢失底层 errno，造成几乎立即失败却只留下泛化未知。修复使用新的本地 HTTP socket、关闭错误复用的连接，并增加异常阶段与白名单错误码等诊断。**因为原异常已丢失，不能事后声称已经证明某次旧故障就是特定网络错误。**

后续分层超时设计：浏览器工作预算约 60 秒、Bridge 约 70 秒、runner 本地 HTTP 约 75 秒，外层给内层留保存确定反馈的时间。不能把未知请求原地重发当成修复。

代表性本地记录：

- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\recent-uu-recovery-verified-20261104.json`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\recent-uu-recovery-node-verification.txt`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\recent-uu-recovery-final-python-verification.txt`

### 8.2 平台反馈已保存，本地 SQLite 写入锁冲突

出现过平台结果已返回，但本地入账 SQLITE_BUSY/locked。此时重新发平台请求会制造重复读取或未知副作用。

处理方式是 WAL、短事务、有限次数本地提交重试；对已落盘完整反馈做幂等本地恢复，不请求平台。历史保留过 3 次有界本地事务重试方案，不能扩大成无限重试。

证据位置：

`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\local-ingest-recovery-20261102`

11 月 4 日后续同类入账恢复也保存在 active-runner.json 的 prior_local_ingest_failure、local_ingest_recovered_at 中。

### 8.3 Windows 控制文件原子替换失败

出现过一页已解析和入账，但 control 文件替换受临时共享占用影响而失败。它与平台未知不是一回事。

修复为只对明确共享冲突做 20/40/80/160ms 有界退避，并依据已有 parsed 回执恢复本地控制状态，不重读那一页。

证据：

- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\recent-uu-control-recovery-verified-20261104.json`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\recent-uu-control-recovery-node-verification-20261104.txt`

### 8.4 身份核验总失败

用户账号没变，但 self profile 接口可能返回暂时 5xx、缺 user/UID 或前后核验超时。原先单一「身份失败」提示无法区分原因。

增加 identity_before、identity_after、HTTP 状态、平台状态、是否有 user/UID、UID 是否匹配等诊断。仅对明确暂时 5xx 或 status=0 但 UID 缺失的窄条件允许一次约 250ms 的身份读取重查；真实不匹配、账号不明、业务未知仍停。

身份核验文件：

`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\collection_identity_check.cjs`

前核失败可能尚未发业务；后核失败则不能假定业务没执行。任何历史例外都需精确事件和响应 hash 复核，不能把所有 identity 错误一概忽略。

### 8.5 搜索返回 service_empty，不能误当结果耗尽

观察过 HTTP 200、status_code=0、data 为空、has_more=1，search_nil_info 明确为 service_empty/search_service_rpc_err，而前后身份一致的响应。

这是无效页，不能作为有效入账或来源耗尽。用户明确继续后，可在精确响应证据、身份复核和排除原目标的条件下进入新 scope。相关判据在 scoped_recovery.py；与验证码、非零状态、身份异常不是同一个放行条件。

### 8.6 真正的验证码

11 月 6 日约 18:43—18:45 的历史检查实际观察到验证码，并保存验证证据。用户需要自己在浏览器完成后确认继续。不能因为此前有一次只是超时，便断言以后所有阻断都没有验证码；也不能拿过去验证码的证据说现在仍有验证码。

### 8.7 原始反馈已知与未知的恢复边界

完整反馈已落盘：只恢复本地事务、索引或控制状态。

已派发但结果未知：保留 unknown，跳过原关键词/视频/目标，不重发原未知业务。

平台验证、限流、错账号、身份不明：仍需人工处理；不能用新 scope 或换账号绕过。

仅 prepared 且有未派发证据：按受控入口处理；不能拿这一条件覆盖 dispatching。

## 9. 时间筛选规则的变化，必须按先后理解

用户确实改过规则，不能把历史不同口径揉成一条从未改变的规则。

1. 先要求近期评论优先，今天、昨天、前天优先，重点 15 天，最多约 30 天；日期未知隔离。
2. 讨论过将 60 天左右也入账、最多 90 天，回复仍以时间特别高优先级排序。保留了 90 天 backfill 等文件。
3. 11 月 5 日用户重新明确只保留 30 天以内，超过 30 天从有效派生池移除，旧大累计不再当成果。
4. 11 月 6 日进一步要求源 comments 业务正文也清理：精确滚动 30×86400 秒，超期及已锁定低意向/非客户/结束需求按证据删除，保留最小防重和必要恢复链。

**当前接续不能再用 90 天作为准入。** active-runner.json 内某些旧字段或 progress-report-state.json 仍可能留 90，不代表新规则被撤回。

### 9.1 CLI 能不能让平台只返回 30 天内评论

本窗口已经纠正过用户的这一理解：不是已证明平台接口提供「只返回一个月内评论」的可靠过滤。当前方式是先读平台返回，再由接在 CLI 后的本地代码检查原评论时间，决定是否进入客户/分类流程。

平台仍可能大量返回旧评论，故读取了许多页却只新增几条近期有效记录是可能的。不能把旧评论过滤少的结果包装成速度变快，也不能承诺平台按最新排序。

### 9.2 原日期、抓取日期与来源日期

准入基于原评论 create_time 的精确滚动秒数，不用本地抓取时间冒充评论时间，不拿视频发布时间代替评论发布时间。今天/昨天/前天用于优先级和显示，不替代 2592000 秒边界。

时间未知、尚未分析留后台待核，不显示为有效客户，也不能全部删除。

### 9.3 90 天历史文件的地位

`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\backfill_recent_90.py`

`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\recent-90-backfill-20261105.json`

它们记录历史阶段，不能在新任务中直接运行以复活已清理旧 CID。

## 10. 本地清理、最小防重与缓存删除一致性

实现入口：

- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\comment_retention.py`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\classified_comment_prune.py`

### 10.1 超期清理

按滚动 30 天检查业务实体、来源关联、旧业务索引和近期 backfill。使用短批事务，历史实现每批约 200 CID，WAL 模式，不做大规模 VACUUM 影响其他读写。

删除业务正文不等于销毁全部原始 signed response、请求、页指纹和恢复证据。为了不复活旧数据、能够核对未知，需要保留最小必要证据。

### 10.2 分类排除必须有四重一致性

清理依据是最新锁定分类中的 lead_intent=low/non_customer/ended，而不是看到商业匹配字段 unverified 就删除。

必须检查：分类版本锁定、产物 SHA 一致、CID 一致、源原文 SHA 与当前实际业务正文一致。源库 entities、items、observations 的同 CID 原文若冲突，应拒绝删除并待核，不能以旧分类覆盖新正文。

排除指纹示例机制为 SHA256("douyin\\0" + CID) 的不可见最小防重记录，附分类版本、等级和快照 hash；不把全文客户明细复制进交接文件。

### 10.3 防止旧 CID 被重新导入

Ledger._observe 等入口检查过期与排除指纹。派生缓存也需要跟随源库删除同步，不能只增不减。

修正过源表删除后 rowid 重用/数量变化导致派生统计或旧关联重新出现的问题。有效关系计数应来自当前活跃 observations，不从旧 raw response 无限复活已删除业务数据。

### 10.4 不明不等于无效

预算 3000—3999、预算未知、用途不清、分类不确定、未分析，不应仅因为没进高意向池就当 low 删除。它们应根据当前规则留在后台、暂缓或待核。

## 11. 本地分类、语气窗口和回复顺序

### 11.1 两段分工的最终解释

前段 CLI 负责找、采、相关来源、时间准入、去重和回执；后段本地分类负责理解求租需求、预算、地区、时间、双方意愿、商业匹配、分池、排序和回复草稿。

关键词命中不等于求租；求租不等于适合方隅；IP 属地不等于意向地区；搜索来源门店不等于客户意向门店。这几个误区已经多次向用户澄清。

### 11.2 用户追问「为什么一千多只有七百多」

用户要求把硬筛选和排序讲清，不能简单把没进候选池的都称为应删除。

最终应区分：时间硬准入、明确无效需求排除、预算及商业适配、未确定记录暂缓、有效客户排序、共享账本已处理记录过滤。候选数少于有效评论数，不代表差额都是垃圾。

用户授权联系语气窗口，要求明确第一层、第二层及排序规则，并与 CLI 同步。历史协作里还修复过旧回复索引漏纳问题，恢复约 589 条候选关联；这是历史修复量，不能拿来替代当前可回复总数。

### 11.3 规则版本与本地链路

本窗口长期消费：

`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\classification-handoff-status.json`

已认可并仍在当前状态中出现的商业适配版本：`fangyu-commercial-fit-v4.3-20261106`。以后以用户认可的后续版本为准，不因为文件名较新就自动认为用户已认可。

已知预算规则包括：整租月预算上限明确低于 3000 的排除；3000—3999 暂缓；未知不造预算。正文广告租金与客户自己的预算不是同一证据，不能混写。

排序主轴是时间优先、再结合预算和意愿。具体分桶、冲突处理与模板以语气窗口规则源为准，本文不编造一个从未核准的打分公式。

### 11.4 分类相关完整路径

- 分类工作区：`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029`
- 当前语义修复/分类产物目录：`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\douyin-semantic-repair-v5`
- 本地增量 worker：`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\douyin-semantic-repair-v5\watch_increment.py`
- 快照构建：`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\douyin-semantic-repair-v5\build_snapshot.py`
- 语义保护：`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\douyin-semantic-repair-v5\semantic_guard.py`
- 本地复核：`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\douyin-semantic-repair-v5\local_recheck.py`
- 本地需求补全：`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\douyin-semantic-repair-v5\complete_local_demand.py`
- 商业筛选代码：`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\business-fit\business_fit.py`
- 分类器目录：`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\pool-sop-v3\classifier`
- 时间优先目录：`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\recency-priority`
- 商业全池产物：`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\douyin-semantic-repair-v5\all-pool-business-fit.jsonl`
- 用户可见有效客户池：`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\douyin-semantic-repair-v5\retained-business-customers.jsonl`
- 分类运行日志：`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\douyin-semantic-repair-v5\watch.log`
- 分类中文状态：`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\douyin-semantic-repair-v5\实时进度.txt`

这里列出的是接入依赖及已核路径，不把语气窗口全部分类实现冒称为本窗口独立完成。

### 11.5 不是全程 AI 逐条分析

watch_increment.py 在文件签名/增量或时间桶变化时构建本地快照，带单实例锁，写 worker 状态和水位。当前状态明确 model_auto_calls=false。

模型只做疑难审核和异常解释；不能为追求 token 省略关键证据，也不能为看起来聪明而逐条调用远端模型。时间、预算与质量同时受约束。

## 12. 共享账本：采集与发送不能混成一张「显得多」的表

用户问过采集的几千评论是否都要放共享账本、是否显得更多。技术上可建立关联，但不能将采集数伪装成已回复数或有效客户数。

主要共享账本路径：

`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\shared-acquisition-ledger\shared.sqlite3`

进度窗口还兼容读取历史回复回执路径：

`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\Codex获客工作台\work\reply_receipts.sqlite3`

当前只针对 platform=douyin 核对；不能读取、重置或接管其他平台状态。sent、unknown、reserved 保留，不把 unknown 当失败自动再发。

采集 source ledger 负责完整采集证据与 CID 防重；共享发送账本负责跨操作的发送防重和结果状态；分类产物负责有效性和排序。这三个数量不能混报。

目录内历史 reply-pilot、reply-live-status 是相邻链路的试验/状态工具。本文不提供发送启动命令，也不将它们作为采集任务的必要启动项。

## 13. 2026-11-06：采集进度窗口和用户可见的继续按钮

用户反复问「暂停了为什么」「验证码完成后按钮在哪里」「之前那个数量窗口还在吗」，因此把采集进度和恢复入口做成独立可视窗口。

主文件：

`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\collection_progress_window.py`

窗口标题：**抖音采集｜进度与继续**。

主要交互：

- 绿色「验证已完成，继续采集」按钮，绑定当前待确认事件。
- 「停止采集并保留当前结果」写入当前运行目录 STOP。
- 关闭窗口不等于停止采集；只打开窗口也不启动采集。
- 点击继续后显示核对中、不能继续的原因或实际恢复结果，避免用户点了毫无反馈。
- 展示本次继续后的采集入账、已确认当前有效中高意向、可回复等业务数字。
- 原始日志保留在文件；对人显示简单业务状态，不用大量内部字段占界面。

恢复实现：

`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\continue_collection.py`

按钮不是清除所有 halt。它核对活跃进程、租约、STOP、当前事件、严格连接、同账号和页面状态，再决定本地恢复或新确认 scope。重复点击有互斥保护，不能生成多个 runner。

验证码由用户在可见浏览器完成；AI 不代点确认、不定时清除验证。用户说「OK了」在历史授权中可以视为已完成验证的明确确认，但仍要核实当前账号和页面，不是免核查通行证。

手机提醒曾被用户要求，但本窗口没有得到已配置且经过送达验证的手机推送渠道。不能把桌面聊天通知冒充手机已收到。

## 14. 2026-11-07：纯等待超时不应全局退出，增加有界本地守护

用户不接受因普通等待长期停住；同时要求未知那条跳过，不重发。为兼顾连续运行和证据边界，增加窄条件本地等待 worker：

- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\collection_wait_worker.py`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\collection-wait-state.json`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\collection-wait-worker.log`

### 14.1 自动接续的精确条件

只限 unknown、ok=false、transport_error=request_timeout、阶段为 business、没有确定 value、前核账号匹配且平台状态正常的那类事件。

随后必须重新严格连接、同 UID、页面已加载且可确认没有验证挑战。符合条件后排除原未知目标，按精确事件 review 新 scope 继续，不重发未知业务。

### 14.2 次数上限与等待

一个恢复周期最多连续跳过 3 次这类超时。达到阈值后 worker 留在 waiting_for_connection，只低频检查连接/身份，不继续循环新业务请求。

正常退避不反复通知用户，不因心跳又启动另一个守护。用户 STOP 优先，不自动恢复用户主动停止。验证码、限流、身份异常仍交人工处理。

worker 自身临时本地异常会记录错误类型后等待，不直接无声退出；但进程是否仍活着必须实际核对，不能只凭 state 文件的 PID。

### 14.3 最后一次本窗口历史健康检查

保留记忆中，11 月 7 日约 01:41 的实际检查曾确认采集、等待守护和分类 worker 都在、effective halt 为空；当时可见有效线索 4157，可回复 1631。

这是**当时的历史快照**，不是 11 月 10 日的运行结论。之后许多排队心跳没有逐次实际工具检查，不能补写成「每次都查过」。

## 15. 本次只读发现的 11 月 9 日后续代码与计划

本次目录里出现了较晚的新一轮入口和自动续跑文件。下面是代码/文件可核实的现状；并不把所有 11 月 9 日后续改动都追认为本窗口压缩记忆中已经完整保留的亲历过程。

### 15.1 新一轮采集入口

- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\new_round.py`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\collection-config-fixed.json`

可见流程：先检查已有 runner/租约，核严格桥和当前已登录账号，存在多个不同账号时拒绝猜选；从固定配置生成新 scan 和目录，排除本账号历史未知相关词/视频，最近 3 天搜索过的词后置，再做账号核验、一页验证、后台全量、进度窗。

固定配置 rule_source 记录了 11 月 9 日关键词提案、增删及轮换分组。应把这些当本地配置 provenance 核对，不能仅凭代码注释扩大当前授权。

与 11 月 7 日的固定账号恢复相比，「用当前登录账号开新轮」是另一种入口。是否可以使用，应结合后续用户真实授权；不能因为新脚本存在就静默切换正在进行任务的账号。

### 15.2 自动开新轮入口

- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\auto_collect.py`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\启动采集自动续跑.cmd`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\auto-collect.log`

代码可见：约每 60 秒检查；runner 或租约存在则不重复开轮；对列举终止原因延迟后调用 new_round.py；一小时最多 6 次后冷却 30 分钟；auto-collect.stop 用于停止该自动器。

**这与 collection_wait_worker 的「business 超时、最多 3 次」是两层不同机制。** auto_collect.py 不是可以跳过所有 unknown 的通行证；new_round.py 仍须让 effective_halt 拒绝不可恢复事件。两者同机存在时应审查实际进程、授权和互斥，不能分别再启动一份。

本次没有验证这条后续自动开轮链路的全套平台行为，没有运行 new_round.py，也没有打开自动续跑按钮。不能把阅读代码写成已验收。

## 16. 2026-11-10 本次只读状态快照

核对时刻约为 **2026-11-10 14:25—14:26 +08:00**。以下只是写历程时的只读观察，没有据此做恢复。

### 16.1 活跃入口文件的内容

入口：

`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\active-runner.json`

该文件修改时间约 2026-11-09 23:09。它指向：

- 计划：`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\plan-round-20261109-230850.json`
- 运行目录：`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\runner-live-round-20261109-230850`
- 控制文件：`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\runner-live-round-20261109-230850\control.json`
- 标准输出：`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\runner-round-20261109-230850-stdout.log`
- 标准错误：`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\runner-round-20261109-230850-stderr.log`
- 一页验证：`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\runner-round-20261109-230850-validation.log`
- 身份证据：`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\identity-round-20261109-230850.json`
- 严格连接证明：`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\strict-proof-round-20261109-230850.json`

这些身份文件只提供路径，不复制其中账号或连接内容。

### 16.2 文件写 running 不等于进程存在

active 文件仍为 status=running、pid=62008；本次 tasklist 精确查询该 PID，没有找到进程。等待 state 记录 pid=47840、mode=platform_or_identity_review，也未找到该 PID。

分类状态记录 pid=38104，本次 tasklist 显示为 python.exe。只匹配到 PID/可执行名，不把它夸大为已完成整个分类逻辑审计。

control.stopped 为 null，stdout 最后可见记录是 page_committed，不能由此推出采集为何退出。**本次没有调查最终退出根因、没有核当前平台身份、没有调用平台、没有执行 effective_halt 实查，也没有恢复进程。** 后续应先查 PID 是否复用、租约、pending/feedback、stderr 和末尾回执，不能直接认定验证码或超时。

### 16.3 分类产物与数量

本次 handoff 的商业适配版本仍为 v4.3。visible_business_pool 指向文件存在，并且现场 SHA256 与 handoff 声明一致；商业全池文件也存在且 SHA 一致。

该快照声明有效可见线索 4643：中 4152、高 479、超高 12；pending_candidates_count 为 839。worker 显示 waiting/观察增量阶段，model_auto_calls=false，error=null，水位 9500。

这些数字有不同含义：4643 是快照声明的 30 天内中高超高有效池；839 是待回复候选数；9500 是分类登记水位，不能当有效客户数。本次核验的是产物存在及 hash 一致，未逐条重新验证 4643 条在阅读时刻的滚动时效和业务分类。

### 16.4 旧汇报文件明显滞后

`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\progress-report-state.json`

仍停在 11 月 7 日约 01:42 的旧检查，含旧 PID、旧批次、90 天等过往字段。它是汇报去重/异常指纹历史，不是当前运行真相。本次按「只写历程」要求没有刷新它。

## 17. 核心文件索引及各自作用

| 完整路径 | 用途及接续注意 |
|---|---|
| C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\active-runner.json | 当前入口指针；读取后还要核实际进程，不能只信 status |
| C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\runner.cjs | 采集调度、请求边界、回执、节奏、租约、停止与本地恢复 |
| C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\runner_ledger_adapter.py | 源库/缓存适配、scope gate、增量索引和入账 |
| C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\ledger.py | 请求与响应校验、持久化、CID/页/来源关系防重 |
| C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\scoped_recovery.py | 按账号和 scan 判断有效 halt，精确复核旧事件 |
| C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\collection_confirmed_scope.py | 用户确认后的新 scope 和排除原未知目标 |
| C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\continue_collection.py | 现有任务继续入口，非通用无条件重启器 |
| C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\collection_identity_check.cjs | 严格连接、账号和页面状态核验；会访问平台，本文未执行 |
| C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\collection_progress_window.py | 独立可视进度和用户继续/停止按钮 |
| C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\collection_wait_worker.py | 窄条件 business timeout 有界接续守护 |
| C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\comment_retention.py | 原评论滚动 30 天的本地保留清理 |
| C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\classified_comment_prune.py | 锁定分类和原文证据一致时清理明确无效业务正文 |
| C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\classification-handoff-status.json | 分类版本、有效池路径/hash、worker、水位和候选 |
| C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\keyword_effectiveness_audit.py | 本地关键词效果审核入口；本次未运行 |
| C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\runtime\collection.sqlite3 | 采集源账本，含必要 raw/attempt/游标/恢复证据，勿整体清空 |
| C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\runtime\runner-cache-v7.sqlite3 | 可重建缓存，不能当源库 |
| C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\shared-acquisition-ledger\shared.sqlite3 | 共享去重/发送状态，抖音任务仅核抖音 |
| C:\Users\rmsama\Documents\ChatGPT\自动获客系统\抖音自用采集台\data\bridge.json | 当前代码使用的桥配置路径，含敏感连接配置，不复制内容 |
| C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\runtime\douyin-bridge | 本地复用 Bridge 运行环境、lib、node_modules、server、node.exe、LICENSE |
| C:\Users\rmsama\Documents\ChatGPT\自动获客系统\抖音自用采集台\启动.cmd | 相邻采集台入口；不要与独立 runner/自动器盲目同时启动 |

数据库中的 attempts、entities、observations、scan_pages、scan_streams、items、recent_comment_backfill、account_halts、collection_halt_events、collection_scope_reviews、collection_event_reviews，以及过期/排除指纹是不同证据层。实际字段以当前源码和 schema 为准，不根据本文擅自迁移。

## 18. 后续如何启动、如何接续（本次未执行）

### 18.1 第一步必须只读核对

1. 读 active-runner.json，定位实际计划、目录、日志、身份和 strict proof。
2. 查实际 PID 和命令归属、同连接/同数据库租约、自动续跑器、等待守护、分类 worker，避免重复启动。
3. 看当前运行目录 control.json 的 pending、prepared/dispatching、反馈文件和 STOP；看末尾 stdout、stderr。
4. 对 plan.account_uid、scan_id 用 scoped_recovery.effective_halt 核有效阻断。不能只看历史 account_halts，也不能清空 halt。
5. 读取 handoff 的版本、文件 hash、worker 水位；不要拿 progress-report-state 的旧计数代替当前状态。
6. 区分单纯查看、恢复当前 scope、用户完成验证码确认、新授权开新轮、仅本地反馈重入账。这些动作的副作用不同。

本次任务只写历程，不构成重新启动授权。

### 18.2 仅显示进度窗口

后续用户明确要求打开窗口时，可在项目工作目录执行以下展示入口。若已打开，先定位原窗口，不重复开多个：

```powershell
Set-Location -LiteralPath 'C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent'
pythonw.exe collection_progress_window.py
```

打开只读进度窗本身不启动采集，但窗口中的继续和停止按钮有实际业务作用，不能代用户点击验证确认。

### 18.3 当前任务的明确确认继续

用户在浏览器完成验证并明确确认后，优先使用进度窗口的绿色按钮。命令入口也存在：

```text
python.exe continue_collection.py --confirmed <当前精确待确认事件ID>
```

占位符不是可照抄的命令，必须取当前事件。脚本本身会核对并可能联网、写 review、新 scope 和启动 runner；本文没有执行。不能拿历史 request_id 代替当前事件，不能用它无条件清平台验证。

### 18.4 新一轮采集

后续另获用户授权开新轮、并确认没有其他活跃采集或冲突自动器后，现有入口是：

```powershell
Set-Location -LiteralPath 'C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent'
python.exe new_round.py
```

它会产生真实平台访问及本地写入，不是只读检查。不要为了查看帮助运行它，也不要在运行中再执行一次。

`启动采集自动续跑.cmd` 会启动后台自动器，不等于只打开进度。需单独核实其授权、单实例及与 timeout 守护的互斥，不能顺手双击。

### 18.5 手工 runner 的组成

若维护时需要绕过包装器诊断，只能从当前源码和 active 文件重建完整参数：plan、database、directory、qualification-policy、bridge-config、identity-probe、strict-proof、minimum-delay-ms，以及明确 --run。

本窗口不提供带真实身份或连接内容的一键粘贴命令。旧 README 的 --minimum-delay-ms 40000、早期生产下限 30000 和旧缓存 v5 均不是当前 active 参数。

### 18.6 纯本地反馈恢复

只有完整确定反馈已落盘并与原请求一致时，才使用 runner 的 recover-local 路径幂等修复。先确认 lease 和当前任务状态，不能同时与另一 ingest 修改同一请求。没有反馈的 dispatching 只能保留 unknown。

### 18.7 分类接续

分类 watcher 是上述 watch_increment.py，已有 worker 时不重启。后续确需恢复时，应核 STOP 的来源和单实例锁，再由拥有分类规则的窗口沿现有入口启动。不要为「同步」重新跑所有历史 AI 分析或覆写已审核语气。

## 19. 验证做过什么、还不能声称什么

历史工作做过合成账本、runner、缓存、scope 恢复、近期评论边界、分类排除和页面/身份等代表性验证。早期文档记录过 18 项 Node runner 测试、5 项 Python cache 测试；后续代码另有补充，不能把早期数量当作当前完整测试集。

保留的相关测试入口包括：

- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\test_ledger.py`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\runner_test.cjs`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\runner_cache_test.py`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\test_scoped_recovery.py`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\test_recent_collection.py`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\business-fit\test_business_fit.py`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-text-business-20261029\douyin-semantic-repair-v5\test_semantic_guard.py`

本次仅文档整理，没有重跑上述测试；没有用测试程序去初始化或改写生产库。合成测试通过不等于平台没有限流，进程启动不等于持续采集有效，产物 hash 一致不等于用户已认可所有回复，草稿生成不等于平台发送成功。

## 20. 剩余问题与应优先处理的卡点

### 20.1 当前入口与实际进程不一致

本次实际看到 active 写 running 但对应采集 PID 不存在，等待 worker 的 PID 也不存在。原因未查明。后续应从最终日志、pending、租约和系统退出情况定位，不得按旧经验直接清 halt 或重启。

### 20.2 状态文件有旧字段混杂

active、progress-report-state 内保留多次历史变更、旧批起点、旧 PID 和旧时间口径。它们对溯源有用，但容易误导 UI 或接手 AI。若以后改造，应分开当前事实与历史记录，先做兼容验证，不直接删除证据；本次未改。

### 20.3 说明文档明显过时

README 仍写独立离线小样、未接平台；runner_README 仍有 30/40 秒、v5 缓存和早期未验状态。这些是当时真实阶段，不能覆盖后来实采与 1 秒修改。本文已明确差异；本次没有顺手重写这些文件。

### 20.4 两层自动接续存在协调风险

11 月 7 日 business timeout 守护和 11 月 9 日 auto_collect/new_round 各有自己的状态和节奏。需要明确谁拥有恢复权、谁检查用户 STOP、历史 unknown 排除是否完整、失败是否会形成循环。现有代码和租约提供部分保护，不据此声称全组合已验收。

### 20.5 用户体感慢与业务有效率需要分开测

1 秒页间隔不会消除平台响应时间、身份核验、重复页、旧评论和低相关来源。应在同一时间窗口分开看：成功页、业务请求耗时、本地入账耗时、近期去重增量、最终有效线索增量、停止原因。没有这些证据不能保证「这段时间应该几万条」。

### 20.6 搜索并非可靠按最新评论排序

当前读取契约没有证明平台提供可用的评论最新排序。已有局部作品时间优先、关键词轮换和日期过滤，仍可能反复遇到旧内容。后续若研究新接口，应先独立小样、核官方/成熟实现、保护当前链路，不能擅自切生产接口。

### 20.7 分类时效和待核不能靠静态总数解决

30 天边界不断移动；快照应持续由本地 worker 刷新。用户可见数必须基于最新 hash 一致有效池，并区分可回复。未知、预算待定和未分析应留后台，不为了凑数贴高意向。

### 20.8 通知缺少手机送达闭环

手机渠道尚无经过本窗口验证的配置和送达记录。后续若用户要求停机手机提醒，应明确渠道和授权后做一次真实送达验证，不能只写规则或桌面消息就说完成。

### 20.9 不是一个已经完整商业交付的通用客户端

本窗口跑通和修复的是本机真实采集链路及其配套工具；不能把它扩张为跨电脑部署、所有账号自动切换、所有异常自动恢复、正式客户安装包、实际发送全链路均已通过。工坊客户版/UI 的其他历史属于别的窗口，本历程没有混入。

## 21. 接手者必须记住的业务口径

- 原始采集量、近期准入量、分类水位、有效中高意向、可回复、已发送，是六类不同数量。
- 视频不是评论，评论不是独立人数，来源门店不是意向门店，IP 属地不是求租地区。
- 时间、预算、双方意愿是高优先级；排序规则由语气窗口的认可版本维护。
- 当前原评论准入为精确滚动 30 天；90 天只是历史阶段。
- 过期和已锁定无效业务正文可按证据清理；日期未知/不确定/未分析不是随便删除的对象。
- 未知不重发，sent/unknown/reserved 不重置，历史 halt 不清空。
- 有完整反馈的本地故障可以本地幂等恢复；真实平台验证和身份异常仍需处理。
- 只读看窗口与启动采集不同，继续当前任务与开新轮不同，采集与发送授权不同。
- 代码、文件、进程、平台回执、用户认可分别核实；写盘不代表其他窗口已经读取。

## 22. 本次交付与变更范围

唯一写入文件：

`C:\Users\rmsama\Documents\ChatGPT\codex-briefs-20261110\douyin-cli-search-history.md`

所在目录：

`C:\Users\rmsama\Documents\ChatGPT\codex-briefs-20261110`

本次只读核对了统一要求、项目规则、相关源码入口、状态、日志末尾、路径存在性、分类产物 hash 和记录中的三个 PID。没有调用抖音页面、没有初始化账本、没有清理客户正文、没有消费新评论、没有发送消息、没有启动任何生产脚本，也没有改自动化。

未在本文保留客户原文、客户 ID/联系人、实际登录 UID、账号密码、Cookie、Token 或 Bridge 配置内容。路径供本机有权限的后续 AI 定位原工程；不得把配置文件正文当作可公开交接材料。
