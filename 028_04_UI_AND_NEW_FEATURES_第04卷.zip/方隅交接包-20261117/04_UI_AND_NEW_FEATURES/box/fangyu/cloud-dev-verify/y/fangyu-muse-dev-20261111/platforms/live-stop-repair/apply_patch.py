from pathlib import Path
import hashlib,json
S=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project')
T=Path(__file__).resolve().parent
changes=[]
def edit(relative,change):
    p=S/relative; before=p.read_bytes(); text=before.decode('utf-8'); after=change(text)
    assert after!=text,relative
    if p.suffix=='.py':compile(after,str(p),'exec')
    backup=T/'before'/relative; backup.parent.mkdir(parents=True,exist_ok=True)
    with backup.open('xb') as f:f.write(before)
    p.write_text(after,encoding='utf-8',newline='')
    changes.append({'path':relative,'before':hashlib.sha256(before).hexdigest(),'after':hashlib.sha256(p.read_bytes()).hexdigest()})
def replace(s,a,b):
    assert s.count(a)==1,(a[:100],s.count(a))
    return s.replace(a,b)

def adapter(s):
    return replace(s,"    facts=platform_failure_from_cli(code,{**diagnostics,**(observed or {})})", """    # The pinned SDK's generic HTTP461 also uses verification_required.
    # Only its explicit, populated challenge fields establish a captcha.
    # Never retain the challenge identifier or infer login expiry from HTTP.
    provider_message=error.get('message') if type(error) is dict else None
    if (code=='verification_required' and isinstance(provider_message,str)
            and len(provider_message)<=512 and re.fullmatch(
                r'Captcha required: type=[1-9][0-9]{0,5}, uuid=[A-Za-z0-9_-]{8,160}',provider_message)):
        diagnostics={**diagnostics,'auth_signal':'captcha_challenge'}
    facts=platform_failure_from_cli(code,{**diagnostics,**(observed or {})})""")
edit('work/ui-runtime-r55/src/core/adapters.py',adapter)

def customer(s):
    s=replace(s,'    def detail(self, user, store_id, ident, *, platform=None):','    def detail_context(self, user, store_id, ident, *, platform=None):')
    return replace(s,"            return {'actor':public,'scope':SCOPE,'id':ident,'item':item}","""            return actor,public,item,person

    def detail(self, user, store_id, ident, *, platform=None):
        _actor,public,item,_person=self.detail_context(user,store_id,ident,platform=platform)
        return {'actor':public,'scope':SCOPE,'id':ident,'item':item}""")
edit('work/ui-native-r57/customer_workbench.py',customer)

def reply(s):
    s=replace(s,"""        detail = self.customers.detail(user,store_id,customer_id,platform=platform)
        actor, public = self.customers._actor(user,store_id)
        person = self.customers._history(actor,store_id,platform).customer_detail(customer_id,actor)
        return actor, public, detail['item'], person""","""        return self.customers.detail_context(user,store_id,customer_id,platform=platform)""")
    s=replace(s,"""            comments = []
            for original in person.get('comments') or []:""","""            comments = []
            replies_by_lead={}
            for saved in self.core.store.list('replies',actor['tenant_id']):
                replies_by_lead.setdefault(saved.get('lead_id'),[]).append(saved)
            visible_accounts=[]
            for account in self.core.store.list('accounts',actor['tenant_id']):
                try:self.core._account_access(actor,account)
                except CoreError:continue
                if account.get('store_id') in (None,'',store_id):visible_accounts.append(account)
            for original in person.get('comments') or []:""")
    s=replace(s,"                reply = self._latest(actor,lead)","""                saved=replies_by_lead.get(lead['id'],[])
                if any(type(row.get('version')) is not int or row['version']<1 for row in saved):
                    fail('REPLY_VERSION_INVALID','历史草稿版本需核对',409)
                reply=max(saved,key=lambda row:(row['version'],row['id']),default=None)""")
    s=replace(s,"""                for account in self.core.store.list('accounts',actor['tenant_id']):
                    try: self.core._account_access(actor,account)
                    except CoreError: continue
                    if (account.get('platform')==lead.get('platform')
                            and account.get('store_id') in (None,'',store_id)):""","""                for account in visible_accounts:
                    if account.get('platform')==lead.get('platform'):""")
    return s
edit('work/ui-native-r57/reply_workbench.py',reply)

def backend(s):
    return replace(s,"""        with self.lock:
            if self.closed:raise WorkbenchError('BACKEND_CLOSED','本地服务已关闭',503)
            user,profile=self._identity(token)
            if data['storeId']!=self._selected_store(user,profile):
                raise WorkbenchError('STORE_FORBIDDEN','不能读取其他门店的图片',403)
        return self.customer_workbench.media(user,data['storeId'],data['leadId'],data['kind'])""","""        # Images must not hold the foreground lock while verifying over the
        # network. Each request has its own fresh verifier, with no token renew
        # or shared mutable identity cache. Public actions keep their verifier.
        if self.closed:raise WorkbenchError('BACKEND_CLOSED','本地服务已关闭',503)
        user,profile=self._identity(token,verification=_ReadOnlyDeliveryIntegrations(self.core))
        def current_scope():
            if self.closed:raise WorkbenchError('BACKEND_CLOSED','本地服务已关闭',503)
            current=self.core.session(token)
            if (not current or current.get('disabled')
                    or any(current.get(key)!=user.get(key) for key in
                        ('id','tenant_id','username','role','cloud_bound'))):
                raise WorkbenchError('AUTH_REQUIRED','员工登录已变化，请重新读取',401)
            # No _selected_store here: that helper activates central rules and
            # performs network I/O. Media only needs the exact visible scope.
            if data['storeId']!=self._load_selection(current,self._stores(profile))['storeId']:
                raise WorkbenchError('STORE_FORBIDDEN','不能读取其他门店的图片',403)
        with self.lock:current_scope()
        result=self.customer_workbench.media(user,data['storeId'],data['leadId'],data['kind'])
        with self.lock:current_scope()
        return result""")
edit('work/ui-native-r57/workbench_backend.py',backend)

def reply_ui(s):
    a="  if(row&&person){"
    b="""  if(!row&&v.selectedId){
    const preview=v.items.find(item=>item.id===v.selectedId);
    if(preview)editor=`<div class="rp-source-preview" aria-busy="${Boolean(v.detailLoading)}"><div class="rp-selected-source">${postCover(preview,'rp-post-thumbnail')}<strong>${esc(preview.postTitle||'原帖子')}</strong></div><div class="rp-person-summary">${customerAvatar(preview,'rp-detail-avatar')}<div class="rp-detail-copy"><strong>${esc(preview.name)}</strong><p>${esc(preview.quote||'')}</p></div></div><p class="rp-loading-note" role="status">${v.detailLoading?'正在加载已保存的草稿…':v.error?'草稿暂未读取，可重选客户重试。':'选择原评论后回复'}</p></div>`;
  }
  if(row&&person){"""
    s=replace(s,a,b)
    # A new selection cannot inherit a previous customer's unsaved text state.
    s=replace(s,"scope=actor(state);v.selectedId=id;v.detail=null;v.detailLoading=true;v.error='';ctx.update(()=>{});","scope=actor(state);v.selectedId=id;v.detail=null;v.leadId='';v.text='';v.dirty=false;v.detailLoading=true;v.error='';ctx.update(()=>{});")
    return s
edit('work/ui-approved-implementation/ui-preview/pages/reply-connected.mjs',reply_ui)

def acquire(s):
    s=replace(s,"||(blocked||failure?live.message||'当前暂不能开始，请在账号页查看连接状态。':'');","||(blocked||failure?live.message||'当前暂不能开始，请在账号页查看连接状态。':activeStatuses.includes(status)?'可切换回复、客户查看，采集会在后台继续；本次门店和条件已锁定。':'');")
    s=replace(s,":live.phase==='analyzing'&&status==='running'?'正在分析':liveStatus(status);",":live.platformError?.category==='verification_required'?'小红书要求验证码':live.platformError?.category==='platform_rejected'?'平台暂未允许继续读取':live.phase==='analyzing'&&status==='running'?'正在分析':liveStatus(status);")
    return s
edit('work/ui-approved-implementation/ui-preview/pages/acquire.mjs',acquire)

def css(s):
    return s+'''
/* Reply hierarchy: original post first, comment next, draft quieter. */
.reply-page.rp-connected .rp-post-name strong{font-size:22px;line-height:1.45;font-weight:650;white-space:normal;display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:2;overflow:hidden}
.reply-page.rp-connected .rp-selected-source strong{font-size:20px!important;line-height:1.45;font-weight:650;overflow-wrap:anywhere}
.reply-page.rp-connected .rp-detail-copy p{font-size:17px;line-height:1.65}
.reply-page.rp-connected .rp-composer textarea{font-size:14px;line-height:1.6}
.reply-page.rp-connected .rp-source-preview .rp-selected-source{display:flex;align-items:center;gap:12px;margin-bottom:16px!important}
.reply-page.rp-connected .rp-source-preview .rp-person-summary{display:flex;align-items:flex-start}
.reply-page.rp-connected .rp-loading-note{font-size:13px;line-height:1.6;color:#617a8c;margin-top:18px}
.shell[data-platform=douyin] .reply-page.rp-connected :is(.rp-empty,.rp-composer,.rp-editor-actions){background:#142c43;color:#dfedf8;border-color:#304c65}
.shell[data-platform=douyin] .reply-page.rp-connected .rp-empty{background:linear-gradient(145deg,#18354d,#11293f);border:1px solid #304c65}
.shell[data-platform=douyin] .reply-page.rp-connected :is(.rp-post-name strong,.rp-selected-source strong,.rp-person-title strong,.rp-detail-copy p,.rp-source-preview strong){color:#e6f3ff}
.shell[data-platform=douyin] .reply-page.rp-connected :is(.rp-empty span,.rp-loading-note,.rp-post-name span,.rp-source-controls label){color:#abc4d8}
.shell[data-platform=douyin] .reply-page.rp-connected .rp-comment.is-selected{background:#1b4058}
.shell[data-platform=douyin] .reply-page.rp-connected .rp-comment:hover{background:#1b384f}
.shell[data-platform=douyin] .reply-page.rp-connected :is(.rp-composer textarea,.rp-source-controls select){background:#122a40;color:#e6f3ff;border-color:#365771}
'''
edit('work/ui-approved-implementation/ui-preview/canvas-fit.css',css)
(T/'SOURCE-CHANGES.json').write_text(json.dumps(changes,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'changed':len(changes),'files':[x['path'] for x in changes]},ensure_ascii=False))
