# 电脑工作连接恢复修复与独立客户工作台交接

最新用户要求：Codex自用获客与交付客户的软件应分别成立，不能依赖逐次人工修补；只修客户版已有工程，不动其他客户/工坊核心/自用实例。回复本人手动，禁止自动发送。

本轮已完成：客户版v48 ui-r57-20261021T061549Z-dfd99b95；canonical launcher SHA ED49C8140582FD12366B05653B84EFA6D3197AE60C8B7AC561A9FC68C1056828。四源文件列CHANGED.json，before保留v47原字节；entry-v48/canonical-entry-before可恢复旧入口；冻结candidate不可修改。2733闭包和137入口文件校验通过。

根因：旧暂停任务有33条本机页队列待分析，模型任务却已completed/pending0；UI把旧analysis phase/pending当成电脑连接恢复禁令，导致已经绑定的电脑在重开后无法启动控制面心跳。

修复契约：已有正确员工绑定可在获客/账号页面每个员工每次页面生命周期自动恢复一次existingOnly连接；只启用已有控制面心跳。设备/员工/门店scope、未确认业务操作与活动任务守卫保留；不绑定新设备、不平台重登、不自动续采、不重发AI。普通网络错误仍由既有心跳1至30秒退避恢复；新增明确人工重新连接入口，拒绝假报online。已确认模型完成且无code/pending、页队列仅pending且同task/tenant/owner时允许用户主动新批次；未知模型、计费、身份不一致仍拦截，旧记录一字不改。

固定回归：test_reconnect.mjs覆盖旧分析、页面重开、轮询不重连、账号切换、网络失败状态释放及不假报在线；test_connection_ui.mjs覆盖重连按钮、状态与existingOnly动作；test_analysis_admission.py四项覆盖已确认与未知分析接纳边界。可设FANGYU_TEST_PROJECT指向待交付candidate/project，对冻结源码运行同一测试。exact frozen host/backend/Core/HTTP/SQLite原回归仍通过（synthetic identity/comments，不算实采）。已有新版本更新需执行这些检查，不能只跑源码或只更改入口。

实际运行已验：active.json和真实loopback均为v48，instance 348f1f10f9594ab9950b8eef79a3467e，PID 33392。用户明确回复“已重开，连接恢复了”。Computer Use已读取本机工作台56519的accessibility，获客页为采集中/正在分析；截图返回与目标窗口不一致，未采纳视觉截图，不可声称视觉验收。

真实采集已开始：用户自己从工作台启动新任务 2caaecfa0835455ea7cc6a4e02b32a80，古北店、小红书、采集账号仍为原选择；截至2026-10-21T06:18:52.280029+00:00，新任务34条原评论/20位唯一作者，30条有分析结果。UI较数据库略早一帧显示33条评论、当天19位客户/17位分析/1位高意向；评论数、作者数、客户显示数和分析条目数不可混为一谈。未中断这批任务、未点击发送、未代做认证。

当前任务仍在推进，不需重启/重建/重复采集。后续先读ACTUAL-LATEST.json与FINAL.json再按需运行observe_actual.py，只读绑定库，不输出凭证/Cookie/私密评论。全批完成、真实断网恢复、其他电脑安装、回复发送均未验收，不冒充全功能或跨客户发布完成。原Gubei1—12个月规则和46词保留；公司云端模型提示词未因本轮改变。最新实际状态优先于10月17旧STATUS和过期夜间自动化。
