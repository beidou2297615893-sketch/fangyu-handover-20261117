from pathlib import Path
import hashlib,json
H=Path(__file__).resolve().parent
S=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
test=json.loads((H/'INCREMENTAL-RESULT.json').read_text('utf-8'))
assert test['status']=='PASS_VERIFIED_RESUME_INCREMENTAL'
changes=json.loads((H.parent/'SOURCE-CHANGES.json').read_text('utf-8'))
files=[{'path':row['path'],'sha256':sha(S/row['path']),'declared_sha256_matches':sha(S/row['path'])==row['after']} for row in changes]
assert all(row['declared_sha256_matches'] for row in files)
review={'status':'PASS_VERIFIED_RESUME_INCREMENTAL_REVIEW','behavior_cases_pass':len(test['checks']),
 'python_readback_syntax_pass':len(test['syntax_checks']),'declared_change_hashes_pass':len(files),
 'source_files':files,'behavior_evidence':'INCREMENTAL-RESULT.json','old_red_evidence':'RESUME-RED.json',
 'source_sha256':test['source_sha256'],'real_platform_requests':0,'real_model_requests':0,'CLI_processes_started':0,
 'UI_operations':0,'real_credential_files_read':0,'production_writes':0,'product_edits_by_reviewer':0,
 'review_limits':['PageWorker used exact request/journal logic with fake in-memory IPC callbacks; original CLI was not started',
 'Runtime used exact selected methods with fake accounts/store/executor; no full backend/browser boot',
 'No actual CAPTCHA was completed and no real task was resumed',
 'Mixed/unfinished/unknown risk remains ineligible; this review does not clear original records or prove the actual account is currently recoverable']}
(H/'FINAL-REVIEW.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
old=json.loads((H/'RESULT.json').read_text('utf-8'));old['status']='CANDIDATE_INCREMENTAL_REVIEW_PASS'
old['candidate_review']='FINAL-REVIEW.json';old['candidate_behavior_cases_pass']=len(test['checks'])
old['investigation_resume_blocker_fixed_in_candidate']=True
old['source_evidence_note']='source_evidence hashes describe the initial read-only investigation; current candidate hashes are in FINAL-REVIEW.json'
(H/'RESULT.json').write_text(json.dumps(old,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
report=(H/'REPORT.md').read_text('utf-8').split('\n## 候选修复后的独立增量审查')[0]
report+='''
## 候选修复后的独立增量审查

上面的只读调查与红样例描述修复前问题。根作者随后增加严格已验证续行grant；当前候选新增31项隔离行为全部通过，6个修改Python从实际保存字节编译通过，10个声明改动hash与当前实物一致。

实际验证的是新 verified_pages、captcha_receipt、PageWorker.request，以及从源码直接提取的runtime相关方法。接口使用合成账号/活动日志、假HOME和内存IPC事件，没有启动原CLI或浏览器，也没有平台/模型请求。原CLI本轮未修改、未重编。

严格验证包含：固定字符串schema_version="1"、ok=false、三键错误封包、两键error、重复JSON键/成功data/generic461拒绝；同UID/auth_generation与10分钟状态回执；未完成日志/新于验证的挑战拒绝；旧原页先归档再授权wire；原件及parent SHA保存；新结果重复读取不重发；新attempt的wire-unknown重启仍拒绝；再次挑战需要新验证；scope/task/args/credential/原件SHA/期限/协议保护；每wire核两项会话generation；本地返回丢失可复用已确认身份回执，无窗口时不会隐式开启或探测。

FINAL-REVIEW.json和INCREMENTAL-RESULT.json记录本次源码精确hash与验证范围。原RESUME-RED.json继续保留。没有实际完成人工验证码或继续真实任务；混杂、未完成和未知风险仍不放行，因此不能据隔离通过承诺当前真实账号必然可恢复。
'''
(H/'REPORT.md').write_text(report,encoding='utf-8')
print(json.dumps({'status':review['status'],'cases':len(test['checks']),'syntax':len(test['syntax_checks']),'hashes':len(files)},ensure_ascii=False))
