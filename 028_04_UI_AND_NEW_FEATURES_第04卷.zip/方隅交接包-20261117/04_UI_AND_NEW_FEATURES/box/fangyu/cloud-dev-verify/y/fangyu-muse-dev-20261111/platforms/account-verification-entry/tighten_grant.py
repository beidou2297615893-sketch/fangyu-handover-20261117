from pathlib import Path
import hashlib,json
T=Path(__file__).resolve().parent
S=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project')
def rep(rel,old,new):
 p=S/rel;b=p.read_text('utf-8');assert b.count(old)==1,(old,b.count(old));b=b.replace(old,new);compile(b,str(p),'exec');p.write_bytes(b.encode('utf-8'))
r='work/ui-runtime-r55/src/core/xhs_verified_resume.py'
rep(r,'def captcha_receipt(value):', '''def _unique(pairs):
    value={}
    for key,item in pairs:
        if key in value:raise ValueError('duplicate key')
        value[key]=item
    return value


def captcha_receipt(value):''')
rep(r,"not in ('search','comments','sub-comments','read')","not in ('search','comments','sub-comments')")
rep(r,"try:payload=json.loads(result['stdout'])","try:payload=json.loads(result['stdout'],object_pairs_hook=_unique)")
rep(r,"if type(payload) is not dict or payload.get('ok') is not False:return False","if (type(payload) is not dict or set(payload)!={'ok','schema_version','error'}\n            or payload.get('ok') is not False or payload.get('schema_version')!='1'):return False")
rep(r,"return bool(type(error) is dict and error.get('code')=='verification_required'","return bool(type(error) is dict and set(error)=={'code','message'} and error.get('code')=='verification_required'")
r='work/ui-runtime-r55/src/core/xhs_page_process.py'
rep(r,'import queue\n','import queue\nimport re\n')
rep(r,"and grant.get('task')==self.job_id and grant.get('scope')==self.scope","and re.fullmatch(r'[a-f0-9]{32}',str(grant.get('generation') or ''))\n                        and re.fullmatch(r'[a-f0-9]{64}',str(grant.get('account_revision') or ''))\n                        and grant.get('task')==self.job_id and grant.get('scope')==self.scope")
r='work/shared-backend-integration/platform_runtime.py'
rep(r,"            if tuple(account.get(k) for k in ('id','tenant_id','cloud_owner','store_id','platform','platform_uid'))!=identity:\n                raise PlatformRuntimeError('ACCOUNT_SCOPE_CHANGED','原采集账号已变化')","            if tuple(account.get(k) for k in ('id','tenant_id','cloud_owner','store_id','platform','platform_uid'))!=identity:\n                raise PlatformRuntimeError('ACCOUNT_SCOPE_CHANGED','原采集账号已变化')\n            if control.get('verified_retry') and any(account.get(k)!=original.get(k) for k in ('auth_generation','identity_revalidation_generation')):\n                raise PlatformRuntimeError('ACCOUNT_SCOPE_CHANGED','验证后的账号会话已变化，采集停止')")
changes=json.loads((T/'SOURCE-CHANGES.json').read_text('utf-8'))
for row in changes:row['after']=hashlib.sha256((S/row['path']).read_bytes()).hexdigest()
(T/'SOURCE-CHANGES.json').write_bytes((json.dumps(changes,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
print('STRICT_ENVELOPE_AND_GENERATION_BOUND')
