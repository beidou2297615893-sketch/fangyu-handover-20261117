from pathlib import Path
import hashlib,json
T=Path(__file__).resolve().parent;S=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project')
changed=json.loads((T/'AUTO-CHANGES.json').read_text('utf-8'))
def edit(rel,fn):
 p=S/rel;old=p.read_bytes();new=fn(old.decode('utf-8')).encode('utf-8');assert new!=old
 backup=T/'auto-before'/rel;backup.parent.mkdir(parents=True,exist_ok=True)
 with backup.open('xb') as f:f.write(old)
 p.write_bytes(new);changed.append({'path':rel,'before':hashlib.sha256(old).hexdigest(),'after':hashlib.sha256(new).hexdigest()})
def once(s,a,b):assert s.count(a)==1,(a[:70],s.count(a));return s.replace(a,b)
def notice(s):
 s=once(s,"点“去验证”打开此账号的小红书网页。完成验证后保持网页打开，再点“验证完成，继续原任务”。",'正在打开此账号受阻的小红书页面；请本人完成验证，通过后会自动继续采集。')
 s=once(s,'点“去验证”完成此账号登录，再点“验证完成，继续原任务”；账号状态会在核对后同步。','正在打开原账号网页；登录完成后会自动核对并续采。')
 s=once(s,"accountId:a.taskScope?.accountId||''", "accountId:a.taskScope?.accountId||'',verificationId:a.verificationId||'',verification:a.verification||{}")
 s=once(s,'[identity(s),n.id,n.taskId,n.accountId]','[identity(s),n.id,n.taskId,n.accountId,n.category,n.verificationId]')
 s=once(s,"      const message=kind==='open'?'原账号窗口正在打开；完成验证后保持窗口打开，再点下面的继续按钮。':'续行请求已提交，请查看获客进度。';", "      if(kind==='open'){state.verificationCollapsedKeys||={};state.verificationCollapsedKeys[key]=true;}\n      const message=kind==='open'?'已打开小红书；完成验证后会自动核对并继续。':'续行请求已提交，请查看获客进度。';")
 start=s.index('export function updatePlatformNotice(');end=s.index('export function createCollectionMonitor(',start)
 s=s[:start]+r'''export function createAutomaticVerification({state,act,blocked=()=>false}){
  let scope='',seen=new Set();
  return {sync(){
    const current=identity(state);if(current!==scope){scope=current;seen=new Set();}
    if(state.busy||blocked())return;
    const targets=platformNotices(state).filter(n=>n.id==='xiaohongshu'&&n.accountId
      &&n.verificationId&&['verification_required','authentication_required'].includes(n.category));
    for(const n of targets){
      const key=noticeKey(state,n);if(seen.has(key))continue;seen.add(key);
      Promise.resolve().then(()=>{if(identity(state)===current)return act('open',n);}).catch(()=>{});
    }
  }};
}
export function updatePlatformNotice(s,host,onAccount,onVerify){
  if(!host)return;
  const notices=platformNotices(s),collapsed=n=>Boolean(s.verificationCollapsedKeys?.[noticeKey(s,n)]);
  const key=JSON.stringify([identity(s),notices,s.verificationAction,s.verificationCollapsedKeys,s.busy]);
  if(host.dataset.noticeKey===key)return;
  host.dataset.noticeKey=key;host.hidden=!notices.length;
  host.classList.toggle('is-collapsed',Boolean(notices.length&&notices.every(collapsed)));
  host.innerHTML=notices.map((n,index)=>{
    const action=s.verificationAction?.key===noticeKey(s,n)?s.verificationAction:null;
    const canVerify=onVerify&&n.id==='xiaohongshu'&&n.accountId&&['verification_required','platform_rejected','authentication_required'].includes(n.category);
    const disabled=action?.pending||s.busy?'disabled':'';
    const compact=collapsed(n),message=n.verification.message||action?.message;
    return `<section class="platform-alert ${compact?'is-compact':''}" role="status"><div class="platform-alert-heading"><strong>${esc(n.title)}</strong><button type="button" data-notice-toggle="${index}" aria-expanded="${!compact}">${compact?'展开':'收起'}</button></div>${compact?'':`<p>${esc(n.body)} 已读取的数据和断点已保留。</p>${message?`<p class="platform-alert-feedback" role="status">${esc(message)}</p>`:''}`}<div class="platform-alert-actions">${canVerify?`<button type="button" data-verify-action="open" data-notice-index="${index}" ${disabled}>${action?.pending&&action.kind==='open'?'正在打开…':'显示验证窗口'}</button>${compact?'':`<button type="button" data-verify-action="resume" data-notice-index="${index}" ${disabled}>${action?.pending&&action.kind==='resume'?'正在核对并续行…':'验证完成，立即核对'}</button>`}`:`<button type="button" data-platform-notice="${n.id}">查看账号</button>`}</div></section>`;
  }).join('');
  host.querySelectorAll('[data-platform-notice]').forEach(button=>button.addEventListener('click',()=>onAccount(button.dataset.platformNotice)));
  host.querySelectorAll('[data-verify-action]').forEach(button=>button.addEventListener('click',()=>onVerify(button.dataset.verifyAction,notices[Number(button.dataset.noticeIndex)])));
  host.querySelectorAll('[data-notice-toggle]').forEach(button=>button.addEventListener('click',()=>{
    const n=notices[Number(button.dataset.noticeToggle)];if(!n)return;
    s.verificationCollapsedKeys||={};const k=noticeKey(s,n);
    s.verificationCollapsedKeys[k]=!s.verificationCollapsedKeys[k];host.dataset.noticeKey='';updatePlatformNotice(s,host,onAccount,onVerify);
  }));
}
''' +s[end:]
 s=once(s,"const targets=()=>snapshots(state).filter(([id,p])=>running.has(p.acquisition.status)\n    &&(id!==(state.activePlatform||'xiaohongshu')||!['acquire','accounts'].includes(state.page)));", "const targets=()=>snapshots(state).filter(([id,p])=>(running.has(p.acquisition.status)\n    ||['verification_required','authentication_required'].includes(p.acquisition.platformError?.category))\n    &&(id!==(state.activePlatform||'xiaohongshu')||!['acquire','accounts'].includes(state.page)));")
 return s
edit('work/ui-approved-implementation/ui-preview/platform-notice.mjs',notice)
def app(s):
 s=once(s,'updatePlatformNotice,createCollectionMonitor,createVerificationActions','updatePlatformNotice,createCollectionMonitor,createVerificationActions,createAutomaticVerification')
 s=once(s,'},verificationAction);}', '},verificationAction);automaticVerification.sync();}')
 needle='const collectionMonitor=createCollectionMonitor('
 s=once(s,needle,"const automaticVerification=createAutomaticVerification({state,act:verificationAction,blocked:()=>backend.unconfirmed||Boolean(state.pendingAction?.unconfirmed)});\n"+needle)
 return s
edit('work/ui-approved-implementation/ui-preview/app.mjs',app)
def css(s):
 s=once(s,'.platform-notice-host[hidden]{display:none}',r'''.platform-notice-host{pointer-events:none}
.platform-notice-host>.platform-alert{pointer-events:auto}
.platform-notice-host.is-collapsed{top:auto;bottom:24px;transform:translateX(-50%);width:max-content;max-width:calc(100vw - 48px)}
.platform-alert-heading{display:flex;align-items:center;justify-content:space-between;gap:20px}
.platform-alert-heading button{border:0;background:transparent;color:inherit;text-decoration:underline;text-underline-offset:3px;padding:6px 8px;cursor:pointer}
.platform-alert.is-compact{display:flex;align-items:center;gap:20px;padding:10px 16px}
.platform-alert.is-compact .platform-alert-actions{margin:0}
.platform-notice-host[hidden]{display:none}''')
 return s
edit('work/ui-approved-implementation/ui-preview/canvas-fit.css',css)
(T/'AUTO-CHANGES.json').write_text(json.dumps(changed,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'changed_files':len(changed)}))
