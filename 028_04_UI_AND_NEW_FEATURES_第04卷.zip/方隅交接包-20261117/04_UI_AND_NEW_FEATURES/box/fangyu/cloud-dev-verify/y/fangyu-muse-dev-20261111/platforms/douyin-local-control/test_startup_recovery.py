"""Offline checks: no browser, publishing, or production ledger access."""
import importlib.util
import json
import pathlib
import tempfile
import unittest
from unittest.mock import Mock

import control


class StartupRecoveryTests(unittest.TestCase):
    def test_transient_windows_file_lock_is_retried(self):
        from unittest.mock import patch
        import startup_recovery
        source=control.ROOT/'work/douyin-local-20261104-94e62190af'
        with tempfile.TemporaryDirectory() as td:
            folder=pathlib.Path(td)
            for name in ('batch_reply_runner.py','resume_after_confirmation.py','send_cli_once.cjs'):
                (folder/name).write_bytes((source/name).read_bytes())
            startup_recovery.upgrade_task(folder)
            spec=importlib.util.spec_from_file_location('offline_save_runner',folder/'batch_reply_runner.py')
            runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
            real_replace=runner.os.replace
            calls=[]
            def retry_replace(*args):
                calls.append(args)
                if len(calls)==1:raise PermissionError('busy')
                return real_replace(*args)
            with patch.object(runner.os,'replace',side_effect=retry_replace) as replace, patch.object(runner.time,'sleep'):
                runner.save(folder/'state.json',{'status':'ok'})
                self.assertEqual(replace.call_count,2)
                self.assertEqual(json.loads((folder/'state.json').read_text(encoding='utf-8'))['status'],'ok')

    def test_default_sender_goes_to_reservation_without_live_comment_scan(self):
        from unittest.mock import patch
        source=control.ROOT/'work/douyin-local-20261104-94e62190af/batch_reply_runner.py'
        spec=importlib.util.spec_from_file_location('offline_direct_runner',source)
        runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
        candidate={'cid':'123','uid':'456','video':'789','created':'2026-11-05',
                   'reply_priority':{'time_band':'近7天','key':[]}}
        def call(args):
            if args[-1]=='--identity':return {'verified':True,'account_uid':runner.ACCOUNT}
            self.assertEqual(pathlib.Path(args[1]).name,'prepare_verified.py')
            raise RuntimeError('offline reservation reached')
        with tempfile.TemporaryDirectory() as td,patch.object(runner,'HERE',pathlib.Path(td)), \
             patch.object(runner,'require_send_allowed'),patch.object(runner,'ledger_rows',return_value=[]), \
             patch.object(runner,'load',return_value={'prepared_by':'douyin-classification-ready-v1','items_sha256':'x','source_output_sha256':'x','priority_queue_sha256':'x'}), \
             patch.object(runner,'validate_queue',return_value=[candidate]),patch.object(runner,'run_json',side_effect=call):
            with self.assertRaisesRegex(RuntimeError,'offline reservation reached'):runner.execute()

    def test_three_page_timeouts_skip_without_reserving_or_stopping(self):
        import startup_recovery
        from unittest.mock import patch
        source = control.ROOT / 'work/douyin-local-20261104-94e62190af/batch_reply_runner.py'
        candidates = [{'cid': str(i), 'uid': 'u'+str(i), 'video': 'v', 'created':'2026-11-05',
            'reply_priority':{'time_band':'近7天','key':[]}} for i in range(3)]
        with tempfile.TemporaryDirectory() as td:
            folder = pathlib.Path(td)
            for filename in ('batch_reply_runner.py','resume_after_confirmation.py','send_cli_once.cjs'):
                (folder/filename).write_bytes((source.parent/filename).read_bytes())
            startup_recovery.upgrade_task(folder)
            spec = importlib.util.spec_from_file_location('offline_recovery_runner', folder/source.name)
            runner = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(runner)
            calls = []
            def fake_call(args):
                calls.append(args)
                if args[-1] == '--identity':
                    return {'verified': True, 'account_uid': runner.ACCOUNT}
                self.assertIn('--preflight', args)
                return {'status': 'target_check', 'diagnosis': {'incomplete':True,'read_timeout':True}}
            with patch.object(runner, 'HERE', folder), \
                 patch.object(runner, 'require_send_allowed'), \
                 patch.object(runner, 'ledger_rows', return_value=[]), \
                 patch.object(runner, 'load', return_value={'prepared_by':'douyin-classification-ready-v1', 'items_sha256':'test','source_output_sha256':'test','priority_queue_sha256':'test','live_preflight':True}), \
                 patch.object(runner, 'validate_queue', return_value=candidates), \
                 patch.object(runner, 'run_json', side_effect=fake_call):
                runner.execute()
            status=json.loads((folder/'batch-runner-status.json').read_text(encoding='utf-8'))
            self.assertEqual(status['status'],'queue_partial')
            self.assertEqual(status['confirmed_sent'],0)
            self.assertEqual(len(calls), 4)
            self.assertFalse(any(folder.glob('*.submitted')))

    def test_transient_probe_recovers_once_and_refreshes_identity(self):
        probe = Mock(side_effect=[RuntimeError('未找到可用的已登录抖音连接'), {'nickname': 'test'}])
        ensure = Mock()
        sleep = Mock()
        self.assertEqual(control.connect_for_start(probe, ensure, sleep), {'nickname': 'test'})
        self.assertEqual(probe.call_count, 2)
        self.assertEqual(ensure.call_count, 2)

    def test_account_conflict_is_never_retried(self):
        probe = Mock(side_effect=RuntimeError('检测到多个不同账号，请只保留本任务的抖音连接'))
        with self.assertRaisesRegex(RuntimeError, '多个不同账号'):
            control.connect_for_start(probe, Mock(), Mock())
        self.assertEqual(probe.call_count, 1)

    def test_connection_failure_is_bounded_and_actionable(self):
        probe = Mock(side_effect=RuntimeError('未找到可用的已登录抖音连接'))
        with self.assertRaisesRegex(RuntimeError, '刷新'):
            control.connect_for_start(probe, Mock(), Mock())
        self.assertEqual(probe.call_count, 2)

    def test_migrate_all_existing_runner_variants_offline_idempotently(self):
        import startup_recovery
        base = pathlib.Path(control.ROOT) / 'work'
        sources = list(base.glob('douyin-local-*/batch_reply_runner.py'))
        sources.append(base / 'douyin-round2-task5/batch_reply_runner.py')
        self.assertGreaterEqual(len(sources), 6)
        for source in sources:
            with self.subTest(task=source.parent.name), tempfile.TemporaryDirectory() as td:
                task = pathlib.Path(td)
                (task / source.name).write_bytes(source.read_bytes())
                resume = source.parent / 'resume_after_confirmation.py'
                (task / resume.name).write_bytes(resume.read_bytes())
                (task/'send_cli_once.cjs').write_bytes((source.parent/'send_cli_once.cjs').read_bytes())
                startup_recovery.upgrade_task(task)
                first = (task / source.name).read_text(encoding='utf-8')
                self.assertNotIn('consecutive_read_timeouts', first)
                self.assertIn("'submission_attempted': False", first)
                self.assertIn('recover_preflight(HERE, ACCOUNT', first)
                self.assertIn("if manifest.get('live_preflight', False):",first)
                self.assertIn("'live_target_check_performed': False",first)
                self.assertIn("'queue_partial' if read_timeout_skips", first)
                self.assertNotIn("print('本轮评论列表未找到该目标，暂跳过。'", first)
                compile(first, str(source), 'exec')
                startup_recovery.upgrade_task(task)
                self.assertEqual(first, (task / source.name).read_text(encoding='utf-8'))


if __name__ == '__main__':
    unittest.main()
