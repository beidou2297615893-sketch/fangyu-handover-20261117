from pathlib import Path
import hashlib,json,importlib.util,sys
sys.dont_write_bytecode=True
T=Path(__file__).resolve().parent
P=Path('C:/积木软件工坊/项目/方隅公寓客户版');F=P/'work/parallel-integration-20261018/final-integration'
S=F/'stage-02/project';C=F/'candidate-unified-v27';PROJECT=C/'project';N=P/'work/ui-native-r57'
read=lambda p:json.loads(p.read_text('utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n','utf-8')
before=read(F/'candidate-unified-v26/INPUT-SNAPSHOT.json')['files'];after=read(C/'INPUT-SNAPSHOT.json')['files']
changed={k for k in before.keys()|after.keys() if before.get(k)!=after.get(k)}
expected={p.relative_to(T/'before').as_posix() for p in (T/'before').rglob('*') if p.is_file()}
assert changed==expected,(changed-expected,expected-changed)
for k in changed:
    assert sha(T/'before'/k)==before[k],k
    assert sha(S/k)==after[k] and sha(PROJECT/k)==after[k],k
pins=read(C/'UNIFIED-PINS.json')
for row in pins['files']:
    p=PROJECT/row['path'];assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],row['path']
guard='work/speed-collection-worker/component/artifacts/platform-cli-guarded/guard-manifest.json'
assert (PROJECT/guard).read_bytes()==(F/'candidate-unified-v26/project'/guard).read_bytes()
assert sha(N/'run_workbench.py')==read(F/'entry-v26/CANONICAL-DELEGATION-PREPARED.json')['launcher_sha256'].lower()
binding=sha(N/'state/production-workspace.json').upper()
assert binding=='14CF53964F5D44D123E989805EA741669AB3F05054E730DDCB299A0AAC51A9CB'
assert sha(PROJECT/'work/ui-native-r57/state/production-workspace.json').upper()==binding
staged=read(C/'STAGED.json');release=Path(staged['release']);manifest=read(release/'RELEASE.json')
assert sha(release/'RELEASE.json').upper()==staged['manifest_sha256'].upper()
files={r['path']:r for r in manifest['files']}
for key in ('reply_delivery.py','web/pages/reply-delivery.mjs','web/pages/acquisition-help.mjs'):
    assert key in files,key
validation={'status':'PASS_CROSS_ACCOUNT_AND_ACCOUNT_CREATE','files':len(pins['files']),
    'changed':sorted(changed),'isolated_behavior_and_queue_tests':24,
    'local_http_test':'PASS_AFTER_LOCALHOST_SANDBOX_RETRY',
    'js_syntax':'PASS_ALL_MODULES','calendar_and_verification_regressions':'PASS',
    'real_sends':0,'real_collection':0,'real_login':0,'douyin_live_cli_tested':False,
    'native_UI_visual_review':'USER_TO_TEST_AFTER_NORMAL_REOPEN'}
write(T/'VALIDATION.json',validation)
spec=importlib.util.spec_from_file_location('existing_entry_builder',N/'freeze_ui.py')
builder=importlib.util.module_from_spec(spec);spec.loader.exec_module(builder)
body=builder.launcher_source(staged['release_id'],staged['manifest_sha256'],files['ui_native_host.py']['sha256'],files['lifecycle_log.py']['sha256'])
needle="RELEASE = ROOT / 'releases/"+staged['release_id']+"'";assert body.count(needle)==1
body=body.replace(needle,"PROJECT_ROOT = ROOT.parent.parent / 'work/parallel-integration-20261018/final-integration/candidate-unified-v27/project'\nRELEASE = PROJECT_ROOT / 'work/ui-native-r57/releases/"+staged['release_id']+"'\nBINDING_SHA256 = '"+binding+"'")
assert body.count('project_root=ROOT.parent.parent')==1
body=body.replace('project_root=ROOT.parent.parent','project_root=PROJECT_ROOT')
needle="        pinned(RELEASE / 'RELEASE.json', MANIFEST_SHA256)";assert body.count(needle)==1
body=body.replace(needle,"        pinned(ROOT / 'state/production-workspace.json', BINDING_SHA256)\n        pinned(PROJECT_ROOT / 'work/ui-native-r57/state/production-workspace.json', BINDING_SHA256)\n"+needle)
compile(body,'run_workbench.py','exec')
launcher=N/('run_delegated_candidate.'+staged['release_id']+'.py')
with launcher.open('xb') as out:out.write(body.encode('utf-8'))
entry=F/'entry-v27';entry.mkdir(exist_ok=False)
plan={'status':'PREPARED_NOT_INSTALLED','release_id':staged['release_id'],'release':staged['release'],
    'manifest_sha256':staged['manifest_sha256'],'launcher':str(launcher),'launcher_sha256':sha(launcher).upper(),
    'expected_previous_launcher_sha256':sha(N/'run_workbench.py').upper(),'expected_previous_frozen_sha256':sha(N/'FROZEN.json').upper(),
    'runtime_project_root':str(PROJECT),'installation_state_root':str(N/'state'),'workspace_binding_sha256':binding,
    'full_closure_files_verified':len(pins['files']),'full_closure_manifest_sha256':sha(C/'UNIFIED-PINS.json').upper(),
    'validation':str(T/'VALIDATION.json'),'installed':False,'component_use_policy':'pending',
    'production_cloud_activation':False,'compiled_cli_executed':False,'production_data_migration':False}
write(entry/'CANONICAL-DELEGATION-PREPARED.json',plan)
write(T/'CHANGES.json',[{'path':k,'before':before[k],'after':after[k]} for k in sorted(changed)])
print(json.dumps({'prepared':True,'release':staged['release_id'],'files':len(pins['files']),'changes':len(changed)}))
