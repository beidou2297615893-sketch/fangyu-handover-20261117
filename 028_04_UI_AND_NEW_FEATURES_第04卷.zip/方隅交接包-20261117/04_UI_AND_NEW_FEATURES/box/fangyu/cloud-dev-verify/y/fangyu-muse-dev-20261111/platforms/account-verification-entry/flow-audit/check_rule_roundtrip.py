from pathlib import Path
import json,os,re,subprocess
T=Path(__file__).resolve().parent;P=Path('C:/积木软件工坊/项目/方隅公寓客户版')
S=P/'work/parallel-integration-20261018/final-integration/stage-02/project'
C=S/'work/overnight-integration/cloud-candidate'
body=(C/'rule_bundle.test.cjs').read_text('utf-8')
body=re.sub(r"require\('(\./[^']+)'\)",lambda m:'require('+json.dumps((C/m[1]).resolve().as_posix(),ensure_ascii=False)+')',body)
body=body.replace("require('../../central-store-config/catalog_build.cjs')",'require('+json.dumps((P/'work/central-store-config/catalog_build.cjs').as_posix(),ensure_ascii=False)+')')
test=T/'rule_bundle_candidate.test.cjs';test.write_text(body,encoding='utf-8')
r=subprocess.run(['node','--test','--test-name-pattern=representative service route|upload limits|CAS conflict',str(test)],capture_output=True,encoding='utf-8',errors='replace',env={**os.environ,'PYTHONIOENCODING':'utf-8'},timeout=60)
(T/'RULE-ROUNDTRIP.log').write_text(r.stdout+r.stderr,encoding='utf-8')
(T/'RULE-ROUNDTRIP.json').write_text(json.dumps({'passed':r.returncode==0,'actual_current_candidate_service':True,'temporary_in_memory_store':True,'production_rule_writes':0}),encoding='utf-8')
print(json.dumps({'passed':r.returncode==0,'summary':(r.stdout+r.stderr)[-1800:]},ensure_ascii=True))
assert r.returncode==0
