from pathlib import Path
import json,sqlite3,hashlib,sys,datetime,collections,re
from urllib.parse import urlsplit,parse_qs
sys.dont_write_bytecode=True
P=Path('C:/积木软件工坊/项目/方隅公寓客户版');H=Path('C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/live-stop-repair/collection-audit');V=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v17/project';sys.path.insert(0,str(V/'work/ui-runtime-r55/src'))
from core.adapters import Adapters
from assistant.xhs_cli_page_worker import digest,page_key
observed=json.loads((H/'LATEST-REAL.json').read_text('utf-8'));b=json.loads((P/'work/ui-native-r57/state/production-workspace.json').read_text('utf-8'));db=sqlite3.connect((Path(b['data_dir'])/'workspace.sqlite3').as_uri()+'?mode=ro',uri=True);db.execute('PRAGMA query_only=ON');user=json.loads(db.execute("SELECT body FROM records WHERE entity='users' AND json_extract(body,'$.username')=?",(b['owner'],)).fetchone()[0]);tenant=user['tenant_id'];zone=datetime.timezone(datetime.timedelta(hours=8));safe=lambda r,ks:{k:r.get(k) for k in ks if k in r};results=[]
def each(value):
 if isinstance(value,dict):
  yield value
  for item in value.values():yield from each(item)
 elif isinstance(value,list):
  for item in value:yield from each(item)
for old in observed['tasks'][:3]:
 tid=old['task']['id'];task=json.loads(db.execute("SELECT body FROM records WHERE entity='tasks' AND tenant_id=? AND id=? AND json_extract(body,'$.cloud_owner')=?",(tenant,tid,b['owner'])).fetchone()[0]);pages=[json.loads(Path(row['file']).read_text('utf-8')) for row in old['page_receipts']];pages.sort(key=lambda r:r['created_at']);notes=[];rawroots=[];cursorvalues={''};commentrows=[]
 for value in each(task.get('pipeline') or {}):
  for key in ('cursor','next_cursor','sub_comment_cursor'):
   if isinstance(value.get(key),str):cursorvalues.add(value[key])
 for page in pages:
  payload=json.loads((page.get('result') or {}).get('stdout') or '{}')
  if page['operation']=='search' and page.get('result',{}).get('returncode')==0:notes.extend(Adapters.map_items(payload,'xhs_v1','xiaohongshu'))
  if page['operation']=='comments' and page.get('result',{}).get('returncode')==0:
   raw=payload.get('data') or {};cursorvalues.add(raw.get('cursor',''));rawroots.extend(raw.get('comments') or [])
   for root in raw.get('comments') or []:
    if isinstance(root.get('sub_comment_cursor'),str):cursorvalues.add(root['sub_comment_cursor'])
 original_notes=list(notes)
 for note in (task.get('pipeline') or {}).get('notes') or []:
  if note.get('url'):notes.append(note)
 urls=list(dict.fromkeys(note.get('url') or note.get('note_url') for note in notes if note.get('url') or note.get('note_url')))
 stats=[]
 for page in pages:
  matches=[]
  if page['operation']=='search':
   candidates=[(['search',word,'--json','--page',str(number)],None) for word in task.get('keywords') or [] for number in [1,2,3]]
  elif page['operation']=='comments':
   candidates=[(['comments',url,'--json']+(['--cursor',cursor] if cursor else []),url) for url in urls for cursor in cursorvalues]
  else:
   rootids=list(dict.fromkeys([str(root.get('id')) for root in rawroots if root.get('id')]+[str(root.get('id')) for root in (task.get('pipeline') or {}).get('reply_queue') or [] if root.get('id')]))
   candidates=[]
   for url in urls:
    noteid=urlsplit(url).path.rstrip('/').split('/')[-1];token=parse_qs(urlsplit(url).query).get('xsec_token',[''])[0]
    for rootid in rootids:
     for cursor in cursorvalues:
      args=['sub-comments',noteid,rootid,'--json']+(['--cursor',cursor] if cursor else [])+(['--xsec-token',token] if token else [])
      candidates.append((args,url))
  for args,url in candidates:
   try:ok=page_key(args)==page['page'] and digest(args)==page['args_digest']
   except ValueError:ok=False
   if ok:matches.append((args,url))
  row={'operation':page['operation'],'state':page['state'],'wire_allow_attempts':page.get('wire_allow_attempts'),'args_exact_reconstructed_matches':len(matches),'returncode':(page.get('result') or {}).get('returncode'),'created_local':datetime.datetime.fromtimestamp(page['created_at'],zone).isoformat(),'received_local':datetime.datetime.fromtimestamp(page.get('received_at',page['created_at']),zone).isoformat()}
  if matches:
   args,url=matches[0];params=parse_qs(urlsplit(url).query) if url else {};row.update(cursor_present='--cursor' in args,token_present=bool(params.get('xsec_token') or '--xsec-token' in args),source_present=bool(params.get('xsec_source')),origin_note_present_in_original_search=url is not None and any((note.get('url') or note.get('note_url'))==url for note in original_notes),token_preserved_from_same_original_note=('--xsec-token' not in args or args[args.index('--xsec-token')+1]==params.get('xsec_token',[''])[0]),source_origin_consistent_with_search=(not url or any(parse_qs(urlsplit(note.get('url') or note.get('note_url')).query).get('xsec_source')==params.get('xsec_source') and urlsplit(note.get('url') or note.get('note_url')).path==urlsplit(url).path for note in original_notes)))
   row['token_origin_consistent_with_search']=not url or any(parse_qs(urlsplit(note.get('url') or note.get('note_url')).query).get('xsec_token')==params.get('xsec_token') and urlsplit(note.get('url') or note.get('note_url')).path==urlsplit(url).path for note in original_notes)
   row['token_flag_present']='--xsec-token' in args
   row['source_flag_present']='--xsec-source' in args
   if page['operation']=='sub-comments':
    matching_roots=[root for root in rawroots if str(root.get('id'))==args[2]]
    row['root_belongs_to_same_note']=any(str(root.get('note_id'))==args[1] for root in matching_roots)
    row['cursor_matches_original_inline_replies']=('--cursor' not in args or any(root.get('sub_comment_cursor')==args[args.index('--cursor')+1] for root in matching_roots))
   if page['operation']=='comments' and row['returncode']==0:
    mapped=Adapters.map_comments(json.loads(page['result']['stdout']),url);commentrows.extend(mapped);dates=collections.Counter((r.get('published_at') or '')[:10] for r in mapped);row.update(mapped_comments=len(mapped),published_day_counts=dict(sorted(dates.items())),outside_selected_date=sum(not(task.get('date_from','')<=(r.get('published_at') or '')[:10]<=task.get('date_to','')) for r in mapped))
  payload=json.loads((page.get('result') or {}).get('stdout') or '{}');error=payload.get('error') or {};match=re.search(r'Captcha required: type=([0-9]+)',str(error.get('message','')));row['captcha_type']=int(match.group(1)) if match else None;stats.append(row)
 events=[r for r in old.get('recent_activity',[]) if r.get('stage') in ('started','finished')];starts={r['request_id']:r for r in events if r['stage']=='started'};wires=[];previous_start=previous_finish=None
 for event in events:
  if event['stage']!='finished':continue
  start=starts.get(event['request_id'],{}).get('at');finish=event['at'];wires.append({'kind':event['kind'],'method':event.get('method'),'status':event.get('status'),'start_local':datetime.datetime.fromtimestamp(start,zone).isoformat() if start else None,'finish_local':datetime.datetime.fromtimestamp(finish,zone).isoformat(),'start_interval_seconds':round(start-previous_start,3) if start and previous_start else None,'idle_since_previous_finish_seconds':round(start-previous_finish,3) if start and previous_finish else None,'elapsed_ms':event.get('elapsed_ms')});previous_start=start;previous_finish=finish
 audits=[]
 for r in db.execute("SELECT body FROM records WHERE entity='audit' AND tenant_id=?",(tenant,)):
  value=json.loads(r[0])
  if tid in json.dumps(value.get('detail'),ensure_ascii=False):audits.append(safe(value,['created_at','action','detail']))
 audits.sort(key=lambda r:r.get('created_at',''))
 results.append({'task_id':tid,'target_count':task['target_count'],'daily_limit':task['daily_limit'],'date_from':task.get('date_from'),'date_to':task.get('date_to'),'pause_reason':task.get('pause_reason'),'last_message':task.get('last_message'),'task_pipeline':safe(task.get('pipeline') or {},['note_index','browsed_notes','keyword_index','search_page','search_more']),'receipt':old['run_receipt'],'pages':stats,'wires':wires,'audit':audits,'actual_task_lead_count':db.execute("SELECT count(*) FROM records WHERE entity='leads' AND tenant_id=? AND json_extract(body,'$.cloud_owner')=? AND json_extract(body,'$.task_id')=?",(tenant,b['owner'],tid)).fetchone()[0]})
db.close();result={'status':'READ_ONLY_V17_LIVE_WIRE_AND_ORIGIN_AUDIT','active':observed['active'],'tasks':results,'new_platform_requests':0,'UI_operations':0,'DB_writes':0,'tokens_or_source_values_exported':False};(H/'WIRE-AND-ORIGIN.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(result,ensure_ascii=False,indent=2))
