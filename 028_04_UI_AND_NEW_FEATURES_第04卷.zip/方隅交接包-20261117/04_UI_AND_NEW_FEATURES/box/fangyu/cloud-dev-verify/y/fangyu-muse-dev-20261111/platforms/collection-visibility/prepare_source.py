from pathlib import Path
import shutil,json
T=Path(__file__).resolve().parent;S=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project')
changed=['work/ui-approved-implementation/ui-preview/pages/acquire.mjs','work/ui-approved-implementation/ui-preview/pages/acquire.css','work/shared-backend-integration/platform_runtime.py']
for name in changed:
 target=T/'before'/name;target.parent.mkdir(parents=True,exist_ok=True)
 if target.exists():raise RuntimeError('Backup already exists')
 shutil.copyfile(S/name,target)
(T/'CHANGED.json').write_text(json.dumps(changed,ensure_ascii=False,indent=2),'utf-8')
(T/'PLAN.md').write_text('客户版增量：获客页默认展示真实阶段、采集账号、已入库与分析数、最后进展和状态新鲜度；明确验证等待/状态未确认/平台拒绝。复用已有原账号验证窗口与刷新/暂停，不创建新登录或绕过。后台每个已确认采集单元后等待5秒，可取消、保存下一次读取时间；不重试未知请求，不模拟浏览/点赞、不改指纹/账号。测试跨公开render、snapshot observation及可取消wait接口，沿用既有授权和scope，不重复请求接口批准。v48源码三文件备份后改，冻结v49回归安装，保护真实库和断点。','utf-8')
print('Backed up three v48 source files; no runtime or data changes')
