# 采集过程可视化与读取负载调整交接

2026-10-21，北京时间。用户要求：采集/处理中/验证等待应能看见当前步骤；先搜GitHub和现有CLI再调整异常处理。随机浏览、点赞等伪装真人及规避核验未做，未发送真实评论/私信/点赞。

已修改客户版canonical源码stage-02/project三文件：pages/acquire.mjs、pages/acquire.css、shared-backend-integration/platform_runtime.py；CHANGED.json列精确路径，before保留v48原字节。不改工坊核心、自用、其他客户、CLI二进制、指纹或会话文件。

已实现：获客页默认展开真实进度面板，显示当前阶段、原任务采集账号、已保存/已分析/后台待分析数量、确认页数、最后进展与状态更新时间；时间按Asia/Shanghai显示；无百分比/假完成标记。平台明确验证时显示本人验证等待/核对/恢复与原账号窗口入口；裸platform_rejected不冒充验证。状态过期显示最后已知结果。刷新只调用原状态读取，任务条件折叠。身份/门店/平台不符不显示任务详情。

后台新增纯metadata observation，复用既有core progress/receipt/AI job时间，隐藏凭证/原命令。每个已确认采集单元结束后新增5秒可取消等待，next_read_at入原task-bound receipt并显示；暂停立即中断，取消/失败不重试原请求，等待结束移除并保存时间标志。不是每个HTTP请求的全局限速，不能保证免风控，未加入会话轮换/代理/模拟点赞。

已完成RED→GREEN测试：public render新面板；5项observation/暂停中断；原v48连接与分析接纳回归仍通过。新增F/test_visibility_frozen.py，exact frozen host/backend/Core/HTTP/SQLite合成身份回归通过（包括安全observation经真实认证HTTP返回），没有真实平台/AI/发送请求。冻结UI以Playwright在1280和900宽分别检查读取、验证、等待、状态过期，共8图无水平溢出，UI-QA.json及ui-qa/；这些是隔离合成任务，不能称实机平台验收。两张图已实际view_image查看。

已冻结并安装candidate-unified-v49，release ui-r57-20261021T071420Z-c66905ab，2733闭包/137入口校验通过。canonical launcher SHA 7506995F32AC7BE351D606621BEB7517351320B51C0F7B31B3D5AD2E1E7298FA（以entry-v49准备文件与安装记录中的实际SHA为准；文本摘要不代替机器校验）。备份F/entry-v49/canonical-entry-before为v48。安装仅替换canonical run_workbench.py和FROZEN.json，不写真实DB/账号/绑定。

实际窗口最后读到的是v48：小红书本次采集需验证，275条本任务评论；获客页，无草稿编辑。已告知保留断点正常重开新版，然后显示原账号验证入口。Computer Use尝试Alt+F4后返回仍有旧window id12719196，尚未确认关闭；随即再观察时工具明确回报用户按物理Escape停止。已停止电脑操作，不再调用Computer Use，不强杀进程、不继续重开、不点击核验。实际新版是否启动/可见未验证，当前窗口最终状态未知。

下一步必须等用户重新授权电脑操作（用户已停止本轮CU）。先读active.json和实际/__workbench_status，再用Computer Use重新枚举唯一目标；不要复用旧坐标/截图/索引。若仍v48，确认无活动采集/未保存草稿后正常关闭，从桌面“方隅工作台”原快捷方式重开v49，核对release并显示新面板。不要启动注册列表里旧安装器exe（它不是当前canonical入口）。人脸/验证码必须本人，且不能通过反复读取去试探核验是否通过。原existingOnly连接恢复、未知AI请求守卫、断点全部保留。

尚未验：新版本实际原生界面、真实5秒等待与暂停、实际验证恢复、采集持续吞吐/异常概率。不要把已安装/隔离测试通过写成这些已验收。

研究：已按agent-reach入口查询上游README、issue71、Crawlee官方API和MDN429；现有代码及许可/来源文件复用，不引入Crawlee框架或模拟模块。GitHub/全网查到的是风险说明、流量控制和异常处理，没有可靠免人脸承诺。Retry-After文档只作研究，本轮没有宣称实现响应头读取。
- https://github.com/jackwener/xiaohongshu-cli#rate-limiting--anti-detection
- https://github.com/jackwener/xiaohongshu-cli/issues/71
- https://crawlee.dev/js/api/basic-crawler/interface/BasicCrawlerOptions#maxRequestsPerMinute
- https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Status/429

其他既有待办：Gubei本地规则与云模型提示词尚未完全统一；全量二次AI复核不应覆盖人工确认，当前任务没有顺手发布公司级规则或新增付费模型调用。

