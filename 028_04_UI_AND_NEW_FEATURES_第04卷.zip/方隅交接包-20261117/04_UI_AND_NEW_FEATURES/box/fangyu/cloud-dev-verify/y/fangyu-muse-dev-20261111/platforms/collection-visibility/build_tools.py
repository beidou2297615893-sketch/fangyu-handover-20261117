from pathlib import Path
T=Path(__file__).resolve().parent;old=T.parent/'device-connection-repair';F=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration')
body=(old/'prepare_install.py').read_text('utf-8')
for before,after in [('candidate-unified-v48','candidate-unified-v49'),('candidate-unified-v47','candidate-unified-v48'),('21A9203A6C38FED5A4D1CB99DA9C4CB222A34C7A1D3BFE78376EA9FF7EC2AA35','ED49C8140582FD12366B05653B84EFA6D3197AE60C8B7AC561A9FC68C1056828'),('runtime-fixture-device-v48','runtime-fixture-visibility-v49'),('entry-v48','entry-v49'),('customer-only device recovery; no task replay; four source files','customer-only task observation and cancellable inter-unit spacing')]:
 assert before in body,before;body=body.replace(before,after)
with (T/'prepare_install.py').open('x',encoding='utf-8') as f:f.write(body)
body=(old/'install.py').read_text('utf-8').replace('entry-v48','entry-v49').replace('candidate-unified-v48','candidate-unified-v49')
with (T/'install.py').open('x',encoding='utf-8') as f:f.write(body)
body=(F/'test_gubei_frozen.py').read_text('utf-8')
needle="            trace.append('actual HTTP platform-scoped customer list and detail')"
assert body.count(needle)==1
body=body.replace(needle,needle+'''
            observed=request('GET','/api/workbench/platform?platform=xiaohongshu',headers=headers)
            assert observed['http']==200,observed['value']
            acquisition=observed['value']['platform']['acquisition']
            assert isinstance(acquisition['observation']['observedAt'],str)
            assert not any(key in acquisition['observation'] for key in ('cookie','token','request_id','command'))
            trace.append('actual authenticated HTTP exposes safe task observation with no platform request')
''')
with (F/'test_visibility_frozen.py').open('x',encoding='utf-8') as f:f.write(body)
print('Task-local v49 entry adapters and frozen HTTP observation regression created')
