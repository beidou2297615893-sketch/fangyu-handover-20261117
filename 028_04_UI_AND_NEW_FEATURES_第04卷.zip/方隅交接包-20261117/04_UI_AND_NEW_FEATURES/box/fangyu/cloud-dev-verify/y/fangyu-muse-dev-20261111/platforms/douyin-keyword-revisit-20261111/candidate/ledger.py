"""Offline Douyin result journal. No HTTP, browser, login, send or retry code.

`parsed` means structurally accepted input, never proof of live account identity.
The caller must solve runtime connection/account isolation before any live use.
"""
import argparse
import datetime
import hashlib
import json
import re
import sqlite3
from contextlib import closing, contextmanager
from pathlib import Path
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit
from scoped_recovery import initialize as initialize_reviews, effective_halt
from comment_retention import initialize as initialize_retention, fingerprint as retention_fingerprint, timestamp as retention_timestamp, expired as retention_expired


ROOT = Path(__file__).resolve().parent
SHARED_LEDGER = ROOT.parent / 'shared-acquisition-ledger' / 'shared.sqlite3'
RECENT_VERSION = 'recent-collection-20261104'
RECENT_90_VERSION = 'recent-collection-90-days-20261105'
# Current Asia/Shanghai civil time is UTC+08 year-round.
SHANGHAI = datetime.timezone(datetime.timedelta(hours=8))
SECRET = re.compile(r'cookie|authorization|token|password|secret|credential|sessionid|ms[_-]?token', re.I)
BLOCKING_STATES = frozenset(('unknown', 'verification_required', 'platform_error',
                             'connection_mismatch', 'invalid_response', 'stale_cursor', 'duplicate_page'))


def scrub(value):
    if isinstance(value, dict):
        return {k: '[REDACTED]' if SECRET.search(k) else scrub(v) for k, v in value.items()}
    if isinstance(value, list):
        return [scrub(v) for v in value]
    if isinstance(value, str) and value.startswith(('https://', 'http://')):
        parts = urlsplit(value)
        query = [(k, '[REDACTED]' if SECRET.search(k) else v) for k, v in parse_qsl(parts.query, keep_blank_values=True)]
        if any(SECRET.search(k) for k, _ in query):
            return urlunsplit((parts.scheme, parts.netloc, parts.path, urlencode(query), parts.fragment))
    return value


def encoded(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)


def stable_id(value):
    if not isinstance(value, str) or not re.fullmatch(r'[0-9]+', value):
        raise ValueError('stable numeric ID must arrive as a string; do not coerce lossy JS numbers')
    return value


def recent_time(item, observed_at):
    value = item.get('create_time')
    if isinstance(value, str) and re.fullmatch(r'[0-9]{1,10}', value):
        value = int(value)
    if type(value) is not int or not 0 < value <= observed_at.timestamp():
        return None
    published = datetime.datetime.fromtimestamp(value, SHANGHAI)
    return (observed_at.date() - published.date()).days, value


def shared_duplicates(ledger_path, ids):
    if not ids:
        return set()
    uri = ledger_path.resolve().as_uri() + '?mode=ro'
    with closing(sqlite3.connect(uri, uri=True, timeout=10)) as shared:
        placeholders = ','.join('?' for _ in ids)
        queries = [
            f"SELECT comment FROM {table} WHERE platform='douyin' AND comment IN ({placeholders})"
            for table in ('leads', 'reservations', 'historical_deliveries')
        ]
        return {row[0] for row in shared.execute(' UNION '.join(queries), ids * len(queries))}


class Ledger:
    def __init__(self, path, shared_ledger=None):
        self.path = Path(path).resolve()
        self.shared_ledger = shared_ledger if shared_ledger is not None else SHARED_LEDGER
        if not self.path.is_relative_to(ROOT):
            raise ValueError('database must remain inside this isolated project directory')
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self._db() as db:
            initialize_retention(db)
            db.executescript('''
                CREATE TABLE IF NOT EXISTS attempts(
                    request_id TEXT PRIMARY KEY, collected_at TEXT NOT NULL,
                    spec TEXT NOT NULL, response TEXT NOT NULL, digest TEXT NOT NULL,
                    state TEXT NOT NULL, detail TEXT NOT NULL, added INTEGER NOT NULL);
                CREATE TABLE IF NOT EXISTS items(
                    stable_key TEXT PRIMARY KEY, kind TEXT NOT NULL, source_id TEXT NOT NULL,
                    target TEXT NOT NULL, first_request TEXT NOT NULL, data TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS streams(
                    account_uid TEXT NOT NULL, kind TEXT NOT NULL, target TEXT NOT NULL,
                    cursor INTEGER NOT NULL, exhausted INTEGER NOT NULL, last_request TEXT NOT NULL,
                    PRIMARY KEY(account_uid,kind,target));
                CREATE TABLE IF NOT EXISTS pages(
                    account_uid TEXT NOT NULL, kind TEXT NOT NULL, target TEXT NOT NULL,
                    cursor INTEGER NOT NULL, request_id TEXT NOT NULL,
                    PRIMARY KEY(account_uid,kind,target,cursor));
                CREATE TABLE IF NOT EXISTS entities(
                    stable_key TEXT PRIMARY KEY, kind TEXT NOT NULL, source_id TEXT NOT NULL,
                    first_request TEXT NOT NULL, data TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS observations(
                    request_id TEXT NOT NULL, stable_key TEXT NOT NULL,
                    scan_id TEXT NOT NULL, account_uid TEXT NOT NULL, store_id TEXT NOT NULL,
                    keyword TEXT NOT NULL, kind TEXT NOT NULL, target TEXT NOT NULL,
                    collected_at TEXT NOT NULL, data TEXT NOT NULL,
                    PRIMARY KEY(request_id,stable_key));
                CREATE TABLE IF NOT EXISTS scan_streams(
                    scan_id TEXT NOT NULL, account_uid TEXT NOT NULL, kind TEXT NOT NULL,
                    target TEXT NOT NULL, store_id TEXT NOT NULL, keyword TEXT NOT NULL,
                    cursor INTEGER NOT NULL, exhausted INTEGER NOT NULL, last_request TEXT NOT NULL,
                    PRIMARY KEY(scan_id,account_uid,kind,target,store_id,keyword));
                CREATE TABLE IF NOT EXISTS scan_pages(
                    scan_id TEXT NOT NULL, account_uid TEXT NOT NULL, kind TEXT NOT NULL,
                    target TEXT NOT NULL, store_id TEXT NOT NULL, keyword TEXT NOT NULL,
                    cursor INTEGER NOT NULL, request_id TEXT NOT NULL,
                    PRIMARY KEY(scan_id,account_uid,kind,target,store_id,keyword,cursor));
                CREATE TABLE IF NOT EXISTS account_halts(
                    account_uid TEXT PRIMARY KEY, request_id TEXT NOT NULL,
                    state TEXT NOT NULL, detail TEXT NOT NULL, halted_at TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS recovery_events(
                    event_id INTEGER PRIMARY KEY, account_uid TEXT NOT NULL,
                    request_id TEXT NOT NULL, operator TEXT NOT NULL, reason TEXT NOT NULL,
                    rule_source TEXT NOT NULL, recovered_at TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS ledger_metadata(key TEXT PRIMARY KEY,value TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS recent_comment_page_counts(request_id TEXT PRIMARY KEY, counts TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS recent_comment_date_review(
                    request_id TEXT NOT NULL, cid TEXT NOT NULL, PRIMARY KEY(request_id,cid));
                CREATE TABLE IF NOT EXISTS recent_comment_backfill(
                    request_id TEXT NOT NULL, cid TEXT NOT NULL, account_uid TEXT NOT NULL,
                    age_days INTEGER NOT NULL, backfilled_at TEXT NOT NULL, PRIMARY KEY(request_id,cid));
                CREATE INDEX IF NOT EXISTS observations_by_stream
                    ON observations(scan_id,account_uid,kind,store_id,keyword,target);
                CREATE INDEX IF NOT EXISTS entities_by_kind ON entities(kind);
            ''')
            initialize_reviews(db)
            self._upgrade_legacy(db)

    def _upgrade_legacy(self, db):
        """Add indexes for this isolated database; never rewrite the old evidence tables.

        Legacy unresolved errors are conservatively blocked for manual review. Historical
        successful requests remain evidence, not proof that an earlier error was resolved.
        """
        db.execute('BEGIN IMMEDIATE')
        if db.execute("SELECT 1 FROM ledger_metadata WHERE key='associations_v1'").fetchone():
            return
        for row in db.execute('SELECT * FROM items'):
            key = ('video:' if row['kind'] == 'search' else 'comment:') + row['source_id']
            db.execute('INSERT OR IGNORE INTO entities VALUES(?,?,?,?,?)',
                       (key, row['kind'], row['source_id'], row['first_request'], row['data']))
        for row in db.execute('SELECT * FROM attempts ORDER BY collected_at,request_id'):
            spec = json.loads(row['spec'])
            if row['state'] == 'parsed':
                parsed = self._parse(spec, json.loads(row['response']))
                if parsed[0] == 'parsed':
                    for _, source_id, item in parsed[2]:
                        self._observe(db, spec, source_id, item, row['collected_at'])
            elif row['state'] in BLOCKING_STATES:
                db.execute('INSERT OR REPLACE INTO account_halts VALUES(?,?,?,?,?)',
                           (spec['account_uid'], row['request_id'], row['state'], row['detail'], row['collected_at']))
        db.execute("INSERT OR IGNORE INTO scan_streams SELECT 'legacy',account_uid,kind,target,'','',cursor,exhausted,last_request FROM streams")
        db.execute("INSERT OR IGNORE INTO scan_pages SELECT 'legacy',account_uid,kind,target,'','',cursor,request_id FROM pages")
        db.execute("INSERT INTO ledger_metadata VALUES('associations_v1','1')")

    @contextmanager
    def _db(self):
        db = sqlite3.connect(self.path, timeout=10)
        try:
            db.row_factory = sqlite3.Row
            db.execute('PRAGMA synchronous=FULL')
            with db:
                yield db
        finally:
            db.close()

    def summary(self):
        with self._db() as db:
            return dict(items=db.execute('SELECT COUNT(*) FROM entities').fetchone()[0],
                        comments=db.execute("SELECT COUNT(*) FROM entities WHERE kind='comments'").fetchone()[0],
                        observations=db.execute('SELECT COUNT(*) FROM observations').fetchone()[0],
                        halted_accounts=db.execute('SELECT COUNT(*) FROM account_halts').fetchone()[0],
                        attempts=db.execute('SELECT COUNT(*) FROM attempts').fetchone()[0],
                        states={row['state']: row['n'] for row in db.execute('SELECT state,COUNT(*) n FROM attempts GROUP BY state')})

    def checkpoint(self, account_uid, kind, target):
        with self._db() as db:
            row = db.execute('SELECT cursor,exhausted,last_request FROM streams WHERE account_uid=? AND kind=? AND target=?',
                             (account_uid, kind, target)).fetchone()
            return dict(row) if row else None

    @staticmethod
    def _scope(spec):
        return (spec.get('scan_id', 'legacy'), spec['account_uid'], spec['kind'],
                spec['target'], spec.get('store_id', ''), spec.get('keyword', ''))

    def scan_checkpoint(self, account_uid, kind, target, scan_id, store_id='', keyword=''):
        with self._db() as db:
            row = db.execute('''SELECT cursor,exhausted,last_request FROM scan_streams
                WHERE scan_id=? AND account_uid=? AND kind=? AND target=? AND store_id=? AND keyword=?''',
                (scan_id, account_uid, kind, target, store_id, keyword)).fetchone()
            return dict(row) if row else None

    def halt_status(self, account_uid):
        with self._db() as db:
            row = db.execute('SELECT * FROM account_halts WHERE account_uid=?', (account_uid,)).fetchone()
            return dict(row) if row else None

    def can_collect(self, account_uid):
        """Local stop gate only; caller must check BEFORE any platform request.

        This does not verify authorization, account ownership or network isolation.
        A caller must also serialize live requests; this method is not a request lease.
        """
        return self.halt_status(account_uid) is None

    def resume(self, account_uid, expected_request_id, operator, reason, rule_source):
        """Record an explicit human-review declaration, then clear exactly that halt.

        The caller must obtain manual review of unknown results / verification / limits
        and confirm account ownership. This API cannot verify that declaration. It never
        retries, alters an attempt, resets cursors, or treats an unknown result as failed.
        """
        if any(not isinstance(v, str) or not v.strip() for v in
               (account_uid, expected_request_id, operator, reason, rule_source)):
            raise ValueError('explicit account, triggering request, reviewer, reason and rule source required')
        with self._db() as db:
            db.execute('BEGIN IMMEDIATE')
            row = db.execute('SELECT * FROM account_halts WHERE account_uid=?', (account_uid,)).fetchone()
            if not row or row['request_id'] != expected_request_id:
                raise ValueError('active halt does not match reviewed request; no recovery performed')
            now = datetime.datetime.now(datetime.timezone.utc).isoformat()
            db.execute('INSERT INTO recovery_events(account_uid,request_id,operator,reason,rule_source,recovered_at) VALUES(?,?,?,?,?,?)',
                       (account_uid, expected_request_id, operator, reason, rule_source, now))
            db.execute('DELETE FROM account_halts WHERE account_uid=? AND request_id=?', (account_uid, expected_request_id))
            return dict(state='manually_resumed', account_uid=account_uid, request_id=expected_request_id)

    def _observe(self, db, spec, source_id, item, now):
        if spec['kind'] == 'comments':
            digest = retention_fingerprint(source_id)
            if db.execute('SELECT 1 FROM expired_comment_fingerprints WHERE digest=? UNION ALL SELECT 1 FROM excluded_comment_fingerprints WHERE digest=?', (digest,digest)).fetchone():
                return 0
            observed = datetime.datetime.now(SHANGHAI)
            published = retention_timestamp(item, observed)
            if published is not None and retention_expired(published, observed):
                db.execute('INSERT OR IGNORE INTO expired_comment_fingerprints VALUES(?)', (digest,))
                return 0
        key = ('video:' if spec['kind'] == 'search' else 'comment:') + source_id
        entity = db.execute('INSERT OR IGNORE INTO entities VALUES(?,?,?,?,?)',
                            (key, spec['kind'], source_id, spec['request_id'], encoded(item)))
        db.execute('INSERT OR IGNORE INTO observations VALUES(?,?,?,?,?,?,?,?,?,?)',
                   (spec['request_id'], key, spec.get('scan_id', 'legacy'), spec['account_uid'],
                    spec.get('store_id', ''), spec.get('keyword', ''), spec['kind'], spec['target'], now, encoded(item)))
        return entity.rowcount

    def _recent_rows(self, db, spec, rows, observed_at, repeated):
        extended = spec['recent_collection']['version'] == RECENT_90_VERSION
        admission_limit = spec['recent_collection'].get('admission_limit')
        counts = dict(within_15_days=0, days_16_to_30=0, expired=0, unknown=0,
                      deduplicated=0, today=0, yesterday=0, day_before_yesterday=0)
        if extended:
            counts.update(days_31_to_60=0, days_61_to_90=0, deferred_at_target=0)
        candidates = []
        for row in rows:
            _, cid, item = row
            timestamp = recent_time(item, observed_at)
            if timestamp is None:
                counts['unknown'] += 1
                db.execute('INSERT OR IGNORE INTO recent_comment_date_review VALUES(?,?)', (spec['request_id'], cid))
            elif observed_at.timestamp() - timestamp[1] > (90 if extended else 30) * 86400:
                counts['expired'] += 1
            else:
                candidates.append((timestamp, row))
        ids = tuple(sorted({row[1] for _, row in candidates}))
        duplicates = shared_duplicates(self.shared_ledger, ids) if not repeated else set()
        accepted = []
        for (age, _), row in sorted(candidates, key=lambda candidate: candidate[0][1], reverse=True):
            cid = row[1]
            if repeated or cid in duplicates or db.execute('SELECT 1 FROM expired_comment_fingerprints WHERE digest=? UNION ALL SELECT 1 FROM excluded_comment_fingerprints WHERE digest=?', (retention_fingerprint(cid),retention_fingerprint(cid))).fetchone() or db.execute('SELECT 1 FROM entities WHERE stable_key=?', ('comment:' + cid,)).fetchone():
                counts['deduplicated'] += 1
                continue
            duplicates.add(cid)
            if admission_limit is not None and len(accepted) >= admission_limit:
                counts['deferred_at_target'] += 1
                continue
            bucket = ('within_15_days' if age <= 15 else 'days_16_to_30' if age <= 30
                      else 'days_31_to_60' if age <= 60 else 'days_61_to_90')
            counts[bucket] += 1
            if age < 3:
                counts[('today', 'yesterday', 'day_before_yesterday')[age]] += 1
            accepted.append(row)
        db.execute('INSERT INTO recent_comment_page_counts VALUES(?,?)', (spec['request_id'], encoded(counts)))
        return accepted, counts

    def ingest(self, spec, response):
        required = ('request_id', 'account_uid', 'connection_id', 'kind', 'target', 'rule_source')
        if not isinstance(spec, dict) or any(not isinstance(spec.get(k), str) or not spec[k].strip() for k in required):
            raise ValueError('explicit request/account/connection/kind/target/rule_source required')
        if spec['kind'] not in ('search', 'comments'):
            raise ValueError('only search and top-level comments results are accepted')
        if type(spec.get('cursor')) is not int or spec['cursor'] < 0:
            raise ValueError('cursor must be an explicit non-negative integer')
        if spec['kind'] == 'comments':
            stable_id(spec['target'])
        observed_at = None
        if 'recent_collection' in spec:
            policy = spec['recent_collection']
            if spec['kind'] != 'comments' or not isinstance(policy, dict) or policy.get('version') not in (RECENT_VERSION, RECENT_90_VERSION):
                raise ValueError('unsupported comment date policy')
            if 'admission_limit' in policy and (policy['version'] != RECENT_90_VERSION or type(policy['admission_limit']) is not int or not 1 <= policy['admission_limit'] <= 20):
                raise ValueError('invalid comment admission limit')
            observed_at = datetime.datetime.fromisoformat(policy['observed_at'])
            if observed_at.utcoffset() is None:
                raise ValueError('explicit timezone required for comment date policy')
            observed_at = observed_at.astimezone(SHANGHAI)
        for field in ('scan_id', 'store_id', 'keyword'):
            if field in spec and (not isinstance(spec[field], str) or not spec[field].strip()):
                raise ValueError(field + ' must be a nonempty string when supplied')
        # No configs, cookies, headers or login objects should be supplied here.
        spec_text, response_text = encoded(scrub(spec)), encoded(scrub(response))
        digest = hashlib.sha256((spec_text + '\n' + response_text).encode()).hexdigest()
        clean_response = json.loads(response_text)
        stream = (spec['account_uid'], spec['kind'], spec['target'])
        scope = self._scope(spec)
        with self._db() as db:
            db.execute('BEGIN IMMEDIATE')
            old = db.execute('SELECT * FROM attempts WHERE request_id=?', (spec['request_id'],)).fetchone()
            if old:
                if old['digest'] != digest:
                    raise ValueError('request ID already exists with different input; do not overwrite evidence')
                receipt = dict(state=old['state'], added=old['added'], detail=old['detail'], request_id=old['request_id'])
                counts = db.execute('SELECT counts FROM recent_comment_page_counts WHERE request_id=?', (old['request_id'],)).fetchone()
                if counts:
                    receipt['recent_counts'] = json.loads(counts[0])
                return receipt
            state, detail, rows, next_cursor, exhausted = self._parse(spec, clean_response)
            repeated_rows = None
            if (spec['kind'] == 'comments'
                    and clean_response.get('transport_error') == 'same_items_page_repeated_with_new_cursor'):
                checked = dict(clean_response)
                checked.pop('transport_error')
                checked_state, _, checked_rows, _, _ = self._parse(spec, checked)
                if checked_state == 'parsed' and checked_rows:
                    current_ids = sorted({row[1] for row in checked_rows})
                    prior = db.execute("""SELECT response FROM attempts WHERE state='parsed'
                        AND json_extract(spec,'$.account_uid')=?
                        AND json_extract(spec,'$.kind')='comments'
                        AND json_extract(spec,'$.target')=?""", (spec['account_uid'],spec['target']))
                    for old_page in prior:
                        old_items = json.loads(old_page['response']).get('value',{}).get('comments') or []
                        if sorted({item.get('cid') for item in old_items}) == current_ids:
                            # The platform result is known. End only this stream
                            # locally, retaining its cursor and original payload.
                            state, detail, rows, next_cursor, exhausted = (
                                'parsed', 'identical prior comment page verified; local stream ended without retry',
                                [], spec['cursor'], True)
                            repeated_rows = checked_rows
                            break
            now = datetime.datetime.now(datetime.timezone.utc).isoformat()
            halt = effective_halt(db, spec['account_uid'], spec.get('scan_id'), spec)
            if halt:
                state, detail = 'blocked', 'manual review required for ' + halt['request_id'] + ' (' + halt['state'] + '); raw input retained, no replay'
            added = 0
            recent_counts = None
            if state == 'parsed':
                page = db.execute('''SELECT request_id FROM scan_pages WHERE scan_id=? AND account_uid=? AND kind=?
                    AND target=? AND store_id=? AND keyword=? AND cursor=?''', scope + (spec['cursor'],)).fetchone()
                checkpoint = db.execute('''SELECT * FROM scan_streams WHERE scan_id=? AND account_uid=? AND kind=?
                    AND target=? AND store_id=? AND keyword=?''', scope).fetchone()
                if page:
                    state, detail = 'duplicate_page', 'this stream cursor is already committed; no replay'
                elif (checkpoint and (checkpoint['exhausted'] or checkpoint['cursor'] != spec['cursor'])) or (not checkpoint and spec['cursor'] != 0):
                    state, detail = 'stale_cursor', 'input cursor does not match committed checkpoint; no guessed resume'
                else:
                    if observed_at is not None:
                        rows, recent_counts = self._recent_rows(
                            db, spec, rows if repeated_rows is None else repeated_rows,
                            observed_at, repeated_rows is not None)
                    for key, source_id, item in rows:
                        if spec['kind'] == 'comments':
                            published = retention_timestamp(item, datetime.datetime.now(SHANGHAI))
                            digest = retention_fingerprint(source_id)
                            if published is not None and retention_expired(published, datetime.datetime.now(SHANGHAI)):
                                db.execute('INSERT OR IGNORE INTO expired_comment_fingerprints VALUES(?)', (digest,))
                                continue
                            if db.execute('SELECT 1 FROM expired_comment_fingerprints WHERE digest=? UNION ALL SELECT 1 FROM excluded_comment_fingerprints WHERE digest=?', (digest,digest)).fetchone():
                                continue
                        db.execute('INSERT OR IGNORE INTO items VALUES(?,?,?,?,?,?)',
                                   (key, spec['kind'], source_id, spec['target'], spec['request_id'], encoded(item)))
                        added += self._observe(db, spec, source_id, item, now)
                    db.execute('INSERT INTO scan_pages VALUES(?,?,?,?,?,?,?,?)', scope + (spec['cursor'], spec['request_id']))
                    db.execute('INSERT OR REPLACE INTO scan_streams VALUES(?,?,?,?,?,?,?,?,?)',
                               scope + (next_cursor, int(exhausted), spec['request_id']))
                    if 'scan_id' not in spec and 'store_id' not in spec and 'keyword' not in spec:
                        db.execute('INSERT INTO pages VALUES(?,?,?,?,?)', stream + (spec['cursor'], spec['request_id']))
                        db.execute('INSERT OR REPLACE INTO streams VALUES(?,?,?,?,?,?)',
                                   stream + (next_cursor, int(exhausted), spec['request_id']))
            if state in BLOCKING_STATES:
                db.execute('INSERT INTO collection_halt_events VALUES(?,?,?,?,?)' if db.execute('SELECT 1 FROM collection_scope_reviews WHERE account_uid=? AND scan_id=?',(spec['account_uid'],spec.get('scan_id'))).fetchone() else 'INSERT INTO account_halts VALUES(?,?,?,?,?)',
                           (spec['account_uid'], spec['request_id'], state, detail, now))
            db.execute('INSERT INTO attempts VALUES(?,?,?,?,?,?,?,?)',
                       (spec['request_id'], now, spec_text, response_text, digest, state, detail, added))
            receipt = dict(state=state, added=added, detail=detail, request_id=spec['request_id'])
            if recent_counts is not None:
                receipt['recent_counts'] = recent_counts
            return receipt

    def _parse(self, spec, response):
        def fail(state, detail):
            return state, detail, [], None, None
        if not isinstance(response, dict):
            return fail('unknown', 'response envelope missing or malformed')
        if response.get('transport_error'):
            return fail('unknown', 'transport did not establish a platform result; no automatic retry')
        if response.get('ok') is not True:
            return fail('unknown', 'bridge did not establish a platform result')
        if response.get('connection') != spec['connection_id']:
            return fail('connection_mismatch', 'actual bridge connection differs from requested connection')
        value = response.get('value')
        if not isinstance(value, dict):
            return fail('invalid_response', 'platform payload must be an object')
        nil_info = value.get('search_nil_info')
        if isinstance(nil_info, dict) and nil_info.get('search_nil_type') == 'verify_check':
            return fail('verification_required', 'platform verification required; stop live execution')
        if 'status_code' not in value:
            return fail('invalid_response', 'platform status_code is absent; success not inferred')
        if type(value['status_code']) is not int or value['status_code'] != 0:
            return fail('platform_error', 'platform returned nonzero or invalid status_code')
        if type(value.get('has_more')) not in (bool, int) or value['has_more'] not in (0, 1):
            return fail('invalid_response', 'explicit has_more must be boolean or 0/1')
        if type(value.get('cursor')) is not int or value['cursor'] < 0:
            return fail('invalid_response', 'explicit returned cursor missing or invalid')
        more = bool(value['has_more'])
        if more and value['cursor'] <= spec['cursor']:
            return fail('invalid_response', 'returned cursor did not advance; stop repeated page')
        raw_items = value.get('data' if spec['kind'] == 'search' else 'comments')
        # Douyin represents a successful, explicitly empty comment stream with
        # comments:null, including when inaccessible comments remain in total.
        # Require an explicit terminal page and nonnegative reported total; never infer an
        # empty page from a missing list or an incomplete/nonzero result.
        if (spec['kind'] == 'comments' and 'comments' in value
                and raw_items is None and not more
                and type(value.get('total')) is int and value['total'] >= 0):
            raw_items = []
        if not isinstance(raw_items, list):
            return fail('invalid_response', 'expected item list absent; empty list is not guessed')
        if more and not raw_items:
            return fail('invalid_response', 'empty page declares more results; manual review required')
        rows = []
        try:
            for item in raw_items:
                if not isinstance(item, dict):
                    raise ValueError('item must be an object')
                if spec['kind'] == 'search':
                    # The general search response can include non-video cards.
                    # Preserve them in raw; never invent a video ID or customer.
                    if not isinstance(item.get('aweme_info'), dict):
                        continue
                    item = item['aweme_info']
                    source_id = stable_id(item.get('aweme_id'))
                    key = 'video:' + source_id
                else:
                    source_id = stable_id(item.get('cid'))
                    key = 'comment:' + spec['target'] + ':' + source_id
                rows.append((key, source_id, item))
        except ValueError as error:
            return fail('invalid_response', str(error))
        return 'parsed', 'structural import only; live account identity not verified by this offline tool', rows, value['cursor'], not more


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--database', default=str(ROOT / 'runtime' / 'collection.sqlite3'))
    sub = parser.add_subparsers(dest='action', required=True)
    ingest = sub.add_parser('ingest', help='import a local JSON object containing spec and response')
    ingest.add_argument('input')
    sub.add_parser('summary')
    args = parser.parse_args()
    ledger = Ledger(args.database)
    if args.action == 'summary':
        result = ledger.summary()
    else:
        document = json.loads(Path(args.input).read_text('utf-8-sig'))
        result = ledger.ingest(document['spec'], document['response'])
    print(json.dumps(result, ensure_ascii=False))


if __name__ == '__main__':
    main()
