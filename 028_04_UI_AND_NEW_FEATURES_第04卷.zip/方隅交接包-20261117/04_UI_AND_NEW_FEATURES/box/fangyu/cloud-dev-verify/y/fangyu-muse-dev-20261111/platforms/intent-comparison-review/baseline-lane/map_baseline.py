"""Map a blind sample to frozen original outputs without modifying sources.

Does not assess correctness, call a model, or expose customer comments.  Only
write inside this script's dedicated folder.  All source hashes are recorded.
"""
from pathlib import Path
from collections import Counter
import hashlib
import json
import sys

HERE = Path(__file__).resolve().parent
TASK = HERE.parent
BASE = Path('C:/积木软件工坊/项目/方隅公寓客户版/work/unified-intent-recheck-20261026')
SOURCES = {
    'model_inputs': BASE / 'model-customers.json',
    'alias_index': BASE / 'alias-index.json',
    'prior_review': BASE / 'review-complete.json',
    'prepared': BASE / 'PREPARED.json',
}

def read(name):
    raw = SOURCES[name].read_bytes()
    return json.loads(raw.decode('utf-8-sig')), hashlib.sha256(raw).hexdigest()

def unique_index(rows, key):
    result = {}
    for row in rows:
        value = row[key]
        if value in result:
            raise ValueError('duplicate unique key in source: ' + key)
        result[value] = row
    return result

def main():
    if len(sys.argv) != 2 or sys.argv[1] not in ('blind_sample', 'blind_challenge'):
        raise ValueError('choose blind_sample or blind_challenge')
    sample_kind = sys.argv[1]
    SOURCES['blind_sample'] = TASK / (sample_kind + '.json')
    loaded = {k: read(k) for k in SOURCES}
    data = {k: v[0] for k, v in loaded.items()}
    hashes = {k: v[1] for k, v in loaded.items()}
    sample, aliases = data['blind_sample'], data['alias_index']
    model = unique_index(data['model_inputs'], 'customerId')
    prior = unique_index(data['prior_review']['customers'], 'customerId')
    expected = data['prepared']['files']
    checks = {
        'blind_source_hash_matches_model_inputs': sample['source_sha256'] == hashes['model_inputs'],
        'prepared_model_inputs_match': expected['model-customers.json'] == hashes['model_inputs'],
        'prepared_alias_index_matches': expected['alias-index.json'] == hashes['alias_index'],
    }
    counts = Counter()
    out = []
    names = set()
    for item in sample['customers']:
        name, alias = item['sample'], item['customerId']
        if name in names:
            raise ValueError('duplicate sample name')
        names.add(name)
        if alias not in aliases or alias not in model:
            counts['missing_alias_or_input'] += 1
            continue
        alias_entry = aliases[alias]
        old_input = model[alias]
        old_output = prior.get(alias_entry['customerId'])
        if old_output is None:
            counts['missing_customer_output'] += 1
            continue
        source_comments = old_input['comments']
        blind_comments = item['comments']
        if len(source_comments) != len(blind_comments):
            counts['comment_count_mismatch'] += 1
            continue
        # The sample removed the comment id; every other input field must match,
        # including title, speaker relationship and captured/published times.
        if any({k: v for k, v in src.items() if k != 'id'} != blind
               for src, blind in zip(source_comments, blind_comments)):
            counts['input_context_mismatch'] += 1
            continue
        alias_leads = alias_entry['leads']
        if any(src['id'] not in alias_leads for src in source_comments):
            counts['missing_comment_alias'] += 1
            continue
        input_ids = [alias_leads[src['id']] for src in source_comments]
        if len(set(input_ids)) != len(input_ids):
            counts['duplicate_comment_alias'] += 1
            continue
        results = unique_index(old_output['comments'], 'id')
        if set(input_ids) != set(results):
            counts['comment_id_set_mismatch'] += 1
            continue
        if old_output.get('platform') != alias_entry.get('platform') or old_output.get('authorId') != alias_entry.get('authorId'):
            counts['customer_identity_mismatch'] += 1
            continue
        customer = old_output['customer']
        out.append({
            'sample': name,
            'baseline_customer': {k: customer.get(k) for k in ('status','level','demandState','needsConfirmation')},
            'baseline_comments': [
                {'ordinal': i + 1, 'status': results[alias_leads[src['id']]].get('status'),
                 'level': results[alias_leads[src['id']]].get('level'),
                 'region_status': results[alias_leads[src['id']]].get('region_status')}
                for i, src in enumerate(source_comments)
            ],
        })
    counts['sample_count'] = len(sample['customers'])
    counts['matched_customers'] = len(out)
    counts['matched_comments'] = sum(len(x['baseline_comments']) for x in out)
    complete = all(checks.values()) and len(out) == len(sample['customers'])
    output = {
        'description': 'Original historical model outputs only; no adjudication or gold labels.',
        'integrity_pass': complete,
        'source_paths': {k: str(v) for k, v in SOURCES.items()},
        'source_sha256': hashes,
        'integrity_checks': checks,
        'counts': dict(counts),
        'historical_review': {k: data['prior_review'].get(k) for k in (
            'provider','model','humanConfirmed','modelsUsed','capturedAt','reviewedAt','contractDigest')},
        'matching_scope': 'Exact input snapshot hash, customer identity, comment ID set, per-comment text/context and published/captured time. Historical outputs are not newly recomputed.',
        'rows': out,
    }
    target = HERE / (sample_kind + '-baseline-mapped.json')
    target.write_text(json.dumps(output, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'integrity_pass': complete, 'checks': checks, 'counts': dict(counts)}, ensure_ascii=False))
    return 0 if complete else 1

if __name__ == '__main__':
    sys.exit(main())
