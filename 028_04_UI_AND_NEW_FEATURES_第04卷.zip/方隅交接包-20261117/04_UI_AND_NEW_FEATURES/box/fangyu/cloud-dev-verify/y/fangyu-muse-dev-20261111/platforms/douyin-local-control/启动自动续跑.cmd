@echo off
cd /d "C:\Users\rmsama\Documents\ChatGPT\�Զ����ϵͳ\work\douyin-local-control"
start "" C:\Users\rmsama\miniconda3\pythonw.exe "C:\Users\rmsama\Documents\ChatGPT\�Զ����ϵͳ\work\douyin-local-control\auto_continue.py"
