from pathlib import Path
import datetime, hashlib, json, sqlite3

T = Path(__file__).resolve().parent
P = Path('C:/积木软件工坊/项目/方隅公寓客户版')
F = P / 'work/parallel-integration-20261018/final-integration'
N = P / 'work/ui-native-r57'
def read(p): return json.loads(p.read_text('utf-8-sig'))
def write(p, obj): p.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
plan = read(F / 'entry-v22/CANONICAL-DELEGATION-PREPARED.json')
launcher_sha = hashlib.sha256((N / 'run_workbench.py').read_bytes()).hexdigest()
assert launcher_sha.upper() == plan['launcher_sha256']
assert read(T / 'EXPIRED-LOGIN-TESTS.json')['status'] == 'PASS'
assert read(T / 'SESSION-TESTS.json')['status'] == 'PASS'
binding = read(N / 'state/production-workspace.json')
tid = 'd36660aed1804857b4f58a2fdc42958a'
with sqlite3.connect((Path(binding['data_dir']) / 'workspace.sqlite3').as_uri() + '?mode=ro', uri=True) as db:
    def row(entity, ident):
        value = db.execute('SELECT body FROM records WHERE entity=? AND id=?', (entity, ident)).fetchone()
        return json.loads(value[0]) if value else {}
    run = row('workbench_collection_run_v1', tid)
    diagnostic = row('workbench_collection_diagnostic_v1', tid)
    account = row('accounts', '7dadec8b3e6241d583f8b234619ae32c')
    leads = [json.loads(r[0]) for r in db.execute('SELECT body FROM records WHERE entity=?', ('leads',))]
    new_leads = [r for r in leads if r.get('task_id') == tid]
    attempts = [json.loads(r[0]) for r in db.execute('SELECT body FROM records WHERE entity=?', ('ai_attempts',))]
    attempts = [r for r in attempts if r.get('created_at', '') >= run['attempt_started_at']]
assert account['status'] == 'ready'
assert account['auth_generation'] != '86b9667b1f5e5db8a11942d84fd95bb3'
assert len(new_leads) == 1 and new_leads[0].get('grade_reason')
assert run['counts']['imported'] == 1 and run['pages'] == 1
assert diagnostic['code'] == 'verification_required'
assert any(r.get('state') == 'validated' and r.get('operation') == 'intent_analyze' for r in attempts)
started = datetime.datetime.fromisoformat(run['attempt_started_at'])
analyzed_at = max(datetime.datetime.fromisoformat(r['updated_at']) for r in attempts)
sample_seconds = (analyzed_at - started).total_seconds()
receipt = {
    'status': 'INSTALLED_REAL_LOGIN_RESUME_PASSED_NEXT_CAPTCHA_SKIPPED',
    'version': 'v22', 'at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'release_id': plan['release_id'], 'launcher_sha256': launcher_sha,
    'closure_files_verified': plan['full_closure_files_verified'],
    'focused_tests': {'expired_login': read(T / 'EXPIRED-LOGIN-TESTS.json'), 'session_handoff': read(T / 'SESSION-TESTS.json')},
    'computer_use': {
        'notice_centered': True, 'continue_clicked_once': True, 'visible_pending_feedback': True,
        'owned_browser_reopened': True, 'account_page_connected': True,
        'auth_generation_changed': True, 'original_task_resumed': True,
        'new_comments': 1, 'new_customers': 1, 'AI_attempt_validated': True,
        'customer_count_before': 72, 'customer_count_after': 73,
        'sample_collection_and_analysis_seconds': sample_seconds,
        'steady_state_throughput_verified': False,
        'next_page': 'verification_required', 'human_CAPTCHA_skipped': True,
        'real_messages_sent': 0, 'platform_logout_performed': False,
        'browser_dimensions_changed': False,
    },
    'task_id': tid,
}
write(T / 'DELIVERY-v22.json', receipt)
report = f'''# 客户端修复与实测结果

登录失效后的“验证完成，继续原任务”已修复，提示窗已移到界面正中间。点击后会显示核对进度，完成后账号页同步显示“已连接”。

已通过实际点击验证：软件重新接上已登录账号，原获客任务恢复，成功新增1条评论和1位客户，并完成意向分析、保存判断依据；客户总数由72变为73。单条采集到分析完成约{sample_seconds:.1f}秒。

随后小红书再次要求验证码，按要求跳过，已采集数据及断点保留。只有1条成功样本，尚不能判断持续采集速度。未发送消息，未退出平台账号。

此前还已实际检查客户列表、分页、详情、回复工作台、获客规则、模型配置和Excel导出。此前导出的客户清单包含72位客户，是本次新增前的快照。
'''
(P / 'outputs/验证续接实测/实测结果.md').write_text(report, encoding='utf-8')
summary = f'''# 当前续行摘要

2026-10-19：v22已通过原CAS入口安装。用户要求修复已登录但续行无反应、账号状态不同步，并将软件内部登录失效提示居中；不要改网页验证窗口尺寸。

来源仍为stage-02/project。本次6文件增量：严格识别已接收的登录过期回执，支持重新打开原账号WebView配置后走同UID status/claim/commit，等待浏览器就绪再捕获；保留精确失败页最多重试一次、未知结果不重放。提示居中并有按钮处理中反馈。12项既有定向检查和4项新检查通过；只读审查无阻塞项；2723文件闭包及原入口校验通过。

真实Computer Use已完成：点击一次续行，原验证网页重新打开，账号页已连接，auth_generation改变，原任务恢复。1条新评论导入并完成意向分析（AI请求validated，等级C/uncertain，有依据），客户由72增到73，单条采集至分析约{sample_seconds:.1f}秒。随后平台新验证码verification_required，按用户要求跳过，不盲目重试；持续吞吐未验证。未发送消息、未退出平台账号。数据和断点保留。

release={plan['release_id']}
入口SHA={launcher_sha}
证据：{T / 'DELIVERY-v22.json'}
旧v21证据保留，勿把旧失败结果覆盖成本轮结果。不要重编CLI、重开17小时旧任务、读取大历史或重跑旧完整测试。不改核心/自用/其他客户。
'''
(T / 'CONTINUE.md').write_text(summary, encoding='utf-8')
(P / 'work/当前续行摘要.md').write_text(summary, encoding='utf-8')
session = P / 'memory/sessions/2026-10-19-登录过期续行v22与实测.md'
session.parent.mkdir(exist_ok=True)
session.write_text(summary, encoding='utf-8')
print(json.dumps({'status': receipt['status'], 'sample_seconds': sample_seconds, 'new_customers': len(new_leads), 'next_page': diagnostic['code']}, ensure_ascii=False))
