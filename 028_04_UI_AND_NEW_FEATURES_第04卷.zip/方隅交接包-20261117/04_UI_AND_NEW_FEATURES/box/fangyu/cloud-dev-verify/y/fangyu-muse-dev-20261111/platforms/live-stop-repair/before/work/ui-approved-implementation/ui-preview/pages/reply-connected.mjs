import {evidenceSummary,assessmentLabel,workflowScope} from './workflow-summary.mjs';
import {customerAvatar,postCover,bindCustomerAvatars,warmCustomerMedia} from '../avatar.mjs';
// Connected reply workspace. Preview examples remain confined to reply.mjs.
import {renderDelivery,bindDelivery,prepareReviewed} from './reply-delivery.mjs';
import {personaChoices} from './management-tone.mjs';
import {bindBatch,renderBatch} from './reply-batch.mjs';
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const icon=name=>`<img class="rp-icon" src="/assets/${name}" alt="">`;
const actor=s=>`${s.authEpoch||0}|${s.user}|${s.storeId||''}|${s.activePlatform||'xiaohongshu'}`;
const matches=(s,value)=>value?.actor?.username===s.user&&value?.actor?.storeId===s.storeId;
const active=s=>s.connection==='connected'&&Boolean(s.session)&&s.page==='reply';
const statusLabels={draft:'草稿已保存 · 未发送',approved:'已核对 · 未发送',sent:'已有发送记录',unknown:'发送结果待核对',copied:'已复制 · 未确认发送',superseded:'历史草稿'};
function model(state){
  if(!state.replyLive||state.replyLive.actor!==actor(state))state.replyLive={actor:actor(state),status:'idle',items:[],stats:{},tab:'pending',groupBy:'post',query:'',page:1,generation:0,selectedId:'',leadId:'',text:'',accountId:'',busy:false,pending:null,error:'',detail:null,collapsedGroups:[],intent:'all',checkedIds:[]};
  return state.replyLive;
}
const selected=v=>v.detail?.comments?.find(row=>row.id===v.leadId);
function customerRow(p,v){return `<div class="rp-selectable-comment"><input type="checkbox" data-live-check-customer="${esc(p.id)}" aria-label="选择${esc(p.name)}" ${(v.checkedIds||[]).includes(p.id)?'checked':''}><button type="button" class="rp-comment ${v.selectedId===p.id?'is-selected':''}" data-live-customer="${esc(p.id)}" aria-pressed="${v.selectedId===p.id}">${customerAvatar(p,'rp-avatar')}<span class="rp-comment-copy"><strong>${esc(p.name)}</strong><span>${esc(p.quote)}</span></span><span class="rp-badge rp-${['urgent','high','medium','low','muted'].includes(p.tone)?p.tone:'muted'}">${esc(p.level)}</span><span class="rp-status ${p.replied?'is-replied':''}">${esc(p.contactLabel)}</span><time title="${p.publishedAt?'原评论时间':'原评论时间未提供，可查看来源记录'}">${esc(p.publishedAt||'—')}</time></button></div>`;}
function groups(v){
  if(v.groupBy!=='post')return `<section class="rp-post rp-flat-post" style="min-height:max-content;flex-shrink:0"><div class="rp-flat-title">${v.groupBy==='intent'?'按意向查看':'按时间查看'}<span>本页 ${v.items.length} 位客户</span></div>${v.items.map(p=>customerRow(p,v)).join('')}</section>`;
  const posts=new Map();
  for(const p of v.items){const key=JSON.stringify([p.platform,p.postUrl||p.postTitle||p.id]);if(!posts.has(key))posts.set(key,[]);posts.get(key).push(p);}
  return [...posts].map(([key,items])=>{const p=items[0],closed=v.collapsedGroups.includes(key);return `<section class="rp-post ${closed?'is-collapsed':''}" style="min-height:max-content;flex-shrink:0"><div class="rp-post-heading">${postCover(p,'rp-post-thumbnail','object-fit:cover;flex-shrink:0')}<div class="rp-post-name" style="min-width:0;flex:1"><div><strong style="overflow:hidden;text-overflow:ellipsis" title="${esc(p.postTitle)}">${esc(p.postTitle||'帖子标题未提供')}</strong></div><span>${esc(p.channel)}<i>·</i>本页 ${items.length} 位客户${items.some(p=>p._outsidePage)?' · 含指定客户':''}</span></div><button type="button" class="rp-icon-button rp-collapse ${closed?'is-closed':''}" data-live-collapse="${esc(key)}" aria-label="${closed?'展开':'收起'}帖子客户" aria-expanded="${!closed}">${icon('tabler-chevron-down.svg')}</button></div>${closed?'':`<div class="rp-comment-list">${items.map(p=>customerRow(p,v)).join('')}</div>`}</section>`;}).join('');
}
function choose(v,id){const row=v.detail?.comments?.find(row=>row.id===id);v.leadId=row?.id||'';v.text=row?.draft?.text||'';v.accountId=row?.draft?.review_account_id||row?.accounts?.[0]?.id||'';v.dirty=false;v.evidenceOpen=false;}
function accept(state,v,result){
  if(!matches(state,result)||result.customerId!==v.selectedId)throw new Error('员工、门店或客户范围已变化，请重新载入。');
  v.detail=result;choose(v,result.comments?.some(row=>row.id===v.leadId)?v.leadId:result.comments?.[0]?.id);
  warmCustomerMedia([result.item],workflowScope(state));
  const pending=result.comments?.find(row=>row.pendingRequestId);
  if(pending)v.pending={customerId:result.customerId,leadId:pending.id,requestId:pending.pendingRequestId};
}
export function renderConnected(state){
  if(!state.storeId)return '<div class="reply-page" role="status">请先在获客页选择门店，再查看本店客户和原评论。</div>';
  const v=model(state),row=selected(v),person=v.detail?.item;
  const known=Number.isSafeInteger(v.stats.total)&&Number.isSafeInteger(v.stats.replied);
  const counts={pending:known?Math.max(0,v.stats.total-v.stats.replied):'—',replied:known?v.stats.replied:'—',all:known?v.stats.total:'—'};
  const toolbar=`<div class="rp-toolbar"><div class="rp-tabs" role="tablist" aria-label="回复状态">${[['pending','待处理'],['replied','已回复'],['all','全部']].map(([id,label])=>`<button type="button" role="tab" aria-selected="${v.tab===id}" class="rp-tab ${v.tab===id?'is-active':''}" data-live-tab="${id}">${label}<span>${counts[id]}</span></button>`).join('')}</div><label class="rp-group"><select data-live-group aria-label="排列方式">${[['post','按帖子'],['intent','按意向'],['time','按时间']].map(([id,label])=>`<option value="${id}" ${v.groupBy===id?'selected':''}>${label}</option>`).join('')}</select></label><label class="rp-group"><select data-live-intent aria-label="意向筛选">${[['all','全部意向'],['super_high','超高意向'],['high','高意向'],['medium','中意向'],['low','低意向'],['very_low','极低意向'],['uncertain','待分析 / 待定'],['unrelated','无关']].map(([id,label])=>`<option value="${id}" ${v.intent===id?'selected':''}>${label}</option>`).join('')}</select></label><label class="rp-search">${icon('fy-icon-07-search.png')}<input id="reply-search" type="search" data-live-search value="${esc(v.query)}" maxlength="100" placeholder="搜索评论或用户名…" aria-label="搜索评论或用户名"></label></div>`;
  const list=groups(v);
  let editor=`<div class="rp-empty"><strong>${v.detailLoading?'正在读取原评论与草稿':'选择客户后，逐条选择原评论'}</strong><span>草稿和核对记录均不代表已发送。</span></div>`;
  if(row&&person){
    const locked=v.busy||v.batchBusy||Boolean(v.pending)||Boolean(v.batchPending),tone=['urgent','high','medium','low','muted'].includes(person.tone)?person.tone:'muted';
    const reasons=[...new Set((person.evidence||[]).filter(x=>typeof x==='string'&&x.trim()))].slice(0,3);
    const disclosure=`<div class="rp-evidence" id="reply-live-evidence" ${v.evidenceOpen?'':'hidden'}>${reasons.map(text=>`<span>${esc(text)}</span>`).join('')||'<span>尚无分析原因。</span>'}${v.recoveryText?`<blockquote>${esc(v.recoveryText)}</blockquote>`:''}</div>`;
    const sourceControls=`<div class="rp-source-controls">${v.detail.comments.length>1?`<label>原评论 <select data-live-comment ${locked?'disabled':''} style="width:100%">${v.detail.comments.map((c,i)=>`<option value="${esc(c.id)}" ${c.id===v.leadId?'selected':''}>${i+1}. ${esc(c.text.slice(0,48))}</option>`).join('')}</select></label>`:''}<label>核对账号 <select data-live-account ${locked?'disabled':''} style="width:100%"><option value="">请选择本人账号</option>${row.accounts.map(a=>`<option value="${esc(a.id)}" ${a.id===v.accountId?'selected':''}>${esc(a.name)}</option>`).join('')}</select></label></div>`;
    editor=`<div class="rp-person-summary" style="flex-shrink:0">${customerAvatar(person,'rp-detail-avatar')}<div class="rp-detail-copy" style="min-width:0"><div class="rp-person-title"><strong style="overflow:hidden;text-overflow:ellipsis;max-width:160px">${esc(person.name)}</strong><span class="rp-badge rp-${tone}">${esc(person.level)}</span></div><p style="white-space:pre-wrap;overflow-wrap:anywhere;max-height:180px;overflow:auto">${esc(row.text)}</p>${row.text.length>55?'<button type="button" class="rp-text-link" data-live-full-comment>查看完整原评论</button>':''}</div></div>
      <div class="rp-selected-source" style="display:flex;gap:12px;margin:14px 0;align-items:center;flex-shrink:0">${postCover(row,'rp-post-thumbnail','width:92px;height:92px;object-fit:cover;flex-shrink:0;border-radius:12px')}<div style="min-width:0;flex:1"><strong style="display:block;font-size:16px;overflow-wrap:anywhere">${esc(row.postTitle)}</strong><span style="font-size:13px;color:#7186a6">${esc(row.publishedAt||'原评论时间未提供')}</span><button type="button" class="rp-text-link" data-live-source style="display:block">打开原帖</button></div></div>
      <button type="button" class="rp-evidence-toggle" data-live-evidence aria-controls="reply-live-evidence" aria-expanded="${Boolean(v.evidenceOpen)}">分析原因 ${icon('tabler-chevron-down.svg')}</button>${disclosure}${sourceControls}
      <div class="rp-persona-controls"><button type="button" class="rp-secondary" data-live-tone ${locked?'disabled':''}>选择员工 / 客户 SOP</button></div>
      <div class="rp-composer"><textarea id="connected-reply-draft" data-live-draft aria-label="回复草稿" maxlength="1000" ${locked||!row.canSave?'disabled':''} placeholder="粘贴或填写已核实的回复内容…">${esc(v.text)}</textarea><span class="rp-char-count"><span data-live-count>${v.text.length}</span> / 1000</span></div>
      <div class="rp-draft-tools" style="gap:18px;flex-wrap:wrap"><button type="button" data-live-copy>${icon('fy-icon-25-copy.png')}复制</button>${renderDelivery(state,v)}</div>
      <div class="rp-editor-actions"><button type="button" class="rp-primary" data-live-review ${locked||!v.text.trim()?'disabled':''}>${icon('fy-icon-23-send.png')}${v.dirty?'保存并核对':row.reviewCurrent?'准备发送':'核对并继续'}</button><button type="button" class="rp-secondary" data-live-save ${locked||!row.canSave||!v.text.trim()?'disabled':''}>保存草稿</button></div>`;
  }
  const status=v.error||v.pending?`<div role="status" style="flex-shrink:0;padding:8px 12px;font-size:14px;background:#fff7ed;color:#8c5323;overflow-wrap:anywhere">${v.error?`<span role="alert">${esc(v.error)}</span>`:''}${v.pending?' <button type="button" class="rp-text-link" data-live-check>核对上次操作</button>':''}</div>`:'';
  const height='calc(658px * var(--space-y))';
  return `<div class="reply-page rp-connected">${toolbar}${renderBatch(state,v)}<div class="rp-workspace"><div class="rp-posts" style="display:flex;flex-direction:column;height:${height};min-height:0;gap:0;overflow:hidden"><div data-live-list style="flex:1;min-height:0;overflow-y:auto;overflow-x:hidden;display:grid;grid-auto-rows:max-content;align-content:start;gap:calc(19px * var(--space-y))">${list||`<div class="rp-empty"><strong>${v.status==='error'?'客户暂未加载':v.status==='loading'?'正在加载真实客户…':'当前没有符合条件的客户'}</strong><span>${esc(v.error||'可切换全部或重新读取。')}</span></div>`}</div><div style="display:flex;align-items:center;justify-content:space-between;gap:8px;min-height:42px;flex-shrink:0;padding:5px 10px;font-size:14px;color:#7186a6"><span>${v.total||0} 位 · ${v.page} / ${Math.max(1,v.pages||0)} 页</span><button type="button" class="rp-text-link" data-live-reload ${v.busy?'disabled':''}>刷新</button><span><button type="button" class="rp-text-link" data-live-page="-1" ${v.page<=1||v.busy?'disabled':''}>上一页</button> <button type="button" class="rp-text-link" data-live-page="1" ${v.page>=(v.pages||0)||v.busy?'disabled':''}>下一页</button></span></div></div><aside class="rp-editor" style="height:${height};min-height:0;overflow-y:auto;overflow-x:hidden" aria-label="回复编辑">${status}${editor}${!row?renderDelivery(state,v):''}</aside></div></div>`;
}
async function load(state,ctx,v,{customerId}={}){
  const generation=++v.generation,scope=actor(state),filterKey=JSON.stringify([v.query,v.tab,v.intent||'all',v.groupBy,v.page]),cached=Boolean(v.loadedAt&&v.loadedFilter===filterKey);
  if(!cached){v.items=[];v.stats={};if(!v.dirty&&!v.pending&&!v.batchBusy&&!v.batchPending){v.detail=null;v.selectedId='';v.leadId='';v.text='';}}
  v.status=cached?'ready':'loading';v.refreshing=true;v.error='';
  const owns=()=>state.connection==='connected'&&Boolean(state.session)&&state.replyLive===v&&generation===v.generation&&scope===actor(state);
  const redraw=()=>{if(owns()&&active(state))ctx.update(()=>{});};redraw();
  try{
    const result=await ctx.replyCustomers({query:v.query,filter:v.tab,sort:v.groupBy,page:v.page,pageSize:20,audience:'all',intent:v.intent||'all'});
    if(!owns())return;
    if(!matches(state,result.customers))throw new Error('员工或门店已变化，请重新载入。');
    v.checkedIds=[];
    Object.assign(v,{items:result.customers.items,total:result.customers.total,stats:result.customers.stats,pages:result.customers.pages,page:result.customers.page,status:'ready',loadedAt:Date.now(),loadedFilter:filterKey});
    warmCustomerMedia(v.items,workflowScope(state));
    if(v.dirty||v.pending||v.busy||v.batchBusy||v.batchPending)return;
    const chosen=customerId||v.selectedId,next=customerId||(v.items.some(row=>row.id===chosen)?chosen:v.items[0]?.id||'');
    if(next!==v.selectedId){v.detail=null;v.leadId='';v.text='';}v.selectedId=next;
    if(active(state)&&v.selectedId){v.detailLoading=true;redraw();const selectedId=v.selectedId;
      const detail=await ctx.replyRead({storeId:state.storeId,customerId:selectedId});
      if(!owns()||v.dirty||v.pending||v.selectedId!==selectedId)return;accept(state,v,detail.replyWorkspace);
      if(customerId&&!v.items.some(row=>row.id===customerId))v.items.unshift({...detail.replyWorkspace.item,_outsidePage:true});}
  }catch(error){if(owns()){
    const keep=cached&&['timeout','connection_failed'].includes(error.code);v.status=keep?'ready':'error';v.error=error.message;
    if(!keep){v.items=[];v.stats={};v.total=0;v.detail=null;v.leadId='';v.text='';v.dirty=false;if(!v.pending)v.selectedId='';}
    if(active(state)||error.code==='AUTH_REQUIRED')ctx.replyError(error);
  }}
  finally{if(owns()){v.detailLoading=false;v.refreshing=false;redraw();}}
}
export function preloadConnected(state,ctx){
  if(state.connection!=='connected'||!state.session||!state.storeId)return null;
  const v=model(state);if(v.status!=='idle')return null;return load(state,ctx,v);
}
async function selectCustomer(state,ctx,v,id){
  if(v.selectedId===id&&v.detail&&!v.detailLoading)return;
  const generation=++v.generation,scope=actor(state);v.selectedId=id;v.detail=null;v.detailLoading=true;v.error='';ctx.update(()=>{});
  const owns=()=>state.connection==='connected'&&Boolean(state.session)&&state.replyLive===v&&generation===v.generation&&scope===actor(state);
  try{const result=await ctx.replyRead({storeId:state.storeId,customerId:id});if(owns()&&!v.dirty&&!v.pending)accept(state,v,result.replyWorkspace);}
  catch(error){if(owns()){v.error=error.message;if(active(state)||error.code==='AUTH_REQUIRED')ctx.replyError(error);}}
  finally{if(owns()){v.detailLoading=false;if(active(state))ctx.update(()=>{});}}
}
async function mutate(state,ctx,v,review=false){
  const row=selected(v);if(!row||v.busy||v.pending)return false;
  const scope=actor(state),requestId=crypto.randomUUID(),customerId=v.selectedId,leadId=row.id;
  const generation=v.generation;
  const ownsView=()=>state.connection==='connected'&&Boolean(state.session)&&state.replyLive===v&&scope===actor(state)&&v.generation===generation&&v.selectedId===customerId&&v.leadId===leadId;
  const ownsAttempt=()=>ownsView()&&v.pending?.requestId===requestId;
  const payload={storeId:state.storeId,customerId,leadId,sourceDigest:row.sourceDigest,expectedVersion:row.draft?.version||0,expectedReplyId:row.draft?.id||'',requestId,...(review?{accountId:v.accountId,confirmed:true}:{text:v.text})};
  v.busy=true;v.error='';v.pending={customerId,leadId,requestId};ctx.update(()=>{});
  try{
    const result=await (review?ctx.replyReview(payload):ctx.replySave(payload));
    if(!ownsAttempt())return false;
    if(!matches(state,result.replyWorkspace)||result.replyWorkspace?.customerId!==customerId){const error=new Error('草稿保存结果尚未确认，请核对原操作。');error.code='REPLY_RESULT_UNCONFIRMED';throw error;}
    v.pending=null;accept(state,v,result.replyWorkspace);if(active(state))ctx.toast(review?'草稿已逐条核对，尚未发送。':'草稿已保存，尚未发送。');return true;
  }catch(error){if(ownsAttempt()){if(!['RESULT_UNCONFIRMED','REPLY_RESULT_UNCONFIRMED'].includes(error.code))v.pending=null;v.error=error.message;if(active(state)||error.code==='AUTH_REQUIRED')ctx.replyError(error);}return false;}
  finally{if(ownsView()&&(!v.pending||v.pending.requestId===requestId)){v.busy=false;if(active(state))ctx.update(()=>{});}}
}
async function checkPending(state,ctx,v){
  if(v.busy||!v.pending)return;
  const scope=actor(state),generation=v.generation,pending={...v.pending};
  const ownsView=()=>state.connection==='connected'&&Boolean(state.session)&&state.replyLive===v&&scope===actor(state)&&v.generation===generation&&v.selectedId===pending.customerId;
  const ownsAttempt=()=>ownsView()&&v.pending?.requestId===pending.requestId;
  v.busy=true;ctx.update(()=>{});
  try{
    const result=await ctx.replyCheck({storeId:state.storeId,...pending});if(!ownsAttempt())return;
    accept(state,v,result.replyWorkspace);
    if(['accepted','observed','not_found','not_applied','rejected','changed'].includes(result.replyWorkspace.receipt?.state)){
      v.pending=null;v.recoveryText=result.replyWorkspace.receipt?.attemptText||'';
      v.error=result.replyWorkspace.receipt?.state==='changed'?'原评论或草稿版本已变化，旧操作已关闭。保留当前草稿；请逐条重核，旧审核不代表当前来源有效。':'请逐条核对当前后台正文和版本，尚未发送。';
    }else v.error='后台尚未确认原操作，请保留当前记录，不要重复保存。';
  }catch(error){if(ownsAttempt()){v.error=error.message;if(active(state)||error.code==='AUTH_REQUIRED')ctx.replyError(error);}}
  finally{if(ownsView()&&(!v.pending||v.pending.requestId===pending.requestId)){v.busy=false;if(active(state))ctx.update(()=>{});}}
}
let currentScope='';
export function syncConnected(state,ctx){
  if(!active(state)||!state.storeId){currentScope='';return;}
  const v=model(state);
  if(currentScope===actor(state)&&v.status!=='idle')return;
  currentScope=actor(state);
  if(v.refreshing||v.status==='loading'||v.status==='scheduled'||v.dirty||v.pending||v.busy||v.batchBusy||v.batchPending)return;
  if(v.status==='ready'&&Date.now()-(v.loadedAt||0)<15000){
    if(v.selectedId&&!v.detail&&!v.detailLoading)queueMicrotask(()=>{if(active(state)&&state.replyLive===v)selectCustomer(state,ctx,v,v.selectedId);});
    return;
  }
  v.status=v.loadedAt?'ready':'scheduled';queueMicrotask(()=>{const id=state.selectedCustomer||state.replyDelivery?.customerIds?.[0];delete state.selectedCustomer;if(active(state)&&state.replyLive===v)load(state,ctx,v,{customerId:id});});
}
export function bindConnected(root,ctx){
  bindCustomerAvatars(root);
  const state=ctx.state,v=model(state);
  bindBatch(root,ctx,v);
  root.querySelector('[data-live-intent]')?.addEventListener('change',e=>discard(()=>{v.intent=e.target.value;v.page=1;load(state,ctx,v);}));
  root.querySelectorAll('[data-live-tone]').forEach(el=>el.addEventListener('click',()=>ctx.openToneTools?.()));
  root.querySelector('[data-live-evidence]')?.addEventListener('click',()=>ctx.update(()=>{v.evidenceOpen=!v.evidenceOpen;}));
  const discard=fn=>{if(v.busy||v.pending||v.batchBusy||v.batchPending){ctx.toast('请先核对当前操作结果。');return;}if(v.dirty)ctx.modal({title:'有未保存修改',html:'<p>切换后将重新读取后台草稿，未保存文字会丢失。</p>',confirmLabel:'放弃修改并继续',onConfirm:()=>{v.dirty=false;return fn();}});else fn();};
  bindDelivery(root,ctx,v,id=>discard(()=>selectCustomer(state,ctx,v,id)));
  root.querySelector('[data-live-reload]')?.addEventListener('click',()=>discard(()=>load(state,ctx,v)));
  root.querySelectorAll('[data-live-collapse]').forEach(el=>el.addEventListener('click',()=>{const key=el.dataset.liveCollapse;v.collapsedGroups=v.collapsedGroups.includes(key)?v.collapsedGroups.filter(k=>k!==key):[...v.collapsedGroups,key];ctx.update(()=>{});}));
  root.querySelectorAll('[data-live-tab]').forEach(el=>el.addEventListener('click',()=>discard(()=>{v.tab=el.dataset.liveTab;v.page=1;load(state,ctx,v);})));
  root.querySelector('[data-live-group]')?.addEventListener('change',e=>discard(()=>{v.groupBy=e.target.value;v.page=1;load(state,ctx,v);}));
  const search=root.querySelector('[data-live-search]');
  search?.addEventListener('change',e=>{const query=e.target.value;discard(()=>{v.query=query;v.page=1;load(state,ctx,v);});});
  root.querySelectorAll('[data-live-page]').forEach(el=>el.addEventListener('click',()=>discard(()=>{v.page+=Number(el.dataset.livePage);load(state,ctx,v);})));
  root.querySelectorAll('[data-live-customer]').forEach(el=>el.addEventListener('click',()=>discard(()=>selectCustomer(state,ctx,v,el.dataset.liveCustomer))));
  root.querySelector('[data-live-comment]')?.addEventListener('change',e=>{const id=e.target.value;discard(()=>{choose(v,id);ctx.update(()=>{});});});
  root.querySelector('[data-live-account]')?.addEventListener('change',e=>{if(v.busy||v.pending)return;v.accountId=e.target.value;ctx.update(()=>{});});
  root.querySelector('[data-live-draft]')?.addEventListener('input',e=>{if(v.busy||v.pending||!selected(v)?.canSave)return;v.text=e.target.value;v.dirty=v.text!==(selected(v)?.draft?.text||'');root.querySelector('[data-live-count]').textContent=v.text.length;root.querySelector('[data-live-save]').disabled=v.busy||!selected(v)?.canSave||!v.text.trim()||Boolean(v.pending);root.querySelector('[data-live-review]').disabled=v.busy||!v.text.trim()||Boolean(v.pending);root.querySelector('[data-live-review]').lastChild.textContent=v.dirty?'保存并核对':selected(v)?.reviewCurrent?'准备发送':'核对并继续';});
  root.querySelector('[data-live-copy]')?.addEventListener('click',async()=>{try{await navigator.clipboard.writeText(v.text);ctx.toast('内容已复制，尚未确认发送。');}catch{root.querySelector('[data-live-draft]')?.select();ctx.toast('已选中文字，可手动复制。');}});
  root.querySelector('[data-live-save]')?.addEventListener('click',()=>mutate(state,ctx,v));
  root.querySelector('[data-live-review]')?.addEventListener('click',async()=>{
    if(!selected(v)||v.busy||v.pending||!v.text.trim())return;
    if(v.dirty&&!(await mutate(state,ctx,v)))return;
    const row=selected(v);if(!row||v.busy||v.pending||v.dirty)return;
    if(row.reviewCurrent&&row.draft?.status==='approved'&&row.draft.review_account_id===v.accountId){prepareReviewed(state,ctx,v);return;}
    if(!row.canReview||!v.accountId){ctx.update(()=>{v.evidenceOpen=true;});ctx.toast(row.reason||(!v.accountId?'请先选择本人核对账号。':'请先保存草稿并核对当前回复条件。'));return;}
    const expected={actor:actor(state),customerId:v.selectedId,leadId:v.leadId,generation:v.generation,text:v.text,accountId:v.accountId,sourceDigest:row.sourceDigest,replyId:row.draft?.id,version:row.draft?.version};
    const account=row.accounts.find(a=>a.id===v.accountId);
    ctx.modal({title:'确认回复 · 逐条核对',html:`<p>原评论：</p><blockquote style="max-height:30vh;overflow:auto;white-space:pre-wrap;overflow-wrap:anywhere">${esc(row.text)}</blockquote><p>账号：${esc(account?.name)}</p><blockquote class="rp-confirm-quote">${esc(v.text)}</blockquote><p>本步只保存审核记录，不会发送到平台。下一步须核对完整发送正文并最后授权。</p>`,confirmLabel:'核对本条并继续',onConfirm:async()=>{
      const current=selected(v);
      if(!active(state)||state.replyLive!==v||actor(state)!==expected.actor||v.selectedId!==expected.customerId||v.leadId!==expected.leadId||v.generation!==expected.generation||v.text!==expected.text||v.accountId!==expected.accountId||v.dirty||v.pending||current?.sourceDigest!==expected.sourceDigest||current?.draft?.id!==expected.replyId||current?.draft?.version!==expected.version)return false;
      const reviewed=await mutate(state,ctx,v,true);if(reviewed)await prepareReviewed(state,ctx,v);return reviewed;
    }});
  });
  root.querySelector('[data-live-check]')?.addEventListener('click',()=>checkPending(state,ctx,v));
  root.querySelector('[data-live-full-comment]')?.addEventListener('click',()=>ctx.modal({title:'完整原评论',html:`<blockquote style="max-height:55vh;overflow:auto;white-space:pre-wrap;overflow-wrap:anywhere">${esc(selected(v)?.text)}</blockquote>`,confirmLabel:'知道了'}));
  root.querySelectorAll('[data-live-source]').forEach(button=>button.addEventListener('click',()=>{const row=selected(v);const hosts={xiaohongshu:['www.xiaohongshu.com','xiaohongshu.com'],douyin:['www.douyin.com','douyin.com']};try{const url=new URL(row.postUrl);if(url.protocol!=='https:'||url.username||url.password||url.port||!hosts[row.platform]?.includes(url.hostname))throw new Error();window.open(url.href,'_blank','noopener');}catch{ctx.toast('源帖地址尚未核对，保留原评论来源。');}}));
}
