"""User-enabled collection with current-page recovery."""
from current_collection import start, ensure_supervisor
if __name__ == "__main__":
    print(start(), flush=True)
    ensure_supervisor()
