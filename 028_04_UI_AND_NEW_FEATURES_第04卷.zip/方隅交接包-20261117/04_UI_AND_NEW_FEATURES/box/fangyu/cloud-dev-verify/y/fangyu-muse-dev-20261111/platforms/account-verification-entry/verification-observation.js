(() => {
  if(location.origin!=='https://www.xiaohongshu.com')return null;
  const key='__fangyuHumanVerificationActivityV1';
  if(!window[key]){
    window[key]={activity:0};
    for(const name of ['pointerup','keydown'])document.addEventListener(name,event=>{
      if(event.isTrusted&&window[key])window[key].activity=Math.min(1000000,window[key].activity+1);
    },true);
  }
  const visible=node=>{const r=node.getBoundingClientRect(),s=getComputedStyle(node);
    return r.width>0&&r.height>0&&s.display!=='none'&&s.visibility!=='hidden'&&Number(s.opacity)>0;};
  const challenged=location.pathname.startsWith('/website-login/captcha')||
    Array.from(document.querySelectorAll('.security-container,.risk-control,.verify-container,.captcha-container,#captcha,iframe[src*="captcha"]')).some(visible);
  const logged=Array.from(document.querySelectorAll('a[href]')).some(link=>{
    if(!visible(link)||!['我','我的','我的主页','个人主页'].includes((link.innerText||link.getAttribute('aria-label')||'').replace(/\s+/g,'')))return false;
    const u=new URL(link.getAttribute('href'),location.href);
    return u.origin===location.origin&&/^\/user\/profile\/[A-Za-z0-9]{8,64}\/?$/.test(u.pathname);
  });
  const guest=!logged&&Array.from(document.querySelectorAll('button,#login-btn,[class*="login-btn"]')).some(node=>visible(node)&&/^(登录|登录后查看|立即登录)/.test((node.innerText||'').trim()));
  return {logged,challenged,guest,activity:window[key].activity};
})()