"""Local, read-only transport recovery. Never retries a publish."""
import json
import subprocess
import time
from pathlib import Path
from unknown_resolution import current_stop,LIVE_STOPS


def transport_failure(result):
    if result.get('status') != 'not_sent' or result.get('receipt'):
        return False
    error = result.get('error') or ''
    return current_stop(result)=='page_unresponsive' or any(word in error for word in ('Request timeout', 'request timeout',
        'no polling client', 'HTTP request failed', 'fixed connection unavailable',
        'No active Douyin page connection', '连接请求超时'))


def recover_preflight(task, account, read, require_allowed, report,
                      probe=None, ensure=None, sleep=None, attempts=2):
    from control import probe as actual_probe
    from startup_recovery import ensure_local_bridge
    probe = probe or actual_probe
    ensure = ensure or ensure_local_bridge
    sleep = sleep or time.sleep
    for attempt in range(attempts):
        require_allowed()
        try:
            result = read()
        except subprocess.TimeoutExpired:
            result = {'status':'not_sent','error':'Request timeout in read-only preflight'}
        if current_stop(result) in ('captcha','rate_limit','identity'):
            raise RuntimeError(LIVE_STOPS[current_stop(result)])
        if not transport_failure(result):
            return result
        report(f'目标尚未提交；本地正在恢复读取连接（{attempt+1}/{attempts}）…')
        with (task/'read-recovery-events.jsonl').open('a',encoding='utf-8') as log:
            log.write(json.dumps({'at':time.time(),'attempt':attempt+1,
                'error':result.get('error'),'submission_attempted':False},ensure_ascii=False)+'\n')
        try:
            ensure()
            identity = probe(timeout=25)
        except (RuntimeError,subprocess.TimeoutExpired,OSError) as exc:
            reason=current_stop({'error':str(exc)})
            if reason in ('captcha','rate_limit','identity') or '多个不同账号' in str(exc):
                raise
        else:
            if identity.get('account_uid') != account:
                raise RuntimeError('重连后账号已变化，未提交，等待确认当前账号。')
            destination=task/'cli-current-binding.json'
            temporary=destination.with_suffix('.reconnect.tmp')
            temporary.write_text(json.dumps(identity,ensure_ascii=False),encoding='utf-8')
            temporary.replace(destination)
        if attempt+1<attempts:
            sleep(1)
    return {'status':'target_check','submission_attempted':False,'automatic_retry':False,
            'diagnosis':{'read_timeout':True,'background_transport':True,'check_complete':False,
                         'target_present':None,'reason':'read_timeout'}}
