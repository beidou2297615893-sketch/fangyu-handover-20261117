@echo off
start "" pythonw "%~dp0status_window.py"
