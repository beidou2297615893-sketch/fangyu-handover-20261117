'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const {createBridgeTransport}=require('./runner.cjs');
test('failed Bridge calls preserve safe cause evidence and never retry',async()=>{
 for(const [error,kind] of [['Request timeout after 30000ms','request_timeout'],['TypeError: Failed to fetch','fetch_failed'],['ReferenceError: helper is not defined','javascript_error'],['unexpected token=synthetic-private-value','bridge_error']]){
  let calls=0;
  const bridge={host:'127.0.0.1',port:0,status:async()=>({connections:{'douyin.com':[{id:'synthetic-binding',alive:true}]}}),call:async()=>{calls++;return {ok:false,error};}};
  const transport=createBridgeTransport(bridge,{connection_id:'synthetic-binding',strict_proof:{verified:true,source:'offline synthetic test'},minimum_delay_ms:0});
  const result=await transport({connection_id:'synthetic-binding',account_uid:'synthetic-owner',kind:'search',target:'synthetic term',cursor:0},10);
  assert.equal(result.ok,false);assert.equal(result.transport_error,'bridge_result_not_established');assert.equal(calls,1);
  assert.equal(result.transport_meta?.bridge_failure_kind,kind);
  assert.equal(result.transport_meta.bridge_error_sha256,crypto.createHash('sha256').update(error).digest('hex'));
  assert(!JSON.stringify(result).includes(error));assert(!JSON.stringify(result).includes('synthetic-private-value'));
 }
});
