// One read-only identity probe against the user's existing Bridge; never log configuration.
const fs = require('fs');
const path = require('path');
const base = path.resolve(__dirname, '../..');
const cfg = JSON.parse(fs.readFileSync(path.join(base, '抖音自用采集台/data/bridge.json'), 'utf8'));
if (cfg.bridge.host !== '127.0.0.1' || cfg.bridge.port !== 19422) throw Error('Unexpected Bridge address');
const { BridgeClient } = require(path.join(base, 'work/runtime/douyin-bridge/lib/client/bridge-client'));
const bridge = new BridgeClient(cfg.bridge);
(async () => {
  const state = await bridge.status();
  const list = (state.connections?.['douyin.com'] || []).filter(x => x.alive);
  if (list.length !== 1) throw Error(`Expected exactly one active Douyin connection; got ${list.length}`);
  const conn = list[0].id;
  const expr = `(async()=>{const p=new URLSearchParams(window.__bridge._q());const r=await fetch('/aweme/v1/web/user/profile/self/?'+p,{credentials:'include'});if(!r.ok)throw Error('self HTTP '+r.status);const d=await r.json();const u=d.user||{};return {status_code:d.status_code,sec_uid:u.sec_uid||'',nickname:u.nickname||'',unique_id:u.unique_id||u.short_id||''}})()`;
  const result = await bridge.call({site:'douyin.com', connId:conn, expression:expr, awaitPromise:true, timeout:30000});
  if (!result.ok || result.connection !== conn) throw Error('Identity request failed or connection could not be established');
  if (!result.value?.sec_uid) throw Error('Identity response did not contain a stable account ID');
  const record={observed_at:new Date().toISOString(), connection_id:conn, account:result.value, state:'observed_not_user_confirmed'};
  const output=process.argv[2]||'identity-probe.json';
  if(!/^[a-z0-9-]+\.json$/.test(output))throw Error('Invalid output name');
  fs.writeFileSync(path.join(__dirname,output), JSON.stringify(record,null,2),{flag:'wx'});
  console.log(JSON.stringify({connected:true,nickname:record.account.nickname,handle:record.account.unique_id,identity_observed:true}));
})().catch(e=>{console.error(e.message);process.exitCode=1;});
