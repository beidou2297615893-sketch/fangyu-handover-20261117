﻿$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding
$env:PYTHONIOENCODING = 'utf-8'
$Host.UI.RawUI.WindowTitle = '方隅抖音回复实时状态 · 只读 · 上限200条'
python -u (Join-Path $PSScriptRoot 'watch_replies.py')
