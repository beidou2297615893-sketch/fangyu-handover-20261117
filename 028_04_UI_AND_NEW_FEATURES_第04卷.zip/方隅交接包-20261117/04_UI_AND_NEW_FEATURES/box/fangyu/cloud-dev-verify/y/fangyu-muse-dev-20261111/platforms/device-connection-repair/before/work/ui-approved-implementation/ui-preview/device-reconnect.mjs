// Resume an already bound employee connection once per page lifetime. Never log in a
// platform account, enroll a device, start a task, or retry an unknown action.
export function createDeviceReconnect({state,prepare,hasUnconfirmed}){
  const attempted=new Set();
  return async function reconnect(){
    const p=state.platform,d=p?.device,user=state.user,analysis=p?.acquisition?.analysis;
    if(state.connection!=='connected'||!user||state.session?.user?.username!==user
      ||!state.storeId||!['acquire','accounts'].includes(state.page)
      ||p?.actor?.username!==user||p.actor.storeId!==state.storeId
      ||d?.bound!==true||d.state!=='offline'||state.busy||hasUnconfirmed()
      ||['submitted','unconfirmed'].includes(p.lastRequest?.state)
      ||['running','starting','pausing','analyzing','queued'].includes(p.acquisition?.status)
      ||p.acquisition?.phase==='analyzing'||analysis?.pending>0
      ||['running','queued','pending','unknown'].includes(analysis?.status)
      ||/UNKNOWN|UNCONFIRMED/.test(analysis?.code||''))return;
    const key=user;
    if(attempted.has(key))return;
    attempted.add(key);state.deviceReconnectOwner=key;state.deviceReconnecting=true;
    try{return await prepare({existingOnly:true});}
    finally{if(state.deviceReconnectOwner===key)state.deviceReconnecting=false;}
  };
}
