from pathlib import Path
import hashlib, json, datetime
T=Path(__file__).resolve().parent
P=Path('C:/积木软件工坊/项目/方隅公寓客户版')
F=P/'work/parallel-integration-20261018/final-integration'
S=F/'stage-02/project'
relative='work/ui-approved-implementation/ui-preview/platform-notice.mjs'
p=S/relative
body=p.read_text('utf-8')
assert 'let timer=null,flight=false;' in body
body=body.replace('let timer=null,flight=false;','let timer=null,timerScope=null,flight=false;')
old='''  function sync(){
    if(timer!==null){cancel(timer);timer=null;}
    if(!flight&&targets().length)timer=schedule(tick,5000);
  }
  async function tick(){
    timer=null;if(flight)return;flight=true;'''
new='''  function sync(){
    const wanted=targets().length>0,scope=identity(state);
    if(timer!==null&&(!wanted||timerScope!==scope)){
      cancel(timer);timer=null;timerScope=null;
    }
    if(!flight&&wanted&&timer===null){
      timerScope=scope;timer=schedule(tick,5000);
    }
  }
  async function tick(){
    timer=null;timerScope=null;if(flight)return;flight=true;'''
assert body.count(old)==1
body=body.replace(old,new)
p.write_bytes(body.encode('utf-8'))
(T/'platform-notice.mjs').write_bytes(p.read_bytes())
changes=json.loads((T/'SOURCE-CHANGES.json').read_text('utf-8-sig'))
for row in changes:
    if row['path']==relative:row['after']=hashlib.sha256(p.read_bytes()).hexdigest()
(T/'SOURCE-CHANGES.json').write_bytes((json.dumps(changes,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
rejected={'status':'REJECTED_BEFORE_INSTALL','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reason':'Repeated foreground render postpones background monitor timer; fixed before v20 freeze.','installed':False}
(F/'candidate-unified-v19/NOT-INSTALLED.json').write_bytes((json.dumps(rejected,indent=2)+'\n').encode('utf-8'))
for name in ['prepare','install']:
    body=(T/(name+'_v19.py')).read_text('utf-8').replace('v19','v20')
    (T/(name+'_v20.py')).write_bytes(body.encode('utf-8'))
print(json.dumps({'status':'FIXED_MONITOR_CADENCE','sha256':hashlib.sha256(p.read_bytes()).hexdigest()}))
