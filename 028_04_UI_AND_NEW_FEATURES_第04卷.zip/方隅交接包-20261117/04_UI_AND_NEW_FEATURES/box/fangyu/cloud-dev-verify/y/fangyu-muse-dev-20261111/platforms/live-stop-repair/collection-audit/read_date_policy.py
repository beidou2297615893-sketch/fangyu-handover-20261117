from pathlib import Path
import json,sqlite3,re
P=Path('C:/积木软件工坊/项目/方隅公寓客户版');H=Path('C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/live-stop-repair/collection-audit');V=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v17/project';b=json.loads((P/'work/ui-native-r57/state/production-workspace.json').read_text('utf-8'));db=sqlite3.connect((Path(b['data_dir'])/'workspace.sqlite3').as_uri()+'?mode=ro',uri=True);db.execute('PRAGMA query_only=ON');user=json.loads(db.execute("SELECT body FROM records WHERE entity='users' AND json_extract(body,'$.username')=?",(b['owner'],)).fetchone()[0]);tasks=[]
for tid in [r['task_id'] for r in json.loads((H/'WIRE-AND-ORIGIN.json').read_text('utf-8'))['tasks']]:
 task=json.loads(db.execute("SELECT body FROM records WHERE entity='tasks' AND tenant_id=? AND id=? AND json_extract(body,'$.cloud_owner')=?",(user['tenant_id'],tid,b['owner'])).fetchone()[0]);tasks.append({k:task.get(k) for k in ('id','scope','continuous_enabled','comment_keyword_mode','comment_date_range','comment_date_from','comment_date_to','date_from','date_to','unknown_policy','comment_depth','intent_mode')})
db.close();web=V/'work/ui-runtime-r55/src/web/workspace/index.html';text=web.read_text('utf-8');matches=[]
for pattern in ('帖子时间','评论时间','commentDateRange','dateFrom','dateTo'):
 found=list(re.finditer(re.escape(pattern),text));matches.append({'needle':pattern,'occurrences':len(found),'first_contexts':[{'line':text.count('\n',0,m.start())+1,'context':text[max(0,m.start()-170):m.end()+190]} for m in found[:5]]})
result={'tasks':tasks,'UI_evidence':matches};(H/'DATE-POLICY-EVIDENCE.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(result,ensure_ascii=False,indent=2))
