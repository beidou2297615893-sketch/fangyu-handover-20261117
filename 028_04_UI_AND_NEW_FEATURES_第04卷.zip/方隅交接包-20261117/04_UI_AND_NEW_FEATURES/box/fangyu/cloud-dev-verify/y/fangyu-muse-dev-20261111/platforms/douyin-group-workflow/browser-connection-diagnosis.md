# 2026-09-18 浏览器连接诊断

用户授权排错，不改网站权限、不退出抖音。

- Chrome扩展可发现，但listTabs连续约21秒后报nodeRepl.fetch request failed。
- 用户截图确认ChatGPT扩展已启用，网站访问权限为所有网站。
- Windows NativeMessagingHosts中com.openai.codexextension注册存在；注册指向的extension-host.exe文件存在；排错前进程16380运行中。
- 已精确校验路径并停止唯一匹配通信进程，以触发Chrome自动重连；未关闭Chrome、未修改注册表、未更改扩展权限。随后重置工具会话并重新发现Chrome，但listTabs仍失败。
- Codex日志另有当前任务的“No ChatGPT browser route is available for browser session”错误，此证据属于内置浏览器，不能直接认定为Chrome故障根因。
- 尚未修复；不能将可发现浏览器当作成功连接。

后续恢复需要重新建立扩展与桌面应用之间的会话，或由应用维护方诊断连接层。不要继续重复扩展权限检查，不要绕过网址识别检查，不要手写工具私有通信协议。
