const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const actor=s=>`${s.authEpoch||0}|${s.user}|${s.storeId||''}|${s.activePlatform||'xiaohongshu'}`;
const matches=(s,p)=>p?.actor?.username===s.user&&p?.actor?.storeId===s.storeId;
const labels={prepared:'已准备，尚未授权发送',awaiting_collection:'已授权，等待采集本批结束',running:'正在按已授权快照顺序发送',completed:'本批处理完成',stopped:'本批已停止，请核对逐条结果',cancelled:'已停止后续发送',interrupted:'原批次已中断，未自动续发',authorization_expired:'原发送授权已失效，未自动续发',blocked:'发送被当前平台或设备条件阻止',empty:'暂无发送批次',not_found:'未找到原准备操作'};
function model(state){
  if(!state.replyDelivery||state.replyDelivery.actor!==actor(state)||state.replyBatchIds){state.replyDelivery={actor:actor(state),customerIds:[...(state.replyBatchIds||[])],chosen:[],names:{},plan:null,busy:false,attempt:null,error:''};delete state.replyBatchIds;}
  return state.replyDelivery;
}
const summary=(text,n=100)=>String(text||'').length>n?String(text).slice(0,n)+'…':String(text||'');
export function renderDelivery(state,v){
  const d=model(state),label=d.attempt?'发送结果待核对':d.error?'查看发送结果':d.plan?.canCancel?'发送状态':d.plan?.canStart?'待授权发送':d.customerIds.length?`本批客户 ${d.customerIds.length} 位`:'发送与批次';
  return `<button type="button" data-delivery-open title="${esc(d.plan?labels[d.plan.state]||'查看发送状态':'查看批量准备、发送记录与停止操作')}">${esc(label)}</button>`;
}
function panelHtml(state,v){
  const d=model(state),row=v.detail?.comments?.find(r=>r.id===v.leadId),p=d.plan;
  const usable=row?.reviewCurrent&&row.draft?.status==='approved'&&!v.dirty&&!v.pending&&!v.busy&&!d.busy&&!d.attempt;
  const ready=d.chosen.length>0&&d.customerIds.every(id=>d.chosen.some(c=>c.customerId===id));
  return `<div class="reply-page" style="max-height:55vh;overflow:auto;overflow-wrap:anywhere"><div class="rp-evidence" aria-label="人工确认发送与批量回复"><span>请核对回复正文；点击最后的发送按钮才会发送。</span>${d.customerIds.length?`<span>本批客户 ${d.customerIds.length} 位：${d.customerIds.map(id=>`<button type="button" class="rp-text-link" data-delivery-customer="${esc(id)}">${esc(d.names[id]||('选择客户 '+id.slice(0,6)))}</button>`).join(' ')}</span>`:''}<div class="rp-editor-actions"><button type="button" class="rp-secondary" data-delivery-add ${!usable?'disabled':''}>将本条加入本批</button><button type="button" class="rp-secondary" data-delivery-single ${!usable?'disabled':''}>准备发送本条</button><button type="button" class="rp-primary" data-delivery-prepare ${!ready||d.busy||d.attempt?'disabled':''}>准备本批 ${d.chosen.length} 条</button><button type="button" class="rp-secondary" data-delivery-status ${d.busy?'disabled':''}>${d.attempt?'核对上次发送操作':'刷新发送状态 / 最近批次'}</button></div>${d.chosen.map((c,i)=>`<span>${i+1}. ${esc(c.name)} · ${esc(summary(c.comment))} <button type="button" class="rp-text-link" data-delivery-remove="${esc(c.leadId)}" ${d.busy||d.attempt?'disabled':''}>移除</button></span>`).join('')}${p?`<span><strong>${esc(labels[p.state]||p.state)}</strong> · ${p.sent||0}/${p.items?.length||0} 条有成功记录</span><span>${esc(p.message)}</span>${(p.items||[]).map((r,i)=>`<span>${i+1}. ${esc(r.customerName)} · ${esc(r.status)}${r.message?' · '+esc(r.message):''}</span>`).join('')}<div class="rp-editor-actions">${p.canStart?`<button type="button" class="rp-primary" data-delivery-authorize ${d.busy||d.attempt?'disabled':''}>核对并授权本批发送</button>`:''}${p.canCancel?`<button type="button" class="rp-secondary" data-delivery-cancel ${d.busy||d.attempt?'disabled':''}>停止后续发送</button>`:''}</div>`:''}${d.error?`<span role="alert">${esc(d.error)}</span>`:''}${d.attempt?'<span>上次操作结果未确认，只能核对状态，不能重复发起。</span>':''}</div></div>`;
}
function selectedItem(v){const row=v.detail?.comments?.find(r=>r.id===v.leadId);if(!row?.reviewCurrent||row.draft?.status!=='approved'||v.dirty||v.pending||v.busy)return null;return {customerId:v.selectedId,leadId:row.id,sourceDigest:row.sourceDigest,replyId:row.draft.id,version:row.draft.version,accountId:row.draft.review_account_id,name:v.detail.item.name,comment:row.text};}
const payload=item=>Object.fromEntries(['customerId','leadId','sourceDigest','replyId','version','accountId'].map(k=>[k,item[k]]));
function fullList(plan){return `<p>共 ${plan.items.length} 条。请核对每一条；最后点击才授权原队列顺序发送。</p><div style="max-height:55vh;overflow:auto;overflow-wrap:anywhere">${plan.items.map((r,i)=>`<section><h3>${i+1}. ${esc(r.customerName)} · ${esc(r.accountName)}</h3><p>来源：${esc(r.postTitle)}</p><p>完整原评论：</p><blockquote style="white-space:pre-wrap">${esc(r.comment)}</blockquote><p>回复正文：</p><blockquote style="white-space:pre-wrap">${esc(r.text)}</blockquote></section>`).join('')}</div><p>取消只能停止后续条目，在途项可能完成；未知结果不会自动重试。</p>`;}
function confirmPlan(state,ctx,d){
  const plan=d.plan;if(!plan?.canStart||d.busy||d.attempt)return;
  const scope=actor(state),id=plan.id,digest=plan.snapshotDigest;
  ctx.modal({title:`最终授权本批发送 ${plan.items.length} 条`,html:fullList(plan),confirmLabel:`授权发送本批 ${plan.items.length} 条`,onConfirm:async()=>{
    if(scope!==actor(state)||state.replyDelivery!==d||d.plan?.id!==id||d.plan?.snapshotDigest!==digest)return false;
    const requestId=crypto.randomUUID();return operation(state,ctx,d,'start',{id,snapshotDigest:digest,confirmed:true,requestId});
  }});
}
async function operation(state,ctx,d,kind,data){
  if(d.busy||d.attempt)return false;
  const scope=actor(state);d.busy=true;d.error='';d.attempt={kind,...data};ctx.update(()=>{});
  try{
    const result=await ctx.deliveryAction(kind,{storeId:state.storeId,...data});
    if(scope!==actor(state)||state.replyDelivery!==d)return false;
    if(!matches(state,result.delivery))throw new Error('发送批次的员工或门店范围已变化。');
    d.plan=result.delivery;d.attempt=null;if(kind==='prepare'){d.busy=false;confirmPlan(state,ctx,d);}
    return true;
  }catch(error){if(scope===actor(state)&&state.replyDelivery===d){if(!['RESULT_UNCONFIRMED','DELIVERY_RESULT_UNCONFIRMED'].includes(error.code))d.attempt=null;d.error=error.message;ctx.replyError(error);}return false;}
  finally{if(scope===actor(state)&&state.replyDelivery===d){d.busy=false;ctx.update(()=>{});}}
}
export function prepareReviewedBatch(state,ctx,v,items){
  const d=model(state);if(!items.length||items.length>20||d.busy||d.attempt)return false;
  d.chosen=items;d.customerIds=items.map(i=>i.customerId);
  return operation(state,ctx,d,'prepare',{items:items.map(payload),requestId:crypto.randomUUID()});
}
export function prepareReviewed(state,ctx,v){
  const d=model(state),row=selectedItem(v);
  if(state.connection!=='connected'||!state.session||state.page!=='reply'||d.busy||d.attempt||!row)return false;
  return operation(state,ctx,d,'prepare',{items:[payload(row)],requestId:crypto.randomUUID()});
}
function bindControls(root,ctx,v,select){
  if(!root?.querySelector)return;
  const state=ctx.state,d=model(state);if(v.detail?.item)d.names[v.selectedId]=v.detail.item.name;
  root.querySelectorAll('[data-delivery-customer]').forEach(el=>el.addEventListener('click',()=>select(el.dataset.deliveryCustomer)));
  root.querySelectorAll('[data-delivery-remove]').forEach(el=>el.addEventListener('click',()=>{if(d.busy||d.attempt)return;const removed=d.chosen.find(c=>c.leadId===el.dataset.deliveryRemove);d.chosen=d.chosen.filter(c=>c!==removed);if(removed&&!d.chosen.some(c=>c.customerId===removed.customerId))d.customerIds=d.customerIds.filter(id=>id!==removed.customerId);ctx.update(()=>{});}));
  root.querySelector('[data-delivery-add]')?.addEventListener('click',()=>{if(d.busy||d.attempt)return;const row=selectedItem(v);if(!row)return;if(d.chosen.length>=20&&!d.chosen.some(c=>c.leadId===row.leadId)){ctx.toast('每批最多20条，请先处理当前批次。');return;}d.chosen=[...d.chosen.filter(c=>c.leadId!==row.leadId),row];if(!d.customerIds.includes(row.customerId))d.customerIds.push(row.customerId);ctx.update(()=>{});});
  root.querySelector('[data-delivery-single]')?.addEventListener('click',()=>{const row=selectedItem(v);if(row)operation(state,ctx,d,'prepare',{items:[payload(row)],requestId:crypto.randomUUID()});});
  root.querySelector('[data-delivery-prepare]')?.addEventListener('click',()=>{if(!d.chosen.length||!d.customerIds.every(id=>d.chosen.some(c=>c.customerId===id)))return;operation(state,ctx,d,'prepare',{items:d.chosen.map(payload),requestId:crypto.randomUUID()});});
  root.querySelector('[data-delivery-authorize]')?.addEventListener('click',()=>confirmPlan(state,ctx,d));
  root.querySelector('[data-delivery-cancel]')?.addEventListener('click',()=>{const plan=d.plan;if(!plan?.canCancel)return;ctx.modal({title:'停止后续发送',html:'<p>后续未发送条目将停止。本次身份核验或已经在途的一条可能完成，不能撤回已发内容。</p>',confirmLabel:'停止后续条目',onConfirm:()=>operation(state,ctx,d,'cancel',{id:plan.id})});});
  root.querySelector('[data-delivery-status]')?.addEventListener('click',async()=>{
    if(d.busy)return;const scope=actor(state),attempt=d.attempt;d.busy=true;ctx.update(()=>{});
    try{const lookup=attempt?.kind==='prepare'?{requestId:attempt.requestId}:d.plan?.id?{id:d.plan.id}:{};const result=await ctx.deliveryAction('status',{storeId:state.storeId,...lookup});if(scope!==actor(state)||state.replyDelivery!==d)return;if(!matches(state,result.delivery))throw new Error('发送状态范围已变化。');d.plan=result.delivery.state==='not_found'?null:result.delivery;d.attempt=null;d.error='已读取当前结果；不会自动续发或重试。';}
    catch(error){if(scope===actor(state)&&state.replyDelivery===d){d.error=error.message;ctx.replyError(error);}}
    finally{if(scope===actor(state)&&state.replyDelivery===d){d.busy=false;ctx.update(()=>{});}}
  });
}
export function bindDelivery(root,ctx,v,select){
  bindControls(root,ctx,v,select);
  root.querySelector('[data-delivery-open]')?.addEventListener('click',()=>{
    const state=ctx.state,d=model(state),scope=actor(state),h={dialog:null,owner:null};
    const owns=()=>state.replyDelivery===d&&scope===actor(state)&&state.page==='reply'&&h.dialog?.open!==false&&h.dialog?.__modalOwner===h.owner;
    const panelCtx={...ctx,update:fn=>{ctx.update(fn);if(owns())show();}};
    const show=()=>{
      if(state.replyDelivery!==d||scope!==actor(state)||state.page!=='reply')return;
      h.dialog=ctx.modal({title:'发送与批次',html:panelHtml(state,v)});h.owner=h.dialog?.__modalOwner;
      bindControls(h.dialog,panelCtx,v,id=>{h.dialog?.close();select(id);});
    };
    show();
  });
}
