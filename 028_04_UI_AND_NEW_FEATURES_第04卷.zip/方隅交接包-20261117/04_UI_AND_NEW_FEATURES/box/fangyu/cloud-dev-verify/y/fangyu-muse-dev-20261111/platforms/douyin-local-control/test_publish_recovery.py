import unittest
from publish_recovery import unavailable_target

class PublishRecoveryTests(unittest.TestCase):
    def test_only_negative_receipt_and_missing_video_can_be_skipped(self):
        result={'receipt':{'status_code':2053},'diagnosis':{'detail_status':0,'video_present':False,'no_video_detail':True}}
        self.assertTrue(unavailable_target(result))
        self.assertTrue(unavailable_target(dict(result,receipt={'status_code':2209})))
        for code in (3002123,2147,0):
            self.assertFalse(unavailable_target(dict(result,receipt={'status_code':code})))
        self.assertFalse(unavailable_target(dict(result,receipt={'status_code':2053,'cid':'reply'})))
        self.assertFalse(unavailable_target(dict(result,diagnosis={})))

if __name__=='__main__':unittest.main()
