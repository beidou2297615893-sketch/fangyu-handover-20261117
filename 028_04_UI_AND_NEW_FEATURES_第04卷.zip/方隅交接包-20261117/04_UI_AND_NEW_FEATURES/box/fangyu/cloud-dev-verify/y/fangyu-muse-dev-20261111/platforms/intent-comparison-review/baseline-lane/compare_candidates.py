"""Compare CPU candidates with blinded AI reference; never print source text.

The reference is not human-confirmed; metrics do not establish true accuracy.
The runner must disclose whether full context and source hashes were captured.
"""
from pathlib import Path
from collections import Counter, defaultdict
import hashlib
import json
import sys

HERE = Path(__file__).resolve().parent
TASK = HERE.parent
CPU = TASK.parent / 'intent-comparison-cpu' / 'candidate' / 'predictions.json'
BGE = TASK.parent / 'intent-comparison-paddle' / 'candidate-reranker-v2.json'
REFERENCE = ('positive', 'no_evidence', 'supply', 'uncertain')
CLASSES = {'本人询租证据': 'positive', '未见本人需求证据': 'no_evidence',
           '房源供给': 'supply', '信息不足': 'uncertain',
           'rental': 'positive', 'no_evidence': 'no_evidence',
           'provider': 'supply', 'uncertain': 'uncertain'}

def read(path):
    raw = path.read_bytes()
    return json.loads(raw.decode('utf-8-sig')), hashlib.sha256(raw).hexdigest()

def main():
    if len(sys.argv) != 2 or sys.argv[1] not in ('qwen', 'bge'):
        raise ValueError('choose qwen or bge')
    kind = sys.argv[1]
    source = CPU if kind == 'qwen' else BGE
    data, source_hash = read(source)
    labels, labels_hash = read(TASK / 'blind_agent_labels.json')
    if labels.get('humanConfirmed') is not False or labels.get('blinded_to_predictions') is not True:
        raise ValueError('Review provenance mismatch')
    ref = {}
    for row in labels['labels']:
        if row['sample'] in ref or row['expected_evidence_class'] not in REFERENCE:
            raise ValueError('Duplicate or invalid reference')
        ref[row['sample']] = row['expected_evidence_class']
    ref_hashes = {x['file']: x['sha256'] for x in labels['source_files']}
    raw = {}
    if kind == 'qwen':
        for row in data['results']:
            ds = row['source_set']
            raw.setdefault(ds, []).append(row)
    else:
        raw = {ds: group['results'] for ds, group in data['results'].items()}
    groups = {}
    seen = set()
    for ds in ('blind_sample.json', 'blind_challenge.json'):
        sample, sample_hash = read(TASK / ds)
        if ref_hashes.get(ds) != sample_hash:
            raise ValueError('Reference/sample hash mismatch')
        if kind == 'bge' and data['results'][ds]['source_sha256'] != sample_hash:
            raise ValueError('BGE/sample source hash mismatch')
        ids = {r['sample'] for r in sample['customers']}
        prediction = {}
        for row in raw.get(ds, []):
            if row['sample'] in prediction:
                raise ValueError('Duplicate prediction')
            prediction[row['sample']] = row
        extra = set(prediction) - ids
        if extra: raise ValueError('Unexpected extra predicted sample IDs')
        table = defaultdict(Counter)
        counts = Counter()
        disagreements = []
        for name in sorted(ids):
            if name in seen or name not in ref: raise ValueError('Duplicate or missing reference')
            seen.add(name)
            expected = ref[name]
            row = prediction.get(name)
            if row is None:
                actual = 'missing'
            elif kind == 'qwen' and row.get('status') != 'ok':
                actual = 'execution_error'
            else:
                code = row.get('predicted_class') if kind == 'qwen' else row.get('top')
                actual = CLASSES.get(code, 'invalid')
            table[expected][actual] += 1
            counts['total'] += 1
            if actual in ('missing', 'execution_error', 'invalid'):
                counts[actual] += 1
                continue
            if expected == 'uncertain':
                counts['reference_uncertain'] += 1
                continue
            counts['clear_reference'] += 1
            if actual == 'uncertain':
                counts['candidate_uncertain_on_clear'] += 1
                continue
            counts['candidate_decisive_on_clear'] += 1
            positive = expected == 'positive'
            predicted_positive = actual == 'positive'
            if positive and predicted_positive: counts['tp'] += 1
            elif not positive and predicted_positive: counts['fp'] += 1
            elif positive and not predicted_positive: counts['fn'] += 1
            else: counts['tn'] += 1
            if positive != predicted_positive:
                disagreements.append({'sample': name, 'reference_class': expected, 'candidate_class': actual})
        groups[ds] = {
            'reference_by_candidate': {category: dict(table.get(category, {})) for category in REFERENCE},
            'counts': dict(counts),
            'binary_agreement_ratio_among_decisive_clear': (counts['tp'] + counts['tn']) / counts['candidate_decisive_on_clear'] if counts['candidate_decisive_on_clear'] else None,
            'positive_precision_among_decisive_clear': counts['tp'] / (counts['tp'] + counts['fp']) if counts['tp'] + counts['fp'] else None,
            'positive_recall_among_decisive_clear': counts['tp'] / (counts['tp'] + counts['fn']) if counts['tp'] + counts['fn'] else None,
            'binary_disagreement_ids_only': disagreements,
            'source_sample_sha256': sample_hash,
            'candidate_source_hash_attested_by_output': kind == 'bge',
        }
    if seen != set(ref): raise ValueError('Reference set does not match samples')
    output = {
        'model': data['model'], 'model_sha256': data.get('model_sha256'),
        'cpu_only': data.get('cpu_only'), 'prediction_file_sha256': source_hash,
        'labels_file_sha256': labels_hash,
        'limitations': [
            'Reference is a blinded independent AI review, not human-confirmed truth.',
            'Reference concerns observed demand evidence at comment time, not confirmed current demand or conversion.',
            'Uncertain is reported as its own class; it is excluded from binary agreement denominators.',
            'No-evidence means no observed evidence in available text, not proof a person has no need.',
            'The challenge sample is enriched, not representative; do not pool with the random sample.',
            'BGE uses the top of four text-similarity labels and has no confidence threshold. Scores are not probabilities.',
            'Qwen output did not itself retain sample file hashes, so hash attestation cannot prove the exact bytes the runner saw.',
        ],
        'groups': groups,
    }
    (HERE / (kind + '-blind-comparison.json')).write_text(json.dumps(output, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    for ds, group in groups.items():
        print(ds, json.dumps({'reference_by_candidate': group['reference_by_candidate'], 'counts': group['counts']}, ensure_ascii=False))

if __name__ == '__main__':
    main()
