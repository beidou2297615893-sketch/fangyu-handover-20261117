"""Exact public open endpoint: passive readiness then one guarded handoff."""
from test_session_handoff import *
tree=ast.parse(runtime_path.read_text('utf-8'))
names={'_watch_acquisition_verification','open_acquisition_verification','_verification_state'}
methods=[copy.deepcopy(n) for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name in names]
space={'threading':threading,'time':time,'json':json,'os':os,'uuid4':lambda:SimpleNamespace(hex=os.urandom(16).hex())}
exec(compile(ast.fix_missing_locations(ast.Module(body=[ast.ClassDef(name='AutoRuntime',bases=[],keywords=[],body=methods,decorator_list=[])],type_ignores=[])),str(runtime_path),'exec'),space)
AutoRuntime=space['AutoRuntime']
class AutoHandoffTests(HandoffTests):
 def auto(self):
  user,server,service=self.environment();runtime=AutoRuntime()
  task={'id':self.task,'account_id':self.account['id'],'pipeline':{}}
  runtime.data_dir=self.root;runtime._run_lock=threading.RLock();runtime._verification_waits={};runtime.closed=False
  runtime._verification_task=lambda u,d:(user,task,self.account)
  runtime._collection_binding=lambda t:'fixed';runtime._verified_scope=lambda *a:self.scope
  runtime._verification_windows=lambda *a:[self.job]
  self.opens=[];self.resumes=[]
  def open_window(u,d):
   self.opens.append(d);return {'result':{'status':'verification_open'}}
  runtime.open_account_verification=open_window
  runtime.resume_verified_acquisition=lambda u,d,**k:self.resumes.append(d)
  runtime.open_acquisition_verification(user,{'taskId':self.task})
  self.wait=runtime._verification_waits[self.task]
  end=time.monotonic()+1
  while not (self.stage/'verification-watch.json').exists() and time.monotonic()<end:time.sleep(.01)
  self.assertTrue((self.stage/'verification-watch.json').is_file())
  self.assertEqual(self.opens,[{'accountId':self.account['id']}])
  return runtime,user,task
 def ready(self,nonce=None):
  nonce=nonce or self.wait['request'];p=self.stage/('verification-ready-'+nonce+'.json')
  p.write_text(json.dumps({'version':1,'request':nonce,'state':'ready'}),encoding='ascii')
 def test_auto_wait_has_no_resume_without_readiness(self):
  runtime,user,task=self.auto();time.sleep(.6);self.assertEqual(self.resumes,[])
  self.wait['cancel'].set();self.wait['thread'].join(2)
 def test_matching_readiness_hands_off_exact_original_task_once(self):
  runtime,user,task=self.auto();self.ready();self.wait['thread'].join(2)
  self.assertEqual(self.resumes,[{'taskId':self.task}]);self.assertEqual(self.wait['state'],'resumed')
  self.assertEqual(runtime._verification_state(user,task)['state'],'resumed')
 def test_wrong_readiness_nonce_cannot_continue(self):
  runtime,user,task=self.auto();self.ready('f'*32);time.sleep(.6);self.assertEqual(self.resumes,[])
  self.wait['cancel'].set();self.wait['thread'].join(2)
 def test_receipt_changed_to_unknown_cannot_continue(self):
  runtime,user,task=self.auto();self.receipt['state']='unknown';self.path.write_text(json.dumps(self.receipt))
  self.ready();self.wait['thread'].join(2);self.assertEqual(self.resumes,[])
 def test_cancelled_wait_cannot_late_continue(self):
  runtime,user,task=self.auto();self.wait['cancel'].set();self.ready();self.wait['thread'].join(2)
  self.assertEqual(self.resumes,[])
if __name__=='__main__':
 suite=unittest.TestSuite(AutoHandoffTests(n) for n in [
  'test_auto_wait_has_no_resume_without_readiness','test_matching_readiness_hands_off_exact_original_task_once',
  'test_wrong_readiness_nonce_cannot_continue','test_receipt_changed_to_unknown_cannot_continue','test_cancelled_wait_cannot_late_continue'])
 result=unittest.TextTestRunner(verbosity=2).run(suite)
 (T/'AUTO-HANDOFF-TESTS.json').write_text(json.dumps({'status':'PASS' if result.wasSuccessful() else 'FAIL','tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'synthetic_only':True}))
 raise SystemExit(not result.wasSuccessful())
