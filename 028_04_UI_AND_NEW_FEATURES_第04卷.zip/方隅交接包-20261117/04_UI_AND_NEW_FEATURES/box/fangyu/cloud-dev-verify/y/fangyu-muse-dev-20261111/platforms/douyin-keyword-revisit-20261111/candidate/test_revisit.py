import json,sqlite3,tempfile,unittest
from pathlib import Path
import current_collection as c

class Revisit(unittest.TestCase):
 def test_empty_comments_without_cursor_can_be_skipped_not_retried(self):
  from scoped_recovery import verification_resume_evidence
  checks=[{'stage':'identity_before','uid_matches':True,'status_code':0},{'stage':'identity_after','uid_matches':True,'status_code':0}]
  v={'ok':True,'transport_meta':{'http_status':200,'identity_verified':True,'identity_checks':checks},'value':{'comment_common_data':{},'status_code':0,'comments':None,'has_more':0}}
  self.assertTrue(verification_resume_evidence('invalid_response',v))
  without_optional={**v,'value':{k:val for k,val in v['value'].items() if k!='comment_common_data'}}
  self.assertTrue(verification_resume_evidence('invalid_response',without_optional))
  self.assertFalse(verification_resume_evidence('invalid_response',{**v,'value':{'status_code':0,'has_more':0}}))
  self.assertFalse(verification_resume_evidence('invalid_response',{**v,'value':{**v['value'],'status_code':8}}))
  self.assertFalse(verification_resume_evidence('invalid_response',{**v,'value':{**v['value'],'comments':[{'cid':'1'}]}}))
  self.assertFalse(verification_resume_evidence('invalid_response',{**v,'transport_meta':{**v['transport_meta'],'identity_checks':checks[:1]}}))
  from scoped_recovery import initialize,effective_halt
  import hashlib
  d=sqlite3.connect(':memory:');d.row_factory=sqlite3.Row
  d.executescript('create table account_halts(account_uid,request_id,state,detail,halted_at);create table attempts(request_id,state,added,spec,response);');initialize(d)
  raw=json.dumps(v);spec=json.dumps({'account_uid':'a','scan_id':'old','kind':'comments','target':'222','keyword':'oldword'})
  d.execute('insert into attempts values(?,?,?,?,?)',('r','invalid_response',0,spec,raw))
  d.execute('insert into collection_halt_events values(?,?,?,?,?)',('a','r','invalid_response','empty','now'))
  d.execute('insert into collection_event_reviews values(?,?,?,?,?,?,?)',('a','new','r',hashlib.sha256(raw.encode()).hexdigest(),'authorized','identity','now'))
  self.assertIsNone(effective_halt(d,'a','new',{'kind':'comments','target':'333','keyword':'fresh'}))
  self.assertIsNotNone(effective_halt(d,'a','new',{'kind':'comments','target':'222','keyword':'fresh'}))
  self.assertEqual(d.execute('select state,response from attempts').fetchone()['state'],'invalid_response')
 def test_known_targets_cycle_but_unknown_and_orphan_never_replay(self):
  with tempfile.TemporaryDirectory() as t:
   r=Path(t);(r/'runner-live-a').mkdir();(r/'runner-live-b').mkdir()
   (r/'plan.json').write_text(json.dumps({'account_uid':'a','connection_id':'c','scan_id':'s'}))
   orphan=r/'runner-live-b'/'unknown.json'
   orphan.write_text(json.dumps({'state':'prepared_not_dispatched','response':None,'spec':{'request_id':'orphan','kind':'comments','target':'777','keyword':'orphanword','account_uid':'a','connection_id':'c','scan_id':'s'}}))
   (r/'runner-live-b'/'control.json').write_text(json.dumps({'pending':{'request_id':'orphan','phase':'dispatching','record_path':str(orphan)}}))
   (r/'runner-live-a'/'control.json').write_text('{}')
   db=sqlite3.connect(r/'db');db.execute('create table attempts(state,spec)')
   for state,kind,target,keyword in [('parsed','search','done','done'),('unknown','search','unknown','unknown'),('parsed','comments','111','done'),('unknown','comments','222','blocked')]:
    db.execute('insert into attempts values(?,?)',(state,json.dumps({'kind':kind,'target':target,'keyword':keyword,'account_uid':'a'})))
   db.commit();db.close();before=orphan.read_bytes()
   cfg={'stores':[{'keywords':['done','fresh','unknown','blocked','orphanword','never']}], 'excluded_historical_videos':['111','222'], 'diagnostic_keywords_never_automatically_replay':['never']}
   out=c.remaining_config(r,r/'db',{'directory':'runner-live-a','plan':'plan.json'},cfg)
   self.assertEqual(out['stores'][0]['keywords'],['fresh','done'])
   self.assertNotIn('111',out['excluded_historical_videos'])
   self.assertTrue({'222','777'}.issubset(out['excluded_historical_videos']))
   self.assertEqual(before,orphan.read_bytes())

if __name__=='__main__':unittest.main()
