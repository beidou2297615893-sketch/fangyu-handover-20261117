'use strict';
// Independent composition only. Importing this module does not read configuration,
// attach WebSockets, register signal handlers, or listen on any network port.
const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const DEFAULT_UPSTREAM = path.resolve(__dirname, '../../抖音自用采集台/work/collector');
const { ConnectionRegistry } = require(path.join(DEFAULT_UPSTREAM, 'lib/server/registry'));
const { WebSocketHub } = require(path.join(DEFAULT_UPSTREAM, 'lib/server/ws-hub'));
const { Router } = require(path.join(DEFAULT_UPSTREAM, 'lib/server/router'));

function readConfig(file) {
  if (typeof file !== 'string' || !file) throw Error('explicit_config_path_required');
  try { return JSON.parse(fs.readFileSync(path.resolve(file), 'utf8').replace(/^\uFEFF/, '')); }
  catch { throw Error('configuration_unreadable_or_invalid'); }
}

function createStrictBridge(options = {}) {
  const { config, port, host = '127.0.0.1', allowOwned19422 = false } = options;
  if (!Number.isInteger(port) || port < 1024 || port > 65535) throw Error('explicit_independent_port_required');
  // The caller must separately verify ownership of the existing process before
  // explicitly opting in. Neither configuration fields nor environment enable it.
  if (port === 19422 && allowOwned19422 !== true) throw Error('original_port_protected');
  if (host !== '127.0.0.1') throw Error('loopback_host_required');
  const bridgeConfig = config && config.bridge;
  if (!bridgeConfig || typeof bridgeConfig.token !== 'string' || !bridgeConfig.token.trim()) throw Error('configured_token_required');
  const registry = new ConnectionRegistry();
  const hub = new WebSocketHub({ registry, host, port,
    heartbeatInterval: bridgeConfig.heartbeatInterval,
    heartbeatTimeout: bridgeConfig.heartbeatTimeout,
    heartbeatMaxFailures: bridgeConfig.heartbeatMaxFailures,
    maxPayload: bridgeConfig.maxBodySize });
  const router = new Router({ registry, wsHub: hub, token: bridgeConfig.token,
    requestTimeout: bridgeConfig.requestTimeout || 30000,
    maxBodySize: bridgeConfig.maxBodySize,
    strictConnections: true,
    allowedSite: 'douyin.com' });
  const httpServer = http.createServer((req, res) => router.handle(req, res));
  let started = false;
  async function start() {
    if (started) throw Error('already_started');
    started = true;
    try {
      hub.attach(httpServer);
      await new Promise((resolve, reject) => {
        httpServer.once('error', reject);
        httpServer.listen(port, host, () => { httpServer.removeListener('error', reject); resolve(); });
      });
    } catch {
      await stop();
      throw Error('strict_bridge_start_failed_no_original_service_changed');
    }
  }
  async function stop() {
    // Standalone lifecycle: clear only this instance's queues and synthetic state.
    for (const pending of router._pending.values()) {
      clearTimeout(pending.timer);
      pending.reject(new Error('independent_bridge_stopped'));
    }
    router._pending.clear();
    for (const waiters of router._pollWaiters.values()) for (const waiter of waiters) {
      clearTimeout(waiter.timer);
      if (!waiter.res.headersSent) router._sendJson(waiter.res, 503, { ok: false, error: 'independent_bridge_stopped' });
    }
    router._pollWaiters.clear(); router._pollQueue.clear();
    if (httpServer.listening) httpServer.close();
    if (hub._wss) {
      for (const client of hub._wss.clients) client.terminate();
      await hub.stop();
    }
    started = false;
  }
  function summary() {
    return { strictConnections: router.strictConnections, allowedSite: router.allowedSite,
      host, port, credentialConfigured: true, originalConfigurationWritten: false,
      listening: httpServer.listening, owned19422Override: port === 19422 && allowOwned19422 === true,
      activeBridge19422Compatibility: 'UNVERIFIED' };
  }
  return { registry, hub, router, httpServer, start, stop, summary };
}

async function main(args) {
  if (!args.length || args.includes('--help')) {
    console.log('Offline check: node strict-bridge-server.cjs --check-config --config <file> --port <independent-port>');
    console.log('Explicit start: node strict-bridge-server.cjs --serve --config <file> --port <independent-port>');
    console.log('No current service or browser is changed. Port 19422 is protected. Browser compatibility remains unverified.');
    console.log('Only after separately verifying process ownership, --allow-owned-19422 explicitly permits port 19422. It does not verify ownership or browser polling compatibility.');
    return;
  }
  const flags = new Set(['--check-config', '--serve']);
  const values = new Map(); let mode; let allowOwned19422 = false;
  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    if (flags.has(arg)) { if (mode) throw Error('one_explicit_mode_required'); mode = arg; }
    else if (arg === '--allow-owned-19422') {
      if (allowOwned19422) throw Error('duplicate_argument'); allowOwned19422 = true;
    }
    else if (['--config', '--port'].includes(arg) && args[i + 1] && !args[i + 1].startsWith('--')) {
      if (values.has(arg)) throw Error('duplicate_argument'); values.set(arg, args[++i]);
    } else throw Error('invalid_argument');
  }
  if (!mode) throw Error('one_explicit_mode_required');
  const bridge = createStrictBridge({ config: readConfig(values.get('--config')), port: Number(values.get('--port')), allowOwned19422 });
  if (mode === '--check-config') { console.log(JSON.stringify(bridge.summary())); await bridge.stop(); return; }
  await bridge.start();
  console.log(JSON.stringify(bridge.summary()));
  const shutdown = async () => { await bridge.stop(); process.exit(0); };
  process.once('SIGINT', shutdown); process.once('SIGTERM', shutdown);
}

if (require.main === module) main(process.argv.slice(2)).catch(error => {
  // Emit only known fixed error codes, never raw parser errors or configuration.
  const safeErrors = new Set(['explicit_config_path_required', 'configuration_unreadable_or_invalid',
    'explicit_independent_port_required', 'original_port_protected', 'loopback_host_required',
    'configured_token_required', 'already_started', 'strict_bridge_start_failed_no_original_service_changed',
    'one_explicit_mode_required', 'duplicate_argument', 'invalid_argument']);
  console.error(safeErrors.has(error.message) ? error.message : 'strict_bridge_failed'); process.exitCode = 1;
});
module.exports = { createStrictBridge, readConfig, DEFAULT_UPSTREAM };
