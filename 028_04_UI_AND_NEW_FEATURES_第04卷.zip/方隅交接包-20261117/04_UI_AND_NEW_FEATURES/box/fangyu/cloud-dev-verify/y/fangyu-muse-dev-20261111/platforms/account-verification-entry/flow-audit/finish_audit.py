from pathlib import Path
import datetime,hashlib,json,sqlite3
T=Path(__file__).resolve().parent;A=T.parent
P=Path('C:/积木软件工坊/项目/方隅公寓客户版');N=P/'work/ui-native-r57';F=P/'work/parallel-integration-20261018/final-integration'
read=lambda p:json.loads(p.read_text('utf-8-sig'))
staged=read(F/'candidate-unified-v25/STAGED.json');active=read(N/'state/active.json')
assert active['release']==staged['release_id']
plan=read(F/'entry-v25/CANONICAL-DELEGATION-PREPARED.json')
assert hashlib.sha256((N/'run_workbench.py').read_bytes()).hexdigest().upper()==plan['launcher_sha256']
assert read(T/'FLOW-TESTS.json')['status']=='PASS' and read(T/'RULE-ROUNDTRIP.json')['passed']
assert '准备发送' in (T/'reopened-reply-ui.txt').read_text('utf-8')
binding=read(N/'state/production-workspace.json');D=Path(binding['data_dir'])
db=sqlite3.connect((D/'workspace.sqlite3').as_uri()+'?mode=ro',uri=True)
runs=[json.loads(r[0]) for r in db.execute("select body from records where entity='workbench_collection_run_v1'")]
current=[r for r in runs if any(r.get(k)=='d36660aed1804857b4f58a2fdc42958a' for k in ('id','task_id','taskId'))]
receipt={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'INSTALLED_AND_ORIGINAL_ENTRY_REOPENED','release':staged['release_id'],'launcher_sha256':plan['launcher_sha256'],'closure_files':2723,'changed_source_files':read(A/'FLOW-CHANGES.json'),'python_behavior_tests':32,'node_qr_behavior_test_passed':True,'node_rule_roundtrip_tests':3,'real_customer_export_rows':82,'single_reply_ui':'saved_reviewed_prepared_final_confirmation_not_sent','draft_survives_normal_reopen':True,'account_ui':'connected','batch_ui':'blocked_by_both_empty_company_SOP_templates','customer_xlsx_import':'not_implemented','rules_import':'isolated_roundtrip_passed_no_production_rule_write','platform_write_calls':0,'collection_waits_for_human':False,'continuous_collection_verified':False,'current_collection_run':current}
(T/'FINAL-DELIVERY.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8')
report='''# 当前实测结果

小红书 CLI 当前为 0.6.4，与官方最新发布版一致；比对的六个主要源码文件也与上游一致。没有因为版本旧而需要升级的证据。

频繁验证目前发生在小红书的评论回复读取环节。平台实际要求身份核验；账号页显示已连接，并不代表每个读取请求都会获准。最后两次读取请求间隔约四秒，仍再次触发验证。目前无法确定平台究竟按账号、网络还是会话触发，不能承诺完成一次验证后可连续采集多久。

已安装两处修复：普通点击和按键不会再被当成验证完成；扫码身份验证提示会继续阻止自动续采。批量回复中途撤销员工回复权限后，队列会停止后续发送。原先居中的提示和底部收起方式保留，其他页面仍可操作。

| 流程 | 实测结果 |
| --- | --- |
| 客户列表、分页、账号状态 | 真实界面可用；账号显示已连接，客户共82位 |
| 客户 Excel 导出 | 真实界面导出成功，文件核对82行客户、15个业务栏目 |
| 回复草稿、逐条审核、发送预览 | 真实界面已到最终发送确认；重开后正文和审核状态保留 |
| 批量回复 | 临时测试数据下，顺序处理、权限撤销、未知结果不重复发送等检查通过；真实界面因两套公司回复话术均未填写，套用功能给出提示，未完成真实整批发送 |
| 规则导入 | 临时测试数据下，导出、分片上传、预览、应用和冲突核对通过；未改线上规则 |
| 客户 Excel 导入 | 当前客户端没有这个入口，不能视为已支持；它也不是小红书 CLI 的原生能力 |
| 采集 | 当前累计18条评论，新增10位客户；平台要求验证，按当前要求暂不继续等待或反复重试 |

本次共通过32项 Python 行为检查、二维码识别检查及3项规则导入检查。真实对外回复没有发送。持续采集速度、真人扫码后连续采集，以及抖音账号的真实流程尚未完成验证。

当前导出文件为“客户清单82位.xlsx”。原“客户清单.xlsx”为之前的72位快照。
'''
(P/'outputs/验证续接实测/实测结果.md').write_text(report,encoding='utf-8')
continuation='''# 当前续行摘要

用户最新要求：无法扫码，不等验证；采集能修就修，不能先放旁边；核对CLI最新、跑导出导入回复一键回复。该轮检查已完成，不能声称所有真实流程已通过。

已安装并从原桌面入口正常重开 v25：release ui-r57-20261019T115208Z-fb9458d0；launcher SHA 1C91A54C165A671922B8CD86A352A051058F31BFB59555EEE055E798DB80D6C6。2723文件冻结和原入口--check通过，备份 final-integration/entry-v25/canonical-entry-before。仅stage-02/project改3文件，FLOW-CHANGES.json。

修复1：browser_login_window.py 去掉普通点击/按键作为验证码完成的资格；添加真实“请通过验证/为保护账号安全/扫码验证身份”文本检测，主页已登录不能略过二维码挑战。platform_runtime.py 仅刷新helper SHA pin。修复2：workbench_backend.py _delivery_identity 显式拒绝fresh profile can_reply=false，避免只读身份核对保留旧用户权限导致后续批量发送不停。旧15项delivery测试中的撤权测试先复现失败，修复后通过。

证据都在本目录flow-audit：FLOW-TESTS.json=PASS，32Python行为项（8draft/review、15delivery、2规则客户端边界、7验证状态）+Node二维码DOM；RULE-ROUNDTRIP.json=PASS 3Node原候选服务导入测试（内存存储），无线上规则写入。旧外部身份fixtures已适配新中央门店只读契约，源码使用当前stage，不是旧P源码。127.0.0.1 HTTP需显式升级沙箱执行，已正常通过。FINAL-DELIVERY.json是最新技术回执。

真实Computer Use使用原生sky：82客户列表；导出文件从真实保存对话框生成，原保存到Documents/方隅客户清单 (12).xlsx，已复制至P/outputs/验证续接实测/客户清单82位.xlsx，20,097bytes/82客户/15中文栏目/技术字段0。导出校验曾漏读sharedStrings，已在audit_local_evidence.py真正解码并更新报告。单条首位绿油油草稿，普通询问户型入住时间，不承诺价格，已保存审核并到最终授权弹窗；已取消，无真实发送；v25正常重开后正文仍在且按钮“准备发送”。real UI account页蕾姆显示已连接。

两套公司SOP实际均为空，真实双选批量按钮正确提示“公司尚未配置这套SOP”，未擅自填公司话术；隔离队列发送测试已通过但不冒称真实整批平台发出。客户Excel导入当前没有入口/实现，不是CLI原生；规则文件导入只有既有管理员技术工具及服务能力，隔离回路通过，不声称线上UI导入通过。

CLI审计：当前xiaohongshu-cli 0.6.4=PyPI最新；6源码与GitHub main 4d63f3c0c85ccd9054fa8e96d7f761aaf2507449相同；CLI-VERSION-AUDIT.json。平台活动记录1074条，340次HTTP200、19次461（整个历史，不是单任务统计）。最后一次status200后sub-comments200，然后约4秒后另一次sub-comments461。没有证据是CLI旧版本；服务器身份核验真实存在，具体账号/IP/会话风控根因未知。当前累计18评论/10新增客户/4高意向，总客户82。持续速度未证明。当前无新采集、无真实回复。不要重开旧17小时任务，不注销账号、不改CLI或其他客户。

用户可见最新报告P/outputs/验证续接实测/实测结果.md；原客户清单.xlsx是72位旧快照。源目录仍S，P根入口使用候选v25。最后真实UI在账号页，主窗id10034358；node_repl sky/state/targetWindow/auditFs可继续。普通登录验证窗不必重开，用户明确现在不能扫码。若发现另有验证窗口保持可正常关闭，不能解验证码。
'''
(A/'CONTINUE.md').write_text(continuation,encoding='utf-8')
(P/'work/当前续行摘要.md').write_text(continuation,encoding='utf-8')
print(json.dumps({'status':receipt['status'],'release':staged['release_id'],'tests':32,'customer_export_rows':82,'real_messages_sent':0,'matched_collection_runs':len(current)}))
