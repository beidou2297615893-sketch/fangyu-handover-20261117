'use strict';
// Only reload an existing uniquely connected Douyin page. Never solve a challenge.
const fs=require('node:fs');
const {BridgeClient}=require('../runtime/douyin-bridge/lib/client/bridge-client');
(async()=>{
 const b=new BridgeClient({...JSON.parse(fs.readFileSync(process.argv[2],'utf8')).bridge,reuseConnections:false});
 const denied=await b.call({site:'douyin.com',connId:'nonexistent-collection-confirmation-proof',expression:'1',awaitPromise:true,timeout:3000});
 if(denied.ok!==false||!/指定(?:群工具|浏览器)连接已离线/.test(denied.error||''))throw Error('strict_required');
 const conns=((await b.status()).connections?.['douyin.com']||[]).filter(c=>c.alive);
 if(conns.length!==1)throw Error('unique_page_required');
 const expression=`(()=>{if(location.hostname!=='www.douyin.com')return {refreshed:false};const challenge_visible=Array.from(document.querySelectorAll('iframe')).some(f=>{const r=f.getBoundingClientRect(),s=getComputedStyle(f);return /verifycenter|captcha|rmc.bytedance.com/.test(f.src)&&r.width>0&&r.height>0&&s.display!=='none'&&s.visibility!=='hidden'&&s.opacity!=='0';});if(challenge_visible)return {challenge_visible:true,refreshed:false};setTimeout(()=>location.reload(),500);return {challenge_visible:false,refreshed:true};})()`;
 const r=await b.call({site:'douyin.com',connId:conns[0].id,expression,awaitPromise:true,timeout:5000});
 console.log(JSON.stringify(r.ok===true&&r.connection===conns[0].id?r.value:{refreshed:false}));
})().catch(()=>{console.log('{"refreshed":false}');process.exitCode=1;});
