from pathlib import Path
import shutil,json
T=Path('C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/douyin-login-sync-20261020');S=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project')
files=['work/ui-approved-implementation/ui-preview/'+n for n in ['app.mjs','account-connection-state.mjs','pages/accounts.mjs']]
for n in files:
 p=T/'before'/n;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();shutil.copyfile(S/n,p)
(T/'ADDED.json').write_text('[]',encoding='utf-8')
(T/'PLAN.md').write_text('增量修复v39：仅改app登录弹窗自动确认与账号页状态/昵称文案。抖音无jobId但拥有本次账号窗口时自动调用原account_check，绑定确切accountId，不自动重开浏览器，不修改身份/组件/许可/会话守卫。5至10秒间隔、有界次数/时间；失败/关闭/切换停止，不反复扫码。沿用已确认render/bind/原showAccountJob及隔离后台接口测试边界。未取得平台身份成功回执不能显示已连接。',encoding='utf-8')
