from pathlib import Path
import hashlib,json
S=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project');T=Path(__file__).resolve().parent
rows=json.loads((T/'SOURCE-CHANGES.json').read_text('utf-8'))
def edit(path,old,new):
    p=S/path;s=p.read_text('utf-8');assert s.count(old)==1;s=s.replace(old,new)
    if p.suffix=='.py':compile(s,str(p),'exec')
    p.write_text(s,encoding='utf-8');next(r for r in rows if r['path']==path)['after']=hashlib.sha256(p.read_bytes()).hexdigest()
edit('work/ui-native-r57/customer_workbench.py',"""            'sourceNotice':'帖子日期未提供，时间范围待核实' if any(
                (comment.get('lead') or {}).get('post_date_status')=='unverified' for comment in comments) else '',""","""            'sourceNotice':'帖子日期未提供，时间范围待核实' if (
                (representative or (comments[0] if comments else {})).get('lead') or {}).get('post_date_status')=='unverified' else '',""")
edit('work/ui-native-r57/reply_workbench.py',"                    'publishedAt':str(original.get('published_at') or ''),","""                    'publishedAt':str(original.get('published_at') or ''),
                    'sourceNotice':'帖子日期未提供，时间范围待核实' if lead.get('post_date_status')=='unverified' else '',""")
edit('work/ui-approved-implementation/ui-preview/pages/reply-connected.mjs',"${person.sourceNotice?`<small class=\"rp-loading-note\">${esc(person.sourceNotice)}</small>`:''}","${row.sourceNotice?`<small class=\"rp-loading-note\">${esc(row.sourceNotice)}</small>`:''}")
(T/'SOURCE-CHANGES.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
print('Date notice now matches each exact post/comment source')
