from pathlib import Path
import hashlib,json
T=Path(__file__).resolve().parent
F=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration');S=F/'stage-02/project'
changes=json.loads((T/'SOURCE-CHANGES.json').read_text('utf-8-sig'))
def edit(relative,fn):
    p=S/relative;before=p.read_bytes();backup=T/'before'/relative;backup.parent.mkdir(parents=True,exist_ok=True)
    if not backup.exists():backup.write_bytes(before)
    body=fn(before.decode('utf-8').replace('\r\n','\n'));p.write_bytes(body.encode('utf-8'))
    changes.append({'path':relative,'before':hashlib.sha256(before).hexdigest(),'after':hashlib.sha256(p.read_bytes()).hexdigest()})
def rep(b,old,new):assert b.count(old)==1,(old,b.count(old));return b.replace(old,new)
def notice(b):
    b=rep(b,'请在这个账号的平台网页按提示完成验证，再回获客页点“继续原任务”；没有验证入口时联系管理员。','点“去验证”打开此账号的小红书网页。完成验证后保持网页打开，再点“验证完成，继续原任务”。')
    begin=b.index('export function updatePlatformNotice(');end=b.index('export function createCollectionMonitor(',begin)
    return b[:begin]+'''const noticeKey=(s,n)=>JSON.stringify([identity(s),n.id,n.taskId,n.accountId]);
export function createVerificationActions({state,open,resume,changed,blocked=()=>false,notify=()=>{}}){
  let pending=false;
  return async function act(kind,n){
    if(!['open','resume'].includes(kind)||pending||state.busy||blocked())return;
    const key=noticeKey(state,n),current=()=>platformNotices(state).some(v=>noticeKey(state,v)===key);
    if(!current()||n.id!=='xiaohongshu'||!n.accountId)return;
    pending=true;state.verificationAction={key,pending:true,kind,message:kind==='open'?'正在打开原账号网页…':'正在核对网页验证结果…'};changed();
    try{
      const response=await (kind==='open'?open:resume)(n.taskId);
      if(!current())return;
      const job=response?.job,p=response?.platform;
      if(job?.taskId!==n.taskId||job?.accountId!==n.accountId||p?.actor?.username!==state.user||p?.actor?.storeId!==state.storeId)
        throw new Error('操作回执与原任务不一致，请刷新状态核对。');
      if(p.acquisition?.taskId===n.taskId&&(!p.acquisition.taskScope?.platform||p.acquisition.taskScope.platform===n.id)){
        if(n.id===(state.activePlatform||'xiaohongshu'))state.platform=p;
        else if(state.platformWorkspaces?.[n.id])state.platformWorkspaces[n.id].platform=p;
      }
      const message=kind==='open'?'原账号窗口正在打开；完成验证后保持窗口打开，再点下面的继续按钮。':'续行请求已提交，请查看获客进度。';
      state.verificationAction={key,pending:false,kind,message};notify(message);
    }catch(error){if(current())state.verificationAction={key,pending:false,kind,message:error.message||'操作暂未完成，请查看平台提示。'};}
    finally{pending=false;if(state.verificationAction?.key===key)state.verificationAction.pending=false;changed();}
  };
}
export function updatePlatformNotice(s,host,onAccount,onVerify){
  if(!host)return;
  const notices=platformNotices(s),key=JSON.stringify([identity(s),notices,s.verificationAction,s.busy]);
  if(host.dataset.noticeKey===key)return;
  host.dataset.noticeKey=key;host.hidden=!notices.length;
  host.innerHTML=notices.map((n,index)=>{
    const action=s.verificationAction?.key===noticeKey(s,n)?s.verificationAction:null;
    const canVerify=onVerify&&n.id==='xiaohongshu'&&n.accountId&&['verification_required','platform_rejected','authentication_required'].includes(n.category);
    const disabled=action?.pending||s.busy?'disabled':'';
    return `<section class="platform-alert" role="alert"><div><strong>${esc(n.title)}</strong><p>${esc(n.body)} 已读取的数据和断点已保留。</p>${action?.message?`<p class="platform-alert-feedback" role="status">${esc(action.message)}</p>`:''}</div><div class="platform-alert-actions">${canVerify?`<button type="button" data-verify-action="open" data-notice-index="${index}" ${disabled}>去验证</button><button type="button" data-verify-action="resume" data-notice-index="${index}" ${disabled}>验证完成，继续原任务</button>`:`<button type="button" data-platform-notice="${n.id}">查看账号</button>`}</div></section>`;
  }).join('');
  host.querySelectorAll('[data-platform-notice]').forEach(button=>button.addEventListener('click',()=>onAccount(button.dataset.platformNotice)));
  host.querySelectorAll('[data-verify-action]').forEach(button=>button.addEventListener('click',()=>onVerify(button.dataset.verifyAction,notices[Number(button.dataset.noticeIndex)])));
}
'''+b[end:]
edit('work/ui-approved-implementation/ui-preview/platform-notice.mjs',notice)
def app(b):
    b=rep(b,'import {updatePlatformNotice,createCollectionMonitor}', 'import {updatePlatformNotice,createCollectionMonitor,createVerificationActions}')
    b=rep(b,"});}\nconst collectionMonitor=", "},verificationAction);}\nconst verificationAction=createVerificationActions({state,open:id=>backend.openAcquisitionVerification(id),resume:id=>backend.resumeVerifiedAcquisition(id),changed:showPlatformNotice,blocked:()=>backend.unconfirmed||Boolean(state.pendingAction?.unconfirmed),notify:toast});\nconst collectionMonitor=")
    return b
edit('work/ui-approved-implementation/ui-preview/app.mjs',app)
edit('work/ui-approved-implementation/ui-preview/backend.mjs',lambda b:rep(b,"openAccountVerification:accountId=>request('account_verification_open',{accountId})","openAccountVerification:accountId=>request('account_verification_open',{accountId}),openAcquisitionVerification:taskId=>request('acquisition_verification_open',{taskId}),resumeVerifiedAcquisition:taskId=>request('acquisition_verification_resume',{taskId})"))
edit('work/ui-approved-implementation/ui-preview/canvas-fit.css',lambda b:b+'\n.platform-alert-actions{display:flex;flex-wrap:wrap;gap:8px;align-items:center}.platform-alert{flex-wrap:wrap}.platform-alert-actions button{font-size:13px;white-space:normal}.platform-alert-feedback{font-weight:600}.platform-alert-actions button:disabled{opacity:.6;cursor:wait}\n')
(T/'SOURCE-CHANGES.json').write_bytes((json.dumps(changes,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
print(json.dumps({'status':'UI_PATCHED','total_files':len(changes)}))
