"""Finish one ledgered attempt. Reads only the fixed account's original thread."""
from pathlib import Path
import subprocess
import hashlib
from unknown_resolution import (LIVE_STOPS, SKIP_LIMIT, SKIP_PAUSE, build_verify_command,
                                commit_resolution, current_stop, diagnosis_from_cli, resolve_on_start)


def raise_if_current_stop(result):
    reason = current_stop(result)
    if reason and reason != 'page_unresponsive':
        raise RuntimeError(LIVE_STOPS[reason])


def background_transport(result):
    return current_stop(result) == 'page_unresponsive'


def normalize_background_result(status, result):
    if status == 'not_sent' and background_transport(result):
        result = dict(result, status='unknown', original_cli_status='not_sent',
                      submission_attempted=False, automatic_retry=False)
        return 'unknown', result
    return status, result


def _target_key(cid):
    return hashlib.sha256(('douyin\0'+str(cid)).encode('utf-8')).hexdigest()


def background_target_skipped(folder, cid, *, load):
    path=Path(folder)/'background-skipped-targets.json'
    return path.exists() and _target_key(cid) in load(path)


def mark_background_target(folder, item, *, load, save, now):
    path=Path(folder)/'background-skipped-targets.json'
    body=load(path) if path.exists() else {}
    body[_target_key(item['cid'])]={'at':now(),'outcome':'unknown_target_not_submitted',
                                  'submission_attempted':False,'automatic_retry':False}
    save(path,body)

def skipped_count(previous):
    count = previous + 1
    if count >= SKIP_LIMIT:
        raise RuntimeError(SKIP_PAUSE)
    return count

def finish_attempt(folder, attempt, result, *, run_json, node, adapter, record, load, save, now):
    """Return True only if the original unknown can now be recorded as sent."""
    stop = current_stop(result)
    if stop == 'page_unresponsive':
        from publish_recovery import isolate_unknown_in_run
        isolate_unknown_in_run(Path(folder),str(attempt['comment_id']),result)
        return False
    if stop:
        raise RuntimeError(LIVE_STOPS[stop])
    if result.get('status') == 'not_sent':
        if 'unresolved platform rejection' in str(result.get('error','')).lower():
            raise RuntimeError('任务存在尚未处理的平台限制，请检查已登录页面后再点启动／继续。')
        return False

    cid = str(attempt['comment_id'])
    uid = attempt['account_uid']
    token = attempt['attempt_id']
    auth_path = Path(folder) / 'captcha-recovery-authorization.json'
    state = {'prefix':token,'runner_account':uid,'identity_uid':uid,
             'auth':load(auth_path) if auth_path.exists() else {},
             'submitted':{cid:attempt.get('submitted_at')},'receipts':{cid:result},
             'attempts':{cid:attempt},'rows':[{'token':token,'status':'unknown','comment':cid}]}
    def read(item, original):
        cmd = build_verify_command(node, adapter, original['video_id'], cid)
        try:
            return diagnosis_from_cli(run_json(cmd))
        except (subprocess.TimeoutExpired,OSError,RuntimeError) as exc:
            stop = current_stop({'error':str(exc)})
            if stop or isinstance(exc,subprocess.TimeoutExpired):
                return {'_stop':stop or 'page_unresponsive','own_reply_state':'unchecked'}
            raise RuntimeError('只读核对程序未返回结果，请检查已登录页面后再点启动／继续。') from exc

    resolved = resolve_on_start(state, {'now':now,'read_reply':read})
    # This check belongs to the attempt already in progress; a second click never occurred.
    auth = resolved.get('auth')
    if auth:
        for event in auth.get('events',[])[len(state['auth'].get('events',[])):]:
            event['source']='in_run_read_only_check'
            event.pop('user_statement',None)
            event.pop('user_confirmed',None)
    commit_resolution(resolved, {'record':lambda task,evidence:record(task,'sent',evidence),
                                 'auth':lambda body:save(auth_path,body)})
    if not resolved['continue_queue']:
        raise RuntimeError(resolved['summary'])
    return bool(resolved['records'])
