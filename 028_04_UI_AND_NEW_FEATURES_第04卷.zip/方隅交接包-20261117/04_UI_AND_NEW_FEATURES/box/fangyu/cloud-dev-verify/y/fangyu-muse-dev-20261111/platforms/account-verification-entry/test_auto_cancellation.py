from test_session_handoff import *
class CancellationTests(HandoffTests):
 def test_cancel_during_status_cannot_commit_or_resume(self):
  runtime,user,worker=self.runtime();wait={'cancel':threading.Event()};runtime._verification_waits={self.task:wait}
  original=runtime.core.adapters.execute
  def status(*a,**k):
   answer=original(*a,**k);wait['cancel'].set();return answer
  runtime.core.adapters.execute=status
  with self.assertRaises(RuntimeErrorType):runtime.resume_verified_acquisition(user,{'taskId':self.task},automatic=wait)
  worker.join(1);self.assertEqual(self.calls['resume'],0)
  self.assertEqual(self.store.get('accounts',self.account['id']),self.account)
 def test_replaced_wait_cannot_continue(self):
  runtime,user,worker=self.runtime();wait={'cancel':threading.Event()};runtime._verification_waits={self.task:{'cancel':threading.Event()}}
  with self.assertRaises(RuntimeErrorType):runtime.resume_verified_acquisition(user,{'taskId':self.task},automatic=wait)
  self.assertEqual(self.calls['status'],0);self.assertEqual(self.calls['resume'],0)
if __name__=='__main__':
 suite=unittest.TestSuite(CancellationTests(n) for n in ['test_cancel_during_status_cannot_commit_or_resume','test_replaced_wait_cannot_continue'])
 result=unittest.TextTestRunner(verbosity=2).run(suite);raise SystemExit(not result.wasSuccessful())
