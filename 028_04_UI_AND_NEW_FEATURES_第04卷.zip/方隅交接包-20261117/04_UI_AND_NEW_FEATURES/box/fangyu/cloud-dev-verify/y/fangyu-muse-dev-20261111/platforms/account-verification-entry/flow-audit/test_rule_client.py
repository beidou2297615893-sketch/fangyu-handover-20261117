"""Synthetic only: public localhost actions, intercepted cloud, temporary SQLite."""
import sys, json, tempfile, time, unittest
from pathlib import Path
from copy import deepcopy
from unittest.mock import patch
ROOT=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project')
sys.dont_write_bytecode=True
sys.path[:0]=[str(ROOT/'work/ui-native-r57'),str(ROOT/'work/shared-backend-integration/vendor-src'),str(ROOT/'work/ui-runtime-r55/src')]
from workbench_backend import WorkbenchBackend, WorkbenchError, _digest
from core.engine import Core
from integrations import IntegrationError

class Cloud:
 def __init__(self):
  self.role='admin';self.disabled=False;self.grants=['store-a','store-b'];self.calls=[];self.fail=''
  self.stores=[{'id':k,'name':'合成门店'+k,'materialKey':k,'status':'candidate'} for k in self.grants]
  self.configs={}
  for store in self.stores:
   k=store['id'];ids=[f'{k}-{i}' for i in range(130)]
   words=[{'id':ident,'keyword':f'合成{k}租房{i}','group':'synthetic','priority':1,'enabled':False,'csvCandidateEligible':True,
    'bindings':[{'materialKey':k,'csvCandidateEligible':True,'holdReasons':[],'sourceRefs':['synthetic-evidence'],
    'noteIds':[],'sourceArtifactId':'synthetic-source','rawKeywordId':ident,'rawKeywordPointer':'/synthetic','presetIds':['precise']}]} for i,ident in enumerate(ids)]
   material={'key':k,'name':store['name'],'city':'合成市','status':'candidate','keywordIds':ids,'heldKeywordIds':[]}
   package={'schema_version':'fangyu-store-materials-catalog/1','version':'synthetic-v1','materials':[material],'keywords':words,
    'rulesSummary':{'version':'synthetic-rule','priceVerified':False},'intentRule':{'version':'synthetic-rule','enabled':False,'prompts':'PRIVATE PROMPT'}}
   package['digest']=_digest(package)
   self.configs[k]={'store_id':k,'material_key':k,'evaluator_version':'2026-10-16-intent-budget-income-draft-v2','package':package}
 def __call__(self,url,data,token=''):
  op=data['operation'];self.calls.append(deepcopy(data))
  if op==self.fail:raise OSError('synthetic lost response')
  user={'username':'synthetic-user','role':self.role,'disabled':self.disabled,'can_reply':False}
  response={'contract':'fangyu-workspace-v1','company_id':'fangyu-apartment-client','environment_id':'synthetic-env','user':user}
  if op=='login':response.update(token='synthetic-token',expires=time.time()+3600)
  if op in ('login','me','logout'):return response
  if op=='store_config_read':
   stores=[r for r in self.stores if self.role=='admin' or r['id'] in self.grants]
   response.update(schema='store-config-v1',read_only=True,catalog_revision='synthetic-r1',catalog_digest='a'*64,
    actor={'username':user['username'],'role':self.role},scope={'type':'company' if self.role=='admin' else 'store','store_ids':[r['id'] for r in stores]},stores=stores)
   if data.get('store_id'):
    config=deepcopy(self.configs[data['store_id']]);response.update(store_id=data['store_id'],config=config,config_digest=_digest(config))
   return response
  if op.startswith('rule_bundle_'):
   if self.role!='admin':raise AssertionError('operator reached cloud rule op')
   response.update(revision='synthetic-r1',digest='a'*64,bytes=2,chunkCount=1,summary={'stores':2},
    uploadId='synthetic-upload',requestId='synthetic-request',state='prepared',previewDigest='b'*64,warnings=[])
   return response
  raise AssertionError('unexpected outbound '+op)

class Platform:
 def __init__(self,project_root,data_dir,company):
  self.core=Core(data_dir,defer_startup_recovery=True);self.calls=[]
 def snapshot(self,user):return {'acquisition':{'status':'idle'},'accounts':[],'platforms':[]}
 def start_acquisition(self,user,data):self.calls.append(deepcopy(data));return {'taskId':'synthetic-task','status':'queued'}
 def close(self):self.core.adapters.close()

class ClientTest(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory(dir=Path(__file__).parent);self.cloud=Cloud()
  self.outbound=patch('integrations.request_json',side_effect=self.cloud);self.outbound.start()
  self.company={'id':'fangyu-apartment-client','edition':'customer','personalMode':False,'authMode':'managed','platforms':['xiaohongshu'],
   'managedWorkspace':{'environment_id':'synthetic-env','endpoint':'https://example.invalid/synthetic'}}
  self.backend=WorkbenchBackend(ROOT,self.temp.name,self.company,platform_factory=Platform)
 def tearDown(self):self.backend.close();self.outbound.stop();self.temp.cleanup()
 def login(self):
  value=self.backend.dispatch('login',{'username':'synthetic-user','password':'[REDACTED:assigned_secret]'})
  self.token=value['token'];return value
 def boot(self):return self.backend.dispatch('bootstrap',{},self.token)
 def choose(self,key):return self.backend.dispatch('select_store',{'storeId':key},self.token)
 def apply(self):
  boot=self.boot();return self.backend.dispatch('apply_preset',{'storeId':boot['selection']['storeId'],'searchPresetId':'precise','intentPresetId':'standard','expectedRevision':boot['selection']['revision']},self.token)
 def test_rule_actions_recheck_true_admin_and_never_forward_operator(self):
  self.login();result=self.backend.dispatch('rule_bundle_status',{},self.token)
  self.assertEqual(result['ruleBundle']['revision'],'synthetic-r1')
  self.cloud.role='operator'
  with self.assertRaises(WorkbenchError) as caught:self.backend.dispatch('rule_bundle_status',{},self.token)
  self.assertIn(caught.exception.status,(401,403))
  self.backend.dispatch('logout',{},self.token)
  self.login()
  with self.assertRaises(WorkbenchError) as caught:self.backend.dispatch('rule_bundle_status',{},self.token)
  self.assertEqual(caught.exception.status,403)
  self.assertEqual(sum(r['operation']=='rule_bundle_status' for r in self.cloud.calls),1)
 def test_auto_profile_keeps_130_words_no_start_on_apply_and_rotates_only_explicit_start(self):
  self.login();a=self.choose('store-a')
  self.assertEqual(len(a['materials']['currentSelection']['selectedKeywords']),130)
  saved=self.apply();self.assertEqual(len(saved['selection']['applied']['selectedKeywords']),130)
  self.assertEqual(self.backend.platform_runtime.calls,[])
  data={'storeId':'store-a','expectedRevision':saved['selection']['revision'],'platform':'xiaohongshu','accountId':'synthetic-account','region':'','time':'最近7天','requestId':'synthetic-run-0001'}
  result=self.backend.dispatch('acquisition_start',data,self.token)
  self.assertEqual(len(self.backend.platform_runtime.calls[0]['keywords']),100)
  self.assertEqual(result['job']['keywordBatch']['total'],130)
  self.backend.dispatch('acquisition_start',data,self.token)
  self.assertEqual(len(self.backend.platform_runtime.calls),1)
  self.choose('store-b');self.apply();self.choose('store-a')
  data.update(expectedRevision=self.boot()['selection']['revision'],requestId='synthetic-run-0002')
  self.backend.dispatch('acquisition_start',data,self.token)
  second=self.backend.platform_runtime.calls[1]['keywords'];self.assertEqual(len(second),30)
  self.assertEqual(len(set(second+self.backend.platform_runtime.calls[0]['keywords'])),130)
  self.assertFalse(next(r for r in self.boot()['catalog']['intent'] if r['id']=='rental-evidence')['assessmentEnabled'])
 def test_invalid_chunk_is_rejected_before_cloud_and_unknown_commit_is_explicit(self):
  self.login()
  with self.assertRaises(WorkbenchError):self.backend.dispatch('rule_bundle_import_chunk',{'uploadId':'synthetic-upload','index':0,'dataBase64':'!'},self.token)
  self.assertFalse(any(r['operation']=='rule_bundle_import_chunk' for r in self.cloud.calls))
  self.cloud.fail='rule_bundle_import_commit'
  with self.assertRaises(WorkbenchError) as caught:self.backend.dispatch('rule_bundle_import_commit',{'uploadId':'synthetic-upload','previewDigest':'b'*64},self.token)
  self.assertEqual(caught.exception.code,'RULE_BUNDLE_RESULT_UNCONFIRMED')
  self.backend.dispatch('rule_bundle_import_status',{'uploadId':'synthetic-upload'},self.token)
  self.assertEqual(sum(r['operation']=='rule_bundle_import_commit' for r in self.cloud.calls),1)

if __name__=='__main__':unittest.main(verbosity=2)
