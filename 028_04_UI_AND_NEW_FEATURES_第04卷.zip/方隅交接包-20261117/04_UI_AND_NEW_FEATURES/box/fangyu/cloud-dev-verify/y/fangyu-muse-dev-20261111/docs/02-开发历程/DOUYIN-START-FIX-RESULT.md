# 抖音「启动／继续」修复结果

日期：2026-11-10。对应窗口：抖音 CLI｜搜索跟进。

## 现场追补：15:19 连续跳过的回执核查

用户报告连续跳过后，只读核对到本轮 8 条 3002123 都集中于同一视频，平台返回没有具体说明。逐条与采集源记录核对，视频及作者均一致，未发现串错目标。7 条完整只读核对未找到原回复，1 条只读未完成而隔离；全部保持未知，不重发。

随后走到其他视频的原队列条目，已连续得到 15 条成功回执。15:19:42 批状态为 publishing，累计已确认 539（此前 524）。这证明当前启动与单条跳过后的续发路径实际工作，不代表已查明该视频返回 3002123 的具体原因。

本次没有停止当前进程、替换运行中的发送程序、重排/抽改当前队列或重发这 8 条。核查证据：`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\start-fix-20261110\followup-seven-skips\diagnosis.json`。

## 现场追补：15:12 已修旧失联连接挡住正常页面

用户反馈点击仍没有效果后，实际查到 15:09:21 控制器已经进入启动流程，但停在连接核验，不是按钮事件没到。

本地 Bridge 列出两个 alive 连接：旧连接的实际只读请求返回 no polling client；当前绑定页面的只读请求正常。上一轮新增页面检查遇到旧连接就退出，未检查后面的正常页面。这是上一轮离线测试漏掉的现场问题。

已修 account_probe.cjs：优先核当前绑定，逐页做真实只读检查；跳过确认不响应的旧路由，不以缓存 URL 判断当场验证码；实际验证/限流仍阻断，多个真实账号仍拒绝猜选，也不因原绑定失联而静默切到另一账号。使用独立本地 HTTP 连接，未重启 Bridge、未修改浏览器登录状态。

已补并通过 7 个账号连接回归场景，原 11 个页面验证场景、8 项员工入口测试也通过。**15:12:22 使用实际本地 Node 执行只读账号探针，耗时约 5.62 秒，exit=0，当前账号及连接与 active 绑定一致。** 没有调用 control.py、发送器或采集器，没有发送业务请求，没有代点按钮；完整发送仍需员工下一次真实点击验收。

证据：`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\start-fix-20261110\followup-stale-connection\live-read-only-check.json`。
新增回归：`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\douyin-local-control\test_account_probe.cjs`。

任务来源：已读取并执行同目录 DOUYIN-START-FIX.md。此前「只写历程」的限制已按新任务结束。

## 结论

**已把修复装入现有本地入口。没有由本次任务启动生产采集、生产发送、执行生产未知记录恢复，或代点任何按钮。**

- 发送：员工在原进度窗口点「启动／继续」，旧 3002123 不再凭历史错误码直接挡住整批；先只读核对，保持未知不重发，继续当前已批准队列。连续 12 条新跳过/拒绝才安全暂停，成功会重置连续计数；当场验证、限流、身份异常仍立即停。
- 采集：已修陈旧租约、旧继续锁和异常退出的断点处理，启动与继续共用单实例锁。主动暂停标记仍被尊重，发送期间不恢复采集。
- 当前生产任务目录内的发送程序与适配器没有被本次直接替换；共用控制器会在员工下次合法点击、持有原单实例锁时，完成已有任务程序的受控升级。
- 真实平台效果尚待员工点击后的现场验收。此次通过的是离线回归，不能说已经成功实发或恢复实采。

## 一、发送启动如何处理旧 3002123

直接原因已经复现：原 unknown_resolution.resolve_on_start 只要发现未保留的旧 3002123，就在任何只读核对前停线。员工点按钮后没有提交，自然看起来像启动失效。

现在按以下顺序处理：

1. 核对当前账号、停止状态、锁和已批准任务。
2. 对旧未知条目，只在原账号、原目标、原回复范围内读取，不重新提交。
3. 能确认本账号的原回复已存在：按只读证据记已发送。
4. 完整核对后没有找到原回复：原结果仍保持 unknown，登记保留并跳过该条，不改成失败、不重发。
5. 仅局部核对未完成：隔离这条未知记录，保留原证据，不让它无限挡住其余已审队列。
6. 当场页面无响应：明确提示刷新已登录页面，再点「启动／继续」，不猜测已经发送或未发送。

旧 3002123 与「当前真的仍在验证」已拆开。当前可见验证组件、安全验证页面、明确平台限流消息、账号异常和既有明确限制标记仍会阻断。可见检测包含已遇到的验证 iframe；没有模拟滑块、绕过验证或自动换账号。

单条提交超时会先做新的只读核对，不能仅凭单次提交 timeout 就说整线掉线。当前只读页面检查确实无响应时才提示刷新。

## 二、失败跳过及当前批次

- 单条普通拒绝或未知：落账/保留后跳过，继续下一条。
- 连续新发生的跳过/拒绝合并计数，到 12 条暂停；新的成功回执或只读确认已发送会重置计数。
- 预检读取跳过和提交后跳过使用同一连续门槛，避免只修提交分支、预检仍少量失败就停。
- 原账本里已经处理过的记录照原规则排除，不自动重发。
- 已批准且尚未结束的当前批复用原清单，不因点继续而重新生成、重排或按新同视频规则改这批。

旧自动守护还在后台。本次增加启动来源判断：新版面板带显式员工启动参数；已经打开的旧面板，按直接父进程的 Python 路径和本项目 panel.py 完整路径识别。无参数的后台守护调用不会因此补丁自行开始发送，来源不明也不会发送。

这不是关闭原进程；没有停止或重开原面板、守护。实际单条跳过由本轮批程序内部继续，不依赖后台不断重新点启动。

## 三、采集启动和崩溃恢复

### 主动暂停仍有效

以下文件仍在，未删除、未改写：

`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\auto-collect.stop`

启动和继续先检查它；存在时明确解释「按要求暂停，发送期间不恢复」，不连接平台、不清锁或重开采集。没有把主动暂停伪装成按钮坏了。

### 陈旧租约

新一轮和继续使用同一个操作系统文件锁，异常退出会释放，不依赖永久 PID 文件。

员工后续合法恢复时：

- 先查真实进程。活进程或无法证明归属的锁不清，保持单实例。
- 只有确认 owner 已退出的 runner 租约、旧 continue 锁才移入项目内 startup-recovery，原字节保留。
- 先核完整组，再归档；状态刚变化则停止本次检查，不猜测。
- 不清空账本、不重置游标，不删除历史 halt。

**现场原陈旧租约此次没有现在就移走。** 因为仍处于用户主动暂停，恢复逻辑要等后续合法点击时才执行。

### 已派发但没反馈

本次还查到现场 control.pending 是 dispatching，而原始记录没有 response。仅修租约后仍会卡在未知，因此一并修复：

- 只允许员工明确点击的入口，不让等待守护自动处理这种未落反馈的崩溃。
- 严格连接、原账号和当前页面核验成功后，原 control/raw 逐字节保留，未知保持未知。
- 建立独立新范围，排除原未知关键词/视频及已有请求目标，不重新请求原未知业务，不伪造平台反馈。
- 原有同账号有效 review 可受控继承并按新范围收窄；新出现的 halt 仍阻断。
- **新范围指针先原子保存，再允许第一新页网络派发**，避免第一验证页中途崩溃后丢失范围、下次重复请求。
- 第一页验证后，再检查主动暂停、目录 STOP 和新 halt，才允许后续后台执行。

明确处于 prepared、原文证据一致且从未派发的意图，与 dispatching 未知分开：员工点击后可调用已有的纯本地严格取消入口，再继续。不能把 dispatching 当未派发取消。

首次初始化失败、尚无请求痕迹时可重新检查；若 control 缺失但目录有请求痕迹，则保留现场并解释原因，不能猜一个新游标重读。

## 四、改动文件

项目根目录：

`C:\Users\rmsama\Documents\ChatGPT\自动获客系统`

发送侧共用运行文件（没有直接覆盖生产任务目录下正在使用的发送程序）：

1. `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\douyin-local-control\control.py`
2. `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\douyin-local-control\panel.py`
3. `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\douyin-local-control\startup_recovery.py`
4. `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\douyin-local-control\unknown_resolution.py`
5. `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\douyin-local-control\account_probe.cjs`
6. `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\douyin-local-control\target_reader.cjs`
7. `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\douyin-local-control\attempt_recovery.py`（新增）
8. `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\douyin-local-control\page_guard.cjs`（新增）

采集侧运行文件：

1. `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\collection_startup.py`（新增）
2. `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\continue_collection.py`
3. `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\new_round.py`
4. `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\collection_progress_window.py`
5. `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\collection_confirmed_scope.py`

新增离线测试：

- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\douyin-local-control\test_employee_resume.py`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\douyin-local-control\test_send_resume_runner.py`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\douyin-local-control\test_page_guard.cjs`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\fangyu-douyin-independent\test_collection_startup.py`

未改采集 runner.cjs、ledger.py、共享账本实现，未改现有自动守护程序。原共用源码备份与全部工作证据在：

`C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\start-fix-20261110`

其中 send-source-before、before-collection 是源码备份；send-stage、baseline-collection 是隔离验证目录，不是新的业务入口。

## 五、没有改当前队列，但观察到原链路另有活动

本次没有调用生产 start、resolve、发送器、清单生成器，也没有写入实际授权、未知记录或共享账本。安装共用发送源码时持有原控制器单实例锁，安装前后核对没有正在运行的 control.py 或批程序；先更换人工入口门槛，再安装依赖。

核对结果不能简单写成「整段所有 SHA 都一样」：

- 14:48:55 记录首轮指纹。
- 14:55:06 当前批准清单更新；14:55:12 共享账本、生产批状态和生产日志更新，观察到原程序 PID 39728 的活动，随后停在一条未知。
- 这些活动早于 14:57:12 新共用控制器安装。发起活动的人员或入口没有核实，不能猜测。
- 两次所见清单都是 798 项，但相同行数不证明内容完全相同；未回滚、覆盖或抽改这两份发生变化的文件。
- 实际任务的发送程序和适配器，安装前后 hash 一致；授权文件、continuation-state 与采集 auto-collect.stop 指纹一致。
- 本窗口采集 active、wait state、原租约及停止标记也保持本次保护快照一致。

生产文件变化和测试路径均已审查：新增测试使用临时清单、临时授权、替身账本和替身适配器；迁移测试操作临时程序副本。记录这些观察，不把未查明的活动冒称为本次修复启动，也不宣称已证明是谁触发。

## 六、验证证据及限制

已实际通过：

- 发送启动/未知处理/入口来源：8 项 Python 测试。
- 真实批循环的隔离执行：6 项 Python 测试，覆盖单条拒绝、只读确认、超时、预检与提交混合计数、成功重置、晚出现的验证/限流信号。
- 页面可见信号：11 个 Node 合成场景；原目标分页测试通过。
- 采集启动和 scope：25 项 Python 测试，含 17 项新增启动测试及 8 项原 scope 回归；包含暂停、死锁、活锁、未知目标排除、入口模拟、请求前指针保存、验证期间新增暂停和纯本地取消未派发意图。
- 采集 Node runner 原回归：22 项通过，runner 文件未改。
- 发送程序六种历史版本的临时副本迁移及二次迁移幂等检查通过；语法检查通过。

**没有把全部旧测试写成全绿：**

1. 发送侧全发现 35 项，补齐旧账号私有模块的测试搜索路径后，34 项通过，旧用例 `test_default_sender_goes_to_reservation_without_live_comment_scan` 仍失败。它的虚构候选缺少原评论文本，既有商业筛查正确跳过，测试却预期进入预留；修复前版本也复现。没有放宽生产商业筛查来迎合旧样本。
2. 采集旧库、旧 90 天回填及缓存测试，在修改前源码的独立副本仍复现 6 failure + 2 error。涉及幂等、旧时间/无时间样本计数等；没有借本次启动修复改动生产账本规则。方法名和日志见项目内 collection-fix-notes.md、baseline-existing-test-failures.log。

本次没有现场启动生产来测试按钮，所以不宣称用户当前账号已完成真实发送验收，也不承诺平台所有未来提示形态都被识别。「系统拦截打开进度窗口」没有现场复现，原打开窗口脚本未改，没有冒称修复操作系统策略。

## 七、员工接下来怎么用

- 发送：继续在原已打开窗口点「启动／继续」。旧窗口的直接父进程形态已只读核对匹配；无须助手代点或代启动。
- 页面没有响应：按窗口提示刷新原已登录的抖音页面，再点一次。
- 当前有真实验证、限流、身份或明确停止原因：仍按实际提示处理，不自动切号、不重发未知。
- 采集：目前仍因 auto-collect.stop 主动暂停；本次不会解除。发送结束并明确可以恢复后，再处理原暂停并由员工点继续。
- 已经打开、缓存了旧 Python 模块的采集进度窗口，需要员工正常关闭后从原入口重新打开才能加载新代码；本次没有代为重开。

## 八、权限与交付位置

**不需要再到官方 Codex 开一个窗口或额外批准写入：本窗口已实际写入并核验修复文件。** 真实按钮点击仍由员工完成，这是用户明确要求的执行边界，不是写入权限未获批准。

结果文件完整路径：

`C:\Users\rmsama\Documents\ChatGPT\codex-briefs-20261110\DOUYIN-START-FIX-RESULT.md`

所在文件夹：

`C:\Users\rmsama\Documents\ChatGPT\codex-briefs-20261110`

详细工作记录：

- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\start-fix-20261110\send-fix-notes.md`
- `C:\Users\rmsama\Documents\ChatGPT\自动获客系统\work\start-fix-20261110\collection-fix-notes.md`

本结果不含客户评论原文、登录凭据或可复制登录状态。
