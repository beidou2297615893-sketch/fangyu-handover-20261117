from pathlib import Path
import hashlib,json
T=Path(__file__).resolve().parent;P=Path('C:/积木软件工坊/项目/方隅公寓客户版');F=P/'work/parallel-integration-20261018/final-integration';S=F/'stage-02/project'
changes=[]
def edit(relative,fn):
 p=S/relative;raw=p.read_bytes();before=T/'expiry-before'/relative;before.parent.mkdir(parents=True,exist_ok=True)
 with before.open('xb') as stream:stream.write(raw)
 value=fn(raw.decode('utf-8').replace('\r\n','\n'))
 if p.suffix=='.py':compile(value,str(p),'exec')
 p.write_bytes(value.encode());changes.append({'path':relative,'before':hashlib.sha256(raw).hexdigest(),'after':hashlib.sha256(p.read_bytes()).hexdigest()})

def receipt(s):
 a=s.index('def captcha_receipt(');b=s.index('\n\ndef failed_page',a)
 old=s[a:b];cut=old.index("    return bool(type(error)")
 shared=old[:cut].replace('def captcha_receipt(value):','def _failed_error(value):').replace('return False','return None')
 shared+='    return error if type(error) is dict and set(error)=={\'code\',\'message\'} and type(error.get(\'message\')) is str and len(error[\'message\'])<=512 else None\n'
 shared+='''

def captcha_receipt(value):
    error=_failed_error(value)
    return bool(error and error.get('code')=='verification_required' and re.fullmatch(
        r'Captcha required: type=[1-9][0-9]{0,5}, uuid=[A-Za-z0-9_-]{8,160}',error['message']))


def verification_receipt(value):
    """Only completed native CAPTCHA or explicit expired-login failures."""
    error=_failed_error(value)
    return bool(captcha_receipt(value) or error and error.get('code')=='not_authenticated'
        and error['message']=='Session expired — please re-login with: xhs login')
'''
 s=s[:a]+shared+s[b:]
 s=s.replace('one explicit original CAPTCHA receipt','one explicit original CAPTCHA or expired-login receipt')
 return s.replace('if not captcha_receipt(value)', 'if not verification_receipt(value)')
edit('work/ui-runtime-r55/src/core/xhs_verified_resume.py',receipt)
edit('work/ui-runtime-r55/src/core/xhs_page_process.py',lambda s:s.replace('from .xhs_verified_resume import captcha_receipt','from .xhs_verified_resume import verification_receipt').replace('and captcha_receipt(previous)','and verification_receipt(previous)'))

def browser(s):
 old="""            if capture.is_file() and not capture.is_symlink():
                capture.unlink(missing_ok=True)
                self.finish(explicit=True)
"""
 new="""            if capture.is_file() and not capture.is_symlink():
                # A reopened owned profile may still be at about:blank. Keep
                # this single explicit signal until its XHS navigation is ready.
                try:ready=_is_xhs_origin(self.window.get_current_url())
                except Exception:ready=False
                if ready:
                    capture.unlink(missing_ok=True)
                    self.finish(explicit=True)
"""
 assert s.count(old)==1;return s.replace(old,new)
edit('work/shared-backend-integration/vendor-src/assistant/browser_login_window.py',browser)

def runtime(s):
 old="""            if not self._verification_windows(user,account):
                raise PlatformRuntimeError('VERIFICATION_WINDOW_REQUIRED','请先点“去验证”，完成网页验证后保持窗口打开，再继续原任务',409)
"""
 assert s.count(old)==1;s=s.replace(old,'')
 needle='            self._commit_verified_browser(user,task,account,context)\n';assert s.count(needle)==1
 s=s.replace(needle,"""            if not self._verification_windows(user,account):
                # Reopen the same owned WebView profile after a human closed it;
                # never create an account or treat website login as verified.
                self.open_acquisition_verification(user,data)
                deadline=time.monotonic()+12
                while time.monotonic()<deadline:
                    windows=self._verification_windows(user,account)
                    if len(windows)==1 and windows[0].get('window_open') is True and windows[0].get('identity_capture_capable') is True:break
                    self.service.stop_event.wait(.05)
                else:raise PlatformRuntimeError('VERIFICATION_WINDOW_OPENING','原账号网页正在打开，请保持网页打开后再次点继续；原任务已保留',409)
"""+needle)
 import re
 digest=hashlib.sha256((S/'work/shared-backend-integration/vendor-src/assistant/browser_login_window.py').read_bytes()).hexdigest().upper()
 s,count=re.subn(r"_BROWSER_LOGIN_HELPER_SHA = '[A-F0-9]{64}'","_BROWSER_LOGIN_HELPER_SHA = '"+digest+"'",s)
 assert count==1;return s
edit('work/shared-backend-integration/platform_runtime.py',runtime)

def notice(s):
 s=s.replace("authentication_required:[`${name}登录已失效`,'请到账号页重新连接这个账号，再继续原任务。']", "authentication_required:[`${name}登录已失效`,'点“去验证”完成此账号登录，再点“验证完成，继续原任务”；账号状态会在核对后同步。']")
 s=s.replace('${disabled}>去验证</button>','${disabled}>${action?.pending&&action.kind===\'open\'?\'正在打开…\':\'去验证\'}</button>')
 s=s.replace('${disabled}>验证完成，继续原任务</button>','${disabled}>${action?.pending&&action.kind===\'resume\'?\'正在核对并续行…\':\'验证完成，继续原任务\'}</button>')
 return s
edit('work/ui-approved-implementation/ui-preview/platform-notice.mjs',notice)
def css(s):
 old='.platform-notice-host{position:fixed;top:70px;right:24px;width:min(470px,calc(100vw - 48px));z-index:65;display:grid;gap:10px}'
 new='.platform-notice-host{position:fixed;top:50%;left:50%;right:auto;transform:translate(-50%,-50%);width:min(520px,calc(100vw - 48px));max-height:calc(100dvh - 48px);overflow-y:auto;z-index:65;display:grid;gap:10px}'
 assert s.count(old)==1;return s.replace(old,new)
edit('work/ui-approved-implementation/ui-preview/canvas-fit.css',css)
(T/'EXPIRY-CHANGES.json').write_bytes((json.dumps(changes,ensure_ascii=False,indent=2)+'\n').encode())
print('Changed 6 source files; login-window dimensions unchanged')
