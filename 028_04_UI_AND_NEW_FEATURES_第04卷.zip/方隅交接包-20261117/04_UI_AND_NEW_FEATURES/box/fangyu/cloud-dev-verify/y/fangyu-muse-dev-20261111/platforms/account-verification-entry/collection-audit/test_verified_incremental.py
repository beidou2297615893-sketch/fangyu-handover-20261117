"""New resume-grant behavior only; synthetic HOME, journal and in-memory IPC."""
from pathlib import Path
from copy import deepcopy
from types import SimpleNamespace
import ast,hashlib,json,os,sys,time,traceback,threading
sys.dont_write_bytecode=True
H=Path(__file__).resolve().parent
P=Path('C:/积木软件工坊/项目/方隅公寓客户版')
S=P/'work/parallel-integration-20261018/final-integration/stage-02/project'
SRC=S/'work/ui-runtime-r55/src'
def audit(event,args):
    if event in ('socket.connect','socket.bind','subprocess.Popen','os.system','os.startfile'):raise RuntimeError('Review prohibits network/process/UI')
    if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
        mode,flags=args[1] or '',args[2] or 0
        write=any(c in str(mode) for c in 'wax+') or isinstance(flags,int) and flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC)
        if write and not Path(os.fsdecode(args[0])).absolute().is_relative_to(H):raise RuntimeError('Review writes only evidence')
sys.addaudithook(audit);sys.path.insert(0,str(SRC))
from core.xhs_verified_resume import captcha_receipt,verified_pages
from core.xhs_page_process import PageWorker,PageWorkerError,fingerprint
from core.xhs_identity_recovery import digest as raw_digest,scan_activity
from assistant.xhs_cli_page_worker import digest,page_key
from assistant.browser_session_commit import account_revision
names=['core/xhs_verified_resume.py','core/xhs_page_process.py','core/adapters.py']
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
initial={r:sha(SRC/r) for r in names}
runtime_path=S/'work/shared-backend-integration/platform_runtime.py';initial['runtime']=sha(runtime_path)
task_id='2'*32;account_id='1'*32;generation='3'*32;scope='a'*64
args=['comments','https://www.xiaohongshu.com/explore/synthetic','--json'];key=page_key(args)
account={'id':account_id,'tenant_id':'synthetic-tenant','cloud_owner':'synthetic-owner','store_id':'synthetic-store','platform':'xiaohongshu','platform_uid':'synthetic-uid','status':'ready','auth_generation':generation,'identity_revalidation_generation':generation}
counter=0;cases=[]
def case(name,fn):
    try:fn();cases.append({'name':name,'status':'PASS'})
    except BaseException as error:cases.append({'name':name,'status':'FAIL','error_type':type(error).__name__,'trace':traceback.format_exc()})
def encode(row):return (json.dumps(row,separators=(',',':'))+'\n').encode()
def fixture():
    global counter
    counter+=1;base=H/'new-fixtures'/f'case-{counter:03d}';home=base/'accounts'/account['tenant_id']/account_id
    home.mkdir(parents=True,exist_ok=False);config=home/'.xiaohongshu-cli';config.mkdir()
    (config/'cookies.json').write_text('{"synthetic_fixture":true}',encoding='ascii')
    now=time.time();request='4'*16
    pending=b''.join(encode(row) for row in [
        {'at':now-20,'stage':'started','kind':'comments','request_id':'5'*16,'method':'GET'},
        {'at':now-19,'stage':'finished','kind':'comments','request_id':'5'*16,'method':'GET','status':461},
        {'at':now-18,'stage':'cli_finished','kind':'comments','status':'verification_required'}])
    status=b''.join(encode(row) for row in [
        {'at':now-5,'stage':'started','kind':'status','attempt_id':generation,'request_id':request,'method':'GET'},
        {'at':now-4,'stage':'finished','kind':'status','attempt_id':generation,'request_id':request,'method':'GET','status':200},
        {'at':now-3,'stage':'cli_finished','kind':'status','attempt_id':generation,'request_id':request,'status':'completed','exit_code':0}])
    event={'at':now-2,'stage':'identity_revalidated','kind':'status','attempt_id':generation,'scope_hash':'b'*64,
        'covers_through_revision':len(pending),'covered_prefix_sha256':raw_digest(pending),
        'receipt_start':len(pending),'receipt_end':len(pending+status),'request_id':request,
        'uid_hash':raw_digest(account['platform_uid'].encode()),'account_revision':'c'*64,
        'auth_generation_hash':raw_digest(b'old-generation'),'next_auth_generation_hash':raw_digest(generation.encode()),
        'identity_evidence_kind':'single_status_receipt','revalidation_generation':generation}
    raw=pending+status+encode(event);assert not scan_activity(raw)['pending']
    activity=home/'platform-activity.jsonl';activity.write_bytes(raw)
    payload={'ok':False,'schema_version':'1','error':{'code':'verification_required','message':'Captcha required: type=124, uuid=synthetic_fixture_only'}}
    result={'stdout':json.dumps(payload),'stderr':'','returncode':1}
    value={'version':1,'task':task_id,'scope':scope,'page':key,'args_digest':digest(args),'operation':'comments','state':'acknowledged','created_at':now-17,'received_at':now-16,'wire_allow_attempts':1,'result':result,'digest':digest(result)}
    folder=home/'.workbench-page-receipts'/task_id;folder.mkdir(parents=True);path=folder/(key+'.json');path.write_bytes(encode(value))
    return SimpleNamespace(base=base,home=home,path=path,value=value,activity=activity,raw=raw,event=event,prefix=pending+status,account=deepcopy(account),payload=payload)
def replace_payload(f,payload):
    f.value['result']['stdout']=payload if isinstance(payload,str) else json.dumps(payload)
    f.value['digest']=digest(f.value['result']);f.path.write_bytes(encode(f.value))
def grants(f):return verified_pages(f.home,task_id,scope,f.account)
def rejects_payload(transform):
    f=fixture();payload=transform(deepcopy(f.payload));replace_payload(f,payload)
    assert captcha_receipt(f.value) is False and not grants(f)
case('Exact native failed CAPTCHA envelope and valid same-UID activity produce one page grant',lambda:(_ for _ in ()).throw(AssertionError()) if len(grants(fixture()))!=1 else None)
for name,change in [
 ('ok true',lambda p:{**p,'ok':True}),('missing ok',lambda p:{k:v for k,v in p.items() if k!='ok'}),
 ('wrong schema numeric',lambda p:{**p,'schema_version':1}),('missing schema',lambda p:{k:v for k,v in p.items() if k!='schema_version'}),
 ('mixed success data',lambda p:{**p,'data':{'comments':[]}}),('generic461',lambda p:{**p,'error':{'code':'verification_required','message':'HTTP461'}}),
 ('empty uuid',lambda p:{**p,'error':{'code':'verification_required','message':'Captcha required: type=124, uuid='}}),
 ('other code',lambda p:{**p,'error':{**p['error'],'code':'api_error'}}),
 ('duplicate JSON ok',lambda p:json.dumps(p)[:-1]+',"ok":true,"ok":false}')]:
    case('Reject fake/non-native CAPTCHA: '+name,lambda change=change:rejects_payload(change))
def reject_account(field,value):
    f=fixture();f.account[field]=value;assert not grants(f)
for field,value in [('platform_uid','other-uid'),('auth_generation','other-gen'),('identity_revalidation_generation','9'*32),('status','disconnected')]:
    case('Grant rejects changed '+field,lambda field=field,value=value:reject_account(field,value))
def mixed_journal():
    f=fixture();f.activity.write_bytes(f.raw+encode({'at':time.time(),'stage':'started','kind':'comments','request_id':'6'*16,'method':'GET'}));assert not grants(f)
case('Grant rejects a later unfinished real-wire journal entry',mixed_journal)
def postdated_failure():
    f=fixture();f.value['received_at']=time.time();f.path.write_bytes(encode(f.value));assert not grants(f)
case('Old identity proof cannot permit a newer CAPTCHA failure',postdated_failure)
def stale_proof():
    f=fixture();f.event['at']=time.time()-601;f.activity.write_bytes(f.prefix+encode(f.event));assert not grants(f)
case('Identity proof older than ten minutes cannot issue grant',stale_proof)
def wrong_binding():
    f=fixture();assert not verified_pages(f.home,task_id,'d'*64,f.account)
case('Grant rejects receipt scope different from current task binding',wrong_binding)

def fake_worker(f,grant=None,mode='success',protocol='task-bound-read-v1'):
    spec={'argv':[sys.executable],'env':{'HOME':str(f.home)},'cwd':str(H)}
    w=PageWorker(spec,task_id,scope,lambda:None,protocol=protocol,recover_unsent=True,verified_retry=grant)
    stats={'starts':0,'wire_allows':0,'packets':[]};events=[]
    success={'stdout':json.dumps({'ok':True,'schema_version':'1','data':{'comments':[]}}),'stderr':'','returncode':0}
    def start(deadline):
        stats['starts']+=1;w._ready=True
        events.append({'type':'wire_ready','nonce':w.nonce,'page':key,'wire':'7'*32,'method':'GET'})
        if mode=='success':events.append({'type':'result','nonce':w.nonce,'page':key,**success,'digest':digest(success)})
        elif mode=='captcha':events.append({'type':'result','nonce':w.nonce,'page':key,**f.value['result'],'digest':digest(f.value['result'])})
    def send(packet):
        stats['packets'].append(packet['type'])
        if packet['type']=='wire_allow':
            current=json.loads(f.path.read_text('utf-8'));assert current['wire_allow_attempts']==1 and current.get('verified_retry')
            archive=f.path.parent/current['verified_retry']['archive'];assert archive.read_bytes()==encode(f.value)
            stats['wire_allows']+=1
    def nxt(deadline):
        if not events:raise TimeoutError('synthetic response unknown')
        return events.pop(0)
    w._start=start;w._send=send;w._next=nxt
    return w,stats
def successful_retry():
    f=fixture();grant=grants(f);original=f.path.read_bytes();w,stats=fake_worker(f,grant)
    assert w.request(args)[2]==0 and stats['starts']==1 and stats['wire_allows']==1
    saved=json.loads(f.path.read_text('utf-8'));assert saved['state']=='acknowledged' and saved['verified_retry']['previous_sha256']==hashlib.sha256(original).hexdigest()
    assert (f.path.parent/saved['verified_retry']['archive']).read_bytes()==original
    assert w.request(args)[2]==0 and stats['starts']==1
    w.close()
case('Successful verified retry archives original before wire, records parent, and repeated request returns new success',successful_retry)
def unknown_new_attempt():
    f=fixture();grant=grants(f);w,stats=fake_worker(f,grant,mode='timeout')
    try:w.request(args)
    except PageWorkerError as e:assert e.code=='CLI_PAGE_UNCONFIRMED'
    else:raise AssertionError('Expected unknown attempt')
    saved=json.loads(f.path.read_text('utf-8'));assert saved['state']=='unknown' and saved['wire_allow_attempts']==1 and saved['verified_retry']
    fresh,again=fake_worker(f,grant)
    try:fresh.request(args)
    except PageWorkerError as e:assert e.code=='CLI_PAGE_UNCONFIRMED'
    else:raise AssertionError('Old verification grant replayed unknown result')
    assert again['starts']==0;fresh.close()
case('New attempt wire-unknown remains durable and cannot reuse old grant after restart',unknown_new_attempt)
def repeated_challenge():
    f=fixture();grant=grants(f);w,stats=fake_worker(f,grant,mode='captcha');assert w.request(args)[2]==1
    assert stats['wire_allows']==1 and not grants(f)
    fresh,again=fake_worker(f,grant);assert fresh.request(args)[2]==1 and again['starts']==0;fresh.close()
case('Repeated challenge needs fresh identity proof; old grant cannot retry twice',repeated_challenge)
def denied_grant(change):
    f=fixture();grant=grants(f);change(grant[key]);w,stats=fake_worker(f,grant)
    assert w.request(args)[2]==1 and stats['starts']==0;w.close()
for name,change in [('expired',lambda g:g.update(expires_at=time.time()-1)),('wrong cookie',lambda g:g.update(credential_sha256='f'*64)),
 ('wrong task',lambda g:g.update(task='wrong-task')),('wrong args',lambda g:g.update(args_digest='f'*64)),('wrong raw receipt',lambda g:g.update(receipt_sha256='f'*64))]:
    case('PageWorker rejects grant '+name,lambda change=change:denied_grant(change))
def unsupported_protocol():
    f=fixture();w,stats=fake_worker(f,grants(f),protocol='other');assert w.request(args)[2]==1 and stats['starts']==0;w.close()
case('Other protocol cannot consume verified resume grant',unsupported_protocol)

def runtime_methods():
    tree=ast.parse(runtime_path.read_text('utf-8'))
    error=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='PlatformRuntimeError')
    wanted={'_begin_cli_pages','resume_verified_acquisition','resume_acquisition'}
    methods=[deepcopy(n) for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name in wanted]
    module=ast.Module(body=[deepcopy(error),ast.ClassDef(name='RuntimeMethods',bases=[],keywords=[],body=methods,decorator_list=[])],type_ignores=[]);ast.fix_missing_locations(module)
    space={'threading':threading,'hashlib':hashlib,'json':json};exec(compile(module,str(runtime_path)+'[exact selected methods]','exec'),space)
    return space['RuntimeMethods'],space['PlatformRuntimeError']
RuntimeMethods,RuntimeErrorType=runtime_methods()
def runtime_fake():
    f=fixture();r=RuntimeMethods();user={'tenant_id':account['tenant_id'],'username':account['cloud_owner']}
    current={'id':task_id,'platform':'xiaohongshu','account_id':account_id,'status':'ready'}
    r._principal=lambda u:u;r._task=lambda u,i:deepcopy(current);r._account=lambda u,i:deepcopy(f.account);r._collection_binding=lambda t:'synthetic-binding'
    executor=SimpleNamespace(_guard_platform_qa_command=lambda *a:None);r._executor=lambda u:executor
    r._collection_readiness=lambda u,a:('','');r.closed=False
    capture={};adapters=SimpleNamespace(begin_xhs_cli_pages=lambda *a,**k:capture.update(args=a,kwargs=k))
    r.core=SimpleNamespace(adapters=adapters,store=SimpleNamespace(directory=f.base),running=set(),sequences=set())
    r.server=SimpleNamespace(_platform_execution_guard=lambda p:None)
    control={'event':threading.Event(),'binding':'synthetic-binding'}
    return f,r,user,current,executor,control,capture
def runtime_generation_guard(field):
    f,r,user,current,executor,control,capture=runtime_fake()
    control['verified_retry']={key:{'account_revision':account_revision(f.account),'generation':generation}}
    r._begin_cli_pages(executor,user,task_id,control);guard=capture['args'][3];guard()
    f.account[field]='8'*32
    try:guard()
    except RuntimeErrorType as e:assert e.code in ('ACCOUNT_SCOPE_CHANGED','ACCOUNT_SESSION_CHANGED')
    else:raise AssertionError('Fresh verification generation changed but per-wire guard accepted')
for field in ('auth_generation','identity_revalidation_generation'):
    case('Runtime per-wire guard rejects changed '+field,lambda field=field:runtime_generation_guard(field))
def lost_response():
    f,r,user,current,executor,control,capture=runtime_fake();calls=[]
    r._verification_task=lambda u,d:(u,current,f.account);r._verified_task_pages=lambda *a:{key:{'fake':'existing'}}
    r._recover_xhs_identity=lambda *a:(_ for _ in ()).throw(AssertionError('Must not repeat successful identity call'))
    r.resume_acquisition=lambda u,d:calls.append(d) or {'result':{'taskId':task_id}}
    result=r.resume_verified_acquisition(user,{'taskId':task_id});assert calls==[{'taskId':task_id}] and result['result']['accountId']==account_id
case('Lost response path reuses confirmed local identity proof without repeating capture/status',lost_response)
def no_window():
    f,r,user,current,executor,control,capture=runtime_fake()
    r._verification_task=lambda u,d:(u,current,f.account);r._verified_task_pages=lambda *a:{};r._verification_windows=lambda *a:[]
    r._recover_xhs_identity=lambda *a:(_ for _ in ()).throw(AssertionError('No implicit browser or recovery allowed'))
    try:r.resume_verified_acquisition(user,{'taskId':task_id})
    except RuntimeErrorType as e:assert e.code=='VERIFICATION_WINDOW_REQUIRED'
    else:raise AssertionError('Missing original window was not rejected')
case('No verification proof/window does not launch browser, recover automatically or resume',no_window)

changes=json.loads((H.parent/'SOURCE-CHANGES.json').read_text('utf-8'));syntax=[]
for row in changes:
    target=S/row['path']
    if target.suffix=='.py':
        try:compile(target.read_bytes(),str(target),'exec');syntax.append({'path':row['path'],'status':'PASS','sha256':sha(target)})
        except SyntaxError as e:syntax.append({'path':row['path'],'status':'FAIL','line':e.lineno,'error':e.msg})
current={r:sha(SRC/r) for r in names};current['runtime']=sha(runtime_path)
result={'status':'PASS_VERIFIED_RESUME_INCREMENTAL' if all(c['status']=='PASS' for c in cases) and all(c['status']=='PASS' for c in syntax) and current==initial else 'FAIL',
 'checks':cases,'source_sha256':initial,'source_stable_during_test':current==initial,'syntax_checks':syntax,
 'fixture_transport':'PageWorker exact request/journal logic with fake in-memory _start/_send/_next; no CLI process',
 'runtime_scope':'Exact selected Runtime methods against fake accounts/store/executor; no server boot',
 'real_platform_requests':0,'real_model_requests':0,'CLI_processes_started':0,'UI_operations':0,'real_credential_files_read':0,'production_writes':0,'product_edits_by_reviewer':0}
(H/'INCREMENTAL-RESULT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2));raise SystemExit(result['status']=='FAIL')
