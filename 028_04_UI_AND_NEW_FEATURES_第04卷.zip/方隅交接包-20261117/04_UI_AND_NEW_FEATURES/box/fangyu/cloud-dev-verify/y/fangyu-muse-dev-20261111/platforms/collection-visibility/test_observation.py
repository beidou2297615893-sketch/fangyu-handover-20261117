from pathlib import Path
import importlib.util,os,sys,unittest,threading,time
sys.dont_write_bytecode=True
S=Path(os.environ.get('FANGYU_TEST_PROJECT','C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project'))
spec=importlib.util.spec_from_file_location('visibility_runtime',S/'work/shared-backend-integration/platform_runtime.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class Observation(unittest.TestCase):
 def test_snapshot_exposes_only_verified_progress_metadata(self):
  got=m.collection_observation({'updated_at':'2026-10-21T15:00:00','elapsed_seconds':7.2},{'pages':4,'updated_at':'2026-10-21T07:00:01+00:00','next_read_at':'2026-10-21T07:00:06+00:00'},True)
  self.assertEqual(got['confirmedPages'],4);self.assertEqual(got['elapsedSeconds'],7.2);self.assertEqual(got['progressAt'],'2026-10-21T07:00:01+00:00');self.assertNotIn('counts',got)
 def test_terminal_and_invalid_waits_do_not_claim_a_pending_read(self):
  self.assertNotIn('nextReadAt',m.collection_observation({}, {'pages':-1,'next_read_at':'secret-cookie'},False))
 def test_pause_interrupts_wait_without_starting_a_request(self):
  e=threading.Event();e.set();start=time.monotonic();self.assertFalse(m.wait_for_collection_slot(e,time.time()+5));self.assertLess(time.monotonic()-start,.1)
 def test_wait_expiry_can_proceed(self):self.assertTrue(m.wait_for_collection_slot(threading.Event(),time.time()-.1))
 def test_pause_also_interrupts_an_already_waiting_slot(self):
  e=threading.Event();timer=threading.Timer(.02,e.set);timer.start();start=time.monotonic()
  try:self.assertFalse(m.wait_for_collection_slot(e,time.time()+5));self.assertLess(time.monotonic()-start,.5)
  finally:timer.cancel();timer.join()
if __name__=='__main__':unittest.main(verbosity=2)
