'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const source=fs.readFileSync(path.join(__dirname,'account_probe.cjs'),'utf8');
const realGuard=require('./page_guard.cjs');
async function check(pages,behavior,args=[]){
 const calls=[],printed=[],proc={exitCode:0,argv:['node','account_probe.cjs',...args]};
 class BridgeClient {
  async status(){return {connections:{'douyin.com':pages}};}
  async call(options){
   calls.push(options.connId);
   const item=behavior[options.connId];
   if(item==='dead')return {ok:false,error:'Request timeout after 3000ms — no polling client connected'};
   if(options.expression.includes('/user/profile/self/'))return {ok:true,connection:options.connId,
       value:{status_code:0,account_uid:item.uid,nickname:'synthetic'}};
   return {ok:true,connection:options.connId,value:item.gate||'ready'};
  }
 }
 const fakeFs={existsSync:()=>true,readFileSync:p=>JSON.stringify(String(p).includes('active.json')?
    {connection_id:'current',account_uid:'same'}:{bridge:{host:'127.0.0.1',port:1}})};
 await vm.runInNewContext(source,{__dirname,process:proc,console:{log:s=>printed.push(JSON.parse(s))},
  require:name=>name==='fs'?fakeFs:name==='path'?path:name==='./page_guard.cjs'?realGuard:{BridgeClient}});
 return {result:printed.at(-1),code:proc.exitCode,calls};
}
const page=(id,url='https://www.douyin.com/')=>({id,alive:true,url,lastActivity:'2026-11-10T07:00:00Z'});
(async()=>{
 let r=await check([page('ghost'),page('current')],{ghost:'dead',current:{uid:'same'}});
 assert.equal(r.code,0,'one unresponsive stale connection must not hide the responding pinned page');
 assert.equal(r.result.account_uid,'same');
 assert.equal(r.result.connection_id,'current');
 r=await check([page('ghost','https://www.douyin.com/ucenter/security/old'),page('current')],{ghost:'dead',current:{uid:'same'}});
 assert.equal(r.code,0,'a stale URL is not a current visible captcha');
 r=await check([page('current')],{current:{uid:'same',gate:'captcha'}});
 assert.equal(r.result.error,'CURRENT_GATE:captcha');
 r=await check([page('current')],{current:{uid:'same',gate:'rate_limit'}});
 assert.equal(r.result.error,'CURRENT_GATE:rate_limit');
 r=await check([page('current')],{current:'dead'});
 assert.equal(r.result.error,'CURRENT_GATE:page_unresponsive');
 r=await check([page('current'),page('other')],{current:{uid:'same'},other:{uid:'different'}});
 assert.notEqual(r.code,0,'two genuinely responding accounts must remain ambiguous');
 r=await check([page('current'),page('other')],{current:'dead',other:{uid:'different'}});
 assert.equal(r.result.error,'CURRENT_GATE:identity','a dead binding must not silently switch accounts');
 r=await check([page('current')],{current:{uid:'different'}},['--discover-current-account']);
 assert.equal(r.code,0,'explicit employee start can discover a new account without applying the old UID');
 assert.equal(r.result.account_uid,'different');
 r=await check([page('current'),page('other')],{current:{uid:'same'},other:{uid:'different'}},['--discover-current-account']);
 assert.notEqual(r.code,0,'two live identities remain ambiguous even at explicit start');
 console.log('Account probe: 9 connection and live-gate scenarios passed.');
})().catch(error=>{console.error(error);process.exitCode=1});
