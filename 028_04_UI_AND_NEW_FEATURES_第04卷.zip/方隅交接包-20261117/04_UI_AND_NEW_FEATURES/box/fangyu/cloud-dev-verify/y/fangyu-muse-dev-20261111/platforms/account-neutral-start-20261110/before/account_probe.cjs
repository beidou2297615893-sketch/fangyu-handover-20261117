const fs=require('fs'),path=require('path');
const root=path.resolve(__dirname,'../..'), runtime=path.join(root,'work/runtime/douyin-bridge');
const read=p=>JSON.parse(fs.readFileSync(p,'utf8').replace(/^\uFEFF/,''));
const {BridgeClient}=require(path.join(runtime,'lib/client/bridge-client'));
const client=new BridgeClient({...read(path.join(root,'抖音自用采集台/data/bridge.json')).bridge,
 reuseConnections:false});
(async()=>{try{
 const status=await client.status();
 const bindingFile=path.join(__dirname,'active.json');
 const binding=fs.existsSync(bindingFile)?read(bindingFile):{};
 const pages=(status.connections?.['douyin.com']||[]).filter(c=>c.alive)
  .sort((a,b)=>Number(b.id===binding.connection_id)-Number(a.id===binding.connection_id));
 const found=[];
 let unresponsive=0;
 for(const page of pages){
  const {assertPageReady}=require('./page_guard.cjs');
  try{
   // A stale status entry is not proof that the page is still polling. Skip
   // only that dead route; keep live challenge/limit signals authoritative.
   await assertPageReady({call:options=>client.call({...options,timeout:3000})},page.id);
  }catch(error){
   if(error.message==='CURRENT_GATE:page_unresponsive'){unresponsive++;continue;}
   throw error;
  }
  const r=await client.call({site:'douyin.com',connId:page.id,timeout:10000,expression:`(async()=>{const r=await fetch('/aweme/v1/web/user/profile/self/?'+new URLSearchParams(window.__bridge._q()),{credentials:'include'});const d=await r.json();return {http_status:r.status,status_msg:d.status_msg,status_code:d.status_code,account_uid:d.user?.sec_uid,nickname:d.user?.nickname}})()`});
  const {assertIdentityReply}=require('./page_guard.cjs');
  try{assertIdentityReply(r,page.id,binding.account_uid);}
  catch(error){
   if(error.message==='CURRENT_GATE:page_unresponsive'){unresponsive++;continue;}
   throw error;
  }
  found.push({...r.value,connection_id:page.id});
 }
 if(!found.length)throw Error(unresponsive?'CURRENT_GATE:page_unresponsive':'未找到可用的已登录抖音连接');
 if(new Set(found.map(x=>x.account_uid)).size!==1)throw Error('检测到多个不同账号，请只保留本任务的抖音连接');
 if(binding.account_uid&&found[0].account_uid!==binding.account_uid)throw Error('CURRENT_GATE:identity');
 console.log(JSON.stringify(found[0]));
}catch(e){console.log(JSON.stringify({error:e.message}));process.exitCode=1;}})();
