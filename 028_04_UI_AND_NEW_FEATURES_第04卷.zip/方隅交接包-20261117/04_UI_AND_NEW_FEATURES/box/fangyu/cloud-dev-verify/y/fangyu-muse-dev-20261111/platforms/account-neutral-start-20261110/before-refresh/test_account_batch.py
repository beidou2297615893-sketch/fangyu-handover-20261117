"""Account-neutral batches: temporary directories only; no platform or ledger writes."""
import hashlib
import json
import tempfile
import unittest
from pathlib import Path

import account_batch

ACTUAL=next(p for p in Path(__file__).resolve().parents if p.name=='work')/'douyin-local-20261104-40aaf15b06'
def write(path,value):path.write_text(json.dumps(value,ensure_ascii=False),encoding='utf-8')
def hashes(path):return {str(p.relative_to(path)):hashlib.sha256(p.read_bytes()).hexdigest() for p in path.rglob('*') if p.is_file()}

class AccountBatch(unittest.TestCase):
    def fixture(self,root):
        work=root/'work';work.mkdir()
        control=work/'douyin-local-control';control.mkdir()
        source=work/ACTUAL.name;source.mkdir()
        actual=json.loads((ACTUAL/'approved-cli-queue.json').read_text(encoding='utf-8-sig'))
        uid=actual['account_uid']
        for name in account_batch.CODE_FILES:
            (source/name).write_bytes((ACTUAL/name).read_bytes())
        items=[{'cid':'123','uid':'456','video':'789','draft':'approved',
                'reply_sha256':hashlib.sha256(b'approved').hexdigest()}]
        payload=json.dumps(items,ensure_ascii=False,sort_keys=True,separators=(',',':'))
        manifest={'authorized':True,'account_uid':uid,'prepared_by':'douyin-classification-ready-v1',
                  'items':items,'items_sha256':hashlib.sha256(payload.encode()).hexdigest()}
        write(source/'approved-cli-queue.json',manifest)
        write(source/'continuation-state.json',{'status':'authorized','unknown':1})
        write(source/'captcha-recovery-authorization.json',{'isolated_unknown_comments':['123']})
        write(source/'batch-runner-status.json',{'status':'blocked','confirmed_sent':715})
        write(control/'active.json',{'task':str(source),'account_uid':uid,'nickname':'old'})
        write(control/'accounts.json',{uid:str(source)})
        return control,source,manifest

    def test_switched_account_keeps_exact_batch_and_old_evidence(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);control,source,manifest=self.fixture(root)
            (source/'123.json.submitted').write_text('unknown',encoding='utf-8')
            before=hashes(source)
            task=account_batch.prepare_batch_session(root,control,{'account_uid':'new-uid','nickname':'new'})
            queue=json.loads((task/'approved-cli-queue.json').read_text(encoding='utf-8'))
            self.assertNotEqual(task,source)
            self.assertEqual(queue['account_uid'],'new-uid')
            self.assertEqual(queue['items'],manifest['items'])
            self.assertEqual(queue['items_sha256'],manifest['items_sha256'])
            self.assertEqual(before,hashes(source))
            self.assertIn('new-uid',(task/'batch_reply_runner.py').read_text(encoding='utf-8'))
            self.assertIn(task.name,(task/'prepare_verified.py').read_text(encoding='utf-8'))
            self.assertNotIn(source.name,(task/'prepare_verified.py').read_text(encoding='utf-8'))
            excluded=json.loads((task/'unavailable-targets.json').read_text(encoding='utf-8'))
            self.assertIn('123',excluded['comments'])
            self.assertFalse((task/'123.json.submitted').exists())
            self.assertEqual(json.loads((task/'continuation-state.json').read_text(encoding='utf-8'))['unknown'],0)

    def test_repeat_click_reuses_scope_and_next_account_keeps_batch_origin(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);control,source,manifest=self.fixture(root)
            identity={'account_uid':'new-uid','nickname':'new'}
            task=account_batch.prepare_batch_session(root,control,identity)
            write(control/'active.json',dict(identity,task=str(task)))
            before=hashes(task)
            self.assertEqual(account_batch.prepare_batch_session(root,control,identity),task)
            # On every entry, the latest derived exclusions may be merged; the
            # approved queue, runtime code, receipts and auth stay unchanged.
            self.assertEqual({k:v for k,v in hashes(task).items() if k!='unavailable-targets.json'},
                             {k:v for k,v in before.items() if k!='unavailable-targets.json'})
            other=account_batch.prepare_batch_session(root,control,{'account_uid':'third-uid','nickname':'third'})
            context=json.loads((other/'batch-context.json').read_text(encoding='utf-8'))
            self.assertEqual(context['source_task'],str(source))
            self.assertEqual(json.loads((other/'approved-cli-queue.json').read_text())['items_sha256'],manifest['items_sha256'])

    def test_switch_back_reuses_original_without_rewriting_it(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);control,source,manifest=self.fixture(root)
            task=account_batch.prepare_batch_session(root,control,{'account_uid':'new-uid','nickname':'new'})
            write(control/'active.json',{'task':str(task),'account_uid':'new-uid','nickname':'new'})
            before=hashes(source)
            returned=account_batch.prepare_batch_session(root,control,{'account_uid':manifest['account_uid'],'nickname':'old'})
            self.assertEqual(returned,source)
            self.assertEqual({k:v for k,v in before.items() if k!='unavailable-targets.json'},
                             {k:v for k,v in hashes(source).items() if k!='unavailable-targets.json'})

    def test_other_account_task_must_not_replace_current_batch(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);control,source,manifest=self.fixture(root)
            unrelated=root/'work/douyin-local-unrelated';unrelated.mkdir()
            queue=dict(manifest,account_uid='new-uid',items=[],items_sha256=hashlib.sha256(b'[]').hexdigest())
            write(unrelated/'approved-cli-queue.json',queue)
            registry=json.loads((control/'accounts.json').read_text())
            registry['new-uid']=str(unrelated);write(control/'accounts.json',registry)
            returned=account_batch.prepare_batch_session(root,control,{'account_uid':'new-uid','nickname':'new'})
            self.assertNotEqual(returned,unrelated)
            self.assertEqual(json.loads((returned/'approved-cli-queue.json').read_text())['items'],manifest['items'])

    def test_unjournalled_attempt_elsewhere_and_background_skip_never_revive(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);control,source,_=self.fixture(root)
            other=root/'work/douyin-local-old';other.mkdir()
            write(other/'approved-cli-queue.json',{'items':[]})
            (other/'222.json').write_text('{}')
            write(source/'unavailable-targets.json',{'comments':{'333':{'reason':'old skip'}}})
            task=account_batch.prepare_batch_session(root,control,{'account_uid':'new-uid','nickname':'new'})
            excluded=json.loads((task/'unavailable-targets.json').read_text(encoding='utf-8'))['comments']
            self.assertIn('222',excluded);self.assertIn('333',excluded)

    def test_submitted_target_blocks_second_comment_by_same_customer_and_background_fingerprint(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);control,source,manifest=self.fixture(root)
            item=dict(manifest['items'][0],cid='124')
            manifest['items'].append(item)
            manifest['items'].append(dict(item,cid='125',uid='999'))
            manifest['items_sha256']=hashlib.sha256(json.dumps(manifest['items'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
            write(source/'approved-cli-queue.json',manifest)
            (source/'123.json.submitted').write_text('unknown')
            key=hashlib.sha256(b'douyin\x00125').hexdigest()
            write(source/'background-skipped-targets.json',{key:{'automatic_retry':False}})
            task=account_batch.prepare_batch_session(root,control,{'account_uid':'new-uid','nickname':"bad' {raise}\\n"})
            excluded=json.loads((task/'unavailable-targets.json').read_text(encoding='utf-8'))['comments']
            self.assertTrue({'123','124','125'}<=excluded.keys())
            self.assertNotIn("bad'",(task/'batch_reply_runner.py').read_text(encoding='utf-8'))

    def test_return_to_existing_scope_refreshes_orphan_attempts_from_legacy_batch(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);control,source,manifest=self.fixture(root)
            task=account_batch.prepare_batch_session(root,control,{'account_uid':'new-uid','nickname':'new'})
            # Legacy round2 account attempted another CID for this customer;
            # the process died before creating its shared-ledger reservation.
            old=root/'work/douyin-round2-task1';old.mkdir()
            write(old/'approved-cli-queue.json',{'items':[{'cid':'999','uid':'456'}]})
            (old/'999.json.submitted').write_text('uncertain')
            write(control/'active.json',{'task':str(task),'account_uid':'new-uid'})
            returned=account_batch.prepare_batch_session(root,control,{'account_uid':manifest['account_uid'],'nickname':'old'})
            self.assertEqual(returned,source)
            excluded=json.loads((source/'unavailable-targets.json').read_text(encoding='utf-8'))['comments']
            self.assertIn('123',excluded)
            write(control/'active.json',{'task':str(source),'account_uid':manifest['account_uid']})
            returned=account_batch.prepare_batch_session(root,control,{'account_uid':'new-uid','nickname':'new'})
            self.assertIn('123',json.loads((returned/'unavailable-targets.json').read_text(encoding='utf-8'))['comments'])

    def test_batch_stop_or_platform_hold_cannot_be_cleared_by_switching(self):
        for name,value in [('batch-stop.json',{'user_pause':True}),
                           ('continuation-state.json',{'status':'stopped_platform_rejection','unknown':1})]:
            with self.subTest(name=name),tempfile.TemporaryDirectory() as td:
                root=Path(td);control,source,_=self.fixture(root)
                write(source/name,value)
                before=hashes(source)
                with self.assertRaises(RuntimeError):
                    account_batch.prepare_batch_session(root,control,{'account_uid':'new-uid','nickname':'new'})
                self.assertEqual(before,hashes(source))

    def test_self_consistent_republished_queue_cannot_change_batch_on_same_account_resume(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);control,source,_=self.fixture(root)
            identity={'account_uid':'new-uid','nickname':'new'}
            task=account_batch.prepare_batch_session(root,control,identity)
            write(control/'active.json',dict(identity,task=str(task)))
            queue=json.loads((task/'approved-cli-queue.json').read_text(encoding='utf-8'))
            queue['items']=[];queue['items_sha256']=hashlib.sha256(b'[]').hexdigest()
            write(task/'approved-cli-queue.json',queue)
            with self.assertRaises(RuntimeError):account_batch.prepare_batch_session(root,control,identity)

    def test_real_runner_captcha_or_rate_stop_cannot_be_bypassed_by_switching(self):
        from unknown_resolution import LIVE_STOPS
        for reason in (LIVE_STOPS['captcha'],LIVE_STOPS['rate_limit']):
            with self.subTest(reason=reason),tempfile.TemporaryDirectory() as td:
                root=Path(td);control,source,manifest=self.fixture(root)
                write(source/'batch-runner-status.json',{'status':'blocked','reason':reason,'automatic_retry':False})
                with self.assertRaises(RuntimeError):
                    account_batch.prepare_batch_session(root,control,{'account_uid':'new-uid','nickname':'new'})
                # The same account can undergo the normal live verification flow.
                self.assertEqual(account_batch.prepare_batch_session(root,control,{'account_uid':manifest['account_uid']}),source)

    def test_account_with_old_unprepared_template_still_continues_current_batch(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);control,source,manifest=self.fixture(root)
            old=root/'work/douyin-local-legacy';old.mkdir()
            write(old/'approved-cli-queue.json',{'account_uid':'new-uid','authorized':True,'items':[]})
            registry=json.loads((control/'accounts.json').read_text(encoding='utf-8'))
            registry['new-uid']=str(old);write(control/'accounts.json',registry)
            task=account_batch.prepare_batch_session(root,control,{'account_uid':'new-uid','nickname':'new'})
            self.assertNotEqual(task,old)
            self.assertEqual(json.loads((task/'approved-cli-queue.json').read_text(encoding='utf-8'))['items'],manifest['items'])

    def test_bad_queue_hash_or_unauthorized_source_cannot_create_scope(self):
        for override in ({'items_sha256':'bad'},{'authorized':False}):
            with self.subTest(override=override),tempfile.TemporaryDirectory() as td:
                root=Path(td);control,source,manifest=self.fixture(root)
                write(source/'approved-cli-queue.json',dict(manifest,**override))
                with self.assertRaises(RuntimeError):
                    account_batch.prepare_batch_session(root,control,{'account_uid':'new-uid','nickname':'new'})
                self.assertEqual(len(list((root/'work').glob('douyin-local-*'))),2)  # includes control

if __name__=='__main__':unittest.main()
