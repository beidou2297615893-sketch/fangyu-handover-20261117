from pathlib import Path
import re,shutil
S=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project')
W=S/'work/ui-approved-implementation/ui-preview';T=Path(__file__).resolve().parent
def save(p,new):
    old=p.read_text('utf-8')
    if old==new:return
    b=T/'before'/p.relative_to(S);b.parent.mkdir(parents=True,exist_ok=True)
    if not b.exists():shutil.copy2(p,b)
    p.write_text(new,'utf-8')
p=W/'pages/acquisition-help.mjs';t=p.read_text('utf-8')
a=t.index('export function helpFooter()');b=t.index('\nexport function openAcquisitionHelp',a)
t=t[:a]+'''export function helpFooter(needsVerification=false){return `<div class="wb-help-links">${needsVerification?'<button type="button" data-acquire-verify>打开原账号验证网页</button>':''}<button type="button" data-acquisition-help>查看使用说明</button></div>`;}'''+t[b:]
t=t.replace('<h3>每天采集500', '<h3>多个账号回复同一客户</h3><p>本机同一工作区内，同平台同一客户只要已有账号回复成功，其他账号的批次自动跳过；两个账号同时提交时，只允许一个进入发送。正在发送、结果未知或中途退出的记录会保留拦截，核实前不换号重发。跳过会单独显示，不计入发送成功。软件外手动发送的内容无法自动识别。</p>\n<h3>每天采集500')
save(p,t)
p=W/'pages/acquire.mjs';t=p.read_text('utf-8')
old='${[\'verification_required\',\'authentication_required\'].includes(live.platformError?.category)?\'<button type="button" class="wb-inline-verify" data-acquire-verify>打开原账号验证网页</button>\':\'\'}${helpFooter()}'
assert old in t
save(p,t.replace(old,"${helpFooter(['verification_required','authentication_required'].includes(live.platformError?.category))}"))
p=W/'pages/reply-delivery.mjs';t=p.read_text('utf-8')
t=t.replace('const labels=',"const itemLabels={skipped:'已跳过',sent:'已发送',approved:'已审核，尚未发送',sending:'正在发送',unknown:'结果待核对',draft:'草稿'};\nconst labels=",1)
t=t.replace('${p.sent||0}/${p.items?.length||0} 条有成功记录','成功 ${p.sent||0} 条 · 跳过 ${p.skipped||0} 条 · 共 ${p.items?.length||0} 条')
t=t.replace('${esc(r.status)}','${esc(itemLabels[r.status]||r.status)}')
save(p,t)
# Increase explicit type sizes once, including inline page labels, with layout
# dimensions unchanged. Inherited sizes follow their parent rather than compound.
for p in list(W.rglob('*.css'))+list(W.rglob('*.mjs')):
    if 'node_modules' in p.parts:continue
    t=p.read_text('utf-8')
    new=re.sub(r'(font-size\s*:\s*)(\d+(?:\.\d+)?)px',lambda m:m[1]+format(float(m[2])+2,'g')+'px' if float(m[2])>0 else m[0],t)
    save(p,new)
p=W/'redesign.css';save(p,p.read_text('utf-8')+'''
/* Larger platform targets and unboxed left-aligned help links. */
.platform-switch{gap:24px}.platform-switch button{font-size:21px;min-width:122px;gap:12px}.platform-switch img{width:42px;height:42px}
.wb-help-links{display:flex;justify-content:flex-start;align-items:center;flex-wrap:wrap;gap:20px;margin:16px 0 0;padding:0}
.wb-help-links button{border:0;background:transparent;color:#087d8c;font:inherit;text-decoration:underline;text-underline-offset:4px;padding:6px 0;cursor:pointer}
.shell[data-platform=douyin] .wb-help-links button{color:#46dce7}
''')
