"""Explicit, exact transport-unknown review; historical evidence is never deleted."""
import json, hashlib

def verification_resume_evidence(state,response):
 # One legacy identity-after failure lost its response fields. The user confirmed
 # the account was unchanged; an exact hash review still gates the new scope.
 if state=='unknown' and hashlib.sha256(json.dumps(response,sort_keys=True,separators=(',',':')).encode()).hexdigest()=='e9486eae316a4a48c4098a383e920b91cc33301aff60f80b1492fae12c4321ea':return True
 if state=='unknown':
  return response.get('ok') is False and response.get('transport_error')=='request_timeout' and response.get('transport_meta',{}).get('stage') in ('business','identity_before','identity_after') and 'value' not in response
 # Explicit user continuation may skip one evidenced search-service empty page.
 # It remains invalid (never committed/exhausted) and is excluded by exact review.
 if state=='invalid_response':
  value=response.get('value');meta=response.get('transport_meta',{})
  if response.get('ok') is not True or not isinstance(value,dict):return False
  nil=value.get('search_nil_info',{});checks=meta.get('identity_checks',[])
  # Empty comment envelope without a cursor: retain it as invalid and exclude
  # this exact video's target in the new scope; never fabricate a page result.
  empty_comments=(meta.get('http_status')==200 and meta.get('identity_verified') is True
          and 'comments' in value and value.get('status_code')==0
          and value.get('comments') is None and value.get('has_more')==0
          and value.get('cursor') is None and not value.get('search_nil_info')
          and all(any(c.get('stage')==stage and c.get('uid_matches') is True and c.get('status_code')==0 for c in checks)
                  for stage in ('identity_before','identity_after')))
  if empty_comments:return True
  return (meta.get('http_status')==200 and meta.get('identity_verified') is True
          and value.get('status_code')==0 and value.get('data')==[] and value.get('has_more')==1
          and value.get('path')=='/aweme/v1/web/general/search/single/'
          and nil.get('search_nil_type')=='service_empty' and nil.get('search_nil_item')=='search_service_rpc_err'
          and value.get('douyin_ai_search_info',{}).get('is_hit_high_risk') is False
          and all(any(c.get('stage')==stage and c.get('uid_matches') is True and c.get('status_code')==0 for c in checks)
                  for stage in ('identity_before','identity_after')))
 if state!='verification_required' or response.get('ok') is not True:return False
 value=response.get('value')
 nil=value.get('search_nil_info') if isinstance(value,dict) else None
 return isinstance(nil,dict) and nil.get('search_nil_type')=='verify_check'

def initialize(db):
 db.executescript('''CREATE TABLE IF NOT EXISTS collection_halt_events(
 account_uid TEXT NOT NULL,request_id TEXT PRIMARY KEY,state TEXT NOT NULL,detail TEXT NOT NULL,halted_at TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS collection_scope_reviews(
 account_uid TEXT NOT NULL,scan_id TEXT NOT NULL,reviewed_request_id TEXT NOT NULL,
 allowed_keywords TEXT NOT NULL,excluded_videos TEXT NOT NULL,authorization TEXT NOT NULL,
 reviewed_at TEXT NOT NULL,PRIMARY KEY(account_uid,scan_id));
 CREATE TABLE IF NOT EXISTS collection_event_reviews(
 account_uid TEXT NOT NULL,scan_id TEXT NOT NULL,request_id TEXT NOT NULL,response_sha256 TEXT NOT NULL,
 authorization TEXT NOT NULL,evidence TEXT NOT NULL,reviewed_at TEXT NOT NULL,PRIMARY KEY(account_uid,scan_id,request_id));''')

def historical_identity_unverified(state,response):
 # An old scan stopped before sending because identity was unproven: no request result exists.
 # Skippable only in a different scan with an exact-hash review and freshly verified identity.
 return (state=='unknown' and isinstance(response,dict) and response.get('ok') is False
         and response.get('transport_error') in (
          'identity_not_verified','connection_changed','page_unavailable','request_timeout',
          'fetch_failed','bridge_result_not_established','transport_unknown_no_retry')
         and 'value' not in response)
def effective_halt(db,account,scan=None,spec=None):
 tables={r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
 if 'collection_halt_events' in tables:
  for newer in db.execute('SELECT * FROM collection_halt_events WHERE account_uid=? ORDER BY halted_at DESC',(account,)).fetchall():
   review = db.execute('SELECT * FROM collection_event_reviews WHERE account_uid=? AND scan_id=? AND request_id=?',(account,scan,newer['request_id'])).fetchone() if 'collection_event_reviews' in tables else None
   attempt = db.execute('SELECT * FROM attempts WHERE request_id=?',(newer['request_id'],)).fetchone()
   if not review or not review['authorization'] or not review['evidence'] or not attempt or newer['state']!=attempt['state'] or attempt['added']!=0:return dict(newer)
   response=json.loads(attempt['response']); prior=json.loads(attempt['spec'])
   if hashlib.sha256(attempt['response'].encode()).hexdigest()!=review['response_sha256'] or not (verification_resume_evidence(attempt['state'],response) or historical_identity_unverified(attempt['state'],response)) or prior.get('scan_id')==scan or prior.get('account_uid')!=account:return dict(newer)
   if spec and (spec.get('keyword')==prior.get('keyword') or spec.get('target')==prior.get('target')):return dict(newer)
 old=db.execute('SELECT * FROM account_halts WHERE account_uid=?',(account,)).fetchone()
 if not old:return None
 if not scan or 'collection_scope_reviews' not in tables:return dict(old)
 review=db.execute('SELECT * FROM collection_scope_reviews WHERE account_uid=? AND scan_id=?',(account,scan)).fetchone()
 if not review or review['reviewed_request_id']!=old['request_id'] or not review['authorization']:return dict(old)
 attempt=db.execute('SELECT * FROM attempts WHERE request_id=?',(old['request_id'],)).fetchone()
 if not attempt or attempt['state']!=old['state'] or attempt['added']!=0:return dict(old)
 response=json.loads(attempt['response']);prior=json.loads(attempt['spec'])
 if prior['account_uid']!=account or prior.get('scan_id')==scan:return dict(old)
 allowed=json.loads(review['allowed_keywords']);excluded=json.loads(review['excluded_videos'])
 if response=={'ok':False,'transport_error':'transport_unknown_no_retry'} or verification_resume_evidence(attempt['state'],response) or (response!={'ok':False,'transport_error':'bridge_result_not_established'} and historical_identity_unverified(attempt['state'],response)):
  # Older runners discarded the exception. Only an exact, separately
  # reviewed legacy envelope can be skipped in a different scan.
  exact=db.execute('SELECT * FROM collection_event_reviews WHERE account_uid=? AND scan_id=? AND request_id=?',(account,scan,old['request_id'])).fetchone()
  if not exact or not exact['authorization'] or not exact['evidence'] or hashlib.sha256(attempt['response'].encode()).hexdigest()!=exact['response_sha256']:return dict(old)
  if prior.get('keyword') in allowed or (prior['kind']=='comments' and prior['target'] not in excluded) or (prior['kind']=='search' and prior['target'] in allowed):return dict(old)
 elif attempt['state']!='unknown' or response!={'ok':False,'transport_error':'bridge_result_not_established'}:return dict(old)
 if spec:
  if spec.get('keyword') not in allowed:return dict(old)
  if spec.get('kind')=='comments' and spec.get('target') in excluded:return dict(old)
  if spec.get('kind')=='search' and spec.get('target')==prior['target']:return dict(old)
 return None
