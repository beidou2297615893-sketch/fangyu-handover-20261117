"""Skip or isolate one failed target without changing its unknown receipt."""
import datetime
import json
from pathlib import Path

CAPTCHA_STATUS = 3002123

# Exact mid-run CLI errors from send_cli_once.cjs lines 67/69/71 before post().
# attempted stays false, so the catch emits status=not_sent (never unknown).
_CLI_IDENTITY_ERRORS = (
    'batch account binding missing',
    'task account mismatch',
    'round2task5 identity changed',
)

# Empirically seen page/Bridge disconnect text. Not a bare "Request timeout":
# a comment-level timeout without these markers still isolates and continues.
_BRIDGE_DISCONNECT_MARKERS = (
    'no polling client',
    'no active douyin page connection',
    'fixed connection unavailable',
)


def unavailable_target(result):
    receipt=result.get('receipt') or {}
    diagnosis=result.get('diagnosis') or {}
    return (receipt.get('status_code') in (2053, 2209) and not receipt.get('cid')
        and diagnosis.get('detail_status')==0
        and diagnosis.get('video_present') is False
        and diagnosis.get('no_video_detail') is True)


def captcha_unknown(result):
    if not isinstance(result, dict) or result.get('status') != 'unknown':
        return False
    receipt = result.get('receipt') if isinstance(result.get('receipt'), dict) else {}
    return receipt.get('status_code') == CAPTCHA_STATUS


def identity_not_sent(result):
    """True only for the CLI's pre-submit identity/account failures.

    Under send_cli_once.cjs, those throws happen before loggedCall/post, so the
    catch path emits status=not_sent. They are not ordinary unknowns.
    """
    if not isinstance(result, dict) or result.get('status') != 'not_sent':
        return False
    error = str(result.get('error') or '').lower()
    return any(marker in error for marker in _CLI_IDENTITY_ERRORS)


def bridge_disconnect(result):
    """True for a page/Bridge disconnect signal in the CLI error text.

    Field evidence: status=unknown with
    'Request timeout after15000ms — no polling client connected'.
    After loggedCall sets attempted=true, the catch emits unknown; v3 would
    otherwise isolate and walk the rest of the approved queue while disconnected.
    """
    if not isinstance(result, dict):
        return False
    error = str(result.get('error') or '').lower()
    return any(marker in error for marker in _BRIDGE_DISCONNECT_MARKERS)


def preserve_unavailable(task,cid,result):
    if not unavailable_target(result):
        return False
    path=task/'captcha-recovery-authorization.json'
    data=json.loads(path.read_text(encoding='utf-8-sig'))
    preserved=set(data.get('preserve_unknown_comments',[]))
    if cid not in preserved:
        preserved.add(cid)
        data['preserve_unknown_comments']=sorted(preserved)
        data.setdefault('events',[]).append({'at':datetime.datetime.now().astimezone().isoformat(),
            'source':'user_authorized_skip_unavailable_target','skip_unknown_comments':[cid],
            'receipt_status':result['receipt']['status_code'],'diagnosis':result['diagnosis'],
            'note':'原始结果保持未知，不重发；仅跳过当前视频详情不可用的这一目标'})
        temporary=path.with_suffix('.unavailable.tmp')
        temporary.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
        temporary.replace(path)
    return True


def isolate_unknown_in_run(task, cid, result=None):
    """Keep one in-run unknown as-is and let the approved queue continue.

    Never treats the outcome as confirmed unsent. Never republishes the cid.
    """
    path = Path(task) / 'captcha-recovery-authorization.json'
    if path.exists():
        data = json.loads(path.read_text(encoding='utf-8-sig'))
    else:
        data = {'preserve_unknown_comments': [], 'events': []}
    isolated = list(data.get('isolated_unknown_comments') or [])
    if cid not in isolated:
        isolated.append(cid)
    data['isolated_unknown_comments'] = sorted(isolated)
    data['preserve_unknown_comments'] = list(data.get('preserve_unknown_comments') or [])
    receipt = (result or {}).get('receipt') if isinstance(result, dict) else {}
    if not isinstance(receipt, dict):
        receipt = {}
    event = {
        'at': datetime.datetime.now().astimezone().isoformat(),
        'source': 'in_run_unknown_isolated',
        'mark': 'isolated, not resent',
        'note': '本条结果未知，保持未知不重发，继续其余已审队列',
        'isolated_comments': [cid],
        'submission_attempted': False if isinstance(result, dict) and result.get('submission_attempted') is False else True,
        'automatic_retry': False,
    }
    code = receipt.get('status_code')
    if isinstance(code, int) and not isinstance(code, bool):
        event['status_code'] = code
    data.setdefault('events', []).append(event)
    temporary = path.with_suffix('.inrun.tmp')
    temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    temporary.replace(path)
    return True


def in_run_non_sent_action(status, result):
    """Decide whether one non-sent outcome stops the whole run.

    Ordinary unknowns are always isolated and the rest of the approved queue
    continues. There is no count threshold.

    Returns one of:
      continue_unavailable, continue_isolated, continue_skip_target,
      stop_captcha, stop_bridge, stop_identity, stop_other
    """
    payload = dict(result or {})
    if status and 'status' not in payload:
        payload['status'] = status
    if status == 'unknown' and unavailable_target(payload):
        return 'continue_unavailable'
    if status == 'unknown' and captcha_unknown(payload):
        return 'stop_captcha'
    if status in ('unknown', 'not_sent') and bridge_disconnect(payload):
        return 'stop_bridge'
    if status == 'not_sent' and identity_not_sent(payload):
        return 'stop_identity'
    if status == 'unknown':
        return 'continue_isolated'
    if status == 'not_sent' and payload.get('skip_target') is True:
        diagnosis = payload.get('diagnosis') or {}
        if (diagnosis.get('detail_status') == 0 and diagnosis.get('comments_status') == 0
                and diagnosis.get('has_more') == 0 and diagnosis.get('target_present') is False):
            return 'continue_skip_target'
    return 'stop_other'


def load_auth(task):
    path = Path(task) / 'captcha-recovery-authorization.json'
    if not path.exists():
        return {'preserve_unknown_comments': [], 'isolated_unknown_comments': [], 'events': []}
    return json.loads(path.read_text(encoding='utf-8-sig'))


def simulate_execute(task, items, cli_results, *, hold_reason=None, identity_ok=True, lock_busy=False):
    """Offline stand-in for the runner's per-item post-CLI branch. No real CLI."""
    if lock_busy:
        raise RuntimeError('本批程序已经运行，请勿重复启动')
    if hold_reason:
        raise RuntimeError(hold_reason)
    if identity_ok is not True:
        raise RuntimeError('当前账号未核验或账号不匹配，已停止')
    task = Path(task)
    auth_path = task / 'captcha-recovery-authorization.json'
    if not auth_path.exists():
        auth_path.write_text(json.dumps({
            'preserve_unknown_comments': [], 'isolated_unknown_comments': [], 'events': []},
            ensure_ascii=False, indent=2), encoding='utf-8')
    sent, isolated, skipped = [], [], []
    for item in items:
        cid = item['cid']
        auth = load_auth(task)
        decided = set(auth.get('preserve_unknown_comments') or []) | set(auth.get('isolated_unknown_comments') or [])
        if cid in decided:
            skipped.append(cid)
            continue
        result = dict(cli_results[cid])
        status = result.get('status')
        if status == 'sent':
            sent.append(cid)
            continue
        action = in_run_non_sent_action(status, result)
        if action == 'continue_unavailable':
            preserve_unavailable(task, cid, result)
            isolated.append(cid)
            continue
        if action == 'continue_isolated':
            isolate_unknown_in_run(task, cid, result)
            isolated.append(cid)
            continue
        if action == 'continue_skip_target':
            skipped.append(cid)
            continue
        if action == 'stop_captcha':
            raise RuntimeError('存在验证码或平台验证未结束的未知记录（错误码 3002123），已停线。不会自动重发')
        if action == 'stop_bridge':
            raise RuntimeError('抖音页面连接已断开，已停线。本条保持未知、不重发。请刷新登录页面后再点启动／继续。')
        if action == 'stop_identity':
            raise RuntimeError('账号核对未通过，已停线。没有继续发送。')
        raise RuntimeError('已保存CLI返回结果并停止；不会自动重发')
    return {
        'sent': sent,
        'isolated': isolated,
        'skipped': skipped,
        'auth': load_auth(task),
    }
