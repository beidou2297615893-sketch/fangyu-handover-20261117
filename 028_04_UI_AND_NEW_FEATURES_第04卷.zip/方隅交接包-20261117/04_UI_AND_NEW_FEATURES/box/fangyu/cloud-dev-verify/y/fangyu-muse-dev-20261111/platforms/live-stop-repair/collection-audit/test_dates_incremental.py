"""Review new date-domain and captcha behavior. No platform requests or DB writes."""
from pathlib import Path
from copy import deepcopy
from datetime import datetime
import ast,hashlib,json,sys,traceback,collections,re,os
from urllib.parse import urlsplit
sys.dont_write_bytecode=True
H=Path(__file__).resolve().parent
P=Path('C:/积木软件工坊/项目/方隅公寓客户版')
S=P/'work/parallel-integration-20261018/final-integration/stage-02/project'
V=P/'work/parallel-integration-20261018/final-integration/candidate-unified-v17/project'
SRC=S/'work/ui-runtime-r55/src';OLD=V/'work/ui-runtime-r55/src'
def audit(event,args):
    if event in ('socket.connect','socket.bind','subprocess.Popen','os.system','os.startfile'):raise RuntimeError('Review prohibits network/process/UI')
    if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
        mode,flags=args[1] or '',args[2] or 0
        write=any(c in str(mode) for c in 'wax+') or isinstance(flags,int) and flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC)
        if write and not Path(os.fsdecode(args[0])).absolute().is_relative_to(H):raise RuntimeError('Review write outside evidence')
sys.addaudithook(audit);sys.path.insert(0,str(SRC))
from core import pipeline
from core.adapters import Adapters,_raise_xhs_cli_error,AdapterAuthRequired,PageUnavailable
from core.page_errors import PageOperationFailure,PAGE_ERROR_MESSAGES
from core.platform_failure import AdapterPlatformFailure,validated as validated_platform_failure
from core.selection import identity_decision

def filter_function(path):
    tree=ast.parse(path.read_text('utf-8'));inner=next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=='_run_inner')
    loop=next(n for n in ast.walk(inner) if isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id=='item' and isinstance(n.iter,ast.Name) and n.iter.id=='items')
    condition=next(n for n in loop.body if isinstance(n,ast.If) and isinstance(n.test,ast.UnaryOp))
    start=next(i for i,n in enumerate(condition.body) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='exclude' for t in n.targets))
    end=next(i for i,n in enumerate(condition.body[start:],start) if isinstance(n,ast.If) and isinstance(n.test,ast.Name) and n.test.id=='exclude')
    body=deepcopy(condition.body[start:end+1])
    template=ast.parse('def run(items,task):\n selected=[]\n reasons=[]\n def rejected(reason):reasons.append(reason)\n for item in deepcopy(items):\n  pass\n return selected,reasons\n')
    fn=template.body[0];target=next(n for n in fn.body if isinstance(n,ast.For));target.body=body+[ast.parse('selected.append(item)').body[0]]
    ast.fix_missing_locations(template);space={'__package__':'core','deepcopy':deepcopy,'datetime':datetime}
    exec(compile(template,str(path)+'[exact-date-block]','exec'),space)
    return space['run']

oldfilter=filter_function(OLD/'core/engine.py');newfilter=filter_function(SRC/'core/engine.py')
cases=[]
followup='--followup' in sys.argv
prior=json.loads((H/'DATE-CAPTCHA-RESULT.RED-before-fix.json').read_text('utf-8')) if followup else {}
new_names={'Unknown post date keeps prior review evidence once without fabricating a verified range',
    'Known outside cached post is skipped before before_read and adapter request',
    'Actual three ACK error payloads map to fixed captcha enum without exposing challenge type/uuid',
    'Exact Core failure handler preserves ready account/session on explicit CAPTCHA and only pauses task',
    'Customer-only DY overlay pin equals newly reviewed exact pipeline source hash'}
def case(name,fn):
    if followup and name not in new_names:
        previous=next(c for c in prior['checks'] if c['name']==name)
        assert previous['status']=='PASS'
        cases.append({**previous,'reused_from':'DATE-CAPTCHA-RESULT.RED-before-fix.json','executed_this_followup':False});return
    try:fn();cases.append({'name':name,'status':'PASS'})
    except BaseException as error:cases.append({'name':name,'status':'FAIL','error_type':type(error).__name__,'trace':traceback.format_exc()})
task={'platform':'xiaohongshu','scope':'search_comments','continuous_enabled':False,'comment_keyword_mode':'all','comment_date_range':'all','date_from':'2026-10-13','date_to':'2026-10-19','region':'','unknown_policy':'exclude','keywords':['synthetic'],'comment_depth':'all'}
observed=json.loads((H/'LATEST-REAL.json').read_text('utf-8'));latest=observed['tasks'][0];real_pages=[];notes=[]
for row in reversed(latest['page_receipts']):
    page=json.loads(Path(row['file']).read_text('utf-8'));payload=json.loads((page.get('result') or {}).get('stdout') or '{}')
    if page['operation']=='search' and page['result']['returncode']==0:notes=Adapters.map_items(payload,'xhs_v1','xiaohongshu')
    elif page['operation']=='comments' and page['result']['returncode']==0:real_pages.append((page,payload))
baseline=[];all_rows=[];note_metadata=[]
for index,(page,payload) in enumerate(real_pages,1):
    rawcomments=payload['data']['comments'];ids={str(c.get('note_id')) for c in rawcomments};matched=[n for n in notes if urlsplit(n['url']).path.rsplit('/',1)[-1] in ids];assert len(matched)==1
    note=matched[0];rows=Adapters.map_comments(payload,note['url'])
    for row in rows:row['content_published_at']=note.get('published_at','')
    original_data=next(json.loads(json.loads(Path(p['file']).read_text('utf-8'))['result']['stdout'])['data'] for p in latest['page_receipts'] if p['operation']=='search')
    card=next(x['note_card'] for x in original_data['items'] if str(x.get('id')) in ids)
    datefields=[]
    def inspect(value,prefix='note_card'):
        if isinstance(value,dict):
            for key,item in value.items():
                current=prefix+'.'+key
                if re.search(r'time|date|publish|create',key,re.I):
                    date=''
                    if isinstance(item,(int,float)) and 946684800<=item<=4102444800000:
                        date=Adapters.timestamp(item)[:10]
                    elif isinstance(item,str) and re.fullmatch(r'\d{4}-\d{2}-\d{2}(?:[T ].*)?',item):date=item[:10]
                    datefields.append({'field':current,'date':date or None,'value_type':type(item).__name__})
                inspect(item,current)
        elif isinstance(value,list):
            for i,item in enumerate(value):inspect(item,prefix+f'[{i}]')
    inspect(card)
    note_metadata.append({'note_ordinal':index,'card_field_names':list(card),'recognized_date_fields':datefields,'mapped_post_date':note.get('published_at') or None,'comments_count':len(rows)})
    for row in rows:
        baseline.append({'row_ordinal':len(baseline)+1,'note_ordinal':index,'comment_date':row.get('published_at','')[:10],'post_date':row.get('content_published_at') or None,'is_reply':bool(row.get('parent_id')),'avatar_source_present':bool(row.get('author_avatar_url')),'text_present':bool(row.get('text')),'source_fingerprint':hashlib.sha256(row['source_id'].encode()).hexdigest()})
    all_rows.extend(rows)
assert len(all_rows)==17

def real_old_new():
    old,old_reasons=oldfilter(all_rows,task);new,new_reasons=newfilter(all_rows,task)
    assert len(old)==0 and old_reasons==['date']*17
    assert len(new)==17 and not new_reasons
    assert all(r.get('verification_status')=='pending' and r.get('post_date_status')=='unverified' and '帖子日期' in r.get('filter_review_reason','') for r in new)
case('Exact old/new Core filter on 17 cached real comments: old rejects date, new retains all as unverified post date',real_old_new)

def inrange_old_comment():
    row={'published_at':'2026-09-11T12:00:00','content_published_at':'2026-10-18T12:00:00'}
    assert oldfilter([row],task)[1]==['date']
    accepted,reasons=newfilter([row],task);assert len(accepted)==1 and not reasons and accepted[0]['post_date_status']=='in_range'
case('Known in-range post allows old comment under explicit comment all-time scope',inrange_old_comment)

def known_outside():
    row={'published_at':'2026-10-18T12:00:00','content_published_at':'2026-09-11T12:00:00'}
    assert len(oldfilter([row],task)[0])==1
    assert newfilter([row],task)[1]==['date']
case('Known outside post rejects recent comment by post date instead of comment date',known_outside)

def unknown_reason_kept():
    row={'published_at':'2026-09-11T12:00:00','content_published_at':'','filter_review_reason':'已有来源待核实'}
    accepted,_=newfilter([row],task)
    assert len(accepted)==1 and accepted[0]['filter_review_reason'].startswith('已有来源待核实；')
    repeated,_=newfilter(accepted,task)
    assert repeated[0]['filter_review_reason']==accepted[0]['filter_review_reason']
case('Unknown post date keeps prior review evidence once without fabricating a verified range',unknown_reason_kept)

def legacy_unchanged(change):
    oldtask={**task,**change};assert not pipeline.uses_post_dates(oldtask)
    rows=[{'published_at':'2026-09-11','content_published_at':'2026-10-18'},{'published_at':'2026-10-18','content_published_at':'2026-09-11'},{'published_at':''}]
    assert newfilter(rows,oldtask)==oldfilter(rows,oldtask)
for change in ({'scope':'comments'},{'continuous_enabled':True},{'comment_date_range':'3months'},{'comment_keyword_mode':'match'},{'platform':'zhihu'}):
    case('Legacy/continuous date-block semantics unchanged: '+json.dumps(change),lambda change=change:legacy_unchanged(change))

class FakeAdapters:
    def __init__(self):self.reads=0
    def comments(self,platform,query):
        self.reads+=1;query['_page_info']={'has_more':False,'cursor':''};query['_reply_roots']=[];query['_reply_pages']=[]
        return [{'source_id':'synthetic-comment','text':'synthetic','published_at':'2026-09-11','author':'synthetic','author_id':'synthetic'}]
    def search(self,*a,**k):raise AssertionError('No search may be issued by this cached-note fixture')
    def sub_comments(self,*a,**k):raise AssertionError('No subcomment fixture request expected')
def pipeline_fixture(date):
    return {**deepcopy(task),'pipeline':{'keyword_index':0,'search_page':1,'notes':[{'url':'https://www.xiaohongshu.com/explore/synthetic','title':'synthetic','author':'synthetic','author_id':'synthetic','published_at':date}], 'note_index':0,'cursor':'','reply_queue':[],'search_more':False}}
def skipped_before_read():
    current=pipeline_fixture('2026-09-11');adapter=FakeAdapters();calls=[];snapshots=[]
    rows=pipeline.collect_batch(adapter,current,lambda:snapshots.append(deepcopy(current.get('pipeline'))),before_read=lambda:calls.append('read'))
    assert rows==[] and calls==[] and adapter.reads==0
    assert current['_pipeline_next']['date_skipped_posts']==1
case('Known outside cached post is skipped before before_read and adapter request',skipped_before_read)

def inside_pipeline():
    current=pipeline_fixture('2026-10-18');adapter=FakeAdapters();calls=[]
    rows=pipeline.collect_batch(adapter,current,lambda:None,before_read=lambda:calls.append('read'))
    assert len(rows)==1 and calls==['read'] and adapter.reads==1
    assert rows[0]['published_at']=='2026-09-11' and rows[0]['content_published_at']=='2026-10-18'
case('Pipeline preserves separate in-range post date and old comment date',inside_pipeline)

def captcha_real():
    inspected=0
    for taskrow in observed['tasks'][:3]:
        for entry in taskrow['page_receipts']:
            page=json.loads(Path(entry['file']).read_text('utf-8'));payload=json.loads((page.get('result') or {}).get('stdout') or '{}')
            if page.get('state')=='acknowledged' and page.get('result',{}).get('returncode')==1:
                receipt_hash=hashlib.sha256(Path(entry['file']).read_bytes()).hexdigest()
                original_payload=deepcopy(payload)
                try:_raise_xhs_cli_error('verification_required',payload,{'http_status':461,'platform_code':0})
                except Exception as error:
                    assert isinstance(error,AdapterPlatformFailure) and not isinstance(error,AdapterAuthRequired)
                    facts=getattr(error,'platform_error',None);assert facts and facts['auth_signal']=='captcha_challenge' and facts['category']=='verification_required'
                    assert 'uuid' not in json.dumps(facts) and '124' not in json.dumps(facts)
                else:raise AssertionError('Exact cached error was not raised')
                assert payload==original_payload and hashlib.sha256(Path(entry['file']).read_bytes()).hexdigest()==receipt_hash
                inspected+=1
    assert inspected==3
case('Actual three ACK error payloads map to fixed captcha enum without exposing challenge type/uuid',captcha_real)

def captcha_generic(message,code='verification_required'):
    try:_raise_xhs_cli_error(code,{'error':{'code':code,'message':message}},{'http_status':461})
    except Exception as error:
        facts=getattr(error,'platform_error',None);assert facts and facts['auth_signal'] is None and facts['category']=='platform_rejected'
    else:raise AssertionError('Expected bounded platform failure')
for message in ('HTTP461','Captcha required: type=unknown, uuid=unknown','Captcha required: type=124, uuid=','Captcha required: type=0, uuid=abcdefgh','Captcha required: type=124, uuid=abcdefgh\n'):
    case('Generic/malformed CAPTCHA text cannot infer auth: '+str(len(message)),lambda message=message:captcha_generic(message))
case('Other CLI code cannot borrow CAPTCHA wording to change category',lambda:captcha_generic('Captcha required: type=124, uuid=abcdefgh','api_error'))

def core_failure_handler():
    tree=ast.parse((SRC/'core/engine.py').read_text('utf-8'))
    inner=next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=='_run_inner')
    handler=next(n for n in inner.body if isinstance(n,ast.Try)).handlers[-1]
    assert isinstance(handler.type,ast.Name) and handler.type.id=='Exception' and handler.name=='exc'
    template=ast.parse('def handle(self,task,exc,tenant,user):\n pass\n')
    template.body[0].body=deepcopy(handler.body);ast.fix_missing_locations(template)
    space={'AdapterAuthRequired':AdapterAuthRequired,'AdapterPlatformFailure':AdapterPlatformFailure,
           'PageUnavailable':PageUnavailable,'PageOperationFailure':PageOperationFailure,'PAGE_ERROR_MESSAGES':PAGE_ERROR_MESSAGES,
           'validated_platform_failure':validated_platform_failure,'now':lambda:'isolated-review'}
    exec(compile(template,str(SRC/'core/engine.py')+'[exact-failure-handler]','exec'),space)
    return space['handle']

class FakeStore:
    def __init__(self):self.rows={'tasks':{'id':'fake-task','account_id':'fake-account','tenant_id':'fake-tenant'},'accounts':{'id':'fake-account','tenant_id':'fake-tenant','status':'ready'}};self.writes=[]
    def get(self,kind,key):return deepcopy(self.rows[kind])
    def put(self,kind,row):self.writes.append(kind);self.rows[kind]=deepcopy(row)
class FakeCore:
    def __init__(self):self.store=FakeStore();self.audits=[]
    def _audit(self,*args):self.audits.append(args)

def captcha_does_not_drop_session():
    error=None
    for taskrow in observed['tasks'][:1]:
        for entry in taskrow['page_receipts']:
            page=json.loads(Path(entry['file']).read_text('utf-8'))
            if page.get('state')=='acknowledged' and page.get('result',{}).get('returncode')==1:
                payload=json.loads(page['result']['stdout'])
                try:_raise_xhs_cli_error('verification_required',payload,{'http_status':461,'platform_code':0})
                except AdapterPlatformFailure as caught:error=caught
    assert error and not isinstance(error,AdapterAuthRequired)
    core=FakeCore();current=deepcopy(core.store.rows['tasks'])
    result=core_failure_handler()(core,current,error,'fake-tenant',{})
    assert result['status']=='blocked' and result['platform_error']['auth_signal']=='captcha_challenge'
    assert core.store.rows['accounts']['status']=='ready' and 'accounts' not in core.store.writes
    assert core.store.rows['tasks']['pause_reason']=='collection_error'
case('Exact Core failure handler preserves ready account/session on explicit CAPTCHA and only pauses task',captcha_does_not_drop_session)

def overlay_matches():
    path=S/'work/shared-backend-integration/vendor-src/douyin_pipeline_overlay.py'
    code=path.read_text('utf-8');tree=ast.parse(code)
    assignment=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='_PIPELINE_SHA' for t in n.targets))
    assert ast.literal_eval(assignment.value).lower()==hashlib.sha256((SRC/'core/pipeline.py').read_bytes()).hexdigest()
case('Customer-only DY overlay pin equals newly reviewed exact pipeline source hash',overlay_matches)

old_kept,old_rejected=oldfilter(all_rows,task);new_kept,new_rejected=newfilter(all_rows,task)
baseline_result={'status':'READ_ONLY_REAL_CACHED_BASELINE_AND_CANDIDATE_MATRIX','task_id':latest['task']['id'],'real_cached_comments':len(all_rows),'post_cards':note_metadata,'comment_rows':baseline,
    'candidate_policies':[{'policy':'v17_actual_comment_date_filter','kept':len(old_kept),'date_rejected':len(old_rejected)},
      {'policy':'post_dates_strict_unknown_exclude','kept':0,'post_date_unknown':17,'comment_time_rejections':0},
      {'policy':'root_candidate_post_dates_unknown_pending','kept':len(new_kept),'date_rejected':len(new_rejected),'post_date_pending':sum(r.get('verification_status')=='pending' for r in new_kept),'verified_post_dates':0}],
    'AI_analyzed_by_this_review':0,'imported_by_this_review':0,'production_writes':0,'tokens_or_source_values_exported':False}
if not followup:(H/'CACHED-17-BASELINE.json').write_text(json.dumps(baseline_result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
files=['core/engine.py','core/pipeline.py','core/adapters.py'];result={'status':'PASS_DATE_CAPTCHA_INCREMENTAL' if all(c['status']=='PASS' for c in cases) else 'FAIL','checks':cases,'source_sha256':{r:hashlib.sha256((SRC/r).read_bytes()).hexdigest() for r in files},'old_filter_source_sha256':hashlib.sha256((OLD/'core/engine.py').read_bytes()).hexdigest(),'real_cached_rows_read':17,'real_platform_requests':0,'real_model_requests':0,'CLI_processes_started':0,'UI_operations':0,'production_writes':0,'product_edits_by_reviewer':0}
(H/'DATE-CAPTCHA-RESULT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2));raise SystemExit(any(c['status']!='PASS' for c in cases))
