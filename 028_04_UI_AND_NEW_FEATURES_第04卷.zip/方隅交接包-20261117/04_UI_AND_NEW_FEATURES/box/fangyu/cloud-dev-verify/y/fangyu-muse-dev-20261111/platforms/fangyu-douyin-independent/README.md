# 方隅抖音独立离线账本小样

本目录仅做本地结果导入和校验，没有网络请求、浏览器操作、发送、验证码处理或自动重试能力。未连接平台，未采集真人数据。

`ledger.py` 仅使用 Python 标准库。运行合成测试：

```powershell
python -m unittest -v test_ledger.py
```

可导入本地 JSON：

```powershell
python ledger.py ingest sample-input.json
python ledger.py summary
```

默认账本在本目录 `runtime/collection.sqlite3`。所有数据库路径必须在本目录内。测试数据位于各个 `test-*` 子目录，全部为合成数据。未创建生产账本或导入任何旧客户。

输入对象必须包含 `spec` 和 `response`：

```json
{
  "spec": {
    "request_id": "unique-request-id",
    "account_uid": "explicit-owner-uid",
    "connection_id": "explicit-bridge-connection-id",
    "kind": "comments",
    "target": "123456789",
    "cursor": 0,
    "rule_source": "current-user-authorization-reference"
  },
  "response": {
    "ok": true,
    "connection": "explicit-bridge-connection-id",
    "value": {
      "status_code": 0,
      "comments": [{"cid": "987654321", "text": "合成测试原文"}],
      "cursor": 20,
      "has_more": 0
    }
  }
}
```

搜索使用 `kind=search`，`target` 为关键词；响应来自既有 `__bridge.search` 原始返回，列表为 `data[].aweme_info`，稳定ID为字符串 `aweme_id`。评论来自 `__bridge.getComments`，列表为 `comments[]`，稳定ID为字符串 `cid`。数字ID拒绝强转，避免旧 JS 层可能产生的整数精度丢失。非视频搜索卡片仅留在原始响应中，不虚构作品或客户。视频仅是入口，不计入评论数；不把评论条数当独立客户人数。

`attempts` 保存每次导入的请求、经已知凭据字段脱敏的完整响应结构、接收时间、状态、规则来源和摘要；`items` 按稳定ID去重；`streams` 保存账号/搜索词或作品维度游标；`pages` 防止同页重复记入。原始响应、去重项和游标在同一事务提交。失败不推进游标，写入失败时整体回滚。相同 request_id 的同一输入可幂等读回，冲突输入拒绝覆盖证据。原始响应以 JSON 字段保真保存，不承诺原始网络字节保真。

状态 `parsed` 只表示结构校验通过，**不表示平台成功验收或本人账号身份已验证**。账号UID来自调用方的显式声明，本工具没有权限核验。`unknown` 表示没有确定的平台结果，不是失败，不自动重试；`verification_required`、`platform_error`、`connection_mismatch`、`invalid_response`、`stale_cursor` 均保留输入证据且不推进。仅识别已知 `search_nil_info.search_nil_type=verify_check` 验证码字段，不能保证所有平台验证/限流形态都已穷举；其他未知结构拒绝猜成功。

不要输入 Cookie、Token、Headers、登录配置或任意含秘密的报错。本工具针对已知凭据键和 URL 敏感参数做防御性脱敏，无法证明任意自由文本绝不包含秘密。未读取旧配置或会话，未修改旧服务。

## 既有代码复用评估

已只读检查本地既有 `douyin_read.cjs`、`campaign_collect.py`、`comment_job.py`、`BridgeClient` 和 `router.js`。旧包装器硬绑定个人19422并读取旧实例配置，不能直接作为本独立实例入口。既有 Bridge 来源为 Yht20927/douyin-cli，本地许可为 MIT；本次未复制上游源码、未新增依赖，仅复用其返回数据契约。

`router.js` 在 `strictConnections` 未开启且指定连接失效时会退回该站点首个连接。当前本地源码提供 strictConnections 分支，但实际运行服务配置和网页归属未由本工具验证。客户端每次读取前后核验唯一连接、实际返回 connection、本人账号UID是必要措施；如果请求本身没有服务端/页面内严格约束，前后核验存在竞态，不能仅据此宣称采集隔离安全。真实采集应先独立验证严格连接失败即停止、请求实际账号归属及小样返回结构；不能修改或借用旧服务来省略这些步骤。

本交付仅是隔离可复用存储层。未提供或启动实采worker、调度器、意向分析器、草稿生成器和发送器。没有凭本地测试冒充真实平台验收。
