"""Read-only console view of the authorized Douyin reply batch."""
import argparse
from contextlib import closing
import ctypes
import datetime as dt
import json
import os
from pathlib import Path
import re
import sqlite3
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
LEDGER = ROOT / 'work/shared-acquisition-ledger/shared.sqlite3'
DETAILS = ROOT / 'work/fangyu-douyin-independent/reply-pilot'
BATCH_PREFIX = 'douyin-v3-%20261101-%'
LIMIT = 200


def clean(value, maxlen=80):
    text = re.sub(r'[\x00-\x1f\x7f-\x9f]', ' ', str(value or ''))
    return text if len(text) <= maxlen else text[:maxlen - 1] + '…'


def parsed_time(value):
    if not value:
        return None
    try:
        if isinstance(value, (int, float)):
            return dt.datetime.fromtimestamp(value).astimezone()
        return dt.datetime.fromisoformat(str(value).replace('Z', '+00:00')).astimezone()
    except (TypeError, ValueError, OSError):
        return None


def stamp(value):
    moment = parsed_time(value)
    return moment.strftime('%m-%d %H:%M:%S') if moment else '未记录'


def snapshot():
    # Opening in read-only mode and query_only prevents writes to shared records.
    with closing(sqlite3.connect(LEDGER.as_uri() + '?mode=ro', uri=True, timeout=0.5)) as conn:
        conn.row_factory = sqlite3.Row
        conn.execute('PRAGMA query_only=ON')
        rows = [dict(r) for r in conn.execute(
            "SELECT r.*, a.data AS assessment FROM reservations r LEFT JOIN assessments a "
            "ON a.platform=r.platform AND a.customer=r.customer AND a.comment=r.comment "
            "WHERE r.platform='douyin' AND r.token LIKE ? ORDER BY r.created DESC", (BATCH_PREFIX,))]
    counts = {status: sum(r['status'] == status for r in rows)
              for status in ('sent', 'reserved', 'unknown', 'not_sent')}
    lines = ['方隅抖音 · 回复实时状态（只读）',
             '刷新时间：' + dt.datetime.now().strftime('%Y-%m-%d %H:%M:%S') + '   每 3 秒更新',
             '=' * 74,
             f"本轮上限：{LIMIT} 条   已确认成功：{counts['sent']} 条   尚余名额：{max(0, LIMIT-len(rows))} 条",
             f"登记中/发送待核验：{counts['reserved']}   结果未知：{counts['unknown']}   明确未发送：{counts['not_sent']}",
             '成功以实际回执为准；登记不等于已发送。结果未知不会当作失败重发。',
             '本窗口只展示账本，不控制发送；关闭本窗口不影响正在处理的回复。',
             '历史辅助进程退出不代表回复失败；发送结果只按下方共享账本统计。',
             '-' * 74, '最近处理记录：']
    labels = {'sent': '成功', 'reserved': '登记中/待核验', 'unknown': '结果未知', 'not_sent': '明确未发送'}
    for row in rows[:8]:
        filename = 'pilot.json' if 'pilot-' in row['token'] else row['comment'] + '.json'
        try:
            record = json.loads((DETAILS / filename).read_text(encoding='utf-8-sig'))
        except (OSError, ValueError):
            record = {}
        try:
            assessment = json.loads(row['assessment'] or '{}')
        except ValueError:
            assessment = {}
        reply = record.get('reply', {})
        if not isinstance(reply, dict):
            reply = {}
        submit = record.get('submitted_at') or record.get('submission_intent_at')
        receipt = record.get('receipt_at') or record.get('verified_at') or record.get('confirmed_at')
        t1, t2 = parsed_time(record.get('submitted_at')), parsed_time(receipt)
        elapsed = f'{(t2-t1).total_seconds():.1f} 秒' if t1 and t2 and t2 >= t1 else '未知（缺少完整起止时间）'
        lines.extend([
            f"[{labels.get(row['status'], '待核验')}] 登记 {stamp(row['created'])}  提交准备 {stamp(submit)}  核验 {stamp(receipt)}",
            '  原评论：' + clean(record.get('comment_text') or record.get('original_comment') or '暂未关联原文'),
            '  回复：' + clean(reply.get('draft_text') or record.get('draft_text') or assessment.get('draft') or '暂未关联正文'),
            '  处理耗时：' + elapsed,
        ])
    if not rows:
        lines.append('当前尚无本轮回复登记。')
    return '\n'.join(lines)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--once', action='store_true')
    args = parser.parse_args()
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    if os.name == 'nt' and not args.once:
        ctypes.windll.kernel32.SetConsoleTitleW('方隅抖音回复实时状态 · 只读 · 上限200条')
    while True:
        try:
            content = snapshot()
        except (OSError, sqlite3.Error, ValueError) as exc:
            content = ('方隅抖音 · 回复实时状态（只读）\n'
                       '本轮暂时未读到账本，等待下次刷新；不会影响发送。\n'
                       '详情类型：' + type(exc).__name__)
        if not args.once:
            os.system('cls' if os.name == 'nt' else 'clear')
        print(content, flush=True)
        if args.once:
            return
        time.sleep(3)


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        pass
