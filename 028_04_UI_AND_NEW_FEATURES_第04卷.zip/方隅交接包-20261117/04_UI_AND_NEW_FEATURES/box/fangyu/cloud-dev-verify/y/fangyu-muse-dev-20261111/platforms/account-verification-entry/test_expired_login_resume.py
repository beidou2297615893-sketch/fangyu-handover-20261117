"""Focused real regression: same-UID login renewal after closing owned window."""
from test_session_handoff import *
from core.xhs_verified_resume import captcha_receipt

class ExpiredLoginTests(HandoffTests):
    def expired(self):
        self.receipt['result']['stdout']=json.dumps({'ok':False,'schema_version':'1','error':{
            'code':'not_authenticated','message':'Session expired — please re-login with: xhs login'}})
        self.receipt['digest']=digest(self.receipt['result'])
        self.path.write_bytes(json.dumps(self.receipt).encode())

    def test_expired_login_closed_window_reopens_and_updates_account(self):
        self.expired();runtime,user,worker=self.runtime()
        account=self.store.get('accounts',self.account['id']);account['status']='login_required';self.store.put('accounts',account)
        runtime.server.jobs.clear();opened=[]
        def reopen(u,d):
            opened.append(d);runtime.server.jobs[self.job['id']]=self.job
            return {'result':{'taskId':self.task,'accountId':self.account['id'],'status':'verification_open'}}
        runtime.open_account_verification=reopen
        runtime.resume_verified_acquisition(user,{'taskId':self.task});worker.join(1)
        self.assertEqual(opened,[{'accountId':self.account['id']}]);self.assertEqual(self.calls['resume'],1)
        self.assertEqual(self.store.get('accounts',self.account['id'])['status'],'ready')

    def test_expired_login_cannot_authorize_unknown_or_unsent(self):
        self.expired()
        for changed in ({'state':'unknown'},{'wire_allow_attempts':0}):
            original=self.path.read_bytes();self.path.write_bytes(json.dumps({**self.receipt,**changed}).encode())
            self.assertIsNone(failed_page(self.home,self.task,self.scope));self.path.write_bytes(original)

    def test_expired_login_is_not_mislabelled_as_captcha(self):
        self.expired();self.assertFalse(captcha_receipt(self.receipt))

    def test_expired_login_grant_consumes_only_one_original_page(self):
        self.expired();self.context=failed_page(self.home,self.task,self.scope)
        self.assertEqual(self.validate().state,'completed')
        fresh=self.store.get('accounts',self.account['id']);grants=verified_pages(self.home,self.task,self.scope,fresh)
        worker,calls=self.worker(grants)
        self.assertEqual(worker.request(self.args)[2],0);self.assertEqual(calls,['start','allow'])
        self.assertEqual(worker.request(self.args)[2],0);self.assertEqual(calls,['start','allow'])
        self.assertIsNone(failed_page(self.home,self.task,self.scope));worker.close()

if __name__=='__main__':
    suite=unittest.TestSuite(ExpiredLoginTests(name) for name in [
        'test_expired_login_closed_window_reopens_and_updates_account',
        'test_expired_login_cannot_authorize_unknown_or_unsent','test_expired_login_is_not_mislabelled_as_captcha',
        'test_expired_login_grant_consumes_only_one_original_page'])
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    (T/'EXPIRED-LOGIN-TESTS.json').write_bytes((json.dumps({'status':'PASS' if result.wasSuccessful() else 'FAIL',
        'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'synthetic_only':True})+'\n').encode())
    raise SystemExit(not result.wasSuccessful())
