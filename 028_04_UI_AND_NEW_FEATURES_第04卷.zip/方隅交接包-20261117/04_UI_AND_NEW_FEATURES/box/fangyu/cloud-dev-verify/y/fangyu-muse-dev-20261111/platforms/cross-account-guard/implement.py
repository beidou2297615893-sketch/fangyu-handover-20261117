from pathlib import Path
import shutil
S=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project')
T=Path(__file__).resolve().parent
def edit(rel,fn):
    p=S/rel;b=T/'before'/rel;b.parent.mkdir(parents=True,exist_ok=True)
    if not b.exists():shutil.copy2(p,b)
    old=p.read_text('utf-8');new=fn(old)
    assert new!=old,rel
    p.write_text(new,'utf-8')
R='work/shared-backend-integration/platform_runtime.py'
def runtime(t):
    t=t.replace("else account_view(connected)['status'])","else account_view(connected).get('status') or 'login_required')")
    t=t.replace("record['store_id']=selected\n            self.core.store.put('accounts',record)","record['store_id']=selected\n            record.setdefault('status','login_required')\n            self.core.store.put('accounts',record)")
    t=t.replace("result={'id':ident,'status':state,'phase':phase,'message':messages[state],","result={'id':ident,'accountId':job.get('account_id'),'status':state,'phase':phase,'message':messages[state],")
    t=t.replace("elif window_open and state=='failed':","elif state=='failed' and job.get('error_code')=='identity_mismatch':\n            result['message']='网页登录的账号与本条记录绑定的账号不同；请登录原账号，或在新增账号条目连接新账号'\n        elif window_open and state=='failed':")
    return t
edit(R,runtime)
W='work/ui-approved-implementation/ui-preview/'
edit(W+'app.mjs',lambda t:t.replace('await connectAccount(platformId);return;}const result=jobId?', 'await connectAccount(platformId,latestJob.accountId);return;}const result=jobId?'))

# Keep the original queue lease, validation, cancel and unknown-result rules.
# Extend only its item loop so a customer conflict is recorded as a skip.
base=(S/'work/ui-runtime-r55/src/core/review_queue.py').read_text('utf-8')
method=base[base.index('    def process(self, ident):'):]
assert method.rstrip().endswith('self._workers.pop(ident, None)')
method=method.replace('    def process(self, ident):','    def _process_guarded(self, ident):',1)
old="""                    lead, _ = self._validate(reply, user, tenant, account, value)
                result = self.core._send_reply({'id': reply['id'], 'account_id': account['id'], 'authorized': True},
                    user, tenant, reply, lead, mode_owner=owner)"""
new="""                    lead = self.core._get('leads',reply['lead_id'],tenant)
                    conflict = self.owner.customer_conflict(tenant,lead)
                    if not conflict:
                        lead, _ = self._validate(reply, user, tenant, account, value)
                result = ({'status':'skipped','last_error':conflict} if conflict else
                    self.core._send_reply({'id': reply['id'], 'account_id': account['id'], 'authorized': True},
                        user, tenant, reply, lead, mode_owner=owner))"""
assert old in method;method=method.replace(old,new)
method=method.replace("                    elif queue['status'] == 'running':", "                    elif result['status'] == 'skipped':\n                        queue['skipped']=queue.get('skipped',0)+1\n                        queue.setdefault('skipped_reasons',{})[reply['id']]=result['last_error']\n                    elif queue['status'] == 'running':")

guard='''
    def _customer_key(self,tenant,lead):
        author=str(lead.get('author_id') or '').strip()
        if not author:fail('CUSTOMER_ID_REQUIRED','缺少客户平台身份，不能确认是否已回复；请先核对来源',409)
        return digest([tenant,lead.get('platform'),author])

    @staticmethod
    def _conflict_message(state):
        return ('该客户已有账号回复成功，本条自动跳过' if state=='sent' else
            '该客户正在发送或上次结果待核对，本条自动跳过，避免跨账号重复联系')

    def _customer_claim(self,tenant,lead,reply=None,account_id=None):
        # BEGIN IMMEDIATE serializes reservations even across independent Core
        # instances. No database transaction is held during the platform call.
        key=self._customer_key(tenant,lead)
        with self.core.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            row=db.execute('SELECT body FROM records WHERE entity=? AND id=?',
                (CUSTOMER_GUARD,key)).fetchone()
            prior=json.loads(row['body']) if row else None
            if prior and prior.get('state')!='released':
                return None,self._conflict_message(prior.get('state'))
            # Include pre-upgrade history, across accounts, employees and posts.
            history=db.execute("""SELECT r.body FROM records r JOIN records l
                ON l.entity='leads' AND l.tenant_id=r.tenant_id
                AND l.id=json_extract(r.body,'$.lead_id')
                WHERE r.entity='replies' AND r.tenant_id=?
                AND json_extract(l.body,'$.platform')=?
                AND CAST(json_extract(l.body,'$.author_id') AS TEXT)=?
                AND json_extract(r.body,'$.status') IN ('sent','sending','unknown')""",
                (tenant,lead.get('platform'),str(lead.get('author_id')))).fetchall()
            if history:
                states=[json.loads(r['body']).get('status') for r in history]
                return None,self._conflict_message('sent' if 'sent' in states else 'unknown')
            if reply is None:return None,''
            claim={'id':key,'tenant_id':tenant,'state':'reserved','reservation':uuid4().hex,
                'reply_id':reply['id'],'account_id':account_id,'created_at':stamp()}
            db.execute('INSERT OR REPLACE INTO records VALUES(?,?,?,?)',
                (CUSTOMER_GUARD,key,tenant,json.dumps(claim,ensure_ascii=False)))
            return claim,''

    def customer_conflict(self,tenant,lead):
        return self._customer_claim(tenant,lead)[1]

    def _finish_claim(self,claim):
        with self.core.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            row=db.execute('SELECT body FROM records WHERE entity=? AND id=?',
                (CUSTOMER_GUARD,claim['id'])).fetchone()
            current=json.loads(row['body']) if row else {}
            if current.get('reservation')!=claim['reservation']:return
            row=db.execute("SELECT body FROM records WHERE entity='replies' AND id=? AND tenant_id=?",
                (claim['reply_id'],claim['tenant_id'])).fetchone()
            reply=json.loads(row['body']) if row else {}
            # A definite pre-send refusal is safe to release. Interrupted or
            # uncertain sends never expire into an automatic retry.
            state=('sent' if reply.get('status')=='sent' else 'released'
                if reply.get('status')=='approved' and not reply.get('attempted_at') else 'unknown')
            current.update(state=state,updated_at=stamp())
            db.execute('UPDATE records SET body=? WHERE entity=? AND id=?',
                (json.dumps(current,ensure_ascii=False),CUSTOMER_GUARD,claim['id']))

'''
def delivery(t):
    t=t.replace('import threading,hashlib,json,re','import threading,hashlib,json,re,time\nfrom core.continuous import process_alive,stamp')
    t=t.replace("ENTITY='ui_reply_delivery_v1'","ENTITY='ui_reply_delivery_v1'\nCUSTOMER_GUARD='ui_customer_reply_guard_v1'")
    t=t.replace('try:return super().process(ident)','try:return self._process_guarded(ident)')
    t=t.replace('\n\nclass ReplyDelivery:', '\n\n'+method+'\n\nclass ReplyDelivery:')
    t=t.replace('        original=core.adapters.platform_guard', '''        send=core._send_reply
        def customer_guarded(data,user,tenant,reply,lead,mode_owner=None):
            claim,reason=self._customer_claim(tenant,lead,reply,data.get('account_id'))
            if reason:return {'status':'skipped','last_error':reason}
            try:return send(data,user,tenant,reply,lead,mode_owner=mode_owner)
            finally:self._finish_claim(claim)
        core._send_reply=customer_guarded
        original=core.adapters.platform_guard''')
    t=t.replace('    def validation(self,reply_id,expected):',guard+'    def validation(self,reply_id,expected):')
    t=t.replace("'status':reply.get('status'),'message':str(reply.get('last_error') or ''),", "'status':'skipped' if row['replyId'] in queue.get('skipped_reasons',{}) else reply.get('status'),\n                'message':queue.get('skipped_reasons',{}).get(row['replyId'],str(reply.get('last_error') or '')),")
    t=t.replace("'processed':queue.get('processed',0),'sent':queue.get('sent',0),", "'processed':queue.get('processed',0),'sent':queue.get('sent',0),'skipped':queue.get('skipped',0),")
    return t
edit('work/ui-native-r57/reply_delivery.py',delivery)
