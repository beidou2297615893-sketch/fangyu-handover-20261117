import unittest, tempfile, json, sqlite3
from pathlib import Path
from unittest.mock import patch
import current_collection as c
import new_round as n
import subprocess
from types import SimpleNamespace

class Recovery(unittest.TestCase):
    def test_remaining_scope_preserves_unknown_and_excludes_attempted_targets(self):
        with tempfile.TemporaryDirectory() as t:
            r=Path(t); (r/'old').mkdir()
            record=r/'old'/'pending.json'
            record.write_text(json.dumps({'state':'prepared_not_dispatched','response':None,'spec':{'request_id':'r','kind':'comments','target':'123','keyword':'old','account_uid':'A','connection_id':'old','scan_id':'s'}}))
            control={'pending':{'request_id':'r','record_path':str(record),'phase':'dispatching'}}
            (r/'old'/'control.json').write_text(json.dumps(control))
            (r/'plan.json').write_text(json.dumps({'account_uid':'A','connection_id':'old','scan_id':'s'}))
            active={'directory':'old','plan':'plan.json'}
            db=sqlite3.connect(r/'db'); db.execute('create table attempts(spec text)'); db.execute('insert into attempts values(?)',(json.dumps({'kind':'search','target':'done','account_uid':'A'}),));db.commit();db.close()
            before=record.read_bytes()
            cfg={'stores':[{'keywords':['old','done','fresh']}], 'collection_accounts':['A']}
            result=c.remaining_config(r,r/'db',active,cfg)
            self.assertEqual(result['stores'][0]['keywords'],['fresh'])
            self.assertIn('123',result['excluded_historical_videos'])
            self.assertEqual(before,record.read_bytes())
    def test_current_account_discovery_happens_in_new_round_not_old_identity(self):
        with patch.object(c,'send_busy',return_value=True):
            self.assertIn('发送',c.start())
    def test_captcha_does_not_dispatch_until_probe_passes(self):
        self.assertEqual(c.probe_decision(False), 'waiting_for_page')
        self.assertEqual(c.probe_decision(True), 'ready')

    def test_new_scope_uses_current_B_instead_of_saved_A_and_validates_before_dispatch(self):
        with tempfile.TemporaryDirectory() as t:
            r=Path(t);db=sqlite3.connect(r/'db')
            db.executescript('create table collection_halt_events(account_uid,request_id); create table account_halts(account_uid,request_id);create table attempts(spec,state,collected_at);');db.close()
            (r/'active-runner.json').write_text(json.dumps({'account_nickname':'A','directory':'old','plan':'old.json'}))
            cfg={'stores':[{'keywords':['fresh']}],'collection_accounts':['A']}
            calls=[]
            def run(args,**kw):
                calls.append(args)
                if 'collection_identity_check.cjs' in args:
                    p=json.loads((r/args[2]).read_text(encoding='utf-8'))
                    self.assertEqual(p['account_uid'],'B');self.assertEqual(p['connection_id'],'new')
                    return SimpleNamespace(returncode=0,stdout='{"connection_id":"new","account":{"sec_uid":"B"}}')
                if '--max-pages' in args:
                    kw['stdout'].write(b'{"state":"bounded_batch_complete"}\n')
                    return SimpleNamespace(returncode=0)
                return SimpleNamespace(returncode=0,stdout='collection_progress_window')
            who={'strict':True,'conns':[{'ok':True,'id':'new','connection':'new','last':'now','v':{'s':0,'u':'B','n':'B'}}]}
            # Load the production writer via a stub, avoiding any platform/ledger dependency.
            import sys
            writer=SimpleNamespace(write_active=lambda p,v:p.write_text(json.dumps(v),encoding='utf-8'))
            with patch.dict(sys.modules,{'continue_collection':writer}),patch.object(n,'ROOT',r),patch.object(n,'DB',r/'db'),patch.object(n,'who',return_value=who),patch.object(n,'running',return_value=False),patch.object(n,'effective_halt',return_value=None),patch.object(n.subprocess,'run',side_effect=run),patch.object(n.subprocess,'Popen',return_value=SimpleNamespace(pid=123,poll=lambda:None)),patch.object(n.time,'sleep'):
                self.assertEqual(n._main(config_override=cfg),0)
            self.assertTrue(any('collection_identity_check.cjs' in a for a in calls))
            self.assertEqual(json.loads((r/'active-runner.json').read_text())['account_nickname'],'B')

    def test_failed_identity_or_captcha_never_starts_runner(self):
        with tempfile.TemporaryDirectory() as t:
            r=Path(t);db=sqlite3.connect(r/'db');db.executescript('create table collection_halt_events(account_uid,request_id);create table account_halts(account_uid,request_id);create table attempts(spec,state,collected_at);');db.close()
            (r/'active-runner.json').write_text('{}')
            who={'strict':True,'conns':[{'ok':True,'id':'new','connection':'new','last':'now','v':{'s':0,'u':'B','n':'B'}}]}
            with patch.object(n,'ROOT',r),patch.object(n,'DB',r/'db'),patch.object(n,'who',return_value=who),patch.object(n,'running',return_value=False),patch.object(n,'effective_halt',return_value=None),patch.object(n.subprocess,'run',return_value=SimpleNamespace(returncode=1,stdout='',stderr='{"challenge_visible":true}')),patch.object(n.subprocess,'Popen') as spawn:
                self.assertEqual(n._main(config_override={'stores':[{'keywords':['fresh']}]}),1)
                spawn.assert_not_called()

if __name__=='__main__':unittest.main()
