"""Narrow collection-only recovery after explicit human verification confirmation."""
import hashlib
import json
import sqlite3
from contextlib import closing
from datetime import datetime
from pathlib import Path

from scoped_recovery import effective_halt, verification_resume_evidence


def prepare_orphaned_scope(database, plan, directory, control, new_scope, authorization, identity_file):
    """Explicit user skip of a crashed dispatch with no response, never a replay.

    Caller has freshly verified the strict pinned identity and holds the startup
    mutex. The old control and raw record stay byte-for-byte unchanged. No
    platform response, success, failure, or source attempt is manufactured.
    """
    directory = Path(directory).resolve()
    pending = control.get('pending') or {}
    record_path = Path(pending.get('record_path', '')).resolve()
    if (pending.get('phase') != 'dispatching' or not authorization or not identity_file
            or not new_scope or new_scope == plan['scan_id'] or not record_path.is_relative_to(directory)):
        raise ValueError('orphan dispatch evidence does not match')
    original_control = (directory / 'control.json').read_bytes()
    original_record = record_path.read_bytes()
    if json.loads(original_control.decode('utf-8-sig')) != control:
        raise ValueError('control changed during review')
    record = json.loads(original_record.decode('utf-8-sig'))
    spec = record.get('spec') or {}
    if (record.get('response') is not None or record.get('state') not in ('prepared_not_dispatched', 'dispatching')
            or not pending.get('request_id') or spec.get('request_id') != pending['request_id']
            or any(spec.get(field) != plan[field] for field in ('account_uid','connection_id','scan_id'))
            or spec.get('kind') not in ('search','comments') or not isinstance(spec.get('target'), str)
            or not spec['target'] or not isinstance(spec.get('keyword'), str) or not spec['keyword']):
        raise ValueError('orphan dispatch has mismatched or already saved evidence')
    words = set(plan.get('deferred_previous_account_searches', [])) | {spec['keyword']}
    videos = set(plan.get('excluded_historical_videos', []))
    if spec['kind'] == 'search':
        words.add(spec['target'])
    else:
        videos.add(spec['target'])
    uid, old_scope = plan['account_uid'], plan['scan_id']
    with closing(sqlite3.connect(database, timeout=10)) as db, db:
        db.row_factory = sqlite3.Row
        db.execute('BEGIN IMMEDIATE')
        if effective_halt(db, uid, old_scope):
            raise ValueError('effective halt still requires separate exact review')
        for row in db.execute('SELECT spec FROM attempts'):
            prior = json.loads(row[0])
            if prior.get('kind') == 'search':
                words.add(prior['target'])
            elif prior.get('kind') == 'comments':
                videos.add(prior['target'])
        stores = [dict(store, keywords=[word for word in store['keywords'] if word not in words])
                  for store in plan['stores']]
        if not all(store['keywords'] for store in stores):
            raise ValueError('a store has no untried search terms')
        # Carry only reviews which were already valid for this same pinned account.
        db.execute('''INSERT INTO collection_scope_reviews
                      SELECT account_uid,?,reviewed_request_id,allowed_keywords,excluded_videos,authorization,reviewed_at
                      FROM collection_scope_reviews WHERE account_uid=? AND scan_id=?''', (new_scope,uid,old_scope))
        db.execute('''UPDATE collection_scope_reviews SET allowed_keywords=?,excluded_videos=?
                      WHERE account_uid=? AND scan_id=?''',
                   (json.dumps(sorted({word for store in stores for word in store['keywords']})),
                    json.dumps(sorted(videos)),uid,new_scope))
        db.execute('''INSERT INTO collection_event_reviews
                      SELECT account_uid,?,request_id,response_sha256,authorization,evidence,reviewed_at
                      FROM collection_event_reviews WHERE account_uid=? AND scan_id=?''', (new_scope,uid,old_scope))
        if effective_halt(db, uid, new_scope):
            raise ValueError('an effective halt remains in the new scope')
        if ((directory/'control.json').read_bytes() != original_control or record_path.read_bytes() != original_record):
            raise ValueError('orphan evidence changed during review')
    updated = dict(plan, scan_id=new_scope, stores=stores, recovery_from_scan=old_scope,
                   deferred_previous_account_searches=sorted(words), excluded_historical_videos=sorted(videos))
    evidence = dict(unknown_request=pending['request_id'], original_phase='dispatching',
                    old_scope=old_scope,new_scope=new_scope,excluded_keyword=spec['keyword'],excluded_target=spec['target'],
                    original_control=str(directory/'control.json'),original_record=str(record_path),
                    control_sha256=hashlib.sha256(original_control).hexdigest(),record_sha256=hashlib.sha256(original_record).hexdigest(),
                    authorization=authorization,identity_evidence=identity_file,network_started=False,
                    original_result='unknown_no_response_saved',original_evidence_unchanged=True)
    return updated,evidence


def confirmable(attempt):
    if not attempt or attempt['added'] != 0:
        return False
    return verification_resume_evidence(attempt['state'], json.loads(attempt['response']))


def prepare_scope(database, plan, confirmed_id, new_scope, authorization, identity_file):
    uid, old_scope = plan['account_uid'], plan['scan_id']
    words = set(plan.get('deferred_previous_account_searches', []))
    videos = set(plan.get('excluded_historical_videos', []))
    with closing(sqlite3.connect(database, timeout=10)) as db, db:
        db.row_factory = sqlite3.Row
        db.execute('BEGIN IMMEDIATE')
        halt = effective_halt(db, uid, old_scope)
        if not halt or halt['request_id'] != confirmed_id:
            raise ValueError('confirmed event no longer matches the current stop')
        attempt = db.execute('SELECT * FROM attempts WHERE request_id=?', (confirmed_id,)).fetchone()
        if not confirmable(attempt):
            raise ValueError('this halt does not allow human verification continuation')
        spec = json.loads(attempt['spec'])
        if spec['account_uid'] != uid or spec['scan_id'] != old_scope:
            raise ValueError('confirmation does not match the active account and scope')
        for row in db.execute('SELECT spec FROM attempts'):
            prior = json.loads(row[0])
            if prior['kind'] == 'search':
                words.add(prior['target'])
            elif prior['kind'] == 'comments':
                videos.add(prior['target'])
        words.add(spec['keyword'])
        stores = [dict(store, keywords=[word for word in store['keywords'] if word not in words])
                  for store in plan['stores']]
        if not all(store['keywords'] for store in stores):
            raise ValueError('a store has no untried search terms')
        allowed = sorted({word for store in stores for word in store['keywords']})
        old_review = db.execute('SELECT * FROM collection_scope_reviews WHERE account_uid=? AND scan_id=?',
                                (uid, old_scope)).fetchone()
        now = datetime.now().astimezone().isoformat()
        inherited = old_review['reviewed_request_id'] if old_review else confirmed_id
        db.execute('INSERT INTO collection_scope_reviews VALUES(?,?,?,?,?,?,?)',
                   (uid, new_scope, inherited, json.dumps(allowed), json.dumps(sorted(videos)), authorization, now))
        db.execute('''INSERT INTO collection_event_reviews
                      SELECT account_uid,?,request_id,response_sha256,authorization,evidence,reviewed_at
                      FROM collection_event_reviews WHERE account_uid=? AND scan_id=?''', (new_scope, uid, old_scope))
        digest = hashlib.sha256(attempt['response'].encode()).hexdigest()
        db.execute('INSERT INTO collection_event_reviews VALUES(?,?,?,?,?,?,?)',
                   (uid, new_scope, confirmed_id, digest, authorization, identity_file, now))
        if effective_halt(db, uid, new_scope):
            raise ValueError('an effective halt remains in the new scope')
    updated = dict(plan, scan_id=new_scope, stores=stores, recovery_from_scan=old_scope,
                   deferred_previous_account_searches=sorted(words), excluded_historical_videos=sorted(videos))
    evidence = dict(request_id=confirmed_id, original_state=attempt['state'], response_sha256=digest,
                    old_scope=old_scope, new_scope=new_scope, excluded_target=spec['target'],
                    excluded_keyword=spec['keyword'], authorization=authorization, identity_evidence=identity_file)
    return updated, evidence
