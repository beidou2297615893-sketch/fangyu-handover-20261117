from test_session_handoff import *
tree=ast.parse(runtime_path.read_text('utf-8'));names={'open_account_verification','_verification_windows','_verification_idle'}
methods=[copy.deepcopy(n) for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name in names]
space={'threading':threading,'json':json,'hashlib':hashlib,'os':os,'PlatformRuntimeError':RuntimeErrorType}
exec(compile(ast.fix_missing_locations(ast.Module(body=[ast.ClassDef(name='OwnedWindow',bases=[],keywords=[],body=methods,decorator_list=[])],type_ignores=[])),str(runtime_path),'exec'),space)
class AdoptionTests(HandoffTests):
 def test_completed_owned_login_window_can_be_used_without_closing(self):
  user,server,service=self.environment();runtime=space['OwnedWindow']()
  runtime.server=server;runtime.core=server.core;runtime.data_dir=self.root;runtime._run_lock=threading.RLock()
  runtime._principal=lambda u:u;runtime._executor=lambda u:service
  runtime._account=lambda u,i:self.store.get('accounts',i)
  runtime._readiness=lambda *a:('','');runtime._task_active=lambda t:False;runtime.snapshot=lambda u:{}
  (self.home/'xhs-browser-profile').mkdir()
  self.job.update(purpose='login',persistent_browser=True,status='completed',phase='completed')
  result=runtime.open_account_verification(user,{'accountId':self.account['id']})
  self.assertEqual(result['result']['status'],'verification_open')
  self.assertEqual(self.job['purpose'],'manual_verification');self.assertEqual(self.job['status'],'running')
  self.assertTrue((self.stage/'focus.flag').exists());self.assertEqual(len(server.jobs),1)
if __name__=='__main__':
 suite=unittest.TestSuite([AdoptionTests('test_completed_owned_login_window_can_be_used_without_closing')])
 result=unittest.TextTestRunner(verbosity=2).run(suite);raise SystemExit(not result.wasSuccessful())
