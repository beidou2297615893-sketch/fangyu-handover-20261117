@echo off
cd /d "%~dp0..\.."
start "" "C:\Users\rmsama\miniconda3\pythonw.exe" "%~dp0panel.py"
