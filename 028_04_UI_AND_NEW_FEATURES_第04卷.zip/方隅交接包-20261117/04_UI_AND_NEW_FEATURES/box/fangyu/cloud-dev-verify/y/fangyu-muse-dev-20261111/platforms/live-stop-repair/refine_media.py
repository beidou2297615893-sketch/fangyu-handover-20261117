from pathlib import Path
import hashlib,json
S=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project')
T=Path(__file__).resolve().parent
p=S/'work/ui-native-r57/workbench_backend.py';s=p.read_text('utf-8')
needle='\n\ndef _digest(value):'
assert s.count(needle)==1
s=s.replace(needle,'''

class _MediaReadIntegrations(_ReadOnlyDeliveryIntegrations):
    """Fresh media-only authority, for both existing employee/admin roles.

    Never refresh credentials or rewrite local user/role state in background.
    A role change fails closed and is reconciled by the foreground path.
    """
    def verify_identity(self,user,expected_user=None):
        expected=expected_user or user
        try:
            profile=self._cloud(self._read(user['tenant_id']),user,'me')['user']
            current=self.core.store.get('users',user['id'])
            if (not current or current.get('disabled') or profile.get('disabled')
                    or current.get('cloud_bound') is not True
                    or current.get('role') not in ('operator','admin')
                    or any(current.get(key)!=expected.get(key) for key in
                        ('id','tenant_id','username','role','cloud_bound'))
                    or profile.get('username')!=current.get('username')
                    or profile.get('role')!=current.get('role')):
                return None
            return self.core._public(current)
        except (IntegrationError,KeyError,TypeError):
            return None
'''+needle)
s=s.replace('verification=_ReadOnlyDeliveryIntegrations(self.core))','verification=_MediaReadIntegrations(self.core))')
compile(s,str(p),'exec');p.write_text(s,encoding='utf-8')
rows=json.loads((T/'SOURCE-CHANGES.json').read_text('utf-8'))
for row in rows:
    if row['path']==p.relative_to(S).as_posix():row['after']=hashlib.sha256(p.read_bytes()).hexdigest()
(T/'SOURCE-CHANGES.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
print('media verifier supports existing operator and admin, zero role/session writes')
