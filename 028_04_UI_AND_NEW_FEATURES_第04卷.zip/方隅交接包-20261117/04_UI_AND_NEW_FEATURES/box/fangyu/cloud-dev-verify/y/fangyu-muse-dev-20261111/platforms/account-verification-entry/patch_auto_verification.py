from pathlib import Path
import hashlib,json,re
T=Path(__file__).resolve().parent
S=Path('C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project')
changed=[]
def edit(rel,fn):
 p=S/rel;old=p.read_bytes();new=fn(old.decode('utf-8')).encode('utf-8')
 assert new!=old,rel
 backup=T/'auto-before'/rel;backup.parent.mkdir(parents=True,exist_ok=True)
 with backup.open('xb') as f:f.write(old)
 p.write_bytes(new);changed.append({'path':rel,'before':hashlib.sha256(old).hexdigest(),'after':hashlib.sha256(new).hexdigest()})
def once(s,a,b):
 assert s.count(a)==1,(a[:90],s.count(a));return s.replace(a,b)

tracker=r'''
class VerificationTransition:
    """An untrusted readiness hint, never authority to mark an account ready.

    A CAPTCHA pause needs a visible challenge transition or fresh human
    activity. Merely seeing a logged-in homepage cannot trigger retry loops.
    """
    def __init__(self, reason):
        self.reason=reason;self.challenge_seen=False;self.guest_seen=False
        self.baseline=None;self.clear_since=None;self.consumed=False

    def update(self, now, value):
        if self.consumed or type(value) is not dict:return False
        if any(type(value.get(k)) is not bool for k in ('logged','challenged','guest')):return False
        activity=value.get('activity')
        if type(activity) is not int or not 0<=activity<=1000000:return False
        if self.baseline is None:self.baseline=activity
        self.challenge_seen|=value['challenged'];self.guest_seen|=value['guest']
        changed=(self.reason=='authentication_required' or self.challenge_seen
            or self.guest_seen or activity>self.baseline)
        if not value['logged'] or value['challenged'] or not changed:
            self.clear_since=None;return False
        if self.clear_since is None:self.clear_since=now
        if now-self.clear_since<3:return False
        self.consumed=True;return True


VERIFICATION_OBSERVATION_JS = r"""(() => {
  if(location.origin!=='https://www.xiaohongshu.com')return null;
  const key='__fangyuHumanVerificationActivityV1';
  if(!window[key]){
    window[key]={activity:0};
    for(const name of ['pointerup','keydown'])document.addEventListener(name,event=>{
      if(event.isTrusted&&window[key])window[key].activity=Math.min(1000000,window[key].activity+1);
    },true);
  }
  const visible=node=>{const r=node.getBoundingClientRect(),s=getComputedStyle(node);
    return r.width>0&&r.height>0&&s.display!=='none'&&s.visibility!=='hidden'&&Number(s.opacity)>0;};
  const challenged=location.pathname.startsWith('/website-login/captcha')||
    Array.from(document.querySelectorAll('.security-container,.risk-control,.verify-container,.captcha-container,#captcha,iframe[src*="captcha"]')).some(visible);
  const logged=Array.from(document.querySelectorAll('a[href]')).some(link=>{
    if(!visible(link)||!['我','我的','我的主页','个人主页'].includes((link.innerText||link.getAttribute('aria-label')||'').replace(/\s+/g,'')))return false;
    const u=new URL(link.getAttribute('href'),location.href);
    return u.origin===location.origin&&/^\/user\/profile\/[A-Za-z0-9]{8,64}\/?$/.test(u.pathname);
  });
  const guest=!logged&&Array.from(document.querySelectorAll('button,#login-btn,[class*="login-btn"]')).some(node=>visible(node)&&/^(登录|登录后查看|立即登录)/.test((node.innerText||'').trim()));
  return {logged,challenged,guest,activity:window[key].activity};
})()"""

'''
def helper(s):
 s=once(s,'import tempfile\n','import tempfile\nimport time\n')
 s=once(s,'class PersistentLoginWindowController(LoginWindowController):',tracker+'class PersistentLoginWindowController(LoginWindowController):')
 s=once(s,'        self._last_observation = None\n','        self._last_observation = None\n        self.verification_request = None\n        self.verification_transition = None\n')
 marker='    def watch_requests(self):\n        while not self.finished.wait(.2):'
 i=s.index(marker,s.index('class PersistentLoginWindowController'))
 method=r'''    def watch_verification(self):
        """Observe a human-owned page; no clicks, answers, fetches or API polling."""
        request=self.staging_root/'verification-watch.json'
        try:
            if request.is_symlink() or request.stat().st_size>12288:return
            value=json.loads(request.read_text('utf-8'))
            if (type(value) is not dict or set(value)!={'version','request','reason','url'}
                    or value['version']!=1 or not re.fullmatch(r'[a-f0-9]{32}',str(value['request']))
                    or value['reason'] not in ('authentication_required','verification_required')
                    or type(value['url']) is not str or len(value['url'])>8192):return
            target=urlsplit(value['url'])
            if (not _is_xhs_origin(value['url']) or target.fragment
                    or not re.fullmatch(r'/explore(?:/[A-Za-z0-9]{1,160})?/?',target.path)):return
            if self.window is None or not _is_xhs_origin(self.window.get_current_url()):return
            sample=self.window.evaluate_js(VERIFICATION_OBSERVATION_JS)
            if value['request']!=self.verification_request:
                self.verification_request=value['request']
                self.verification_transition=VerificationTransition(value['reason'])
                self._title('请完成此页面的验证；通过后工作台会自动继续采集')
                # Show the affected note once, without disturbing a challenge
                # already being completed by the human in this same window.
                if (value['reason']=='verification_required' and type(sample) is dict
                        and sample.get('challenged') is False
                        and self.window.get_current_url()!=value['url']):
                    self.window.load_url(value['url']);return
            if not self.verification_transition.update(time.monotonic(),sample):return
            ready=self.staging_root/('verification-ready-'+value['request']+'.json')
            body={'version':1,'request':value['request'],'state':'ready'}
            with ready.open('x',encoding='ascii') as stream:json.dump(body,stream)
        except (OSError,ValueError,TypeError,Exception):
            # DOM/navigation readiness is not authentication; parent checks
            # status, same UID, account claim and commit after one hint only.
            return

'''
 s=s[:i]+method+s[i:]
 s=once(s,'            if self.attempt <= self.result_consumed:\n','            self.watch_verification()\n            if self.attempt <= self.result_consumed:\n')
 return s
edit('work/shared-backend-integration/vendor-src/assistant/browser_login_window.py',helper)

def backend(s):
 s=once(s,'        self._douyin_observations = {}\n','        self._douyin_observations = {}\n        self._verification_waits = {}\n')
 s=once(s,"                'platformError':self._collection_platform_error(task),", "                'platformError':self._collection_platform_error(task),\n                'verificationId':receipt.get('attempt_id','') if receipt else '',\n                'verification':self._verification_state(user,task),")
 methods=r'''    def _verification_state(self,user,task):
        wait=getattr(self,'_verification_waits',{}).get(task['id']) if task else None
        if not wait or wait['owner']!=(user['tenant_id'],user['username']):return {}
        if wait['binding']!=self._collection_binding(task):return {}
        return {'state':wait.get('state','waiting_user'),'message':wait.get('message','')}

    def _watch_acquisition_verification(self,user,task,account):
        """One passive readiness wait per exact failed receipt and owned window."""
        from core.xhs_verified_resume import failed_page
        from assistant.browser_login_service import _staging_scope
        directory=self.data_dir/'accounts'/user['tenant_id']/account['id']
        context=failed_page(directory,task['id'],self._verified_scope(user,task,account))
        if context is None:return
        windows=self._verification_windows(user,account)
        if len(windows)!=1:return
        job=windows[0];stage=directory/'work/browser-login'/job['id']
        if not _staging_scope(self.data_dir,directory,stage):return
        with self._run_lock:
            waits=self._verification_waits
            prior=waits.get(task['id'])
            if (prior and prior['receipt']==context['receipt_sha256']
                    and prior.get('thread') and prior['thread'].is_alive()):return
            if prior:prior['cancel'].set()
            wait={'owner':(user['tenant_id'],user['username']),'binding':self._collection_binding(task),
                'receipt':context['receipt_sha256'],'request':uuid4().hex,'cancel':threading.Event(),
                'state':'waiting_user','message':'已打开原账号页面，等待本人完成验证；通过后自动继续采集。'}
            waits[task['id']]=wait
        raw=json.loads((directory/'.workbench-page-receipts'/task['id']/(context['page']+'.json')).read_text('utf-8'))
        payload=json.loads(raw['result']['stdout'])
        reason='authentication_required' if payload['error']['code']=='not_authenticated' else 'verification_required'
        target='https://www.xiaohongshu.com/explore'
        pipeline=task.get('pipeline') or {};notes=pipeline.get('notes');index=pipeline.get('note_index')
        if reason=='verification_required' and type(notes) is list and type(index) is int and 0<=index<len(notes):
            from assistant.xhs_cli_page_worker import validate_args
            candidate=notes[index].get('url') if type(notes[index]) is dict else None
            try:
                validate_args(['comments',candidate,'--json'])
                from urllib.parse import urlsplit
                parsed=urlsplit(candidate)
                if parsed.hostname=='www.xiaohongshu.com' and parsed.path.startswith('/explore/'):target=candidate
            except (ValueError,TypeError):pass
        def worker():
            try:
                deadline=time.monotonic()+15
                while time.monotonic()<deadline and not wait['cancel'].is_set() and not self.closed:
                    windows=self._verification_windows(user,account)
                    if (len(windows)==1 and windows[0]['id']==job['id'] and windows[0].get('window_open')
                            and windows[0].get('identity_capture_capable') and stage.is_dir()):break
                    wait['cancel'].wait(.2)
                else:raise ValueError('window_not_ready')
                request=stage/'verification-watch.json'
                if request.is_symlink():raise ValueError('verification_scope_changed')
                temporary=stage/('verification-watch-'+wait['request']+'.tmp')
                with temporary.open('x',encoding='utf-8') as stream:
                    json.dump({'version':1,'request':wait['request'],'reason':reason,'url':target},stream)
                os.replace(temporary,request)
                ready=stage/('verification-ready-'+wait['request']+'.json')
                while not wait['cancel'].wait(.5) and not self.closed:
                    actor,fresh,current=self._verification_task(user,{'taskId':task['id']})
                    if (self._collection_binding(fresh)!=wait['binding']
                            or self._verified_scope(actor,fresh,current)!=context['scope']):return
                    active=self._verification_windows(actor,current)
                    if not active or active[0]['id']!=job['id']:raise ValueError('window_closed')
                    if not ready.exists():continue
                    if ready.is_symlink() or ready.stat().st_size>512:raise ValueError('readiness_invalid')
                    observed=json.loads(ready.read_text('ascii'))
                    if observed!={'version':1,'request':wait['request'],'state':'ready'}:raise ValueError('readiness_invalid')
                    latest=failed_page(directory,task['id'],self._verified_scope(actor,fresh,current))
                    if latest!=context:raise ValueError('receipt_changed')
                    ready.unlink();wait.update(state='checking',message='网页验证状态已变化，正在核对账号并继续原任务…')
                    self.resume_verified_acquisition(actor,{'taskId':task['id']})
                    wait.update(state='resumed',message='验证已通过，原任务已继续。')
                    return
                wait.update(state='cancelled',message='验证等待已停止，原断点保留。')
            except Exception:
                wait.update(state='waiting_user',message='本次验证尚未核实，请在原网页完成验证；可用继续按钮手动核对一次。')
        thread=threading.Thread(target=worker,name='human-verification-'+task['id'],daemon=True)
        wait['thread']=thread;thread.start()

'''
 s=once(s,'    def open_acquisition_verification(self,user,data):',methods+'    def open_acquisition_verification(self,user,data):')
 s=once(s,"        result['result'].update(taskId=task['id'],accountId=account['id'])\n        return result", "        self._watch_acquisition_verification(user,task,account)\n        result['result'].update(taskId=task['id'],accountId=account['id'])\n        return result")
 # Internal resume reopens without arming a competing automatic continuation.
 s=once(s,'                self.open_acquisition_verification(user,data)\n',"                self.open_account_verification(user,{'accountId':account['id']})\n")
 s=once(s,"            executor._explicit_task_ids.add(ident)\n", "            for wait in self._verification_waits.values():wait['cancel'].set()\n            executor._explicit_task_ids.add(ident)\n")
 s=once(s,"            control=self._run_cancels.get(data['taskId'])\n", "            wait=self._verification_waits.get(data['taskId'])\n            if wait:wait['cancel'].set()\n            control=self._run_cancels.get(data['taskId'])\n")
 helper_sha=hashlib.sha256((S/'work/shared-backend-integration/vendor-src/assistant/browser_login_window.py').read_bytes()).hexdigest().upper()
 s,n=re.subn(r"_BROWSER_LOGIN_HELPER_SHA = '[A-F0-9]{64}'",f"_BROWSER_LOGIN_HELPER_SHA = '{helper_sha}'",s);assert n==1
 return s
edit('work/shared-backend-integration/platform_runtime.py',backend)

def receipts(s):
 return once(s,"        if not verification_receipt(value) or 'verified_retry' in value:continue", "        # A newly completed human verification may authorize one attempt for\n        # this new, known CAPTCHA receipt, including a prior verified attempt.\n        # Its exact bytes and a fresh commit still gate each retry; unknowns\n        # never qualify and one proof cannot authorize two wire attempts.\n        if not verification_receipt(value):continue")
edit('work/ui-runtime-r55/src/core/xhs_verified_resume.py',receipts)
(T/'AUTO-CHANGES.json').write_text(json.dumps(changed,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'changed_files':len(changed)}))
