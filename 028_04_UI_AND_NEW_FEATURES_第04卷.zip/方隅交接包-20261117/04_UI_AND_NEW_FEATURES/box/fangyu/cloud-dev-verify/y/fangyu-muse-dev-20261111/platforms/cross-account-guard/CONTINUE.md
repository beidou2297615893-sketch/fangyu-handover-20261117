# 当前交付：v27，等待用户正常重开并亲测

用户目标：补跨账号客户级防重复，修第二小红书账号新增/连接失败，最后调整验证入口及字体。用户自己测试，不使用 Computer Use，不执行真实采集/发送/登录或抖音 CLI。

已完成并更新原启动入口：ui-r57-20261019T155517Z-51391a86。入口 SHA256 66B44A13982830EC25C3E77CD6B3463BC50F27C396DE3400B3E070DC7B934DC6。入口 --check PASS（134 release files，0 native windows，未导入业务应用）。完整候选闭包2727文件验签；19个源文件有变更，见CHANGES.json。platform_runtime冻结副本与源文件字节相同。原工作区绑定hash不变。v26备份保留在 final-integration/entry-v27/canonical-entry-before。

新增账号根因：account_create成功持久化了无status的新账号，snapshot通过account_view(connected)['status']抛KeyError，网关显示“平台操作未取得确认”。现在新增默认login_required；旧缺status记录也能投影，不修改真实记录/UID/凭据。真实已新增账号“2”保留，可直接点它连接，无需重复新建。登录任务返回accountId，继续登录固定原账号条目；identity_mismatch给明确说明，仍禁止覆盖原账号绑定。

防重复：reply_delivery新增SQLite持久客户保留，tenant+platform+author_id作为键，BEGIN IMMEDIATE原子竞争，成功/在途/未知/进程中断均阻止其他账号发送同客户；确定CLI未启动的拒绝才释放。读取旧replies+leads历史。队列在客户冲突时计skipped并继续下一位；原草稿不伪装sent，成功数不含跳过。保留旧权限、快照、账号租约、最终Popen检查、取消及unknown不重试。没有稳定客户平台身份时阻止发送。软件外手动回复无法自动识别。不同平台是不同身份范围。

界面：验证按钮与说明并排左对齐，取消说明卡片；全界面显式字号约加2px，平台切换及标志放大；发送状态以中文显示成功和跳过数；说明增加跨账号防重边界。

验证：test_guard.py共24项通过（9新行为+15原队列回归）。原队列多条测试fixture改为不同客户；新行为单独验证同客户跨账号跳过与并发竞争。localhost HTTP项受沙箱10013阻止，单独提升后通过；未访问真实平台。全JS模块node --check通过，旧日历及验证码提示回归通过。UI字体未做视觉验收，真实抖音CLI未测试。

安装完成时active.json仍为v26进程60172；没有关闭/重开用户软件或影响当前任务。新版本须用户正常关闭工作台后重开。用户已说原小红书账号人脸解除限制，不能继续把旧“永久冻结”当成当前事实；也不能自动续采/发送。用户下一步自行测试账号“2”、跨账号回复及抖音连接。
