'use strict';

// Only examine the fixed page's visible verification UI, never comment text or credentials.
function visiblePageGate() {
 if (/^\/ucenter\/security(?:\/|$)/i.test(location.pathname)) return 'captcha';
 const visible = element => {
  const style = getComputedStyle(element);
  const rect = element.getBoundingClientRect();
  return style.display !== 'none' && style.visibility !== 'hidden' && style.opacity !== '0'
      && rect.width > 0 && rect.height > 0;
 };
 const widgets = document.querySelectorAll('iframe[src*="rmc.bytedance.com"],iframe[src*="captcha"],iframe[src*="verifycenter"],#captcha_container,#verify-center,[id^="captcha-verify"]');
 if (Array.from(widgets).some(visible)) return 'captcha';
 for (const box of document.querySelectorAll('[role="dialog"],[role="alert"],[role="status"],[class*="toast"],[class*="Toast"]')) {
  if (!visible(box)) continue;
  const message=(box.innerText || '').trim();
  if (/操作(过于|太)?频繁|请求(过于|太)?频繁|访问(过于|太)?频繁|too many requests/i.test(message)) return 'rate_limit';
  if (/请.{0,8}完成.{0,6}验证|拖动滑块|安全验证|captcha required/i.test(message)) return 'captcha';
 }
 return 'ready';
}
async function assertPageReady(client, connId) {
 if (!connId) throw Error('CURRENT_GATE:page_unresponsive');
 let response;
 try {
  response = await client.call({site:'douyin.com',connId,timeout:10000,expression:'('+visiblePageGate.toString()+')()'});
 } catch(error) {
  throw Error('CURRENT_GATE:'+(explicitGate(error)||'page_unresponsive'));
 }
 if (response?.connection && response.connection !== connId) throw Error('CURRENT_GATE:identity');
 if (response?.ok && response.connection !== connId) throw Error('CURRENT_GATE:identity');
 const explicit=explicitGate(response);
 if(explicit)throw Error('CURRENT_GATE:'+explicit);
 if (!response || !response.ok) throw Error('CURRENT_GATE:page_unresponsive');
 if (response.value === 'captcha' || response.value === 'rate_limit') throw Error('CURRENT_GATE:'+response.value);
 if (response.value !== 'ready') throw Error('CURRENT_GATE:page_unresponsive');
}
function responseGate(raw) {
 if (!raw) return '';
 const message=String(raw.status_msg || raw.message || '');
 if (Number(raw.status_code)===429 || Number(raw.http_status)===429 || /操作(过于|太)?频繁|请求(过于|太)?频繁|访问(过于|太)?频繁|too many requests/i.test(message)) return 'rate_limit';
 if (/请.{0,8}完成.{0,6}验证|需要安全验证|captcha required/i.test(message)) return 'captcha';
 return '';
}
function explicitGate(value){
 const text=String(value?.error || value?.message || '');
 const exact=text.match(/^CURRENT_GATE:(captcha|rate_limit|identity)$/);
 if(exact)return exact[1];
 if(/\bHTTP(?:\/\d(?:\.\d)?)?\s+429\b|too many requests|rate limit/i.test(text))return 'rate_limit';
 if(/请.{0,8}完成.{0,6}验证|需要安全验证|captcha required/i.test(text))return 'captcha';
 if(/account mismatch|identity changed|identity not verified|connection mismatch|账号不匹配|账号核对/i.test(text))return 'identity';
 return responseGate(value)||responseGate(value?.value);
}
function assertIdentityReply(response,connId,expectedUid,fields={code:'status_code',uid:'account_uid'}) {
 if (response?.connection && response.connection !== connId) throw Error('CURRENT_GATE:identity');
 const explicit=explicitGate(response);
 if(explicit)throw Error('CURRENT_GATE:'+explicit);
 if (!response?.ok) {
  const error=String(response?.error||'');
  if (/no polling client|request timeout|http request failed|ECONNREFUSED|ECONNRESET|no active douyin|fixed connection unavailable/i.test(error))
   throw Error('CURRENT_GATE:page_unresponsive');
  throw Error('CURRENT_GATE:identity');
 }
 if (response.connection !== connId) throw Error('CURRENT_GATE:identity');
 const value=response.value||{},gate=responseGate({...value,status_code:value[fields.code]});
 if(gate)throw Error('CURRENT_GATE:'+gate);
 if(value[fields.code]!==0 || !value[fields.uid] || (expectedUid && value[fields.uid]!==expectedUid))
  throw Error('CURRENT_GATE:identity');
 return value;
}
module.exports={assertPageReady,responseGate,assertIdentityReply};
