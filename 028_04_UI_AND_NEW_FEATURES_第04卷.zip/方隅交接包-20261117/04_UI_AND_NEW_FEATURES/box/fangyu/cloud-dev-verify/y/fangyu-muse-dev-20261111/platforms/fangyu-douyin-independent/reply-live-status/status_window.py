"""Native read-only status window; uses the same console renderer."""
import tkinter as tk
import datetime as dt
import json
import os
from pathlib import Path
import traceback
from tkinter import ttk
from watch_replies import snapshot

HERE = Path(__file__).resolve().parent
def lifecycle(state, error=None):
    value = {'process_id': os.getpid(), 'state': state, 'read_only': True,
             'checked_at': dt.datetime.now().astimezone().isoformat(),
             'note': 'This is display lifecycle only, not sending status.'}
    if error:
        value['error'] = error
    target = HERE / 'window-status.json'
    temp = target.with_suffix('.tmp')
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')
    os.replace(temp, target)

(HERE / 'window.pid').write_text(str(os.getpid()), encoding='utf-8')

app = tk.Tk()
app.title('方隅抖音回复实时状态 · 只读')
app.geometry('1100x780+60+60')
app.minsize(760, 500)
frame = ttk.Frame(app, padding=10)
frame.pack(fill='both', expand=True)
text = tk.Text(frame, wrap='word', font=('Microsoft YaHei UI', 11),
               background='#f7f9fc', foreground='#172334', padx=12, pady=12)
scroll = ttk.Scrollbar(frame, command=text.yview)
text.configure(yscrollcommand=scroll.set)
scroll.pack(side='right', fill='y')
text.pack(side='left', fill='both', expand=True)


def refresh():
    try:
        value = snapshot()
    except Exception:
        value = '账本暂时未读取成功，稍后自动刷新。\n本窗口不会影响发送任务。'
    position = text.yview()[0]
    text.configure(state='normal')
    text.delete('1.0', 'end')
    text.insert('1.0', value)
    text.configure(state='disabled')
    text.yview_moveto(position)
    lifecycle('running')
    app.after(3000, refresh)


def close():
    lifecycle('closed_via_window')
    app.destroy()

app.protocol('WM_DELETE_WINDOW', close)
try:
    refresh()
    app.mainloop()
except BaseException:
    lifecycle('display_error', traceback.format_exc())
    raise
