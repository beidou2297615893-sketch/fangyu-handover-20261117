from pathlib import Path
T=Path(__file__).resolve().parent
old=T.parent/'古北店规则接入'
body=(old/'prepare_install.py').read_text('utf-8')
for before,after in (
 ('candidate-unified-v47','candidate-unified-v48'),
 ('candidate-unified-v40','candidate-unified-v47'),
 ('67368098926387DD0D7ECDEDE9D192CFF7CD32C3EB4FBF53B695BADC80E4ABE8','21A9203A6C38FED5A4D1CB99DA9C4CB222A34C7A1D3BFE78376EA9FF7EC2AA35'),
 ('runtime-fixture-gubei-v47','runtime-fixture-device-v48'),
 ('gubei_existing_entry_builder','device_existing_entry_builder'),
 ('entry-v47','entry-v48'),
 ('Gubei-only; manual replies; 1-12 months grouped','customer-only device recovery; no task replay; four source files')):
 assert before in body,before
 body=body.replace(before,after)
# Scope assertions must compare actual previous v47 and new v48 snapshots.
assert "before=read(F/'candidate-unified-v47/INPUT-SNAPSHOT.json')" in body
with (T/'prepare_install.py').open('x',encoding='utf-8') as f:f.write(body)
body=(old/'install.py').read_text('utf-8').replace('gubei_existing_canonical_installer','device_existing_canonical_installer').replace('entry-v47','entry-v48').replace('candidate-unified-v47','candidate-unified-v48')
with (T/'install.py').open('x',encoding='utf-8') as f:f.write(body)
print('Prepared task-local adapters for the existing freezer/installer; not installed yet')
