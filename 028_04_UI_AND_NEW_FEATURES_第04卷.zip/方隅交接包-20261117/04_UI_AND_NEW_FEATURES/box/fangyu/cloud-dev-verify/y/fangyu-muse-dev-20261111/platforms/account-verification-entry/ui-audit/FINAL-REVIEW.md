# 原任务验证入口：UI 独立增量复核通过

本轮新增 24 项验证全部通过。直接导入当前实际 platform-notice.mjs 和 backend.mjs，用隔离 host、受控 Promise 和记录请求的 fetcher 测试。没有启动真实 UI、账号窗口，没有平台/模型调用或产品写入；旧 18 项未重跑。

“去验证”只发送原失败 taskId，忽略当前下拉框选择的另一账号；只触发打开请求，不串联续行。第二步“验证完成，继续原任务”也只在本人点击时发送原 taskId。实际 backend API 对应两个 POST action 为 acquisition_verification_open、acquisition_verification_resume，data 均严格为 `{taskId}`，未补当前账号、门店、平台或新任务条件。

已验证立即 pending 锁和双击防重、在打开未完成时点击继续不产生第二请求、busy/结果未确认时不提交、伪造 task/account/platform 提示拒绝执行；回执的 job 与 snapshot 必须同时匹配原 taskId、accountId、平台、员工和门店。认证 epoch、员工、门店、会话、连接或原 task/account 在等待时发生变化，旧回执不能写入新范围或触发成功通知。

验证操作只更新独立 banner。回复草稿对象、内容、dirty 状态、隔离 textarea 节点身份与选区保持；app 的实际新动作回调没有调用全页 render 或 runPlatformOperation。错误信息局部显示且转义，不自动重试，不自动登录、不发送、不新建采集。打开窗口回执只说明窗口正在打开，不宣称验证码已经通过。

审查中指出的两个问题已由根修正并纳入本次 24 项：抖音验证码提示使用通用账号页文案，不承诺不存在的小红书按钮；错误 task/account/platform 的 snapshot 不再仅跳过更新后仍报成功。当前 bytes 的源码 hash 在测试前后保持一致。

## 精确源码 SHA256

| ui-preview 下文件 | SHA256 |
| --- | --- |
| platform-notice.mjs | e204507246a0e5d18600a7fa969061dba8589d1377c091934ddb7b814fc15fd4 |
| app.mjs | 2bd5737152cd2625d3b048eb9c1f538d5380b80aec3b06127340a1ffb724254c |
| backend.mjs | 2476314cb807247bcebffb29bdb9029545d88afeb3f7311e65b93a4fda24a2a3 |

证据 RESULT.json，脚本 verify_actions.mjs，事前计划 TEST-PLAN.md。后台原账号窗口、权限/租约/UID、验证凭据和确切失败页恢复由对应后台专项审查负责；本报告不将隔离测试当成真实验证码完成、真实续行或桌面已安装。
