// Single read-only comment-page probe; original business state stays untouched.
const fs=require('fs'),path=require('path');
const base=path.resolve(__dirname,'../..');
const cfg=JSON.parse(fs.readFileSync(path.join(base,'抖音自用采集台/data/bridge.json'),'utf8'));
const identity=JSON.parse(fs.readFileSync(path.join(__dirname,process.argv[6]||'identity-probe.json'),'utf8'));
const {BridgeClient}=require(path.join(base,'work/runtime/douyin-bridge/lib/client/bridge-client'));
const bridge=new BridgeClient(cfg.bridge);
const sensitive=/cookie|authorization|token|password|secret|credential|sessionid/i;
function clean(x){if(Array.isArray(x))return x.map(clean);if(x&&typeof x==='object')return Object.fromEntries(Object.entries(x).map(([k,v])=>[k,sensitive.test(k)?'[REDACTED]':clean(v)]));return x}
(async()=>{
 const state=await bridge.status(),list=(state.connections?.['douyin.com']||[]).filter(x=>x.alive);
 if(list.length!==1||list[0].id!==identity.connection_id)throw Error('Page connection changed; stop');
 const expected=identity.account.sec_uid,video=process.argv[2]||'7685022323279784421';
 const store=process.argv[3]||'上海古北店',keyword=process.argv[4]||'上海古北个人求租';
 const outputName=process.argv[5]||'first-comments-raw.json';
 const cursor=Number(process.argv[7]||0);
 if(!Number.isSafeInteger(cursor)||cursor<0)throw Error('Invalid cursor');
 if(!/^\d+$/.test(video)||!/^[a-z0-9-]+\.json$/.test(outputName))throw Error('Invalid input');
 const outputPath=path.join(__dirname,outputName);
 if(fs.existsSync(outputPath))throw Error('Output already exists; preserve earlier evidence');
 const expr=`(async()=>{const p=new URLSearchParams(window.__bridge._q());const r=await fetch('/aweme/v1/web/user/profile/self/?'+p,{credentials:'include'});if(!r.ok)throw Error('identity HTTP '+r.status);const d=await r.json();if((d.user||{}).sec_uid!==${JSON.stringify(expected)})throw Error('ACCOUNT_CHANGED');return await window.__bridge.getComments(${JSON.stringify(video)},${cursor},20)})()`;
 const response=await bridge.call({site:'douyin.com',connId:identity.connection_id,expression:expr,awaitPromise:true,timeout:30000});
 if(!response.ok||response.connection!==identity.connection_id)throw Error('Bridge request failed or returned a different connection');
 const record={at:new Date().toISOString(),platform:'douyin',store,keyword,video,request_cursor:cursor,connection_id:identity.connection_id,account_uid:expected,response:clean(response.value)};
 fs.writeFileSync(outputPath,JSON.stringify(record,null,2),{flag:'wx'});
 const v=response.value||{};console.log(JSON.stringify({status_code:v.status_code??null,comments:Array.isArray(v.comments)?v.comments.length:null,has_more:v.has_more??null,cursor:v.cursor??null,keys:Object.keys(v).slice(0,12)}));
})().catch(e=>{console.error(e.message);process.exitCode=1});
