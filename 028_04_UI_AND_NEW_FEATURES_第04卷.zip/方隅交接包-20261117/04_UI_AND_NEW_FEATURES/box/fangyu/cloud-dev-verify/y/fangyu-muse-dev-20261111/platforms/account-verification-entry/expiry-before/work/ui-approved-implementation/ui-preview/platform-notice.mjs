const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const running=new Set(['queued','running','resuming','pausing','stopping']);
const platforms=['xiaohongshu','douyin'];
const identity=s=>JSON.stringify([s.authEpoch||0,s.user,s.storeId||'']);
function snapshots(s){
  if(s.connection!=='connected'||!s.session)return [];
  return platforms.map(id=>[id,id===(s.activePlatform||'xiaohongshu')?s.platform:s.platformWorkspaces?.[id]?.platform])
    .filter(([id,p])=>p?.actor?.username===s.user&&p?.actor?.storeId===s.storeId&&p?.acquisition?.taskId
      &&(!p.acquisition.taskScope?.platform||p.acquisition.taskScope.platform===id));
}
export function platformNotices(s){
  return snapshots(s).flatMap(([id,p])=>{
    const a=p.acquisition,category=a.platformError?.category;
    if(running.has(a.status)||!category)return [];
    const name=id==='xiaohongshu'?'小红书':'抖音';
    const messages={
      verification_required:[`${name}需要验证码`,id==='xiaohongshu'?'点“去验证”打开此账号的小红书网页。完成验证后保持网页打开，再点“验证完成，继续原任务”。':'请到账号页查看此抖音账号的提示，在平台网页完成验证后再继续。'],
      authentication_required:[`${name}登录已失效`,'请到账号页重新连接这个账号，再继续原任务。'],
      platform_rejected:[`${name}暂未允许继续读取`,'请查看账号页面是否有平台提示；当前不能确认是登录问题。'],
      rate_limited:[`${name}暂时限制读取频率`,'请稍后查看账号状态，再手动继续原任务。'],
      transport_error:[`${name}连接中断`,'请检查网络后继续原任务。'],
      compatibility_error:[`${name}接口暂不兼容`,'请联系管理员更新客户端，任务断点已保留。'],
      protocol_error:[`${name}读取结果未确认`,'请联系管理员核对本次记录，避免重复读取。'],
      unknown:[`${name}读取未完成`,'请查看账号状态；仍未恢复时联系管理员。']};
    if(!messages[category])return [];
    return [{id,taskId:a.taskId,category,title:messages[category][0],body:messages[category][1],
      accountId:a.taskScope?.accountId||''}];
  });
}
const noticeKey=(s,n)=>JSON.stringify([identity(s),n.id,n.taskId,n.accountId]);
export function createVerificationActions({state,open,resume,changed,blocked=()=>false,notify=()=>{}}){
  let pending=false;
  return async function act(kind,n){
    if(!['open','resume'].includes(kind)||pending||state.busy||blocked())return;
    const key=noticeKey(state,n),current=()=>platformNotices(state).some(v=>noticeKey(state,v)===key);
    if(!current()||n.id!=='xiaohongshu'||!n.accountId)return;
    pending=true;state.verificationAction={key,pending:true,kind,message:kind==='open'?'正在打开原账号网页…':'正在核对网页验证结果…'};changed();
    try{
      const response=await (kind==='open'?open:resume)(n.taskId);
      if(!current())return;
      const job=response?.job,p=response?.platform;
      if(job?.taskId!==n.taskId||job?.accountId!==n.accountId||p?.actor?.username!==state.user||p?.actor?.storeId!==state.storeId
          ||p.acquisition?.taskId!==n.taskId||p.acquisition.taskScope?.accountId!==n.accountId||p.acquisition.taskScope?.platform!==n.id)
        throw new Error('操作回执与原任务不一致，请刷新状态核对。');
      if(p.acquisition?.taskId===n.taskId&&(!p.acquisition.taskScope?.platform||p.acquisition.taskScope.platform===n.id)){
        if(n.id===(state.activePlatform||'xiaohongshu'))state.platform=p;
        else if(state.platformWorkspaces?.[n.id])state.platformWorkspaces[n.id].platform=p;
      }
      const message=kind==='open'?'原账号窗口正在打开；完成验证后保持窗口打开，再点下面的继续按钮。':'续行请求已提交，请查看获客进度。';
      state.verificationAction={key,pending:false,kind,message};notify(message);
    }catch(error){if(current())state.verificationAction={key,pending:false,kind,message:error.message||'操作暂未完成，请查看平台提示。'};}
    finally{pending=false;if(state.verificationAction?.key===key)state.verificationAction.pending=false;changed();}
  };
}
export function updatePlatformNotice(s,host,onAccount,onVerify){
  if(!host)return;
  const notices=platformNotices(s),key=JSON.stringify([identity(s),notices,s.verificationAction,s.busy]);
  if(host.dataset.noticeKey===key)return;
  host.dataset.noticeKey=key;host.hidden=!notices.length;
  host.innerHTML=notices.map((n,index)=>{
    const action=s.verificationAction?.key===noticeKey(s,n)?s.verificationAction:null;
    const canVerify=onVerify&&n.id==='xiaohongshu'&&n.accountId&&['verification_required','platform_rejected','authentication_required'].includes(n.category);
    const disabled=action?.pending||s.busy?'disabled':'';
    return `<section class="platform-alert" role="alert"><div><strong>${esc(n.title)}</strong><p>${esc(n.body)} 已读取的数据和断点已保留。</p>${action?.message?`<p class="platform-alert-feedback" role="status">${esc(action.message)}</p>`:''}</div><div class="platform-alert-actions">${canVerify?`<button type="button" data-verify-action="open" data-notice-index="${index}" ${disabled}>去验证</button><button type="button" data-verify-action="resume" data-notice-index="${index}" ${disabled}>验证完成，继续原任务</button>`:`<button type="button" data-platform-notice="${n.id}">查看账号</button>`}</div></section>`;
  }).join('');
  host.querySelectorAll('[data-platform-notice]').forEach(button=>button.addEventListener('click',()=>onAccount(button.dataset.platformNotice)));
  host.querySelectorAll('[data-verify-action]').forEach(button=>button.addEventListener('click',()=>onVerify(button.dataset.verifyAction,notices[Number(button.dataset.noticeIndex)])));
}
export function createCollectionMonitor({state,read,changed,schedule=setTimeout,cancel=clearTimeout}){
  let timer=null,timerScope=null,flight=false;
  const targets=()=>snapshots(state).filter(([id,p])=>running.has(p.acquisition.status)
    &&(id!==(state.activePlatform||'xiaohongshu')||!['acquire','accounts'].includes(state.page)));
  function sync(){
    const wanted=targets().length>0,scope=identity(state);
    if(timer!==null&&(!wanted||timerScope!==scope)){
      cancel(timer);timer=null;timerScope=null;
    }
    if(!flight&&wanted&&timer===null){
      timerScope=scope;timer=schedule(tick,5000);
    }
  }
  async function tick(){
    timer=null;timerScope=null;if(flight)return;flight=true;
    const scope=identity(state);
    try{
      for(const [id,prior] of targets()){
        if(scope!==identity(state)||state.connection!=='connected'||!state.session)break;
        try{
          const response=await read({platform:id});
          const p=response?.platform;
          if(scope!==identity(state)||state.connection!=='connected'||!state.session)break;
          const current=snapshots(state).find(([platform])=>platform===id)?.[1];
          if(!p||p.actor?.username!==state.user||p.actor?.storeId!==state.storeId
              ||p.acquisition?.taskId!==prior.acquisition.taskId||current?.acquisition?.taskId!==prior.acquisition.taskId
              ||(p.acquisition.taskScope?.platform&&p.acquisition.taskScope.platform!==id))continue;
          if(id===(state.activePlatform||'xiaohongshu'))state.platform=p;
          else if(state.platformWorkspaces?.[id])state.platformWorkspaces[id].platform=p;
          changed();
        }catch{ /* Preserve the last known task; foreground reads show service errors. */ }
      }
    }finally{flight=false;sync();}
  }
  return {sync};
}
