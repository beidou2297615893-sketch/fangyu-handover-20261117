"""Local incremental cache; source database is attached read-only. No platform calls."""
import hashlib,json,sqlite3,sys,time,datetime
from pathlib import Path
from ledger import Ledger
from scoped_recovery import effective_halt

def encoded(x):return json.dumps(x,ensure_ascii=False,separators=(',',':'))
def connect_ro(p):
 d=sqlite3.connect(Path(p).resolve().as_uri()+'?mode=ro',uri=True);d.row_factory=sqlite3.Row;return d
def gate(p,account,scan=None,spec=None):
 with connect_ro(p) as d:
  row=effective_halt(d,account,scan,spec)
  return dict(can_collect=row is None,halt=dict(row) if row else None)
def fingerprint(kind,value):
 rows=value.get('data' if kind=='search' else 'comments') or []
 ids=[((r.get('aweme_info') or {}).get('aweme_id') if kind=='search' else r.get('cid')) for r in rows if isinstance(r,dict)]
 ids=sorted({x for x in ids if isinstance(x,str) and x.isdigit()})
 return hashlib.sha256(encoded(ids).encode()).hexdigest() if ids else None

def collection_accounts(p):
 accounts=p.get('collection_accounts',[p['account_uid']])
 if not isinstance(accounts,list) or not accounts or any(not isinstance(x,str) or not x for x in accounts) or p['account_uid'] not in accounts:raise ValueError('explicit collection accounts required')
 if len(set(accounts))>1 and not p.get('account_transition_source'):raise ValueError('account transition authorization required')
 return sorted(set(accounts))

def assess(body,store):
 cities=('上海','北京','成都','杭州','福州','郑州','深圳','广州','南京','苏州','武汉','西安','重庆','天津','长沙','合肥','宁波','东莞','佛山','无锡','济南','青岛','厦门')
 city=store.get('city') or next((x for x in cities[:5] if x in store.get('name',store['store_id'])),None)
 anchors=store.get('geography_anchors') or ([city] if city else [])
 matched=[x for x in anchors if x and x in body];foreign=[x for x in cities if x!=city and x in body]
 rentals=[x for x in ('租房','求租','出租','招租','转租','找房','合租','整租','月租','长租','租金','房租') if x in body]
 sales=[x for x in ('买房','购房','卖房','售房','新房出售','二手房出售','首付','按揭') if x in body]
 # Candidate place strings from the source-retained 15 official detail addresses
 # and store names; not verified current operating addresses. Matches are body
 # relevance hints, never proof of distance, current store status, intent, or IP.
 local_names={'上海联航路云涛公寓':('联航路','万泰路','浦江镇'),'上海古北方隅服务公寓':('古北','红松东路'),'上海会展方隅国际公寓':('龙蟠桥路',),'上海浦江方隅服务公寓':('浦江','江鹏路'),'上海中骏广场方隅服务公寓':('申长路',),'FUNLIVE·上海天璟方隅服务公寓':('蟠中路','徐泾镇'),'上海龙柏方隅服务公寓':('龙柏','金汇路'),'北京天璟方隅公寓':('门头沟','城子东路','城子东一街'),'北京未来云城方隅公寓':('安源巷','太福路'),'北京沙河方隅服务公寓':('沙河','白石山街','百善村路'),'成都高新西方隅服务公寓':('高新西','安业路'),'杭州东站方隅公寓':('杭州东站','天城路'),'杭州余杭方隅公寓':('余杭','联创街'),'杭州青山湖方隅服务公寓':('青山湖','钱王街','望湖路'),'福州白湖亭方隅服务公寓':('白湖亭','高仕路')}
 local=[x for x in local_names.get(store['store_id'],()) if x in body]
 return dict(state='eligible' if body and matched and rentals and not foreign and not sales else 'review_required',body_geography=matched,body_store_area_mentions=local,body_rental_terms=rentals,body_foreign_cities=foreign,body_sales_terms=sales,rule='post_body_geography_and_rental_required_v2',store_assignment='source_relation_only_intent_unreviewed')

class Cache:
 def __init__(self,source,cache_path=None):
  self.source=Path(source).resolve();self.path=Path(cache_path) if cache_path else self.source.parent/'runner-cache-v7.sqlite3'
  self.path.parent.mkdir(parents=True,exist_ok=True);self.db=sqlite3.connect(self.path,uri=True);self.db.row_factory=sqlite3.Row
  self.db.execute('ATTACH DATABASE ? AS source',(self.source.as_uri()+'?mode=ro',))
  self.db.executescript('''
   CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY,value TEXT);
   CREATE TABLE IF NOT EXISTS fingerprints(scan TEXT,account TEXT,kind TEXT,target TEXT,digest TEXT,request TEXT,cursor INTEGER,PRIMARY KEY(scan,account,kind,target,digest));
   CREATE TABLE IF NOT EXISTS videos(scan TEXT,account TEXT,video TEXT,store TEXT,keyword TEXT,request TEXT,body TEXT,published INTEGER,likes INTEGER,PRIMARY KEY(scan,account,video));
   CREATE TABLE IF NOT EXISTS refs(scan TEXT,account TEXT,video TEXT,store TEXT,keyword TEXT,request TEXT,PRIMARY KEY(scan,account,video,store,keyword,request));
   CREATE TABLE IF NOT EXISTS counts(scan TEXT,account TEXT,kind TEXT,target TEXT,store TEXT,keyword TEXT,n INTEGER,PRIMARY KEY(scan,account,kind,target,store,keyword));
   CREATE TABLE IF NOT EXISTS comment_yield(scan TEXT,account TEXT,target TEXT,store TEXT,keyword TEXT,last_added INTEGER,PRIMARY KEY(scan,account,target,store,keyword));
   CREATE TABLE IF NOT EXISTS comment_relations(request TEXT,cid TEXT,account TEXT,state TEXT,PRIMARY KEY(request,cid));
   CREATE TABLE IF NOT EXISTS qualified_comments(policy TEXT,account TEXT,cid TEXT,PRIMARY KEY(policy,account,cid));
   CREATE INDEX IF NOT EXISTS comments_account ON comment_relations(account);
   CREATE TABLE IF NOT EXISTS admissions(scan TEXT,account TEXT,video TEXT,plan TEXT,store TEXT,scope_store TEXT,scope_keyword TEXT,state TEXT,evidence TEXT,PRIMARY KEY(scan,account,video,plan));
   CREATE INDEX IF NOT EXISTS admission_queue ON admissions(scan,account,plan,store,state);
   CREATE INDEX IF NOT EXISTS video_scan ON videos(scan,account,store);
   CREATE INDEX IF NOT EXISTS refs_video ON refs(scan,account,video);
  ''');self.decoded=0
 def get(self,k,default='0'):
  r=self.db.execute('SELECT value FROM meta WHERE key=?',(k,)).fetchone();return r[0] if r else default
 def put(self,k,v):self.db.execute('INSERT OR REPLACE INTO meta VALUES(?,?)',(k,str(v)))
 def sync(self):
  stat=self.source.stat();identity=str((stat.st_dev,stat.st_ino));maximum=self.db.execute('SELECT COALESCE(MAX(rowid),0) FROM source.attempts').fetchone()[0];last=int(self.get('attempt_rowid'))
  if self.get('identity','')!=identity or maximum<last:
   for t in ('meta','fingerprints','videos','refs','counts','comment_yield','admissions','comment_relations','qualified_comments'):self.db.execute('DELETE FROM '+t)
   self.put('identity',identity);last=0
  for r in self.db.execute('SELECT rowid,* FROM source.attempts WHERE rowid>? ORDER BY rowid',(last,)).fetchall():
   self.decoded+=1
   if r['state']!='parsed':continue
   s=json.loads(r['spec']);v=json.loads(r['response']).get('value',{});scan,acct,kind,target=s.get('scan_id','legacy'),s['account_uid'],s['kind'],s['target'];store,word=s.get('store_id',''),s.get('keyword','');digest=fingerprint(kind,v)
   if digest:self.db.execute('INSERT OR IGNORE INTO fingerprints VALUES(?,?,?,?,?,?,?)',(scan,acct,kind,target,digest,r['request_id'],s['cursor']))
   self.db.execute('INSERT INTO counts VALUES(?,?,?,?,?,?,1) ON CONFLICT(scan,account,kind,target,store,keyword) DO UPDATE SET n=n+1',(scan,acct,kind,target,store,word))
   if kind=='comments':
    self.db.execute('INSERT OR REPLACE INTO comment_yield VALUES(?,?,?,?,?,?)',(scan,acct,target,store,word,r['added'] if isinstance(r['added'],int) else 0))
    eligibility=s.get('eligibility');state=eligibility.get('state','review_required') if isinstance(eligibility,dict) else (eligibility or 'review_required')
    if 'recent_collection' in s:
     cids=(row[0].removeprefix('comment:') for row in self.db.execute(
      "SELECT stable_key FROM source.observations WHERE request_id=? AND kind='comments' ORDER BY rowid",(r['request_id'],)))
    else:
     cids=(item.get('cid') for item in v.get('comments') or [])
    for cid in cids:
     if isinstance(cid,str):self.db.execute('INSERT OR IGNORE INTO comment_relations VALUES(?,?,?,?)',(r['request_id'],cid,acct,state))
   if kind=='search':
    for card in v.get('data',[]):
     item=card.get('aweme_info') if isinstance(card,dict) else None
     if not isinstance(item,dict):continue
     video=item.get('aweme_id')
     if not isinstance(video,str) or not video.isdigit():raise ValueError('non-exact ID')
     published=item.get('create_time');likes=(item.get('statistics') or {}).get('digg_count')
     self.db.execute('INSERT OR IGNORE INTO videos VALUES(?,?,?,?,?,?,?,?,?)',(scan,acct,video,store,word,r['request_id'],item.get('desc') if isinstance(item.get('desc'),str) else '',published if type(published) is int and published>0 else None,likes if type(likes) is int and likes>=0 else None))
     for sid in s.get('store_refs') or [store]:self.db.execute('INSERT OR IGNORE INTO refs VALUES(?,?,?,?,?,?)',(scan,acct,video,sid,word,r['request_id']))
  self.put('attempt_rowid',maximum)
  if self.db.execute("SELECT 1 FROM source.sqlite_master WHERE name='recent_comment_backfill'").fetchone():
   last_backfill=int(self.get('recent_backfill_rowid'))
   for row in self.db.execute("""SELECT b.rowid,b.request_id,b.cid,b.account_uid,a.spec
     FROM source.recent_comment_backfill b JOIN source.attempts a ON a.request_id=b.request_id
     WHERE b.rowid>? ORDER BY b.rowid""",(last_backfill,)):
    eligibility=json.loads(row['spec']).get('eligibility')
    state=eligibility.get('state','review_required') if isinstance(eligibility,dict) else (eligibility or 'review_required')
    self.db.execute('INSERT OR IGNORE INTO comment_relations VALUES(?,?,?,?)',(row['request_id'],row['cid'],row['account_uid'],state))
    last_backfill=row['rowid']
   self.put('recent_backfill_rowid',last_backfill)
  previous=int(self.get('entity_rowid'))
  for r in self.db.execute('SELECT kind,COUNT(*) n,MAX(rowid) maximum FROM source.entities WHERE rowid>? GROUP BY kind',(previous,)).fetchall():
   self.put('count_'+r['kind'],int(self.get('count_'+r['kind']))+r['n']);previous=max(previous,r['maximum'])
  self.put('entity_rowid',previous)
  # Retention deletes business observations. Never revive them from raw attempts.
  self.db.execute("DELETE FROM comment_relations WHERE request||char(0)||cid NOT IN (SELECT request_id||char(0)||substr(stable_key,instr(stable_key,':')+1) FROM source.observations WHERE kind='comments')")
  self.db.execute("DELETE FROM qualified_comments WHERE cid NOT IN (SELECT source_id FROM source.entities WHERE kind='comments')")
  self.db.execute("DELETE FROM meta WHERE key LIKE 'qualified_count_%' OR key LIKE 'qualified_rowid_%'")
  for kind in ('comments','search'):
   self.put('count_'+kind,self.db.execute('SELECT COUNT(*) FROM source.entities WHERE kind=?',(kind,)).fetchone()[0])
  self.db.commit()
 def seen(self,s):return self.db.execute('SELECT 1 FROM fingerprints WHERE scan=? AND account=? AND kind=? AND target=? AND digest=?',(s['scan_id'],s['account_uid'],s['kind'],s['target'],s.get('page_items_digest'))).fetchone() is not None
 def qualified(self,p):
  policy=p.get('qualification_policy',{});approved=set(policy.get('qualified_request_ids',[]));policyhash=hashlib.sha256(encoded(policy).encode()).hexdigest();account=p['account_uid']
  accounts=collection_accounts(p)
  if policy and policy.get('account_uid') not in accounts:raise ValueError('qualification account mismatch')
  if len(accounts)>1:policyhash=hashlib.sha256(encoded(dict(policy=policy,accounts=accounts)).encode()).hexdigest()
  # Counts derive from current business rows, not monotonically increasing IDs.
  account_marks=','.join('?' for _ in accounts)
  approved_marks=','.join('?' for _ in approved) or 'NULL'
  now=datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8)))
  cutoff=now.timestamp()-30*86400
  query="SELECT COUNT(DISTINCT c.cid) FROM comment_relations c JOIN source.entities e ON e.kind='comments' AND e.source_id=c.cid WHERE c.account IN ("+account_marks+") AND CAST(json_extract(e.data,'$.create_time') AS INTEGER) BETWEEN ? AND ? AND c.state!='excluded_irrelevant' AND (c.state='eligible' OR (c.account=? AND c.request IN ("+approved_marks+")))"
  return self.db.execute(query,(*accounts,cutoff,now.timestamp(),policy.get('account_uid'),*approved)).fetchone()[0]

 def snapshot(self,p):
  qualified=self.qualified(p)
  scan,acct=p['scan_id'],p['account_uid'];stores={x['store_id']:x for x in p['stores']};aliases={a:s['store_id'] for s in p['stores'] for a in s.get('aliases',[])};canonical=lambda s:s if s in stores else aliases.get(s)
  planhash=hashlib.sha256(encoded(p['stores']).encode()).hexdigest()
  accounts=collection_accounts(p);previous_videos=set()
  if len(accounts)>1:
   planhash=hashlib.sha256(encoded(dict(stores=p['stores'],accounts=accounts)).encode()).hexdigest()
  if p.get('revisit_historical_videos') is True:
   self.seed_historical_videos(p,planhash,accounts)
  # Classify only new discoveries or an explicitly changed plan, once. Original bodies are not reread.
  fresh=list(self.db.execute('SELECT v.* FROM videos v LEFT JOIN admissions a ON a.scan=v.scan AND a.account=v.account AND a.video=v.video AND a.plan=? WHERE v.scan=? AND v.account=? AND a.video IS NULL',(planhash,scan,acct)))
  existing={}
  if fresh:
   if len(accounts)>1:
    marks=','.join('?' for _ in accounts)
    previous_videos={r[0] for r in self.db.execute("SELECT DISTINCT json_extract(spec,'$.target') FROM source.attempts WHERE json_extract(spec,'$.scan_id')=? AND json_extract(spec,'$.kind')='comments' AND json_extract(spec,'$.account_uid')!=? AND json_extract(spec,'$.account_uid') IN ("+marks+")",(scan,acct,*accounts))}
   for r in self.db.execute("SELECT * FROM source.scan_streams WHERE scan_id=? AND account_uid=? AND kind='comments'",(scan,acct)):
    old=existing.get(r['target'])
    if not old or (r['exhausted'],r['cursor'])>(old['exhausted'],old['cursor']):existing[r['target']]=dict(r)
  for r in fresh:
   old=existing.get(r['video']);raw_store=old['store_id'] if old else r['store'];raw_word=old['keyword'] if old else r['keyword'];sid=canonical(raw_store)
   admission=assess(r['body'],stores[sid]) if sid else dict(state='unmapped_store',rule='explicit_store_mapping_required')
   if r['video'] in previous_videos or r['video'] in p.get('excluded_historical_videos',[]):admission=dict(state='previous_account_source_retained',rule='do_not_replay_prior_account_video_or_unknown_request',store_assignment='source_relation_only_intent_unreviewed')
   self.db.execute('INSERT INTO admissions VALUES(?,?,?,?,?,?,?,?,?)',(scan,acct,r['video'],planhash,sid or raw_store,raw_store,raw_word,admission['state'],encoded(admission)))
  self.db.commit()
  checkpoints={};planned={x['keyword']:x for x in p.get('search_tasks',[])}
  for r in self.db.execute("SELECT s.*,COALESCE(c.n,0) pages FROM source.scan_streams s LEFT JOIN counts c ON c.scan=s.scan_id AND c.account=s.account_uid AND c.kind=s.kind AND c.target=s.target AND c.store=s.store_id AND c.keyword=s.keyword WHERE s.scan_id=? AND s.account_uid=? AND s.kind='search'",(scan,acct)):
   owner=planned.get(r['target'],{}).get('store_id',canonical(r['store_id']))
   if not owner:continue
   cp=dict(cursor=r['cursor'],exhausted=r['exhausted'],pages=r['pages'],scope_store_id=r['store_id'],scope_keyword=r['keyword']);k=encoded(('search',r['target'],owner,r['target']));old=checkpoints.get(k)
   if not old or (cp['exhausted'],cp['cursor'])>(old['exhausted'],old['cursor']):checkpoints[k]=cp
  videos=[]
  query="SELECT v.video,v.keyword,v.published,v.likes,a.store,a.scope_store,a.scope_keyword,a.evidence,COALESCE(s.cursor,0) cursor,COALESCE(s.exhausted,0) exhausted,COALESCE(c.n,0) pages,y.last_added FROM admissions a JOIN videos v ON v.scan=a.scan AND v.account=a.account AND v.video=a.video LEFT JOIN source.scan_streams s ON s.scan_id=a.scan AND s.account_uid=a.account AND s.kind='comments' AND s.target=a.video AND s.store_id=a.scope_store AND s.keyword=a.scope_keyword LEFT JOIN counts c ON c.scan=a.scan AND c.account=a.account AND c.kind='comments' AND c.target=a.video AND c.store=a.scope_store AND c.keyword=a.scope_keyword LEFT JOIN comment_yield y ON y.scan=a.scan AND y.account=a.account AND y.target=a.video AND y.store=a.scope_store AND y.keyword=a.scope_keyword WHERE a.scan=? AND a.account=? AND a.plan=? AND a.store=? AND a.state='eligible' AND COALESCE(s.exhausted,0)=0 ORDER BY (v.published IS NULL),v.published DESC,CASE WHEN json_array_length(json_extract(a.evidence,'$.body_store_area_mentions'))>0 THEN 0 ELSE 1 END,v.likes DESC,CASE WHEN y.last_added>=10 THEN 0 WHEN y.last_added IS NULL THEN 1 ELSE 2 END,y.last_added DESC,v.video LIMIT 1"
  for sid in stores:
   r=self.db.execute(query,(scan,acct,planhash,sid)).fetchone()
   if not r:continue
   refs=list(self.db.execute('SELECT store,keyword,request FROM refs WHERE scan=? AND account=? AND video=?',(scan,acct,r['video'])))
   videos.append(dict(kind='comments',target=r['video'],store_id=sid,keyword=r['keyword'],scope_store_id=r['scope_store'],scope_keyword=r['scope_keyword'],cursor=r['cursor'],exhausted=r['exhausted'],pages=r['pages'],store_refs=sorted({canonical(x['store']) or x['store'] for x in refs}),source_refs=[dict(store_id=canonical(x['store']) or x['store'],keyword=x['keyword'],search_request_id=x['request']) for x in refs],priority_evidence=dict(published_at_unix=r['published'],likes=r['likes'],basis='returned_post_fields_only',intent='not_evaluated'),eligibility=json.loads(r['evidence'])))
  review={r['state']:r['n'] for r in self.db.execute('SELECT state,COUNT(*) n FROM admissions WHERE scan=? AND account=? AND plan=? GROUP BY state',(scan,acct,planhash))}
  halt=gate(self.source,acct,scan)['halt']
  return dict(can_collect=halt is None,halt=dict(halt) if halt else None,summary=dict(comments=qualified,total_comments=int(self.get('count_comments')),items=int(self.get('count_comments'))+int(self.get('count_search'))),checkpoints=checkpoints,videos=videos,review_counts=review,cache_stats=dict(attempts_decoded=self.decoded,admissions_computed=len(fresh),source_attempt_rowid=int(self.get('attempt_rowid')),returned_video_candidates=len(videos)))

 def seed_historical_videos(self,p,planhash,accounts):
  # Carry only previously eligible videos with a successful comment read.
  # A fresh scan restarts at the first comment page; the ledger deduplicates CIDs.
  scan,account=p['scan_id'],p['account_uid']
  marker='historical-seed:'+hashlib.sha256(encoded((scan,account,planhash)).encode()).hexdigest()
  if self.get(marker,'')=='done':return
  stores={s['store_id']:set(s.get('keywords',[])) for s in p['stores']}
  blocked=set(p.get('excluded_historical_videos',[]))
  read_videos=set();recent_videos=set();cutoff=time.time()-30*60
  for raw,collected_at in self.db.execute("SELECT spec,collected_at FROM source.attempts WHERE state='parsed' AND json_extract(spec,'$.kind')='comments'"):
   target=json.loads(raw).get('target');read_videos.add(target)
   try:
    stamp=datetime.datetime.fromisoformat(collected_at.replace('Z','+00:00'))
    if stamp.tzinfo is None:stamp=stamp.replace(tzinfo=datetime.timezone.utc)
    if stamp.timestamp()>=cutoff:recent_videos.add(target)
   except (ValueError,AttributeError,OverflowError):recent_videos.add(target)
  marks=','.join('?' for _ in accounts)
  candidates=self.db.execute("SELECT v.*,a.store admitted_store,a.scope_store,a.scope_keyword,a.evidence FROM admissions a JOIN videos v ON v.scan=a.scan AND v.account=a.account AND v.video=a.video WHERE a.state='eligible' AND a.scan!=? AND a.account IN ("+marks+") ORDER BY v.rowid DESC",(scan,*accounts)).fetchall()
  seen=set()
  for row in candidates:
   video=row['video'];store=row['admitted_store'];word=row['scope_keyword'];scope_store=row['scope_store']
   if video in seen or video in blocked or video in recent_videos or video not in read_videos or word not in stores.get(store,set()):continue
   seen.add(video)
   self.db.execute('INSERT OR IGNORE INTO videos VALUES(?,?,?,?,?,?,?,?,?)',(scan,account,video,scope_store,word,row['request'],row['body'],row['published'],row['likes']))
   self.db.execute('INSERT OR IGNORE INTO refs VALUES(?,?,?,?,?,?)',(scan,account,video,scope_store,word,row['request']))
   self.db.execute('INSERT OR IGNORE INTO admissions VALUES(?,?,?,?,?,?,?,?,?)',(scan,account,video,planhash,store,scope_store,word,'eligible',row['evidence']))
  self.put(marker,'done');self.db.commit()

def ingest_local(path, data, shared_ledger):
 for attempt in range(3):
  try:
   return Ledger(path, shared_ledger=shared_ledger).ingest(data['spec'],data['response'])
  except sqlite3.OperationalError as error:
   code=getattr(error,'sqlite_errorcode',0) & 0xff
   if code not in (sqlite3.SQLITE_BUSY,sqlite3.SQLITE_LOCKED) or attempt==2:raise
   # The durable runner record is already on disk; only the local
   # idempotent transaction is retried. No browser call is involved.
   time.sleep(0.25 * (attempt+1))

def main():
 path=Path(sys.argv[1]).resolve();data=json.load(sys.stdin);action=sys.argv[2]
 if action=='ingest':result=ingest_local(path,data,Path(sys.argv[3]) if len(sys.argv)>3 else None)
 elif action=='gate':result=gate(path,data['account_uid'],data.get('scan_id'),data if 'kind' in data else None) if path.exists() else dict(can_collect=True,halt=None)
 else:
  if not path.exists():Ledger(path)
  cache=Cache(path)
  try:
   cache.sync()
   if action=='snapshot':result=cache.snapshot(data)
   elif action=='page_seen':result=cache.seen(data['spec'])
   else:raise ValueError('unsupported local action')
  finally:cache.db.close()
 print(encoded(result))
if __name__=='__main__':main()
