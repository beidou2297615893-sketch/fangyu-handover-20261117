'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {createBridgeTransport,Runner}=require('./runner.cjs');
const base=fs.mkdtempSync(path.join(__dirname,'zero-test-'));
const plan=()=>({scan_id:'synthetic-scan',account_uid:'synthetic-owner',connection_id:'synthetic-page',rule_source:'synthetic-only',target_comments:100000,stores:Array.from({length:15},(_,i)=>({store_id:'store-'+i,name:'上海合成门店'+i,city:'上海',geography_anchors:['上海'],keywords:['synthetic-term-'+i]}))});
const envelope=(spec,value)=>({ok:true,connection:spec.connection_id,value});
const searchValue=(id)=>({status_code:0,data:[{aweme_info:{aweme_id:id,desc:'上海租房合成视频'}}],cursor:10,has_more:0});
test('zero interval keeps transport serial and never sleeps',async()=>{
 const p=plan();let active=0,peak=0,calls=0,sleeps=[];const clock={now:()=>0,sleep:async ms=>sleeps.push(ms)};
 const bridge={host:'synthetic-zero',port:1,status:async()=>({connections:{'douyin.com':[{id:p.connection_id,alive:true},{id:'independent-tab',alive:true}]}}),call:async()=>{calls++;active++;peak=Math.max(peak,active);await new Promise(r=>setTimeout(r,2));active--;return {ok:true,connection:p.connection_id,value:{identity_verified:true,http_status:200,content_type:'application/json',raw_text:'{"status_code":0,"data":[],"cursor":0,"has_more":0}'}};}};
 const transport=createBridgeTransport(bridge,{connection_id:p.connection_id,strict_proof:{verified:true,source:'synthetic'},minimum_delay_ms:0,clock});const spec={...p,kind:'search',target:'synthetic',cursor:0};
 const results=await Promise.all([transport(spec,10),transport(spec,10),transport(spec,10)]);assert.equal(peak,1);assert.equal(calls,3);assert.deepEqual(sleeps,[]);assert(results.every(r=>r.ok===true));
});
test('zero interval keeps account, page and proof protections',async()=>{
 const p=plan();let calls=0;const clock={now:()=>0,sleep:async()=>{throw Error('unexpected sleep')}};
 const bridge={host:'synthetic-zero-guard',port:1,status:async()=>({connections:{'douyin.com':[{id:'different',alive:true}]}}),call:async()=>{calls++;return {ok:true,connection:'wrong',value:{identity_verified:false}};}};
 assert.throws(()=>createBridgeTransport(bridge,{connection_id:p.connection_id,minimum_delay_ms:0,clock}));
 const transport=createBridgeTransport(bridge,{connection_id:p.connection_id,strict_proof:{verified:true,source:'synthetic'},minimum_delay_ms:0,clock});const spec={...p,kind:'search',target:'synthetic',cursor:0};
 assert.equal((await transport(spec,10)).transport_error,'connection_changed');assert.equal(calls,0);
 bridge.status=async()=>({connections:{'douyin.com':[{id:p.connection_id,alive:true}]}});assert.equal((await transport(spec,10)).transport_error,'bridge_result_not_established');assert.equal(calls,1);
 bridge.call=async()=>({ok:true,connection:p.connection_id,value:{identity_verified:false}});assert.equal((await transport(spec,10)).transport_error,'identity_not_verified');
});
test('zero runner interval skips wait and others preserve checks',async()=>{
 let sleeps=0,calls=0;const clock={now:()=>0,sleep:async()=>{sleeps++}};const directory=path.join(base,'zero-runner');
 const ledger={snapshot:()=>({can_collect:true,summary:{comments:0},checkpoints:{},videos:[]}),gate:()=>({can_collect:true}),pageSeen:()=>false,ingest:({spec})=>({state:'parsed',request_id:spec.request_id,added:1})};
 const runner=new Runner({plan:plan(),ledger,transport:async spec=>{calls++;return envelope(spec,searchValue('9007199254740993001'));},directory,minimum_delay_ms:0,clock});
 assert.equal((await runner.step()).state,'page_committed');assert.equal((await runner.step()).state,'page_committed');assert.equal(calls,2);assert.equal(sleeps,0);
 for(const ms of [-1,1,5000,29999,NaN,1.5])assert.throws(()=>new Runner({plan:plan(),ledger,transport:()=>{},directory:path.join(base,'bad-'+String(ms)),minimum_delay_ms:ms,clock}));
 for(const ms of [30000,40000])assert.doesNotThrow(()=>new Runner({plan:plan(),ledger,transport:()=>{},directory:path.join(base,'good-'+ms),minimum_delay_ms:ms,clock}));
});
