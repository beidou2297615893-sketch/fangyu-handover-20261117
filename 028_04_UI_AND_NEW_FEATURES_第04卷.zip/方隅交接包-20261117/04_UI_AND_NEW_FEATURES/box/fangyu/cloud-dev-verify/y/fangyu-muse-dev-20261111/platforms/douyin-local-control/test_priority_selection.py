import json
from datetime import datetime, timedelta, timezone
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

T = Path(__file__).resolve().parents[1] / 'douyin-round2-task5'
sys.path.insert(0, str(T))
import batch_reply_runner as runner
import time_priority as priority
import control
sys.path.insert(0, str(T.parent / 'fangyu-text-business-20261029/recency-priority'))
from publish_douyin_send_queue import ordered_items

def item(cid, video='same-video', uid=None):
    return {'cid': cid, 'uid': uid or 'user-'+cid, 'video': video, 'draft': 'approved'}

def row(cid, date='2026-10-30T12:00:00+08:00'):
    return {'comment_id': cid, 'published_at': date, 'commercial_fit': {'budget': {'state': 'budget_unverified'}}, 'interest_at_comment': 'high'}

class PriorityTests(unittest.TestCase):
    def test_video_observation_does_not_hide_new_comment(self):
        candidates=[item('new'), item('old','another-video')]
        self.assertEqual(priority.unattempted_items(candidates, [], {'videos': {'same-video': {}}}), candidates)

    def test_every_attempt_status_and_customer_remain_excluded(self):
        records=[{'comment':str(i),'customer':'u'+str(i),'status':status}
                 for i,status in enumerate(['sent','unknown','reserved','not_sent'])]
        candidates=[item(str(i)) for i in range(4)]+[item('alias',uid='u1'),item('safe')]
        self.assertEqual(priority.unattempted_items(candidates,records,{}),[item('safe')])

    def test_exact_comment_exclusion_is_kept(self):
        self.assertEqual(priority.unattempted_items([item('a'),item('b')],[],{'comments':{'a':{}}}),[item('b')])

    def test_latest_priority_overrides_old_approved_order(self):
        candidates=[item('old'),item('new')]
        self.assertEqual(priority.order_from_snapshot(candidates,[row('new'),row('old')]),list(reversed(candidates)))
        self.assertEqual(priority.order_from_snapshot(candidates,[row('unauthorized')]),[])

    def test_pointer_and_ledger_refreshed_between_selections(self):
        source={'source_sha256':'source','sha256':'queue'}
        with tempfile.TemporaryDirectory() as tmp, patch.object(runner,'HERE',Path(tmp)), \
             patch.object(runner,'ledger_rows',side_effect=[[],[{'comment':'b','customer':'user-b'}]]), \
             patch.object(priority,'priority_snapshot',side_effect=[(source,[row('a'),row('b'),row('c')]),(source,[row('b'),row('c'),row('a')])]):
            selected=priority.live_ordered([item('c'),item('b'),item('a')])
            self.assertEqual(next(selected)['cid'],'a')
            second=next(selected)
            self.assertEqual(second['cid'],'c')
            self.assertEqual(second['_priority_evidence']['queue_sha256'],'queue')

    def test_live_selection_uses_recent_bands_budget_and_intent_then_older(self):
        now = datetime.now(timezone.utc)
        inputs = [('old', 40, True, 'super_high'), ('week2', 10, True, 'super_high'),
                  ('week1-unknown-budget', 2, False, 'super_high'),
                  ('week1-weaker', 1, True, 'low'), ('week1-stronger', 5, True, 'high')]
        rows = []
        for cid, days, budget, intent in inputs:
            candidate = row(cid, (now - timedelta(days=days)).isoformat())
            if budget:
                candidate['commercial_fit']['budget']['state'] = 'budget_at_least_4000'
            candidate['interest_at_comment'] = intent
            rows.append(candidate)
        with tempfile.TemporaryDirectory() as tmp, patch.object(runner, 'HERE', Path(tmp)), \
             patch.object(runner, 'ledger_rows', return_value=[]), \
             patch.object(priority, 'priority_snapshot', return_value=({'source_sha256':'source','sha256':'queue'}, rows)):
            selected = list(priority.live_ordered([item(data[0]) for data in inputs]))
        self.assertEqual([x['cid'] for x in selected],
                         ['week1-stronger', 'week1-weaker', 'week1-unknown-budget', 'week2', 'old'])
        self.assertTrue(all(x['_priority_evidence']['source_sha256'] == 'source' for x in selected))

    def test_sender_pauses_if_a_newer_pool_is_outside_approval(self):
        now = datetime.now(timezone.utc)
        newer = row('222', (now - timedelta(days=5)).isoformat())
        newer.update(customer_uid='333', video_id='444', pending_candidate=True,
                     reply={'draft_text': '宝宝，我住方隅，这边可以看看。'})
        newer['commercial_fit']['eligible_candidate'] = True
        older = row('old', (now - timedelta(days=65)).isoformat())
        source = {'source_sha256': 'source', 'sha256': 'queue'}
        with tempfile.TemporaryDirectory() as tmp, patch.object(runner,'HERE',Path(tmp)), \
             patch.object(runner,'ledger_rows',return_value=[]), \
             patch.object(priority,'priority_snapshot',return_value=(source,[newer,older])):
            with self.assertRaisesRegex(RuntimeError, '更近期候选待纳入批准队列'):
                next(priority.live_ordered([item('old')], enforce_review_gap=True))
            (Path(tmp)/'unavailable-targets.json').write_text(
                json.dumps({'operator_skipped_videos': {'444': {}}}), encoding='utf-8')
            self.assertEqual(next(priority.live_ordered([item('old')], enforce_review_gap=True))['cid'], 'old')

    def test_queue_preserves_generated_reply_without_phrase_filter(self):
        draft = '宝宝，我住方隅，这边可以看看。'
        candidate = row('111')
        candidate.update(customer_uid='222', video_id='333', comment_text='想找房',
                         pending_candidate=True, reply={'draft_text': draft},
                         reply_body_sha256=runner.digest(draft),
                         reply_priority={'time_band': '近7天'})
        candidate['commercial_fit']['eligible_candidate'] = True
        with tempfile.TemporaryDirectory() as tmp:
            items = list(ordered_items([candidate], {'111': candidate}, set(), set(), {}, Path(tmp)))
        self.assertEqual(len(items), 1)
        self.assertEqual(items[0]['draft'], draft)
        self.assertEqual(items[0]['reply_sha256'], runner.digest(draft))

    def test_pause_only_cleared_after_explicit_ready_click(self):
        with tempfile.TemporaryDirectory() as tmp:
            task=Path(tmp);marker=task/'batch-stop.json'
            marker.write_text(json.dumps({'user_pause':True}),encoding='utf-8')
            with self.assertRaises(RuntimeError):control.acknowledge_repaired_pause(task)
            self.assertTrue(marker.exists())
            marker.write_text(json.dumps({'user_pause':True,'ready_for_user_resume':True}),encoding='utf-8')
            control.acknowledge_repaired_pause(task)
            self.assertFalse(marker.exists())
            self.assertTrue((task/'pause-resume-events.jsonl').exists())

if __name__=='__main__':unittest.main()
