from pathlib import Path
import hashlib,json
T=Path(__file__).resolve().parent
P=Path('C:/积木软件工坊/项目/方隅公寓客户版');F=P/'work/parallel-integration-20261018/final-integration'
read=lambda p:json.loads(p.read_text('utf-8-sig'))
assert read(T/'flow-audit/FLOW-TESTS.json')['status']=='PASS'
assert read(T/'flow-audit/RULE-ROUNDTRIP.json')['passed']
before=read(F/'candidate-unified-v24/INPUT-SNAPSHOT.json')['files'];after=read(F/'candidate-unified-v25/INPUT-SNAPSHOT.json')['files']
changed=[{'path':k,'before':before.get(k),'after':after.get(k)} for k in sorted(before.keys()|after.keys()) if before.get(k)!=after.get(k)]
assert {r['path'] for r in changed}=={'work/shared-backend-integration/vendor-src/assistant/browser_login_window.py','work/shared-backend-integration/platform_runtime.py','work/ui-native-r57/workbench_backend.py'}
(T/'FLOW-CHANGES.json').write_text(json.dumps(changed,ensure_ascii=False,indent=2),encoding='utf-8')
body=(T/'prepare_v24.py').read_text('utf-8').replace('v24','v25').replace('v23','v24').replace('STARTUP-CHANGES.json','FLOW-CHANGES.json')
previous=read(F/'entry-v24/CANONICAL-DELEGATION-PREPARED.json')['launcher_sha256'].lower()
assert hashlib.sha256((P/'work/ui-native-r57/run_workbench.py').read_bytes()).hexdigest()==previous
body=body.replace('9a118e29e357f009b44eb7f85b5932845a32aef6e0c0f541dd428203a749429f',previous)
body=body.replace("assert read(T/'AUTO-TESTS.json')['status']=='PASS'","assert read(T/'AUTO-TESTS.json')['status']=='PASS'\nassert read(T/'flow-audit/FLOW-TESTS.json')['status']=='PASS'\nassert read(T/'flow-audit/RULE-ROUNDTRIP.json')['passed']")
(T/'prepare_v25.py').write_text(body,encoding='utf-8')
(T/'install_v25.py').write_text((T/'install_v24.py').read_text('utf-8').replace('v24','v25'),encoding='utf-8')
print(json.dumps({'changed_files':len(changed),'previous_launcher_verified':True}))
