from pathlib import Path
import ast,hashlib,json,os,re,subprocess,sys,zipfile,xml.etree.ElementTree as ET
sys.stdout.reconfigure(encoding='utf-8',errors='replace')
T=Path(__file__).resolve().parent
P=Path('C:/积木软件工坊/项目/方隅公寓客户版')
S=P/'work/parallel-integration-20261018/final-integration/stage-02/project'
helper=S/'work/shared-backend-integration/vendor-src/assistant/browser_login_window.py'
runtime=S/'work/shared-backend-integration/platform_runtime.py'
h=hashlib.sha256(helper.read_bytes()).hexdigest().upper()
body,n=re.subn(r"_BROWSER_LOGIN_HELPER_SHA = '[A-F0-9]{64}'","_BROWSER_LOGIN_HELPER_SHA = '"+h+"'",runtime.read_text('utf-8'));assert n==1
runtime.write_text(body,encoding='utf-8')
fixtures=[('work/ui-native-r57/test_workbench_backend.py','test_workbench_backend.py'),('work/reply-integration/test_reply_workflow.py','test_reply_workflow.py'),('work/reply-delivery/test_delivery.py','test_delivery.py'),('work/rule-bundle/client/test_client.py','test_rule_client.py')]
for source,name in fixtures:
 body=(P/source).read_text('utf-8')
 body,n=re.subn(r'ROOT\s*=\s*Path\(__file__\)\.resolve\(\)\.parents\[\d\]',lambda _:f'ROOT=Path({S.as_posix()!r})',body);assert n==1
 body=body.replace("dir=ROOT/'work/reply-delivery'","dir=Path(__file__).parent").replace("dir=ROOT/'work/reply-integration'","dir=Path(__file__).parent")
 body=body.replace("self.assertEqual(store.exception.code,'STORE_FORBIDDEN')","self.assertIn(store.exception.code,('STORE_FORBIDDEN','STORE_REQUIRED'))")
 (T/name).write_text(body,encoding='utf-8')
fixture=T/'test_workbench_backend.py'
body=fixture.read_text('utf-8').replace('class CloudFixture:','class LegacyCloudFixture:')
body+='''
class CloudFixture(LegacyCloudFixture):
    """Only the external directory fixture is updated for the central contract."""
    def __call__(self,url,payload,token=''):
        if payload['operation']!='store_config_read':return super().__call__(url,payload,token)
        import copy,json,hashlib
        response=super().__call__(url,{**payload,'operation':'me'},token)
        compiled=json.loads(Path('C:/积木软件工坊/项目/方隅公寓客户版/work/central-store-config/compiled-fixture.json').read_text('utf-8-sig'))
        base=next(r['config'] for r in compiled['documents'] if r.get('doc_type')=='store_config_version')
        digest=lambda v:hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
        configs={k:{**copy.deepcopy(base),'store_id':k} for k in ('fixture-store-a','fixture-store-b')}
        allowed=list(configs) if self.user['role']=='admin' else [self.user.get('store_id','fixture-store-a')]
        rows=[{'id':k,'name':'合成门店 '+k,'materialKey':configs[k]['material_key'],'config_digest':digest(configs[k])} for k in allowed if k in configs]
        response.update(schema='store-config-v1',read_only=True,catalog_revision='synthetic-central-v1',catalog_digest='a'*64,actor={'username':self.user['username'],'role':self.user['role']},scope={'type':'company' if self.user['role']=='admin' else 'store','store_ids':[r['id'] for r in rows]},stores=rows)
        if payload.get('store_id'):
            k=payload['store_id'];response.update(store_id=k,config=configs[k],config_digest=digest(configs[k]))
        return response
'''
fixture.write_text(body,encoding='utf-8')
tree=ast.parse(helper.read_text('utf-8'))
js=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='VERIFICATION_OBSERVATION_JS' for t in n.targets))
(T/'verification-observation.js').write_text(js,encoding='utf-8')
checks=[]
commands=[[sys.executable,'-B',str(T/n)] for n in ['test_reply_workflow.py','test_delivery.py','test_rule_client.py']]
commands[2]+=['ClientTest.test_rule_actions_recheck_true_admin_and_never_forward_operator','ClientTest.test_invalid_chunk_is_rejected_before_cloud_and_unknown_commit_is_explicit']
commands += [[sys.executable,'-B',str(T.parent/'test_auto_verification.py')],['node',str(T/'test_qr_observation.mjs')]]
for i,command in enumerate(commands):
 r=subprocess.run(command,cwd=T,capture_output=True,encoding='utf-8',errors='replace',env={**os.environ,'PYTHONIOENCODING':'utf-8'},timeout=100)
 output=r.stdout+r.stderr;(T/f'FLOW-CHECK-{i+1}.log').write_text(output,encoding='utf-8')
 count=re.search(r'Ran (\d+) tests?',output)
 row={'test':Path(command[-1]).name,'passed':r.returncode==0,'count':int(count[1]) if count else None};checks.append(row);print(json.dumps(row),flush=True)
 if r.returncode:print(output[-1800:],flush=True)
file=P/'outputs/验证续接实测/客户清单82位.xlsx'
ns={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
with zipfile.ZipFile(file) as z:
 root=ET.fromstring(z.read('xl/worksheets/sheet1.xml'));rows=root.findall('m:sheetData/m:row',ns)
 text=' '.join(n.text or '' for n in root.iter() if n.tag.endswith('}t'))
 header=[''.join(c.itertext()) for c in rows[0]]
 export={'rows':len(rows)-1,'bytes':file.stat().st_size,'technical_strings':re.findall(r'(?i)(?:C:\\Users|tenant_id|sourceDigest|rule_version|traceback)',text),'header':header}
 assert export['rows']==82 and not export['technical_strings'],export
(T/'EXPORT-82-CHECK.json').write_text(json.dumps(export,ensure_ascii=False,indent=2),encoding='utf-8')
report={'status':'PASS' if all(r['passed'] for r in checks) else 'FAIL','checks':checks,'export':export,'synthetic_external_calls_only':True,'real_messages_sent':0}
(T/'FLOW-TESTS.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
assert report['status']=='PASS'
