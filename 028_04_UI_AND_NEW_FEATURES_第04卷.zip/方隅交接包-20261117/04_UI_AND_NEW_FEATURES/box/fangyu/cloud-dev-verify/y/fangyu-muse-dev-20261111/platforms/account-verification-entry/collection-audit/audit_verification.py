"""Existing owned-session/manual-verification path: source review and offline RED.

Does not open any browser or read any real credentials. Fake HOME contains only
an inert JSON fixture; no SDK, CLI process or platform transport is initialized.
"""
from pathlib import Path
import ast,hashlib,json,os,sys,time
sys.dont_write_bytecode=True
H=Path(__file__).resolve().parent
P=Path('C:/积木软件工坊/项目/方隅公寓客户版')
S=P/'work/parallel-integration-20261018/final-integration/stage-02/project'
SRC=S/'work/ui-runtime-r55/src'
SDK=P/'work/speed-collection-worker/component/artifacts/platform-cli-guarded/_internal/xhs_cli'
def audit(event,args):
    if event in ('socket.connect','socket.bind','subprocess.Popen','os.system','os.startfile'):
        raise RuntimeError('Review prohibits network, processes and UI')
    if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
        mode,flags=args[1] or '',args[2] or 0
        write=any(c in str(mode) for c in 'wax+') or isinstance(flags,int) and flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC)
        if write and not Path(os.fsdecode(args[0])).absolute().is_relative_to(H):
            raise RuntimeError('Review writes only its own evidence')
sys.addaudithook(audit)
sys.path.insert(0,str(SRC))
from core.xhs_page_process import PageWorker,PageWorkerError
from assistant.xhs_cli_page_worker import page_key,digest

files={
 'runtime':S/'work/shared-backend-integration/platform_runtime.py',
 'owned_browser_helper':S/'work/shared-backend-integration/vendor-src/assistant/browser_login_window.py',
 'helper_argv':SRC/'assistant/owned_helper_process.py',
 'session_commit':SRC/'assistant/browser_session_commit.py',
 'identity_recovery':SRC/'core/xhs_identity_recovery.py',
 'page_worker':SRC/'core/xhs_page_process.py',
 'page_child':SRC/'assistant/xhs_cli_page_worker.py',
 'SDK_client':SDK/'client.py','SDK_exceptions':SDK/'exceptions.py'}
needles={
 'runtime':['def open_account_verification','def _recovery_candidate_provider','def _recover_xhs_identity','def _readiness',"code=='account_review_required'",'def _begin_cli_pages','scope=hashlib.sha256','def resume_acquisition'],
 'owned_browser_helper':['XHS_ENTRY_URL =','def _persistent_profile_path','def finish(self, *, explicit=False)','capture.flag','explicit_capture_only:controller.automatic_attempted','storage_path=str(storage_path)'],
 'helper_argv':['def login_helper_argv'],
 'session_commit':['def account_revision','def commit_identity_revalidation',"stage':'identity_revalidated'","pending['auth_generation']",'identity_revalidation_generation=attempt.attempt_id'],
 'identity_recovery':['def scan_activity',"stage == 'identity_revalidated'",'def begin_identity_revalidation'],
 'page_worker':['def request',"previous.get('state') in ('received','acknowledged')",'return result[\'stdout\']',"legacy_unsent=(",'def fingerprint'],
 'page_child':['def page_key','Refreshing a note'],
 'SDK_client':['def _handle_response','verify_type=resp.headers','verify_uuid=resp.headers'],
 'SDK_exceptions':['class NeedVerifyError','Captcha required: type=']}
source={}
for name,path in files.items():
    data=path.read_bytes();text=data.decode('utf-8');lines=text.splitlines()
    source[name]={'path':str(path),'sha256':hashlib.sha256(data).hexdigest(),'anchors':{needle:[i+1 for i,line in enumerate(lines) if needle in line] for needle in needles[name]}}
frozen=json.loads((P/'work/speed-collection-worker/component/artifacts/FROZEN.json').read_text('utf-8'))
for key,relative in [('SDK_client','platform-cli-guarded/_internal/xhs_cli/client.py'),('SDK_exceptions','platform-cli-guarded/_internal/xhs_cli/exceptions.py')]:
    pin=next(row for row in frozen['outputs'] if row['relative']==relative)
    source[key]['frozen_manifest_sha_matches']=source[key]['sha256']==pin['sha256'].lower()
    assert source[key]['frozen_manifest_sha_matches']

# Strictly fake account/task. No real account directory or cookie file is read.
fixture=H/'red-fixture';home=fixture/'synthetic-account';home.mkdir(parents=True,exist_ok=True)
config=home/'.xiaohongshu-cli';config.mkdir(exist_ok=True)
cookie=config/'cookies.json';cookie.write_text('{"synthetic_fixture_generation":1}',encoding='ascii')
spec={'argv':[sys.executable],'env':{'HOME':str(home)},'cwd':str(H)}
args=['comments','https://www.xiaohongshu.com/explore/synthetic','--json']
scope='a'*64;job='synthetic-task';key=page_key(args)
stats={'guard_calls':0,'process_starts':0}
def guard():stats['guard_calls']+=1
def worker():
    value=PageWorker(spec,job,scope,guard,protocol='task-bound-read-v1',recover_unsent=True)
    def never_start(*args):stats['process_starts']+=1;raise AssertionError('No process allowed')
    value._start=never_start
    return value
w=worker();path=w.receipts/(key+'.json')
result={'stdout':json.dumps({'error':{'code':'verification_required','message':'Captcha required: type=124, uuid=synthetic_fixture_only'}}),'stderr':'','returncode':1}
receipt={'version':1,'scope':scope,'task':job,'page':key,'args_digest':digest(args),'operation':'comments',
    'state':'acknowledged','created_at':time.time(),'wire_allow_attempts':1,'result':result,'digest':digest(result)}
w._save(path,receipt);before=path.read_bytes()
assert w.request(args)==tuple(result[k] for k in ('stdout','stderr','returncode'));w.close()
# Emulate only a changed local credential file and fresh parent process.
# This is NOT an actual identity commit or real authorization grant.
cookie.write_text('{"synthetic_fixture_generation":2}',encoding='ascii')
w2=worker();assert w2.request(args)==tuple(result[k] for k in ('stdout','stderr','returncode'));w2.close()
assert path.read_bytes()==before and stats['process_starts']==0
unknown={k:v for k,v in receipt.items() if k not in ('result','digest')};unknown.update(state='unknown',error_type='TimeoutError')
w3=worker();w3._save(path,unknown)
try:w3.request(args)
except PageWorkerError as error:assert error.code=='CLI_PAGE_UNCONFIRMED'
else:raise AssertionError('Unknown prior wire unexpectedly allowed')
w3.close();assert stats['process_starts']==0
repro={'status':'RED_CONFIRMED_ACKED_CAPTCHA_CACHED_AFTER_FRESH_SYNTHETIC_SESSION',
 'confirmed':['Existing worker returns exact acknowledged failed CAPTCHA without spawning',
    'New worker after synthetic credential-file change still returns the exact failed page',
    'Prior unknown with one allowed wire remains blocked; no replay'],
 'scope_explanation':'Runtime scope uses actor tenant/username, task id, identity six-tuple and task binding; cookie/auth_generation are not scope components',
 'fake_fixture_only':True,'real_credential_files_read':0,'real_platform_requests':0,'real_model_requests':0,'CLI_processes_started':stats['process_starts'],
 'UI_operations':0,'production_writes':0,'product_edits_by_reviewer':0,'page_worker_source_sha256':source['page_worker']['sha256']}
(H/'RESUME-RED.json').write_text(json.dumps(repro,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
facts={'status':'READ_ONLY_EXISTING_ACCOUNT_VERIFICATION_DESIGN','source_evidence':source,
 'SDK_diagnostic':{'fields':['verify_type','verify_uuid'],'verification_URL_provided':False,
   'current_cli_message':'Captcha required: type=<header>, uuid=<header>','raw_challenge_identifiers_exported':False},
 'existing_session_reuse':{'profile':'data/accounts/<tenant>/<account>/xhs-browser-profile',
   'browser':'WebView2 edgechromium','private_mode':False,'entry_URL':'https://www.xiaohongshu.com/explore',
   'exact_CAPTCHA_deeplink_available':False,'same_UID_requires_fresh_identity_proof':True,
   'capture':'registered owned keep-open helper + capture.flag + candidate ready/ACK',
   'CLI_sync':'_recover_xhs_identity + single status receipt + same-UID claim + commit_identity_revalidation',
   'current_check_dispatch_gap':'_readiness currently never emits account_review_required; check_account/connect_account recovery branches therefore do not handle this signal'},
 'resume_blocker':'PageWorker replays acknowledged failure from local journal forever; changing session does not invalidate this cached page',
 'limits':['No real browser session, challenge page or successful post-validation request was exercised',
    'Opening saved explore profile can expose account web context, but source contains no proven URL that directly presents challenge124',
    'Profile path alone is not proof of the visible logged-in UID; fresh same-UID capture/status must succeed before continuing'],
 'real_platform_requests':0,'real_model_requests':0,'CLI_processes_started':0,'real_credential_files_read':0,'UI_operations':0,'production_writes':0}
(H/'RESULT.json').write_text(json.dumps(facts,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':facts['status'],'red':repro['status'],'source_files':len(source),'real_requests':0,'real_credentials_read':0,'UI':0},ensure_ascii=False,indent=2))
