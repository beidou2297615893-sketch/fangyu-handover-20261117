// Check live strict refusal using a nonexistent ID; no platform request is issued.
const fs=require('fs'),path=require('path');
const base=path.resolve(__dirname,'../..');
const cfg=JSON.parse(fs.readFileSync(path.join(base,'抖音自用采集台/data/bridge.json'),'utf8'));
const id=JSON.parse(fs.readFileSync(path.join(__dirname,'identity-strict.json'),'utf8'));
const {BridgeClient}=require(path.join(base,'work/runtime/douyin-bridge/lib/client/bridge-client'));
const b=new BridgeClient(cfg.bridge);
(async()=>{
 const status=await b.status(), list=(status.connections?.['douyin.com']||[]).filter(c=>c.alive);
 if(list.length!==1||list[0].id!==id.connection_id)throw Error('Active connection changed');
 const denied=await b.call({site:'douyin.com',connId:'nonexistent-fangyu-proof',expression:'1',awaitPromise:true,timeout:3000});
 if(denied.ok!==false||!String(denied.error||'').includes('指定群工具连接已离线'))throw Error('Exact routing could not be verified');
 const proof={verified:true,source:'live strict service refused nonexistent connection; real identity probe matched same active connection',connection_id:id.connection_id,account_uid:id.account.sec_uid,observed_at:new Date().toISOString(),server_pid:37844};
 fs.writeFileSync(path.join(__dirname,'strict-proof.json'),JSON.stringify(proof,null,2),{flag:'wx'});
 console.log(JSON.stringify({strict:true,active_connection_verified:true,nonexistent_connection_refused:true}));
})().catch(e=>{console.error(e.message);process.exitCode=1});
