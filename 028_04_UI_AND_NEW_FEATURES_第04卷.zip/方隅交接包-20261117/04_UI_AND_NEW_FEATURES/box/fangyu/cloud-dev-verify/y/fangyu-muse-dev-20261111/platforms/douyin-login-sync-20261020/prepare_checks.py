from pathlib import Path
T=Path('C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/douyin-login-sync-20261020');old=T.parent/'reply-sender-choice-20261020'
s=(old/'prepare_v39.py').read_text('utf-8').replace('v39','v40').replace('v38','v39')
s=s.replace("'status':'PASS_SOURCE_CLOSURE_AND_EXPLICIT_REPLY_SENDER'", "'status':'PASS_SOURCE_CLOSURE_AND_DOUYIN_LOGIN_SYNC'")
a=s.index(",'explicit_uniform_sender'");b=s.index(",'native_UI_visual_review'",a)
s=s[:a]+",'jobless_douyin_auto_check':'PASS_RED_TO_GREEN','exact_account_scope':'PASS','verified_nickname_and_connected_status':'PASS','stop_on_close_switch_failure_timeout':'PASS','terminal_receipt_regressions':'PASS','js_syntax':'PASS'"+s[b:]
(T/'prepare_v40.py').write_text(s,encoding='utf-8');(T/'install_v40.py').write_text((old/'install_v39.py').read_text('utf-8').replace('v39','v40'),encoding='utf-8')
