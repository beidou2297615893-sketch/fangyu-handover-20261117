"""Explicitly enabled collector recovery; never replays an uncertain target."""
import copy, json, os, sqlite3, subprocess, sys, time, io
from contextlib import closing, redirect_stdout
from pathlib import Path
from collection_startup import startup_lock, recover_stale_leases, process_running, collection_pause_reason, control_for_start, StartupBlocked
ROOT=Path(__file__).resolve().parent
FLAGS=0x08000000

def bridge_listening():
    import socket
    try:
        with socket.create_connection(('127.0.0.1',19422),timeout=1):return True
    except OSError:return False

def ensure_bridge(node,config):
    if bridge_listening():return
    with (ROOT/'collection-bridge-recovery.log').open('ab') as out:
        subprocess.Popen([node,str(ROOT/'strict-bridge-server.cjs'),'--serve','--config',str(config),'--port','19422','--allow-owned-19422'],cwd=ROOT,stdout=out,stderr=out,creationflags=FLAGS)
    for _ in range(10):
        if bridge_listening():return
        time.sleep(.5)
    raise StartupBlocked('本地采集桥暂未就绪，正在自动恢复。')

def atomic(path,value):
    import uuid
    tmp=path.with_name(path.name+'.'+uuid.uuid4().hex+'.tmp')
    tmp.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
    for delay in (.02,.04,.08,.16,None):
        try:os.replace(tmp,path);return
        except PermissionError:
            if delay is None:raise
            time.sleep(delay)

def classify(message):
    if any(x in message for x in ('可能出验证码了','仍有平台验证','验证仍在','限流','账号异常','没有可用的已登录','原采集账号未核实')):return 'platform_verification'
    if '已使用当前登录页面' in message or '已在运行' in message:return 'running'
    if '发送' in message:return 'waiting_for_send'
    if '已用尽' in message or '没有关键词' in message:return 'sources_exhausted'
    return 'reconnecting'

def notify_verification():
    code="import tkinter as t,tkinter.messagebox as m,winsound;r=t.Tk();r.withdraw();r.attributes('-topmost',True);winsound.MessageBeep();m.showwarning('抖音采集需要处理','可能出验证码了。请检查抖音页面并完成验证；完成后自动继续，无需再点启动。',parent=r)"
    subprocess.Popen([str(Path(sys.executable).with_name('pythonw.exe')),'-c',code],creationflags=FLAGS)

def save_status(mode,message):
    from datetime import datetime
    path=ROOT/'current-collection-status.json'
    try:old=json.loads(path.read_text(encoding='utf-8'))
    except (OSError,ValueError):old={}
    value=dict(mode=mode,message=message,updated_at=datetime.now().astimezone().isoformat(),supervisor_pid=os.getpid())
    atomic(path,value)
    if (old.get('mode'),old.get('message'))!=(mode,message):
        print(time.strftime('%m-%d %H:%M:%S'),mode,message,flush=True)
    if mode=='platform_verification' and old.get('mode')!='platform_verification':
        try:notify_verification()
        except OSError:pass

def reconcile_unlocked():
    path=ROOT/'active-runner.json';a=json.loads(path.read_text(encoding='utf-8-sig'))
    if process_running(a.get('pid')):return a
    if a.get('status')=='running' or a.get('pid'):
        reason='process_exited'
        try:
            with (ROOT/a['stdout']).open('rb') as f:
                f.seek(max(0,(ROOT/a['stdout']).stat().st_size-16000))
                for line in reversed(f.read().splitlines()):
                    try:
                        event=json.loads(line);reason=event.get('reason') or event.get('state') or reason;break
                    except ValueError:continue
        except OSError:pass
        a.update(status='paused',last_exited_pid=a.get('pid'),pid=None,last_stop_reason=reason)
        atomic(path,a)
    return a

def reconcile():
    with startup_lock(ROOT):return reconcile_unlocked()

def should_stop(active):
    return (ROOT/'auto-collect.stop').exists() or (ROOT/active['directory']/'STOP').exists()

def send_busy():
    result=subprocess.run(['powershell','-NoProfile','-Command',
        "Get-CimInstance Win32_Process -Filter \"Name='python.exe' OR Name='pythonw.exe' OR Name='node.exe'\" | Select-Object -ExpandProperty CommandLine"],capture_output=True,text=True,creationflags=FLAGS,timeout=20)
    if result.returncode: return True
    return any(x in result.stdout for x in ('batch_reply_runner','send_cli_once','control.py'))

def probe_decision(verified):
    return 'ready' if verified else 'waiting_for_page'

def remaining_config(root,database,active,config):
    root=Path(root).resolve(); words=set(); videos=set(config.get('excluded_historical_videos',[])); accounts=set(config.get('collection_accounts',[]))
    directory=(root/active['directory']).resolve()
    if not directory.is_relative_to(root): raise StartupBlocked('断点目录不在采集目录内。')
    control=control_for_start(active,directory)
    pending=control.get('pending')
    if pending:
        path=Path(pending['record_path']).resolve()
        if not path.is_relative_to(directory): raise StartupBlocked('断点记录路径无法核对。')
        record=json.loads(path.read_text(encoding='utf-8-sig')); spec=record.get('spec',{})
        original=json.loads((root/active['plan']).read_text(encoding='utf-8-sig'))
        if (spec.get('request_id')!=pending.get('request_id') or any(spec.get(k)!=original[k] for k in ('account_uid','connection_id','scan_id'))):
            raise StartupBlocked('断点与原任务不一致，已保留原记录。')
        # Exclude the whole target whether saved, unknown, or prepared: never replay.
        if spec.get('keyword'): words.add(spec['keyword'])
        (words if spec['kind']=='search' else videos).add(spec['target'])
        accounts.add(spec['account_uid'])
    with closing(sqlite3.connect(Path(database).resolve().as_uri()+'?mode=ro',uri=True)) as db:
        for (raw,) in db.execute('SELECT spec FROM attempts'):
            spec=json.loads(raw)
            if spec.get('account_uid'): accounts.add(spec['account_uid'])
            (words if spec['kind']=='search' else videos).add(spec['target'])
    cfg=copy.deepcopy(config)
    cfg['stores']=[dict(st,keywords=[k for k in st['keywords'] if k not in words]) for st in cfg['stores']]
    if any(not st['keywords'] for st in cfg['stores']): raise StartupBlocked('剩余未尝试关键词已用尽，已保留断点。')
    cfg.update(excluded_historical_videos=sorted(videos),collection_accounts=sorted(accounts))
    return cfg

def start():
    import new_round
    if send_busy(): return '发送仍在运行，采集等待让路。'
    paused=collection_pause_reason(ROOT)
    if paused:return paused
    try:
        with startup_lock(ROOT):
            active=reconcile_unlocked()
            if process_running(active.get('pid')):return '采集已在运行，未重复启动。'
            if (ROOT/active['directory']/'STOP').exists():return '采集已按停止按钮暂停；断点已保留。'
            cfg=remaining_config(ROOT,new_round.DB,active,new_round.rd(new_round.CONFIG))
            recover_stale_leases(ROOT)
            if send_busy():return '发送仍在运行，采集等待让路。'
            ensure_bridge(new_round.NODE,new_round.BRIDGE)
            output=io.StringIO()
            with redirect_stdout(output):code=new_round._main(config_override=cfg)
            detail=output.getvalue().strip().splitlines()
            result='已使用当前登录页面继续采集。' if code==0 else (detail[-1] if detail else '采集页面暂未响应，正在自动重连。')
            mode=classify(result)
            if mode=='platform_verification':result='可能出验证码了。请检查抖音验证、限流或登录提示；完成后会自动继续，无需再点启动。'
            save_status(mode,result)
            return result
    except StartupBlocked as e:return str(e)
    except (OSError,ValueError,KeyError,sqlite3.Error,subprocess.TimeoutExpired) as e:
        return '采集恢复等待本地检查：'+type(e).__name__+'；未知记录已保留。'

def ensure_supervisor():
    with startup_lock(ROOT):
        state=ROOT/'current-collection-supervisor.json'
        old=json.loads(state.read_text(encoding='utf-8')) if state.exists() else {}
        if process_running(old.get('pid')):return
        with (ROOT/'current-collection-supervisor.log').open('ab') as out:
            p=subprocess.Popen([sys.executable,str(Path(__file__).resolve()),'--watch'],cwd=ROOT,stdout=out,stderr=out,creationflags=FLAGS)
        state.write_text(json.dumps({'pid':p.pid,'enabled_by':'user explicit continue 2026-11-10'}),encoding='utf-8')

def watch_loop():
    retries=0;last_refresh=0
    while True:
        time.sleep(15)
        try:
            a=reconcile()
            if should_stop(a):save_status('user_stopped','采集已按停止要求暂停，断点已保留。');return
            if process_running(a.get('pid')):
                retries=0;save_status('running','采集运行中。');continue
            result=start()
            mode=classify(result);save_status(mode,result)
            if mode=='sources_exhausted':return
            retries=retries+1 if mode=='reconnecting' else 0
            if retries>=2 and time.monotonic()-last_refresh>=300:
                refresh_current_page();last_refresh=time.monotonic()
            if '已使用当前登录页面' not in result:time.sleep(45)
        except Exception as error:
            try:save_status('reconnecting','本地检查暂未完成，正在自动重试：'+type(error).__name__)
            except Exception:pass

def refresh_current_page():
    import new_round
    result=subprocess.run([new_round.NODE,str(ROOT/'collection_refresh_page.cjs'),str(new_round.BRIDGE)],cwd=ROOT,capture_output=True,text=True,timeout=30,creationflags=FLAGS)
    try:diagnosis=json.loads(result.stdout)
    except ValueError:return
    if diagnosis.get('challenge_visible') is True:
        save_status('platform_verification','可能出验证码了。请完成抖音页面验证，完成后自动继续。')
    elif diagnosis.get('refreshed') is True:
        save_status('reconnecting','已自动刷新当前抖音页面，正在等待连接恢复。')

def watch():
    # A second watcher exits immediately even if its PID state was stale.
    import msvcrt
    with (ROOT/'collection-supervisor-worker.lock').open('a+b') as handle:
        handle.seek(0)
        try:msvcrt.locking(handle.fileno(),msvcrt.LK_NBLCK,1)
        except OSError:return
        try:watch_loop()
        finally:
            handle.seek(0);msvcrt.locking(handle.fileno(),msvcrt.LK_UNLCK,1)

if __name__=='__main__':
    if '--watch' in sys.argv:watch()
    else:
        print(start(),flush=True);ensure_supervisor()
