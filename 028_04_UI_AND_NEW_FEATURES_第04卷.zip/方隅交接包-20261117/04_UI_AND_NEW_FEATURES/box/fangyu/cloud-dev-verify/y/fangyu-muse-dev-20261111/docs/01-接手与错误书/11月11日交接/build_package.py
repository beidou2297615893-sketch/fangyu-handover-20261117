from pathlib import Path
import hashlib,json,re,sqlite3,time,zipfile,os
R=Path('C:/Users/rmsama/Documents/ChatGPT/自动获客系统')
B=R.parent/'codex-briefs-20261110'
K=Path('C:/积木软件工坊/项目/方隅公寓客户版')
W=K/'work/handoff-package-20261111'
OUT=K/'outputs/软件完整交接'
DEST=OUT/'方隅软件交接包'
DEST.mkdir(parents=True,exist_ok=True)
records=[]
skipdirs={'node_modules','.git','__pycache__','.venv','venv','site-packages','logs','log','backups','backup','sessions','profiles','browser-profile','live-tasks'}
exts={'.py','.js','.cjs','.mjs','.ts','.tsx','.jsx','.html','.css','.sql','.md','.txt','.toml','.yaml','.yml','.json'}
secretnames=re.compile(r'(^\.env|cookies?\.(json|txt)|tokens?\.(json|txt)|credentials|passwords?\.|storage.?state|production-workspace|session-state|auth-state|account-profiles)',re.I)
secretvalue=re.compile(r'(?:sk-[A-Za-z0-9_-]{20,}|Bearer\s+[A-Za-z0-9._-]{24,}|(?:api_key|access_token|refresh_token|password|cookie)\s*[=:]\s*[\x22\x27][A-Za-z0-9/+=._%-]{20,}[\x22\x27])',re.I)
private=re.compile(r'(?<!\d)1[3-9]\d{9}(?!\d)|[A-Za-z0-9._%+-]+@(?!example\.|test\.|localhost)[A-Za-z0-9.-]+\.[A-Za-z]{2,}')
def add(p,rel,images=False):
    row={'source':str(p),'destination':str(rel)}
    try:
        if p.is_symlink(): reason='link'
        elif p.suffix.lower() not in (exts|({'.png','.jpg','.jpeg','.webp','.svg','.woff','.woff2'} if images else set())):reason='excluded_type'
        elif secretnames.search(p.name):reason='credential_or_runtime_binding_name'
        elif p.stat().st_size>8*1024*1024:reason='large_file_review_required'
        elif p.suffix.lower()=='.json' and not any(s in str(p).lower() for s in ('rules','keywords','mothers','stores','schema','manifest','package.json','source.json','verification','regression','offline','loopback')):reason='runtime_json_not_exported'
        else:
            raw=p.read_bytes()
            if p.suffix.lower() in exts:
                text=raw.decode('utf-8-sig',errors='replace')
                if secretvalue.search(text):reason='possible_embedded_secret'
                elif p.suffix.lower() in {'.md','.txt','.json'} and private.search(text):reason='possible_private_contact_data'
                else:reason=None
            else:reason=None
            if reason is None:
                dst=DEST/rel;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(raw)
                row.update(status='included',bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest());records.append(row);return
        row.update(status='excluded',reason=reason)
    except (OSError,ValueError) as e:row.update(status='excluded',reason=type(e).__name__)
    records.append(row)
def tree(root,rel,images=False):
    if not root.exists():records.append({'source':str(root),'status':'missing'});return
    for current,dirs,files in os.walk(root,followlinks=False):
        dirs[:]=[d for d in dirs if d.lower() not in skipdirs and not d.lower().startswith(('backup-','_backup')) and not (Path(current)/d).is_symlink()]
        for name in files:
            p=Path(current)/name
            parts=p.relative_to(root).parts
            if any(x.lower() in {'runtime','data','evidence','state','attempts','batches','queues'} for x in parts[:-1]) and p.suffix.lower() not in {'.py','.js','.cjs','.mjs','.sql'}:continue
            add(p,Path(rel)/p.relative_to(root),images)
for name in ['00-接手说明.md','已知错误与一键修复.md','AGENTS.md']:
    add(R/name,Path('01-接手与决策')/name)
for p in W.glob('*.md'):add(p,Path('01-接手与决策')/p.name)
for p in B.glob('*.md'):
    if p.name in {'HANDOFF.md','issues-20261110.md','ui-flow-20261110.md','HISTORY-COMMON.md'} or p.name.lower().startswith(('quiz','contract','patent')):continue
    if any(p.name.lower().startswith(s) for s in ('fangyu','douyin','xhs','reply-tone','rules-confirmed','handoff-','software-acceptance','user-change','product-spec','errorbook','ui-experience')):add(p,Path('01-接手与决策/历程与规格')/p.name)
for root in (R/'work').iterdir():
    if not root.is_dir():continue
    name=root.name
    if name=='fangyu-text-business-20261029':tree(root,'04-规则关键词与母句/'+name)
    elif name.startswith(('xhs-','douyin-','fangyu-douyin-','shared-acquisition-ledger','shared-ledger-reply','cli-window-handoff','filter-audit','软件代码整合备案')):tree(root,'02-本地链路/'+name)
I=K/'work/backend-integration-20261102'
for name in ['src','tests','overlay','vendor','docs']:tree(I/name,'03-软件候选/11月10日工作稿/'+name)
for name in ['README.md','CURRENT.json']:add(I/name,Path('03-软件候选/11月10日工作稿')/name)
add(I/'evidence/FINAL-VERIFICATION-r3.json',Path('03-软件候选/r3冻结验证回执.json'))
tree(K/'work/integration-20261111/backend','03-软件候选/11月11日独立候选')
for p in (K/'work/integration-20261111').glob('*.md'):add(p,Path('03-软件候选/审计与计划')/p.name)
tree(K/'work/integration-20261111/host-baseline/project','03-软件候选/现用宿主源码快照',True)
add(K/'work/integration-20261111/host-baseline/copy-receipt.json',Path('03-软件候选/宿主复制清单.json'))
add(K/'work/ui-native-r57/run_workbench.py',Path('03-软件候选/原桌面入口仅供阅读.py'))
for folder in ['简洁无小字界面','暖色公寓简洁界面']:
    tree(K/'outputs'/folder,'05-界面设计/'+folder,True)
tree(Path('C:/Users/rmsama/agent-tools/fangyu-ui-design/batch-07'),'05-界面设计/Grok原参考',True)
ledger=R/'work/shared-acquisition-ledger/shared.sqlite3'
target=DEST/'06-账本快照/共享业务账本.sqlite3';target.parent.mkdir(parents=True,exist_ok=True)
started=time.time()
with sqlite3.connect(ledger.as_uri()+'?mode=ro',uri=True,timeout=3) as src,sqlite3.connect(target) as dst:
    def progress(status,remaining,total):
        if time.time()-started>90:raise TimeoutError('snapshot deadline')
    src.backup(dst,pages=256,progress=progress,sleep=0.05)
    check=dst.execute('PRAGMA quick_check').fetchone()[0]
    if check!='ok':raise RuntimeError('snapshot integrity failed')
    dst.execute('PRAGMA wal_checkpoint(TRUNCATE)')
    dst.execute('PRAGMA journal_mode=DELETE')
src.close()
dst.close()
raw=target.read_bytes();records.append({'source':str(ledger),'destination':str(target.relative_to(DEST)),'status':'snapshot_included','bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
(DEST/'06-账本快照/使用说明.md').write_text('这是用户授权的本地共享业务账本一致性快照，包含业务个人信息，仅限授权接手使用，不公开上传。源账本未修改；快照不能当作最新任务、发送授权或恢复依据。未知不重发，不把快照覆盖回现用账本。账号会话与密码未导出。',encoding='utf-8')
(DEST/'文件清单与未收入项.json').write_text(json.dumps({'created_at':time.strftime('%Y-%m-%d %H:%M:%S'),'records':records},ensure_ascii=False,indent=2),encoding='utf-8')
(DEST/'先读这里.md').write_text('先阅读01-接手与决策/交接说明.md和界面最新要求.md，再查文件清单。此包是源码、规则、设计和业务账本快照交接，不是安装包，不可直接运行生产。凭据、登录态、浏览器依赖、客户原文批次和历史运行文件有排除，详见清单；不得声称全量运行环境已迁移。邮件系统尚未核实，不含私人邮件。后续AI按交接说明完成隔离实施与验证。',encoding='utf-8')
zip_path=OUT/'方隅软件与本地链路交接.zip'
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in DEST.rglob('*'):
        if p.is_file():z.write(p,p.relative_to(DEST))
with zipfile.ZipFile(zip_path) as z:
    bad=z.testzip()
    if bad:raise RuntimeError('zip verification failed')
    count=len(z.namelist())
result={'zip':str(zip_path),'files':count,'bytes':zip_path.stat().st_size,'sha256':hashlib.sha256(zip_path.read_bytes()).hexdigest(),'included':sum(x['status'] in {'included','snapshot_included'} for x in records),'excluded':sum(x['status']=='excluded' for x in records),'ledger_quick_check':check}
(W/'打包回执.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))
