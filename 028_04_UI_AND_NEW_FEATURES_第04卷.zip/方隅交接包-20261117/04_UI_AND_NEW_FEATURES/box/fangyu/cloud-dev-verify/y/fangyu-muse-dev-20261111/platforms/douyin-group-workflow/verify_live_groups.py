"""Validate public group UI evidence; never sends platform requests."""
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, 'C:/积木软件工坊/核心组件/work/douyin-group-workflow')
from group_observation import parse_group_dialog
from group_plan import plan

folder = Path(__file__).parent
now = datetime.now(timezone.utc)
rows = parse_group_dialog((folder/'live-group-dialog.txt').read_text(encoding='utf-8'),
                          '63949359344', '高司令（速凌电竞）', now.isoformat())
assert len(rows) == 7
assert sum(r['status']=='full' for r in rows) == 6
assert [r['member_count'] for r in rows] == [8,1000,1000,1000,1000,1000,1000]
assert rows[4]['required_follow_days'] == 30
assert rows[5]['gate'] == 'open'
output = dict(verified='live_public_dialog_read_and_parse_only', observed_at=now.isoformat(),
              mutations_performed=False, records=rows,
              plan=plan(dict(account_id='read-only-verification-not-bound',groups=rows),
                        ['速凌'],0,0,now))
target=folder/'live-group-verification.json'
target.write_text(json.dumps(output,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'parsed':len(rows),'full':6,'membership':1,'assertions':'passed',
                  'actual_join_or_forward':False},ensure_ascii=False))
