import unittest,tempfile,json
from pathlib import Path
from unittest.mock import patch
import current_collection as c

class Supervision(unittest.TestCase):
 def test_bridge_is_restarted_only_when_port_is_absent(self):
  with tempfile.TemporaryDirectory() as t,patch.object(c,'ROOT',Path(t)),patch.object(c,'bridge_listening',side_effect=[False,True]),patch.object(c.subprocess,'Popen') as spawn,patch.object(c.time,'sleep'):
   c.ensure_bridge('node','bridge-config-path')
   spawn.assert_called_once();self.assertIn('--allow-owned-19422',spawn.call_args.args[0])
  with patch.object(c,'bridge_listening',return_value=True),patch.object(c.subprocess,'Popen') as spawn:
   c.ensure_bridge('node','bridge-config-path');spawn.assert_not_called()
 def test_dead_running_is_reconciled_without_changing_unknown_control(self):
  with tempfile.TemporaryDirectory() as t:
   r=Path(t);(r/'run').mkdir();(r/'run'/'control.json').write_text('{"pending":{"request_id":"unknown"}}')
   (r/'out.log').write_text('{"state":"paused","reason":"ledger_unknown"}\n')
   a={'status':'running','pid':123,'directory':'run','stdout':'out.log','plan':'p'}
   (r/'active-runner.json').write_text(json.dumps(a));before=(r/'run'/'control.json').read_bytes()
   with patch.object(c,'ROOT',r),patch.object(c,'process_running',return_value=False):result=c.reconcile()
   self.assertEqual(result['status'],'paused');self.assertIsNone(result['pid']);self.assertEqual(result['last_stop_reason'],'ledger_unknown')
   self.assertEqual(before,(r/'run'/'control.json').read_bytes())
 def test_live_runner_is_not_rewritten_or_restarted(self):
  with tempfile.TemporaryDirectory() as t:
   r=Path(t);raw='{"status":"running","pid":123}';(r/'active-runner.json').write_text(raw)
   with patch.object(c,'ROOT',r),patch.object(c,'process_running',return_value=True):c.reconcile()
   self.assertEqual((r/'active-runner.json').read_text(),raw)
 def test_only_evidenced_platform_gate_prompts_verification(self):
  self.assertEqual(c.classify('当前页面仍有平台验证。'),'platform_verification')
  self.assertEqual(c.classify('采集桥连接失败'),'reconnecting')
  self.assertEqual(c.classify('已有启动／继续操作正在处理'),'reconnecting')
 def test_transient_unknown_is_reviewable_but_real_platform_response_is_not(self):
  from scoped_recovery import historical_identity_unverified
  for error in ('connection_changed','fetch_failed','bridge_result_not_established','page_unavailable'):
   self.assertTrue(historical_identity_unverified('unknown',{'ok':False,'transport_error':error}))
   self.assertFalse(historical_identity_unverified('unknown',{'ok':False,'transport_error':error,'value':{'status_code':1}}))
  self.assertFalse(historical_identity_unverified('platform_error',{'ok':True,'value':{'status_code':2147}}))
 def test_watch_retries_after_local_exception_then_recovers(self):
  with patch.object(c,'reconcile',side_effect=[OSError('temporary'),{'pid':None,'directory':'x'}]),patch.object(c,'save_status') as save,patch.object(c,'start',return_value='已使用当前登录页面继续采集。') as start,patch.object(c,'should_stop',return_value=False),patch.object(c.time,'sleep',side_effect=[None,None,KeyboardInterrupt]):
   with self.assertRaises(KeyboardInterrupt):c.watch_loop()
   start.assert_called_once();self.assertTrue(save.called)
 def test_verification_cleared_is_retried_without_another_button_click(self):
  with patch.object(c,'reconcile',return_value={'pid':None,'directory':'x'}),patch.object(c,'should_stop',return_value=False),patch.object(c,'process_running',return_value=False),patch.object(c,'save_status') as save,patch.object(c,'start',side_effect=['可能出验证码了。','已使用当前登录页面继续采集。']) as start,patch.object(c.time,'sleep',side_effect=[None,None,None,KeyboardInterrupt]):
   with self.assertRaises(KeyboardInterrupt):c.watch_loop()
   self.assertEqual(start.call_count,2)
   self.assertEqual([a.args[0] for a in save.call_args_list],['platform_verification','running'])
 def test_second_supervisor_cannot_enter_watch_loop(self):
  import msvcrt
  with tempfile.TemporaryDirectory() as t,patch.object(c,'ROOT',Path(t)),patch.object(c,'watch_loop') as loop:
   with (Path(t)/'collection-supervisor-worker.lock').open('a+b') as handle:
    handle.write(b'0');handle.flush();handle.seek(0);msvcrt.locking(handle.fileno(),msvcrt.LK_NBLCK,1)
    try:c.watch();loop.assert_not_called()
    finally:handle.seek(0);msvcrt.locking(handle.fileno(),msvcrt.LK_UNLCK,1)

if __name__=='__main__':unittest.main()
