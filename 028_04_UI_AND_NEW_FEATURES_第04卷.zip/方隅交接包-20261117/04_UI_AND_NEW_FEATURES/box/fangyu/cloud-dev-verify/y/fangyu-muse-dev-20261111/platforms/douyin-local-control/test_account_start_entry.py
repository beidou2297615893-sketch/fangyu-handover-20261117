"""Run the actual employee entry up to the no-send boundary in a temporary root."""
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import control
import startup_recovery
import test_account_batch as fixtures

COMMON=fixtures.ACTUAL.parent/'douyin-local-control'

class AccountStartEntry(unittest.TestCase):
    def test_real_explicit_entry_discovers_new_identity_and_never_republishes_queue(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);p,source,manifest=fixtures.AccountBatch().fixture(root)
            for name in ('page_guard.cjs','attempt_recovery.py','account_batch.py'):(p/name).write_text('fixture')
            before=fixtures.hashes(source)
            ident={'account_uid':'new-uid','nickname':'new','connection_id':'new-connection'}
            seen=[]
            def probe(timeout=None,*,discover_current=False):
                self.assertTrue(discover_current)
                return ident
            def resolution(identity,task):
                self.assertEqual(identity,ident)
                queue=json.loads((task/'approved-cli-queue.json').read_text(encoding='utf-8'))
                self.assertEqual(queue['items'],manifest['items'])
                self.assertEqual(queue['account_uid'],'new-uid')
                self.assertEqual(json.loads((task/'cli-current-binding.json').read_text(encoding='utf-8'))['account_uid'],'new-uid')
                seen.append(task)
                raise RuntimeError('OFFLINE_REACHED_READY_NO_SEND')
            with patch.object(control,'P',p),patch.object(control,'ROOT',root), \
                 patch.object(sys,'argv',['control.py','--employee-start']), \
                 patch.object(control,'employee_start',return_value=True), \
                 patch.object(control,'require_send_allowed'),patch.object(control,'ensure_local_bridge'), \
                 patch.object(control,'foreign_runner_locked',return_value=False), \
                 patch.object(control,'probe',side_effect=probe), \
                 patch.object(control,'resolve_task_on_start',side_effect=resolution), \
                 patch.object(control.subprocess,'run',side_effect=AssertionError('No publisher, sender or real probe allowed')):
                control.main()
            self.assertEqual(len(seen),1)
            self.assertEqual(json.loads((p/'status.json').read_text(encoding='utf-8'))['message'],'OFFLINE_REACHED_READY_NO_SEND')
            self.assertEqual(fixtures.hashes(source),before)
            self.assertEqual(json.loads((p/'active.json').read_text(encoding='utf-8'))['account_uid'],'new-uid')
            # Execute a VM copy of the new adapter, with fake network and fake post.
            check=subprocess.run(['node',str(COMMON/'test_identity_adapter.cjs'),str(seen[0]/'send_cli_once.cjs')],
                                 capture_output=True,text=True,encoding='utf-8',timeout=15)
            self.assertEqual(check.returncode,0,check.stderr)
            self.assertIn('11 VM scenarios passed',check.stdout)

    def test_probe_defaults_strict_and_discovery_is_opt_in(self):
        calls=[]
        def run(args,**kw):
            calls.append(args)
            return subprocess.CompletedProcess(args,0,stdout='{"account_uid":"fixture"}',stderr='')
        with patch.object(control.subprocess,'run',side_effect=run):
            control.probe(timeout=1)
            control.probe(timeout=1,discover_current=True)
        self.assertNotIn('--discover-current-account',calls[0])
        self.assertEqual(calls[1][-1],'--discover-current-account')

if __name__=='__main__':unittest.main()
