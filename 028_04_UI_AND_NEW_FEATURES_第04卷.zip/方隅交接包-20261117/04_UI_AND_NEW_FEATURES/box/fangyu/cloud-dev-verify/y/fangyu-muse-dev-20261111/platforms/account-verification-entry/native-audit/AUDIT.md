# “去验证”原生入口只读审计

结论：现有工程已经有精确账号原生验证窗口，应该复用，不需要新装浏览器、重新扫码或给主工作台放开任意外链。当前真实账号不满足现成 `_recover_xhs_identity` 的旧日志扫描准入；但**普通浏览器候选同UID核验与原子会话提交不受旧活动日志阻挡**，可以复用，而不能把“窗口已打开”写成“验证并恢复成功”。下文普通连接结论已按实际代码更正。

源根目录为 `C:/积木软件工坊/项目/方隅公寓客户版/work/parallel-integration-20261018/final-integration/stage-02/project`。以下行号为本次读取时的源文件行号。

## 现成调用链

| 层级 | 文件与位置 | 当前接口 |
| --- | --- | --- |
| UI actions | `work/ui-approved-implementation/ui-preview/app.mjs:466–471,569` | `openAccountVerification(id)` 经 `accountSafetyOperation`；注意该函数把参数解释为 platformId，再取当前平台选中账号，不能传 task.accountId 冒充 platformId。 |
| 前端 HTTP | `work/ui-approved-implementation/ui-preview/backend.mjs:137` | `openAccountVerification(accountId)` 发 `account_verification_open`，仅 accountId，无 URL/路径参数。 |
| 本机入口 | `work/ui-native-r57/ui_native_host.py:38,303` | action 已在 allowlist；同源 CSRF API分发。 |
| 新工作台后台 | `work/ui-native-r57/workbench_backend.py:889–947` | fresh `_identity`、当前选店、账号ID格式；转 `platform_runtime.open_account_verification(user,{accountId})`。 |
| 运行时 | `work/shared-backend-integration/platform_runtime.py:1080–1179` | 精确账号持久化 WebView2 窗口；已有注册窗口发 focus.flag复用，没有则注册手动验证job并启动已校验helper。 |
| helper argv | `work/ui-runtime-r55/src/assistant/owned_helper_process.py:91–111`；运行时 `platform_runtime.py:1155–1161` | 固定 live/stage/cancel/profile 参数，运行时追加 `--keep-open --explicit-capture-only`。不接受客户传入的任意 URL或用户Chrome目录。 |
| 实际原生实现 | `work/shared-backend-integration/vendor-src/assistant/browser_login_window.py:61,675–790` | 固定 `https://www.xiaohongshu.com/explore`；pywebview + edgechromium，`js_api=None`，精确账号 storage_path，非private持久化会话。此vendor版本有keep-open等能力，不能误用r55基础文件中较早的实现。 |

## 账号、任务、设备与窗口绑定

- `PlatformRuntime._principal:180–192` 复核本地用户、tenant、role、cloud_bound、当前工作台店；不允许其他客户/owner。
- `_executor:235–255` 与 `_readiness:284–304` 保留设备、lease、平台许可、远程暂停和未完成身份提交约束。
- `_account:257–269` 做 tenant/account访问；管理员额外要求自身owner与当前store精确一致。
- `_task:271–282` 复核同tenant/task访问；管理员额外要求owner/currentstore精确一致。新按钮必须先 `_task(user,taskId)`，再用其 `account_id` 取得账号，不使用UI当前选中的另一个账号。
- `open_account_verification:1090–1110` 拒绝禁用、撤销、UID冲突、身份未知、恢复提交未完；要求已有非空平台UID和既有 `accounts/<tenant>/<account>/xhs-browser-profile`，不会创建一个可假冒旧会话的新profile。
- `_profile_scope` 位于 vendor `browser_login_service.py:187–203`；拒绝目录外跳转、符号链接、junction/reparse。stage同样限定在此账号 `work/browser-login/<job>`（163–184）。
- `_verification_windows:1031–1038` 只匹配同account、owner_id、tenant_id、purpose=`manual_verification`、仍活跃worker/process；existing分支1120–1123发focus，不重复创建窗口。
- `_verification_idle:1040–1051` 不在该账号活跃采集/其它登录进程时打开；原任务必须先进入真实暂停。worker在helper存活期间持续authorize，失去原绑定会取消窗口（1164–1169）。

## 原生URL与bridge边界

主桌面 `ui_native_host.native_navigation_handler:925–941` 只允许本机稳定origin/about:blank与本机UUID blob。直接在主工作台加载小红书会被取消。不要修改成通用外部URL允许，也不要为这个功能新增任意命令/任意URL的网页JS桥。

成熟路径是在后台启动/聚焦**独立的账号所属helper窗口**。helper初始URL只有固定explore；`browser_login_window._is_xhs_origin:155–162` 在身份观察/候选读取边界只接受HTTPS `www.xiaohongshu.com`（无userinfo，端口默认/443）。它不是主工作台的任意外链授权，也不能宣称对整个helper人工浏览过程都实施了同样的导航取消策略。

`--explicit-capture-only` 会禁止自动身份尝试（helper750行）；候选读取只响应服务器在明确用户动作后写入的capture.flag（PersistentLoginWindowController.watch_requests:618–648）。现成 `ManualVerificationWindowController`（650–670）则完全不做capture/identity，但运行时当前选用的是带显式capture能力的keep-open路径，以支持随后同UID核验。不能把两者混称。

## “验证后继续”的现成链与当前限制

`check_account:868–891` 的普通状态检查，在需要身份恢复时走 `_recover_xhs_identity:893–985`。后者使用 `_recovery_candidate_provider:985–1029`，只接受同账号已注册且支持身份capture的唯一窗口；一次用户明确动作才发capture.flag，候选留在本机stage，使用单次status尝试核实原UID；提交成功后结果明确为 `collectionAuthorized=False,autoResume=False`。

`resume_acquisition:1997–2024` 已按 task.account_id 复核账号、当前设备/权限/任务条件，然后恢复同一task。它不应由窗口关闭事件、页面成功标记或旧HTTP461自动触发。

建议的最小新入口为 `acquisition_verification_open({taskId})` 和 `acquisition_verification_resume({taskId})`：两者都在服务器复核task后派生账号；open复用原窗口；resume只在本次显式同UID核验确实成功且权限/范围未变时继续原task。UI只需要“去验证”和“已验证，继续原任务”，不恢复本地人工复核锁，不清旧风险/journal。

**当前真实约束：** 只读 `OWNED-FLAGS.json` 确认原profile/CLI会话文件存在，账号ready且有UID，没有identity_recovery_pending或commit marker。没有读取Cookie内容。最新任务真实为paused。

但用当前真实 `core/xhs_identity_recovery.scan_activity` 读取同一账号日志：1024事件、pending40，其中10项nonrecoverable、2项unfinished、resolution0。因此 `IdentityAttempt.__init__:260–261` 会拒绝该历史状态。最近确有comments/sub-comments的HTTP461 + CLI verification_required配对，随后还有search API/进程异常；不能仅根据最后一条461忽略其它未完成记录。

这10项为读取链异常（sub-comments protocol_error、search api_error/protocol_error/not_authenticated/process_failed）；2项unfinished为sub-comments GET和search POST。它们不是输出中已证明的发送请求，但现成严格扫描仍拒绝，不能清日志、伪造回执或声称全部已对账。

## 新接线最小验证边界

只需隔离检查 task→account绑定、跨owner/store/task拒绝、缺原profile拒绝、精确原窗口focus、helper固定URL/argv、打开不触发采集/status/candidate自动读取、手动resume前fresh同UID结果、未确认结果不重放、旧失败保留。真实验证码必须由本人在原账号页面完成。没有真实原生操作证据时，只报告接线和隔离行为验证，不能报告实际平台验证通过。

本审计未打开任何界面、未调用平台/云、未修改产品/DB，未读取密码或Cookie文件内容。

## 普通候选会话路径：按实际实现更正

早先审计把 `require_account_safe` 的名字等同“旧活动日志人工复核锁”，由此推断普通连接也会因mixed日志拒绝。这一推断错误，已通知root并撤回。

当前 `core/adapters.py:505–518 require_account_safe` 只阻挡未完成version2 `.browser-session-commit.json`；没有扫描platform-activity。`core/account_safety.py:401–415` 明确输出observe和manual_review_enabled=False，不存在已被用户撤销的本地人工复核锁。不得恢复该锁。

普通服务 `service.start_account_login:1023–1031 → browser_login_service.start_browser_account_login:314–319 → xhs_browser_login.start_persistent_login` 确实复用同profile。当前stage不存在公开 `_validate_candidate` 函数；成熟实现是 `start_persistent_login:349–457` 内的status/claim/commit闭包及BrowserLoginCoordinator。可最小抽取为可调用的候选验证方法，为现有manual_verification job的stage/process使用，不必另开登录窗口。

- status：先 `_canonical_candidate_scope` 精确校验账号与候选，再 `adapters.execute('xiaohongshu',['status','--json'],canonical_account,candidate_home=canonical_candidate)`，每个不可变candidate只验一次。
- claim：使用已存在的 `service._claim_xhs_account`，保留云端原UID/重复身份约束。
- commit：fresh_snapshot后 `commit_browser_session`；仍保留身份/账号revision、窗口存活、取消、设备/云许可、candidate路径和同UID检查。
- `browser_session_commit.py:385–495` 的普通提交不扫描或清理旧活动日志；473–475行成功后更新 `auth_generation=nonce` 并原子保留新会话。

因此可以基于本次明确成功的普通同UID候选核验与提交，为当前精确task/失败页签发独立的新attempt授权；这不表示旧未知page已被解决。具体grant签名/单次消费由该模块独立审查。窗口打开、网页看似登录、旧身份记录都不能替代本次完整协同结果。

旧通用 `src/app.py:1242–1249 account_browser_open → account_browser.py:7,23–25` 也不是XHS替代：PLATFORM_URLS仅列抖音、快手、知乎，小红书会明确要求工作台扫码入口。不要为本轮把该通用外部浏览器入口扩成任意小红书会话。

针对当前真实记录可用的通俗提示：

> 验证窗口已打开。该账号还保留未完成的读取记录，本次未恢复采集；原任务和客户数据已保留。

正常、无其它混杂风险的paired461记录可以走现成strict身份恢复；当前mixed历史也可以使用普通同UID候选提交路径，在成功后按精确新grant明确继续，不删除旧活动记录。本审计没有实际执行这条平台链路。
