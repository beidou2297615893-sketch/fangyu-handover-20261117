"""Consume explicit UI receipts only. No browser/network/sending capability."""
import argparse
from contextlib import closing
import datetime as dt
import hashlib
import json
import msvcrt
import os
from pathlib import Path
import re
import sqlite3
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
DETAILS = ROOT / 'work/fangyu-douyin-independent/reply-pilot'
DB = ROOT / 'work/shared-acquisition-ledger/shared.sqlite3'
CLI = ROOT / 'work/shared-acquisition-ledger/ledger.py'
EVENTS = DETAILS / 'ui-receipts.jsonl'
ACK = DETAILS / 'ui-receipts-ack.json'
LOCK = Path(__file__).with_suffix('.lock')
TOKEN = re.compile(r'^douyin-v3-(?:pilot-)?20261101-([0-9]+)$')


def now():
    return dt.datetime.now().astimezone().isoformat()


def atomic_json(path, data):
    temporary = path.with_name(path.name + '.bridge.tmp')
    with temporary.open('w', encoding='utf-8') as handle:
        json.dump(data, handle, ensure_ascii=False, indent=2)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, path)


def lookup(token):
    with closing(sqlite3.connect(DB.as_uri() + '?mode=ro', uri=True, timeout=0.5)) as conn:
        conn.row_factory = sqlite3.Row
        conn.execute('PRAGMA query_only=ON')
        result = conn.execute('SELECT * FROM reservations WHERE token=?', (token,)).fetchone()
    if result is None or result['platform'] != 'douyin':
        raise ValueError('No existing authorized Douyin reservation')
    return dict(result)


def validate(event):
    match = TOKEN.fullmatch(str(event.get('token', '')))
    if not match or match.group(1) != str(event.get('cid')):
        raise ValueError('Token or comment identity does not match this batch')
    if event.get('status') not in ('sent', 'unknown', 'not_sent'):
        raise ValueError('Unsupported explicit receipt status')
    if not isinstance(event.get('evidence'), str) or not event['evidence'].strip():
        raise ValueError('Explicit UI evidence required')
    for key in ('submitted_at', 'verified_at'):
        if event.get(key):
            dt.datetime.fromisoformat(str(event[key]).replace('Z', '+00:00'))
    if event.get('status') == 'sent' and not event.get('verified_at'):
        raise ValueError('Verified receipt time required for sent')
    filename = 'pilot.json' if 'pilot-' in event['token'] else str(event['cid']) + '.json'
    path = DETAILS / filename
    record = json.loads(path.read_text(encoding='utf-8-sig'))
    if str(record.get('comment_id', record.get('cid', ''))) != str(event['cid']):
        raise ValueError('Local attempt comment mismatch')
    return path, record


def consume(event):
    path, record = validate(event)
    row = lookup(event['token'])
    if row['comment'] != str(event['cid']):
        raise ValueError('Shared reservation comment mismatch')
    if row['status'] == event['status']:
        action = 'already_recorded'
    elif row['status'] == 'reserved':
        result = subprocess.run(
            [sys.executable, str(CLI), '--db', str(DB), 'outcome', event['token'],
             event['status'], event['evidence']],
            capture_output=True, text=True, encoding='utf-8', errors='replace',
            creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0,
            env={**os.environ, 'PYTHONIOENCODING': 'utf-8'})
        if result.returncode:
            message = result.stdout + result.stderr
            if 'database is locked' in message or 'database is busy' in message:
                raise sqlite3.OperationalError('database is locked')
            raise ValueError('Shared ledger rejected receipt: ' + message[:500])
        action = 'recorded'
    else:
        raise ValueError('Existing different final status; manual reconciliation required')
    confirmed = lookup(event['token'])
    if confirmed['status'] != event['status']:
        raise ValueError('Shared ledger readback mismatch')
    # Preserve existing historical evidence; never replace it with a new assertion.
    record['status'] = {'sent': 'sent_ui_verified', 'unknown': 'unknown',
                        'not_sent': 'not_sent'}[event['status']]
    record['receipt_evidence'] = confirmed['evidence']
    record['ui_receipt_evidence'] = event['evidence']
    for key in ('submitted_at', 'verified_at', 'screenshot'):
        if event.get(key):
            record[key] = event[key]
    record['automatic_retry'] = False
    record['receipt_bridge_recorded_at'] = now()
    atomic_json(path, record)
    return {'token': event['token'], 'cid': str(event['cid']), 'status': event['status'],
            'action': action, 'acknowledged_at': now(), 'verified_at': event.get('verified_at')}


def run():
    LOCK.parent.mkdir(parents=True, exist_ok=True)
    lock_handle = LOCK.open('a+b')
    lock_handle.seek(0)
    if not lock_handle.read(1):
        lock_handle.write(b'1'); lock_handle.flush()
    lock_handle.seek(0)
    try:
        msvcrt.locking(lock_handle.fileno(), msvcrt.LK_NBLCK, 1)
    except OSError:
        raise SystemExit('Another receipt bridge owns the local lock')
    state = json.loads(ACK.read_text(encoding='utf-8-sig')) if ACK.exists() else {
        'offset': 0, 'processed': 0, 'receipts': {}}
    if str(state.get('bridge_status', '')).startswith('blocked'):
        raise SystemExit('Prior bridge block requires explicit reconciliation')
    state.update(bridge_status='ready', process_id=os.getpid(), checked_at=now())
    atomic_json(ACK, state)
    while True:
        try:
            if not EVENTS.exists():
                time.sleep(1); continue
            with EVENTS.open('rb') as handle:
                if EVENTS.stat().st_size < state['offset']:
                    raise ValueError('Receipt stream truncated; refusing replay')
                handle.seek(state['offset'])
                raw = handle.readline()
                next_offset = handle.tell()
            if not raw or not raw.endswith(b'\n'):
                time.sleep(1); continue
            event = json.loads(raw.decode('utf-8-sig'))
            result = consume(event)
            result['event_sha256'] = hashlib.sha256(raw).hexdigest()
            state['receipts'][event['token']] = result
            state.update(offset=next_offset, processed=state['processed'] + 1,
                         last_receipt=result, checked_at=now(), bridge_status='ready')
            if event['status'] in ('unknown', 'not_sent'):
                state['bridge_status'] = 'blocked_' + event['status']
            atomic_json(ACK, state)
            if state['bridge_status'].startswith('blocked'):
                return
        except sqlite3.OperationalError as exc:
            if 'locked' in str(exc) or 'busy' in str(exc):
                time.sleep(1); continue
            state.update(bridge_status='blocked_error', error=str(exc), checked_at=now())
            atomic_json(ACK, state); return
        except Exception as exc:
            state.update(bridge_status='blocked_error', error=str(exc), checked_at=now())
            atomic_json(ACK, state); return


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--verify-existing')
    options = parser.parse_args()
    if options.verify_existing:
        row = lookup(options.verify_existing)
        if row['status'] != 'sent' or not TOKEN.fullmatch(row['token']):
            raise SystemExit('Expected a completed task token')
        print(json.dumps({'verified_read_only': True, 'token': row['token'],
                          'status': row['status'], 'would_skip_outcome_write': True}))
    else:
        run()
