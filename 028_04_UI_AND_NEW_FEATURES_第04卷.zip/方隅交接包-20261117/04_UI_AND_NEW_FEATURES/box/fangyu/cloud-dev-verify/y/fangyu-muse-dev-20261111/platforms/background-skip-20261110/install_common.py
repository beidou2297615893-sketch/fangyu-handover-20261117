"""Install tested shared code only while every existing sender lock is free.

Never starts/resumes a sender and never migrates a production task here.
"""
import ast
import hashlib
import json
import msvcrt
import os
import subprocess
from contextlib import ExitStack
from datetime import datetime
from pathlib import Path

BASE=Path(__file__).resolve().parent
ROOT=BASE.parents[1]
DEST=ROOT/'work/douyin-local-control'
RUNTIME=['control.py','unknown_resolution.py','attempt_recovery.py','read_recovery.py',
         'startup_recovery.py','page_guard.cjs','account_probe.cjs','target_reader.cjs']
TESTS=['test_background_skip.py','test_identity_adapter.cjs','test_send_resume_runner.py',
       'test_employee_resume.py','test_read_recovery.py','test_target_reader.cjs']


def running_senders():
    command=r"""[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false); @(Get-CimInstance Win32_Process | Where-Object {
        $_.Name -match '^(python|pythonw|node).*' -and
        $_.CommandLine -match '(control\.py|batch_reply_runner\.py|send_cli_once\.cjs)'
        } | Select-Object ProcessId,Name) | ConvertTo-Json -Compress"""
    result=subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-Command',command],
        capture_output=True,text=True,encoding='utf-8',timeout=20,creationflags=subprocess.CREATE_NO_WINDOW)
    if result.returncode:
        raise RuntimeError('cannot establish sender process state')
    data=json.loads(result.stdout) if result.stdout.strip() else []
    return data if isinstance(data,list) else [data]


def main():
    with ExitStack() as stack:
        locks=[DEST/'control.lock']
        locks.extend(ROOT.glob('work/douyin-local-*/batch-runner.lock'))
        old=ROOT/'work/douyin-round2-task5/batch-runner.lock'
        if old.exists():locks.append(old)
        for path in locks:
            if not path.resolve().is_relative_to(ROOT):raise RuntimeError('lock outside project')
            handle=stack.enter_context(path.open('a+b'));handle.seek(0)
            try:msvcrt.locking(handle.fileno(),msvcrt.LK_NBLCK,1)
            except OSError:raise RuntimeError('sender still running; install deferred')
        active=running_senders()
        if active:raise RuntimeError('sender still running; install deferred')
        prior=BASE/'install-result.json'
        installed=json.loads(prior.read_text(encoding='utf-8')) if prior.exists() else {}
        for name in RUNTIME+TESTS:
            source=BASE/'stage'/name;before=BASE/'before'/name;target=DEST/name
            if before.exists():
                if (not target.exists() or (target.read_bytes()!=before.read_bytes()
                        and hashlib.sha256(target.read_bytes()).hexdigest()!=installed.get('files',{}).get(name))):
                    raise RuntimeError('shared source changed during preparation: '+name)
            elif target.exists() and hashlib.sha256(target.read_bytes()).hexdigest()!=installed.get('files',{}).get(name):
                raise RuntimeError('new destination already exists: '+name)
            if name.endswith('.py'):ast.parse(source.read_text(encoding='utf-8-sig'))
            else:
                result=subprocess.run(['node','--check',str(source)],capture_output=True,timeout=15,
                    creationflags=subprocess.CREATE_NO_WINDOW)
                if result.returncode:raise RuntimeError('syntax check failed: '+name)
        if running_senders():raise RuntimeError('sender appeared; install deferred')
        for name in RUNTIME+TESTS:
            target=DEST/name;temporary=target.with_name(target.name+'.background-install.tmp')
            temporary.write_bytes((BASE/'stage'/name).read_bytes());os.replace(temporary,target)
        after=running_senders()
        report={'installed_at':datetime.now().astimezone().isoformat(),'running_before':active,
            'running_after':after,'files':{name:hashlib.sha256((DEST/name).read_bytes()).hexdigest() for name in RUNTIME+TESTS},
            'production_task_migration_executed':False,'send_or_collection_started':False}
        (BASE/'install-result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
        print(json.dumps({'installed':True,'running_before':active,'running_after':after,'files_count':len(report['files'])}))


if __name__=='__main__':main()
