import json,os,subprocess,sys,tkinter as tk,msvcrt
from datetime import datetime, timezone, timedelta
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from tkinter.scrolledtext import ScrolledText
from tkinter import ttk
from send_hold import hold_reason
from summary import Summary
P=Path(__file__).resolve().parent
w=tk.Tk();w.title('抖音回复｜近30天进度');w.geometry('900x550')
tk.Label(w,text='抖音回复 · 本地任务',font=('Microsoft YaHei UI',17)).pack(pady=12)
s=tk.StringVar(value='请登录本轮账号，然后点击启动／继续')
tk.Label(w,textvariable=s,wraplength=920,font=('Microsoft YaHei UI',11)).pack()
child=None
def controller_running():
 try:
  with (P/'control.lock').open('a+b') as lock:
   lock.seek(0)
   try:msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
   except OSError:return True
   lock.seek(0);msvcrt.locking(lock.fileno(),msvcrt.LK_UNLCK,1)
  return False
 except OSError:return True
def start():
 global child
 if (child and child.poll() is None) or controller_running():
  s.set('任务正在运行，进度会自动更新。')
  return
 args=[str(Path(sys.executable).with_name('python.exe')),str(P/'control.py')]
 checking=bool(hold_reason())
 args.append('--check-resume' if checking else '--employee-start')
 try:
  child=subprocess.Popen(args,cwd=P.parents[1],creationflags=subprocess.CREATE_NO_WINDOW)
 except OSError as exc:
  s.set(f'无法打开检查进程。{exc}')
  return
 s.set('正在重新检查账号和近期队首…' if checking else '正在只读核对已提交的未知记录，然后按已审队列继续…')
 btn.config(state='disabled',text='检查中…' if checking else '启动中…')
btn=tk.Button(w,text='启动／继续',command=start,font=('Microsoft YaHei UI',14),padx=35,pady=9);btn.pack(pady=10)
button_help=tk.StringVar()
tk.Label(w,textvariable=button_help,wraplength=860).pack()
summary_text=tk.StringVar(value='正在读取近30天的符合条件评论…')
summary_frame=tk.LabelFrame(w,text='近30天业务评论',padx=10,pady=8)
summary_frame.pack(fill='x',padx=12,pady=5)
tk.Label(summary_frame,textvariable=summary_text,justify='left',anchor='w',
         wraplength=1040,font=('Microsoft YaHei UI',10)).pack(fill='x')
summary_reader=Summary()
summary_executor=ThreadPoolExecutor(max_workers=1)
live_executor=ThreadPoolExecutor(max_workers=1)
summary_future=None
live_future=None
def refresh_summary():
 global summary_future
 summary_future=summary_executor.submit(summary_reader.refresh)
 w.after(300,finish_summary)
def finish_summary():
 if not summary_future.done():
  w.after(300,finish_summary)
  return
 try:summary_text.set(summary_future.result())
 except Exception:
  if summary_reader.snapshot is None:summary_text.set('统计正在更新，稍后重试。发送进度见下方日志。')
 w.after(60000,refresh_summary)
live_text=tk.StringVar(value='正在读取回复进度…')
tk.Label(w,textvariable=live_text,anchor='w',justify='left',font=('Microsoft YaHei UI',14)).pack(fill='x',padx=20,pady=20)
def refresh_live():
 global live_future
 live_future=live_executor.submit(summary_reader.live)
 w.after(100,finish_live)
def finish_live():
 if not live_future.done():
  w.after(100,finish_live)
  return
 try:
  data=live_future.result()
  if data:
   live_text.set(f'符合条件 {data["total"]:,} 条　　本批可回复 {data["remaining"]:,} 条　　已回复 {data["sent"]:,} 条')
 except Exception:pass
 w.after(1500,refresh_live)
box=ScrolledText(w,wrap='word',font=('Microsoft YaHei UI',10));box.pack(fill='both',expand=True,padx=12,pady=10)
last=''
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def recent_progress(task):
 path=task/'runner-stdout.log'
 if not path.exists():return '等待发送进度…'
 lines=path.read_text(encoding='utf-8',errors='replace')[-40000:].splitlines()
 groups=[]; current=[]; allowed=False
 for line in lines:
  if line.startswith('选取原评论日期：'):
   if current:groups.append(current)
   current=[]; allowed=False
   try:
    value=line.split('：',1)[1].split('｜',1)[0].strip()
    date=datetime.fromisoformat(value.replace('Z','+00:00'))
    if date.tzinfo is None:date=date.replace(tzinfo=timezone.utc)
    age=datetime.now(timezone.utc)-date.astimezone(timezone.utc)
    allowed=timedelta(hours=-1) <= age <= timedelta(days=30)
   except (ValueError,IndexError):pass
  if allowed:current.append(line)
 if current:groups.append(current)
 return '\n'.join(line for group in groups[-3:] for line in group) or '等待近30天评论的发送进度…'
def poll():
 global last
 try:
  busy=(child is not None and child.poll() is None) or controller_running()
  hold=hold_reason()
  if busy:
   btn.config(state='disabled',text='检查中…' if hold else '运行中…')
  else:
   btn.config(state='normal',text='重新检查' if hold else '启动／继续')
  button_help.set('暂停期间可检查账号和近期队首。' if hold else '点启动／继续。已提交但回执未知时会先只读核对；只有完整确认没有本账号回复才跳过该条。核对不完整的单条保留未知，不重发。页面失联请刷新；出现验证、限流、账号异常或连续12条跳过时暂停。')
  d=read(P/'status.json') if (P/'status.json').exists() else {}
  if hold and d.get('mode')!='resume_check':
   message=hold
  else:
   message=d.get('message','请登录本轮账号，然后点击启动／继续')
  if (P/'active.json').exists():
   active=read(P/'active.json');task=Path(active['task'])
   state=read(task/'batch-runner-status.json') if (task/'batch-runner-status.json').exists() else {}
   message=active['nickname']+' ｜ '+message
   text=state.get('reason','')+'\n'+recent_progress(task)
   if text!=last:box.delete('1.0','end');box.insert('end',text);box.see('end');last=text
  s.set(message)
 except Exception as e:s.set('读取进度中：'+str(e))
 w.after(1500,poll)
poll();refresh_summary();refresh_live();w.mainloop()
