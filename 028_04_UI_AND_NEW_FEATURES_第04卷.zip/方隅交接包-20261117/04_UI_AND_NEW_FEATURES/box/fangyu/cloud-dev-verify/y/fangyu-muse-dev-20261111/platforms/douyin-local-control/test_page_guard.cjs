const {strict:assert}=require('node:assert');
const vm=require('node:vm');
const {assertPageReady, responseGate}=require('./page_guard.cjs');
async function probe({url='https://www.douyin.com/video/1',dialogs=[],visibleFrame=false,dead=false}) {
 const node=(text,visible)=>({innerText:text,getClientRects:()=>visible?[{}]:[],getBoundingClientRect:()=>({width:visible?120:0,height:visible?40:0})});
 const document={querySelectorAll:selector=>selector.includes('iframe')?(visibleFrame && selector.includes(visibleFrame)?[node('',true)]:[]):dialogs.map(([t,v])=>node(t,v))};
 const client={call:async({expression})=>dead?{ok:false}:{ok:true,connection:'fixed',value:vm.runInNewContext(expression,{location:new URL(url),document,
    getComputedStyle:()=>({display:'block',visibility:'visible',opacity:'1'})})}};
 return assertPageReady(client,'fixed');
}
(async()=>{
 await probe({});
 await probe({dialogs:[['请完成安全验证',false]]});
 await assert.rejects(probe({visibleFrame:'rmc.bytedance.com'}),/CURRENT_GATE:captcha/);
 await assert.rejects(probe({url:'https://www.douyin.com/ucenter/security/xyz'}),/CURRENT_GATE:captcha/);
 await assert.rejects(probe({dialogs:[['请完成安全验证',true]]}),/CURRENT_GATE:captcha/);
 await assert.rejects(probe({dialogs:[['操作过于频繁，请稍后再试',true]]}),/CURRENT_GATE:rate_limit/);
 await assert.rejects(probe({dead:true}),/CURRENT_GATE:page_unresponsive/);
 assert.equal(responseGate({status_code:3002123}),'');
 assert.equal(responseGate({status_code:3002123,status_msg:'请完成安全验证'}),'captcha');
 assert.equal(responseGate({status_code:429}),'rate_limit');
 assert.equal(responseGate({status_code:1,status_msg:'操作太频繁'}),'rate_limit');
 console.log('Page guard: 11 synthetic cases passed.');
})().catch(e=>{console.error(e);process.exitCode=1});
