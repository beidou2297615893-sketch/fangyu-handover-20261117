"""Resumable search -> comment batches, using the existing isolated CLI adapter."""
from copy import deepcopy
import hashlib
import re
from urllib.parse import urlsplit
from .selection import identity_decision

def _seen_note_key(platform,url):
    value=str(url or '')
    if platform=='xiaohongshu':
        match=re.fullmatch(r'/(?:explore|search_result)/([A-Za-z0-9]+)/?',urlsplit(value).path)
        if match:return 'xhs:'+match.group(1)
    return value

def _page_cursor(value):
    if (not isinstance(value,str) or not value or len(value)>512
            or any(char.isspace() or ord(char)<32 or ord(char)==127 for char in value)):
        return ''
    return value

def _advance_comment_page(state,info):
    if info.get('has_more') is True:
        cursor=_page_cursor(info.get('cursor'))
        if not cursor or cursor==state.get('cursor'):
            raise ValueError('评论还有下一页，但游标缺失或未前进；已暂停并保留断点')
        state['cursor']=cursor
        state.setdefault('cursor_history',[]).append(cursor)
    else:
        state['note_index']+=1
        state['current_note_counted']=False
        state['cursor']=''
        state['cursor_history']=[]

def _check_page(info, cursor, label, strict=False, history=()):
    if strict and type(info.get('has_more')) is not bool:
        raise ValueError(label+'分页状态缺失，已暂停并保留断点')
    if info.get('has_more') is True:
        next_cursor=_page_cursor(info.get('cursor'))
        if not next_cursor or next_cursor==cursor or next_cursor in history:
            raise ValueError(label+'还有下一页，但游标缺失或未前进；已暂停并保留断点')

def collect_batch(adapters, task, checkpoint, progress=None,*,before_read=None):
    report=progress or (lambda *args,**kwargs:None)
    platform=task['platform']
    if platform not in ('xiaohongshu','douyin','zhihu','wechat_channels'):
        raise ValueError('此平台尚未接入关键词到评论的完整流程')
    continuous=task.get('continuous_enabled') is True
    # The explicit workbench loop runs one Core batch at a time. It is not a
    # recurring scheduler, but must follow confirmed search pages to the end.
    complete_search=continuous or (platform=='xiaohongshu'
        and task.get('scope')=='search_comments'
        and task.get('continuous_enabled') is False
        and task.get('comment_keyword_mode','match')=='all'
        and task.get('region','')=='' and task.get('unknown_policy','exclude')=='exclude')
    fixed=continuous and task.get('scope')=='comments'
    keywords=([task.get('note_url')] if fixed else task.get('keywords')) or []
    if not keywords: raise ValueError('关键词评论采集至少需要一个关键词')
    state=deepcopy(task.get('pipeline') or {'keyword_index':0,'search_page':1,'notes':None,'note_index':0,
        'cursor':str(task.get('next_cursor') or '') if fixed else '', 'reply_queue':[]})
    state.setdefault('reply_queue',[])
    state.setdefault('browsed_notes',0)
    state.setdefault('current_note_counted',False)
    if platform=='xiaohongshu' and task.get('comment_depth','all')=='main' and state['reply_queue']:
        after=state.get('after_replies')
        if not isinstance(after,dict):
            raise ValueError('楼中楼断点缺少主评论分页信息；已暂停并保留断点')
        state['reply_queue']=[]
        state.pop('after_replies',None)
        _advance_comment_page(state,after)
    if state['keyword_index']>=len(keywords):
        task['_pipeline_next']=state
        return []
    if state['notes'] is None:
        if fixed:
            state['notes']=[{'url':task['note_url'],'title':task.get('content_title',''),
                'author':task.get('source_blogger',''),'author_id':task.get('source_blogger_id',''),
                'author_avatar_url':'','cover_url':'','published_at':''}]
            state['search_more']=False
            state['note_index']=0
            task['pipeline']=deepcopy(state)
            checkpoint()
        else:
            _discover(adapters,task,state,platform,keywords,complete_search,report,checkpoint,before_read)
    rows=[]
    # Re-check saved discovery against rules changed while the task was paused.
    while state['note_index']<len(state['notes']):
        note=state['notes'][state['note_index']]
        decision,_=identity_decision({**note,'source_type':'note'},{**task,'excluded_authors':[]})
        if decision!='exclude':break
        state['note_index']+=1;state['current_note_counted']=False;state['cursor']='';state['cursor_history']=[];state['reply_queue']=[];state.pop('after_replies',None)
    if state['note_index']<len(state['notes']):
        note=state['notes'][state['note_index']]
        source={'content_title':note.get('title',''),'note_url':note.get('url',''),
                'content_author':note.get('author',''),
                'content_author_avatar_url':note.get('author_avatar_url',''),
                'content_cover_url':note.get('cover_url',''),
                'content_published_at':note.get('published_at','')}
        if state['reply_queue']:
            root=state['reply_queue'][0]
            query={**task,'note_url':note['url'],'root_comment_id':root['id'],'next_cursor':root.get('cursor','')}
            report('reading_comments',discovered_notes=len(state['notes']),browsed_notes=state['browsed_notes'],current_source=source)
            if before_read:before_read()
            rows=adapters.sub_comments(platform,query)
            for item in rows:item.setdefault('parent_text',root.get('parent_text',''))
            info=query.get('_page_info',{})
            _check_page(info,root.get('cursor',''),'楼中楼',complete_search,root.get('cursor_history',[]))
            if info.get('has_more') is True:
                root['cursor']=_page_cursor(info.get('cursor'))
                root.setdefault('cursor_history',[]).append(root['cursor'])
            else:
                state['reply_queue'].pop(0)
                if not state['reply_queue']:
                    _advance_comment_page(state,state.pop('after_replies',{}))
        else:
            query={**task,'note_url':note['url'],'next_cursor':state.get('cursor','')}
            report('reading_comments',discovered_notes=len(state['notes']),browsed_notes=state['browsed_notes'],current_source=source)
            if before_read:before_read()
            rows=adapters.comments(platform,query)
            info=query.get('_page_info',{})
            _check_page(info,state.get('cursor',''),'评论',complete_search,state.get('cursor_history',[]))
            if not state['current_note_counted']:
                state['browsed_notes']+=1
                state['current_note_counted']=True
                report('reading_comments',browsed_notes=state['browsed_notes'])
            roots=query.get('_reply_roots',[]) if platform=='xiaohongshu' and task.get('comment_depth','all')=='all' else []
            if roots:
                root_text={str(item.get('comment_id') or ''):item.get('text','') for item in rows}
                pages=query.get('_reply_pages',[])
                if not isinstance(pages,list):pages=[]
                page_by_id={page['root_id']:page for page in pages
                            if isinstance(page,dict) and isinstance(page.get('root_id'),str)}
                state['reply_queue']=[]
                for ident in dict.fromkeys(roots):
                    page=page_by_id.get(str(ident),{})
                    cursor=_page_cursor(page.get('cursor'))
                    parent_text=page.get('parent_text')
                    if not isinstance(parent_text,str):parent_text=root_text.get(str(ident),'')
                    state['reply_queue'].append({
                        'id':ident,'cursor':cursor,
                        'cursor_history':[cursor] if cursor else [],
                        'parent_text':parent_text})
                state['after_replies']=info
            else:
                _advance_comment_page(state,info)
        parent_text={str(item.get('comment_id') or ''):item.get('text','') for item in rows}
        for item in rows:
            if item.get('parent_id'):item.setdefault('parent_text',parent_text.get(str(item['parent_id']),''))
            item.setdefault('note_url',note['url'])
            item.setdefault('url',note['url'])
            item.update(source_type='comment',content_author=note['author'],content_author_id=note['author_id'],content_title=note.get('title',''),
                content_author_avatar_url=note.get('author_avatar_url',''),content_cover_url=note.get('cover_url',''),
                content_published_at=note.get('published_at',''))
    if state['note_index']>=len(state['notes']):
        state['notes']=None
        state['note_index']=0
        if state.get('search_more'):
            state['search_page']+=1
            if platform=='wechat_channels':state['search_cursor']=state.get('next_search_cursor','')
        else:
            state['keyword_index']+=1
            state['search_page']=1
            state.pop('search_range',None)
            # One continuous scan can find the same post under several seeds.
            # A later 30-minute scan starts from a fresh pipeline in _claim.
            if not (complete_search and platform=='xiaohongshu'):
                state['seen_note_urls']=[]
            state.pop('last_search_page_fingerprint',None)
            state['repeat_same_page_count']=0
            state['search_cursor']=''
    # Commit only after the entire selected batch fits the daily/total import quota.
    task['_pipeline_next']=state
    return rows

def _discover(adapters,task,state,platform,keywords,continuous,report,checkpoint,before_read=None):
        query={**task,'keywords':[keywords[state['keyword_index']]],'next_page':state['search_page']}
        if state.get('search_range') is not None:query['search_range']=state['search_range']
        if platform=='wechat_channels': query['next_cursor']=state.get('search_cursor','')
        report('searching')
        if before_read:before_read()
        notes=adapters.search(platform,query)
        info=query.get('_page_info',{})
        natural_dom=(platform=='xiaohongshu' and info.get('mode')=='natural_dom')
        if natural_dom:
            from xhs_natural_search import validate_range
            observed_range=validate_range(info.get('search_range'),keyword=keywords[state['keyword_index']])
            if observed_range['state'] != info.get('range_state'):
                raise ValueError('搜索范围状态不一致，已保留断点')
            state['search_range']=deepcopy(observed_range)
        if continuous and not natural_dom and type(info.get('has_more')) is not bool:
            raise ValueError('搜索分页状态缺失，已暂停并保留断点')
        state['search_more']=(info['range_state'] in ('more','unknown') if natural_dom else
            info.get('has_more') is True if continuous else
            (platform in ('xiaohongshu','douyin') and bool(notes)
             and state['search_page']<int(task.get('search_pages',3))
             and info.get('has_more') is not False))
        if platform=='wechat_channels':
            info=query.get('_page_info',{})
            state['search_more']=info.get('has_more') is True
            state['next_search_cursor']=info.get('cursor','')
            if state['search_more'] and (not state['next_search_cursor'] or state['next_search_cursor']==state.get('search_cursor','')): raise ValueError('视频号搜索游标未前进，保留断点并停止')
        if platform=='douyin' or continuous:
            # Search links to one post can carry different xsec tokens. Keep
            # the original URL for requests, but dedupe by its stable note ID.
            seen={_seen_note_key(platform,url) for url in state.get('seen_note_urls',[])}
            fresh=[]
            for item in notes:
                url=item.get('url')
                key=_seen_note_key(platform,url)
                if key in seen:
                    continue
                fresh.append(item)
                if continuous and platform=='xiaohongshu' and url:
                    seen.add(key)
            fingerprint=None
            if continuous and platform=='xiaohongshu' and notes:
                keys=sorted({_seen_note_key(platform,item.get('url')) for item in notes})
                fingerprint=hashlib.sha256('\0'.join(keys).encode('utf-8')).hexdigest()
            if notes and not fresh:
                if continuous and platform=='xiaohongshu':
                    same=fingerprint==state.get('last_search_page_fingerprint')
                    repeats=int(state.get('repeat_same_page_count') or 0)+1 if same else 0
                    # Repeated platform pages are an uncertain boundary, not
                    # proof that this keyword's search range is exhausted.
                    if not natural_dom and state['search_more'] and repeats>=3:
                        raise ValueError('搜索连续返回重复的一页，已暂停并保留断点；不能确认搜索范围已读完')
                    state['repeat_same_page_count']=repeats
                else:
                    raise ValueError('搜索返回了重复的一页，已暂停；保留断点，不会反复抓取同一批视频')
            else:
                state['repeat_same_page_count']=0
            if continuous and platform=='xiaohongshu':
                state['last_search_page_fingerprint']=fingerprint
            seen.update(_seen_note_key(platform,item['url']) for item in notes if item.get('url'))
            state['seen_note_urls']=sorted(seen)
            notes=fresh
        state['notes']=[]
        for item in notes:
            decision,_=identity_decision({**item,'source_type':'note'},{**task,'excluded_authors':[]})
            if decision=='exclude': continue
            url=item.get('url')
            if url:
                state['notes'].append({'url':url,'title':item.get('title',''),'author':item.get('author',''),'author_id':item.get('author_id',''),
                    'author_avatar_url':item.get('author_avatar_url',''),'cover_url':item.get('cover_url',''),
                    'published_at':item.get('published_at','')})
        state['note_index']=0
        state['current_note_counted']=False
        # Save discovered work before requesting comments, so a failed request resumes here.
        task['pipeline']=deepcopy(state)
        checkpoint()
