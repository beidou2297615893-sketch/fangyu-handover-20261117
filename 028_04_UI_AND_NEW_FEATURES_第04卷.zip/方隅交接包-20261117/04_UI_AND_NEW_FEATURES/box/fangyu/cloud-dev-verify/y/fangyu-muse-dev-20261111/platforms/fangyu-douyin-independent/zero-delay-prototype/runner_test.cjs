'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const {parseExact,scrub,normalizePlan,buildExpression,createBridgeTransport,createLedgerAdapter,Runner,acquireLease}=require('./runner.cjs');
const base=fs.mkdtempSync(path.join(__dirname,'runner-test-'));
const plan=()=>({scan_id:'synthetic-scan',account_uid:'synthetic-owner',connection_id:'synthetic-page',rule_source:'synthetic-test-only',target_comments:100000,stores:Array.from({length:15},(_,i)=>({store_id:'store-'+i,name:'上海合成门店'+i,city:'上海',geography_anchors:['上海'],keywords:['synthetic-term-'+i]}))});
const fakeClock=()=>{let at=0;return {now:()=>at,sleep:async ms=>{at+=ms;}}};
const envelope=(spec,value)=>({ok:true,connection:spec.connection_id,value});
const searchValue=(id,cursor=10,more=0)=>({status_code:0,data:[{aweme_info:{aweme_id:id,desc:'上海租房合成视频'}}],cursor,has_more:more});
const commentsValue=(id,cursor=20,more=0)=>({status_code:0,comments:[{cid:id,aweme_id:'9007199254740993001',text:'合成评论',ip_label:'测试地区',user:{uid:'9007199254740993002'}}],cursor,has_more:more});
function setup(name,transport,custom={}){const directory=path.join(base,name),ledger=createLedgerAdapter(path.join(directory,'collection.sqlite3'));return {ledger,runner:new Runner({plan:{...plan(),...custom},ledger,transport,directory,minimum_delay_ms:40000,clock:fakeClock()})};}

test('preserve exact unsafe integer lexemes before conversion, strings and escapes',()=>{
 const parsed=parseExact('{"aweme_id":9007199254740993123,"cid":"9007199254740993124","quoted":"\\\" 9007199254740993125","n":20,"neg":-9007199254740993126}');
 assert.equal(parsed.aweme_id,'9007199254740993123');assert.equal(parsed.cid,'9007199254740993124');assert.equal(parsed.n,20);assert.equal(parsed.neg,'-9007199254740993126');assert.equal(parsed.quoted,'" 9007199254740993125');assert.throws(()=>parseExact('{"n":01}'));
});
test('secret keys and URL credential parameters removed without copying private configs',()=>{
 const clean=scrub({token:'synthetic-secret',data:{url:'https://example.test/?msToken=fake&q=safe',cid:'123'}});assert.equal(clean.token,'[REDACTED]');assert(!JSON.stringify(clean).includes('fake'));assert.equal(clean.data.cid,'123');
});
test('15 explicit unique stores, deduplicate shared terms with source refs, never infer newest',()=>{
 const p=plan();p.stores[1].keywords=[p.stores[0].keywords[0]];const n=normalizePlan(p);assert.equal(n.search_tasks.length,14);assert.equal(n.search_tasks[0].store_refs.length,2);assert.equal(n.sort_order,'comprehensive_default_no_newest_control');p.stores.pop();assert.throws(()=>normalizePlan(p));
});
test('live and runner interval below 30 seconds is rejected even with an injected clock',()=>{
 assert.throws(()=>createBridgeTransport({call(){},status(){}},{connection_id:'fake',strict_proof:{verified:true,source:'synthetic'},minimum_delay_ms:5000,clock:fakeClock()}));
 assert.throws(()=>new Runner({plan:plan(),ledger:{},transport(){},directory:path.join(base,'invalid-delay'),minimum_delay_ms:5000,clock:fakeClock()}));
});
test('already-reached unique-comment goal makes no request',async()=>{
 let calls=0;const runner=new Runner({plan:{...plan(),target_comments:1},ledger:{snapshot:()=>({can_collect:true,summary:{comments:1}})},transport:()=>{calls++;},directory:path.join(base,'goal'),minimum_delay_ms:40000,clock:fakeClock()});assert.equal((await runner.step()).state,'target_reached');assert.equal(calls,0);
});
test('generated page expression makes only known GETs, guards identity both sides, no retries',async()=>{
 const p=plan(),spec={...p,kind:'comments',target:'9007199254740993123',cursor:0};
 const calls=[];const context={location:{hostname:'www.douyin.com'},URLSearchParams,window:{__bridge:{_q:()=>({aid:'6383'})}},fetch:async(url,opts)=>{calls.push({url,opts});return {ok:true,status:200,headers:{get:()=> 'application/json'},json:async()=>({status_code:0,user:{sec_uid:p.account_uid}}),text:async()=>'{}'};}};
 const result=await vm.runInNewContext(buildExpression(spec,20),context);assert.equal(calls.length,3);assert.equal(result.identity_verified,true);assert(calls[1].url.includes('aweme_id=9007199254740993123'));assert(calls.every(c=>!c.opts.method));assert(!buildExpression(spec,20).includes('publish'));assert(!buildExpression(spec,20).includes('sort_type'));
 calls.length=0;context.fetch=async()=>{calls.push(1);throw Error('synthetic net failure');};await assert.rejects(vm.runInNewContext(buildExpression(spec,20),context));assert.equal(calls.length,1);
});
test('wrong account never requests search/comments',async()=>{
 const p=plan(),spec={...p,kind:'search',target:'synthetic',cursor:0};let calls=0;
 const result=await vm.runInNewContext(buildExpression(spec,10),{location:{hostname:'www.douyin.com'},URLSearchParams,window:{__bridge:{_q:()=>({})}},fetch:async()=>{calls++;return {ok:true,json:async()=>({status_code:0,user:{sec_uid:'different'}})};}});assert.equal(calls,1);assert.equal(result.runner_stop,'identity_not_verified');
});
test('transport enforces one pinned page and serializes all calls for that connection',async()=>{
 const p=plan();let active=0,peak=0,calls=0;
 const bridge={host:'127.0.0.1',port:1,status:async()=>({connections:{'douyin.com':[{id:p.connection_id,alive:true}]}}),call:async()=>{calls++;active++;peak=Math.max(peak,active);await new Promise(r=>setTimeout(r,5));active--;return {ok:true,connection:p.connection_id,value:{identity_verified:true,http_status:200,content_type:'application/json',raw_text:'{"status_code":0,"cid":9007199254740993123}'}};}};
 const transport=createBridgeTransport(bridge,{connection_id:p.connection_id,strict_proof:{verified:true,source:'synthetic'},clock:fakeClock()});const spec={...p,kind:'search',target:'synthetic',cursor:0};const results=await Promise.all([transport(spec,10),transport(spec,10)]);assert.equal(peak,1);assert.equal(calls,2);assert.equal(results[0].value.cid,'9007199254740993123');
 bridge.status=async()=>({connections:{'douyin.com':[{id:'other-page',alive:true}]}});assert.equal((await transport(spec,10)).ok,false);assert.equal(calls,2);
});
test('15-store rotation, persisted ledger is sole cursor, global unique comments goal',async()=>{
 const seen=[];const {runner,ledger}=setup('rotation',async spec=>{seen.push({kind:spec.kind,store:spec.store_id,cursor:spec.cursor});return envelope(spec,spec.kind==='search'?searchValue('9007199254740993001'):commentsValue('9007199254740993003'));});
 for(let i=0;i<15;i++)assert.equal((await runner.step()).state,'page_committed');assert.deepEqual(seen.map(x=>x.store),plan().stores.map(x=>x.store_id));assert(seen.every(x=>x.kind==='search'));
 const snap=ledger.snapshot(normalizePlan(plan()));assert.equal(snap.videos.length,1);assert.equal(snap.videos[0].source_refs.length,15);
 assert.equal((await runner.step()).state,'page_committed');assert.equal(seen.at(-1).kind,'comments');assert.equal(ledger.snapshot(normalizePlan(plan())).summary.comments,1);
 const reboot=new Runner({plan:plan(),ledger,transport:()=>{throw Error('no_more_network_expected');},directory:runner.directory,minimum_delay_ms:40000,clock:fakeClock()});assert.equal((await reboot.step()).state,'sources_exhausted');
});
test('empty and captcha/nonzero/unknown/mismatch stop durably with zero successful item import',async()=>{
 const cases={captcha:spec=>envelope(spec,{status_code:0,search_nil_info:{search_nil_type:'verify_check'}}),nonzero:spec=>envelope(spec,{status_code:9}),empty:spec=>envelope(spec,{status_code:0,data:[],cursor:10,has_more:1}),mismatch:()=>({ok:true,connection:'wrong',value:searchValue('123')}),unknown:()=>({ok:false,transport_error:'synthetic_unknown'})};
 for(const [name,result] of Object.entries(cases)){let calls=0;const {runner,ledger}=setup(name,async spec=>{calls++;return result(spec);});assert.equal((await runner.step()).state,'paused');assert.equal((await runner.step()).state,'paused');assert.equal(calls,1);const snap=ledger.snapshot(normalizePlan(plan()));assert.equal(snap.can_collect,false);assert.equal(snap.summary.items,0);}
});
test('unsafe numeric IDs from pre-parsed bridge payload are rejected, never string-coerced',async()=>{
 const {runner,ledger}=setup('numeric',async spec=>envelope(spec,searchValue(9007199254740993001)));assert.equal((await runner.step()).state,'paused');assert.equal(ledger.snapshot(normalizePlan(plan())).summary.items,0);
});
test('same items returned at a new cursor is durably halted, never indefinite repeated scan',async()=>{
 const p=plan();p.stores.forEach((s,i)=>s.keywords=['shared']);let calls=0;
 const {runner,ledger}=setup('repeat',async spec=>{calls++;return envelope(spec,spec.kind==='search'?searchValue('9007199254740993001',spec.cursor+10,1):commentsValue('9007199254740993003'));},p);
 assert.equal((await runner.step()).state,'page_committed');assert.equal((await runner.step()).state,'page_committed');assert.equal((await runner.step()).state,'paused');assert.equal(calls,3);assert.equal(ledger.snapshot(normalizePlan(p)).can_collect,false);
});
test('pending request marker prevents automatic refetch after a crash',async()=>{
 const {runner}=setup('pending',()=>{throw Error('must_not_call');});runner.state.pending={request_id:'synthetic-crash',record_path:path.join(runner.directory,'missing.json')};runner.save();assert.equal((await runner.step()).reason,'pending_request_requires_local_review_no_refetch');
});
test('local STOP has priority and no read is invoked',async()=>{
 let calls=0;const {runner}=setup('stop',()=>{calls++;});fs.writeFileSync(path.join(runner.directory,'STOP'),'synthetic stop');assert.equal((await runner.step()).reason,'local_stop_requested');assert.equal(calls,0);
});
test('STOP during pacing creates no pending request and explicit resume records evidence',async()=>{
 let calls=0;const {runner}=setup('stop-while-waiting',async spec=>{calls++;return envelope(spec,searchValue('9007199254740993001'));});
 await runner.step();let at=0;runner.clock={now:()=>at,sleep:async ms=>{at+=ms;fs.writeFileSync(path.join(runner.directory,'STOP'),'synthetic operator stop');}};
 assert.equal((await runner.step()).reason,'local_stop_requested_before_call');assert.equal(runner.state.pending,null);assert.equal(calls,1);
 const result=runner.resumeLocal({account_uid:plan().account_uid,operator:'synthetic-reviewer',reason:'operator explicitly resumes test',rule_source:'synthetic-only'});assert.equal(result.network_started,false);assert(!fs.existsSync(path.join(runner.directory,'STOP')));assert(fs.readdirSync(runner.directory).some(x=>x.startsWith('resume-')));
});
test('only proven prepared phase may be cancelled; dispatched unknown cannot resume',()=>{
 const {runner}=setup('resume-prepared',()=>{throw Error('must_not_call');});
 const file=path.join(runner.directory,'synthetic-prepared.json');const spec={request_id:'synthetic-prepared',account_uid:plan().account_uid};fs.writeFileSync(file,JSON.stringify({spec,response:null,state:'prepared_not_dispatched'}));runner.state.pending={request_id:spec.request_id,record_path:file,phase:'prepared'};runner.state.stopped='local_stop_requested_before_dispatch';runner.save();
 const review={account_uid:plan().account_uid,operator:'synthetic-reviewer',reason:'cancel unstarted read',rule_source:'synthetic-only'};assert.equal(runner.resumeLocal(review).state,'local_resume_recorded');assert.equal(JSON.parse(fs.readFileSync(file)).state,'cancelled_before_dispatch');
 runner.state.pending={request_id:spec.request_id,record_path:file,phase:'dispatching'};assert.throws(()=>runner.resumeLocal(review));
});
test('connection and database leases reject cross-process duplicate scope',()=>{
 const database=path.join(base,'lease','collection.sqlite3');const release=acquireLease({connection_id:'synthetic-lease',database});assert.throws(()=>acquireLease({connection_id:'synthetic-lease',database:path.join(base,'other.sqlite3')}));assert.throws(()=>acquireLease({connection_id:'different',database}));release();
});
test.skip('existing real probes checked offline for structure only, no private content output',()=>{
 const s=JSON.parse(fs.readFileSync(path.join(__dirname,'first-search-raw.json'),'utf8')),c=JSON.parse(fs.readFileSync(path.join(__dirname,'first-comments-raw.json'),'utf8'));
 assert.equal(s.response.status_code,0);assert.equal(s.response.data.length,10);assert.equal(s.response.cursor,10);assert.equal(s.response.has_more,1);
 assert.equal(c.response.status_code,0);assert.equal(c.response.comments.length,20);assert.equal(c.response.cursor,20);assert.equal(c.response.has_more,1);
 assert(c.response.comments.every(x=>typeof x.cid==='string'&&typeof x.aweme_id==='string'&&typeof x.ip_label==='string'));
});
