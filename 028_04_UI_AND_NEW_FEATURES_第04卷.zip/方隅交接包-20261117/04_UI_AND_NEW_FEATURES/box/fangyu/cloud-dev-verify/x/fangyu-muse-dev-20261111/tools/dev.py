"""方隅 Muse 开发入口（Linux / Windows 通用，只用标准库）。

python3 tools/dev.py check            检查环境与关键目录
python3 tools/dev.py preview [--port 8765] [--design]
                                      只读静态预览（仅绑定 127.0.0.1，不连后台、不连平台）
python3 tools/dev.py test             运行可在 Linux 跑的离线测试，结果写入 _dev/test-results/
python3 tools/dev.py export           导出“开发到一半”的完整工程 ZIP 到 _dev/exports/
python3 tools/dev.py init-baseline    （仅打包方用一次）记录基线散列

本工具不启动采集、发送、登录，不访问外网。
"""
from pathlib import Path
import argparse, datetime, functools, hashlib, http.server, json, os, platform, subprocess, sys, zipfile

ROOT = Path(__file__).resolve().parents[1]
DEV = ROOT / '_dev'
BASELINE = ROOT / 'MANIFEST' / 'baseline-sha256.json'
CFG = json.loads((ROOT / 'config' / 'paths.json').read_text(encoding='utf-8'))
P = {k: ROOT / v for k, v in CFG['paths'].items()}
SKIP = {'_dev', '__pycache__', '.git', '.venv', 'venv', 'node_modules', '.pytest_cache'}


def check(_):
    ok = True
    print('Python', sys.version.split()[0], platform.system())
    if sys.version_info < (3, 12):
        print('需要 Python 3.12+'); ok = False
    try:
        print('Node', subprocess.run(['node', '--version'], capture_output=True, text=True).stdout.strip())
    except Exception:
        print('Node 未安装（仅抖音 worker 的 JS 测试需要，建议 Node 24）')
    for k, p in P.items():
        print(('OK      ' if p.exists() else 'MISSING ') + k + ' -> ' + str(p.relative_to(ROOT)))
        ok &= p.exists()
    return 0 if ok else 1


def preview(a):
    root = P['design_latest'] if a.design else P['frontend_web']
    h = functools.partial(http.server.SimpleHTTPRequestHandler, directory=str(root))
    with http.server.ThreadingHTTPServer(('127.0.0.1', a.port), h) as s:
        print('静态预览: http://127.0.0.1:%d/  目录: %s  (Ctrl+C 结束)' % (a.port, root.relative_to(ROOT)), flush=True)
        try:
            s.serve_forever()
        except KeyboardInterrupt:
            pass
    return 0


def _run(name, cmd, cwd):
    out = DEV / 'test-results'
    out.mkdir(parents=True, exist_ok=True)
    r = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, encoding='utf-8', errors='replace')
    (out / (name + '.log')).write_text(r.stdout + '\n--stderr--\n' + r.stderr, encoding='utf-8')
    tail = (r.stdout + r.stderr).strip().splitlines()[-1:] or ['']
    print(('PASS ' if r.returncode == 0 else 'FAIL ') + name + '  ' + tail[0][:160])
    return {'name': name, 'returncode': r.returncode, 'cmd': cmd, 'cwd': str(Path(cwd).relative_to(ROOT))}


GUARD = ("import sys,unittest,socket,subprocess,pathlib;sys.path[:0]=['src','tests'];"
         "b=lambda *a,**k:(_ for _ in ()).throw(RuntimeError('offline guard'));"
         "socket.socket=b;subprocess.run=b;subprocess.Popen=b;"
         "n=[p.stem for p in sorted(pathlib.Path('tests').glob('test_*.py')) if p.stem not in {'test_real_backend','test_runner_bridge','test_read_services_http'}];"
         "r=unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName(x) for x in n));"
         "print('RESULT run=%d fail=%d err=%d skip=%d'%(r.testsRun,len(r.failures),len(r.errors),len(r.skipped)));sys.exit(not r.wasSuccessful())")


def test(_):
    py = sys.executable
    res = [
        _run('integration-backend-offline', [py, '-B', '-X', 'utf8', '-c', GUARD], P['backend']),
        _run('integration-http-loopback', [py, '-B', '-X', 'utf8', '-c', "import sys,unittest;sys.path[:0]=['src','tests'];r=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromName('test_read_services_http'));print('RESULT run=%d fail=%d err=%d'%(r.testsRun,len(r.failures),len(r.errors)));sys.exit(not r.wasSuccessful())"], P['backend']),
        _run('host-baseline-fixture', [py, '-B', '-m', 'unittest', '-v', 'test_fixture_wiring'], P['host_baseline']),
        _run('backend-r3-offline', [py, '-B', '-X', 'utf8', '-c', GUARD], P['backend_r3']),
        _run('original-core-tests', [py, '-B', '-m', 'unittest', 'discover', '-s', 'tests'], P['original_core']),
    ]
    out = DEV / 'test-results' / 'summary.json'
    out.write_text(json.dumps({'utc': datetime.datetime.utcnow().isoformat() + 'Z', 'python': sys.version, 'results': res}, ensure_ascii=False, indent=1), encoding='utf-8')
    print('结果:', out.relative_to(ROOT))
    return 0 if all(r['returncode'] == 0 for r in res) else 1


def _inventory():
    files = {}
    for cur, dirs, names in os.walk(ROOT):
        dirs[:] = [d for d in dirs if d not in SKIP]
        for n in names:
            p = Path(cur) / n
            if p.is_symlink():
                continue
            rel = p.relative_to(ROOT).as_posix()
            if rel == 'MANIFEST/baseline-sha256.json':
                continue
            files[rel] = hashlib.sha256(p.read_bytes()).hexdigest()
    return files


def init_baseline(_):
    if BASELINE.exists():
        print('基线已存在，拒绝覆盖'); return 1
    BASELINE.write_text(json.dumps(_inventory(), ensure_ascii=False, indent=0), encoding='utf-8'); print('基线已写入'); return 0


def export(a):
    base = json.loads(BASELINE.read_text(encoding='utf-8')) if BASELINE.exists() else {}
    cur = _inventory()
    ch = {'added': sorted(cur.keys() - base.keys()), 'deleted': sorted(base.keys() - cur.keys()),
          'modified': sorted(k for k in cur.keys() & base.keys() if cur[k] != base[k])}
    stamp = datetime.datetime.now().strftime('%Y%m%d-%H%M%S')
    (DEV / 'exports').mkdir(parents=True, exist_ok=True)
    target = DEV / 'exports' / ('fangyu-muse-dev-export-%s.zip' % stamp)
    nxt = ROOT / 'NEXT-STEPS.md'
    with zipfile.ZipFile(target, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for rel in cur:
            z.write(ROOT / rel, 'fangyu-muse-dev/' + rel)
        z.writestr('fangyu-muse-dev/_export/changes.json', json.dumps(ch, ensure_ascii=False, indent=1))
        z.writestr('fangyu-muse-dev/_export/sha256.json', json.dumps(cur, ensure_ascii=False, indent=0))
        tr = DEV / 'test-results'
        if tr.exists():
            for p in tr.rglob('*'):
                if p.is_file():
                    z.write(p, 'fangyu-muse-dev/_export/test-results/' + p.name)
        z.writestr('fangyu-muse-dev/_export/environment.txt', 'python %s\n%s\n' % (sys.version, platform.platform()))
        if not nxt.exists():
            z.writestr('fangyu-muse-dev/_export/NEXT-STEPS-MISSING.txt', '请在工程根目录写 NEXT-STEPS.md：做到哪、改了什么、下一步。')
    with zipfile.ZipFile(target) as z:
        assert z.testzip() is None
    print('导出:', target, '| 新增', len(ch['added']), '修改', len(ch['modified']), '删除', len(ch['deleted']))
    print('sha256:', hashlib.sha256(target.read_bytes()).hexdigest())
    return 0


def main():
    ap = argparse.ArgumentParser()
    sp = ap.add_subparsers(dest='cmd', required=True)
    sp.add_parser('check').set_defaults(f=check)
    p = sp.add_parser('preview'); p.add_argument('--port', type=int, default=8765); p.add_argument('--design', action='store_true'); p.set_defaults(f=preview)
    sp.add_parser('test').set_defaults(f=test)
    sp.add_parser('export').set_defaults(f=export)
    sp.add_parser('init-baseline').set_defaults(f=init_baseline)
    a = ap.parse_args()
    return a.f(a)


if __name__ == '__main__':
    raise SystemExit(main())
