# Linux 实测记录（打包方，2026-11-11 09:05 北京时间）

环境：Linux（Grok 盒子），Python 3.13.5，Node v24.22.1。ZIP 解压到全新目录后执行 `python3 tools/dev.py check / test / preview / export`。全部为合成数据，网络与子进程在单元测试里被拦截（不是系统级沙箱）。

| 项目 | 命令 | 结果 |
| --- | --- | --- |
| ZIP 完整性 | `zipfile.testzip()`；`MANIFEST/baseline-sha256.json` 逐文件比对 | 通过；testzip 无坏文件 |
| 环境/目录检查 | `tools/dev.py check` | 通过 |
| 11-11 候选后台离线回归 | `tools/dev.py test` → integration-backend-offline | 124 项通过，0 失败 |
| 原 HTTP 处理器回环测试 | integration-http-loopback（仅 127.0.0.1） | 2 项通过 |
| 宿主合成接线 | host-baseline-fixture（`test_fixture_wiring.py`） | 5 项通过 |
| 11-02 后台 / 11-10 工作稿离线回归 | backend-r3-offline | 94 项通过，0 失败 |
| 自动获客系统原核心测试 | original-core-tests | **已知失败**：60 项中 10 项报错（Windows 专属 `creationflags`、快手组件未打包、依赖原机文件/端口）。属 Windows 宿主，回 Windows 验证 |
| 静态预览 | `tools/dev.py preview` | 通过：127.0.0.1 返回 200（旧现用前端，不是新设计） |
| 导出脚本 | `tools/dev.py export` | 通过：生成 ZIP、变更清单、sha256 |

## 未验证 / 已知问题（Muse 下一步）

- `backend/tests/test_runner_bridge.py`：**未验证**。写死 `C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/xhs-send-current-20261029/bulk_run.py` 等原机路径（对应源码在 `platforms/xhs-send-current-20261029/`）。需加测试入口适配层。
- `backend/tests/douyin_worker_test.cjs`：**已知失败**（ENOENT），写死 `C:/…/work/runtime/douyin-bridge`；源码在 `platforms/runtime/douyin-bridge/`。
- `backend/tests/test_real_backend.py`：**未验证**。按旧目录层级找 `work/combined-full-candidate-20261027/project` 和 `work/central-store-config/test_central_client.py`；后者未收进包。
- `tests/review_runner_guard.py` 同样写死原机路径，未运行。
- 旧交接包曾把 `ui_native_host.py`（SESSION_COOKIE 名称常量被误判为密钥）和 `*cookies.py` 源码误排除；本包已补回，上面 HTTP 与宿主测试正是依赖它们跑通。
- Windows 桌面窗口（pywebview/WebView2）、真实 WorkbenchBackend 完整构造、原生发送、平台登录：Linux **未验证**，回 Windows 后验证。
- 新界面三批样图均**未实现**、未经用户认可。

注意：ZIP 内中文文件名用 UTF-8 标记。若 Linux 的 `unzip` 显示乱码，请用 `python3 -m zipfile -e 包名.zip 目标目录` 或 `7z x` 解压。
