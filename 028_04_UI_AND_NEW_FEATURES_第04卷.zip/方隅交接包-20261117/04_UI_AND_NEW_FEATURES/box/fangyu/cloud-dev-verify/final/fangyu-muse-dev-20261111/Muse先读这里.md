# Muse 先读这里 · 方隅公寓获客工作台 Linux 云端开发工程

打包时间：2026-11-11（北京时间）。打包方：Grok「技术 软件集成」。分工：用户决策，Grok 打包，Muse 在 Linux 云电脑开发，Codex 只负责决策。

## 1. 目标

把现有抖音、小红书本地链路和桌面工作台整合成给门店员工用的 Windows 软件：**安装时选门店 → 员工登录 → 简洁的抖音/小红书工作台**。在 Linux 上做源码开发、界面静态预览和能跑的离线测试；Windows 专属宿主（pywebview/WebView2、原生发送、浏览器会话）保留源码，整包下载回 Windows 后再验证。

先读：`docs/01-接手与错误书/11月11日交接/交接说明.md`、`界面最新要求.md`，再读 `docs/01-接手与错误书/00-接手说明.md` 和 `已知错误与一键修复.md`。

## 2. 目录

| 目录 | 内容 |
| --- | --- |
| `project/integration-20261111/` | **11 月 11 日最新独立候选**（开发主线）。`backend/`：`src/fangyu_integration`、tests、overlay（接入原 WorkbenchBackend 与原 HTTP 宿主）、vendor/pool_sop、evidence；`host-baseline/`：现用 r57 宿主源码闭包副本（含前端 web、ui-runtime-r55 桌面核心，已剔除 DLL/PYD/EXE）及合成接线测试 |
| `project/r57-release-extras/` | 现用 r57 发布中、host-baseline 里没有的源码/配置（同相对路径）。门店目录、受控回复材料等见此处和 `rules/门店目录与意向政策-r57/` |
| `project/desktop-entry-r57/` | 现用桌面入口 `run_workbench.py`（只读参考，写死原机相对路径和散列，Linux 不运行）及 r57 宿主工具、测试 |
| `project/backend-r3-20261102/` | 11 月 2 日后台：r3 冻结记录（evidence/CURRENT.json）与 11 月 10 日工作稿（src/tests/overlay）。冻结的 candidate-release 静态闭包（478MB）未收，源码已在 src/overlay |
| `project/original-core/` | 自动获客系统原核心 src/tests、company.json |
| `platforms/` | 抖音、小红书 CLI 及适配器、控制器、采集、筛选、回复、回信、恢复、防重、共享账本代码与测试，按原 `自动获客系统/work/<目录名>` 保留名称（含 `runtime/douyin-bridge` 源码、package.json 等依赖清单）。运行数据、回执、队列、会话已剔除 |
| `rules/` | 关键词、门店目录、分类/排除规则、母句、微调规则及其 versions 版本目录（`fangyu-text-business-20261029`、两边 outputs 里的门店词库/规则、r57 的 `store_materials_catalog.json`/`store_search_profiles.json`/`approved_intent_policy.json`） |
| `docs/` | 01 接手与错误书；02 各窗口开发历程（抖音、小红书、回复语气、界面、代码整合、错误书摘录、验收映射 `software-acceptance-mapping.md`、用户改动记录 `USER-CHANGE-LOG.md`）；03 界面历程材料；04 旧云端工具说明 |
| `designs/` | 三批样图，按时间先后：`1-…0725-Grok原参考-batch07`（Grok 出的原参考，主界面+两个悬浮窗）→ `2-…0733-Codex-暖色公寓简洁界面`（主界面、运行悬浮窗、验证提醒悬浮窗，07:33–07:35）→ `3-…0800-Codex-简洁无小字界面-最新`（员工登录、安装选店、主工作台，08:00–08:01，**最新一批**）。三批都还在等用户认可，界面都**没有实现** |
| `ledger-snapshot/` | 共享业务账本一致性快照（08:09 用 sqlite 备份 API 生成，integrity_check=ok，表行数见 `table-counts.json`）。含业务个人信息，仅限本项目开发核对防重/状态，不得上传公开处，不得覆盖回现用账本 |
| `config/paths.json` | 开发入口用的相对路径配置；原机 C:\ 路径只作回传核对 |
| `tools/dev.py` | 开发入口：检查、预览、测试、导出 |
| `MANIFEST/` | `included-files.json`（每个文件来源与 sha256）、`excluded.json`（排除项与理由）、`excluded-summary.json`、`LINUX-VERIFY.md`（打包方在 Linux 的实测结果） |

## 3. 环境与启动命令

解压：中文文件名为 UTF-8，Linux 上建议 `python3 -m zipfile -e 方隅-Muse云端开发工程-20261111.zip .`（老版 unzip 可能乱码）。

- Python **3.12+**（打包方实测 3.13.5；原机 3.12.9），后台与测试只用标准库。Node **24**（实测 v24.22.1），仅抖音 worker 的 JS 测试需要。
- 规则管线 `rule_config.json` 声明 `pyahocorasick-2.3.1`；涉及规则管线时 `pip install pyahocorasick==2.3.1`。桌面宿主在 Windows 需要 pywebview + WebView2（Linux 不装）。各子目录的 package.json / package-lock.json / dependency-lock.json 为原依赖清单。

```sh
python3 tools/dev.py check                 # 检查环境与目录
python3 tools/dev.py preview               # 现用前端静态预览 http://127.0.0.1:8765/
python3 tools/dev.py preview --design --port 8766   # 浏览最新样图目录
python3 tools/dev.py test                  # 离线测试，结果在 _dev/test-results/
python3 tools/dev.py export                # 开发到一半导出完整工程 ZIP（_dev/exports/）
```

预览只是静态文件，不连后台、不登录、不连平台；现用前端是旧界面，不是新设计。

## 4. 禁区

- 不启动真实采集、发送、登录；不连抖音/小红书；不调用付费模型。测试只用合成数据。
- 包里**没有**密钥、Cookie、密码、登录态、浏览器用户目录，也没有迁移它们；不要尝试补齐或索要。
- 不新增自动换号、24 小时常驻、发送计数工具。保留已有防重、预留、异常停线和身份核对。
- **unknown 不清除、不重发**；快照里的历史授权不等于今天可执行。
- 不改用户原机的现用程序、队列、账本；不把快照写回。
- 不混入「每日百题」、合同、专利材料。

## 5. 已知缺口（先处理）

1. 测试里写死原机路径：`backend/tests/test_runner_bridge.py`（`C:/Users/rmsama/Documents/ChatGPT/自动获客系统/work/xhs-send-current-20261029/bulk_run.py`、`xhs-cli-standalone-entry/standalone_cli.py`）、`tests/douyin_worker_test.cjs`（`…/work/runtime/douyin-bridge`）、`tests/review_runner_guard.py`、`test_real_backend.py`（按旧目录层级找 `work/combined-full-candidate-20261027/project` 与 `work/central-store-config/test_central_client.py`）。对应源码多数已在 `platforms/` 下同名目录；`central-store-config` 未收。请加**测试入口适配层**（例如读 `config/paths.json` 或环境变量）而不是改业务代码。
2. 旧交接包把 `ui_native_host.py`（SESSION_COOKIE 名称常量被误判为密钥）和若干 `*cookies.py` 源码误排除；本包已按内容复核补回。若仍发现缺文件，查 `MANIFEST/excluded.json`。
3. 宿主复制回执记录原 r57 发布 647 项未进 host-baseline（156 DLL、33 PYD、EXE、PEM 等 Windows 二进制与第三方 vendor）。Linux 不需要；回 Windows 后按原 manifest 来源、散列和许可复用。
4. 门店完整目录口径（14 还是 15 店）、员工归属、两平台字段契约等需用户/负责人核实，见交接说明“实施顺序”。

## 6. 实施顺序

1. `check` → `test`，确认结果与 `MANIFEST/LINUX-VERIFY.md` 一致（打包方实测：候选后台 124+2、宿主接线 5、11-02 后台 94 项通过；原核心 10 项 Windows 专属报错）。
2. 补测试入口适配层，让第 5 节的测试在 Linux 用合成数据跑通。
3. 在 `project/integration-20261111` 上接真实 WorkbenchBackend（合成 company/data），打通 session/Origin/CSRF/门店权限。
4. 用真实组件实现三屏（安装选店保留完整门店选择、登录简洁、主界面暖色公寓背景+透明玻璃、无大白块、无辅助小字），以第 3 批样图为准、参考第 1/2 批的悬浮窗；用户认可样图前只做可回退实现。
5. 按平台接业务（先一条合成贯通），再做恢复与交付验证。详见交接说明。

## 7. 验收要求

- 每次交付写明：改动文件、依赖来源、测试命令、通过/失败/跳过数、数据范围（合成）、截图或演示位置、未覆盖项。
- Linux 只能证明源码与离线测试；WebView2 窗口、原生发送、真实平台必须回 Windows 验证，未验证的写“未验证”。
- 合成测试、截图、文件落盘都不等于用户认可或平台验收。

## 8. 回传方式

1. 在根目录写 `NEXT-STEPS.md`（做到哪、改了什么、下一步、阻塞）。
2. 运行 `python3 tools/dev.py test` 再 `python3 tools/dev.py export`。
3. 把 `_dev/exports/` 里的 ZIP 和打印的 sha256 交给用户，整包下载回 Windows。ZIP 内 `_export/changes.json` 是相对基线（`MANIFEST/baseline-sha256.json`）的新增/修改/删除清单，`_export/test-results/` 是测试日志。
