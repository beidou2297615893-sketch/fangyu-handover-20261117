#!/usr/bin/env python3
"""Minimal shared DeepSeek chat/completions + balance CLI for all agents on this box.

Never prints, echoes, logs, or writes the API key value.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

BASE = "https://api.deepseek.com"
CHAT_URL = f"{BASE}/chat/completions"
BALANCE_URL = f"{BASE}/user/balance"
DEFAULT_MODEL = "deepseek-flash"
ALLOWED_MODELS = ("deepseek-flash", "deepseek-v4-pro")
DEFAULT_MAX_TOKENS = 4000
TIMEOUT_S = 120
TZ = ZoneInfo("Asia/Shanghai")
HERE = Path(__file__).resolve().parent
USAGE_LOG = HERE / "usage.jsonl"


def _die(msg: str, code: int = 1) -> None:
    print(msg, file=sys.stderr)
    raise SystemExit(code)


def _api_key() -> str:
    key = os.environ.get("DEEPSEEK_API_KEY", "").strip()
    if not key:
        _die("DEEPSEEK_API_KEY is not set in this process environment.", 2)
    return key


def _now_iso() -> str:
    return datetime.now(TZ).isoformat(timespec="seconds")


def _append_usage(row: dict[str, Any]) -> None:
    USAGE_LOG.parent.mkdir(parents=True, exist_ok=True)
    with USAGE_LOG.open("a", encoding="utf-8") as f:
        f.write(json.dumps(row, ensure_ascii=False) + "\n")


def _parse_retry_after(headers: Any) -> float:
    raw = None
    try:
        raw = headers.get("Retry-After")
    except Exception:
        raw = None
    if not raw:
        return 1.0
    try:
        return max(0.0, float(raw))
    except ValueError:
        return 1.0


def _http_json(
    method: str,
    url: str,
    body: dict[str, Any] | None = None,
    *,
    allow_retry: bool = True,
) -> tuple[int, dict[str, Any] | list[Any] | None, str]:
    """Return (status, parsed_json_or_None, raw_text). Retries once on 429/5xx."""
    key = _api_key()
    data = None
    headers = {
        "Authorization": f"Bearer {key}",
        "Accept": "application/json",
    }
    if body is not None:
        data = json.dumps(body).encode("utf-8")
        headers["Content-Type"] = "application/json"

    attempt = 0
    while True:
        attempt += 1
        req = urllib.request.Request(url, data=data, headers=headers, method=method)
        try:
            with urllib.request.urlopen(req, timeout=TIMEOUT_S) as resp:
                raw = resp.read().decode("utf-8", errors="replace")
                status = getattr(resp, "status", 200) or 200
                try:
                    parsed: dict[str, Any] | list[Any] | None = json.loads(raw) if raw else None
                except json.JSONDecodeError:
                    parsed = None
                return status, parsed, raw
        except urllib.error.HTTPError as e:
            raw = e.read().decode("utf-8", errors="replace") if e.fp else ""
            status = int(e.code)
            if allow_retry and attempt == 1 and (status == 429 or 500 <= status <= 599):
                time.sleep(_parse_retry_after(e.headers))
                continue
            try:
                parsed = json.loads(raw) if raw else None
            except json.JSONDecodeError:
                parsed = None
            return status, parsed, raw
        except urllib.error.URLError as e:
            if allow_retry and attempt == 1:
                time.sleep(1.0)
                continue
            _die(f"Network error talking to DeepSeek: {e}", 3)
        except TimeoutError:
            if allow_retry and attempt == 1:
                time.sleep(1.0)
                continue
            _die("DeepSeek request timed out after 120s.", 3)


def _error_message(status: int, parsed: Any, raw: str) -> str:
    msg = ""
    if isinstance(parsed, dict):
        err = parsed.get("error")
        if isinstance(err, dict):
            msg = str(err.get("message") or err.get("code") or "")
        elif isinstance(err, str):
            msg = err
        if not msg:
            msg = str(parsed.get("message") or "")
    if not msg:
        msg = (raw or "").strip()[:300] or f"HTTP {status}"
    return msg


def cmd_balance(_args: argparse.Namespace) -> int:
    status, parsed, raw = _http_json("GET", BALANCE_URL)
    if status in (401, 402):
        _die(f"DeepSeek auth/billing error HTTP {status}: {_error_message(status, parsed, raw)}", 4)
    if status != 200 or not isinstance(parsed, dict):
        _die(f"Balance request failed HTTP {status}: {_error_message(status, parsed, raw)}", 5)

    is_available = parsed.get("is_available")
    infos = parsed.get("balance_infos") or []
    print(f"is_available: {is_available}")
    if not infos:
        print("(no balance_infos)")
    for info in infos:
        if not isinstance(info, dict):
            continue
        currency = info.get("currency", "?")
        total = info.get("total_balance", "?")
        granted = info.get("granted_balance", "?")
        topped = info.get("topped_up_balance", "?")
        print(
            f"currency={currency} total_balance={total} "
            f"granted_balance={granted} topped_up_balance={topped}"
        )
    return 0


def cmd_usage(args: argparse.Namespace) -> int:
    if not USAGE_LOG.exists():
        print("No usage log yet.")
        return 0
    since = None
    if args.since:
        try:
            since = datetime.fromisoformat(args.since)
            if since.tzinfo is None:
                since = since.replace(tzinfo=TZ)
        except ValueError:
            _die(f"Invalid --since date: {args.since} (use ISO date/datetime)", 2)

    total_calls = 0
    ok_calls = 0
    fail_calls = 0
    prompt_tok = 0
    completion_tok = 0
    total_tok = 0
    by_model: dict[str, dict[str, int]] = {}
    by_tag: dict[str, int] = {}

    with USAGE_LOG.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                row = json.loads(line)
            except json.JSONDecodeError:
                continue
            t = row.get("time")
            if since and t:
                try:
                    row_t = datetime.fromisoformat(t)
                    if row_t.tzinfo is None:
                        row_t = row_t.replace(tzinfo=TZ)
                    if row_t < since:
                        continue
                except ValueError:
                    pass
            total_calls += 1
            st = str(row.get("status", ""))
            if st == "ok" or st == "200":
                ok_calls += 1
            else:
                fail_calls += 1
            pt = int(row.get("prompt_tokens") or 0)
            ct = int(row.get("completion_tokens") or 0)
            tt = int(row.get("total_tokens") or 0)
            prompt_tok += pt
            completion_tok += ct
            total_tok += tt
            model = str(row.get("model") or "?")
            bm = by_model.setdefault(model, {"calls": 0, "total_tokens": 0})
            bm["calls"] += 1
            bm["total_tokens"] += tt
            tag = str(row.get("tag") or "")
            if tag:
                by_tag[tag] = by_tag.get(tag, 0) + 1

    print(f"calls={total_calls} ok={ok_calls} fail={fail_calls}")
    print(
        f"tokens prompt={prompt_tok} completion={completion_tok} total={total_tok}"
    )
    if by_model:
        print("by_model:")
        for m, v in sorted(by_model.items()):
            print(f"  {m}: calls={v['calls']} total_tokens={v['total_tokens']}")
    if by_tag:
        print("by_tag:")
        for t, c in sorted(by_tag.items()):
            print(f"  {t}: calls={c}")
    return 0


def cmd_run(args: argparse.Namespace) -> int:
    model = args.model or DEFAULT_MODEL
    if model not in ALLOWED_MODELS:
        _die(f"Unsupported model {model!r}; use one of {ALLOWED_MODELS}", 2)

    if args.prompt_file:
        try:
            prompt = Path(args.prompt_file).read_text(encoding="utf-8")
        except OSError as e:
            _die(f"Cannot read --prompt-file: {e}", 2)
    else:
        if sys.stdin.isatty() and not args.prompt_file:
            # Allow empty? Prefer reading stdin always when no file.
            pass
        prompt = sys.stdin.read()
    if not prompt.strip():
        _die("Empty prompt (provide --prompt-file or stdin).", 2)

    messages: list[dict[str, str]] = []
    if args.system:
        messages.append({"role": "system", "content": args.system})
    messages.append({"role": "user", "content": prompt})

    body: dict[str, Any] = {
        "model": model,
        "messages": messages,
        "max_tokens": int(args.max_tokens),
        "thinking": {"type": args.thinking},
    }
    if args.json:
        body["response_format"] = {"type": "json_object"}

    tag = args.tag or ""
    status, parsed, raw = _http_json("POST", CHAT_URL, body)

    usage = {}
    if isinstance(parsed, dict) and isinstance(parsed.get("usage"), dict):
        usage = parsed["usage"]

    log_row = {
        "time": _now_iso(),
        "tag": tag,
        "model": model,
        "prompt_tokens": usage.get("prompt_tokens"),
        "completion_tokens": usage.get("completion_tokens"),
        "total_tokens": usage.get("total_tokens"),
        "status": "ok" if status == 200 else str(status),
    }

    if status in (401, 402):
        _append_usage(log_row)
        _die(
            f"DeepSeek auth/billing error HTTP {status}: {_error_message(status, parsed, raw)}",
            4,
        )

    # Insufficient balance often surfaces as 402 or an error message on other codes.
    err_text = _error_message(status, parsed, raw).lower()
    if status != 200 and (
        "insufficient" in err_text
        or "balance" in err_text
        or "quota" in err_text
        or "billing" in err_text
    ):
        _append_usage(log_row)
        _die(f"DeepSeek balance/quota error HTTP {status}: {_error_message(status, parsed, raw)}", 4)

    if status != 200 or not isinstance(parsed, dict):
        _append_usage(log_row)
        _die(f"Chat request failed HTTP {status}: {_error_message(status, parsed, raw)}", 5)

    choices = parsed.get("choices") or []
    text = ""
    finish_reason = None
    reasoning_len = 0
    if choices and isinstance(choices[0], dict):
        finish_reason = choices[0].get("finish_reason")
        msg = choices[0].get("message") or {}
        if isinstance(msg, dict):
            text = msg.get("content") or ""
            rc = msg.get("reasoning_content") or ""
            if isinstance(rc, str):
                reasoning_len = len(rc)
        if not text:
            text = choices[0].get("text") or ""
    if text is None:
        text = ""

    # deepseek-flash may spend the whole budget on reasoning_content
    if not str(text).strip():
        log_row["status"] = "empty_content"
        _append_usage(log_row)
        hint = ""
        if finish_reason == "length" or reasoning_len:
            hint = (
                f" Model used reasoning_content ({reasoning_len} chars) and left "
                f"message.content empty (finish_reason={finish_reason!r}). "
                "Retry with a higher --max-tokens (default 4000)."
            )
        _die(f"Chat returned empty content.{hint}", 6)

    _append_usage(log_row)

    if args.out:
        out_path = Path(args.out)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(text, encoding="utf-8")
    else:
        # Print only model text to stdout
        sys.stdout.write(text)
        if text and not text.endswith("\n"):
            sys.stdout.write("\n")
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="ds",
        description="Shared DeepSeek CLI (chat + balance + usage). Key never printed.",
    )
    sub = p.add_subparsers(dest="cmd", required=True)

    run_p = sub.add_parser("run", help="Chat completion; prints only model text")
    run_p.add_argument("--prompt-file", "-f", help="Prompt file path (else read stdin)")
    run_p.add_argument("--system", "-s", default=None, help="Optional system message")
    run_p.add_argument(
        "--model",
        "-m",
        default=DEFAULT_MODEL,
        choices=ALLOWED_MODELS,
        help=f"Model id (default {DEFAULT_MODEL})",
    )
    run_p.add_argument(
        "--max-tokens",
        type=int,
        default=DEFAULT_MAX_TOKENS,
        help=f"Max completion tokens (default {DEFAULT_MAX_TOKENS})",
    )
    run_p.add_argument(
        "--json",
        action="store_true",
        help="Request JSON object response_format",
    )
    run_p.add_argument("--out", "-o", help="Write model text to this file instead of stdout")
    run_p.add_argument("--tag", default="", help="Tag recorded in usage.jsonl")
    run_p.add_argument(
        "--thinking",
        choices=("disabled", "enabled"),
        default="disabled",
        help="DeepSeek thinking mode (default disabled for ordinary execution)",
    )
    run_p.set_defaults(func=cmd_run)

    bal_p = sub.add_parser("balance", help="Show account balance")
    bal_p.set_defaults(func=cmd_balance)

    use_p = sub.add_parser("usage", help="Summarize local usage.jsonl")
    use_p.add_argument(
        "--since",
        help="ISO date/datetime (Asia/Shanghai assumed if naive); only rows on/after",
    )
    use_p.set_defaults(func=cmd_usage)

    return p


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
