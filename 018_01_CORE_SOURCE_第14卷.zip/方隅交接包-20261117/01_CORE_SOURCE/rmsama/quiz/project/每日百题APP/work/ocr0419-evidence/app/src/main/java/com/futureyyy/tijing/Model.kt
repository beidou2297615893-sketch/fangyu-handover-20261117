package com.futureyyy.tijing
data class CaptureFrame(val dataUrl:String,val localPng:ByteArray?=null)
data class NormalizedBox(val x:Float,val y:Float,val width:Float,val height:Float) {val centerX:Float get()=x+width/2f;val centerY:Float get()=y+height/2f}
object VisibleQuestionReader{data class Node(val text:String,val box:NormalizedBox?,val children:List<Node> = emptyList(), val continuousRule:Boolean=false)}


