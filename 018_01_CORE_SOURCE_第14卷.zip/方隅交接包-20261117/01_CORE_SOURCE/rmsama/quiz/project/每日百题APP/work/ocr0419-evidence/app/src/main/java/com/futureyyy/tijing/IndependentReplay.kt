package com.futureyyy.tijing
import android.app.Instrumentation
import android.os.Bundle
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
class IndependentReplay:Instrumentation(){
 override fun onCreate(arguments:Bundle?){super.onCreate(arguments);start()}
 override fun onStart(){val out=Bundle()
 try{val input=JSONArray(context.openFileInput("lines-pages.json").bufferedReader().use{it.readText()});val all=JSONArray()
 IndependentLineReader(context).use{ engine ->
 for(i in 0 until input.length()){val row=input.getJSONObject(i);val name=row.getString("file");val src=row.getJSONArray("lines")
 val nodes=(0 until src.length()).map{j->val l=src.getJSONObject(j);val b=l.getJSONArray("box");VisibleQuestionReader.Node(l.getString("text"),NormalizedBox(b.getDouble(0).toFloat(),b.getDouble(1).toFloat(),b.getDouble(2).toFloat(),b.getDouble(3).toFloat()))}
 val image=context.assets.open(name).use{it.readBytes()}
 val read=engine.read(CaptureFrame("",image),nodes)
 val lines=JSONArray();for(n in read){val b=n.box!!;lines.put(JSONObject().put("text",n.text).put("continuousRule",n.continuousRule).put("box",JSONArray().put(b.x.toDouble()).put(b.y.toDouble()).put(b.width.toDouble()).put(b.height.toDouble())))}
 all.put(JSONObject().put("file",name).put("lines",lines))
 context.openFileOutput("pages-paddle.json",0).bufferedWriter().use{it.write(all.toString())}
 }}
 out.putString("stream","pages="+all.length()+"\n");finish(-1,out)
 }catch(e:Throwable){out.putString("stream",e.stackTraceToString());finish(0,out)}
 }}
