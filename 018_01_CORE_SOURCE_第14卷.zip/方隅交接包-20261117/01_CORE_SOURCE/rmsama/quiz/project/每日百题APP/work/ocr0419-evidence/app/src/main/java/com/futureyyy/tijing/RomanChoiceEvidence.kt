package com.futureyyy.tijing

import java.text.Normalizer
import kotlin.math.abs

/** Same-font, isolated I/V strokes in a four-level, common-prefix choice group. */
internal object RomanChoiceEvidence {
    private val labelled = Regex("""^([\u3400-\u9fff]{2,20})\s*([,、:])\s*[IV1丨|]{1,5}$""")
    private val levels = setOf("I", "II", "III", "IV")
    private data class Reading(val word: String, val prefix: BooleanArray, val prefixWidth: Int,
        val lineHeight: Int, val strokes: List<Pair<Int, Int>>)

    fun read(w: Int, h: Int, pixels: IntArray, rows: List<VisibleQuestionReader.Node>): List<VisibleQuestionReader.Node>? {
        if (rows.size != 4 || w.toLong() * h != pixels.size.toLong()) return null
        val labels = rows.map { labelled.matchEntire(Normalizer.normalize(it.text.trim(), Normalizer.Form.NFKC)) ?: return null }
        val prefix = labels.map { it.groupValues[1] + it.groupValues[2] }.distinct().singleOrNull() ?: return null
        val readings = rows.map { row ->
            val box = row.box ?: return null
            val l = ((box.x * w / 100).toInt() - 3).coerceAtLeast(0)
            val t = ((box.y * h / 100).toInt() - 3).coerceAtLeast(0)
            val r = (((box.x + box.width) * w / 100).toInt() + 3).coerceAtMost(w)
            val b = (((box.y + box.height) * h / 100).toInt() + 3).coerceAtMost(h)
            if (b - t !in 20..160 || r - l !in 20..800) return null
            val ink = BooleanArray((r-l)*(b-t)) { i ->
                val color = pixels[(t + i/(r-l))*w + l + i%(r-l)]
                ((color ushr 16 and 255)*77 + (color ushr 8 and 255)*150 + (color and 255)*29) < 140*256
            }
            readLine(ink, r-l, b-t) ?: return null
        }
        if (readings.map { it.word }.toSet() != levels) return null
        val ref = readings.first()
        if (readings.any { line ->
                line.prefixWidth != ref.prefixWidth || line.lineHeight != ref.lineHeight ||
                    line.prefix.indices.count { i -> line.prefix[i] != ref.prefix[i] } > ref.prefix.size * 0.045
            }) return null
        val strokes = readings.flatMap { it.strokes }
        if (strokes.maxOf { it.first } - strokes.minOf { it.first } > 1 ||
            strokes.maxOf { it.second } - strokes.minOf { it.second } > 1) return null
        return rows.mapIndexed { i, row -> row.copy(text = prefix + readings[i].word) }
    }

    private fun readLine(ink: BooleanArray, width: Int, height: Int): Reading? {
        val columns = (0 until width).filter { x -> (0 until height).any { y -> ink[y*width+x] } }
        val blank = columns.zipWithNext().lastOrNull { (l,r) -> r-l-1 > height * 0.40 && r > width * 0.55 } ?: return null
        val prefixWidth = blank.first+1
        val prefix = BooleanArray(prefixWidth*height) { i -> ink[i/prefixWidth*width+i%prefixWidth] }
        val spans = mutableListOf<IntRange>()
        for (x in columns.filter { it >= blank.second }) {
            val last = spans.lastOrNull()
            if (last == null || x > last.last+1) spans.add(x..x)
            else spans[spans.lastIndex] = last.first..x
        }
        if (spans.size !in 1..3) return null
        val word = StringBuilder()
        val strokes = mutableListOf<Pair<Int,Int>>()
        for (span in spans) {
            val ys = (0 until height).filter { y -> span.any { x -> ink[y*width+x] } }
            val top = ys.first(); val tall = ys.last()-top+1; val wide = span.last-span.first+1
            if (tall < 16 || ys.size != tall) return null
            val area = ys.sumOf { y -> span.count { x -> ink[y*width+x] } }
            if (wide <= tall*0.19 && area > wide*tall*0.88) {
                word.append('I');strokes.add(wide to tall)
            } else {
                fun xs(f: Double) = span.filter { x -> ink[(top+(tall*f).toInt())*width+x] }
                fun extent(xs: List<Int>) = xs.last()-xs.first()
                val a=xs(.10); val m=xs(.50);val b=xs(.88)
                if (a.size<2 || m.size<2 || b.size<2 || extent(a)<=wide*.70 || extent(b)>=wide*.5 ||
                    extent(b)>=extent(m) || extent(m)>=extent(a) || abs(b.average()-(span.first+span.last)/2.0)>wide*.2 ||
                    (a.first()..a.last()).none { !ink[(top+(tall*.10).toInt())*width+it] }) return null
                word.append('V')
            }
        }
        if (word.toString() !in levels) return null
        return Reading(word.toString(), prefix, prefixWidth, height, strokes)
    }
}
