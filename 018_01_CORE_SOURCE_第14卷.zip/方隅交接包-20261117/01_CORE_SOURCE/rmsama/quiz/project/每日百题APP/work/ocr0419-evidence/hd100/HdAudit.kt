package com.futureyyy.tijing
import com.google.gson.*
import java.io.File
fun main(){
 val bankRoot=JsonParser.parseString(File("V:/work/知题本轮验收/bank/铁路题库-保留选项变体.json").readText()).asJsonObject
 fun type(s:String)=when(s){"multiple"->QuestionType.MULTIPLE;"boolean","true_false"->QuestionType.TRUE_FALSE;"fill_blank"->QuestionType.FILL_BLANK;else->QuestionType.SINGLE}
 val records=bankRoot.getAsJsonArray("questions").map{v->val q=v.asJsonObject;LocalQuestionBankRecord(q.get("id").asString,q.get("question").asString,type(q.get("type").asString),q.getAsJsonArray("answer_indices").map{it.asInt},answerText=q.get("answer_text").asString,options=q.getAsJsonArray("options").map {val o=it.asJsonObject;QuizOption(o.get("index").asInt,o.get("text").asString,null)})}
 val bank=QuestionBankIndex.fromRecords(records, bankRoot.getAsJsonArray("conflicts").map { it.asJsonObject["normalized_question"].asString }.toSet())
 val root=File("V:/work/ocr0419-evidence/hd100")
 val manifests=listOf("manifest.json","replay-manifest.json","hundred-manifest.json").map { File(root,it) }.filter{it.exists()}.flatMap{JsonParser.parseString(it.readText()).asJsonObject["rows"].asJsonArray.toList()}.associate { it.asJsonObject["file"].asString to it.asJsonObject }
 for(kind in listOf("field-mlkit","field-paddle","replay-mlkit","replay-paddle","hundred-mlkit","hundred-paddle")) {
 val path=File(root,kind+".json");if(!path.exists())continue
 val out=JsonArray()
 for (item in JsonParser.parseString(path.readText()).asJsonArray) {
 val row=item.asJsonObject; val id=row["file"].asString.removePrefix("page-");val expected=manifests[id]?:continue
 val lines=row["lines"].asJsonArray.map{v->val n=v.asJsonObject;val b=n["box"].asJsonArray; VisibleQuestionReader.Node(n["text"].asString,NormalizedBox(b[0].asFloat,b[1].asFloat,b[2].asFloat.coerceAtMost(100f-b[0].asFloat),b[3].asFloat.coerceAtMost(100f-b[1].asFloat)),continuousRule=n["continuousRule"]?.asBoolean?:false)}
 val num=expected["questionNo"].asInt; val want=expected["expected"].asJsonArray.map { it.asString.single()-'A' }.toSet()
 val page=VisibleQuestionReader.readOcrLines(lines,num)
 val final=page?.let{runCatching {bank.verifiedAnswer(it)}.getOrNull()}?:bank.verifiedOcrPage(lines,num)
 val verified=when{final==null->"reject";final.answerIndices.toSet()==want->"correct";else->"WRONG"}
 val flags=OcrHostPage.read(lines)
 out.add(JsonObject().apply{addProperty("file",id);addProperty("questionNo",num);addProperty("outcome",verified);addProperty("readStem",page?.question);addProperty("readOptions",page?.options?.joinToString("|"){it.text});addProperty("answer",final?.answerIndices?.joinToString());add("answerCoordinates",Gson().toJsonTree(final?.options?.filter { it.index in final.answerIndices }?.map { it.box }));addProperty("phase",flags.page.progress?.current);addProperty("finish",flags.result)})
 }
 File(root,"audit-"+kind+".json").writeText(GsonBuilder().setPrettyPrinting().create().toJson(out)); println(kind+" "+out.map{it.asJsonObject["outcome"].asString}.groupingBy{it}.eachCount())
 }
}
