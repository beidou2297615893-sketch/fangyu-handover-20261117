from pathlib import Path
import json,subprocess,time
out=Path("V:/work/ocr0419-evidence/hd100");adb=["V:/work/tools/android-sdk/platform-tools/adb.exe","-P","15057","-s","127.0.0.1:5741"];pkg="com.jimusoft.ocrreplay";last=time.perf_counter()+60
while time.perf_counter()<last:
 r=subprocess.run(adb+["exec-out","run-as",pkg,"cat","files/lines-pages.json"],capture_output=True)
 try:a=json.loads(r.stdout)
 except ValueError:a=[]
 if len(a)==101 and a[0]["file"].startswith("page-full-"):
  (out/"a8-hundred-mlkit.json").write_bytes(r.stdout); break
 time.sleep(1)
else:raise Exception("batch not yet complete")
subprocess.run(adb+["install","-r","V:/work/ocr0419-evidence/app/build/outputs/apk/debug/app-debug.apk"],check=True)
subprocess.run(adb+["shell","am","instrument","-w","-e","method","a7spot",pkg+"/com.jimusoft.ocrreplay.Replay"],check=True)
subprocess.run(adb+["shell","am","instrument","-w",pkg+"/com.futureyyy.tijing.IndependentReplay"],check=True)
for device,local in [("files/lines-pages.json","a7-spot-mlkit.json"),("files/pages-paddle.json","a7-spot-paddle.json")]:
 data=subprocess.check_output(adb+["exec-out","run-as",pkg,"cat",device]);assert len(json.loads(data))==1;(out/local).write_bytes(data)
subprocess.run(adb+["push",str(out/"a8-hundred-mlkit.json"),"/data/local/tmp/ocr0419-pages.json"],check=True)
subprocess.run(adb+["shell","run-as",pkg,"cp","/data/local/tmp/ocr0419-pages.json","files/lines-pages.json"],check=True)
subprocess.run(adb+["shell","am","instrument","-w",pkg+"/com.futureyyy.tijing.IndependentReplay"],check=True)
res=subprocess.check_output(adb+["exec-out","run-as",pkg,"cat","files/pages-paddle.json"]);assert len(json.loads(res))==101;(out/"a8-hundred-paddle.json").write_bytes(res)
for tag in ["mlkit","paddle"]:(out/("hundred-"+tag+".json")).write_bytes((out/("a8-hundred-"+tag+".json")).read_bytes())
subprocess.run(["python","-X","utf8",str(out/"rejudge.py")],check=True)
