package com.jimusoft.ocrreplay;
import android.app.Instrumentation;
import android.os.Bundle;
import android.graphics.*;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.Text;
import com.google.android.gms.tasks.Tasks;
import java.io.*;
import java.util.concurrent.TimeUnit;
import org.json.*;
public final class Replay extends Instrumentation {
 private String runId;
 public void onCreate(Bundle b){super.onCreate(b);runId=b.getString("method","all");start();}
 public void onStart() {
  Bundle b=new Bundle(); int code=0;
  try(TextRecognizer client=TextRecognition.getClient(new ChineseTextRecognizerOptions.Builder().build())){
   for(String mode:new String[]{"pages"}){
    if(!runId.equals("all") && !mode.equals(runId) && !runId.equals("a7spot")) continue;
    JSONArray all=new JSONArray();long begin=System.currentTimeMillis();
    for(String name:getContext().getAssets().list("")){
     if (runId.equals("a7spot") ? !name.startsWith("page-spot-") : !(name.startsWith("page-full-") && name.endsWith(".png"))) continue;
     Bitmap raw;try(InputStream in=getContext().getAssets().open(name)){raw=BitmapFactory.decodeStream(in);}
     float scale=mode.equals("native")?1f:mode.equals("scale150")?1.5f:mode.equals("scale280Pad")?2.8f:2f;
     if(mode.equals("crop300")) { if(!name.equals("sample-h4.png")) {raw.recycle(); continue;} Bitmap cropped=Bitmap.createBitmap(raw,0,(int)(raw.getHeight()*.16),raw.getWidth(),(int)(raw.getHeight()*.27)); raw.recycle();raw=cropped;scale=3f;} if(mode.equals("pages"))scale=1f; int pad=mode.equals("scale280Pad")?20:0;
     int w=Math.round(raw.getWidth()*scale),h=Math.round(raw.getHeight()*scale);
     Bitmap bmp=Bitmap.createBitmap(w+2*pad,h+2*pad,Bitmap.Config.ARGB_8888);
     Canvas canvas=new Canvas(bmp);canvas.drawColor(Color.WHITE);
     Paint paint=new Paint(Paint.FILTER_BITMAP_FLAG);
     if(mode.equals("grayContrast")){
      ColorMatrix gray=new ColorMatrix();gray.setSaturation(0);float c=1.4f;float t=128*(1-c);
      gray.postConcat(new ColorMatrix(new float[]{c,0,0,0,t,0,c,0,0,t,0,0,c,0,t,0,0,0,1,0}));
      paint.setColorFilter(new ColorMatrixColorFilter(gray));
     }
     canvas.drawBitmap(raw,null,new Rect(pad,pad,pad+w,pad+h),paint);raw.recycle();
     Text out=Tasks.await(client.process(InputImage.fromBitmap(bmp,0)),30,TimeUnit.SECONDS);
     JSONArray lines=new JSONArray();for(Text.TextBlock block:out.getTextBlocks())for(Text.Line line:block.getLines()){
      Rect r=line.getBoundingBox();if(r==null)continue;
      float x=(float)Math.max(0,Math.min(100,100.0*(r.left-pad)/w)), y=(float)Math.max(0,Math.min(100,100.0*(r.top-pad)/h)); float ww=Math.min(100-x,100f*r.width()/w), hh=Math.min(100-y,100f*r.height()/h); if(ww<=0||hh<=0)continue;
      lines.put(new JSONObject().put("text",line.getText()).put("box",new JSONArray().put(x).put(y).put(ww).put(hh)));
     }
     bmp.recycle();all.put(new JSONObject().put("file",name).put("lines",lines));
     try(FileOutputStream os=getContext().openFileOutput("lines-"+mode+".json",0)){os.write(all.toString().getBytes("UTF-8"));}
    }
    try(FileOutputStream os=getContext().openFileOutput("lines-"+mode+".json",0)){os.write(all.toString().getBytes("UTF-8"));}
    b.putString("stream",mode+" n="+all.length()+" seconds="+(System.currentTimeMillis()-begin)/1000.0+"\n");sendStatus(0,b);
   }
   code=-1;
  }catch(Throwable t){b.putString("stream","failed "+t+"\n");}
  finish(code,b);
 }
}








