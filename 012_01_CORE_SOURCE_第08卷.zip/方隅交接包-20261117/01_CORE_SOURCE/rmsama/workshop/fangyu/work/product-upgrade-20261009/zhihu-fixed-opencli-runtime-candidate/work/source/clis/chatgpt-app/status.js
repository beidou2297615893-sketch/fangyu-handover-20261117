import { execSync } from 'node:child_process';
import { cli, Strategy } from '@jackwener/opencli/registry';
import { CommandExecutionError, ConfigError } from '@jackwener/opencli/errors';
export const statusCommand = cli({
    site: 'chatgpt-app',
    name: 'status',
    access: 'read',
    description: 'Check if ChatGPT Desktop App is running natively on macOS',
    domain: 'localhost',
    strategy: Strategy.PUBLIC,
    browser: false,
    args: [],
    columns: ['Status'],
    func: async () => {
        if (process.platform !== 'darwin') {
            throw new ConfigError('ChatGPT Desktop integration requires macOS (osascript is not available on this platform)');
        }
        try {
            const output = execSync("osascript -e 'application \"ChatGPT\" is running'", { encoding: 'utf-8' }).trim();
            return [{ Status: output === 'true' ? 'Running' : 'Stopped' }];
        }
        catch {
            throw new CommandExecutionError('Error querying ChatGPT application state');
        }
    },
});
